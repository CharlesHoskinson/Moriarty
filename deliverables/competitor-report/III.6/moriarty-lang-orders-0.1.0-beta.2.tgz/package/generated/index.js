import * as __compactRuntime from '@midnight-ntwrk/compact-runtime';
__compactRuntime.checkRuntimeVersion('0.21.0');

const _descriptor_0 = new __compactRuntime.CompactTypeUnsignedInteger(340282366920938463463374607431768211455n, 16);

const _descriptor_1 = new __compactRuntime.CompactTypeBytes(32);

class _UserAddress_0 {
  alignment() {
    return _descriptor_1.alignment();
  }
  fromValue(value_0) {
    return {
      bytes: _descriptor_1.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_1.toValue(value_0.bytes);
  }
}

const _descriptor_2 = new _UserAddress_0();

const _descriptor_3 = new __compactRuntime.CompactTypeUnsignedInteger(18446744073709551615n, 8);

class _OrderTerms_0 {
  alignment() {
    return _descriptor_2.alignment().concat(_descriptor_2.alignment().concat(_descriptor_2.alignment().concat(_descriptor_1.alignment().concat(_descriptor_1.alignment().concat(_descriptor_1.alignment().concat(_descriptor_1.alignment().concat(_descriptor_1.alignment().concat(_descriptor_3.alignment().concat(_descriptor_0.alignment().concat(_descriptor_0.alignment().concat(_descriptor_0.alignment().concat(_descriptor_3.alignment()))))))))))));
  }
  fromValue(value_0) {
    return {
      account: _descriptor_2.fromValue(value_0),
      recipient: _descriptor_2.fromValue(value_0),
      executor: _descriptor_2.fromValue(value_0),
      orderId: _descriptor_1.fromValue(value_0),
      network: _descriptor_1.fromValue(value_0),
      assetA: _descriptor_1.fromValue(value_0),
      assetB: _descriptor_1.fromValue(value_0),
      program: _descriptor_1.fromValue(value_0),
      epoch: _descriptor_3.fromValue(value_0),
      input: _descriptor_0.fromValue(value_0),
      minimum: _descriptor_0.fromValue(value_0),
      fee: _descriptor_0.fromValue(value_0),
      expiry: _descriptor_3.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_2.toValue(value_0.account).concat(_descriptor_2.toValue(value_0.recipient).concat(_descriptor_2.toValue(value_0.executor).concat(_descriptor_1.toValue(value_0.orderId).concat(_descriptor_1.toValue(value_0.network).concat(_descriptor_1.toValue(value_0.assetA).concat(_descriptor_1.toValue(value_0.assetB).concat(_descriptor_1.toValue(value_0.program).concat(_descriptor_3.toValue(value_0.epoch).concat(_descriptor_0.toValue(value_0.input).concat(_descriptor_0.toValue(value_0.minimum).concat(_descriptor_0.toValue(value_0.fee).concat(_descriptor_3.toValue(value_0.expiry)))))))))))));
  }
}

const _descriptor_4 = new _OrderTerms_0();

class _KernelState_0 {
  alignment() {
    return _descriptor_0.alignment().concat(_descriptor_0.alignment().concat(_descriptor_0.alignment().concat(_descriptor_0.alignment())));
  }
  fromValue(value_0) {
    return {
      f0: _descriptor_0.fromValue(value_0),
      f1: _descriptor_0.fromValue(value_0),
      f2: _descriptor_0.fromValue(value_0),
      f3: _descriptor_0.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_0.toValue(value_0.f0).concat(_descriptor_0.toValue(value_0.f1).concat(_descriptor_0.toValue(value_0.f2).concat(_descriptor_0.toValue(value_0.f3))));
  }
}

const _descriptor_5 = new _KernelState_0();

const _descriptor_6 = __compactRuntime.CompactTypeJubjubPoint;

const _descriptor_7 = __compactRuntime.CompactTypeField;

class _OrderSignature_0 {
  alignment() {
    return _descriptor_6.alignment().concat(_descriptor_7.alignment());
  }
  fromValue(value_0) {
    return {
      announcement: _descriptor_6.fromValue(value_0),
      response: _descriptor_7.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_6.toValue(value_0.announcement).concat(_descriptor_7.toValue(value_0.response));
  }
}

const _descriptor_8 = new _OrderSignature_0();

const _descriptor_9 = __compactRuntime.CompactTypeBoolean;

class _ContractAddress_0 {
  alignment() {
    return _descriptor_1.alignment();
  }
  fromValue(value_0) {
    return {
      bytes: _descriptor_1.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_1.toValue(value_0.bytes);
  }
}

const _descriptor_10 = new _ContractAddress_0();

const _descriptor_11 = new __compactRuntime.CompactTypeUnsignedInteger(255n, 1);

const _descriptor_12 = new __compactRuntime.CompactTypeUnsignedInteger(4294967295n, 4);

class _Arguments1_0 {
  alignment() {
    return _descriptor_12.alignment();
  }
  fromValue(value_0) {
    return {
      a0: _descriptor_12.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_12.toValue(value_0.a0);
  }
}

const _descriptor_13 = new _Arguments1_0();

class _KernelObservations_0 {
  alignment() {
    return _descriptor_0.alignment();
  }
  fromValue(value_0) {
    return {
      o0: _descriptor_0.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_0.toValue(value_0.o0);
  }
}

const _descriptor_14 = new _KernelObservations_0();

const _descriptor_15 = new __compactRuntime.CompactTypeUnsignedInteger(1n, 1);

class _Hints1_0 {
  alignment() {
    return _descriptor_15.alignment();
  }
  fromValue(value_0) {
    return {
      unused: _descriptor_15.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_15.toValue(value_0.unused);
  }
}

const _descriptor_16 = new _Hints1_0();

class _Effect1_0_0 {
  alignment() {
    return _descriptor_12.alignment().concat(_descriptor_12.alignment().concat(_descriptor_12.alignment().concat(_descriptor_0.alignment())));
  }
  fromValue(value_0) {
    return {
      v0: _descriptor_12.fromValue(value_0),
      v1: _descriptor_12.fromValue(value_0),
      v2: _descriptor_12.fromValue(value_0),
      v3: _descriptor_0.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_12.toValue(value_0.v0).concat(_descriptor_12.toValue(value_0.v1).concat(_descriptor_12.toValue(value_0.v2).concat(_descriptor_0.toValue(value_0.v3))));
  }
}

const _descriptor_17 = new _Effect1_0_0();

class _Result1_0 {
  alignment() {
    return _descriptor_5.alignment().concat(_descriptor_0.alignment().concat(_descriptor_0.alignment().concat(_descriptor_17.alignment())));
  }
  fromValue(value_0) {
    return {
      after: _descriptor_5.fromValue(value_0),
      remaining: _descriptor_0.fromValue(value_0),
      revision: _descriptor_0.fromValue(value_0),
      effect0: _descriptor_17.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_5.toValue(value_0.after).concat(_descriptor_0.toValue(value_0.remaining).concat(_descriptor_0.toValue(value_0.revision).concat(_descriptor_17.toValue(value_0.effect0))));
  }
}

const _descriptor_18 = new _Result1_0();

class _MulHint_0 {
  alignment() {
    return _descriptor_3.alignment().concat(_descriptor_3.alignment().concat(_descriptor_3.alignment().concat(_descriptor_3.alignment().concat(_descriptor_3.alignment().concat(_descriptor_3.alignment())))));
  }
  fromValue(value_0) {
    return {
      aLo: _descriptor_3.fromValue(value_0),
      aHi: _descriptor_3.fromValue(value_0),
      bLo: _descriptor_3.fromValue(value_0),
      bHi: _descriptor_3.fromValue(value_0),
      lo: _descriptor_3.fromValue(value_0),
      carry: _descriptor_3.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_3.toValue(value_0.aLo).concat(_descriptor_3.toValue(value_0.aHi).concat(_descriptor_3.toValue(value_0.bLo).concat(_descriptor_3.toValue(value_0.bHi).concat(_descriptor_3.toValue(value_0.lo).concat(_descriptor_3.toValue(value_0.carry))))));
  }
}

const _descriptor_19 = new _MulHint_0();

class _Arguments0_0 {
  alignment() {
    return _descriptor_12.alignment().concat(_descriptor_12.alignment().concat(_descriptor_0.alignment().concat(_descriptor_0.alignment())));
  }
  fromValue(value_0) {
    return {
      a0: _descriptor_12.fromValue(value_0),
      a1: _descriptor_12.fromValue(value_0),
      a2: _descriptor_0.fromValue(value_0),
      a3: _descriptor_0.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_12.toValue(value_0.a0).concat(_descriptor_12.toValue(value_0.a1).concat(_descriptor_0.toValue(value_0.a2).concat(_descriptor_0.toValue(value_0.a3))));
  }
}

const _descriptor_20 = new _Arguments0_0();

class _Hints0_0 {
  alignment() {
    return _descriptor_15.alignment();
  }
  fromValue(value_0) {
    return {
      unused: _descriptor_15.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_15.toValue(value_0.unused);
  }
}

const _descriptor_21 = new _Hints0_0();

class _Effect0_0_0 {
  alignment() {
    return _descriptor_12.alignment().concat(_descriptor_12.alignment().concat(_descriptor_12.alignment().concat(_descriptor_0.alignment())));
  }
  fromValue(value_0) {
    return {
      v0: _descriptor_12.fromValue(value_0),
      v1: _descriptor_12.fromValue(value_0),
      v2: _descriptor_12.fromValue(value_0),
      v3: _descriptor_0.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_12.toValue(value_0.v0).concat(_descriptor_12.toValue(value_0.v1).concat(_descriptor_12.toValue(value_0.v2).concat(_descriptor_0.toValue(value_0.v3))));
  }
}

const _descriptor_22 = new _Effect0_0_0();

class _Effect0_1_0 {
  alignment() {
    return _descriptor_12.alignment().concat(_descriptor_12.alignment().concat(_descriptor_12.alignment().concat(_descriptor_0.alignment())));
  }
  fromValue(value_0) {
    return {
      v0: _descriptor_12.fromValue(value_0),
      v1: _descriptor_12.fromValue(value_0),
      v2: _descriptor_12.fromValue(value_0),
      v3: _descriptor_0.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_12.toValue(value_0.v0).concat(_descriptor_12.toValue(value_0.v1).concat(_descriptor_12.toValue(value_0.v2).concat(_descriptor_0.toValue(value_0.v3))));
  }
}

const _descriptor_23 = new _Effect0_1_0();

class _Result0_0 {
  alignment() {
    return _descriptor_5.alignment().concat(_descriptor_0.alignment().concat(_descriptor_0.alignment().concat(_descriptor_22.alignment().concat(_descriptor_23.alignment()))));
  }
  fromValue(value_0) {
    return {
      after: _descriptor_5.fromValue(value_0),
      remaining: _descriptor_0.fromValue(value_0),
      revision: _descriptor_0.fromValue(value_0),
      effect0: _descriptor_22.fromValue(value_0),
      effect1: _descriptor_23.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_5.toValue(value_0.after).concat(_descriptor_0.toValue(value_0.remaining).concat(_descriptor_0.toValue(value_0.revision).concat(_descriptor_22.toValue(value_0.effect0).concat(_descriptor_23.toValue(value_0.effect1)))));
  }
}

const _descriptor_24 = new _Result0_0();

const _descriptor_25 = __compactRuntime.CompactTypeJubjubScalar;

class _Challenge_0 {
  alignment() {
    return _descriptor_1.alignment().concat(_descriptor_4.alignment().concat(_descriptor_10.alignment().concat(_descriptor_7.alignment().concat(_descriptor_7.alignment().concat(_descriptor_11.alignment().concat(_descriptor_0.alignment().concat(_descriptor_7.alignment().concat(_descriptor_7.alignment()))))))));
  }
  fromValue(value_0) {
    return {
      domain: _descriptor_1.fromValue(value_0),
      terms: _descriptor_4.fromValue(value_0),
      instance: _descriptor_10.fromValue(value_0),
      ownerX: _descriptor_7.fromValue(value_0),
      ownerY: _descriptor_7.fromValue(value_0),
      action: _descriptor_11.fromValue(value_0),
      revision: _descriptor_0.fromValue(value_0),
      announcementX: _descriptor_7.fromValue(value_0),
      announcementY: _descriptor_7.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_1.toValue(value_0.domain).concat(_descriptor_4.toValue(value_0.terms).concat(_descriptor_10.toValue(value_0.instance).concat(_descriptor_7.toValue(value_0.ownerX).concat(_descriptor_7.toValue(value_0.ownerY).concat(_descriptor_11.toValue(value_0.action).concat(_descriptor_0.toValue(value_0.revision).concat(_descriptor_7.toValue(value_0.announcementX).concat(_descriptor_7.toValue(value_0.announcementY)))))))));
  }
}

const _descriptor_26 = new _Challenge_0();

class _Either_0 {
  alignment() {
    return _descriptor_9.alignment().concat(_descriptor_1.alignment().concat(_descriptor_1.alignment()));
  }
  fromValue(value_0) {
    return {
      is_left: _descriptor_9.fromValue(value_0),
      left: _descriptor_1.fromValue(value_0),
      right: _descriptor_1.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_9.toValue(value_0.is_left).concat(_descriptor_1.toValue(value_0.left).concat(_descriptor_1.toValue(value_0.right)));
  }
}

const _descriptor_27 = new _Either_0();

class _Either_1 {
  alignment() {
    return _descriptor_9.alignment().concat(_descriptor_10.alignment().concat(_descriptor_2.alignment()));
  }
  fromValue(value_0) {
    return {
      is_left: _descriptor_9.fromValue(value_0),
      left: _descriptor_10.fromValue(value_0),
      right: _descriptor_2.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_9.toValue(value_0.is_left).concat(_descriptor_10.toValue(value_0.left).concat(_descriptor_2.toValue(value_0.right)));
  }
}

const _descriptor_28 = new _Either_1();

class _Maybe_0 {
  alignment() {
    return _descriptor_9.alignment().concat(_descriptor_28.alignment());
  }
  fromValue(value_0) {
    return {
      is_some: _descriptor_9.fromValue(value_0),
      value: _descriptor_28.fromValue(value_0)
    }
  }
  toValue(value_0) {
    return _descriptor_9.toValue(value_0.is_some).concat(_descriptor_28.toValue(value_0.value));
  }
}

const _descriptor_29 = new _Maybe_0();

export class Contract {
  witnesses;
  constructor(...args_0) {
    if (args_0.length !== 1) {
      throw new __compactRuntime.CompactError(`Contract constructor: expected 1 argument, received ${args_0.length}`);
    }
    const witnesses_0 = args_0[0];
    if (typeof(witnesses_0) !== 'object') {
      throw new __compactRuntime.CompactError('first (witnesses) argument to Contract constructor is not an object');
    }
    this.witnesses = witnesses_0;
    this.circuits = {
      async checkedAdd(context, ...args_1) {
        return { result: pureCircuits.checkedAdd(...args_1), context };
      },
      async checkedSub(context, ...args_1) {
        return { result: pureCircuits.checkedSub(...args_1), context };
      },
      async checkedMul(context, ...args_1) {
        return { result: pureCircuits.checkedMul(...args_1), context };
      },
      async checkedDiv(context, ...args_1) {
        return { result: pureCircuits.checkedDiv(...args_1), context };
      },
      async transition0(context, ...args_1) {
        return { result: pureCircuits.transition0(...args_1), context };
      },
      async transition1(context, ...args_1) {
        return { result: pureCircuits.transition1(...args_1), context };
      },
      async orderChallenge(context, ...args_1) {
        return { result: pureCircuits.orderChallenge(...args_1), context };
      },
      fund: async (...args_1) => {
        if (args_1.length !== 1) {
          throw new __compactRuntime.CompactError(`fund: expected 1 argument (as invoked from Typescript), received ${args_1.length}`);
        }
        const contextOrig_0 = args_1[0];
        if (!(typeof(contextOrig_0) === 'object' && contextOrig_0.callContext.currentQueryContext != undefined)) {
          __compactRuntime.typeError('fund',
                                     'argument 1 (as invoked from Typescript)',
                                     'acceptance.compact line 55 char 1',
                                     'CircuitContext',
                                     contextOrig_0)
        }
        const context = __compactRuntime.copyCircuitContext(contextOrig_0);
        const partialProofData = {
          input: { value: [], alignment: [] },
          output: undefined,
          publicTranscript: [],
          privateTranscriptOutputs: []
        };
        const result_0 = await this._fund_0(context, partialProofData);
        partialProofData.output = { value: [], alignment: [] };
        __compactRuntime.finalizeCallProofData(context, partialProofData);
        return { result: result_0, context: context, gasCost: context.callContext.currentGasCost };
      },
      fill: async (...args_1) => {
        if (args_1.length !== 7) {
          throw new __compactRuntime.CompactError(`fill: expected 7 arguments (as invoked from Typescript), received ${args_1.length}`);
        }
        const contextOrig_0 = args_1[0];
        const expected_0 = args_1[1];
        const amountA_0 = args_1[2];
        const amountB_0 = args_1[3];
        const applicationFee_0 = args_1[4];
        const now_0 = args_1[5];
        const sig_0 = args_1[6];
        if (!(typeof(contextOrig_0) === 'object' && contextOrig_0.callContext.currentQueryContext != undefined)) {
          __compactRuntime.typeError('fill',
                                     'argument 1 (as invoked from Typescript)',
                                     'acceptance.compact line 63 char 1',
                                     'CircuitContext',
                                     contextOrig_0)
        }
        if (!(typeof(expected_0) === 'bigint' && expected_0 >= 0n && expected_0 <= 340282366920938463463374607431768211455n)) {
          __compactRuntime.typeError('fill',
                                     'argument 1 (argument 2 as invoked from Typescript)',
                                     'acceptance.compact line 63 char 1',
                                     'Uint<0..340282366920938463463374607431768211456>',
                                     expected_0)
        }
        if (!(typeof(amountA_0) === 'bigint' && amountA_0 >= 0n && amountA_0 <= 340282366920938463463374607431768211455n)) {
          __compactRuntime.typeError('fill',
                                     'argument 2 (argument 3 as invoked from Typescript)',
                                     'acceptance.compact line 63 char 1',
                                     'Uint<0..340282366920938463463374607431768211456>',
                                     amountA_0)
        }
        if (!(typeof(amountB_0) === 'bigint' && amountB_0 >= 0n && amountB_0 <= 340282366920938463463374607431768211455n)) {
          __compactRuntime.typeError('fill',
                                     'argument 3 (argument 4 as invoked from Typescript)',
                                     'acceptance.compact line 63 char 1',
                                     'Uint<0..340282366920938463463374607431768211456>',
                                     amountB_0)
        }
        if (!(typeof(applicationFee_0) === 'bigint' && applicationFee_0 >= 0n && applicationFee_0 <= 340282366920938463463374607431768211455n)) {
          __compactRuntime.typeError('fill',
                                     'argument 4 (argument 5 as invoked from Typescript)',
                                     'acceptance.compact line 63 char 1',
                                     'Uint<0..340282366920938463463374607431768211456>',
                                     applicationFee_0)
        }
        if (!(typeof(now_0) === 'bigint' && now_0 >= 0n && now_0 <= 18446744073709551615n)) {
          __compactRuntime.typeError('fill',
                                     'argument 5 (argument 6 as invoked from Typescript)',
                                     'acceptance.compact line 63 char 1',
                                     'Uint<0..18446744073709551616>',
                                     now_0)
        }
        if (!(typeof(sig_0) === 'object' && typeof(sig_0.announcement.x) === 'bigint' && sig_0.announcement.x >= 0n && sig_0.announcement.x <= __compactRuntime.MAX_FIELD && typeof(sig_0.announcement.y) === 'bigint' && sig_0.announcement.y >= 0n && sig_0.announcement.y <= __compactRuntime.MAX_FIELD && typeof(sig_0.response) === 'bigint' && sig_0.response >= 0 && sig_0.response <= __compactRuntime.MAX_FIELD)) {
          __compactRuntime.typeError('fill',
                                     'argument 6 (argument 7 as invoked from Typescript)',
                                     'acceptance.compact line 63 char 1',
                                     'struct OrderSignature<announcement: JubjubPoint, response: Field>',
                                     sig_0)
        }
        const context = __compactRuntime.copyCircuitContext(contextOrig_0);
        const partialProofData = {
          input: {
            value: _descriptor_0.toValue(expected_0).concat(_descriptor_0.toValue(amountA_0).concat(_descriptor_0.toValue(amountB_0).concat(_descriptor_0.toValue(applicationFee_0).concat(_descriptor_3.toValue(now_0).concat(_descriptor_8.toValue(sig_0)))))),
            alignment: _descriptor_0.alignment().concat(_descriptor_0.alignment().concat(_descriptor_0.alignment().concat(_descriptor_0.alignment().concat(_descriptor_3.alignment().concat(_descriptor_8.alignment())))))
          },
          output: undefined,
          publicTranscript: [],
          privateTranscriptOutputs: []
        };
        const result_0 = await this._fill_0(context,
                                            partialProofData,
                                            expected_0,
                                            amountA_0,
                                            amountB_0,
                                            applicationFee_0,
                                            now_0,
                                            sig_0);
        partialProofData.output = { value: [], alignment: [] };
        __compactRuntime.finalizeCallProofData(context, partialProofData);
        return { result: result_0, context: context, gasCost: context.callContext.currentGasCost };
      },
      cancel: async (...args_1) => {
        if (args_1.length !== 3) {
          throw new __compactRuntime.CompactError(`cancel: expected 3 arguments (as invoked from Typescript), received ${args_1.length}`);
        }
        const contextOrig_0 = args_1[0];
        const expected_0 = args_1[1];
        const sig_0 = args_1[2];
        if (!(typeof(contextOrig_0) === 'object' && contextOrig_0.callContext.currentQueryContext != undefined)) {
          __compactRuntime.typeError('cancel',
                                     'argument 1 (as invoked from Typescript)',
                                     'acceptance.compact line 81 char 1',
                                     'CircuitContext',
                                     contextOrig_0)
        }
        if (!(typeof(expected_0) === 'bigint' && expected_0 >= 0n && expected_0 <= 340282366920938463463374607431768211455n)) {
          __compactRuntime.typeError('cancel',
                                     'argument 1 (argument 2 as invoked from Typescript)',
                                     'acceptance.compact line 81 char 1',
                                     'Uint<0..340282366920938463463374607431768211456>',
                                     expected_0)
        }
        if (!(typeof(sig_0) === 'object' && typeof(sig_0.announcement.x) === 'bigint' && sig_0.announcement.x >= 0n && sig_0.announcement.x <= __compactRuntime.MAX_FIELD && typeof(sig_0.announcement.y) === 'bigint' && sig_0.announcement.y >= 0n && sig_0.announcement.y <= __compactRuntime.MAX_FIELD && typeof(sig_0.response) === 'bigint' && sig_0.response >= 0 && sig_0.response <= __compactRuntime.MAX_FIELD)) {
          __compactRuntime.typeError('cancel',
                                     'argument 2 (argument 3 as invoked from Typescript)',
                                     'acceptance.compact line 81 char 1',
                                     'struct OrderSignature<announcement: JubjubPoint, response: Field>',
                                     sig_0)
        }
        const context = __compactRuntime.copyCircuitContext(contextOrig_0);
        const partialProofData = {
          input: {
            value: _descriptor_0.toValue(expected_0).concat(_descriptor_8.toValue(sig_0)),
            alignment: _descriptor_0.alignment().concat(_descriptor_8.alignment())
          },
          output: undefined,
          publicTranscript: [],
          privateTranscriptOutputs: []
        };
        const result_0 = await this._cancel_0(context,
                                              partialProofData,
                                              expected_0,
                                              sig_0);
        partialProofData.output = { value: [], alignment: [] };
        __compactRuntime.finalizeCallProofData(context, partialProofData);
        return { result: result_0, context: context, gasCost: context.callContext.currentGasCost };
      }
    };
    this.impureCircuits = {
      fund: this.circuits.fund,
      fill: this.circuits.fill,
      cancel: this.circuits.cancel
    };
    this.provableCircuits = {
      fund: this.circuits.fund,
      fill: this.circuits.fill,
      cancel: this.circuits.cancel
    };
  }
  async initialState(...args_0) {
    if (args_0.length !== 3) {
      throw new __compactRuntime.CompactError(`Contract state constructor: expected 3 arguments (as invoked from Typescript), received ${args_0.length}`);
    }
    const constructorContext_0 = args_0[0];
    const order_0 = args_0[1];
    const owner_0 = args_0[2];
    if (typeof(constructorContext_0) !== 'object') {
      throw new __compactRuntime.CompactError(`Contract state constructor: expected 'constructorContext' in argument 1 (as invoked from Typescript) to be an object`);
    }
    if (!('initialZswapLocalState' in constructorContext_0)) {
      throw new __compactRuntime.CompactError(`Contract state constructor: expected 'initialZswapLocalState' in argument 1 (as invoked from Typescript)`);
    }
    if (typeof(constructorContext_0.initialZswapLocalState) !== 'object') {
      throw new __compactRuntime.CompactError(`Contract state constructor: expected 'initialZswapLocalState' in argument 1 (as invoked from Typescript) to be an object`);
    }
    if (!(typeof(order_0) === 'object' && typeof(order_0.account) === 'object' && order_0.account.bytes.buffer instanceof ArrayBuffer && order_0.account.bytes.BYTES_PER_ELEMENT === 1 && order_0.account.bytes.length === 32 && typeof(order_0.recipient) === 'object' && order_0.recipient.bytes.buffer instanceof ArrayBuffer && order_0.recipient.bytes.BYTES_PER_ELEMENT === 1 && order_0.recipient.bytes.length === 32 && typeof(order_0.executor) === 'object' && order_0.executor.bytes.buffer instanceof ArrayBuffer && order_0.executor.bytes.BYTES_PER_ELEMENT === 1 && order_0.executor.bytes.length === 32 && order_0.orderId.buffer instanceof ArrayBuffer && order_0.orderId.BYTES_PER_ELEMENT === 1 && order_0.orderId.length === 32 && order_0.network.buffer instanceof ArrayBuffer && order_0.network.BYTES_PER_ELEMENT === 1 && order_0.network.length === 32 && order_0.assetA.buffer instanceof ArrayBuffer && order_0.assetA.BYTES_PER_ELEMENT === 1 && order_0.assetA.length === 32 && order_0.assetB.buffer instanceof ArrayBuffer && order_0.assetB.BYTES_PER_ELEMENT === 1 && order_0.assetB.length === 32 && order_0.program.buffer instanceof ArrayBuffer && order_0.program.BYTES_PER_ELEMENT === 1 && order_0.program.length === 32 && typeof(order_0.epoch) === 'bigint' && order_0.epoch >= 0n && order_0.epoch <= 18446744073709551615n && typeof(order_0.input) === 'bigint' && order_0.input >= 0n && order_0.input <= 340282366920938463463374607431768211455n && typeof(order_0.minimum) === 'bigint' && order_0.minimum >= 0n && order_0.minimum <= 340282366920938463463374607431768211455n && typeof(order_0.fee) === 'bigint' && order_0.fee >= 0n && order_0.fee <= 340282366920938463463374607431768211455n && typeof(order_0.expiry) === 'bigint' && order_0.expiry >= 0n && order_0.expiry <= 18446744073709551615n)) {
      __compactRuntime.typeError('Contract state constructor',
                                 'argument 1 (argument 2 as invoked from Typescript)',
                                 'acceptance.compact line 27 char 1',
                                 'struct OrderTerms<account: struct UserAddress<bytes: Bytes<32>>, recipient: struct UserAddress<bytes: Bytes<32>>, executor: struct UserAddress<bytes: Bytes<32>>, orderId: Bytes<32>, network: Bytes<32>, assetA: Bytes<32>, assetB: Bytes<32>, program: Bytes<32>, epoch: Uint<0..18446744073709551616>, input: Uint<0..340282366920938463463374607431768211456>, minimum: Uint<0..340282366920938463463374607431768211456>, fee: Uint<0..340282366920938463463374607431768211456>, expiry: Uint<0..18446744073709551616>>',
                                 order_0)
    }
    if (!(typeof(owner_0.x) === 'bigint' && owner_0.x >= 0n && owner_0.x <= __compactRuntime.MAX_FIELD && typeof(owner_0.y) === 'bigint' && owner_0.y >= 0n && owner_0.y <= __compactRuntime.MAX_FIELD)) {
      __compactRuntime.typeError('Contract state constructor',
                                 'argument 2 (argument 3 as invoked from Typescript)',
                                 'acceptance.compact line 27 char 1',
                                 'JubjubPoint',
                                 owner_0)
    }
    const state_0 = new __compactRuntime.ContractState();
    let stateValue_0 = __compactRuntime.StateValue.newArray();
    stateValue_0 = stateValue_0.arrayPush(__compactRuntime.StateValue.newNull());
    stateValue_0 = stateValue_0.arrayPush(__compactRuntime.StateValue.newNull());
    stateValue_0 = stateValue_0.arrayPush(__compactRuntime.StateValue.newNull());
    stateValue_0 = stateValue_0.arrayPush(__compactRuntime.StateValue.newNull());
    stateValue_0 = stateValue_0.arrayPush(__compactRuntime.StateValue.newNull());
    stateValue_0 = stateValue_0.arrayPush(__compactRuntime.StateValue.newNull());
    state_0.data = new __compactRuntime.ChargedState(stateValue_0);
    state_0.setOperation('fund', new __compactRuntime.ContractOperation());
    state_0.setOperation('fill', new __compactRuntime.ContractOperation());
    state_0.setOperation('cancel', new __compactRuntime.ContractOperation());
    const context = __compactRuntime.createCircuitContext({circuitId: 'constructor', contractAddress: __compactRuntime.dummyContractAddress(), coinPublicKeyOrZswapState: constructorContext_0.initialZswapLocalState.coinPublicKey, contractState: state_0.data, privateState: constructorContext_0.initialPrivateState});
    const partialProofData = {
      input: { value: [], alignment: [] },
      output: undefined,
      publicTranscript: [],
      privateTranscriptOutputs: []
    };
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(0n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_4.toValue({ account: { bytes: new Uint8Array(32) }, recipient: { bytes: new Uint8Array(32) }, executor: { bytes: new Uint8Array(32) }, orderId: new Uint8Array(32), network: new Uint8Array(32), assetA: new Uint8Array(32), assetB: new Uint8Array(32), program: new Uint8Array(32), epoch: 0n, input: 0n, minimum: 0n, fee: 0n, expiry: 0n }),
                                                                                              alignment: _descriptor_4.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(1n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_6.toValue(({x: 0n, y: 1n})),
                                                                                              alignment: _descriptor_6.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(2n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_9.toValue(false),
                                                                                              alignment: _descriptor_9.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(3n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_5.toValue({ f0: 0n, f1: 0n, f2: 0n, f3: 0n }),
                                                                                              alignment: _descriptor_5.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(4n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_0.toValue(0n),
                                                                                              alignment: _descriptor_0.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(5n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_0.toValue(0n),
                                                                                              alignment: _descriptor_0.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    const pinned_0 = Uint8Array.from([60n,
                                      31n,
                                      122n,
                                      61n,
                                      231n,
                                      137n,
                                      119n,
                                      68n,
                                      50n,
                                      12n,
                                      130n,
                                      50n,
                                      73n,
                                      202n,
                                      111n,
                                      134n,
                                      195n,
                                      201n,
                                      69n,
                                      124n,
                                      54n,
                                      232n,
                                      223n,
                                      1n,
                                      250n,
                                      191n,
                                      83n,
                                      74n,
                                      144n,
                                      56n,
                                      10n,
                                      104n],
                                     Number);
    __compactRuntime.assert(this._equal_0(order_0.program, pinned_0),
                            'ORDER_PROGRAM');
    __compactRuntime.assert(!this._equal_1(order_0.assetA, order_0.assetB),
                            'ORDER_ASSETS');
    __compactRuntime.assert(!this._equal_2(order_0.account, order_0.recipient)
                            &&
                            !this._equal_3(order_0.account, order_0.executor)
                            &&
                            !this._equal_4(order_0.recipient, order_0.executor),
                            'ORDER_ROLES');
    __compactRuntime.assert(order_0.input === 100n && order_0.minimum === 200n
                            &&
                            order_0.fee === 0n
                            &&
                            order_0.expiry === 1400n,
                            'O1_TERMS');
    let t_0;
    __compactRuntime.assert((t_0 = order_0.epoch, t_0 <= 18446744073709549615n),
                            'CLOCK_OVERFLOW');
    __compactRuntime.assert(!this._equalPoint_0(owner_0,
                                                this._ecMulGenerator_0(__compactRuntime.convertNumericToJubjubScalar(0n))),
                            'OWNER_IDENTITY');
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(0n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_4.toValue(order_0),
                                                                                              alignment: _descriptor_4.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(1n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_6.toValue(owner_0),
                                                                                              alignment: _descriptor_6.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    state_0.data = new __compactRuntime.ChargedState(context.callContext.currentQueryContext.state.state);
    return {
      currentContractState: state_0,
      currentPrivateState: context.callContext.currentPrivateState,
      currentZswapLocalState: context.callContext.currentZswapLocalState
    }
  }
  _left_0(value_0) {
    return { is_left: true, left: value_0, right: new Uint8Array(32) };
  }
  _right_0(value_0) {
    return { is_left: false, left: { bytes: new Uint8Array(32) }, right: value_0 };
  }
  async _blockTimeLt_0(context, partialProofData, time_0) {
    return _descriptor_9.fromValue(__compactRuntime.queryLedgerState(context,
                                                                     partialProofData,
                                                                     [
                                                                      { dup: { n: 2 } },
                                                                      { idx: { cached: true,
                                                                               pushPath: false,
                                                                               path: [
                                                                                      { tag: 'value',
                                                                                        value: { value: _descriptor_11.toValue(2n),
                                                                                                 alignment: _descriptor_11.alignment() } }] } },
                                                                      { push: { storage: false,
                                                                                value: __compactRuntime.StateValue.newCell({ value: _descriptor_3.toValue(time_0),
                                                                                                                             alignment: _descriptor_3.alignment() }).encode() } },
                                                                      'lt',
                                                                      { popeq: { cached: true,
                                                                                 result: undefined } }]).value);
  }
  async _blockTimeGte_0(context, partialProofData, time_0) {
    return !await this._blockTimeLt_0(context, partialProofData, time_0);
  }
  async _sendUnshielded_0(context,
                          partialProofData,
                          color_0,
                          amount_0,
                          recipient_0)
  {
    const tmp_0 = this._left_0(color_0);
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { swap: { n: 0 } },
                                       { idx: { cached: true,
                                                pushPath: true,
                                                path: [
                                                       { tag: 'value',
                                                         value: { value: _descriptor_11.toValue(7n),
                                                                  alignment: _descriptor_11.alignment() } }] } },
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_27.toValue(tmp_0),
                                                                                              alignment: _descriptor_27.alignment() }).encode() } },
                                       { dup: { n: 1 } },
                                       { dup: { n: 1 } },
                                       'member',
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_0.toValue(amount_0),
                                                                                              alignment: _descriptor_0.alignment() }).encode() } },
                                       { swap: { n: 0 } },
                                       'neg',
                                       { branch: { skip: 4 } },
                                       { dup: { n: 2 } },
                                       { dup: { n: 2 } },
                                       { idx: { cached: true,
                                                pushPath: false,
                                                path: [ { tag: 'stack' }] } },
                                       'add',
                                       { ins: { cached: true, n: 2 } },
                                       { swap: { n: 0 } }]);
    const tmp_1 = this._left_0(color_0);
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { swap: { n: 0 } },
                                       { idx: { cached: true,
                                                pushPath: true,
                                                path: [
                                                       { tag: 'value',
                                                         value: { value: _descriptor_11.toValue(8n),
                                                                  alignment: _descriptor_11.alignment() } }] } },
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell(__compactRuntime.alignedConcat(
                                                                                              { value: _descriptor_27.toValue(tmp_1),
                                                                                                alignment: _descriptor_27.alignment() },
                                                                                              { value: _descriptor_28.toValue(recipient_0),
                                                                                                alignment: _descriptor_28.alignment() }
                                                                                            )).encode() } },
                                       { dup: { n: 1 } },
                                       { dup: { n: 1 } },
                                       'member',
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_0.toValue(amount_0),
                                                                                              alignment: _descriptor_0.alignment() }).encode() } },
                                       { swap: { n: 0 } },
                                       'neg',
                                       { branch: { skip: 4 } },
                                       { dup: { n: 2 } },
                                       { dup: { n: 2 } },
                                       { idx: { cached: true,
                                                pushPath: false,
                                                path: [ { tag: 'stack' }] } },
                                       'add',
                                       { ins: { cached: true, n: 2 } },
                                       { swap: { n: 0 } }]);
    if (recipient_0.is_left
        &&
        this._equal_5(recipient_0.left.bytes,
                      _descriptor_10.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                 partialProofData,
                                                                                 [
                                                                                  { dup: { n: 2 } },
                                                                                  { idx: { cached: true,
                                                                                           pushPath: false,
                                                                                           path: [
                                                                                                  { tag: 'value',
                                                                                                    value: { value: _descriptor_11.toValue(0n),
                                                                                                             alignment: _descriptor_11.alignment() } }] } },
                                                                                  { popeq: { cached: true,
                                                                                             result: undefined } }]).value).bytes))
    {
      const tmp_2 = this._left_0(color_0);
      __compactRuntime.queryLedgerState(context,
                                        partialProofData,
                                        [
                                         { swap: { n: 0 } },
                                         { idx: { cached: true,
                                                  pushPath: true,
                                                  path: [
                                                         { tag: 'value',
                                                           value: { value: _descriptor_11.toValue(6n),
                                                                    alignment: _descriptor_11.alignment() } }] } },
                                         { push: { storage: false,
                                                   value: __compactRuntime.StateValue.newCell({ value: _descriptor_27.toValue(tmp_2),
                                                                                                alignment: _descriptor_27.alignment() }).encode() } },
                                         { dup: { n: 1 } },
                                         { dup: { n: 1 } },
                                         'member',
                                         { push: { storage: false,
                                                   value: __compactRuntime.StateValue.newCell({ value: _descriptor_0.toValue(amount_0),
                                                                                                alignment: _descriptor_0.alignment() }).encode() } },
                                         { swap: { n: 0 } },
                                         'neg',
                                         { branch: { skip: 4 } },
                                         { dup: { n: 2 } },
                                         { dup: { n: 2 } },
                                         { idx: { cached: true,
                                                  pushPath: false,
                                                  path: [ { tag: 'stack' }] } },
                                         'add',
                                         { ins: { cached: true, n: 2 } },
                                         { swap: { n: 0 } }]);
    }
    return [];
  }
  async _receiveUnshielded_0(context, partialProofData, color_0, amount_0) {
    const tmp_0 = this._left_0(color_0);
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { swap: { n: 0 } },
                                       { idx: { cached: true,
                                                pushPath: true,
                                                path: [
                                                       { tag: 'value',
                                                         value: { value: _descriptor_11.toValue(6n),
                                                                  alignment: _descriptor_11.alignment() } }] } },
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_27.toValue(tmp_0),
                                                                                              alignment: _descriptor_27.alignment() }).encode() } },
                                       { dup: { n: 1 } },
                                       { dup: { n: 1 } },
                                       'member',
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_0.toValue(amount_0),
                                                                                              alignment: _descriptor_0.alignment() }).encode() } },
                                       { swap: { n: 0 } },
                                       'neg',
                                       { branch: { skip: 4 } },
                                       { dup: { n: 2 } },
                                       { dup: { n: 2 } },
                                       { idx: { cached: true,
                                                pushPath: false,
                                                path: [ { tag: 'stack' }] } },
                                       'add',
                                       { ins: { cached: true, n: 2 } },
                                       { swap: { n: 0 } }]);
    return [];
  }
  async _unshieldedBalanceLt_0(context, partialProofData, color_0, amount_0) {
    const tmp_0 = this._left_0(color_0);
    return _descriptor_9.fromValue(__compactRuntime.queryLedgerState(context,
                                                                     partialProofData,
                                                                     [
                                                                      { dup: { n: 2 } },
                                                                      { idx: { cached: true,
                                                                               pushPath: false,
                                                                               path: [
                                                                                      { tag: 'value',
                                                                                        value: { value: _descriptor_11.toValue(5n),
                                                                                                 alignment: _descriptor_11.alignment() } }] } },
                                                                      { dup: { n: 0 } },
                                                                      { push: { storage: false,
                                                                                value: __compactRuntime.StateValue.newCell({ value: _descriptor_27.toValue(tmp_0),
                                                                                                                             alignment: _descriptor_27.alignment() }).encode() } },
                                                                      'member',
                                                                      { branch: { skip: 3 } },
                                                                      'pop',
                                                                      { push: { storage: false,
                                                                                value: __compactRuntime.StateValue.newCell({ value: _descriptor_0.toValue(0n),
                                                                                                                             alignment: _descriptor_0.alignment() }).encode() } },
                                                                      { jmp: { skip: 1 } },
                                                                      { idx: { cached: true,
                                                                               pushPath: false,
                                                                               path: [
                                                                                      { tag: 'value',
                                                                                        value: { value: _descriptor_27.toValue(tmp_0),
                                                                                                 alignment: _descriptor_27.alignment() } }] } },
                                                                      { push: { storage: false,
                                                                                value: __compactRuntime.StateValue.newCell({ value: _descriptor_0.toValue(amount_0),
                                                                                                                             alignment: _descriptor_0.alignment() }).encode() } },
                                                                      'lt',
                                                                      { popeq: { cached: true,
                                                                                 result: undefined } }]).value);
  }
  async _unshieldedBalanceGte_0(context, partialProofData, color_0, amount_0) {
    return !await this._unshieldedBalanceLt_0(context,
                                              partialProofData,
                                              color_0,
                                              amount_0);
  }
  _transientHash_0(value_0) {
    const result_0 = __compactRuntime.transientHash(_descriptor_26, value_0);
    return result_0;
  }
  _jubjubPointX_0(pt_0) {
    const result_0 = __compactRuntime.jubjubPointX(pt_0);
    return result_0;
  }
  _jubjubPointY_0(pt_0) {
    const result_0 = __compactRuntime.jubjubPointY(pt_0);
    return result_0;
  }
  _ecAdd_0(a_0, b_0) {
    const result_0 = __compactRuntime.ecAdd(a_0, b_0);
    return result_0;
  }
  _ecMul_0(a_0, b_0) {
    const result_0 = __compactRuntime.ecMul(a_0, b_0);
    return result_0;
  }
  _ecMulGenerator_0(b_0) {
    const result_0 = __compactRuntime.ecMulGenerator(b_0);
    return result_0;
  }
  _checkedAdd_0(a_0, b_0) {
    return ((t1) => {
             if (t1 > 340282366920938463463374607431768211455n) {
               throw new __compactRuntime.CompactError('arithmetic.compact line 14 char 10: cast from Field or Uint value to smaller Uint value failed: ' + t1 + ' is greater than 340282366920938463463374607431768211455');
             }
             return t1;
           })(a_0 + b_0);
  }
  _checkedSub_0(a_0, b_0) {
    __compactRuntime.assert(a_0 >= b_0, 'UINT_UNDERFLOW');
    __compactRuntime.assert(a_0 >= b_0,
                            'result of subtraction would be negative');
    return a_0 - b_0;
  }
  _checkedMul_0(a_0, b_0, h_0) {
    __compactRuntime.assert(a_0 === h_0.aHi * 18446744073709551616n + h_0.aLo,
                            'MUL_A_SPLIT');
    __compactRuntime.assert(b_0 === h_0.bHi * 18446744073709551616n + h_0.bLo,
                            'MUL_B_SPLIT');
    __compactRuntime.assert(h_0.aLo * h_0.bLo
                            ===
                            h_0.carry * 18446744073709551616n + h_0.lo,
                            'MUL_PRODUCT_SPLIT');
    __compactRuntime.assert(h_0.aHi * h_0.bHi === 0n, 'UINT_OVERFLOW_HIGH');
    const middle_0 = h_0.aLo * h_0.bHi + h_0.aHi * h_0.bLo + h_0.carry;
    __compactRuntime.assert(middle_0 < 18446744073709551616n,
                            'UINT_OVERFLOW_MIDDLE');
    return ((t1) => {
             if (t1 > 340282366920938463463374607431768211455n) {
               throw new __compactRuntime.CompactError('arithmetic.compact line 29 char 10: cast from Field or Uint value to smaller Uint value failed: ' + t1 + ' is greater than 340282366920938463463374607431768211455');
             }
             return t1;
           })(middle_0 * 18446744073709551616n + h_0.lo);
  }
  _checkedDiv_0(n_0, d_0, q_0, r_0, h_0) {
    __compactRuntime.assert(d_0 > 0n, 'DIVISION_BY_ZERO');
    __compactRuntime.assert(r_0 < d_0, 'DIVISION_REMAINDER');
    __compactRuntime.assert(this._checkedAdd_0(this._checkedMul_0(d_0, q_0, h_0),
                                               r_0)
                            ===
                            n_0,
                            'DIVISION_EQUATION');
    return q_0;
  }
  _transition0_0(before_0,
                 args_0,
                 observations_0,
                 remaining_0,
                 revision_0,
                 hints_0)
  {
    __compactRuntime.assert(this._checkedAdd_0(revision_0, remaining_0) === 128n,
                            'LIFETIME_INVARIANT');
    __compactRuntime.assert(remaining_0 > 0n, 'LIFETIME_EXHAUSTED');
    let t_0;
    __compactRuntime.assert((t_0 = observations_0.o0, t_0 < 2000n),
                            'HORIZON_EXPIRED');
    const e0_0 = remaining_0;
    const e1_0 = 1n;
    const e2_0 = e0_0 > e1_0;
    __compactRuntime.assert(e2_0, 'reserve cancellation allowance');
    const e3_0 = before_0.f3;
    const e4_0 = 0n;
    const e5_0 = e3_0 === e4_0;
    __compactRuntime.assert(e5_0, 'order closed');
    const e6_0 = args_0.a0;
    const e7_0 = 2n;
    const e8_0 = e6_0 === e7_0;
    __compactRuntime.assert(e8_0, 'only Alice authorizes A');
    const e9_0 = args_0.a1;
    const e10_0 = 3n;
    const e11_0 = e9_0 === e10_0;
    __compactRuntime.assert(e11_0, 'recipient must be Bob');
    const e12_0 = before_0.f0;
    const e13_0 = before_0.f1;
    const e14_0 = this._checkedAdd_0(e12_0, e13_0);
    const e15_0 = before_0.f2;
    const e16_0 = this._checkedAdd_0(e14_0, e15_0);
    const e17_0 = 100n;
    const e18_0 = e16_0 === e17_0;
    __compactRuntime.assert(e18_0, 'A accounting');
    const e19_0 = observations_0.o0;
    const e20_0 = 1400n;
    const e21_0 = e19_0 < e20_0;
    __compactRuntime.assert(e21_0, 'order expired');
    const e22_0 = args_0.a2;
    const e23_0 = 100n;
    const e24_0 = e22_0 === e23_0;
    __compactRuntime.assert(e24_0, 'exact input is 100 A');
    const e25_0 = args_0.a3;
    const e26_0 = 200n;
    const e27_0 = e25_0 >= e26_0;
    __compactRuntime.assert(e27_0, 'output is at least 200 B');
    const e28_0 = before_0.f0;
    const e29_0 = args_0.a2;
    const e30_0 = this._checkedSub_0(e28_0, e29_0);
    const e31_0 = before_0.f1;
    const e32_0 = args_0.a2;
    const e33_0 = this._checkedAdd_0(e31_0, e32_0);
    const e34_0 = 1n;
    const e35_0 = 0n;
    const e36_0 = 4n;
    const e37_0 = 5n;
    const e38_0 = args_0.a2;
    const e39_0 = 1n;
    const e40_0 = 5n;
    const e41_0 = args_0.a1;
    const e42_0 = args_0.a3;
    return { after: { f0: e30_0, f1: e33_0, f2: before_0.f2, f3: e34_0 },
             remaining: this._checkedSub_0(remaining_0, 1n),
             revision: this._checkedAdd_0(revision_0, 1n),
             effect0: { v0: e35_0, v1: e36_0, v2: e37_0, v3: e38_0 },
             effect1: { v0: e39_0, v1: e40_0, v2: e41_0, v3: e42_0 } };
  }
  _transition1_0(before_0,
                 args_0,
                 observations_0,
                 remaining_0,
                 revision_0,
                 hints_0)
  {
    __compactRuntime.assert(this._checkedAdd_0(revision_0, remaining_0) === 128n,
                            'LIFETIME_INVARIANT');
    __compactRuntime.assert(remaining_0 > 0n, 'LIFETIME_EXHAUSTED');
    let t_0;
    __compactRuntime.assert((t_0 = observations_0.o0, t_0 < 2000n),
                            'HORIZON_EXPIRED');
    const e0_0 = before_0.f3;
    const e1_0 = 0n;
    const e2_0 = e0_0 === e1_0;
    __compactRuntime.assert(e2_0, 'order closed');
    const e3_0 = args_0.a0;
    const e4_0 = 2n;
    const e5_0 = e3_0 === e4_0;
    __compactRuntime.assert(e5_0, 'only Alice cancels');
    const e6_0 = before_0.f0;
    const e7_0 = before_0.f1;
    const e8_0 = this._checkedAdd_0(e6_0, e7_0);
    const e9_0 = before_0.f2;
    const e10_0 = this._checkedAdd_0(e8_0, e9_0);
    const e11_0 = 100n;
    const e12_0 = e10_0 === e11_0;
    __compactRuntime.assert(e12_0, 'A accounting');
    const e13_0 = 0n;
    const e14_0 = 4n;
    const e15_0 = 2n;
    const e16_0 = before_0.f0;
    const e17_0 = before_0.f2;
    const e18_0 = before_0.f0;
    const e19_0 = this._checkedAdd_0(e17_0, e18_0);
    const e20_0 = 0n;
    const e21_0 = 1n;
    return { after: { f0: e20_0, f1: before_0.f1, f2: e19_0, f3: e21_0 },
             remaining: this._checkedSub_0(remaining_0, 1n),
             revision: this._checkedAdd_0(revision_0, 1n),
             effect0: { v0: e13_0, v1: e14_0, v2: e15_0, v3: e16_0 } };
  }
  _equalPoint_0(a_0, b_0) {
    return this._jubjubPointX_0(a_0) === this._jubjubPointX_0(b_0)
           &&
           this._jubjubPointY_0(a_0) === this._jubjubPointY_0(b_0);
  }
  _orderChallenge_0(order_0,
                    instance_0,
                    owner_0,
                    action_0,
                    nonce_0,
                    announcement_0)
  {
    const h_0 = this._transientHash_0({ domain:
                                          new Uint8Array([109, 111, 114, 105, 97, 114, 116, 121, 58, 111, 114, 100, 101, 114, 58, 115, 99, 104, 110, 111, 114, 114, 58, 118, 49, 0, 0, 0, 0, 0, 0, 0]),
                                        terms: order_0,
                                        instance: instance_0,
                                        ownerX: this._jubjubPointX_0(owner_0),
                                        ownerY: this._jubjubPointY_0(owner_0),
                                        action: action_0,
                                        revision: nonce_0,
                                        announcementX:
                                          this._jubjubPointX_0(announcement_0),
                                        announcementY:
                                          this._jubjubPointY_0(announcement_0) });
    return __compactRuntime.convertBytesToUint(452312848583266388373324160190187140051835877600158453279131187530910662655n,
                                               31,
                                               ((e, i) => e.slice(i, i+31))(__compactRuntime.convertBigintToBytes(32,
                                                                                                                  h_0,
                                                                                                                  'acceptance.compact line 44 char 21'),
                                                                            Number(0n)),
                                               'Uint<0..452312848583266388373324160190187140051835877600158453279131187530910662656>',
                                               'acceptance.compact line 44 char 11');
  }
  async _authorize_0(context, partialProofData, action_0, expected_0, sig_0) {
    __compactRuntime.assert(_descriptor_0.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                      partialProofData,
                                                                                      [
                                                                                       { dup: { n: 0 } },
                                                                                       { idx: { cached: false,
                                                                                                pushPath: false,
                                                                                                path: [
                                                                                                       { tag: 'value',
                                                                                                         value: { value: _descriptor_11.toValue(5n),
                                                                                                                  alignment: _descriptor_11.alignment() } }] } },
                                                                                       { popeq: { cached: false,
                                                                                                  result: undefined } }]).value)
                            ===
                            expected_0,
                            'ORDER_REVISION');
    __compactRuntime.assert(_descriptor_9.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                      partialProofData,
                                                                                      [
                                                                                       { dup: { n: 0 } },
                                                                                       { idx: { cached: false,
                                                                                                pushPath: false,
                                                                                                path: [
                                                                                                       { tag: 'value',
                                                                                                         value: { value: _descriptor_11.toValue(2n),
                                                                                                                  alignment: _descriptor_11.alignment() } }] } },
                                                                                       { popeq: { cached: false,
                                                                                                  result: undefined } }]).value)
                            &&
                            _descriptor_5.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                      partialProofData,
                                                                                      [
                                                                                       { dup: { n: 0 } },
                                                                                       { idx: { cached: false,
                                                                                                pushPath: false,
                                                                                                path: [
                                                                                                       { tag: 'value',
                                                                                                         value: { value: _descriptor_11.toValue(3n),
                                                                                                                  alignment: _descriptor_11.alignment() } }] } },
                                                                                       { popeq: { cached: false,
                                                                                                  result: undefined } }]).value).f3
                            ===
                            0n,
                            'ORDER_CLOSED');
    __compactRuntime.assert(!this._equalPoint_0(sig_0.announcement,
                                                this._ecMulGenerator_0(__compactRuntime.convertNumericToJubjubScalar(0n))),
                            'ORDER_SIGNATURE_IDENTITY');
    const c_0 = this._orderChallenge_0(_descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                 partialProofData,
                                                                                                 [
                                                                                                  { dup: { n: 0 } },
                                                                                                  { idx: { cached: false,
                                                                                                           pushPath: false,
                                                                                                           path: [
                                                                                                                  { tag: 'value',
                                                                                                                    value: { value: _descriptor_11.toValue(0n),
                                                                                                                             alignment: _descriptor_11.alignment() } }] } },
                                                                                                  { popeq: { cached: false,
                                                                                                             result: undefined } }]).value),
                                       _descriptor_10.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                  partialProofData,
                                                                                                  [
                                                                                                   { dup: { n: 2 } },
                                                                                                   { idx: { cached: true,
                                                                                                            pushPath: false,
                                                                                                            path: [
                                                                                                                   { tag: 'value',
                                                                                                                     value: { value: _descriptor_11.toValue(0n),
                                                                                                                              alignment: _descriptor_11.alignment() } }] } },
                                                                                                   { popeq: { cached: true,
                                                                                                              result: undefined } }]).value),
                                       _descriptor_6.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                 partialProofData,
                                                                                                 [
                                                                                                  { dup: { n: 0 } },
                                                                                                  { idx: { cached: false,
                                                                                                           pushPath: false,
                                                                                                           path: [
                                                                                                                  { tag: 'value',
                                                                                                                    value: { value: _descriptor_11.toValue(1n),
                                                                                                                             alignment: _descriptor_11.alignment() } }] } },
                                                                                                  { popeq: { cached: false,
                                                                                                             result: undefined } }]).value),
                                       action_0,
                                       expected_0,
                                       sig_0.announcement);
    __compactRuntime.assert(this._equalPoint_0(this._ecMulGenerator_0(__compactRuntime.convertNumericToJubjubScalar(sig_0.response)),
                                               this._ecAdd_0(sig_0.announcement,
                                                             this._ecMul_0(_descriptor_6.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                                                     partialProofData,
                                                                                                                                     [
                                                                                                                                      { dup: { n: 0 } },
                                                                                                                                      { idx: { cached: false,
                                                                                                                                               pushPath: false,
                                                                                                                                               path: [
                                                                                                                                                      { tag: 'value',
                                                                                                                                                        value: { value: _descriptor_11.toValue(1n),
                                                                                                                                                                 alignment: _descriptor_11.alignment() } }] } },
                                                                                                                                      { popeq: { cached: false,
                                                                                                                                                 result: undefined } }]).value),
                                                                           __compactRuntime.convertNumericToJubjubScalar(c_0)))),
                            'ORDER_SIGNATURE');
    return [];
  }
  async _fund_0(context, partialProofData) {
    __compactRuntime.assert(!_descriptor_9.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                       partialProofData,
                                                                                       [
                                                                                        { dup: { n: 0 } },
                                                                                        { idx: { cached: false,
                                                                                                 pushPath: false,
                                                                                                 path: [
                                                                                                        { tag: 'value',
                                                                                                          value: { value: _descriptor_11.toValue(2n),
                                                                                                                   alignment: _descriptor_11.alignment() } }] } },
                                                                                        { popeq: { cached: false,
                                                                                                   result: undefined } }]).value),
                            'ALREADY_FUNDED');
    __compactRuntime.assert(await this._blockTimeLt_0(context,
                                                      partialProofData,
                                                      ((t1) => {
                                                        if (t1 > 18446744073709551615n) {
                                                          throw new __compactRuntime.CompactError('acceptance.compact line 57 char 22: cast from Field or Uint value to smaller Uint value failed: ' + t1 + ' is greater than 18446744073709551615');
                                                        }
                                                        return t1;
                                                      })(_descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                                   partialProofData,
                                                                                                                   [
                                                                                                                    { dup: { n: 0 } },
                                                                                                                    { idx: { cached: false,
                                                                                                                             pushPath: false,
                                                                                                                             path: [
                                                                                                                                    { tag: 'value',
                                                                                                                                      value: { value: _descriptor_11.toValue(0n),
                                                                                                                                               alignment: _descriptor_11.alignment() } }] } },
                                                                                                                    { popeq: { cached: false,
                                                                                                                               result: undefined } }]).value).epoch
                                                         +
                                                         _descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                                   partialProofData,
                                                                                                                   [
                                                                                                                    { dup: { n: 0 } },
                                                                                                                    { idx: { cached: false,
                                                                                                                             pushPath: false,
                                                                                                                             path: [
                                                                                                                                    { tag: 'value',
                                                                                                                                      value: { value: _descriptor_11.toValue(0n),
                                                                                                                                               alignment: _descriptor_11.alignment() } }] } },
                                                                                                                    { popeq: { cached: false,
                                                                                                                               result: undefined } }]).value).expiry)),
                            'ORDER_EXPIRED');
    await this._receiveUnshielded_0(context,
                                    partialProofData,
                                    _descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                              partialProofData,
                                                                                              [
                                                                                               { dup: { n: 0 } },
                                                                                               { idx: { cached: false,
                                                                                                        pushPath: false,
                                                                                                        path: [
                                                                                                               { tag: 'value',
                                                                                                                 value: { value: _descriptor_11.toValue(0n),
                                                                                                                          alignment: _descriptor_11.alignment() } }] } },
                                                                                               { popeq: { cached: false,
                                                                                                          result: undefined } }]).value).assetA,
                                    _descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                              partialProofData,
                                                                                              [
                                                                                               { dup: { n: 0 } },
                                                                                               { idx: { cached: false,
                                                                                                        pushPath: false,
                                                                                                        path: [
                                                                                                               { tag: 'value',
                                                                                                                 value: { value: _descriptor_11.toValue(0n),
                                                                                                                          alignment: _descriptor_11.alignment() } }] } },
                                                                                               { popeq: { cached: false,
                                                                                                          result: undefined } }]).value).input);
    const tmp_0 = { f0: 100n, f1: 0n, f2: 0n, f3: 0n };
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(3n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_5.toValue(tmp_0),
                                                                                              alignment: _descriptor_5.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    const tmp_1 = 128n;
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(4n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_0.toValue(tmp_1),
                                                                                              alignment: _descriptor_0.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    const tmp_2 = 0n;
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(5n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_0.toValue(tmp_2),
                                                                                              alignment: _descriptor_0.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(2n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_9.toValue(true),
                                                                                              alignment: _descriptor_9.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    return [];
  }
  async _fill_0(context,
                partialProofData,
                expected_0,
                amountA_0,
                amountB_0,
                applicationFee_0,
                now_0,
                sig_0)
  {
    await this._authorize_0(context, partialProofData, 0n, expected_0, sig_0);
    __compactRuntime.assert(applicationFee_0
                            ===
                            _descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                      partialProofData,
                                                                                      [
                                                                                       { dup: { n: 0 } },
                                                                                       { idx: { cached: false,
                                                                                                pushPath: false,
                                                                                                path: [
                                                                                                       { tag: 'value',
                                                                                                         value: { value: _descriptor_11.toValue(0n),
                                                                                                                  alignment: _descriptor_11.alignment() } }] } },
                                                                                       { popeq: { cached: false,
                                                                                                  result: undefined } }]).value).fee,
                            'APPLICATION_FEE');
    __compactRuntime.assert(await this._blockTimeLt_0(context,
                                                      partialProofData,
                                                      ((t1) => {
                                                        if (t1 > 18446744073709551615n) {
                                                          throw new __compactRuntime.CompactError('acceptance.compact line 67 char 22: cast from Field or Uint value to smaller Uint value failed: ' + t1 + ' is greater than 18446744073709551615');
                                                        }
                                                        return t1;
                                                      })(_descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                                   partialProofData,
                                                                                                                   [
                                                                                                                    { dup: { n: 0 } },
                                                                                                                    { idx: { cached: false,
                                                                                                                             pushPath: false,
                                                                                                                             path: [
                                                                                                                                    { tag: 'value',
                                                                                                                                      value: { value: _descriptor_11.toValue(0n),
                                                                                                                                               alignment: _descriptor_11.alignment() } }] } },
                                                                                                                    { popeq: { cached: false,
                                                                                                                               result: undefined } }]).value).epoch
                                                         +
                                                         _descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                                   partialProofData,
                                                                                                                   [
                                                                                                                    { dup: { n: 0 } },
                                                                                                                    { idx: { cached: false,
                                                                                                                             pushPath: false,
                                                                                                                             path: [
                                                                                                                                    { tag: 'value',
                                                                                                                                      value: { value: _descriptor_11.toValue(0n),
                                                                                                                                               alignment: _descriptor_11.alignment() } }] } },
                                                                                                                    { popeq: { cached: false,
                                                                                                                               result: undefined } }]).value).expiry)),
                            'ORDER_EXPIRED');
    __compactRuntime.assert(now_0
                            <
                            _descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                      partialProofData,
                                                                                      [
                                                                                       { dup: { n: 0 } },
                                                                                       { idx: { cached: false,
                                                                                                pushPath: false,
                                                                                                path: [
                                                                                                       { tag: 'value',
                                                                                                         value: { value: _descriptor_11.toValue(0n),
                                                                                                                  alignment: _descriptor_11.alignment() } }] } },
                                                                                       { popeq: { cached: false,
                                                                                                  result: undefined } }]).value).expiry,
                            'ORDER_EXPIRED');
    __compactRuntime.assert(await this._blockTimeGte_0(context,
                                                       partialProofData,
                                                       ((t1) => {
                                                         if (t1 > 18446744073709551615n) {
                                                           throw new __compactRuntime.CompactError('acceptance.compact line 69 char 23: cast from Field or Uint value to smaller Uint value failed: ' + t1 + ' is greater than 18446744073709551615');
                                                         }
                                                         return t1;
                                                       })(_descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                                    partialProofData,
                                                                                                                    [
                                                                                                                     { dup: { n: 0 } },
                                                                                                                     { idx: { cached: false,
                                                                                                                              pushPath: false,
                                                                                                                              path: [
                                                                                                                                     { tag: 'value',
                                                                                                                                       value: { value: _descriptor_11.toValue(0n),
                                                                                                                                                alignment: _descriptor_11.alignment() } }] } },
                                                                                                                     { popeq: { cached: false,
                                                                                                                                result: undefined } }]).value).epoch
                                                          +
                                                          now_0)),
                            'ORDER_FUTURE');
    __compactRuntime.assert(await this._unshieldedBalanceGte_0(context,
                                                               partialProofData,
                                                               _descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                                         partialProofData,
                                                                                                                         [
                                                                                                                          { dup: { n: 0 } },
                                                                                                                          { idx: { cached: false,
                                                                                                                                   pushPath: false,
                                                                                                                                   path: [
                                                                                                                                          { tag: 'value',
                                                                                                                                            value: { value: _descriptor_11.toValue(0n),
                                                                                                                                                     alignment: _descriptor_11.alignment() } }] } },
                                                                                                                          { popeq: { cached: false,
                                                                                                                                     result: undefined } }]).value).assetA,
                                                               _descriptor_5.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                                         partialProofData,
                                                                                                                         [
                                                                                                                          { dup: { n: 0 } },
                                                                                                                          { idx: { cached: false,
                                                                                                                                   pushPath: false,
                                                                                                                                   path: [
                                                                                                                                          { tag: 'value',
                                                                                                                                            value: { value: _descriptor_11.toValue(3n),
                                                                                                                                                     alignment: _descriptor_11.alignment() } }] } },
                                                                                                                          { popeq: { cached: false,
                                                                                                                                     result: undefined } }]).value).f0),
                            'CUSTODY_A');
    const result_0 = this._transition0_0(_descriptor_5.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                   partialProofData,
                                                                                                   [
                                                                                                    { dup: { n: 0 } },
                                                                                                    { idx: { cached: false,
                                                                                                             pushPath: false,
                                                                                                             path: [
                                                                                                                    { tag: 'value',
                                                                                                                      value: { value: _descriptor_11.toValue(3n),
                                                                                                                               alignment: _descriptor_11.alignment() } }] } },
                                                                                                    { popeq: { cached: false,
                                                                                                               result: undefined } }]).value),
                                         { a0: 2n,
                                           a1: 3n,
                                           a2: amountA_0,
                                           a3: amountB_0 },
                                         { o0: now_0 },
                                         _descriptor_0.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                   partialProofData,
                                                                                                   [
                                                                                                    { dup: { n: 0 } },
                                                                                                    { idx: { cached: false,
                                                                                                             pushPath: false,
                                                                                                             path: [
                                                                                                                    { tag: 'value',
                                                                                                                      value: { value: _descriptor_11.toValue(4n),
                                                                                                                               alignment: _descriptor_11.alignment() } }] } },
                                                                                                    { popeq: { cached: false,
                                                                                                               result: undefined } }]).value),
                                         _descriptor_0.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                   partialProofData,
                                                                                                   [
                                                                                                    { dup: { n: 0 } },
                                                                                                    { idx: { cached: false,
                                                                                                             pushPath: false,
                                                                                                             path: [
                                                                                                                    { tag: 'value',
                                                                                                                      value: { value: _descriptor_11.toValue(5n),
                                                                                                                               alignment: _descriptor_11.alignment() } }] } },
                                                                                                    { popeq: { cached: false,
                                                                                                               result: undefined } }]).value),
                                         { unused: 0n });
    __compactRuntime.assert(result_0.effect0.v0 === 0n
                            &&
                            result_0.effect0.v1 === 4n
                            &&
                            result_0.effect0.v2 === 5n
                            &&
                            result_0.effect0.v3
                            ===
                            _descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                      partialProofData,
                                                                                      [
                                                                                       { dup: { n: 0 } },
                                                                                       { idx: { cached: false,
                                                                                                pushPath: false,
                                                                                                path: [
                                                                                                       { tag: 'value',
                                                                                                         value: { value: _descriptor_11.toValue(0n),
                                                                                                                  alignment: _descriptor_11.alignment() } }] } },
                                                                                       { popeq: { cached: false,
                                                                                                  result: undefined } }]).value).input,
                            'A_EFFECT');
    let t_0;
    __compactRuntime.assert(result_0.effect1.v0 === 1n
                            &&
                            result_0.effect1.v1 === 5n
                            &&
                            result_0.effect1.v2 === 3n
                            &&
                            (t_0 = result_0.effect1.v3,
                             t_0
                             >=
                             _descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                       partialProofData,
                                                                                       [
                                                                                        { dup: { n: 0 } },
                                                                                        { idx: { cached: false,
                                                                                                 pushPath: false,
                                                                                                 path: [
                                                                                                        { tag: 'value',
                                                                                                          value: { value: _descriptor_11.toValue(0n),
                                                                                                                   alignment: _descriptor_11.alignment() } }] } },
                                                                                        { popeq: { cached: false,
                                                                                                   result: undefined } }]).value).minimum),
                            'B_EFFECT');
    await this._receiveUnshielded_0(context,
                                    partialProofData,
                                    _descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                              partialProofData,
                                                                                              [
                                                                                               { dup: { n: 0 } },
                                                                                               { idx: { cached: false,
                                                                                                        pushPath: false,
                                                                                                        path: [
                                                                                                               { tag: 'value',
                                                                                                                 value: { value: _descriptor_11.toValue(0n),
                                                                                                                          alignment: _descriptor_11.alignment() } }] } },
                                                                                               { popeq: { cached: false,
                                                                                                          result: undefined } }]).value).assetB,
                                    result_0.effect1.v3);
    await this._sendUnshielded_0(context,
                                 partialProofData,
                                 _descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                           partialProofData,
                                                                                           [
                                                                                            { dup: { n: 0 } },
                                                                                            { idx: { cached: false,
                                                                                                     pushPath: false,
                                                                                                     path: [
                                                                                                            { tag: 'value',
                                                                                                              value: { value: _descriptor_11.toValue(0n),
                                                                                                                       alignment: _descriptor_11.alignment() } }] } },
                                                                                            { popeq: { cached: false,
                                                                                                       result: undefined } }]).value).assetB,
                                 result_0.effect1.v3,
                                 this._right_0(_descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                         partialProofData,
                                                                                                         [
                                                                                                          { dup: { n: 0 } },
                                                                                                          { idx: { cached: false,
                                                                                                                   pushPath: false,
                                                                                                                   path: [
                                                                                                                          { tag: 'value',
                                                                                                                            value: { value: _descriptor_11.toValue(0n),
                                                                                                                                     alignment: _descriptor_11.alignment() } }] } },
                                                                                                          { popeq: { cached: false,
                                                                                                                     result: undefined } }]).value).recipient));
    await this._sendUnshielded_0(context,
                                 partialProofData,
                                 _descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                           partialProofData,
                                                                                           [
                                                                                            { dup: { n: 0 } },
                                                                                            { idx: { cached: false,
                                                                                                     pushPath: false,
                                                                                                     path: [
                                                                                                            { tag: 'value',
                                                                                                              value: { value: _descriptor_11.toValue(0n),
                                                                                                                       alignment: _descriptor_11.alignment() } }] } },
                                                                                            { popeq: { cached: false,
                                                                                                       result: undefined } }]).value).assetA,
                                 result_0.effect0.v3,
                                 this._right_0(_descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                         partialProofData,
                                                                                                         [
                                                                                                          { dup: { n: 0 } },
                                                                                                          { idx: { cached: false,
                                                                                                                   pushPath: false,
                                                                                                                   path: [
                                                                                                                          { tag: 'value',
                                                                                                                            value: { value: _descriptor_11.toValue(0n),
                                                                                                                                     alignment: _descriptor_11.alignment() } }] } },
                                                                                                          { popeq: { cached: false,
                                                                                                                     result: undefined } }]).value).executor));
    const tmp_0 = result_0.after;
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(3n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_5.toValue(tmp_0),
                                                                                              alignment: _descriptor_5.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    const tmp_1 = result_0.remaining;
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(4n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_0.toValue(tmp_1),
                                                                                              alignment: _descriptor_0.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    const tmp_2 = result_0.revision;
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(5n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_0.toValue(tmp_2),
                                                                                              alignment: _descriptor_0.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    return [];
  }
  async _cancel_0(context, partialProofData, expected_0, sig_0) {
    await this._authorize_0(context, partialProofData, 1n, expected_0, sig_0);
    const result_0 = this._transition1_0(_descriptor_5.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                   partialProofData,
                                                                                                   [
                                                                                                    { dup: { n: 0 } },
                                                                                                    { idx: { cached: false,
                                                                                                             pushPath: false,
                                                                                                             path: [
                                                                                                                    { tag: 'value',
                                                                                                                      value: { value: _descriptor_11.toValue(3n),
                                                                                                                               alignment: _descriptor_11.alignment() } }] } },
                                                                                                    { popeq: { cached: false,
                                                                                                               result: undefined } }]).value),
                                         { a0: 2n },
                                         { o0: 0n },
                                         _descriptor_0.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                   partialProofData,
                                                                                                   [
                                                                                                    { dup: { n: 0 } },
                                                                                                    { idx: { cached: false,
                                                                                                             pushPath: false,
                                                                                                             path: [
                                                                                                                    { tag: 'value',
                                                                                                                      value: { value: _descriptor_11.toValue(4n),
                                                                                                                               alignment: _descriptor_11.alignment() } }] } },
                                                                                                    { popeq: { cached: false,
                                                                                                               result: undefined } }]).value),
                                         _descriptor_0.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                   partialProofData,
                                                                                                   [
                                                                                                    { dup: { n: 0 } },
                                                                                                    { idx: { cached: false,
                                                                                                             pushPath: false,
                                                                                                             path: [
                                                                                                                    { tag: 'value',
                                                                                                                      value: { value: _descriptor_11.toValue(5n),
                                                                                                                               alignment: _descriptor_11.alignment() } }] } },
                                                                                                    { popeq: { cached: false,
                                                                                                               result: undefined } }]).value),
                                         { unused: 0n });
    __compactRuntime.assert(result_0.effect0.v0 === 0n
                            &&
                            result_0.effect0.v1 === 4n
                            &&
                            result_0.effect0.v2 === 2n
                            &&
                            result_0.effect0.v3
                            ===
                            _descriptor_5.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                      partialProofData,
                                                                                      [
                                                                                       { dup: { n: 0 } },
                                                                                       { idx: { cached: false,
                                                                                                pushPath: false,
                                                                                                path: [
                                                                                                       { tag: 'value',
                                                                                                         value: { value: _descriptor_11.toValue(3n),
                                                                                                                  alignment: _descriptor_11.alignment() } }] } },
                                                                                       { popeq: { cached: false,
                                                                                                  result: undefined } }]).value).f0,
                            'REFUND_EFFECT');
    __compactRuntime.assert(await this._unshieldedBalanceGte_0(context,
                                                               partialProofData,
                                                               _descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                                         partialProofData,
                                                                                                                         [
                                                                                                                          { dup: { n: 0 } },
                                                                                                                          { idx: { cached: false,
                                                                                                                                   pushPath: false,
                                                                                                                                   path: [
                                                                                                                                          { tag: 'value',
                                                                                                                                            value: { value: _descriptor_11.toValue(0n),
                                                                                                                                                     alignment: _descriptor_11.alignment() } }] } },
                                                                                                                          { popeq: { cached: false,
                                                                                                                                     result: undefined } }]).value).assetA,
                                                               result_0.effect0.v3),
                            'CUSTODY_A');
    await this._sendUnshielded_0(context,
                                 partialProofData,
                                 _descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                           partialProofData,
                                                                                           [
                                                                                            { dup: { n: 0 } },
                                                                                            { idx: { cached: false,
                                                                                                     pushPath: false,
                                                                                                     path: [
                                                                                                            { tag: 'value',
                                                                                                              value: { value: _descriptor_11.toValue(0n),
                                                                                                                       alignment: _descriptor_11.alignment() } }] } },
                                                                                            { popeq: { cached: false,
                                                                                                       result: undefined } }]).value).assetA,
                                 result_0.effect0.v3,
                                 this._right_0(_descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                                                         partialProofData,
                                                                                                         [
                                                                                                          { dup: { n: 0 } },
                                                                                                          { idx: { cached: false,
                                                                                                                   pushPath: false,
                                                                                                                   path: [
                                                                                                                          { tag: 'value',
                                                                                                                            value: { value: _descriptor_11.toValue(0n),
                                                                                                                                     alignment: _descriptor_11.alignment() } }] } },
                                                                                                          { popeq: { cached: false,
                                                                                                                     result: undefined } }]).value).account));
    const tmp_0 = result_0.after;
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(3n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_5.toValue(tmp_0),
                                                                                              alignment: _descriptor_5.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    const tmp_1 = result_0.remaining;
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(4n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_0.toValue(tmp_1),
                                                                                              alignment: _descriptor_0.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    const tmp_2 = result_0.revision;
    __compactRuntime.queryLedgerState(context,
                                      partialProofData,
                                      [
                                       { push: { storage: false,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_11.toValue(5n),
                                                                                              alignment: _descriptor_11.alignment() }).encode() } },
                                       { push: { storage: true,
                                                 value: __compactRuntime.StateValue.newCell({ value: _descriptor_0.toValue(tmp_2),
                                                                                              alignment: _descriptor_0.alignment() }).encode() } },
                                       { ins: { cached: false, n: 1 } }]);
    return [];
  }
  _equal_0(x0, y0) {
    if (!x0.every((x, i) => y0[i] === x)) { return false; }
    return true;
  }
  _equal_1(x0, y0) {
    if (!x0.every((x, i) => y0[i] === x)) { return false; }
    return true;
  }
  _equal_2(x0, y0) {
    {
      let x1 = x0.bytes;
      let y1 = y0.bytes;
      if (!x1.every((x, i) => y1[i] === x)) { return false; }
    }
    return true;
  }
  _equal_3(x0, y0) {
    {
      let x1 = x0.bytes;
      let y1 = y0.bytes;
      if (!x1.every((x, i) => y1[i] === x)) { return false; }
    }
    return true;
  }
  _equal_4(x0, y0) {
    {
      let x1 = x0.bytes;
      let y1 = y0.bytes;
      if (!x1.every((x, i) => y1[i] === x)) { return false; }
    }
    return true;
  }
  _equal_5(x0, y0) {
    if (!x0.every((x, i) => y0[i] === x)) { return false; }
    return true;
  }
}
export function ledger(stateOrChargedState) {
  const state = stateOrChargedState instanceof __compactRuntime.StateValue ? stateOrChargedState : stateOrChargedState.state;
  const chargedState = stateOrChargedState instanceof __compactRuntime.StateValue ? new __compactRuntime.ChargedState(stateOrChargedState) : stateOrChargedState;
  const context = {
    callContext: { currentQueryContext: new __compactRuntime.QueryContext(chargedState, __compactRuntime.dummyContractAddress()), currentGasCost: __compactRuntime.emptyRunningCost() },
    costModel: __compactRuntime.CostModel.initialCostModel()
  };
  const partialProofData = {
    input: { value: [], alignment: [] },
    output: undefined,
    publicTranscript: [],
    privateTranscriptOutputs: []
  };
  return {
    get terms() {
      return _descriptor_4.fromValue(__compactRuntime.queryLedgerState(context,
                                                                       partialProofData,
                                                                       [
                                                                        { dup: { n: 0 } },
                                                                        { idx: { cached: false,
                                                                                 pushPath: false,
                                                                                 path: [
                                                                                        { tag: 'value',
                                                                                          value: { value: _descriptor_11.toValue(0n),
                                                                                                   alignment: _descriptor_11.alignment() } }] } },
                                                                        { popeq: { cached: false,
                                                                                   result: undefined } }]).value);
    },
    get ownerKey() {
      return _descriptor_6.fromValue(__compactRuntime.queryLedgerState(context,
                                                                       partialProofData,
                                                                       [
                                                                        { dup: { n: 0 } },
                                                                        { idx: { cached: false,
                                                                                 pushPath: false,
                                                                                 path: [
                                                                                        { tag: 'value',
                                                                                          value: { value: _descriptor_11.toValue(1n),
                                                                                                   alignment: _descriptor_11.alignment() } }] } },
                                                                        { popeq: { cached: false,
                                                                                   result: undefined } }]).value);
    },
    get funded() {
      return _descriptor_9.fromValue(__compactRuntime.queryLedgerState(context,
                                                                       partialProofData,
                                                                       [
                                                                        { dup: { n: 0 } },
                                                                        { idx: { cached: false,
                                                                                 pushPath: false,
                                                                                 path: [
                                                                                        { tag: 'value',
                                                                                          value: { value: _descriptor_11.toValue(2n),
                                                                                                   alignment: _descriptor_11.alignment() } }] } },
                                                                        { popeq: { cached: false,
                                                                                   result: undefined } }]).value);
    },
    get kernelState() {
      return _descriptor_5.fromValue(__compactRuntime.queryLedgerState(context,
                                                                       partialProofData,
                                                                       [
                                                                        { dup: { n: 0 } },
                                                                        { idx: { cached: false,
                                                                                 pushPath: false,
                                                                                 path: [
                                                                                        { tag: 'value',
                                                                                          value: { value: _descriptor_11.toValue(3n),
                                                                                                   alignment: _descriptor_11.alignment() } }] } },
                                                                        { popeq: { cached: false,
                                                                                   result: undefined } }]).value);
    },
    get remaining() {
      return _descriptor_0.fromValue(__compactRuntime.queryLedgerState(context,
                                                                       partialProofData,
                                                                       [
                                                                        { dup: { n: 0 } },
                                                                        { idx: { cached: false,
                                                                                 pushPath: false,
                                                                                 path: [
                                                                                        { tag: 'value',
                                                                                          value: { value: _descriptor_11.toValue(4n),
                                                                                                   alignment: _descriptor_11.alignment() } }] } },
                                                                        { popeq: { cached: false,
                                                                                   result: undefined } }]).value);
    },
    get revision() {
      return _descriptor_0.fromValue(__compactRuntime.queryLedgerState(context,
                                                                       partialProofData,
                                                                       [
                                                                        { dup: { n: 0 } },
                                                                        { idx: { cached: false,
                                                                                 pushPath: false,
                                                                                 path: [
                                                                                        { tag: 'value',
                                                                                          value: { value: _descriptor_11.toValue(5n),
                                                                                                   alignment: _descriptor_11.alignment() } }] } },
                                                                        { popeq: { cached: false,
                                                                                   result: undefined } }]).value);
    }
  };
}
const _emptyContext = {
  callContext: { currentQueryContext: new __compactRuntime.QueryContext(new __compactRuntime.ContractState().data, __compactRuntime.dummyContractAddress()), currentGasCost: __compactRuntime.emptyRunningCost() }
};
const _dummyContract = new Contract({ });
export const pureCircuits = {
  checkedAdd: (...args_0) => {
    if (args_0.length !== 2) {
      throw new __compactRuntime.CompactError(`checkedAdd: expected 2 arguments (as invoked from Typescript), received ${args_0.length}`);
    }
    const a_0 = args_0[0];
    const b_0 = args_0[1];
    if (!(typeof(a_0) === 'bigint' && a_0 >= 0n && a_0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('checkedAdd',
                                 'argument 1',
                                 'arithmetic.compact line 13 char 1',
                                 'Uint<0..340282366920938463463374607431768211456>',
                                 a_0)
    }
    if (!(typeof(b_0) === 'bigint' && b_0 >= 0n && b_0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('checkedAdd',
                                 'argument 2',
                                 'arithmetic.compact line 13 char 1',
                                 'Uint<0..340282366920938463463374607431768211456>',
                                 b_0)
    }
    return _dummyContract._checkedAdd_0(a_0, b_0);
  },
  checkedSub: (...args_0) => {
    if (args_0.length !== 2) {
      throw new __compactRuntime.CompactError(`checkedSub: expected 2 arguments (as invoked from Typescript), received ${args_0.length}`);
    }
    const a_0 = args_0[0];
    const b_0 = args_0[1];
    if (!(typeof(a_0) === 'bigint' && a_0 >= 0n && a_0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('checkedSub',
                                 'argument 1',
                                 'arithmetic.compact line 17 char 1',
                                 'Uint<0..340282366920938463463374607431768211456>',
                                 a_0)
    }
    if (!(typeof(b_0) === 'bigint' && b_0 >= 0n && b_0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('checkedSub',
                                 'argument 2',
                                 'arithmetic.compact line 17 char 1',
                                 'Uint<0..340282366920938463463374607431768211456>',
                                 b_0)
    }
    return _dummyContract._checkedSub_0(a_0, b_0);
  },
  checkedMul: (...args_0) => {
    if (args_0.length !== 3) {
      throw new __compactRuntime.CompactError(`checkedMul: expected 3 arguments (as invoked from Typescript), received ${args_0.length}`);
    }
    const a_0 = args_0[0];
    const b_0 = args_0[1];
    const h_0 = args_0[2];
    if (!(typeof(a_0) === 'bigint' && a_0 >= 0n && a_0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('checkedMul',
                                 'argument 1',
                                 'arithmetic.compact line 22 char 1',
                                 'Uint<0..340282366920938463463374607431768211456>',
                                 a_0)
    }
    if (!(typeof(b_0) === 'bigint' && b_0 >= 0n && b_0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('checkedMul',
                                 'argument 2',
                                 'arithmetic.compact line 22 char 1',
                                 'Uint<0..340282366920938463463374607431768211456>',
                                 b_0)
    }
    if (!(typeof(h_0) === 'object' && typeof(h_0.aLo) === 'bigint' && h_0.aLo >= 0n && h_0.aLo <= 18446744073709551615n && typeof(h_0.aHi) === 'bigint' && h_0.aHi >= 0n && h_0.aHi <= 18446744073709551615n && typeof(h_0.bLo) === 'bigint' && h_0.bLo >= 0n && h_0.bLo <= 18446744073709551615n && typeof(h_0.bHi) === 'bigint' && h_0.bHi >= 0n && h_0.bHi <= 18446744073709551615n && typeof(h_0.lo) === 'bigint' && h_0.lo >= 0n && h_0.lo <= 18446744073709551615n && typeof(h_0.carry) === 'bigint' && h_0.carry >= 0n && h_0.carry <= 18446744073709551615n)) {
      __compactRuntime.typeError('checkedMul',
                                 'argument 3',
                                 'arithmetic.compact line 22 char 1',
                                 'struct MulHint<aLo: Uint<0..18446744073709551616>, aHi: Uint<0..18446744073709551616>, bLo: Uint<0..18446744073709551616>, bHi: Uint<0..18446744073709551616>, lo: Uint<0..18446744073709551616>, carry: Uint<0..18446744073709551616>>',
                                 h_0)
    }
    return _dummyContract._checkedMul_0(a_0, b_0, h_0);
  },
  checkedDiv: (...args_0) => {
    if (args_0.length !== 5) {
      throw new __compactRuntime.CompactError(`checkedDiv: expected 5 arguments (as invoked from Typescript), received ${args_0.length}`);
    }
    const n_0 = args_0[0];
    const d_0 = args_0[1];
    const q_0 = args_0[2];
    const r_0 = args_0[3];
    const h_0 = args_0[4];
    if (!(typeof(n_0) === 'bigint' && n_0 >= 0n && n_0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('checkedDiv',
                                 'argument 1',
                                 'arithmetic.compact line 32 char 1',
                                 'Uint<0..340282366920938463463374607431768211456>',
                                 n_0)
    }
    if (!(typeof(d_0) === 'bigint' && d_0 >= 0n && d_0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('checkedDiv',
                                 'argument 2',
                                 'arithmetic.compact line 32 char 1',
                                 'Uint<0..340282366920938463463374607431768211456>',
                                 d_0)
    }
    if (!(typeof(q_0) === 'bigint' && q_0 >= 0n && q_0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('checkedDiv',
                                 'argument 3',
                                 'arithmetic.compact line 32 char 1',
                                 'Uint<0..340282366920938463463374607431768211456>',
                                 q_0)
    }
    if (!(typeof(r_0) === 'bigint' && r_0 >= 0n && r_0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('checkedDiv',
                                 'argument 4',
                                 'arithmetic.compact line 32 char 1',
                                 'Uint<0..340282366920938463463374607431768211456>',
                                 r_0)
    }
    if (!(typeof(h_0) === 'object' && typeof(h_0.aLo) === 'bigint' && h_0.aLo >= 0n && h_0.aLo <= 18446744073709551615n && typeof(h_0.aHi) === 'bigint' && h_0.aHi >= 0n && h_0.aHi <= 18446744073709551615n && typeof(h_0.bLo) === 'bigint' && h_0.bLo >= 0n && h_0.bLo <= 18446744073709551615n && typeof(h_0.bHi) === 'bigint' && h_0.bHi >= 0n && h_0.bHi <= 18446744073709551615n && typeof(h_0.lo) === 'bigint' && h_0.lo >= 0n && h_0.lo <= 18446744073709551615n && typeof(h_0.carry) === 'bigint' && h_0.carry >= 0n && h_0.carry <= 18446744073709551615n)) {
      __compactRuntime.typeError('checkedDiv',
                                 'argument 5',
                                 'arithmetic.compact line 32 char 1',
                                 'struct MulHint<aLo: Uint<0..18446744073709551616>, aHi: Uint<0..18446744073709551616>, bLo: Uint<0..18446744073709551616>, bHi: Uint<0..18446744073709551616>, lo: Uint<0..18446744073709551616>, carry: Uint<0..18446744073709551616>>',
                                 h_0)
    }
    return _dummyContract._checkedDiv_0(n_0, d_0, q_0, r_0, h_0);
  },
  transition0: (...args_0) => {
    if (args_0.length !== 6) {
      throw new __compactRuntime.CompactError(`transition0: expected 6 arguments (as invoked from Typescript), received ${args_0.length}`);
    }
    const before_0 = args_0[0];
    const args_1 = args_0[1];
    const observations_0 = args_0[2];
    const remaining_0 = args_0[3];
    const revision_0 = args_0[4];
    const hints_0 = args_0[5];
    if (!(typeof(before_0) === 'object' && typeof(before_0.f0) === 'bigint' && before_0.f0 >= 0n && before_0.f0 <= 340282366920938463463374607431768211455n && typeof(before_0.f1) === 'bigint' && before_0.f1 >= 0n && before_0.f1 <= 340282366920938463463374607431768211455n && typeof(before_0.f2) === 'bigint' && before_0.f2 >= 0n && before_0.f2 <= 340282366920938463463374607431768211455n && typeof(before_0.f3) === 'bigint' && before_0.f3 >= 0n && before_0.f3 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('transition0',
                                 'argument 1',
                                 'kernel.compact line 13 char 1',
                                 'struct KernelState<f0: Uint<0..340282366920938463463374607431768211456>, f1: Uint<0..340282366920938463463374607431768211456>, f2: Uint<0..340282366920938463463374607431768211456>, f3: Uint<0..340282366920938463463374607431768211456>>',
                                 before_0)
    }
    if (!(typeof(args_1) === 'object' && typeof(args_1.a0) === 'bigint' && args_1.a0 >= 0n && args_1.a0 <= 4294967295n && typeof(args_1.a1) === 'bigint' && args_1.a1 >= 0n && args_1.a1 <= 4294967295n && typeof(args_1.a2) === 'bigint' && args_1.a2 >= 0n && args_1.a2 <= 340282366920938463463374607431768211455n && typeof(args_1.a3) === 'bigint' && args_1.a3 >= 0n && args_1.a3 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('transition0',
                                 'argument 2',
                                 'kernel.compact line 13 char 1',
                                 'struct Arguments0<a0: Uint<0..4294967296>, a1: Uint<0..4294967296>, a2: Uint<0..340282366920938463463374607431768211456>, a3: Uint<0..340282366920938463463374607431768211456>>',
                                 args_1)
    }
    if (!(typeof(observations_0) === 'object' && typeof(observations_0.o0) === 'bigint' && observations_0.o0 >= 0n && observations_0.o0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('transition0',
                                 'argument 3',
                                 'kernel.compact line 13 char 1',
                                 'struct KernelObservations<o0: Uint<0..340282366920938463463374607431768211456>>',
                                 observations_0)
    }
    if (!(typeof(remaining_0) === 'bigint' && remaining_0 >= 0n && remaining_0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('transition0',
                                 'argument 4',
                                 'kernel.compact line 13 char 1',
                                 'Uint<0..340282366920938463463374607431768211456>',
                                 remaining_0)
    }
    if (!(typeof(revision_0) === 'bigint' && revision_0 >= 0n && revision_0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('transition0',
                                 'argument 5',
                                 'kernel.compact line 13 char 1',
                                 'Uint<0..340282366920938463463374607431768211456>',
                                 revision_0)
    }
    if (!(typeof(hints_0) === 'object' && typeof(hints_0.unused) === 'bigint' && hints_0.unused >= 0n && hints_0.unused <= 1n)) {
      __compactRuntime.typeError('transition0',
                                 'argument 6',
                                 'kernel.compact line 13 char 1',
                                 'struct Hints0<unused: Uint<0..2>>',
                                 hints_0)
    }
    return _dummyContract._transition0_0(before_0,
                                         args_1,
                                         observations_0,
                                         remaining_0,
                                         revision_0,
                                         hints_0);
  },
  transition1: (...args_0) => {
    if (args_0.length !== 6) {
      throw new __compactRuntime.CompactError(`transition1: expected 6 arguments (as invoked from Typescript), received ${args_0.length}`);
    }
    const before_0 = args_0[0];
    const args_1 = args_0[1];
    const observations_0 = args_0[2];
    const remaining_0 = args_0[3];
    const revision_0 = args_0[4];
    const hints_0 = args_0[5];
    if (!(typeof(before_0) === 'object' && typeof(before_0.f0) === 'bigint' && before_0.f0 >= 0n && before_0.f0 <= 340282366920938463463374607431768211455n && typeof(before_0.f1) === 'bigint' && before_0.f1 >= 0n && before_0.f1 <= 340282366920938463463374607431768211455n && typeof(before_0.f2) === 'bigint' && before_0.f2 >= 0n && before_0.f2 <= 340282366920938463463374607431768211455n && typeof(before_0.f3) === 'bigint' && before_0.f3 >= 0n && before_0.f3 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('transition1',
                                 'argument 1',
                                 'kernel.compact line 74 char 1',
                                 'struct KernelState<f0: Uint<0..340282366920938463463374607431768211456>, f1: Uint<0..340282366920938463463374607431768211456>, f2: Uint<0..340282366920938463463374607431768211456>, f3: Uint<0..340282366920938463463374607431768211456>>',
                                 before_0)
    }
    if (!(typeof(args_1) === 'object' && typeof(args_1.a0) === 'bigint' && args_1.a0 >= 0n && args_1.a0 <= 4294967295n)) {
      __compactRuntime.typeError('transition1',
                                 'argument 2',
                                 'kernel.compact line 74 char 1',
                                 'struct Arguments1<a0: Uint<0..4294967296>>',
                                 args_1)
    }
    if (!(typeof(observations_0) === 'object' && typeof(observations_0.o0) === 'bigint' && observations_0.o0 >= 0n && observations_0.o0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('transition1',
                                 'argument 3',
                                 'kernel.compact line 74 char 1',
                                 'struct KernelObservations<o0: Uint<0..340282366920938463463374607431768211456>>',
                                 observations_0)
    }
    if (!(typeof(remaining_0) === 'bigint' && remaining_0 >= 0n && remaining_0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('transition1',
                                 'argument 4',
                                 'kernel.compact line 74 char 1',
                                 'Uint<0..340282366920938463463374607431768211456>',
                                 remaining_0)
    }
    if (!(typeof(revision_0) === 'bigint' && revision_0 >= 0n && revision_0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('transition1',
                                 'argument 5',
                                 'kernel.compact line 74 char 1',
                                 'Uint<0..340282366920938463463374607431768211456>',
                                 revision_0)
    }
    if (!(typeof(hints_0) === 'object' && typeof(hints_0.unused) === 'bigint' && hints_0.unused >= 0n && hints_0.unused <= 1n)) {
      __compactRuntime.typeError('transition1',
                                 'argument 6',
                                 'kernel.compact line 74 char 1',
                                 'struct Hints1<unused: Uint<0..2>>',
                                 hints_0)
    }
    return _dummyContract._transition1_0(before_0,
                                         args_1,
                                         observations_0,
                                         remaining_0,
                                         revision_0,
                                         hints_0);
  },
  orderChallenge: (...args_0) => {
    if (args_0.length !== 6) {
      throw new __compactRuntime.CompactError(`orderChallenge: expected 6 arguments (as invoked from Typescript), received ${args_0.length}`);
    }
    const order_0 = args_0[0];
    const instance_0 = args_0[1];
    const owner_0 = args_0[2];
    const action_0 = args_0[3];
    const nonce_0 = args_0[4];
    const announcement_0 = args_0[5];
    if (!(typeof(order_0) === 'object' && typeof(order_0.account) === 'object' && order_0.account.bytes.buffer instanceof ArrayBuffer && order_0.account.bytes.BYTES_PER_ELEMENT === 1 && order_0.account.bytes.length === 32 && typeof(order_0.recipient) === 'object' && order_0.recipient.bytes.buffer instanceof ArrayBuffer && order_0.recipient.bytes.BYTES_PER_ELEMENT === 1 && order_0.recipient.bytes.length === 32 && typeof(order_0.executor) === 'object' && order_0.executor.bytes.buffer instanceof ArrayBuffer && order_0.executor.bytes.BYTES_PER_ELEMENT === 1 && order_0.executor.bytes.length === 32 && order_0.orderId.buffer instanceof ArrayBuffer && order_0.orderId.BYTES_PER_ELEMENT === 1 && order_0.orderId.length === 32 && order_0.network.buffer instanceof ArrayBuffer && order_0.network.BYTES_PER_ELEMENT === 1 && order_0.network.length === 32 && order_0.assetA.buffer instanceof ArrayBuffer && order_0.assetA.BYTES_PER_ELEMENT === 1 && order_0.assetA.length === 32 && order_0.assetB.buffer instanceof ArrayBuffer && order_0.assetB.BYTES_PER_ELEMENT === 1 && order_0.assetB.length === 32 && order_0.program.buffer instanceof ArrayBuffer && order_0.program.BYTES_PER_ELEMENT === 1 && order_0.program.length === 32 && typeof(order_0.epoch) === 'bigint' && order_0.epoch >= 0n && order_0.epoch <= 18446744073709551615n && typeof(order_0.input) === 'bigint' && order_0.input >= 0n && order_0.input <= 340282366920938463463374607431768211455n && typeof(order_0.minimum) === 'bigint' && order_0.minimum >= 0n && order_0.minimum <= 340282366920938463463374607431768211455n && typeof(order_0.fee) === 'bigint' && order_0.fee >= 0n && order_0.fee <= 340282366920938463463374607431768211455n && typeof(order_0.expiry) === 'bigint' && order_0.expiry >= 0n && order_0.expiry <= 18446744073709551615n)) {
      __compactRuntime.typeError('orderChallenge',
                                 'argument 1',
                                 'acceptance.compact line 39 char 1',
                                 'struct OrderTerms<account: struct UserAddress<bytes: Bytes<32>>, recipient: struct UserAddress<bytes: Bytes<32>>, executor: struct UserAddress<bytes: Bytes<32>>, orderId: Bytes<32>, network: Bytes<32>, assetA: Bytes<32>, assetB: Bytes<32>, program: Bytes<32>, epoch: Uint<0..18446744073709551616>, input: Uint<0..340282366920938463463374607431768211456>, minimum: Uint<0..340282366920938463463374607431768211456>, fee: Uint<0..340282366920938463463374607431768211456>, expiry: Uint<0..18446744073709551616>>',
                                 order_0)
    }
    if (!(typeof(instance_0) === 'object' && instance_0.bytes.buffer instanceof ArrayBuffer && instance_0.bytes.BYTES_PER_ELEMENT === 1 && instance_0.bytes.length === 32)) {
      __compactRuntime.typeError('orderChallenge',
                                 'argument 2',
                                 'acceptance.compact line 39 char 1',
                                 'struct ContractAddress<bytes: Bytes<32>>',
                                 instance_0)
    }
    if (!(typeof(owner_0.x) === 'bigint' && owner_0.x >= 0n && owner_0.x <= __compactRuntime.MAX_FIELD && typeof(owner_0.y) === 'bigint' && owner_0.y >= 0n && owner_0.y <= __compactRuntime.MAX_FIELD)) {
      __compactRuntime.typeError('orderChallenge',
                                 'argument 3',
                                 'acceptance.compact line 39 char 1',
                                 'JubjubPoint',
                                 owner_0)
    }
    if (!(typeof(action_0) === 'bigint' && action_0 >= 0n && action_0 <= 255n)) {
      __compactRuntime.typeError('orderChallenge',
                                 'argument 4',
                                 'acceptance.compact line 39 char 1',
                                 'Uint<0..256>',
                                 action_0)
    }
    if (!(typeof(nonce_0) === 'bigint' && nonce_0 >= 0n && nonce_0 <= 340282366920938463463374607431768211455n)) {
      __compactRuntime.typeError('orderChallenge',
                                 'argument 5',
                                 'acceptance.compact line 39 char 1',
                                 'Uint<0..340282366920938463463374607431768211456>',
                                 nonce_0)
    }
    if (!(typeof(announcement_0.x) === 'bigint' && announcement_0.x >= 0n && announcement_0.x <= __compactRuntime.MAX_FIELD && typeof(announcement_0.y) === 'bigint' && announcement_0.y >= 0n && announcement_0.y <= __compactRuntime.MAX_FIELD)) {
      __compactRuntime.typeError('orderChallenge',
                                 'argument 6',
                                 'acceptance.compact line 39 char 1',
                                 'JubjubPoint',
                                 announcement_0)
    }
    return _dummyContract._orderChallenge_0(order_0,
                                            instance_0,
                                            owner_0,
                                            action_0,
                                            nonce_0,
                                            announcement_0);
  }
};
export const expectedVk = {
  'cancel': 'd1f983e549d948774bf12e209c5bfcd408a251a4be69e3ca8078a2c4cbe3789c',
  'fill': 'b443cce8de2a9e8a15f8441bc3711d71e5c8efe571550a855e6e5faff4d54677',
  'fund': '290d1bb0cc13c968b944e31a8af603feb65f417573afe90b13e9ad33c0bc8ba5',
};

export const circuitSignatures = {
  'checkedAdd': {pure: true, provable: false, argumentTypes: [{tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}], resultType: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}},
  'checkedSub': {pure: true, provable: false, argumentTypes: [{tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}], resultType: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}},
  'checkedMul': {pure: true, provable: false, argumentTypes: [{tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Struct', name: 'MulHint', elements: [{name: 'aLo', type: {tag: 'Uint', maxval: '18446744073709551615'}}, {name: 'aHi', type: {tag: 'Uint', maxval: '18446744073709551615'}}, {name: 'bLo', type: {tag: 'Uint', maxval: '18446744073709551615'}}, {name: 'bHi', type: {tag: 'Uint', maxval: '18446744073709551615'}}, {name: 'lo', type: {tag: 'Uint', maxval: '18446744073709551615'}}, {name: 'carry', type: {tag: 'Uint', maxval: '18446744073709551615'}}]}], resultType: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}},
  'checkedDiv': {pure: true, provable: false, argumentTypes: [{tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Struct', name: 'MulHint', elements: [{name: 'aLo', type: {tag: 'Uint', maxval: '18446744073709551615'}}, {name: 'aHi', type: {tag: 'Uint', maxval: '18446744073709551615'}}, {name: 'bLo', type: {tag: 'Uint', maxval: '18446744073709551615'}}, {name: 'bHi', type: {tag: 'Uint', maxval: '18446744073709551615'}}, {name: 'lo', type: {tag: 'Uint', maxval: '18446744073709551615'}}, {name: 'carry', type: {tag: 'Uint', maxval: '18446744073709551615'}}]}], resultType: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}},
  'transition0': {pure: true, provable: false, argumentTypes: [{tag: 'Struct', name: 'KernelState', elements: [{name: 'f0', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'f1', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'f2', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'f3', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}]}, {tag: 'Struct', name: 'Arguments0', elements: [{name: 'a0', type: {tag: 'Uint', maxval: '4294967295'}}, {name: 'a1', type: {tag: 'Uint', maxval: '4294967295'}}, {name: 'a2', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'a3', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}]}, {tag: 'Struct', name: 'KernelObservations', elements: [{name: 'o0', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}]}, {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Struct', name: 'Hints0', elements: [{name: 'unused', type: {tag: 'Uint', maxval: '1'}}]}], resultType: {tag: 'Struct', name: 'Result0', elements: [{name: 'after', type: {tag: 'Struct', name: 'KernelState', elements: [{name: 'f0', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'f1', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'f2', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'f3', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}]}}, {name: 'remaining', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'revision', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'effect0', type: {tag: 'Struct', name: 'Effect0_0', elements: [{name: 'v0', type: {tag: 'Uint', maxval: '4294967295'}}, {name: 'v1', type: {tag: 'Uint', maxval: '4294967295'}}, {name: 'v2', type: {tag: 'Uint', maxval: '4294967295'}}, {name: 'v3', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}]}}, {name: 'effect1', type: {tag: 'Struct', name: 'Effect0_1', elements: [{name: 'v0', type: {tag: 'Uint', maxval: '4294967295'}}, {name: 'v1', type: {tag: 'Uint', maxval: '4294967295'}}, {name: 'v2', type: {tag: 'Uint', maxval: '4294967295'}}, {name: 'v3', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}]}}]}},
  'transition1': {pure: true, provable: false, argumentTypes: [{tag: 'Struct', name: 'KernelState', elements: [{name: 'f0', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'f1', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'f2', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'f3', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}]}, {tag: 'Struct', name: 'Arguments1', elements: [{name: 'a0', type: {tag: 'Uint', maxval: '4294967295'}}]}, {tag: 'Struct', name: 'KernelObservations', elements: [{name: 'o0', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}]}, {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Struct', name: 'Hints1', elements: [{name: 'unused', type: {tag: 'Uint', maxval: '1'}}]}], resultType: {tag: 'Struct', name: 'Result1', elements: [{name: 'after', type: {tag: 'Struct', name: 'KernelState', elements: [{name: 'f0', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'f1', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'f2', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'f3', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}]}}, {name: 'remaining', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'revision', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'effect0', type: {tag: 'Struct', name: 'Effect1_0', elements: [{name: 'v0', type: {tag: 'Uint', maxval: '4294967295'}}, {name: 'v1', type: {tag: 'Uint', maxval: '4294967295'}}, {name: 'v2', type: {tag: 'Uint', maxval: '4294967295'}}, {name: 'v3', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}]}}]}},
  'orderChallenge': {pure: true, provable: false, argumentTypes: [{tag: 'Struct', name: 'OrderTerms', elements: [{name: 'account', type: {tag: 'Struct', name: 'UserAddress', elements: [{name: 'bytes', type: {tag: 'Bytes', length: 32}}]}}, {name: 'recipient', type: {tag: 'Struct', name: 'UserAddress', elements: [{name: 'bytes', type: {tag: 'Bytes', length: 32}}]}}, {name: 'executor', type: {tag: 'Struct', name: 'UserAddress', elements: [{name: 'bytes', type: {tag: 'Bytes', length: 32}}]}}, {name: 'orderId', type: {tag: 'Bytes', length: 32}}, {name: 'network', type: {tag: 'Bytes', length: 32}}, {name: 'assetA', type: {tag: 'Bytes', length: 32}}, {name: 'assetB', type: {tag: 'Bytes', length: 32}}, {name: 'program', type: {tag: 'Bytes', length: 32}}, {name: 'epoch', type: {tag: 'Uint', maxval: '18446744073709551615'}}, {name: 'input', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'minimum', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'fee', type: {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}}, {name: 'expiry', type: {tag: 'Uint', maxval: '18446744073709551615'}}]}, {tag: 'Struct', name: 'ContractAddress', elements: [{name: 'bytes', type: {tag: 'Bytes', length: 32}}]}, {tag: 'JubjubPoint'}, {tag: 'Uint', maxval: '255'}, {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'JubjubPoint'}], resultType: {tag: 'Field'}},
  'fund': {pure: false, provable: true, argumentTypes: [], resultType: {tag: 'Tuple', types: []}},
  'fill': {pure: false, provable: true, argumentTypes: [{tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Uint', maxval: '18446744073709551615'}, {tag: 'Struct', name: 'OrderSignature', elements: [{name: 'announcement', type: {tag: 'JubjubPoint'}}, {name: 'response', type: {tag: 'Field'}}]}], resultType: {tag: 'Tuple', types: []}},
  'cancel': {pure: false, provable: true, argumentTypes: [{tag: 'Uint', maxval: '340282366920938463463374607431768211455'}, {tag: 'Struct', name: 'OrderSignature', elements: [{name: 'announcement', type: {tag: 'JubjubPoint'}}, {name: 'response', type: {tag: 'Field'}}]}], resultType: {tag: 'Tuple', types: []}},
};

export const declaredInterfaces = {};

//# sourceMappingURL=index.js.map
