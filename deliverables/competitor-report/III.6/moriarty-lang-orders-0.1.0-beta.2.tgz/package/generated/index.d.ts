import type * as __compactRuntime from '@midnight-ntwrk/compact-runtime';

export type MulHint = { aLo: bigint;
                        aHi: bigint;
                        bLo: bigint;
                        bHi: bigint;
                        lo: bigint;
                        carry: bigint
                      };

export type DivisionHint = { q: bigint; r: bigint; product: MulHint };

export type KernelState = { f0: bigint; f1: bigint; f2: bigint; f3: bigint };

export type KernelObservations = { o0: bigint };

export type Arguments0 = { a0: bigint; a1: bigint; a2: bigint; a3: bigint };

export type Hints0 = { unused: bigint };

export type Effect0_0 = { v0: bigint; v1: bigint; v2: bigint; v3: bigint };

export type Effect0_1 = { v0: bigint; v1: bigint; v2: bigint; v3: bigint };

export type Result0 = { after: KernelState;
                        remaining: bigint;
                        revision: bigint;
                        effect0: Effect0_0;
                        effect1: Effect0_1
                      };

export type Arguments1 = { a0: bigint };

export type Hints1 = { unused: bigint };

export type Effect1_0 = { v0: bigint; v1: bigint; v2: bigint; v3: bigint };

export type Result1 = { after: KernelState;
                        remaining: bigint;
                        revision: bigint;
                        effect0: Effect1_0
                      };

export type OrderTerms = { account: { bytes: Uint8Array };
                           recipient: { bytes: Uint8Array };
                           executor: { bytes: Uint8Array };
                           orderId: Uint8Array;
                           network: Uint8Array;
                           assetA: Uint8Array;
                           assetB: Uint8Array;
                           program: Uint8Array;
                           epoch: bigint;
                           input: bigint;
                           minimum: bigint;
                           fee: bigint;
                           expiry: bigint
                         };

export type OrderSignature = { announcement: __compactRuntime.JubjubPoint;
                               response: bigint
                             };

export type Witnesses<PS> = {
}

export type ImpureCircuits<PS> = {
  fund(context: __compactRuntime.CircuitContext<PS>): Promise<__compactRuntime.CircuitResults<PS, []>>;
  fill(context: __compactRuntime.CircuitContext<PS>,
       expected_0: bigint,
       amountA_0: bigint,
       amountB_0: bigint,
       applicationFee_0: bigint,
       now_0: bigint,
       sig_0: OrderSignature): Promise<__compactRuntime.CircuitResults<PS, []>>;
  cancel(context: __compactRuntime.CircuitContext<PS>,
         expected_0: bigint,
         sig_0: OrderSignature): Promise<__compactRuntime.CircuitResults<PS, []>>;
}

export type ProvableCircuits<PS> = {
  fund(context: __compactRuntime.CircuitContext<PS>): Promise<__compactRuntime.CircuitResults<PS, []>>;
  fill(context: __compactRuntime.CircuitContext<PS>,
       expected_0: bigint,
       amountA_0: bigint,
       amountB_0: bigint,
       applicationFee_0: bigint,
       now_0: bigint,
       sig_0: OrderSignature): Promise<__compactRuntime.CircuitResults<PS, []>>;
  cancel(context: __compactRuntime.CircuitContext<PS>,
         expected_0: bigint,
         sig_0: OrderSignature): Promise<__compactRuntime.CircuitResults<PS, []>>;
}

export type PureCircuits = {
  checkedAdd(a_0: bigint, b_0: bigint): bigint;
  checkedSub(a_0: bigint, b_0: bigint): bigint;
  checkedMul(a_0: bigint, b_0: bigint, h_0: MulHint): bigint;
  checkedDiv(n_0: bigint, d_0: bigint, q_0: bigint, r_0: bigint, h_0: MulHint): bigint;
  transition0(before_0: KernelState,
              args_0: Arguments0,
              observations_0: KernelObservations,
              remaining_0: bigint,
              revision_0: bigint,
              hints_0: Hints0): Result0;
  transition1(before_0: KernelState,
              args_0: Arguments1,
              observations_0: KernelObservations,
              remaining_0: bigint,
              revision_0: bigint,
              hints_0: Hints1): Result1;
  orderChallenge(order_0: OrderTerms,
                 instance_0: { bytes: Uint8Array },
                 owner_0: __compactRuntime.JubjubPoint,
                 action_0: bigint,
                 nonce_0: bigint,
                 announcement_0: __compactRuntime.JubjubPoint): bigint;
}

export type Circuits<PS> = {
  checkedAdd(context: __compactRuntime.CircuitContext<PS>,
             a_0: bigint,
             b_0: bigint): Promise<__compactRuntime.CircuitResults<PS, bigint>>;
  checkedSub(context: __compactRuntime.CircuitContext<PS>,
             a_0: bigint,
             b_0: bigint): Promise<__compactRuntime.CircuitResults<PS, bigint>>;
  checkedMul(context: __compactRuntime.CircuitContext<PS>,
             a_0: bigint,
             b_0: bigint,
             h_0: MulHint): Promise<__compactRuntime.CircuitResults<PS, bigint>>;
  checkedDiv(context: __compactRuntime.CircuitContext<PS>,
             n_0: bigint,
             d_0: bigint,
             q_0: bigint,
             r_0: bigint,
             h_0: MulHint): Promise<__compactRuntime.CircuitResults<PS, bigint>>;
  transition0(context: __compactRuntime.CircuitContext<PS>,
              before_0: KernelState,
              args_0: Arguments0,
              observations_0: KernelObservations,
              remaining_0: bigint,
              revision_0: bigint,
              hints_0: Hints0): Promise<__compactRuntime.CircuitResults<PS, Result0>>;
  transition1(context: __compactRuntime.CircuitContext<PS>,
              before_0: KernelState,
              args_0: Arguments1,
              observations_0: KernelObservations,
              remaining_0: bigint,
              revision_0: bigint,
              hints_0: Hints1): Promise<__compactRuntime.CircuitResults<PS, Result1>>;
  orderChallenge(context: __compactRuntime.CircuitContext<PS>,
                 order_0: OrderTerms,
                 instance_0: { bytes: Uint8Array },
                 owner_0: __compactRuntime.JubjubPoint,
                 action_0: bigint,
                 nonce_0: bigint,
                 announcement_0: __compactRuntime.JubjubPoint): Promise<__compactRuntime.CircuitResults<PS, bigint>>;
  fund(context: __compactRuntime.CircuitContext<PS>): Promise<__compactRuntime.CircuitResults<PS, []>>;
  fill(context: __compactRuntime.CircuitContext<PS>,
       expected_0: bigint,
       amountA_0: bigint,
       amountB_0: bigint,
       applicationFee_0: bigint,
       now_0: bigint,
       sig_0: OrderSignature): Promise<__compactRuntime.CircuitResults<PS, []>>;
  cancel(context: __compactRuntime.CircuitContext<PS>,
         expected_0: bigint,
         sig_0: OrderSignature): Promise<__compactRuntime.CircuitResults<PS, []>>;
}

export type Ledger = {
  readonly terms: OrderTerms;
  readonly ownerKey: __compactRuntime.JubjubPoint;
  readonly funded: boolean;
  readonly kernelState: KernelState;
  readonly remaining: bigint;
  readonly revision: bigint;
}

export declare class Contract<PS = any, W extends Witnesses<PS> = Witnesses<PS>> {
  witnesses: W;
  circuits: Circuits<PS>;
  impureCircuits: ImpureCircuits<PS>;
  provableCircuits: ProvableCircuits<PS>;
  constructor(witnesses: W);
  initialState(context: __compactRuntime.ConstructorContext<PS>,
               order_0: OrderTerms,
               owner_0: __compactRuntime.JubjubPoint): Promise<__compactRuntime.ConstructorResult<PS>>;
}

export declare function ledger(state: __compactRuntime.StateValue | __compactRuntime.ChargedState): Ledger;
export declare const pureCircuits: PureCircuits;
export declare const expectedVk: Record<string, string>;
export declare const circuitSignatures: __compactRuntime.CircuitSignatures;
export declare const declaredInterfaces: __compactRuntime.DeclaredInterfaces;
