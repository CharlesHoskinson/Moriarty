from pathlib import Path
import json,hashlib,runpy,os,sys
sys.dont_write_bytecode=True
B=Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/financial-MU1-MU2-current196-ordinary-QA-20261020')
load=lambda p:json.loads(Path(p).read_bytes())
plan=B/'PROPOSED-SEVEN-OPERATIONS.json'
assert hashlib.sha256(plan.read_bytes()).hexdigest()=='48357fe6f28866722219207de880185e892cb7d7aff2155545b84819906de46f'
j=load(plan);hp=j['captureHelper']
assert hashlib.sha256(Path(hp['path']).read_bytes()).hexdigest()=='713119d9400f82d559967e4296313cec8cde7125dc91a74152500577ced00626'
h=runpy.run_path(hp['path'],run_name='Root_existing_ordinary_capture_functions_only')
reference=j['previousExistingRootListPrettyInventory'];h['check'](reference)
old=runpy.run_path(reference['path'],run_name='Root_existing_list_pretty_inventory_functions_only')
assert load(B/'CORE-EXACT-L-DIRECTORY-MEMBERSHIP.json')['directories']==load(Path(reference['path']).parent/'CORE-EXACT-L-DIRECTORY-MEMBERSHIP.json')['directories']
flat=load(B/'STATIC-PREPOST-PINS.json')['files'];assert len(flat)==454
control=[h['pin'](p)for p in B.iterdir()if p.is_file()]
assert h['static_check'](flat+control)['all_match'];old['inventory']()
h['check'](j['sourceFreeze']);adoption=Path(j['sourceFreeze']['path']).parent/'ROOT-BOUNDED-SOURCE-ADOPTION.json'
assert load(adoption)['status']=='ADOPTED_SOURCE_FOR_ORDINARY_CHANGED_SOURCE_CHECKS_ONLY'
ops=j['operations'];assert len(ops)==7
for o in ops:
 assert o['wallSeconds']==30 and o['keptBytesPerStream']==131072
 assert o['argv'][:9]==['/usr/bin/timeout','--signal=KILL','30s','/usr/bin/prlimit','--cpu=25:25','--as=2147483648:2147483648','--fsize=67108864:67108864','--core=0:0','--']
 for p in o['outputs']:assert not Path(p).exists() and not Path(p).is_symlink()
W=Path(j['directoryPreparation']['work']);A=Path(j['directoryPreparation']['actualRoot'])
for p in [W,A]:
 assert not p.exists() and not p.is_symlink()
 assert not any(x.is_symlink()for x in p.parents)
W.mkdir()
for p in j['directoryPreparation']['requiredNewDirectories']:Path(p).mkdir(parents=True,exist_ok=True)
A.mkdir(mode=0o700)
def durable(p,x):
 assert not Path(p).exists();h['save'](p,x)
 with Path(p).open('rb') as f:os.fsync(f.fileno())
 fd=os.open(Path(p).parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
selection=dict(selectedIds=[o['id']for o in ops],sourceAdoption=h['pin'](adoption),RootReadBothWholeSourceOpinionsAndExistingFunctions=True,manual=h['pin'](__file__),proposal=h['pin'](plan),sourceMembers=196,normalExpectedDeps=119,cfgExpectedDeps=194,newRuntimeTests=14,allListedExpected=453,noPrefixRerun=True,noNativeSDK=True,noRetry=True)
durable(A/'ROOT-SELECTION.json',selection)
control += [h['pin'](adoption),h['pin'](A/'ROOT-SELECTION.json')]
generated=[];records=[];fullnames=None
try:
 for ix,o in enumerate(ops):
  phase=A/o['id'];phase.mkdir()
  before=h['static_check'](flat+control+generated);assert before['all_match'];old['inventory']()
  assert Path(o['environment']['TMPDIR']).is_dir() and not list(Path(o['environment']['TMPDIR']).iterdir())
  durable(phase/'PRECHECK.json',before)
  raw=h['capture'](o,phase);durable(phase/'RESULT.json',raw)
  for name in ['COMMAND.json','stdout.bin','stderr.bin','RESULT.json']:
   with(phase/name).open('rb')as f:os.fsync(f.fileno())
  fd=os.open(phase,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
  post=h['static_check'](flat+control+generated);durable(phase/'POSTCHECK.json',post)
  assert post['all_match'];old['inventory']()
  assert load(phase/'COMMAND.json')==o
  for x in raw['streams']:
   h['check'](x);assert x['full_stream_retained'] and x['bytes']==x['bytes_seen']==x['bytes_retained']
  assert raw['actual_exit']==0 and raw['controller_failure'] is None,raw
  out=(phase/'stdout.bin').read_bytes();err=(phase/'stderr.bin').read_bytes()
  row=dict(id=o['id'],accepted=True,result=h['pin'](phase/'RESULT.json'),elapsedSeconds=raw['elapsed_seconds'])
  if ix<2:
   assert out==b''
   products=[h['pin'](p)for p in o['outputs']]
   assert all(x['bytes']>0 and not Path(x['path']).is_symlink()for x in products)
   durable(phase/'ACTUAL-GENERATED-PINS.json',dict(files=products))
   cl=load(B/'EXPECTED-DEP-MEMBERSHIP.json')[o['expectedDepMembership']]
   allowed={str(Path(x['path']).resolve(strict=True)):x for x in cl['files']}
   assert len(allowed)==cl['count']==[119,194][ix]
   deps=h['dep_inputs'](o['outputs'][1],allowed)
   seen={str(Path(x['selected_binding']).resolve(strict=True))for x in deps}
   assert seen==set(allowed)
   durable(phase/'EXACT-DEP-MEMBERSHIP.json',dict(files=deps,canonicalCount=len(seen),expected=cl['count'],exact=True))
   for k,p in enumerate(o['outputs']):os.chmod(p,0o500 if ix==1 and k==0 else 0o400)
   generated+=products;row.update(generated=products,exactDependencies=len(seen),diagnostics='Complete compiler stderr retained; full warning classification pending')
  elif '--list' in o['argv']:
   assert err==b''
   names=old['list_names'](out)
   assert names==o['expected']['exactNames'] and len(names)==o['expected']['count']
   if ix==2:assert len(names)==453;fullnames=names
   else:assert fullnames is not None and all(n in fullnames for n in names)
   durable(phase/'FROZEN-ACTUAL-MEMBERSHIP.json',dict(names=names,count=len(names),sourceExpected=h['pin'](B/'EXPECTED-TEST-MEMBERSHIP.json')))
   generated += [h['pin'](phase/'stdout.bin'),h['pin'](phase/'FROZEN-ACTUAL-MEMBERSHIP.json')]
   row['listed']=len(names)
  else:
   assert err==b'' and fullnames is not None
   names=o['expected']['exactNames'];filtered=len(fullnames)-len(names)
   old['pretty'](out,names,filtered)
   row.update(passed=len(names),failed=0,ignored=0,measured=0,filteredOut=filtered,exactNames=names)
  generated += [h['pin'](phase/n)for n in ['COMMAND.json','RESULT.json','stdout.bin','stderr.bin','POSTCHECK.json']]
  durable(phase/'ACCEPTANCE.json',row);records.append(row)
  assert h['static_check'](flat+control+generated)['all_match']
  print(json.dumps({k:v for k,v in row.items()if k not in ['generated','exactNames']}),flush=True)
 assert sum(x.get('passed',0)for x in records)==14
 durable(A/'ROOT-ALL-SEVEN-RESULT.json',dict(accepted=True,records=records,generated=generated,selectedRuntimePassed=14,wholeListed=453,sourceFiles=196,staticRows=454,sourceOnlyVotesSeparate=True,scope='MU1 invariant +MU2 checked selection only; Step/apply/firststatement/MU3-7/fullfinance/execJSON/native/proof/target/EARS remainOPEN',noPrefixReplay=True))
except BaseException as e:
 durable(A/'FAILURE.json',dict(error=type(e).__name__+': '+str(e),acceptedPhases=records,remainingUnrun=True,noRetryOrCapChange=True))
 raise
