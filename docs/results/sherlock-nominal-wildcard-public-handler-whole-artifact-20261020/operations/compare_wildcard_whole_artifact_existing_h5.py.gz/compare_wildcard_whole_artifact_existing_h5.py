"""Wildcard whole public-artifact comparison, selected child only.

Compares the WHOLE parsed original expected artifact against the WHOLE
parsed ACTUAL PUBLISHED artifact through the exact existing H5
boundary_observations_equal. No vector projection, field filtering,
wrapper stripping, source codec, tag rewriting, value coercion, golden
regeneration, or new equality/normalizer is implemented. Native JSON
kinds, array order/multiplicity and all nested membership are preserved;
only object-key order is immaterial through the existing canonical_bytes.

Finite acyclic sealing: this file embeds no hash of itself, of the
caller, of the command, or of the bindings file. The bindings file,
sealed after this file, carries only the external pin of this file.
The caller, command, bindings, review, and this file are all pinned
only by the later external Root selection, which is the trust root
and is pinned by no sealed file. See the seal-order note following
the returned files.

Root and the source author do not open private expected, membership,
derivation, or populated actual bodies. This child reads populated
actual bytes only after public pin checks, and reads the private
expected freeze and expected/membership bodies only after every
immutable actual check below has passed. ProgramView is taken only
from the declared public location admission.program_view for the
supplementary keyset check; whole-object equality remains primary.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, math, sys
sys.dont_write_bytecode = True

ROOT_KEYS = (
    "format", "qualification", "source_profile", "source",
    "execution_profile", "body_typechecking", "semantic_correspondence",
    "evaluation_performed", "config", "target", "admission",
    "preparation", "plans", "evidence",
)
PROGRAM_VIEW_KEYS = (
    "entry", "expressions", "occurrences", "occurrence_paths", "children",
    "functions", "parameters", "arms", "patterns", "pattern_children",
    "types", "type_args", "constructors", "ctor_fields",
    "decl_param_counts", "decl_ctor_counts", "decl_templates",
    "plan_nodes", "plan_cases", "field_paths", "constants",
    "constant_fields", "names",
)
FREEZE_ROOT_KEYS = {"status", "author_identity", "protected_artifacts",
                    "barrier", "limitations"}
HEX = set("0123456789abcdef")
SCHEMA = "sherlock-wildcard-whole-artifact-comparison/1"


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())


def check(row):
    assert isinstance(row, dict), "missing pin row"
    assert set(row) == {"path", "bytes", "sha256"}, "pin row shape"
    assert pin(row["path"]) == row, "pin mismatch"


def _no_duplicates(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError("duplicate object key")
        obj[key] = value
    return obj


def _reject_constant(name):
    raise ValueError("non-finite JSON constant: " + name)


def _finite_float(text):
    value = float(text)
    if not math.isfinite(value):
        raise ValueError("non-finite JSON number")
    return value


def parse_json_bytes(raw):
    """Strict parse guard only; equality is existing H5 canonical_bytes."""
    text = raw.decode("utf-8")
    return json.loads(text, object_pairs_hook=_no_duplicates,
                      parse_constant=_reject_constant,
                      parse_float=_finite_float)


def read_json(path):
    return parse_json_bytes(Path(path).read_bytes())


def load_module(row, name):
    check(row)
    spec = importlib.util.spec_from_file_location(name, row["path"])
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def program_view(artifact):
    assert type(artifact) is dict, "artifact root type"
    admission = artifact["admission"]
    assert type(admission) is dict, "admission type"
    view = admission["program_view"]
    assert type(view) is dict, "ProgramView type"
    return view


def check_static_manifest(b):
    check(b["actualStaticManifest"])
    manifest = read_json(b["actualStaticManifest"]["path"])
    assert type(manifest) is dict and set(manifest) == {"members"}, \
        "static manifest root"
    assert b["actualStaticManifestShape"] == {
        "root_keys": ["members"], "member_count": 477,
        "row_keys": ["path", "bytes", "sha256"]}, "static shape binding"
    members = manifest["members"]
    assert type(members) is list and len(members) == 477, "static count"
    for row in members:
        assert type(row) is dict and set(row) == {"path", "bytes", "sha256"}, \
            "static row shape"
        check(row)
    return members


def check_source_freeze(b):
    check(b["sourceFreeze"])
    check(b["sourceCut"])
    freeze = read_json(b["sourceFreeze"]["path"])
    assert freeze["status"] == "SOURCE_ONLY_UNCOMPILED_UNRUN_UNSELECTED", \
        "source freeze status"
    assert freeze["fileCount"] == 26, "source freeze count"
    files = freeze["files"]
    assert type(files) is list and len(files) == 26, "source freeze files"
    for row in files:
        check(row)
    assert b["sourceCut"] in files, "sourceCut not in source freeze"
    assert files.count(b["sourceCut"]) == 1, "sourceCut not exactly once"
    return files


def check_private_freeze(b):
    """Child-only, after durable actual verification. Exact list shape."""
    check(b["originalExpectedFreeze"])
    freeze = read_json(b["originalExpectedFreeze"]["path"])
    assert type(freeze) is dict and set(freeze) == FREEZE_ROOT_KEYS, \
        "private freeze root keys"
    protected = freeze["protected_artifacts"]
    assert type(protected) is list, "protected_artifacts must be a list"
    assert len(protected) == 22, "protected_artifacts count"
    for row in protected:
        assert type(row) is dict and set(row) == {"path", "bytes", "sha256"}, \
            "protected row shape"
        assert type(row["path"]) is str, "protected path type"
        assert type(row["bytes"]) is int, "protected bytes type"
        assert type(row["sha256"]) is str and len(row["sha256"]) == 64, \
            "protected sha shape"
        assert set(row["sha256"]) <= HEX, "protected sha lowercase hex"
    assert protected.count(b["expectedOpaque"]) == 1, "expected freeze row"
    assert protected.count(b["membershipOpaque"]) == 1, "membership freeze row"
    return freeze


def main(bindings_path):
    b = read_json(bindings_path)
    bindings_observed = pin(bindings_path)
    assert b["schema"] == "sherlock-wildcard-full-artifact-muse-source-input/1"
    assert tuple(b["publicRootKeys"]) == ROOT_KEYS, "public root keys binding"
    assert tuple(b["publicProgramViewKeys"]) == PROGRAM_VIEW_KEYS, \
        "public ProgramView keys binding"
    # No sealedBindings, comparisonCaller, command, or review pin is read
    # from bindings: those pins live only in the external Root selection.
    assert "sealedBindings" not in b, "cyclic sealedBindings in bindings"
    assert "comparisonCaller" not in b, "caller pin must be selection-only"
    assert "command" not in b, "command pin must be selection-only"

    # comparisonSource is an external pin of this file, sealed into the
    # bindings file after this file was final. This file embeds no hash.
    check(b["comparisonSource"])
    assert Path(b["comparisonSource"]["path"]).resolve() == \
        Path(__file__).resolve(), "self pin"

    # Initial public phase: private freeze, expected, and membership rows
    # are carried as metadata only and are neither checked nor opened here.
    public = ([b["actualFreeze"], b["sourceFreeze"], b["sourceCut"],
               b["prefrozenSafe"], b["actualStaticManifest"],
               b["actualPublishedArtifact"], b["actualCaptureStdout"],
               b["actualCaptureStderr"], b["actualPublicationReceipt"],
               b["actualCaptureResult"], b["actualLinkResult"],
               b["captureHelper"], b["comparisonSource"]]
              + b["actualFiles"] + b["generatedArtifacts"]
              + b["helpers"] + b["python"])
    for row in public:
        check(row)
    assert b["actualPublishedArtifact"] in b["generatedArtifacts"]
    assert b["actualStaticManifest"] in b["actualFiles"]
    assert b["actualCaptureStdout"] in b["actualFiles"]
    assert b["actualPublicationReceipt"] in b["actualFiles"]
    assert b["actualCaptureResult"] in b["actualFiles"]
    assert b["actualLinkResult"] in b["actualFiles"]
    assert Path(b["helpers"][0]["path"]).name == "quint_observations.py"
    assert Path(b["helpers"][1]["path"]).name == \
        "core2_await_boundary_wire.py"

    static_members = check_static_manifest(b)
    source_files = check_source_freeze(b)

    # Complete immutable actual capture precedes FIRST private read.
    frozen = read_json(b["actualFreeze"]["path"])
    assert frozen["status"] == "COMPLETE_EXTERNAL_COMPILE_CAPTURE_FROZEN"
    assert frozen["expectedBodyReads"] == 0
    assert frozen["members"] == b["actualFiles"], "actual freeze members"
    assert frozen["generated"] == b["generatedArtifacts"], "actual generated"
    assert frozen["sourceFreeze"] == b["sourceFreeze"], "freeze sourceFreeze"
    assert frozen["sourceCut"] == b["sourceCut"], "freeze sourceCut"
    for row in b["actualFiles"]:
        check(row)
    for row in b["generatedArtifacts"]:
        check(row)

    link = read_json(b["actualLinkResult"]["path"])
    capture_result = read_json(b["actualCaptureResult"]["path"])
    for result in (link, capture_result):
        assert result["actual_exit"] == 0, "actual result exit"
        assert result["controller_failure"] is None, "actual controller"
        streams = result["streams"]
        assert type(streams) is list and len(streams) == 2, "result streams"
        for stream in streams:
            assert stream["full_stream_retained"] is True, "stream retained"
            assert stream["bytes_seen"] == stream["bytes_retained"] == \
                stream["bytes"]
            assert dict(path=stream["path"], bytes=stream["bytes"],
                        sha256=stream["sha256"]) in b["actualFiles"]

    receipt = read_json(b["actualPublicationReceipt"]["path"])
    assert receipt["artifact"] == b["actualPublishedArtifact"], "receipt"
    assert receipt["wholeStdoutSameBytesPlusOneLF"] is True
    assert receipt["onlyPublishedFile"] is True
    assert receipt["genuineExactPreparedStatus"] is True
    assert receipt["populatedArtifactNotPrintedOrParsedByRoot"] is True

    published_raw = Path(b["actualPublishedArtifact"]["path"]).read_bytes()
    stdout_raw = Path(b["actualCaptureStdout"]["path"]).read_bytes()
    check(b["actualPublishedArtifact"])
    check(b["actualCaptureStdout"])
    check(b["actualCaptureStderr"])
    assert len(published_raw) == 10582, "published bytes"
    assert len(stdout_raw) == 10583, "stdout bytes"
    assert stdout_raw == published_raw + b"\n", "stdout is published + LF"
    published_dir = Path(b["actualPublishedArtifact"]["path"]).parent
    assert sorted(p.name for p in published_dir.iterdir()) == \
        ["sherlock-artifact.json"], "publication directory membership"

    safe = read_json(b["prefrozenSafe"]["path"])
    assert safe["status"] == "SAFE-HANDOFF"
    assert safe["expected_public_artifact"] == b["expectedOpaque"], \
        "SAFE expected metadata link"
    assert safe["freeze"] == b["originalExpectedFreeze"], \
        "SAFE freeze metadata link"
    assert safe["membership"] == b["membershipOpaque"], \
        "SAFE membership metadata link"

    q = load_module(b["helpers"][0], "quint_observations")
    h = load_module(b["helpers"][1], "core2_await_boundary_wire")
    assert h.canonical_bytes is q.canonical_bytes, "H5 canonical identity"
    eq = h.boundary_observations_equal

    actual = parse_json_bytes(published_raw)
    assert type(actual) is dict, "actual root type"
    assert set(actual) == set(ROOT_KEYS), "actual root keyset"
    actual_view = program_view(actual)
    assert set(actual_view) == set(PROGRAM_VIEW_KEYS), "actual PV keyset"

    actual_before_first_private_read = True

    # FIRST private open occurs only now: private freeze, then expected
    # and membership pin checks and the expected body, by this child only.
    check_private_freeze(b)
    check(b["expectedOpaque"])
    check(b["membershipOpaque"])
    assert b["expectedOpaque"]["bytes"] == 10583
    assert b["expectedOpaque"]["sha256"] == \
        "228a20680deda6cb08288fc0e4216e3429c4a4a2d679b06c523c1d44f8bc80c3"
    expected = parse_json_bytes(Path(b["expectedOpaque"]["path"]).read_bytes())
    assert type(expected) is dict, "expected root type"
    expected_view = program_view(expected)

    # Whole complete objects are primary; no subset is compared instead.
    whole_artifact_equal = eq(actual, expected)
    root_keyset_equal = set(actual) == set(ROOT_KEYS) and \
        set(expected) == set(ROOT_KEYS)
    program_view_keysets_equal = set(actual_view) == set(PROGRAM_VIEW_KEYS) \
        and set(expected_view) == set(PROGRAM_VIEW_KEYS)

    for row in public + [b["originalExpectedFreeze"], b["expectedOpaque"],
                         b["membershipOpaque"]]:
        check(row)
    assert check_static_manifest(b) == static_members
    assert check_source_freeze(b) == source_files
    check_private_freeze(b)
    assert pin(bindings_path) == bindings_observed, "bindings changed"
    frozen_after = read_json(b["actualFreeze"]["path"])
    assert frozen_after == frozen and frozen_after["expectedBodyReads"] == 0

    passed = (whole_artifact_equal is True and root_keyset_equal is True
              and program_view_keysets_equal is True)
    report = dict(
        schema=SCHEMA,
        status="PASS" if passed else "MISMATCH",
        wholeArtifactEqual=bool(whole_artifact_equal),
        rootKeySetEqual=bool(root_keyset_equal),
        programViewKeySetsEqual=bool(program_view_keysets_equal),
        programViewPresent=True,
        allPredicatesTrue=passed,
        method="Existing H5 canonical_bytes/boundary_observations_equal "
               "over entire parsed top-level objects; object key order "
               "only immaterial",
        actualFreeze=b["actualFreeze"], actualFiles=b["actualFiles"],
        generatedArtifacts=b["generatedArtifacts"],
        actualPublishedArtifact=b["actualPublishedArtifact"],
        actualCaptureStdout=b["actualCaptureStdout"],
        actualPublicationReceipt=b["actualPublicationReceipt"],
        actualCaptureResult=b["actualCaptureResult"],
        actualLinkResult=b["actualLinkResult"],
        actualStaticManifest=b["actualStaticManifest"],
        sourceFreeze=b["sourceFreeze"], sourceCut=b["sourceCut"],
        prefrozenSafe=b["prefrozenSafe"],
        originalExpectedFreeze=b["originalExpectedFreeze"],
        expectedOpaque=b["expectedOpaque"],
        membershipOpaque=b["membershipOpaque"],
        helpers=b["helpers"], python=b["python"],
        captureHelper=b["captureHelper"],
        comparisonSource=b["comparisonSource"],
        bindingsObserved=bindings_observed,
        externalSelectionAuthority="Root selection only; no sealed file "
                                   "pins the selection or itself",
        staticManifest477CheckedBeforeAndAfter=True,
        sourceFreeze26CheckedBeforeAndAfter=True,
        privateFreezeList22CheckedByChildOnlyAfterActual=True,
        actualBeforeFirstPrivateRead=actual_before_first_private_read,
        childOnlyPrivateExpectedRead=True,
        rootPrivateExpectedRead=False,
        allPinsUnchangedBeforeAfter=True,
        scope="Frozen185src+manifest186/fullnormalCore35c7 only; "
              "current187/Host4 excluded. Whole compile/admit/bodytyping/"
              "publication expectation; no runtime/native/ledger/"
              "refinement/EARS approval. Owner-declaration/wire lineage "
              "and source-inspected ABI correlation remain qualified.",
        limitations=[
            "Compile-only bodytyping/admission/planner/publication evidence",
            "No runtime completion or security approval by this oracle",
            "No native/ledger/refinement/EARS acceptance",
            "Historical SOURCE_ONLY_UNCOMPILED source-freeze status is not "
            "the later capture result",
        ])
    print(json.dumps(report, sort_keys=True, separators=(",", ":"),
                     ensure_ascii=False, allow_nan=False))
    return 0 if passed else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--bindings", required=True)
    arguments = parser.parse_args()
    try:
        code = main(arguments.bindings)
    except BaseException as error:
        print(json.dumps(dict(schema=SCHEMA, status="ERROR",
                              errorType=type(error).__name__,
                              allPredicatesTrue=False), sort_keys=True))
        code = 1
    sys.exit(code)
