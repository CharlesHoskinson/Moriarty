"""Root ONE ordinary wildcard whole-artifact comparison composition.

Finite acyclic sealing: this caller embeds only the pre-existing
capture-helper pin. It embeds no pin of itself, of the child, of the
command, or of the bindings. All future pins are carried only by the
external Root selection, constructed last, which this caller verifies
at runtime and records in output receipts. Output receipts are leaves;
no input file pins them.

Root never opens, hashes, parses, stats as content, or enumerates the
private oracle freeze, expected, membership, or derivation files. Their
pin rows in bindings and in the child report are carried and compared
as in-memory metadata dicts only, and are never placed in any Root
static_check, pin, bind, or public-manifest loop. Only the selected
child checks or reads them, after durable actual verification. Same
pinned capture helper and bounded class as the inherited caller; one
attempt, no retry.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, sys
sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
BOUND = {
    "helper": {"path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/435-resolved-signature-execution-preparation/revision03-tail-four/run_tail_four.py", "bytes": 13595, "sha256": "713119d9400f82d559967e4296313cec8cde7125dc91a74152500577ced00626"},
}
SCHEMA = "sherlock-wildcard-whole-artifact-comparison/1"
PRIVATE_BINDING_KEYS = ("originalExpectedFreeze", "expectedOpaque",
                        "membershipOpaque")


def fsync_file(path):
    with Path(path).open("rb") as stream:
        os.fsync(stream.fileno())


def fsync_dir(path):
    fd = os.open(str(path), os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def save(path, value):
    path = Path(path)
    with path.open("xb") as stream:
        stream.write((json.dumps(value, indent=2, ensure_ascii=False,
                                 allow_nan=False) + "\n").encode())
        stream.flush()
        os.fsync(stream.fileno())
    fsync_dir(path.parent)


def bind(row):
    assert isinstance(row, dict), "missing external selection pin"
    assert set(row) == {"path", "bytes", "sha256"}, "selection pin shape"
    raw = Path(row["path"]).read_bytes()
    assert len(raw) == row["bytes"] and \
        hashlib.sha256(raw).hexdigest() == row["sha256"], "selection pin"


def _no_duplicates(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError("duplicate object key")
        obj[key] = value
    return obj


def parse_child_report(raw):
    assert raw.endswith(b"\n"), "child report LF"
    text = raw[:-1].decode("utf-8")
    report, end = json.JSONDecoder(
        object_pairs_hook=_no_duplicates).raw_decode(text)
    assert end == len(text), "child report trailing data"
    return report


def main(selection_path):
    bind(BOUND["helper"])
    spec = importlib.util.spec_from_file_location(
        "wildcard_existing_capture_functions_only", BOUND["helper"]["path"])
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)

    selection_path = Path(selection_path).resolve(strict=True)
    selection = json.loads(selection_path.read_text(encoding="utf-8"))
    assert selection["authorized_one_attempt"] is True
    assert selection["Root_read_full_fresh_comparison_review"] is True
    assert selection["fresh_comparison_review_eligible"] is True

    # External Root selection is the sole carrier of future pins.
    for key in ("caller", "command", "bindings", "comparisonSource",
                "fresh_comparison_review"):
        bind(selection[key])
    caller = helper.pin(__file__)
    assert selection["caller"] == caller, "selection caller pin"
    helper.check(selection["fresh_comparison_review"])

    op = json.loads(Path(selection["command"]["path"]).read_text(
        encoding="utf-8"))
    b = json.loads(Path(selection["bindings"]["path"]).read_text(
        encoding="utf-8"))
    assert selection["selected_operation_id"] == op["id"]
    assert op["comparisonSource"] == selection["comparisonSource"]
    assert b["comparisonSource"] == selection["comparisonSource"]
    assert "sealedBindings" not in b and "comparisonCaller" not in b
    assert "command" not in b and "freshComparisonReview" not in b
    assert Path(selection["bindings"]["path"]).name == "PUBLIC-BINDINGS.json"
    assert str(selection["bindings"]["path"]) in op["argv"]
    assert b["comparisonSource"]["path"] in op["argv"]
    assert Path(sys.executable).resolve() == Path("/usr/bin/python3").resolve()

    # Public manifest only. Private binding rows are not opened, hashed,
    # or included in rows; no private key is traversed for any pin loop.
    manifest = json.loads(Path(b["actualStaticManifest"]["path"]).read_text(
        encoding="utf-8"))
    assert set(manifest) == {"members"} and len(manifest["members"]) == 477
    for row in manifest["members"]:
        assert set(row) == {"path", "bytes", "sha256"}
    rows = (manifest["members"] + b["actualFiles"] + b["generatedArtifacts"]
            + b["helpers"] + b["python"]
            + [b["actualFreeze"], b["sourceFreeze"], b["sourceCut"],
               b["prefrozenSafe"], b["actualStaticManifest"],
               b["actualPublishedArtifact"], b["actualCaptureStdout"],
               b["actualCaptureStderr"], b["actualPublicationReceipt"],
               b["actualCaptureResult"], b["actualLinkResult"],
               b["captureHelper"], b["comparisonSource"], caller,
               selection["command"], selection["bindings"],
               helper.pin(selection_path),
               selection["fresh_comparison_review"]])
    for key in PRIVATE_BINDING_KEYS:
        assert b[key] not in rows, "private row leaked into Root pin loop"

    phase = D / "actual-one-comparison-01"
    assert selection["phaseDirectory"] == str(phase) and not phase.exists()
    assert not (D / "ONE-ATTEMPT.json").exists()
    pre = helper.static_check(rows)
    assert pre["all_match"]
    phase.mkdir(mode=0o700)
    fsync_dir(D)
    save(D / "ONE-ATTEMPT.json",
         dict(caller=caller, selection=helper.pin(selection_path),
              retry=False))
    save(phase / "ROOT-SELECTION.json", selection)
    save(phase / "PRE-PIN-CHECK.json",
         dict(**pre, static477Checked=True, rootExpectedRead=False,
              rootMembershipRead=False, rootDerivationRead=False,
              rootPrivateFreezeRead=False))
    result = helper.capture(op, phase)
    save(phase / "RESULT.json", result)
    for name in ["COMMAND.json", "stdout.bin", "stderr.bin"]:
        path = phase / name
        if path.exists():
            fsync_file(path)
    fsync_dir(phase)
    try:
        post = helper.static_check(rows)
        save(phase / "POST-PIN-CHECK.json",
             dict(**post, static477Checked=True, rootExpectedRead=False,
                  rootMembershipRead=False, rootDerivationRead=False,
                  rootPrivateFreezeRead=False))
        assert post["all_match"] and result["actual_exit"] == 0
        assert result["controller_failure"] is None
        assert len(result["streams"]) == 2
        assert all(row["full_stream_retained"] is True
                   for row in result["streams"])
        assert (phase / "stderr.bin").stat().st_size == 0
        report = parse_child_report((phase / "stdout.bin").read_bytes())
        assert report["schema"] == SCHEMA
        assert report["status"] == "PASS" and \
            report["allPredicatesTrue"] is True
        assert report["wholeArtifactEqual"] is True
        assert report["rootKeySetEqual"] is True
        assert report["programViewKeySetsEqual"] is True
        assert report["programViewPresent"] is True
        assert report["actualBeforeFirstPrivateRead"] is True
        assert report["childOnlyPrivateExpectedRead"] is True
        assert report["rootPrivateExpectedRead"] is False
        assert report["allPinsUnchangedBeforeAfter"] is True
        assert report["staticManifest477CheckedBeforeAndAfter"] is True
        assert report["sourceFreeze26CheckedBeforeAndAfter"] is True
        assert report["privateFreezeList22CheckedByChildOnlyAfterActual"] \
            is True
        assert report["comparisonSource"] == b["comparisonSource"]
        assert report["bindingsObserved"] == selection["bindings"]
        assert report["actualFreeze"] == b["actualFreeze"]
        # Metadata-dict identity only; the files named by these rows were
        # not opened or hashed by Root.
        assert report["expectedOpaque"] == b["expectedOpaque"]
        assert report["membershipOpaque"] == b["membershipOpaque"]
        assert report["originalExpectedFreeze"] == \
            b["originalExpectedFreeze"]
        assert report["prefrozenSafe"] == b["prefrozenSafe"]
        save(phase / "COMPLETE-METADATA-COMPARISON-REPORT.json", report)
        save(phase / "ROOT-COMPLETE-RESULT.json", dict(
            status="WILDCARD_WHOLE_ARTIFACT_COMPARISON_PASS",
            report=helper.pin(phase / "COMPLETE-METADATA-COMPARISON-REPORT.json"),
            rawResult=helper.pin(phase / "RESULT.json"),
            rawStdout=helper.pin(phase / "stdout.bin"),
            actualFreeze=b["actualFreeze"],
            comparisonSource=b["comparisonSource"],
            rootExpectedRead=False, rootMembershipRead=False,
            rootDerivationRead=False, rootPrivateFreezeRead=False,
            onlySelectedChildExpectedRead=True,
            wholeArtifactEqual=True,
            scope="Frozen185src+manifest186/fullnormalCore35c7 only; "
                  "current187/Host4 excluded. Whole compile/admit/"
                  "bodytyping/publication expectation; no runtime/native/"
                  "ledger/refinement/EARS approval. Owner-declaration/wire "
                  "lineage and source-inspected ABI correlation qualified."))
        print(json.dumps(dict(
            status="WILDCARD_WHOLE_ARTIFACT_COMPARISON_PASS",
            report=helper.pin(phase / "ROOT-COMPLETE-RESULT.json")),
            sort_keys=True))
    except BaseException as error:
        save(phase / "ACCEPTANCE-FAILURE.json", dict(
            status="FAIL_STOP_NO_RETRY", errorType=type(error).__name__,
            rawResult=helper.pin(phase / "RESULT.json"),
            rootExpectedRead=False, rootPrivateFreezeRead=False))
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--selection", required=True)
    main(parser.parse_args().selection)
