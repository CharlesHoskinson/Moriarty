# Complete current META diagnostic stream

All raw blocks including formatting, source and locations. Diagnostic text classification only.

## Diagnostic 1: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxExt)`, or replace it by `symbol(cxExt)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(6,26,6,127)
	6 |	  syntax CXExtFields ::= cxExt(Int, Int, Int, Int, Int, Int, Int, Int,
Int, Int, Int, Int, Int, Int, Int, Int) [klabel(cxExt)]
	  .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 2: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxBudgets)`, or replace it by `symbol(cxBudgets)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(7,24,7,63)
	7 |	  syntax CXBudgets ::= cxBudgets(Int, Int) [klabel(cxBudgets)]
	  .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 3: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxBounds)`, or replace it by `symbol(cxBounds)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(8,23,8,160)
	8 |	  syntax CXBounds ::= cxBounds(Int, Int, Int, Int, Int, Int, Int, Int,
Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int)
[klabel(cxBounds)]
	  .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 4: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxLayoutCaps)`, or replace it by `symbol(cxLayoutCaps)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(9,27,9,82)
	9 |	  syntax CXLayoutCaps ::= cxLayoutCaps(Int, Int, Int, Int)
[klabel(cxLayoutCaps)]
	  .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 5: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxHostLimits)`, or replace it by `symbol(cxHostLimits)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(10,27,10,87)
	10 |	  syntax CXHostLimits ::= cxHostLimits(Int, Int, Int, Int, Int)
[klabel(cxHostLimits)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 6: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxPhysCaps)`, or replace it by `symbol(cxPhysCaps)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(11,25,11,191)
	11 |	  syntax CXPhysCaps ::= cxPhysCaps(Int, Int, Int, Int, Int, Int, Int,
Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int,
Int, Int, Int, Int) [klabel(cxPhysCaps)]
	   .	                       
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 7: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxAbsent)`, or replace it by `symbol(cxAbsent)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(12,20,12,49)
	12 |	  syntax CXExt ::= cxAbsent() [klabel(cxAbsent)]
	   .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 8: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxPresent)`, or replace it by `symbol(cxPresent)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(13,20,13,62)
	13 |	  syntax CXExt ::= cxPresent(CXExtFields) [klabel(cxPresent)]
	   .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 9: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxPayload)`, or replace it by `symbol(cxPayload)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(14,24,14,71)
	14 |	  syntax CXPayload ::= cxPayload(CXExt, CXBudgets) [klabel(cxPayload)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 10: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxInput)`, or replace it by `symbol(cxInput)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(15,22,15,96)
	15 |	  syntax CXInput ::= cxInput(CXPayload, CXBounds, CXLayoutCaps,
CXHostLimits) [klabel(cxInput)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 11: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxStateCaps)`, or replace it by `symbol(cxStateCaps)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(16,26,16,81)
	16 |	  syntax CXStateCaps ::= cxStateCaps(CXPhysCaps, Int, Int)
[klabel(cxStateCaps)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 12: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxStateLimits)`, or replace it by `symbol(cxStateLimits)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(17,28,17,70)
	17 |	  syntax CXStateLimits ::= cxStateLimits(Int) [klabel(cxStateLimits)]
	   .	                           ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 13: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxStateView)`, or replace it by `symbol(cxStateView)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(18,26,18,93)
	18 |	  syntax CXStateView ::= cxStateView(CXStateCaps, Bool, CXStateLimits)
[klabel(cxStateView)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 14: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxObservation)`, or replace it by `symbol(cxObservation)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(19,28,19,120)
	19 |	  syntax CXObservation ::= cxObservation(CTLanes, CXPayload, CXExtFields,
CXStateView, CTLanes) [klabel(cxObservation)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 15: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxNoCases)`, or replace it by `symbol(cxNoCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(20,22,20,53)
	20 |	  syntax CXCases ::= cxNoCases() [klabel(cxNoCases)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 16: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxCase)`, or replace it by `symbol(cxCase)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(21,22,21,71)
	21 |	  syntax CXCases ::= cxCase(String, CXInput, CXCases) [klabel(cxCase)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 17: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxNoObservations)`, or replace it by `symbol(cxNoObservations)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(22,29,22,74)
	22 |	  syntax CXObservations ::= cxNoObservations() [klabel(cxNoObservations)]
	   .	                            ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 18: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxObservationCons)`, or replace it by `symbol(cxObservationCons)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-context-syntax.k)
	Location(23,29,23,105)
	23 |	  syntax CXObservations ::= cxObservationCons(CXObservation,
CXObservations) [klabel(cxObservationCons)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 19: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmDecodedWhole)`, or replace it by `symbol(cmDecodedWhole)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-laws.k)
	Location(6,19,6,101)
	6 |	  syntax Bool ::= cmDecodedWhole(CMMetadata, CMMetadataRead, Int)
[function, klabel(cmDecodedWhole)]
	  .	                 
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 20: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmRoundtrip)`, or replace it by `symbol(cmRoundtrip)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-laws.k)
	Location(8,19,8,74)
	8 |	  syntax Bool ::= cmRoundtrip(CMMetadata) [function, klabel(cmRoundtrip)]
	  .	                  ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 21: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmNoBytes)`, or replace it by `symbol(cmNoBytes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(6,22,6,53)
	6 |	  syntax CMBytes ::= cmNoBytes() [klabel(cmNoBytes)]
	  .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 22: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmByte)`, or replace it by `symbol(cmByte)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(7,22,7,59)
	7 |	  syntax CMBytes ::= cmByte(Int, CMBytes) [klabel(cmByte)]
	  .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 23: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmPair)`, or replace it by `symbol(cmPair)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(8,21,8,62)
	8 |	  syntax CMPair ::= cmPair(CMBytes, CMBytes) [klabel(cmPair)]
	  .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 24: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmNoPair)`, or replace it by `symbol(cmNoPair)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(9,24,9,53)
	9 |	  syntax CMOptPair ::= cmNoPair() [klabel(cmNoPair)]
	  .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 25: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmSomePair)`, or replace it by `symbol(cmSomePair)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(10,24,10,63)
	10 |	  syntax CMOptPair ::= cmSomePair(CMPair) [klabel(cmSomePair)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 26: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmDedicated)`, or replace it by `symbol(cmDedicated)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(11,24,11,59)
	11 |	  syntax CMGrammar ::= cmDedicated() [klabel(cmDedicated)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 27: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmGeneric)`, or replace it by `symbol(cmGeneric)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(12,24,12,55)
	12 |	  syntax CMGrammar ::= cmGeneric() [klabel(cmGeneric)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 28: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFinanceAbsent)`, or replace it by `symbol(cmFinanceAbsent)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(13,24,13,67)
	13 |	  syntax CMFinance ::= cmFinanceAbsent() [klabel(cmFinanceAbsent)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 29: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFinanceReserved)`, or replace it by `symbol(cmFinanceReserved)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(14,24,14,71)
	14 |	  syntax CMFinance ::= cmFinanceReserved() [klabel(cmFinanceReserved)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 30: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmUnselected)`, or replace it by `symbol(cmUnselected)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(15,23,15,60)
	15 |	  syntax CMDigest ::= cmUnselected() [klabel(cmUnselected)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 31: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmSelected)`, or replace it by `symbol(cmSelected)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(16,23,16,71)
	16 |	  syntax CMDigest ::= cmSelected(CMPair, CMBytes) [klabel(cmSelected)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 32: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmIdentity)`, or replace it by `symbol(cmIdentity)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(17,25,17,132)
	17 |	  syntax CMIdentity ::= cmIdentity(Int, CMGrammar, CMFinance, CMPair,
CMDigest, CMDigest, CMOptPair, CMDigest) [klabel(cmIdentity)]
	   .	                       
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 33: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmWidth)`, or replace it by `symbol(cmWidth)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(18,27,18,66)
	18 |	  syntax CMWidthEntry ::= cmWidth(CMBytes, Int) [klabel(cmWidth)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 34: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmNoWidthList)`, or replace it by `symbol(cmNoWidthList)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(19,26,19,65)
	19 |	  syntax CMWidthList ::= cmNoWidthList() [klabel(cmNoWidthList)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 35: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmWidthItem)`, or replace it by `symbol(cmWidthItem)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(20,26,20,86)
	20 |	  syntax CMWidthList ::= cmWidthItem(CMWidthEntry, CMWidthList)
[klabel(cmWidthItem)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 36: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmWidths)`, or replace it by `symbol(cmWidths)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(21,23,21,89)
	21 |	  syntax CMWidths ::= cmWidths(CMWidthList, CMWidthList, CMWidthList)
[klabel(cmWidths)]
	   .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 37: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmNoWidths)`, or replace it by `symbol(cmNoWidths)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(22,26,22,59)
	22 |	  syntax CMOptWidths ::= cmNoWidths() [klabel(cmNoWidths)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 38: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmSomeWidths)`, or replace it by `symbol(cmSomeWidths)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(23,26,23,71)
	23 |	  syntax CMOptWidths ::= cmSomeWidths(CMWidths) [klabel(cmSomeWidths)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 39: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmLayout)`, or replace it by `symbol(cmLayout)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(24,23,24,123)
	24 |	  syntax CMLayout ::= cmLayout(CMPair, CMOptPair, CMOptWidths, CMOptPair,
CXBounds, CXLayoutCaps, Bool) [klabel(cmLayout)]
	   .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 40: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmNegative)`, or replace it by `symbol(cmNegative)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(25,23,25,56)
	25 |	  syntax CMRunInt ::= cmNegative() [klabel(cmNegative)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 41: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmNat)`, or replace it by `symbol(cmNat)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(26,23,26,49)
	26 |	  syntax CMRunInt ::= cmNat(Int) [klabel(cmNat)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 42: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmAbove)`, or replace it by `symbol(cmAbove)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(27,23,27,50)
	27 |	  syntax CMRunInt ::= cmAbove() [klabel(cmAbove)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 43: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmRunId)`, or replace it by `symbol(cmRunId)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(28,22,28,79)
	28 |	  syntax CMRunId ::= cmRunId(CMIdentity, CMRunInt, CMRunInt)
[klabel(cmRunId)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 44: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmMetadata)`, or replace it by `symbol(cmMetadata)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(29,25,29,97)
	29 |	  syntax CMMetadata ::= cmMetadata(CMIdentity, CXBounds, CMLayout,
CMRunId) [klabel(cmMetadata)]
	   .	                       
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 45: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmLimits)`, or replace it by `symbol(cmLimits)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(30,23,30,75)
	30 |	  syntax CMLimits ::= cmLimits(Int, Int, Int, Int, Int)
[klabel(cmLimits)]
	   .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 46: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFIdentity)`, or replace it by `symbol(cmFIdentity)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(31,22,31,57)
	31 |	  syntax CMField ::= cmFIdentity() [klabel(cmFIdentity)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 47: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFRunId)`, or replace it by `symbol(cmFRunId)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(32,22,32,51)
	32 |	  syntax CMField ::= cmFRunId() [klabel(cmFRunId)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 48: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFLayout)`, or replace it by `symbol(cmFLayout)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(33,22,33,53)
	33 |	  syntax CMField ::= cmFLayout() [klabel(cmFLayout)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 49: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFLayoutVersion)`, or replace it by `symbol(cmFLayoutVersion)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(34,22,34,67)
	34 |	  syntax CMField ::= cmFLayoutVersion() [klabel(cmFLayoutVersion)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 50: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFLayoutDigest)`, or replace it by `symbol(cmFLayoutDigest)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(35,22,35,65)
	35 |	  syntax CMField ::= cmFLayoutDigest() [klabel(cmFLayoutDigest)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 51: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFBoundsDigest)`, or replace it by `symbol(cmFBoundsDigest)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(36,22,36,65)
	36 |	  syntax CMField ::= cmFBoundsDigest() [klabel(cmFBoundsDigest)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 52: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFFieldId)`, or replace it by `symbol(cmFFieldId)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(37,22,37,55)
	37 |	  syntax CMField ::= cmFFieldId() [klabel(cmFFieldId)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 53: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFMembershipDigest)`, or replace it by `symbol(cmFMembershipDigest)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(38,22,38,73)
	38 |	  syntax CMField ::= cmFMembershipDigest() [klabel(cmFMembershipDigest)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 54: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFFormat)`, or replace it by `symbol(cmFFormat)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(39,22,39,53)
	39 |	  syntax CMField ::= cmFFormat() [klabel(cmFFormat)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 55: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFBytes)`, or replace it by `symbol(cmFBytes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(40,22,40,51)
	40 |	  syntax CMField ::= cmFBytes() [klabel(cmFBytes)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 56: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFFirst)`, or replace it by `symbol(cmFFirst)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(41,22,41,51)
	41 |	  syntax CMField ::= cmFFirst() [klabel(cmFFirst)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 57: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFSecond)`, or replace it by `symbol(cmFSecond)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(42,22,42,53)
	42 |	  syntax CMField ::= cmFSecond() [klabel(cmFSecond)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 58: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFWidths)`, or replace it by `symbol(cmFWidths)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(43,22,43,53)
	43 |	  syntax CMField ::= cmFWidths() [klabel(cmFWidths)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 59: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFIndexWidths)`, or replace it by `symbol(cmFIndexWidths)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(44,22,44,63)
	44 |	  syntax CMField ::= cmFIndexWidths() [klabel(cmFIndexWidths)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 60: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFCounterWidths)`, or replace it by `symbol(cmFCounterWidths)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(45,22,45,67)
	45 |	  syntax CMField ::= cmFCounterWidths() [klabel(cmFCounterWidths)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 61: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFRecordWidths)`, or replace it by `symbol(cmFRecordWidths)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(46,22,46,65)
	46 |	  syntax CMField ::= cmFRecordWidths() [klabel(cmFRecordWidths)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 62: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFName)`, or replace it by `symbol(cmFName)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(47,22,47,49)
	47 |	  syntax CMField ::= cmFName() [klabel(cmFName)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 63: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFScalarLayoutId)`, or replace it by `symbol(cmFScalarLayoutId)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(48,22,48,69)
	48 |	  syntax CMField ::= cmFScalarLayoutId() [klabel(cmFScalarLayoutId)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 64: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmNoPath)`, or replace it by `symbol(cmNoPath)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(49,21,49,50)
	49 |	  syntax CMPath ::= cmNoPath() [klabel(cmNoPath)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 65: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmField)`, or replace it by `symbol(cmField)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(50,21,50,63)
	50 |	  syntax CMPath ::= cmField(CMField, CMPath) [klabel(cmField)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 66: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmIndex)`, or replace it by `symbol(cmIndex)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(51,21,51,59)
	51 |	  syntax CMPath ::= cmIndex(Int, CMPath) [klabel(cmIndex)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 67: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmText)`, or replace it by `symbol(cmText)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(52,25,52,50)
	52 |	  syntax CMBlobKind ::= cmText() [klabel(cmText)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 68: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmOpaque)`, or replace it by `symbol(cmOpaque)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(53,25,53,54)
	53 |	  syntax CMBlobKind ::= cmOpaque() [klabel(cmOpaque)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 69: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmSpan)`, or replace it by `symbol(cmSpan)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(54,21,54,88)
	54 |	  syntax CMSpan ::= cmSpan(CMBlobKind, CMPath, Int, Int, Int, CMBytes)
[klabel(cmSpan)]
	   .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 70: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmNoSpans)`, or replace it by `symbol(cmNoSpans)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(55,22,55,53)
	55 |	  syntax CMSpans ::= cmNoSpans() [klabel(cmNoSpans)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 71: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmSpanItem)`, or replace it by `symbol(cmSpanItem)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(56,22,56,70)
	56 |	  syntax CMSpans ::= cmSpanItem(CMSpan, CMSpans) [klabel(cmSpanItem)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 72: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReader)`, or replace it by `symbol(cmReader)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(57,23,57,83)
	57 |	  syntax CMReader ::= cmReader(CTLanes, Int, CMSpans, Int, Int)
[klabel(cmReader)]
	   .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 73: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmObservation)`, or replace it by `symbol(cmObservation)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(58,28,58,110)
	58 |	  syntax CMObservation ::= cmObservation(CTLanes, CMMetadata, CMSpans,
Int, Int, Int) [klabel(cmObservation)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 74: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmNoObservations)`, or replace it by `symbol(cmNoObservations)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(59,29,59,74)
	59 |	  syntax CMObservations ::= cmNoObservations() [klabel(cmNoObservations)]
	   .	                            ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 75: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmObservationItem)`, or replace it by `symbol(cmObservationItem)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(60,29,60,105)
	60 |	  syntax CMObservations ::= cmObservationItem(CMObservation,
CMObservations) [klabel(cmObservationItem)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 76: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmNoCases)`, or replace it by `symbol(cmNoCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(61,22,61,53)
	61 |	  syntax CMCases ::= cmNoCases() [klabel(cmNoCases)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 77: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmCase)`, or replace it by `symbol(cmCase)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(62,22,62,84)
	62 |	  syntax CMCases ::= cmCase(String, CMLimits, CMMetadata, CMCases)
[klabel(cmCase)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 78: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmBytesRead)`, or replace it by `symbol(cmBytesRead)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(63,26,63,78)
	63 |	  syntax CMBytesRead ::= cmBytesRead(CMBytes, CMReader)
[klabel(cmBytesRead)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 79: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmPairRead)`, or replace it by `symbol(cmPairRead)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(64,25,64,74)
	64 |	  syntax CMPairRead ::= cmPairRead(CMPair, CMReader) [klabel(cmPairRead)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 80: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmOptPairRead)`, or replace it by `symbol(cmOptPairRead)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(65,28,65,86)
	65 |	  syntax CMOptPairRead ::= cmOptPairRead(CMOptPair, CMReader)
[klabel(cmOptPairRead)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 81: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmDigestRead)`, or replace it by `symbol(cmDigestRead)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(66,27,66,82)
	66 |	  syntax CMDigestRead ::= cmDigestRead(CMDigest, CMReader)
[klabel(cmDigestRead)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 82: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmIdentityRead)`, or replace it by `symbol(cmIdentityRead)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(67,29,67,90)
	67 |	  syntax CMIdentityRead ::= cmIdentityRead(CMIdentity, CMReader)
[klabel(cmIdentityRead)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 83: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmBoundsRead)`, or replace it by `symbol(cmBoundsRead)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(68,27,68,82)
	68 |	  syntax CMBoundsRead ::= cmBoundsRead(CXBounds, CMReader)
[klabel(cmBoundsRead)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 84: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmCapsRead)`, or replace it by `symbol(cmCapsRead)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(69,25,69,80)
	69 |	  syntax CMCapsRead ::= cmCapsRead(CXLayoutCaps, CMReader)
[klabel(cmCapsRead)]
	   .	                       
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 85: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmWidthListRead)`, or replace it by `symbol(cmWidthListRead)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(70,30,70,94)
	70 |	  syntax CMWidthListRead ::= cmWidthListRead(CMWidthList, CMReader)
[klabel(cmWidthListRead)]
	   .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 86: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmWidthsRead)`, or replace it by `symbol(cmWidthsRead)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(71,27,71,82)
	71 |	  syntax CMWidthsRead ::= cmWidthsRead(CMWidths, CMReader)
[klabel(cmWidthsRead)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 87: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmOptWidthsRead)`, or replace it by `symbol(cmOptWidthsRead)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(72,30,72,94)
	72 |	  syntax CMOptWidthsRead ::= cmOptWidthsRead(CMOptWidths, CMReader)
[klabel(cmOptWidthsRead)]
	   .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 88: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmLayoutRead)`, or replace it by `symbol(cmLayoutRead)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(73,27,73,82)
	73 |	  syntax CMLayoutRead ::= cmLayoutRead(CMLayout, CMReader)
[klabel(cmLayoutRead)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 89: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmRunIntRead)`, or replace it by `symbol(cmRunIntRead)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(74,27,74,82)
	74 |	  syntax CMRunIntRead ::= cmRunIntRead(CMRunInt, CMReader)
[klabel(cmRunIntRead)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 90: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmRunIdRead)`, or replace it by `symbol(cmRunIdRead)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(75,26,75,78)
	75 |	  syntax CMRunIdRead ::= cmRunIdRead(CMRunId, CMReader)
[klabel(cmRunIdRead)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 91: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmMetadataRead)`, or replace it by `symbol(cmMetadataRead)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta-syntax.k)
	Location(76,29,76,90)
	76 |	  syntax CMMetadataRead ::= cmMetadataRead(CMMetadata, CMReader)
[klabel(cmMetadataRead)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 92: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmByteCount)`, or replace it by `symbol(cmByteCount)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(9,18,9,70)
	9 |	  syntax Int ::= cmByteCount(CMBytes) [function, klabel(cmByteCount)]
	  .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 93: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmBytesLanes)`, or replace it by `symbol(cmBytesLanes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(12,22,12,76)
	12 |	  syntax CTLanes ::= cmBytesLanes(CMBytes) [function,
klabel(cmBytesLanes)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 94: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmTakeBytes)`, or replace it by `symbol(cmTakeBytes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(15,22,15,79)
	15 |	  syntax CMBytes ::= cmTakeBytes(Int, CTLanes) [function,
klabel(cmTakeBytes)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 95: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmAppendField)`, or replace it by `symbol(cmAppendField)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(18,21,18,85)
	18 |	  syntax CMPath ::= cmAppendField(CMPath, CMField) [function,
klabel(cmAppendField)]
	   .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 96: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmAppendIndex)`, or replace it by `symbol(cmAppendIndex)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(22,21,22,81)
	22 |	  syntax CMPath ::= cmAppendIndex(CMPath, Int) [function,
klabel(cmAppendIndex)]
	   .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 97: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReverseSpans)`, or replace it by `symbol(cmReverseSpans)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(26,22,26,89)
	26 |	  syntax CMSpans ::= cmReverseSpans(CMSpans, CMSpans) [function,
klabel(cmReverseSpans)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 98: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmGrammarTag)`, or replace it by `symbol(cmGrammarTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(29,18,29,74)
	29 |	  syntax Int ::= cmGrammarTag(CMGrammar) [function, klabel(cmGrammarTag)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 99: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmGrammarDecode)`, or replace it by `symbol(cmGrammarDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(30,24,30,80)
	30 |	  syntax CMGrammar ::= cmGrammarDecode(Int) [function,
klabel(cmGrammarDecode)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 100: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFinanceTag)`, or replace it by `symbol(cmFinanceTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(35,18,35,74)
	35 |	  syntax Int ::= cmFinanceTag(CMFinance) [function, klabel(cmFinanceTag)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 101: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmFinanceDecode)`, or replace it by `symbol(cmFinanceDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(36,24,36,80)
	36 |	  syntax CMFinance ::= cmFinanceDecode(Int) [function,
klabel(cmFinanceDecode)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 102: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmEncodeBlob)`, or replace it by `symbol(cmEncodeBlob)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(41,22,41,76)
	41 |	  syntax CTLanes ::= cmEncodeBlob(CMBytes) [function,
klabel(cmEncodeBlob)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 103: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmEncodePair)`, or replace it by `symbol(cmEncodePair)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(43,22,43,75)
	43 |	  syntax CTLanes ::= cmEncodePair(CMPair) [function,
klabel(cmEncodePair)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 104: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmEncodeOptPair)`, or replace it by `symbol(cmEncodeOptPair)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(45,22,45,84)
	45 |	  syntax CTLanes ::= cmEncodeOptPair(CMOptPair) [function,
klabel(cmEncodeOptPair)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 105: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmEncodeDigest)`, or replace it by `symbol(cmEncodeDigest)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(48,22,48,81)
	48 |	  syntax CTLanes ::= cmEncodeDigest(CMDigest) [function,
klabel(cmEncodeDigest)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 106: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmEncodeIdentity)`, or replace it by `symbol(cmEncodeIdentity)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(51,22,51,87)
	51 |	  syntax CTLanes ::= cmEncodeIdentity(CMIdentity) [function,
klabel(cmEncodeIdentity)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 107: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmEncodeBounds)`, or replace it by `symbol(cmEncodeBounds)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(53,22,53,81)
	53 |	  syntax CTLanes ::= cmEncodeBounds(CXBounds) [function,
klabel(cmEncodeBounds)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 108: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmEncodeCaps)`, or replace it by `symbol(cmEncodeCaps)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(55,22,55,81)
	55 |	  syntax CTLanes ::= cmEncodeCaps(CXLayoutCaps) [function,
klabel(cmEncodeCaps)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 109: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmWidthCount)`, or replace it by `symbol(cmWidthCount)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(57,18,57,76)
	57 |	  syntax Int ::= cmWidthCount(CMWidthList) [function,
klabel(cmWidthCount)]
	   .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 110: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmEncodeWidthItems)`, or replace it by `symbol(cmEncodeWidthItems)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(60,22,60,92)
	60 |	  syntax CTLanes ::= cmEncodeWidthItems(CMWidthList) [function,
klabel(cmEncodeWidthItems)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 111: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmEncodeWidthList)`, or replace it by `symbol(cmEncodeWidthList)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(63,22,63,90)
	63 |	  syntax CTLanes ::= cmEncodeWidthList(CMWidthList) [function,
klabel(cmEncodeWidthList)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 112: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmEncodeWidths)`, or replace it by `symbol(cmEncodeWidths)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(65,22,65,84)
	65 |	  syntax CTLanes ::= cmEncodeWidths(CMOptWidths) [function,
klabel(cmEncodeWidths)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 113: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmEncodeLayout)`, or replace it by `symbol(cmEncodeLayout)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(68,22,68,81)
	68 |	  syntax CTLanes ::= cmEncodeLayout(CMLayout) [function,
klabel(cmEncodeLayout)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 114: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmEncodeRunInt)`, or replace it by `symbol(cmEncodeRunInt)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(70,22,70,81)
	70 |	  syntax CTLanes ::= cmEncodeRunInt(CMRunInt) [function,
klabel(cmEncodeRunInt)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 115: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmEncodeRunId)`, or replace it by `symbol(cmEncodeRunId)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(74,22,74,78)
	74 |	  syntax CTLanes ::= cmEncodeRunId(CMRunId) [function,
klabel(cmEncodeRunId)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 116: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmEncodeMetadata)`, or replace it by `symbol(cmEncodeMetadata)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(76,22,76,87)
	76 |	  syntax CTLanes ::= cmEncodeMetadata(CMMetadata) [function,
klabel(cmEncodeMetadata)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 117: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadBlob)`, or replace it by `symbol(cmReadBlob)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(78,26,78,97)
	78 |	  syntax CMBytesRead ::= cmReadBlob(CMPath, CMBlobKind, CMReader)
[function, klabel(cmReadBlob)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 118: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadPair)`, or replace it by `symbol(cmReadPair)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(80,25,80,84)
	80 |	  syntax CMPairRead ::= cmReadPair(CMPath, CMReader) [function,
klabel(cmReadPair)]
	   .	                       
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 119: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmPairFirst)`, or replace it by `symbol(cmPairFirst)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(82,25,82,89)
	82 |	  syntax CMPairRead ::= cmPairFirst(CMPath, CMBytesRead) [function,
klabel(cmPairFirst)]
	   .	                       
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 120: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmPairSecond)`, or replace it by `symbol(cmPairSecond)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(84,25,84,92)
	84 |	  syntax CMPairRead ::= cmPairSecond(CMBytes, CMBytesRead) [function,
klabel(cmPairSecond)]
	   .	                       
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 121: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadOptPair)`, or replace it by `symbol(cmReadOptPair)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(86,28,86,93)
	86 |	  syntax CMOptPairRead ::= cmReadOptPair(CMPath, CMReader) [function,
klabel(cmReadOptPair)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 122: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmSomePairRead)`, or replace it by `symbol(cmSomePairRead)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(89,28,89,89)
	89 |	  syntax CMOptPairRead ::= cmSomePairRead(CMPairRead) [function,
klabel(cmSomePairRead)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 123: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadDigest)`, or replace it by `symbol(cmReadDigest)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(91,27,91,90)
	91 |	  syntax CMDigestRead ::= cmReadDigest(CMPath, CMReader) [function,
klabel(cmReadDigest)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 124: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmDigestFormat)`, or replace it by `symbol(cmDigestFormat)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(94,27,94,96)
	94 |	  syntax CMDigestRead ::= cmDigestFormat(CMPath, CMPairRead) [function,
klabel(cmDigestFormat)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 125: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmDigestBytes)`, or replace it by `symbol(cmDigestBytes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(96,27,96,95)
	96 |	  syntax CMDigestRead ::= cmDigestBytes(CMPair, CMBytesRead) [function,
klabel(cmDigestBytes)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 126: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadIdentity)`, or replace it by `symbol(cmReadIdentity)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(98,29,98,96)
	98 |	  syntax CMIdentityRead ::= cmReadIdentity(CMPath, CMReader) [function,
klabel(cmReadIdentity)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 127: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmIdentityStep0)`, or replace it by `symbol(cmIdentityStep0)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(100,29,100,127)
	100 |	  syntax CMIdentityRead ::= cmIdentityStep0(Int, CMGrammar, CMFinance,
CMPath, CMPairRead) [function, klabel(cmIdentityStep0)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 128: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmIdentityStep1)`, or replace it by `symbol(cmIdentityStep1)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(102,29,102,137)
	102 |	  syntax CMIdentityRead ::= cmIdentityStep1(Int, CMGrammar, CMFinance,
CMPair, CMPath, CMDigestRead) [function, klabel(cmIdentityStep1)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 129: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmIdentityStep2)`, or replace it by `symbol(cmIdentityStep2)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(104,29,104,147)
	104 |	  syntax CMIdentityRead ::= cmIdentityStep2(Int, CMGrammar, CMFinance,
CMPair, CMDigest, CMPath, CMDigestRead) [function, klabel(cmIdentityStep2)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 130: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmIdentityStep3)`, or replace it by `symbol(cmIdentityStep3)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(106,29,106,158)
	106 |	  syntax CMIdentityRead ::= cmIdentityStep3(Int, CMGrammar, CMFinance,
CMPair, CMDigest, CMDigest, CMPath, CMOptPairRead) [function,
klabel(cmIdentityStep3)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 131: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmIdentityStep4)`, or replace it by `symbol(cmIdentityStep4)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(108,29,108,168)
	108 |	  syntax CMIdentityRead ::= cmIdentityStep4(Int, CMGrammar, CMFinance,
CMPair, CMDigest, CMDigest, CMOptPair, CMPath, CMDigestRead) [function,
klabel(cmIdentityStep4)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 132: unused-variable

[Warning] Compiler: Variable 'P' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(109,51,109,52)
	109 |	  rule cmIdentityStep4(A, G0, F0, V0, V1, V2, V3, P, cmDigestRead(V4,
R)) => cmIdentityRead(cmIdentity(A, G0, F0, V0, V1, V2, V3, V4), R)
	    .	                                                  ^


## Diagnostic 133: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadBounds)`, or replace it by `symbol(cmReadBounds)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(110,27,110,90)
	110 |	  syntax CMBoundsRead ::= cmReadBounds(CMPath, CMReader) [function,
klabel(cmReadBounds)]
	    .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 134: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadCaps)`, or replace it by `symbol(cmReadCaps)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(112,25,112,84)
	112 |	  syntax CMCapsRead ::= cmReadCaps(CMPath, CMReader) [function,
klabel(cmReadCaps)]
	    .	                       
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 135: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadWidthList)`, or replace it by `symbol(cmReadWidthList)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(114,30,114,99)
	114 |	  syntax CMWidthListRead ::= cmReadWidthList(CMPath, CMReader)
[function, klabel(cmReadWidthList)]
	    .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 136: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadWidthItems)`, or replace it by `symbol(cmReadWidthItems)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(116,30,116,111)
	116 |	  syntax CMWidthListRead ::= cmReadWidthItems(Int, Int, CMPath,
CMReader) [function, klabel(cmReadWidthItems)]
	    .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 137: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadWidthName)`, or replace it by `symbol(cmReadWidthName)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(119,30,119,112)
	119 |	  syntax CMWidthListRead ::= cmReadWidthName(Int, Int, CMPath,
CMBytesRead) [function, klabel(cmReadWidthName)]
	    .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 138: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadWidthTail)`, or replace it by `symbol(cmReadWidthTail)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(121,30,121,112)
	121 |	  syntax CMWidthListRead ::= cmReadWidthTail(CMWidthEntry,
CMWidthListRead) [function, klabel(cmReadWidthTail)]
	    .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 139: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadWidths)`, or replace it by `symbol(cmReadWidths)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(123,27,123,90)
	123 |	  syntax CMWidthsRead ::= cmReadWidths(CMPath, CMReader) [function,
klabel(cmReadWidths)]
	    .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 140: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmWidthsStep0)`, or replace it by `symbol(cmWidthsStep0)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(125,27,125,99)
	125 |	  syntax CMWidthsRead ::= cmWidthsStep0(CMPath, CMWidthListRead)
[function, klabel(cmWidthsStep0)]
	    .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 141: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmWidthsStep1)`, or replace it by `symbol(cmWidthsStep1)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(127,27,127,112)
	127 |	  syntax CMWidthsRead ::= cmWidthsStep1(CMWidthList, CMPath,
CMWidthListRead) [function, klabel(cmWidthsStep1)]
	    .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 142: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmWidthsStep2)`, or replace it by `symbol(cmWidthsStep2)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(129,27,129,125)
	129 |	  syntax CMWidthsRead ::= cmWidthsStep2(CMWidthList, CMWidthList,
CMPath, CMWidthListRead) [function, klabel(cmWidthsStep2)]
	    .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 143: unused-variable

[Warning] Compiler: Variable 'P' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(130,30,130,31)
	130 |	  rule cmWidthsStep2(V0, V1, P, cmWidthListRead(V2, R)) =>
cmWidthsRead(cmWidths(V0, V1, V2), R)
	    .	                             ^


## Diagnostic 144: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadOptWidths)`, or replace it by `symbol(cmReadOptWidths)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(131,30,131,99)
	131 |	  syntax CMOptWidthsRead ::= cmReadOptWidths(CMPath, CMReader)
[function, klabel(cmReadOptWidths)]
	    .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 145: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmSomeWidthsRead)`, or replace it by `symbol(cmSomeWidthsRead)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(134,30,134,97)
	134 |	  syntax CMOptWidthsRead ::= cmSomeWidthsRead(CMWidthsRead) [function,
klabel(cmSomeWidthsRead)]
	    .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 146: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadLayout)`, or replace it by `symbol(cmReadLayout)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(136,27,136,90)
	136 |	  syntax CMLayoutRead ::= cmReadLayout(CMPath, CMReader) [function,
klabel(cmReadLayout)]
	    .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 147: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmLayoutStep0)`, or replace it by `symbol(cmLayoutStep0)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(138,27,138,94)
	138 |	  syntax CMLayoutRead ::= cmLayoutStep0(CMPath, CMPairRead) [function,
klabel(cmLayoutStep0)]
	    .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 148: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmLayoutStep1)`, or replace it by `symbol(cmLayoutStep1)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(140,27,140,105)
	140 |	  syntax CMLayoutRead ::= cmLayoutStep1(CMPair, CMPath, CMOptPairRead)
[function, klabel(cmLayoutStep1)]
	    .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 149: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmLayoutStep2)`, or replace it by `symbol(cmLayoutStep2)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(142,27,142,118)
	142 |	  syntax CMLayoutRead ::= cmLayoutStep2(CMPair, CMOptPair, CMPath,
CMOptWidthsRead) [function, klabel(cmLayoutStep2)]
	    .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 150: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmLayoutStep3)`, or replace it by `symbol(cmLayoutStep3)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(144,27,144,129)
	144 |	  syntax CMLayoutRead ::= cmLayoutStep3(CMPair, CMOptPair, CMOptWidths,
CMPath, CMOptPairRead) [function, klabel(cmLayoutStep3)]
	    .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 151: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmLayoutStep4)`, or replace it by `symbol(cmLayoutStep4)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(146,27,146,139)
	146 |	  syntax CMLayoutRead ::= cmLayoutStep4(CMPair, CMOptPair, CMOptWidths,
CMOptPair, CMPath, CMBoundsRead) [function, klabel(cmLayoutStep4)]
	    .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 152: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmLayoutStep5)`, or replace it by `symbol(cmLayoutStep5)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(148,27,148,147)
	148 |	  syntax CMLayoutRead ::= cmLayoutStep5(CMPair, CMOptPair, CMOptWidths,
CMOptPair, CXBounds, CMPath, CMCapsRead) [function, klabel(cmLayoutStep5)]
	    .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 153: unused-variable

[Warning] Compiler: Variable 'P' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(149,42,149,43)
	149 |	  rule cmLayoutStep5(V0, V1, V2, V3, V4, P, cmCapsRead(V5,
cmReader(ctLane(X, L), C, S, B, W))) => cmLayoutRead(cmLayout(V0, V1, V2, V3,
V4, V5, ctBoolDecode(X)), cmReader(L, C +Int 1, S, B, W))
	    .	                                         ^


## Diagnostic 154: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadRunInt)`, or replace it by `symbol(cmReadRunInt)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(150,27,150,90)
	150 |	  syntax CMRunIntRead ::= cmReadRunInt(CMPath, CMReader) [function,
klabel(cmReadRunInt)]
	    .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 155: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadRunId)`, or replace it by `symbol(cmReadRunId)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(154,26,154,87)
	154 |	  syntax CMRunIdRead ::= cmReadRunId(CMPath, CMReader) [function,
klabel(cmReadRunId)]
	    .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 156: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmRunIdStep0)`, or replace it by `symbol(cmRunIdStep0)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(156,26,156,95)
	156 |	  syntax CMRunIdRead ::= cmRunIdStep0(CMPath, CMIdentityRead) [function,
klabel(cmRunIdStep0)]
	    .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 157: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmRunIdStep1)`, or replace it by `symbol(cmRunIdStep1)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(158,26,158,105)
	158 |	  syntax CMRunIdRead ::= cmRunIdStep1(CMIdentity, CMPath, CMRunIntRead)
[function, klabel(cmRunIdStep1)]
	    .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 158: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmRunIdStep2)`, or replace it by `symbol(cmRunIdStep2)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(160,26,160,115)
	160 |	  syntax CMRunIdRead ::= cmRunIdStep2(CMIdentity, CMRunInt, CMPath,
CMRunIntRead) [function, klabel(cmRunIdStep2)]
	    .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 159: unused-variable

[Warning] Compiler: Variable 'P' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(161,29,161,30)
	161 |	  rule cmRunIdStep2(V0, V1, P, cmRunIntRead(V2, R)) =>
cmRunIdRead(cmRunId(V0, V1, V2), R)
	    .	                            ^


## Diagnostic 160: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmReadMetadata)`, or replace it by `symbol(cmReadMetadata)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(162,29,162,96)
	162 |	  syntax CMMetadataRead ::= cmReadMetadata(CMPath, CMReader) [function,
klabel(cmReadMetadata)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 161: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmMetadataStep0)`, or replace it by `symbol(cmMetadataStep0)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(164,29,164,104)
	164 |	  syntax CMMetadataRead ::= cmMetadataStep0(CMPath, CMIdentityRead)
[function, klabel(cmMetadataStep0)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 162: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmMetadataStep1)`, or replace it by `symbol(cmMetadataStep1)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(166,29,166,114)
	166 |	  syntax CMMetadataRead ::= cmMetadataStep1(CMIdentity, CMPath,
CMBoundsRead) [function, klabel(cmMetadataStep1)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 163: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmMetadataStep2)`, or replace it by `symbol(cmMetadataStep2)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(168,29,168,124)
	168 |	  syntax CMMetadataRead ::= cmMetadataStep2(CMIdentity, CXBounds,
CMPath, CMLayoutRead) [function, klabel(cmMetadataStep2)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 164: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmMetadataStep3)`, or replace it by `symbol(cmMetadataStep3)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(170,29,170,133)
	170 |	  syntax CMMetadataRead ::= cmMetadataStep3(CMIdentity, CXBounds,
CMLayout, CMPath, CMRunIdRead) [function, klabel(cmMetadataStep3)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 165: unused-variable

[Warning] Compiler: Variable 'P' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(171,36,171,37)
	171 |	  rule cmMetadataStep3(V0, V1, V2, P, cmRunIdRead(V3, R)) =>
cmMetadataRead(cmMetadata(V0, V1, V2, V3), R)
	    .	                                   ^


## Diagnostic 166: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmDecodeMetadata)`, or replace it by `symbol(cmDecodeMetadata)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(172,29,172,91)
	172 |	  syntax CMMetadataRead ::= cmDecodeMetadata(CTLanes) [function,
klabel(cmDecodeMetadata)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 167: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmObserve)`, or replace it by `symbol(cmObserve)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(174,28,174,89)
	174 |	  syntax CMObservation ::= cmObserve(CMLimits, CMMetadata) [function,
klabel(cmObserve)]
	    .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 168: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmObserveEncoded)`, or replace it by `symbol(cmObserveEncoded)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(176,28,176,90)
	176 |	  syntax CMObservation ::= cmObserveEncoded(CTLanes) [function,
klabel(cmObserveEncoded)]
	    .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 169: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmObserveDecoded)`, or replace it by `symbol(cmObserveDecoded)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(178,28,178,106)
	178 |	  syntax CMObservation ::= cmObserveDecoded(CTLanes, CMMetadataRead)
[function, klabel(cmObserveDecoded)]
	    .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 170: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cmObserveAll)`, or replace it by `symbol(cmObserveAll)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-positive-meta.k)
	Location(180,29,180,83)
	180 |	  syntax CMObservations ::= cmObserveAll(CMCases) [function,
klabel(cmObserveAll)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 171: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctJoin)`, or replace it by `symbol(ctJoin)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(10,22,10,73)
	10 |	  syntax CTLanes ::= ctJoin(CTLanes, CTLanes) [function, klabel(ctJoin)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 172: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSize)`, or replace it by `symbol(ctSize)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(13,18,13,60)
	13 |	  syntax Int ::= ctSize(CTLanes) [function, klabel(ctSize)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 173: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctTake)`, or replace it by `symbol(ctTake)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(16,22,16,69)
	16 |	  syntax CTLanes ::= ctTake(Int, CTLanes) [function, klabel(ctTake)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 174: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDrop)`, or replace it by `symbol(ctDrop)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(17,22,17,69)
	17 |	  syntax CTLanes ::= ctDrop(Int, CTLanes) [function, klabel(ctDrop)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 175: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAt)`, or replace it by `symbol(ctAt)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(18,18,18,61)
	18 |	  syntax Int ::= ctAt(Int, CTLanes) [function, klabel(ctAt)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 176: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvTag)`, or replace it by `symbol(ctEnvTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(25,18,25,62)
	25 |	  syntax Int ::= ctEnvTag(CTEnv) [function, klabel(ctEnvTag)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 177: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvIndex)`, or replace it by `symbol(ctEnvIndex)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(26,18,26,66)
	26 |	  syntax Int ::= ctEnvIndex(CTEnv) [function, klabel(ctEnvIndex)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 178: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFunctionTag)`, or replace it by `symbol(ctFunctionTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(27,18,27,77)
	27 |	  syntax Int ::= ctFunctionTag(CTFunction) [function,
klabel(ctFunctionTag)]
	   .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 179: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFunctionIndex)`, or replace it by `symbol(ctFunctionIndex)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(28,18,28,81)
	28 |	  syntax Int ::= ctFunctionIndex(CTFunction) [function,
klabel(ctFunctionIndex)]
	   .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 180: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRefTag)`, or replace it by `symbol(ctRefTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(29,18,29,62)
	29 |	  syntax Int ::= ctRefTag(CTRef) [function, klabel(ctRefTag)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 181: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRefIndex)`, or replace it by `symbol(ctRefIndex)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(30,18,30,66)
	30 |	  syntax Int ::= ctRefIndex(CTRef) [function, klabel(ctRefIndex)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 182: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBool)`, or replace it by `symbol(ctBool)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(31,18,31,57)
	31 |	  syntax Int ::= ctBool(Bool) [function, klabel(ctBool)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 183: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvDecode)`, or replace it by `symbol(ctEnvDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(46,20,46,73)
	46 |	  syntax CTEnv ::= ctEnvDecode(Int, Int) [function, klabel(ctEnvDecode)]
	   .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 184: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFunctionDecode)`, or replace it by `symbol(ctFunctionDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(47,25,47,88)
	47 |	  syntax CTFunction ::= ctFunctionDecode(Int, Int) [function,
klabel(ctFunctionDecode)]
	   .	                       
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 185: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRefDecode)`, or replace it by `symbol(ctRefDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(48,20,48,73)
	48 |	  syntax CTRef ::= ctRefDecode(Int, Int) [function, klabel(ctRefDecode)]
	   .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 186: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBoolDecode)`, or replace it by `symbol(ctBoolDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(55,19,55,69)
	55 |	  syntax Bool ::= ctBoolDecode(Int) [function, klabel(ctBoolDecode)]
	   .	                  ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 187: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBinary)`, or replace it by `symbol(ctBinary)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(58,18,58,65)
	58 |	  syntax Int ::= ctBinary(CTBinary) [function, klabel(ctBinary)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 188: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBinaryDecode)`, or replace it by `symbol(ctBinaryDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(59,23,59,77)
	59 |	  syntax CTBinary ::= ctBinaryDecode(Int) [function,
klabel(ctBinaryDecode)]
	   .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 189: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctUnary)`, or replace it by `symbol(ctUnary)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(74,18,74,62)
	74 |	  syntax Int ::= ctUnary(CTUnary) [function, klabel(ctUnary)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 190: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctUnaryDecode)`, or replace it by `symbol(ctUnaryDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(75,22,75,74)
	75 |	  syntax CTUnary ::= ctUnaryDecode(Int) [function, klabel(ctUnaryDecode)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 191: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctExhaust)`, or replace it by `symbol(ctExhaust)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(80,18,80,68)
	80 |	  syntax Int ::= ctExhaust(CTExhaust) [function, klabel(ctExhaust)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 192: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctExhaustDecode)`, or replace it by `symbol(ctExhaustDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(81,24,81,80)
	81 |	  syntax CTExhaust ::= ctExhaustDecode(Int) [function,
klabel(ctExhaustDecode)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 193: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSliceStart)`, or replace it by `symbol(ctSliceStart)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(96,18,96,72)
	96 |	  syntax Int ::= ctSliceStart(CTSlice) [function, klabel(ctSliceStart)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 194: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSliceLen)`, or replace it by `symbol(ctSliceLen)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(97,18,97,68)
	97 |	  syntax Int ::= ctSliceLen(CTSlice) [function, klabel(ctSliceLen)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 195: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEncodeFrame)`, or replace it by `symbol(ctEncodeFrame)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(100,22,100,78)
	100 |	  syntax CTLanes ::= ctEncodeFrame(CTFrame) [function,
klabel(ctEncodeFrame)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 196: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDecodeFrame)`, or replace it by `symbol(ctDecodeFrame)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(101,22,101,78)
	101 |	  syntax CTFrame ::= ctDecodeFrame(CTLanes) [function,
klabel(ctDecodeFrame)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 197: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBindingLanes)`, or replace it by `symbol(ctBindingLanes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(122,22,122,82)
	122 |	  syntax CTLanes ::= ctBindingLanes(CTBinding) [function,
klabel(ctBindingLanes)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 198: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMatchingLanes)`, or replace it by `symbol(ctMatchingLanes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(123,22,123,85)
	123 |	  syntax CTLanes ::= ctMatchingLanes(CTMatching) [function,
klabel(ctMatchingLanes)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 199: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctPrimitiveLanes)`, or replace it by `symbol(ctPrimitiveLanes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(124,22,124,88)
	124 |	  syntax CTLanes ::= ctPrimitiveLanes(CTPrimitive) [function,
klabel(ctPrimitiveLanes)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 200: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctOutcomeLanes)`, or replace it by `symbol(ctOutcomeLanes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(125,22,125,82)
	125 |	  syntax CTLanes ::= ctOutcomeLanes(CTOutcome) [function,
klabel(ctOutcomeLanes)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 201: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBindingDecode)`, or replace it by `symbol(ctBindingDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(136,24,136,90)
	136 |	  syntax CTBinding ::= ctBindingDecode(Int, Int, Int) [function,
klabel(ctBindingDecode)]
	    .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 202: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMatchingDecode)`, or replace it by `symbol(ctMatchingDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(137,25,137,93)
	137 |	  syntax CTMatching ::= ctMatchingDecode(Int, Int, Int) [function,
klabel(ctMatchingDecode)]
	    .	                       
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 203: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctPrimitiveDecode)`, or replace it by `symbol(ctPrimitiveDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(138,26,138,96)
	138 |	  syntax CTPrimitive ::= ctPrimitiveDecode(Int, Int, Int) [function,
klabel(ctPrimitiveDecode)]
	    .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 204: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctOutcomeDecode)`, or replace it by `symbol(ctOutcomeDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(139,24,139,90)
	139 |	  syntax CTOutcome ::= ctOutcomeDecode(Int, Int, Int) [function,
klabel(ctOutcomeDecode)]
	    .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 205: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEncodeControl)`, or replace it by `symbol(ctEncodeControl)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(150,22,150,84)
	150 |	  syntax CTLanes ::= ctEncodeControl(CTControl) [function,
klabel(ctEncodeControl)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 206: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDecodeControl)`, or replace it by `symbol(ctDecodeControl)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(151,24,151,84)
	151 |	  syntax CTControl ::= ctDecodeControl(CTLanes) [function,
klabel(ctDecodeControl)]
	    .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 207: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFrameCount)`, or replace it by `symbol(ctFrameCount)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(174,18,174,73)
	174 |	  syntax Int ::= ctFrameCount(CTFrames) [function, klabel(ctFrameCount)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 208: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEncodeFrames)`, or replace it by `symbol(ctEncodeFrames)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(177,22,177,81)
	177 |	  syntax CTLanes ::= ctEncodeFrames(CTFrames) [function,
klabel(ctEncodeFrames)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 209: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDecodeFrames)`, or replace it by `symbol(ctDecodeFrames)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(180,23,180,86)
	180 |	  syntax CTFrames ::= ctDecodeFrames(Int, CTLanes) [function,
klabel(ctDecodeFrames)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 210: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAlloc0)`, or replace it by `symbol(ctAlloc0)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(183,18,183,64)
	183 |	  syntax Int ::= ctAlloc0(CTAlloc) [function, klabel(ctAlloc0)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 211: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAlloc1)`, or replace it by `symbol(ctAlloc1)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(185,18,185,64)
	185 |	  syntax Int ::= ctAlloc1(CTAlloc) [function, klabel(ctAlloc1)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 212: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAlloc2)`, or replace it by `symbol(ctAlloc2)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(187,18,187,64)
	187 |	  syntax Int ::= ctAlloc2(CTAlloc) [function, klabel(ctAlloc2)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 213: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctActive0)`, or replace it by `symbol(ctActive0)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(189,18,189,67)
	189 |	  syntax Int ::= ctActive0(CTActive) [function, klabel(ctActive0)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 214: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctActive1)`, or replace it by `symbol(ctActive1)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(191,18,191,67)
	191 |	  syntax Int ::= ctActive1(CTActive) [function, klabel(ctActive1)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 215: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctActive2)`, or replace it by `symbol(ctActive2)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(193,18,193,67)
	193 |	  syntax Int ::= ctActive2(CTActive) [function, klabel(ctActive2)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 216: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctActive3)`, or replace it by `symbol(ctActive3)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(195,18,195,67)
	195 |	  syntax Int ::= ctActive3(CTActive) [function, klabel(ctActive3)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 217: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEncodeRoot)`, or replace it by `symbol(ctEncodeRoot)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(197,22,197,75)
	197 |	  syntax CTLanes ::= ctEncodeRoot(CTRoot) [function,
klabel(ctEncodeRoot)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 218: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDecodeRoot)`, or replace it by `symbol(ctDecodeRoot)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(198,21,198,75)
	198 |	  syntax CTRoot ::= ctDecodeRoot(CTLanes) [function,
klabel(ctDecodeRoot)]
	    .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 219: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctObserveRoot)`, or replace it by `symbol(ctObserveRoot)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(201,23,201,86)
	201 |	  syntax CTAnswer ::= ctObserveRoot(String, CTRoot) [function,
klabel(ctObserveRoot)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 220: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctObserveEncoded)`, or replace it by `symbol(ctObserveEncoded)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(202,23,202,101)
	202 |	  syntax CTAnswer ::= ctObserveEncoded(String, CTRoot, CTLanes)
[function, klabel(ctObserveEncoded)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 221: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctObserveAll)`, or replace it by `symbol(ctObserveAll)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-codec.k)
	Location(205,24,205,80)
	205 |	  syntax CTAnswers ::= ctObserveAll(CTQueries) [function,
klabel(ctObserveAll)]
	    .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 222: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctConst)`, or replace it by `symbol(ctConst)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(7,20,7,50)
	7 |	  syntax CTRef ::= ctConst(Int) [klabel(ctConst)]
	  .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 223: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctData)`, or replace it by `symbol(ctData)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(8,22,8,50)
	8 |	                   | ctData(Int) [klabel(ctData)]
	  .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 224: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvNone)`, or replace it by `symbol(ctEnvNone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(9,20,9,51)
	9 |	  syntax CTEnv ::= ctEnvNone() [klabel(ctEnvNone)]
	  .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 225: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvSome)`, or replace it by `symbol(ctEnvSome)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(10,22,10,56)
	10 |	                   | ctEnvSome(Int) [klabel(ctEnvSome)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 226: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFunctionNone)`, or replace it by `symbol(ctFunctionNone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(11,25,11,66)
	11 |	  syntax CTFunction ::= ctFunctionNone() [klabel(ctFunctionNone)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 227: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFunctionSome)`, or replace it by `symbol(ctFunctionSome)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(12,27,12,71)
	12 |	                        | ctFunctionSome(Int) [klabel(ctFunctionSome)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 228: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSlice)`, or replace it by `symbol(ctSlice)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(13,22,13,57)
	13 |	  syntax CTSlice ::= ctSlice(Int, Int) [klabel(ctSlice)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 229: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAdd)`, or replace it by `symbol(ctAdd)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(14,23,14,46)
	14 |	  syntax CTBinary ::= ctAdd() [klabel(ctAdd)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 230: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSub)`, or replace it by `symbol(ctSub)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(15,25,15,48)
	15 |	                      | ctSub() [klabel(ctSub)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 231: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMul)`, or replace it by `symbol(ctMul)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(16,25,16,48)
	16 |	                      | ctMul() [klabel(ctMul)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 232: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEq)`, or replace it by `symbol(ctEq)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(17,25,17,46)
	17 |	                      | ctEq() [klabel(ctEq)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~


## Diagnostic 233: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLt)`, or replace it by `symbol(ctLt)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(18,25,18,46)
	18 |	                      | ctLt() [klabel(ctLt)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~


## Diagnostic 234: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctCons)`, or replace it by `symbol(ctCons)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(19,25,19,50)
	19 |	                      | ctCons() [klabel(ctCons)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 235: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBranch)`, or replace it by `symbol(ctBranch)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(20,25,20,54)
	20 |	                      | ctBranch() [klabel(ctBranch)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 236: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLeaf)`, or replace it by `symbol(ctLeaf)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(21,22,21,47)
	21 |	  syntax CTUnary ::= ctLeaf() [klabel(ctLeaf)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 237: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNot)`, or replace it by `symbol(ctNot)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(22,24,22,47)
	22 |	                     | ctNot() [klabel(ctNot)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 238: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLetF)`, or replace it by `symbol(ctLetF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(23,22,23,67)
	23 |	  syntax CTFrame ::= ctLetF(Int, Int, CTEnv, Int) [klabel(ctLetF)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 239: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLeftF)`, or replace it by `symbol(ctLeftF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(24,24,24,76)
	24 |	                     | ctLeftF(CTBinary, Int, CTEnv, Int)
[klabel(ctLeftF)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 240: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRightF)`, or replace it by `symbol(ctRightF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(25,24,25,73)
	25 |	                     | ctRightF(CTBinary, CTRef, Int) [klabel(ctRightF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 241: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctUnaryF)`, or replace it by `symbol(ctUnaryF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(26,24,26,65)
	26 |	                     | ctUnaryF(CTUnary, Int) [klabel(ctUnaryF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 242: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctIfF)`, or replace it by `symbol(ctIfF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(27,24,27,67)
	27 |	                     | ctIfF(Int, Int, CTEnv, Int) [klabel(ctIfF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 243: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMatchF)`, or replace it by `symbol(ctMatchF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(28,24,28,72)
	28 |	                     | ctMatchF(CTSlice, CTEnv, Int) [klabel(ctMatchF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 244: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctArgsF)`, or replace it by `symbol(ctArgsF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(29,24,29,84)
	29 |	                     | ctArgsF(Int, CTSlice, CTSlice, CTEnv, Int)
[klabel(ctArgsF)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 245: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctReturnF)`, or replace it by `symbol(ctReturnF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(30,24,30,70)
	30 |	                     | ctReturnF(Int, CTEnv, Int) [klabel(ctReturnF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 246: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctScopeF)`, or replace it by `symbol(ctScopeF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(31,24,31,63)
	31 |	                     | ctScopeF(CTEnv, Int) [klabel(ctScopeF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 247: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctConstructorFieldsF)`, or replace it by
`symbol(ctConstructorFieldsF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(32,24,32,131)
	32 |	                     | ctConstructorFieldsF(Int, Int, Int, Int, Bool,
CTSlice, CTSlice, CTEnv, Int) [klabel(ctConstructorFieldsF)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 248: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNoFrames)`, or replace it by `symbol(ctNoFrames)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(33,23,33,56)
	33 |	  syntax CTFrames ::= ctNoFrames() [klabel(ctNoFrames)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 249: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFrame)`, or replace it by `symbol(ctFrame)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(34,25,34,69)
	34 |	                      | ctFrame(CTFrame, CTFrames) [klabel(ctFrame)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 250: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBindingBad)`, or replace it by `symbol(ctBindingBad)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(35,24,35,61)
	35 |	  syntax CTBinding ::= ctBindingBad() [klabel(ctBindingBad)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 251: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBindingOk)`, or replace it by `symbol(ctBindingOk)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(36,26,36,66)
	36 |	                       | ctBindingOk(CTEnv) [klabel(ctBindingOk)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 252: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNoMatch)`, or replace it by `symbol(ctNoMatch)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(37,25,37,56)
	37 |	  syntax CTMatching ::= ctNoMatch() [klabel(ctNoMatch)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 253: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMatched)`, or replace it by `symbol(ctMatched)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(38,27,38,63)
	38 |	                        | ctMatched(CTEnv) [klabel(ctMatched)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 254: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctPrimValue)`, or replace it by `symbol(ctPrimValue)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(39,26,39,66)
	39 |	  syntax CTPrimitive ::= ctPrimValue(CTRef) [klabel(ctPrimValue)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 255: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctPrimError)`, or replace it by `symbol(ctPrimError)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(40,28,40,66)
	40 |	                         | ctPrimError(Int) [klabel(ctPrimError)]
	   .	                           ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 256: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEval)`, or replace it by `symbol(ctEval)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(41,24,41,52)
	41 |	  syntax CTControl ::= ctEval(Int) [klabel(ctEval)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 257: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctReturn)`, or replace it by `symbol(ctReturn)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(42,26,42,60)
	42 |	                       | ctReturn(CTRef) [klabel(ctReturn)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 258: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctScheduleNext)`, or replace it by `symbol(ctScheduleNext)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(43,26,43,86)
	43 |	                       | ctScheduleNext(CTFrame, Int, CTEnv)
[klabel(ctScheduleNext)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 259: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctInvoke)`, or replace it by `symbol(ctInvoke)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(44,26,44,67)
	44 |	                       | ctInvoke(Int, CTSlice) [klabel(ctInvoke)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 260: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnter)`, or replace it by `symbol(ctEnter)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(45,26,45,72)
	45 |	                       | ctEnter(CTFunction, CTSlice) [klabel(ctEnter)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 261: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBound)`, or replace it by `symbol(ctBound)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(46,26,46,72)
	46 |	                       | ctBound(CTBinding, Int, Int) [klabel(ctBound)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 262: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctCases)`, or replace it by `symbol(ctCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(47,26,47,74)
	47 |	                       | ctCases(CTRef, CTSlice, CTEnv) [klabel(ctCases)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 263: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctCaseResult)`, or replace it by `symbol(ctCaseResult)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(48,26,48,101)
	48 |	                       | ctCaseResult(CTMatching, CTRef, Int, CTSlice,
CTEnv) [klabel(ctCaseResult)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 264: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctPrimResult)`, or replace it by `symbol(ctPrimResult)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(49,26,49,74)
	49 |	                       | ctPrimResult(CTPrimitive) [klabel(ctPrimResult)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 265: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctError)`, or replace it by `symbol(ctError)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(50,26,50,56)
	50 |	                       | ctError(Int) [klabel(ctError)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 266: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMaterialize)`, or replace it by `symbol(ctMaterialize)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(51,26,51,82)
	51 |	                       | ctMaterialize(Int, Int, CTSlice)
[klabel(ctMaterialize)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 267: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFuel)`, or replace it by `symbol(ctFuel)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(52,24,52,49)
	52 |	  syntax CTExhaust ::= ctFuel() [klabel(ctFuel)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 268: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDataNodes)`, or replace it by `symbol(ctDataNodes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(53,26,53,61)
	53 |	                       | ctDataNodes() [klabel(ctDataNodes)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 269: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDataFields)`, or replace it by `symbol(ctDataFields)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(54,26,54,63)
	54 |	                       | ctDataFields() [klabel(ctDataFields)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 270: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvironmentCells)`, or replace it by `symbol(ctEnvironmentCells)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(55,26,55,75)
	55 |	                       | ctEnvironmentCells()
[klabel(ctEnvironmentCells)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 271: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctHelperTasks)`, or replace it by `symbol(ctHelperTasks)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(56,26,56,65)
	56 |	                       | ctHelperTasks() [klabel(ctHelperTasks)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 272: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctHelperWork)`, or replace it by `symbol(ctHelperWork)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(57,26,57,63)
	57 |	                       | ctHelperWork() [klabel(ctHelperWork)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 273: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSerializationBytes)`, or replace it by
`symbol(ctSerializationBytes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(58,26,58,79)
	58 |	                       | ctSerializationBytes()
[klabel(ctSerializationBytes)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 274: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRunning)`, or replace it by `symbol(ctRunning)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(59,24,59,55)
	59 |	  syntax CTOutcome ::= ctRunning() [klabel(ctRunning)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 275: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctHalted)`, or replace it by `symbol(ctHalted)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(60,26,60,60)
	60 |	                       | ctHalted(CTRef) [klabel(ctHalted)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 276: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRejected)`, or replace it by `symbol(ctRejected)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(61,26,61,62)
	61 |	                       | ctRejected(Int) [klabel(ctRejected)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 277: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctExhausted)`, or replace it by `symbol(ctExhausted)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(62,26,62,70)
	62 |	                       | ctExhausted(CTExhaust) [klabel(ctExhausted)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 278: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAlloc)`, or replace it by `symbol(ctAlloc)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(63,22,63,62)
	63 |	  syntax CTAlloc ::= ctAlloc(Int, Int, Int) [klabel(ctAlloc)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 279: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctActive)`, or replace it by `symbol(ctActive)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(64,23,64,70)
	64 |	  syntax CTActive ::= ctActive(Int, Int, Int, Int) [klabel(ctActive)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 280: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRoot)`, or replace it by `symbol(ctRoot)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(65,21,65,166)
	65 |	  syntax CTRoot ::= ctRoot(CTControl, Int, CTEnv, Int, CTOutcome, Int,
Int, Int, Int, Int, Int, CTAlloc, CTActive, CTActive, CTAlloc, Int, CTFrames)
[klabel(ctRoot)]
	   .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 281: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNoLanes)`, or replace it by `symbol(ctNoLanes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(66,22,66,53)
	66 |	  syntax CTLanes ::= ctNoLanes() [klabel(ctNoLanes)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 282: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLane)`, or replace it by `symbol(ctLane)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(67,24,67,61)
	67 |	                     | ctLane(Int, CTLanes) [klabel(ctLane)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 283: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAnswer)`, or replace it by `symbol(ctAnswer)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(68,23,68,83)
	68 |	  syntax CTAnswer ::= ctAnswer(String, CTRoot, CTLanes, CTRoot)
[klabel(ctAnswer)]
	   .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 284: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNoQueries)`, or replace it by `symbol(ctNoQueries)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(69,24,69,59)
	69 |	  syntax CTQueries ::= ctNoQueries() [klabel(ctNoQueries)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 285: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctQuery)`, or replace it by `symbol(ctQuery)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(70,26,70,78)
	70 |	                       | ctQuery(String, CTRoot, CTQueries)
[klabel(ctQuery)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 286: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNoAnswers)`, or replace it by `symbol(ctNoAnswers)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(71,24,71,59)
	71 |	  syntax CTAnswers ::= ctNoAnswers() [klabel(ctNoAnswers)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## Diagnostic 287: deprecated-klabel

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAnswerRow)`, or replace it by `symbol(ctAnswerRow)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-META-20261020/source/c6-typed-root-syntax.k)
	Location(72,26,72,80)
	72 |	                       | ctAnswerRow(CTAnswer, CTAnswers)
[klabel(ctAnswerRow)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

