# Fresh focused Opus review: phase01 isolated import correction and real missing API premises

Nonauthor source/ordinaryoperation delta review only; not sourceauthoring, execution or securitygrant. Fresh claude-opus-5-5/high requested, noTools/shell/providers/edits. Prior full26body review is included verbatim. This is not a repeated unchanged6K audit; all model/adapter/rawhelper/linker logic and phases02–10 retain their exact previous pins/argv. Only phase01 argv changes from-I script launch to the exact prior Opus-proposed -c explicit ADAPTER/sys.argv/import render_input/main; its products nowinitial.ng/query.term. Fullold/newproof+inverse provided, original plan preserved. Earlier phase10protectedexpectedpathbinding stays unchanged.

Missing factual premises are now complete: actualF03kast_command/exec_command/kprint_command+globals; full import-time AST; full existing passiveREAD-IMPORT-PINS metadata with scopequalifications; actualadapter/rawhelper/PATH/compiled listings; actualmissing16KorePATHsymlinktargetpins; exactrawhelperlabelheadmatchesinactualdefinition. No hostlibrarypayloads, expected/derivation/exposure/source-retention/freeze bodies were opened; onlySAFE metadata. Do not read protectedoracle before actualALLfreeze. The historicalmanifestisnot an assertionall514rowsarecurrentorselected. Dynamiclibs/Pythonstdlib remain disclosedtrustedlocalpremises, no wholehostattestation.

Importantactualroute: directfrozenargv is passed toF03.launch; legacy UIcommandbuilders are referenceAPIforms, not called. Their UI module/sort/input globals are intentionally replaced by correctcompiledLt/module/NGTape/newinput. Oldexec log-entries is not used; kprint falsefalse is exactbuilderform. F03launch imports/globals/callclosureAST matchcurrentf1bc source; oldmain195-case/ledger/preflight route is unselected. Its launch returnrecord uses returncode/timed_out/outcome/remaining/containment_breach and does not itself interpret success. Rootmustcheckthe actualreturned fields, not an outerexit or wrongcapturekey.

Questions:
1. Is corrected phase01 source/argv executable under-I-B-S with explicit known3-fileADAPTER, with exactoutputproducts, preserving source/input/queryinverse and no model/expected change? Requestconcretefix or abstain if insufficient.
2. Does currentactualAPI/label/directory/importpremise delivery close the previous missingpremises for02–10 under the unchangedexistinglimits and explicitRootpre/postchecks? Distinguish any remaininghostpremise from a newsourcebug. Priorsemantics/sourceverdict and untouchedphases maybereused only at exactpinnedcut; no blanketapprovalfromhashes. Assess all10eligibilityafter01correction, or name specificremainingcondition. No arbitraryhostPIDabsence condition.
3. Retain more-than-boundary-only goal: actualtwoKwindows plus rawcarry/fulltypedjoin and postfreezeindependentwholetracecomparison. NoAddresult/terminalstutter/A/Bcharge/work/recursiveproofvalidity/productionendpoint/hostequivalence, nativeorEARSadoption.
4. Report exactreadcoverage/dissent/protectedoracleabstention. Conciseresponseaim, no reportbyteapprovalgate. No execution has occurred and no authority is claimed by preparation.


===== COMPLETE BODY 1 Full prior source and10operation opinion, dissent/conditions intact =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/actual-fresh-opus-01/FINAL-RESPONSE.txt
BYTES 11391 SHA256 6f14797e55a25c2bc9ace6b276937818c687daae87dd6cc9d75be914fe7d2da4
# Independent source and operation review: two linked uncharged Add windows

**Reviewer:** claude-opus-5-5. I cannot observe my own effort setting, so I can't confirm "HIGH". I used no tools, shell, subcalls, edits or execution. This was one read of inline bodies 1–26. I did not request, read or derive any protected oracle body.

## Headline

The plan as written is **CHANGES_REQUIRED** because of one blocking defect in phase 01. Phases 02–10 are sound under Root obligations, but none of them can run until 01 succeeds.

**Blocking defect: phase 01 will fail to import its own adapter.** It runs `/usr/bin/python3 -I -B -S …/adapter/render_input.py`.
- Python documents that in isolated mode (`-I`, which implies `-P`), `sys.path` does not contain the script's directory.
- `render_input.py` does `import nominal_trace_codec` and `from complete_k_wire import CompleteKWire`.
- So it will exit with `ModuleNotFoundError` before writing anything. This fails closed, but nothing downstream ever runs.
- Phases 05 and 08 avoid this because they call `sys.path.insert(0, ADAPTER)` first. Phase 09's linker imports only the standard library, so it is unaffected.

**Minimum fix:** no helper source change is needed. Replace phase 01's argv with a `-c` body in the same style as 05 and 08:
- `sys.path.insert(0, ADAPTER)`
- `sys.argv = ['render_input.py', '--input', …, '--api', …, '--syntax', …, '--output-dir', …]`
- `import render_input; render_input.main()`

That new argv needs re-review. Also add `initial.ng` and `query.term` to phase 01's products; the list is currently `[]`.

---

## 1. SOURCE — composition is correct; no missing callable

**K semantics** (rules identified only; I did not author a predicted trace):
- **Window 1:** `ngObserve(S0,1)` checks that `ngEval` is non-terminal. `ngStep` fires the `ngEvaluate(ngFoundExpr(ngAdd(…)))` rule. That pushes `ngAddLeft` with source IDs, occurrence and saved Map, and appends exactly one `ngAddStarted`. The budget is then 0, so the result is `ngTape(S0,[S1],S1)`.
- **Window 2:** from S1, the Literal rule for the left operand fires. It appends one `ngLiteralEvaluated` and leaves frames and Map unchanged.
- **Scope consequence:** with a whole-case budget of 2, the trace never reaches `ngAddRightRequested`, `ngAdded`, `ngFinished` or any terminal. The terminal-stutter contract is carried as metadata only; it is not exercised.
- **`--depth 1` is not the step counter.** Every rule has a `[function]` head, so kore-exec evaluates during simplification. The one-step windows come from the `ngObserve` Int bound, not from kore-exec depth.

**Parsing and decoding**
- The `configure` regex correctly registers every base and Lt constructor from the combined syntax. Comments are stripped, and the `\n\s*syntax` and `\nendmodule` lookaheads hold for both modules.
- The `CompleteKWire.__init__` arity checks pass against the public API. I checked ngLtCompared, ngLtSortFailed, ngLtPrimitiveReturned/Failed, ngLetBound, ngBranchSelected, ngAddStarted, ngAddLeft and ngEval, all with exact field counts.
- Unevaluated function residue fails closed. `ngObserve` is not registered, so the parser rejects it. `ngInitial` is registered as NGState but is rejected by the `_args(…, 'ngState')` check.
- The glue reads `parser.API` and `parser.REG` after `configure()`, so it gets fresh globals rather than stale imports. The keyword arguments to `bind_shared_wire` and the `resume_query(bytes, int) → (bytes, dict)` call match their definitions.

**Preservation**
- **Map:** decoded to a sorted list with all rows kept.
- **Frames:** kept top-first.
- **Events:** kept in cumulative append order, and the one-event continuity check is enforced.
- **Program:** the same object is checked in every state.
- **Source IDs and occurrences:** taken from the input table, with no remapping.

**Raw carry is genuine.** `resume_query` byte-slices the third argument of the raw `ngTape` from `result.kore` and only checks that it is a 5-ary `ngState`; it does not regenerate anything from JSON.
- The link is verified independently. Phase 09 checks that the whole typed decoded first final equals the decoded second initial.
- One premise is unverified: the label constants `OBSERVE`, `TAPE` and `STATE` have not been checked against this cohort's `definition.kore`. A mismatch would fail closed.

**Schema**
- Each window has the six root fields and five-field states.
- `observerCuts` is `list(range(2)) == [0,1]`, as `checked_window` requires. The joined wire is `[0,1,2]`.
- Integer vs Bool is preserved by the `type()`-strict `same` function and by `json_domain`.

**Missing callables**
- Not part of this plan's glue: none.
- Not supplied: the Root orchestration driver (directory creation, pins, fsync, stop logic, building `record`), and the F03 bodies `kast_command`, `exec_command` and `kprint_command`. I therefore can't confirm that the argv forms match F03's. I judged them on their own.

**Minor finding:** the linker's receipt says `observerCuts_derived_from_actual: True`, but `[0,1,2]` is a constant. It is only valid because each window is checked to have exactly 2 states.

## 2. Per-operation verdicts

| Phase | Verdict | Notes |
|---|---|---|
| 01 render | **CHANGES_REQUIRED** | `-I` import failure (above); products list incomplete. |
| 02 kast | ELIGIBLE (conditional) | Module and sort are correct: `mainModule`/`mainSyntaxModule` are 32 bytes, which is exactly `SHERLOCK-NOMINAL-LT-OBSERVATIONS`, so the cached scanner should be reused. PATH includes `kore-38afc81/bin`, which is absent from the supplied closure manifest; its pin relies on the unsupplied READ-IMPORT-PINS. Kast could write into the kompiled directory (lock, cache or scanner regeneration), so Root needs a full before/after directory listing, not just the 15 pinned files. |
| 03 reduce | ELIGIBLE (conditional) | This cohort has only a compile-only receipt, so kast → kore-exec → kprint has never run on it. The bare-`ngTape` output form is inherited from a predecessor run. `--smt none` means z3 is unused. |
| 04 print | ELIGIBLE (conditional) | The `false false` argv form cannot be compared to F03 because `kprint_command` was not supplied. The parser fails closed on unexpected print format. |
| 05 decode+carry | ELIGIBLE | Glue is correct. The first wire is written before the carry; a partial failure is handled by the stop rule. |
| 06 reduce | ELIGIBLE | Consumes the generated `second.query.kore`. |
| 07 print | ELIGIBLE | Same as 04. |
| 08 decode | ELIGIBLE | Takes metadata from the budget-2 input, consistent with the linker. |
| 09 link | ELIGIBLE | Imports only stdlib, so `-I` is safe. Uses the budget-2 source, matching the `link()` requirement. |
| 10 compare | ELIGIBLE, only after the barrier | Typed whole equality; mismatches fail closed. `json.loads` accepts duplicate keys (last wins), which only matters for expected-side integrity, already covered by the SHA. |

**Shadowing hazard (phases 05, 08 and fixed 01).** `sys.path.insert(0, ADAPTER)` puts the adapter directory ahead of the standard library for later imports such as `dataclasses`, its dependencies, and `typing`. Also, `-B` only stops Python writing `.pyc` files; it still reads them. An existing `__pycache__` (especially an unchecked-hash `.pyc`) in the adapter directory or the raw-helper directory would be executed.

**Minimum Root obligations**
1. **Fresh directories.** `actual-attempt-01` must be absent or empty. Create each stage directory plus its `home/` and `tmp/` with mode 0700 immediately before the phase, with no pre-existing `stdout`/`stderr`.
2. **Pre- and post-checks around every phase.** Cover:
   - the 6 K sources, combined syntax, API, and all 3 inputs (including first-window `bf5d9…`);
   - the adapter files and the full adapter directory listing (no extra modules, no `__pycache__`), plus the raw helper and its directory;
   - the linker;
   - the F03 full source SHA (`f1bcf0a0…`), plus an AST check that the launch closure equals the corresponding source lines;
   - the 15 compiled files and the full kompiled directory listing;
   - the tool entries, JAR membership, PATH directory listings and python3.
3. **Per-phase checks after each run.**
   - Process outcome: `returncode == 0`, `timed_out False`, `outcome 'exited'`, `remaining == []`, `containment_breach False`.
   - Stage directory: exact expected file set; pin bytes and SHA of every stage file including stderr; fsync files and directories.
   - The launch closure does not check the exit code itself, so Root must.
4. **Carry cross-check.** The carry receipt's `actual_tape_sha256` must equal the pinned 03 `result.kore`, and `next_query_sha256` must equal the pinned `second.query.kore`.
5. **Barrier.** After 09, durably freeze all actual artifacts and the record. Only then:
   - re-verify SAFE-HANDOFF (`eb0e…`);
   - verify the freeze metadata (`3b42…`) and EXPECTED-JOINED (5006 bytes, `7b78…`);
   - run 10;
   - re-hash both the expected and the linked actual after 10, to close the TOCTOU gap.

   Before the barrier, never open, stat or hash the protected files.
6. **Stop rule.** Stop on any nonzero exit, pin drift, leftover child process or unexpected file. No retry, no cap change, no recompile.

## 3. SCOPE

What a pass would establish:
- K function-semantics reductions for two one-step prefixes, joined at one byte-carried, whole-typed-equal boundary.
- Equality of the complete 3-position trace with a prefrozen independent expectation.

That is more than boundary-only identity, which is all that phase 09 alone checks. It is still only a two-step prefix of Add (Add start plus the left literal). It does not establish:
- the Add result, or behaviour at the terminal boundary;
- a charged A/B clock, Kwork or fuel;
- recursive-child, public-state, proof or circuit equivalence;
- production Rust endpoint correspondence (still pending its owner);
- any native, security or adoption grant.

The zero-based `observerCuts` value comes from the existing decoder and consumer (`list(range(len))`, a fixed `[0,1]` check, and constant `[0,1,2]`). It is representation only, not an adjustment to the expectation. If the oracle used a different base, phase 10 fails closed rather than passing falsely.

## 4. COVERAGE

**Reviewed in full:** bodies 1–26.
- Body 2's change is confined to the phase-10 EXPECTED operand and metadata. The original plan was not supplied, so I trust the diff context for the rest.
- Byte arithmetic for body 23 holds: 5090 + 1 + 1070 = 6161.
- I accepted the SHA identities as stated; I did not inspect or verify them myself.

**Not available (premises, not approved):**
- `definition.kore` and compiled binary contents.
- READ-IMPORT-PINS, the full IMPORT-TIME-AST, and the full F03 source; I relied on the projection's no-side-effect claims.
- The adapter and raw-helper directory listings.
- Shared-library closures for kprint and kore-exec, and the python3 stdlib.
- Actual kast, kore-exec and kprint behaviour on this cohort.
- The Root driver.

**Abstained:** all protected oracle bodies, and any judgement of how adequate the oracle's semantics are.

**Dissent preserved:** I do not approve on identity, hash or count evidence. Phase 01 as specified is non-executable. Every other verdict above depends on the listed Root obligations and on re-review of a corrected phase 01 argv.
===== END BODY 1 =====

===== COMPLETE BODY 2 Complete prior oracle-bound tenoperation plan =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/PROPOSED-TEN-PHASES.ORACLE-BOUND.json
BYTES 29314 SHA256 6e12ba39d8b1a2d9b2078380443675a14a5b287db3420cfd02f7f971a65a2442
{
  "status": "ORACLE_PRIVATELY_PREFROZEN_SAFE_METADATA_ONLY_SOURCE_TEN_OPERATION_REVIEW_PENDING",
  "phases": [
    {
      "id": "01-render-first-window",
      "kind": "data-render",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "f4a1c45fbdc8a2eef169625da351c929"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/usr/bin/python3",
        "-I",
        "-B",
        "-S",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter/render_input.py",
        "--input",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/inputs/ADD-ENTRY.first-window.input.json",
        "--api",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/PUBLIC-LT-API.json",
        "--syntax",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/COMPLETE-LT-CONSTRUCTOR-SYNTAX.k.txt",
        "--output-dir",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window"
      ],
      "expected_exit_code": 0,
      "products": [],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "02-kast-first-window",
      "kind": "kast",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/02-kast-first-window",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/02-kast-first-window/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/02-kast-first-window/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "7a77fe0de855e05024f96c2cde84a11a",
        "PATH": "/nix/store/5p6kb76qjrdwjvjmm6l7l2683k41ay1r-kore-38afc81/bin:/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/bin:/nix/store/z1fkfc5ca0rra7m5zrh8i92mx18w9i00-flex-2.6.4/bin:/nix/store/ih51sgk8g57fnkbd5r82ddi8k5vln8cl-z3-4.13.4/bin"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/bin/java",
        "-Xms64m",
        "-Xmx512m",
        "-Xss32m",
        "-XX:ActiveProcessorCount=2",
        "-XX:+ExitOnOutOfMemoryError",
        "-XX:-UsePerfData",
        "-XX:+DisableAttachMechanism",
        "-XX:ErrorFile=/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/02-kast-first-window/hs_err_pid%p.log",
        "-Dfile.encoding=UTF-8",
        "-Djava.awt.headless=true",
        "-Djava.io.tmpdir=/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/02-kast-first-window/tmp",
        "-Duser.home=/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/02-kast-first-window/home",
        "-ea",
        "-cp",
        "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/*",
        "org.kframework.main.Main",
        "-kast",
        "--definition",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled",
        "--module",
        "SHERLOCK-NOMINAL-LT-OBSERVATIONS",
        "--sort",
        "NGTape",
        "--input",
        "program",
        "--output",
        "kore",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/query.term"
      ],
      "expected_exit_code": 0,
      "products": [],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "03-reduce-first-window",
      "kind": "reduce",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/03-reduce-first-window",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/03-reduce-first-window/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/03-reduce-first-window/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "1d2ca6ba0a470bfd78dcdbf224a69a3d",
        "PATH": "/nix/store/ih51sgk8g57fnkbd5r82ddi8k5vln8cl-z3-4.13.4/bin"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/.kore-exec-wrapped",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/definition.kore",
        "--module",
        "SHERLOCK-NOMINAL-LT-OBSERVATIONS",
        "--pattern",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/02-kast-first-window/stdout",
        "--output",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/03-reduce-first-window/result.kore",
        "--depth",
        "1",
        "--smt",
        "none",
        "--log-format",
        "standard",
        "--disable-log-timestamps"
      ],
      "expected_exit_code": 0,
      "products": [
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/03-reduce-first-window/result.kore"
      ],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "04-print-first-window",
      "kind": "print",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/04-print-first-window",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/04-print-first-window/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/04-print-first-window/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "c8ed57eb9ca965c8de5fca16ebe22f4d"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/nix/store/p7hjh21dj4bc1s6kfcdwk45knp5n4cc0-llvm-backend-0.1.140/bin/kprint",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/03-reduce-first-window/result.kore",
        "false",
        "false"
      ],
      "expected_exit_code": 0,
      "products": [],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "05-decode-first-and-carry",
      "kind": "data-decode-raw-carry",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "d756f97a24695d6086a35fd6c699cbee"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/usr/bin/python3",
        "-I",
        "-B",
        "-S",
        "-c",
        "RAW_HELPER='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/actual-c6-schedule-first-arm-continuation-20261019/source/kore_continuation.py'\nRAW_FIRST='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/03-reduce-first-window/result.kore'\nNEXT_QUERY='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/second.query.kore'\nCARRY_RECEIPT='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/carry-receipt.json'\nADAPTER='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter'\nAPI='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/PUBLIC-LT-API.json'\nSYNTAX='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/COMPLETE-LT-CONSTRUCTOR-SYNTAX.k.txt'\nINPUT='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/safe-inputs/ADD-ENTRY.input.json'\nPRINTED='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/04-print-first-window/stdout'\nOUTPUT='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/first.complete-wire.json'\nimport sys,json,importlib.util\nfrom pathlib import Path\nsys.path.insert(0,ADAPTER)\nimport nominal_trace_codec as parser\nfrom complete_k_wire import CompleteKWire\nparser.configure(Path(API),Path(SYNTAX))\nspec=json.loads(Path(INPUT).read_bytes())\ntape=parser.parse_printed(Path(PRINTED).read_text())\nadapter=CompleteKWire(parser.API,parser.REG)\nstates=adapter.complete_states(tape)\nwire=adapter.bind_shared_wire(states,case_id=spec['case_id'],profile=spec['profile'],terminal_step_contract=spec['terminalStepContract'],observer_cuts=list(range(len(states))))\nraw=(json.dumps(wire,indent=2,ensure_ascii=False,allow_nan=False)+'\\n').encode()\nwith Path(OUTPUT).open('xb') as f:f.write(raw)\n\ns=importlib.util.spec_from_file_location('existing_kore_continuation',RAW_HELPER)\nm=importlib.util.module_from_spec(s);s.loader.exec_module(m)\nquery,receipt=m.resume_query(Path(RAW_FIRST).read_bytes(),1)\nwith Path(NEXT_QUERY).open('xb') as f:f.write(query)\nwith Path(CARRY_RECEIPT).open('x') as f:json.dump(receipt,f,indent=2);f.write('\\n')\n"
      ],
      "expected_exit_code": 0,
      "products": [
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/first.complete-wire.json",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/second.query.kore",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/carry-receipt.json"
      ],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "06-reduce-second-window",
      "kind": "reduce",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/06-reduce-second-window",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/06-reduce-second-window/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/06-reduce-second-window/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "855b7b7cb0fada585d1c067dd45ba809",
        "PATH": "/nix/store/ih51sgk8g57fnkbd5r82ddi8k5vln8cl-z3-4.13.4/bin"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/.kore-exec-wrapped",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/definition.kore",
        "--module",
        "SHERLOCK-NOMINAL-LT-OBSERVATIONS",
        "--pattern",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/second.query.kore",
        "--output",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/06-reduce-second-window/result.kore",
        "--depth",
        "1",
        "--smt",
        "none",
        "--log-format",
        "standard",
        "--disable-log-timestamps"
      ],
      "expected_exit_code": 0,
      "products": [
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/06-reduce-second-window/result.kore"
      ],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "07-print-second-window",
      "kind": "print",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/07-print-second-window",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/07-print-second-window/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/07-print-second-window/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "bb8dab9bd32ace9f100fdc7503d349f8"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/nix/store/p7hjh21dj4bc1s6kfcdwk45knp5n4cc0-llvm-backend-0.1.140/bin/kprint",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/06-reduce-second-window/result.kore",
        "false",
        "false"
      ],
      "expected_exit_code": 0,
      "products": [],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "08-decode-second-window",
      "kind": "data-decode",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/08-decode-second-window",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/08-decode-second-window/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/08-decode-second-window/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "5a87f7e2c70a801634b563137d9fcebd"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/usr/bin/python3",
        "-I",
        "-B",
        "-S",
        "-c",
        "ADAPTER='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter'\nAPI='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/PUBLIC-LT-API.json'\nSYNTAX='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/COMPLETE-LT-CONSTRUCTOR-SYNTAX.k.txt'\nINPUT='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/safe-inputs/ADD-ENTRY.input.json'\nPRINTED='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/07-print-second-window/stdout'\nOUTPUT='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/08-decode-second-window/second.complete-wire.json'\nimport sys,json,importlib.util\nfrom pathlib import Path\nsys.path.insert(0,ADAPTER)\nimport nominal_trace_codec as parser\nfrom complete_k_wire import CompleteKWire\nparser.configure(Path(API),Path(SYNTAX))\nspec=json.loads(Path(INPUT).read_bytes())\ntape=parser.parse_printed(Path(PRINTED).read_text())\nadapter=CompleteKWire(parser.API,parser.REG)\nstates=adapter.complete_states(tape)\nwire=adapter.bind_shared_wire(states,case_id=spec['case_id'],profile=spec['profile'],terminal_step_contract=spec['terminalStepContract'],observer_cuts=list(range(len(states))))\nraw=(json.dumps(wire,indent=2,ensure_ascii=False,allow_nan=False)+'\\n').encode()\nwith Path(OUTPUT).open('xb') as f:f.write(raw)\n"
      ],
      "expected_exit_code": 0,
      "products": [
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/08-decode-second-window/second.complete-wire.json"
      ],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "09-link-whole-boundaries",
      "kind": "existing-data-link",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/09-link-whole-boundaries",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/09-link-whole-boundaries/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/09-link-whole-boundaries/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "b5c825740238aeebaba6aa2935d6c907"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/usr/bin/python3",
        "-I",
        "-B",
        "-S",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/source/link_two_k_windows.py",
        "--first",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/first.complete-wire.json",
        "--second",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/08-decode-second-window/second.complete-wire.json",
        "--input",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/safe-inputs/ADD-ENTRY.input.json",
        "--output-dir",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/09-link-whole-boundaries"
      ],
      "expected_exit_code": 0,
      "products": [
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/09-link-whole-boundaries/linked.complete-wire.json",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/09-link-whole-boundaries/link-readback.json"
      ],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "10-independent-whole-trace-comparison",
      "kind": "independent-comparison-after-durable-freeze",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/10-independent-whole-trace-comparison",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/10-independent-whole-trace-comparison/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/10-independent-whole-trace-comparison/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "7be4c9040d73a438e7ec7267bc43943f"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/usr/bin/python3",
        "-I",
        "-B",
        "-S",
        "-c",
        "ACTUAL='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/09-link-whole-boundaries/linked.complete-wire.json'\nEXPECTED='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTED-JOINED.json'\nimport json\nfrom pathlib import Path\ndef same(a,b):\n if type(a) is not type(b):return False\n if type(a) is dict:return a.keys()==b.keys() and all(same(a[k],b[k]) for k in a)\n if type(a) is list:return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))\n return a==b\na=json.loads(Path(ACTUAL).read_bytes());e=json.loads(Path(EXPECTED).read_bytes())\nif not same(a,e):raise SystemExit('FAIL_COMPLETE_INDEPENDENT_K_TRACE_EQUALITY')\nprint('PASS_COMPLETE_INDEPENDENT_K_TRACE_EQUALITY')\n"
      ],
      "expected_exit_code": 0,
      "products": [],
      "status": "PROSPECTIVE_UNSELECTED"
    }
  ],
  "callback": {
    "fullsource": {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/UIREQ021-F03-K-caller-materialized-review/source/k_engine_attempt_f03_01.py",
      "bytes": 73962,
      "sha256": "f1bcf0a0d21b4a7aaedd2f2aae1a1e9e5b62219271eb41b3f71ed97d5a0bc24d"
    },
    "full_callable_closure": {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-product-model-v2-review-operation-20261018/context/EXISTING-LAUNCH-CALLABLE-CLOSURE.py.txt",
      "bytes": 4228,
      "sha256": "996aadee88cf0ac4688925789676dcc9e407cbd3d7c15b912f25204b10861242"
    },
    "full_import_projection": {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-product-model-v2-review-operation-20261018/context/IMPORT-TIME-AST-REVIEW-PROJECTION.json",
      "bytes": 55525,
      "sha256": "9f9e9188139ea024008f204dd9f45d8c4eb119ba2837127fce83ea67b860d4b1"
    },
    "entry": "F03.launch(record,phase.argv,dict(phase.environment),phase.cwd,phase.environment[SHERLOCK_K_ATTEMPT_TOKEN],536870912)",
    "oldmain_ledger_retry_unselected": true
  },
  "limits": {
    "wall_seconds": 30,
    "sweep_seconds": 3,
    "rlimit_core": 0,
    "rlimit_fsize": 536870912,
    "umask": "0o077",
    "JVM_heap_MiB": 512,
    "JVM_stack_MiB": 32,
    "JVM_processors": 2,
    "no_aggregate_CPU_RSS_disk_cap": true,
    "cleanup": "unchanged F03 processgroup+token sweep"
  },
  "new_compile_operations": 0,
  "Kast_operations": 1,
  "K_reduce_windows": 2,
  "new_observation_steps": 2,
  "model_or_guard_changes": false,
  "old_12_source_21_operation_prefix_replayed": false,
  "raw_carry": "Existing resume_query extracts all five actual NGState arguments verbatim from first raw tape into second query, not JSON/expected reconstruction.",
  "independent_barrier": "Different independent author privately prefroze expectations per SAFE-HANDOFF. No protected freeze/expected/derivation/exposure/source-retention body is read before all actual data are frozen. Root durably freezes first+second complete tapes/rawprints/querycarry/joinedwire/sourcecompiledtoolpins/receipts/fsync before ONLY phase10 may read EXPECTED-JOINED; no evaluator/K rerun for comparison.",
  "new_inline_code_scope": "Only ordinary glue invoking existing decoder/raw-carry APIs and full typed equality; AST-parsed only. Fresh nonauthor source/operation audit includes these exact -c bodies and unchanged helper closure.",
  "future_expected": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTED-JOINED.json",
    "bytes": 5006,
    "sha256": "7b78225b8a699046d7c4164f6b242522a78dfc2f4b7fa8b87b21f6cb99053b53",
    "status": "AUTHOR_PRIVATELY_FROZEN_BODY_UNREAD_BY_ROOT_PREPARER_REVIEWER",
    "freeze_metadata": {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTATION-FREEZE.json",
      "bytes": 5251,
      "sha256": "3b42b93bd9903379f39c6760ade58f9ae5647dd87cf7f423570c1d26bfc461c4"
    },
    "safe_handoff": {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/SAFE-HANDOFF.json",
      "bytes": 3099,
      "sha256": "eb0ef778c7bf770840b9001ec3a95ab633f2a3419698fcfb0d748884fc59910c"
    },
    "verify_before_phase10_only": "After all actual windows/rawcarry/joinedwire/receipts are durably frozen, Root verifies exact protected expected bytes/SHA through existing metadata checks before comparison; never prehash/read it before barrier."
  },
  "meaning": "K-only uncharged complete-state link+independent whole-trace equality. NOT primary chargedA/Bsteps, recursiveproofvalidity/circuit endpoints, fuel/work or host/K equivalence.",
  "next_production_mapping": "Owner must supply actual Rust two-step/recursive-child public-state endpoint API and full source closure before any cross-layer relation assertion.",
  "stop": "Any failed phase/pin/containment/output/schema stops remaining UNRUN; no retry/capchange/recompile/sourcefitting; retain available raw.",
  "safe_oracle_limitations": [
    "No actual runtime evidence, implementation-validity/security verdict or native admission",
    "observerCuts uses zero-based local positions; packet omits explicit numeric-base/locality declaration",
    "Two safe bodies lack separate original pins; exact embedded retained bytes pinned"
  ],
  "Root_selection_still_required": true
}

===== END BODY 2 =====

===== COMPLETE BODY 3 Exact old/new phase01 inverseproof =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/revision02-phase01-import-and-actual-premises/PHASE01-OLD-NEW-INVERSE.json
BYTES 10360 SHA256 5f4f28e34f9a361987a1a79dfeace5d9950b3186c61c35063916bc543af7c4aa
{
  "old_plan": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/PROPOSED-TEN-PHASES.ORACLE-BOUND.json",
    "bytes": 29314,
    "sha256": "6e12ba39d8b1a2d9b2078380443675a14a5b287db3420cfd02f7f971a65a2442"
  },
  "new_plan": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/revision02-phase01-import-and-actual-premises/PROPOSED-TEN-PHASES.PHASE01-CORRECTED.json",
    "bytes": 29765,
    "sha256": "6a56fca09acd55949ed87d62eeb9f3a5746fc0828f20a4e641f9084000ca7696"
  },
  "operations": [
    {
      "op": "test",
      "path": "/phases/0",
      "value": {
        "id": "01-render-first-window",
        "kind": "data-render",
        "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window",
        "environment": {
          "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/home",
          "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/tmp",
          "LANG": "C",
          "LC_ALL": "C",
          "SHERLOCK_K_ATTEMPT_TOKEN": "f4a1c45fbdc8a2eef169625da351c929"
        },
        "inherit_environment": false,
        "stdin": "DEVNULL",
        "argv": [
          "/usr/bin/python3",
          "-I",
          "-B",
          "-S",
          "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter/render_input.py",
          "--input",
          "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/inputs/ADD-ENTRY.first-window.input.json",
          "--api",
          "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/PUBLIC-LT-API.json",
          "--syntax",
          "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/COMPLETE-LT-CONSTRUCTOR-SYNTAX.k.txt",
          "--output-dir",
          "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window"
        ],
        "expected_exit_code": 0,
        "products": [],
        "status": "PROSPECTIVE_UNSELECTED"
      }
    },
    {
      "op": "replace",
      "path": "/phases/0",
      "value": {
        "id": "01-render-first-window",
        "kind": "data-render",
        "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window",
        "environment": {
          "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/home",
          "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/tmp",
          "LANG": "C",
          "LC_ALL": "C",
          "SHERLOCK_K_ATTEMPT_TOKEN": "f4a1c45fbdc8a2eef169625da351c929"
        },
        "inherit_environment": false,
        "stdin": "DEVNULL",
        "argv": [
          "/usr/bin/python3",
          "-I",
          "-B",
          "-S",
          "-c",
          "import sys\nADAPTER='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter'\nsys.path.insert(0, ADAPTER)\nsys.argv=['render_input.py', '--input', '/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/inputs/ADD-ENTRY.first-window.input.json', '--api', '/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/PUBLIC-LT-API.json', '--syntax', '/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/COMPLETE-LT-CONSTRUCTOR-SYNTAX.k.txt', '--output-dir', '/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window']\nimport render_input\nrender_input.main()\n"
        ],
        "expected_exit_code": 0,
        "products": [
          "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/initial.ng",
          "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/query.term"
        ],
        "status": "PROSPECTIVE_UNSELECTED"
      }
    }
  ],
  "inverse": [
    {
      "op": "test",
      "path": "/phases/0",
      "value": {
        "id": "01-render-first-window",
        "kind": "data-render",
        "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window",
        "environment": {
          "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/home",
          "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/tmp",
          "LANG": "C",
          "LC_ALL": "C",
          "SHERLOCK_K_ATTEMPT_TOKEN": "f4a1c45fbdc8a2eef169625da351c929"
        },
        "inherit_environment": false,
        "stdin": "DEVNULL",
        "argv": [
          "/usr/bin/python3",
          "-I",
          "-B",
          "-S",
          "-c",
          "import sys\nADAPTER='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter'\nsys.path.insert(0, ADAPTER)\nsys.argv=['render_input.py', '--input', '/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/inputs/ADD-ENTRY.first-window.input.json', '--api', '/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/PUBLIC-LT-API.json', '--syntax', '/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/COMPLETE-LT-CONSTRUCTOR-SYNTAX.k.txt', '--output-dir', '/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window']\nimport render_input\nrender_input.main()\n"
        ],
        "expected_exit_code": 0,
        "products": [
          "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/initial.ng",
          "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/query.term"
        ],
        "status": "PROSPECTIVE_UNSELECTED"
      }
    },
    {
      "op": "replace",
      "path": "/phases/0",
      "value": {
        "id": "01-render-first-window",
        "kind": "data-render",
        "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window",
        "environment": {
          "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/home",
          "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/tmp",
          "LANG": "C",
          "LC_ALL": "C",
          "SHERLOCK_K_ATTEMPT_TOKEN": "f4a1c45fbdc8a2eef169625da351c929"
        },
        "inherit_environment": false,
        "stdin": "DEVNULL",
        "argv": [
          "/usr/bin/python3",
          "-I",
          "-B",
          "-S",
          "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter/render_input.py",
          "--input",
          "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/inputs/ADD-ENTRY.first-window.input.json",
          "--api",
          "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/PUBLIC-LT-API.json",
          "--syntax",
          "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/COMPLETE-LT-CONSTRUCTOR-SYNTAX.k.txt",
          "--output-dir",
          "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window"
        ],
        "expected_exit_code": 0,
        "products": [],
        "status": "PROSPECTIVE_UNSELECTED"
      }
    }
  ],
  "unchanged_phases_02_through_10": true,
  "earlier_phase10_oraclebinding_preserved": true,
  "only_phase01_argv_and_products_changed": true,
  "AST_only_no_import": true
}

===== END BODY 3 =====

===== COMPLETE BODY 4 Literal phase01-onlydiff =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/revision02-phase01-import-and-actual-premises/PHASE01-ARGV-ONLY.diff
BYTES 2515 SHA256 3836902d10b93d0c6b5ed6f18fd6d653c531e2489b37cfbc86ac36acef375ab0
--- phase01.original
+++ phase01.Opus-corrected
@@ -16,17 +16,13 @@
     "-I",
     "-B",
     "-S",
-    "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter/render_input.py",
-    "--input",
-    "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/inputs/ADD-ENTRY.first-window.input.json",
-    "--api",
-    "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/PUBLIC-LT-API.json",
-    "--syntax",
-    "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/COMPLETE-LT-CONSTRUCTOR-SYNTAX.k.txt",
-    "--output-dir",
-    "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window"
+    "-c",
+    "import sys\nADAPTER='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter'\nsys.path.insert(0, ADAPTER)\nsys.argv=['render_input.py', '--input', '/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/inputs/ADD-ENTRY.first-window.input.json', '--api', '/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/PUBLIC-LT-API.json', '--syntax', '/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/COMPLETE-LT-CONSTRUCTOR-SYNTAX.k.txt', '--output-dir', '/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window']\nimport render_input\nrender_input.main()\n"
   ],
   "expected_exit_code": 0,
-  "products": [],
+  "products": [
+    "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/initial.ng",
+    "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/query.term"
+  ],
   "status": "PROSPECTIVE_UNSELECTED"
 }

===== END BODY 4 =====

===== COMPLETE BODY 5 Complete actual F03commandbuilderbodies+globals =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/revision02-phase01-import-and-actual-premises/ACTUAL-F03-COMMAND-BUILDERS-AND-GLOBALS.txt
BYTES 1674 SHA256 9e4aa56825714c823a12827d96e1739928d4c8e49531c954ab3e06cf5e501362
FULL EXACT F03 COMMAND BUILDER BODIES; these legacy builders are reference forms, not invoked by new plan.

def kast_command(stage):
    return (JAVA, '-Xms64m', '-Xmx512m', '-Xss32m', '-XX:ActiveProcessorCount=2',
            '-XX:+ExitOnOutOfMemoryError', '-XX:-UsePerfData', '-XX:+DisableAttachMechanism',
            '-XX:ErrorFile=' + stage + '/hs_err_pid%p.log',
            '-Dfile.encoding=UTF-8', '-Djava.awt.headless=true',
            '-Djava.io.tmpdir=' + stage + '/tmp', '-Duser.home=' + stage + '/home',
            '-ea', '-cp', K_JARS + '/*', 'org.kframework.main.Main', '-kast',
            '--definition', COMPILED, '--module', 'MORIARTY-UI-SYNTAX', '--sort', 'UIRun',
            '--input', 'program', '--output', 'kore', INPUT)


def exec_command(pattern, depth):
    def build(stage):
        return (KORE_EXEC, DEFINITION, '--module', 'MORIARTY-UI', '--pattern', pattern,
                '--output', stage + '/state.kore', '--depth', str(depth), '--smt', 'none',
                '--log-format', 'standard', '--disable-log-timestamps', '--log-entries', LOG_ENTRIES)
    return build


def kprint_command(state):
    return lambda stage: (KPRINT, COMPILED, state, 'false', 'false')


COMPILED = COMPILE_ATTEMPT + '/main-kompiled'

DEFINITION = COMPILED + '/definition.kore'

INPUT = INPUTS + '/F03-fuel093-stack064.ui'

JAVA = JRE_ROOT + '/bin/java'

K_JARS = K_ROOT + '/lib/kframework/java'

KORE_EXEC = STORE + 'qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/.kore-exec-wrapped'

KPRINT = LLVM_ROOT + '/bin/kprint'

CHILD_SECONDS = 30

SWEEP_SECONDS = 3

TOKEN_NAME = 'SHERLOCK_K_ATTEMPT_TOKEN'

LOG_ENTRIES = 'DebugAppliedRewriteRules,InfoExecDepth'


===== END BODY 5 =====

===== COMPLETE BODY 6 Actual F03API/ASTreconciliation =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/revision02-phase01-import-and-actual-premises/F03-ACTUAL-API-RECONCILIATION.json
BYTES 1523 SHA256 2e3b6842a6b58e36e192e2aa66eac323ab4933478c3c75349af150e45c97d639
{
  "source": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/UIREQ021-F03-K-caller-materialized-review/source/k_engine_attempt_f03_01.py",
    "bytes": 73962,
    "sha256": "f1bcf0a0d21b4a7aaedd2f2aae1a1e9e5b62219271eb41b3f71ed97d5a0bc24d"
  },
  "actual_command_bodies": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/revision02-phase01-import-and-actual-premises/ACTUAL-F03-COMMAND-BUILDERS-AND-GLOBALS.txt",
    "bytes": 1674,
    "sha256": "9e4aa56825714c823a12827d96e1739928d4c8e49531c954ab3e06cf5e501362"
  },
  "launch_closure_all_functions_AST_equal_actual_source": [
    "utc",
    "open_exclusive",
    "processes",
    "kill_group",
    "sweep",
    "launch"
  ],
  "legacy_builders_not_called": true,
  "kast": "Same pinned Java flags/classpath and argument shape; intentional data substitutions: compiledLtcohort/module/sortNGTape/newinput/freshstage. OldUI module/sort/input are not reused.",
  "exec": "Direct plan uses pinned kore-exec shape with Ltdefinition/module/result.kore/depth1/smtnone. LegacyUI log-entries extra option is not selected; this does not invoke oldexec_command or its oldledger.",
  "kprint": "Actual kprint_command returns (KPRINT,COMPILED,state,false,false), matching explicit newplan form with currentLt compiled path.",
  "actual_child_outcome_field": "F03.launch record.returncode, not generic actual_exit/exitCode."
}

===== END BODY 6 =====

===== COMPLETE BODY 7 Full actual F03 import-time AST, not projection =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-product-model-v2-review-operation-20261018/context/IMPORT-TIME-AST.json
BYTES 49416 SHA256 11a38a47e51d205aaa76467eab7f5f8f0768f40df0d5ddbaac30440982292a6e
{
  "source": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/UIREQ021-F03-K-caller-materialized-review/source/k_engine_attempt_f03_01.py",
    "bytes": 73962,
    "sha256": "f1bcf0a0d21b4a7aaedd2f2aae1a1e9e5b62219271eb41b3f71ed97d5a0bc24d"
  },
  "method": "ast.parse only; no import/module execution",
  "top_level": [
    {
      "kind": "Expr",
      "line": 2,
      "endLine": 37,
      "text": "\"\"\"Sherlock K-A attempt-engine-F03-01: one-case F03 raw K engine capture. No recompile.\n\nDerived from the consumed attempt-engine-N01-01 driver (53993B, SHA256\naf9f49b07af4b8d16607fd7cbe01df79ff30302a782084ab502a17dda10e56d2) under\nunchanged per-child controls (30 s wall, 3 s sweep, RLIMIT_CORE 0,\nRLIMIT_FSIZE 512 MiB, umask 077, minimal environment, no host PATH).\nConsumed attempt-engine-N01-01 and its ledger remain untouched.\n\n  python3 -I -B k_engine_attempt_f03_01.py --preflight-only\n      Read-only gates and inventories. No directory, claim, ledger record or\n      child. Prints driver_sha256 and identity_sha256 for review.\n  python3 -I -B k_engine_attempt_f03_01.py --execute \\\\\n          --approved-driver-sha256 HEX --approved-identity-sha256 HEX\n      Exactly one terminal attempt-engine-F03-01 in the R251 actual/k root.\n      Never retried, never reset.\n\nFixed stages (195 child processes + 1 driver-only local initializer = 196 stages),\nstrictly in order:\n\n  kast               pinned JRE, org.kframework.main.Main -kast, frozen F03 input\n                     (F03-fuel093-stack064.ui, 359B, fuel 93, stack limit 64)\n  initializer        driver only: the parsed UIRun is bound as $PGM under the\n                     compiled LblinitGeneratedTopCell; no cell or rule is written\n  exec-000           pinned .kore-exec-wrapped depth-0 pre-startup normalization\n  exec-001           pinned .kore-exec-wrapped depth-1 startup transition\n  exec-002..exec-094 pinned .kore-exec-wrapped depth-1 steps (93 charged transitions)\n  exec-095           pinned .kore-exec-wrapped depth-1 step (free publication)\n  exec-096           pinned .kore-exec-wrapped depth-1 separate terminal probe\n  print-000..096     pinned kprint on each of the 97 states, observation only\n\nA stage is consumed once its ledger claim is appended. The first problem\n(launch error, nonzero exit, signal, timeout, containment breach, missing\nproduct, unexpected stage file, protected-tree change or captured-artifact\nchange) stops the attempt: no retry, no alternate method. Outputs are kept\nraw and hashed; nothing is decoded, matched, labelled or certified.\n\"\"\""
    },
    {
      "kind": "Import",
      "line": 38,
      "endLine": 38,
      "text": "import argparse"
    },
    {
      "kind": "Import",
      "line": 39,
      "endLine": 39,
      "text": "import datetime"
    },
    {
      "kind": "Import",
      "line": 40,
      "endLine": 40,
      "text": "import hashlib"
    },
    {
      "kind": "Import",
      "line": 41,
      "endLine": 41,
      "text": "import json"
    },
    {
      "kind": "Import",
      "line": 42,
      "endLine": 42,
      "text": "import os"
    },
    {
      "kind": "Import",
      "line": 43,
      "endLine": 43,
      "text": "import re"
    },
    {
      "kind": "Import",
      "line": 44,
      "endLine": 44,
      "text": "import resource"
    },
    {
      "kind": "Import",
      "line": 45,
      "endLine": 45,
      "text": "import secrets"
    },
    {
      "kind": "Import",
      "line": 46,
      "endLine": 46,
      "text": "import signal"
    },
    {
      "kind": "Import",
      "line": 47,
      "endLine": 47,
      "text": "import stat"
    },
    {
      "kind": "Import",
      "line": 48,
      "endLine": 48,
      "text": "import subprocess"
    },
    {
      "kind": "Import",
      "line": 49,
      "endLine": 49,
      "text": "import sys"
    },
    {
      "kind": "Import",
      "line": 50,
      "endLine": 50,
      "text": "import time"
    },
    {
      "kind": "Assign",
      "line": 52,
      "endLine": 52,
      "text": "WORKSPACE = '/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016'"
    },
    {
      "kind": "Assign",
      "line": 53,
      "endLine": 53,
      "text": "RUNTIME_PARENT = '/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-parallel-20261016'"
    },
    {
      "kind": "Assign",
      "line": 54,
      "endLine": 54,
      "text": "RUNTIME = RUNTIME_PARENT + '/k-actual-01'"
    },
    {
      "kind": "Assign",
      "line": 56,
      "endLine": 56,
      "text": "CONSUMED_N01_ATTEMPT_NAME = 'attempt-engine-N01-01'"
    },
    {
      "kind": "Assign",
      "line": 57,
      "endLine": 57,
      "text": "CONSUMED_N01_ATTEMPT = RUNTIME + '/' + CONSUMED_N01_ATTEMPT_NAME"
    },
    {
      "kind": "Assign",
      "line": 58,
      "endLine": 58,
      "text": "CONSUMED_N01_LEDGER = RUNTIME + '/k-engine-ledger.jsonl'"
    },
    {
      "kind": "Assign",
      "line": 59,
      "endLine": 59,
      "text": "HISTORICAL_N01_DRIVER_SHA256 = 'af9f49b07af4b8d16607fd7cbe01df79ff30302a782084ab502a17dda10e56d2'"
    },
    {
      "kind": "Assign",
      "line": 60,
      "endLine": 60,
      "text": "HISTORICAL_N01_DRIVER_BYTES = 53993"
    },
    {
      "kind": "Assign",
      "line": 62,
      "endLine": 62,
      "text": "PLAN_PARENT = '/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017'"
    },
    {
      "kind": "Assign",
      "line": 63,
      "endLine": 63,
      "text": "PLAN_ROOT = PLAN_PARENT + '/251-f03-paired-model-operation-proposal'"
    },
    {
      "kind": "Assign",
      "line": 64,
      "endLine": 64,
      "text": "ACTUAL_ROOT = PLAN_ROOT + '/actual'"
    },
    {
      "kind": "Assign",
      "line": 65,
      "endLine": 65,
      "text": "ATTEMPT_NAME = 'attempt-engine-F03-01'"
    },
    {
      "kind": "Assign",
      "line": 66,
      "endLine": 66,
      "text": "ATTEMPT = ACTUAL_ROOT + '/k'"
    },
    {
      "kind": "Assign",
      "line": 67,
      "endLine": 67,
      "text": "STAGES_DIR = ATTEMPT"
    },
    {
      "kind": "Assign",
      "line": 68,
      "endLine": 68,
      "text": "RECEIPT = ATTEMPT + '/receipt.json'"
    },
    {
      "kind": "Assign",
      "line": 69,
      "endLine": 69,
      "text": "LEDGER = PLAN_ROOT + '/k-engine-f03-ledger.jsonl'"
    },
    {
      "kind": "Assign",
      "line": 71,
      "endLine": 71,
      "text": "COMPILE_LEDGER = RUNTIME + '/k-attempt-ledger.jsonl'"
    },
    {
      "kind": "Assign",
      "line": 72,
      "endLine": 72,
      "text": "COMPILE_ATTEMPT = RUNTIME + '/attempt-compile-01'"
    },
    {
      "kind": "Assign",
      "line": 73,
      "endLine": 73,
      "text": "COMPILE_DRIVER_SHA256 = '05086da9bc2dc5f3f9d89f0f6734a57b57e408f9fef934351b990edc013011a3'"
    },
    {
      "kind": "Assign",
      "line": 74,
      "endLine": 74,
      "text": "COMPILE_RECEIPT_SHA256 = '946c567c291edf13524a3641d14c7811e855b44073475f6770c9bb0e81399f69'"
    },
    {
      "kind": "Assign",
      "line": 75,
      "endLine": 75,
      "text": "COMPILED = COMPILE_ATTEMPT + '/main-kompiled'"
    },
    {
      "kind": "Assign",
      "line": 76,
      "endLine": 76,
      "text": "DEFINITION = COMPILED + '/definition.kore'"
    },
    {
      "kind": "Assign",
      "line": 77,
      "endLine": 77,
      "text": "SYNTAX_DEFINITION = COMPILED + '/syntaxDefinition.kore'"
    },
    {
      "kind": "Assign",
      "line": 78,
      "endLine": 78,
      "text": "MACROS = COMPILED + '/macros.kore'"
    },
    {
      "kind": "Assign",
      "line": 79,
      "endLine": 79,
      "text": "COMPILE_INPUT = RUNTIME + '/compile-input'"
    },
    {
      "kind": "Assign",
      "line": 80,
      "endLine": 80,
      "text": "CANDIDATE_SNAPSHOT = RUNTIME + '/candidate'"
    },
    {
      "kind": "Assign",
      "line": 81,
      "endLine": 81,
      "text": "CANDIDATE_RECORD = RUNTIME + '/CANDIDATE-SNAPSHOT-AFTER-COMPILE-03.json'"
    },
    {
      "kind": "Assign",
      "line": 82,
      "endLine": 82,
      "text": "CANDIDATE_RECORD_SHA256 = '2a7786ee3ac96788aa9ac389a3d4db93af15a7b7c08c9648de2dca08cd7e81c7'"
    },
    {
      "kind": "Assign",
      "line": 84,
      "endLine": 84,
      "text": "N01_INPUTS = RUNTIME + '/inputs'"
    },
    {
      "kind": "Assign",
      "line": 85,
      "endLine": 85,
      "text": "N01_INPUT = N01_INPUTS + '/N01-fuel-001.ui'"
    },
    {
      "kind": "Assign",
      "line": 86,
      "endLine": 86,
      "text": "N01_INPUT_SHA256 = 'e5fe7b26e9565fdafdc97da0fb25fb81c6171afd69e99eaa6dfb38b5409a2e0f'"
    },
    {
      "kind": "Assign",
      "line": 87,
      "endLine": 87,
      "text": "N01_INPUT_BYTES = 43"
    },
    {
      "kind": "Assign",
      "line": 89,
      "endLine": 89,
      "text": "INPUTS = PLAN_ROOT + '/input'"
    },
    {
      "kind": "Assign",
      "line": 90,
      "endLine": 90,
      "text": "INPUT = INPUTS + '/F03-fuel093-stack064.ui'"
    },
    {
      "kind": "Assign",
      "line": 91,
      "endLine": 91,
      "text": "INPUT_SHA256 = 'c1ab51c62fc70ea5693e1d9046445cba6a03eb3222273c045b511913c0f6b91b'"
    },
    {
      "kind": "Assign",
      "line": 92,
      "endLine": 92,
      "text": "INPUT_BYTES = 359"
    },
    {
      "kind": "Assign",
      "line": 93,
      "endLine": 93,
      "text": "INITIAL_FUEL = 93"
    },
    {
      "kind": "Assign",
      "line": 94,
      "endLine": 94,
      "text": "STACK_LIMIT = 64"
    },
    {
      "kind": "Assign",
      "line": 96,
      "endLine": 96,
      "text": "PROSPECTIVE_K_COMMANDS = PLAN_ROOT + '/K-COMMANDS.json'"
    },
    {
      "kind": "Assign",
      "line": 97,
      "endLine": 97,
      "text": "PROSPECTIVE_K_COMMANDS_SHA256 = 'db62fb14ce8d80e024dfb1d29e1b64dcbe264815690dee6c98619b6e90463110'"
    },
    {
      "kind": "Assign",
      "line": 98,
      "endLine": 98,
      "text": "PROSPECTIVE_K_COMMANDS_BYTES = 413065"
    },
    {
      "kind": "Assign",
      "line": 99,
      "endLine": 99,
      "text": "PROSPECTIVE_K_COMMANDS_COUNT = 195"
    },
    {
      "kind": "Assign",
      "line": 100,
      "endLine": 100,
      "text": "INITIALIZER_RECIPE_SHA256 = 'f9e4d47debf8db513619317aac2115587042e7b284581c48393c3af65bb781cc'"
    },
    {
      "kind": "Assign",
      "line": 101,
      "endLine": 101,
      "text": "INITIALIZER_RECIPE_BYTES = 1613"
    },
    {
      "kind": "Assign",
      "line": 102,
      "endLine": 102,
      "text": "READ_IMPORT_PINS = PLAN_ROOT + '/READ-IMPORT-PINS.json'"
    },
    {
      "kind": "Assign",
      "line": 103,
      "endLine": 103,
      "text": "READ_IMPORT_PINS_SHA256 = '2427379d20bb32c0c9a5d9f77b49c5bac39d1bd67fa39b7664c96cc85c2a6289'"
    },
    {
      "kind": "Assign",
      "line": 104,
      "endLine": 104,
      "text": "READ_IMPORT_PINS_BYTES = 1274580"
    },
    {
      "kind": "Assign",
      "line": 106,
      "endLine": 106,
      "text": "INTERPRETER_SHA256 = '52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41'"
    },
    {
      "kind": "Assign",
      "line": 108,
      "endLine": 108,
      "text": "STORE = '/nix/store/'"
    },
    {
      "kind": "Assign",
      "line": 109,
      "endLine": 109,
      "text": "K_ROOT = STORE + 'y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406'"
    },
    {
      "kind": "Assign",
      "line": 110,
      "endLine": 110,
      "text": "JRE_ROOT = STORE + 'kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35'"
    },
    {
      "kind": "Assign",
      "line": 111,
      "endLine": 111,
      "text": "JAVA = JRE_ROOT + '/bin/java'"
    },
    {
      "kind": "Assign",
      "line": 112,
      "endLine": 112,
      "text": "K_JARS = K_ROOT + '/lib/kframework/java'"
    },
    {
      "kind": "Assign",
      "line": 113,
      "endLine": 113,
      "text": "K_BUILTIN = K_ROOT + '/include/kframework/builtin'"
    },
    {
      "kind": "Assign",
      "line": 114,
      "endLine": 114,
      "text": "K_WRAPPER = K_ROOT + '/bin/kompile'"
    },
    {
      "kind": "Assign",
      "line": 115,
      "endLine": 115,
      "text": "K_UNWRAPPED = K_ROOT + '/bin-unwrapped/kompile'"
    },
    {
      "kind": "Assign",
      "line": 116,
      "endLine": 116,
      "text": "K_LIBRARY = K_ROOT + '/lib/kframework/k'"
    },
    {
      "kind": "Assign",
      "line": 117,
      "endLine": 117,
      "text": "K_KAST_UNWRAPPED = K_ROOT + '/bin-unwrapped/kast'"
    },
    {
      "kind": "Assign",
      "line": 118,
      "endLine": 118,
      "text": "K_KORE_PRINT_UNWRAPPED = K_ROOT + '/bin-unwrapped/kore-print'"
    },
    {
      "kind": "Assign",
      "line": 119,
      "endLine": 119,
      "text": "K_KORE_PRINT_WRAPPER = K_ROOT + '/bin/kore-print'"
    },
    {
      "kind": "Assign",
      "line": 120,
      "endLine": 125,
      "text": "TOOL_ROOTS = (  # PATH order for the kast JVM, identical to the approved compile.\n    ('kore-parser', STORE + '5p6kb76qjrdwjvjmm6l7l2683k41ay1r-kore-38afc81'),\n    ('gcc', STORE + '9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0'),\n    ('flex', STORE + 'z1fkfc5ca0rra7m5zrh8i92mx18w9i00-flex-2.6.4'),\n    ('z3', STORE + 'ih51sgk8g57fnkbd5r82ddi8k5vln8cl-z3-4.13.4'),\n)"
    },
    {
      "kind": "Assign",
      "line": 126,
      "endLine": 126,
      "text": "GCC_ROOT = dict(TOOL_ROOTS)['gcc']"
    },
    {
      "kind": "Assign",
      "line": 127,
      "endLine": 127,
      "text": "FLEX = dict(TOOL_ROOTS)['flex'] + '/bin/flex'"
    },
    {
      "kind": "Assign",
      "line": 128,
      "endLine": 128,
      "text": "KORE_ROOT = dict(TOOL_ROOTS)['kore-parser']"
    },
    {
      "kind": "Assign",
      "line": 129,
      "endLine": 129,
      "text": "Z3_ROOT = dict(TOOL_ROOTS)['z3']"
    },
    {
      "kind": "Assign",
      "line": 130,
      "endLine": 130,
      "text": "KORE_EXEC = STORE + 'qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/.kore-exec-wrapped'"
    },
    {
      "kind": "Assign",
      "line": 131,
      "endLine": 131,
      "text": "KORE_EXEC_SHA256 = '4ebe3cd5b32864352247b954c2d0fb90a7a5730e519a6c4516bb2b5a2c315429'"
    },
    {
      "kind": "Assign",
      "line": 132,
      "endLine": 132,
      "text": "KORE_EXEC_WRAPPER = KORE_ROOT + '/bin/kore-exec'"
    },
    {
      "kind": "Assign",
      "line": 133,
      "endLine": 133,
      "text": "LLVM_ROOT = STORE + 'p7hjh21dj4bc1s6kfcdwk45knp5n4cc0-llvm-backend-0.1.140'"
    },
    {
      "kind": "Assign",
      "line": 134,
      "endLine": 134,
      "text": "KPRINT = LLVM_ROOT + '/bin/kprint'"
    },
    {
      "kind": "Assign",
      "line": 135,
      "endLine": 135,
      "text": "JAVA_PATH = ':'.join(root + '/bin' for _, root in TOOL_ROOTS)"
    },
    {
      "kind": "Assign",
      "line": 136,
      "endLine": 136,
      "text": "KORE_EXEC_PATH = Z3_ROOT + '/bin'"
    },
    {
      "kind": "Assign",
      "line": 138,
      "endLine": 138,
      "text": "CHILD_SECONDS = 30"
    },
    {
      "kind": "Assign",
      "line": 139,
      "endLine": 139,
      "text": "SWEEP_SECONDS = 3"
    },
    {
      "kind": "Assign",
      "line": 140,
      "endLine": 140,
      "text": "FILE_SIZE_LIMIT = 512 * 1024 * 1024"
    },
    {
      "kind": "Assign",
      "line": 141,
      "endLine": 141,
      "text": "TOKEN_NAME = 'SHERLOCK_K_ATTEMPT_TOKEN'"
    },
    {
      "kind": "Assign",
      "line": 142,
      "endLine": 142,
      "text": "STORE_ROOT = re.compile(rb'/nix/store/[0-9a-z]{32}-[0-9A-Za-z+._?=-]+')"
    },
    {
      "kind": "Assign",
      "line": 143,
      "endLine": 143,
      "text": "EMPTY_SHA256 = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'"
    },
    {
      "kind": "Assign",
      "line": 145,
      "endLine": 145,
      "text": "MAIN_REL = 'models/sherlock/k/main.k'"
    },
    {
      "kind": "Assign",
      "line": 146,
      "endLine": 146,
      "text": "MAIN_SHA256 = 'b3746ff51dd7999b046ccb23237595605420adcfeebc0c04c0ad0f1396b11d41'"
    },
    {
      "kind": "Assign",
      "line": 147,
      "endLine": 147,
      "text": "MAIN_BYTES = 16249"
    },
    {
      "kind": "Assign",
      "line": 148,
      "endLine": 160,
      "text": "HISTORICAL_N01_SOURCE_FILES = (\n    (MAIN_REL, MAIN_SHA256, MAIN_BYTES),\n    ('models/sherlock/qa/k_capture_observations.py', '2f9d939ea847a61ecaa6c27058b00504c7d613642273767f79fcaa111fc2f8bd', 11336),\n    ('models/sherlock/qa/test_k_capture_observations.py', 'e4b71ca2c249396e9ad262f5c43a16885193045da649d36a33069b686d898767', 5866),\n    ('models/sherlock/qa/k_observations.py', '540128fdb7f693a7b1f415898fd74bd6c1918df50a7a48ce602471b6e85f9b07', 7686),\n    ('models/sherlock/qa/k_terms.py', 'c79a852cbda9259c736d36da29132486d10903007fd3adc755e7d0585b8366ca', 5666),\n    ('models/sherlock/qa/host_observations.py', '61b8258595a298231679362cb3974ae176b6970e7e4475388252d59da545fcdc', 4912),\n    ('models/sherlock/qa/check.py', '7a6d1bbca881f5c2b012278989dac600834d610986694e640da51a40b5a412e0', 36429),\n    ('models/sherlock/oracles/normal-programs.json', 'ef87f94f7e5d22a75b1c2e5e61af016b08175beee9a3599e3e69ddf92945d32f', 10202),\n    ('models/sherlock/oracles/extra-normal-programs.json', 'dd85e5d400f24e9be5e2ff017f4b8c141a0bf6e4270053917b735cbe5153f153', 3721),\n    ('models/sherlock/oracles/normal-prefixes.json', 'dca67b553d7483fdf7d9148e7f4bf1a6022b42b8843635f33f23c58a2415d56d', 53119),\n    ('models/sherlock/oracles/extra-normal-prefixes.json', 'acf460094b258910bad0499fb8feda0cd85b680023939800ad714d2cb71bee16', 80130),\n)"
    },
    {
      "kind": "Assign",
      "line": 161,
      "endLine": 173,
      "text": "SOURCE_FILES = (\n    (MAIN_REL, MAIN_SHA256, MAIN_BYTES),\n    ('models/sherlock/qa/k_capture_observations.py', '2260ebb2d2bbfc6d1cb3f6d2a6715f023637c6d76e401fe105c42616053ab8ac', 41478),\n    ('models/sherlock/qa/test_k_capture_observations.py', '4e55872346ad58f9a21e67ef0917bf0cbe550c0a5f3e4f3a1e129b4cff78a091', 90731),\n    ('models/sherlock/qa/k_observations.py', '540128fdb7f693a7b1f415898fd74bd6c1918df50a7a48ce602471b6e85f9b07', 7686),\n    ('models/sherlock/qa/k_terms.py', 'c79a852cbda9259c736d36da29132486d10903007fd3adc755e7d0585b8366ca', 5666),\n    ('models/sherlock/qa/host_observations.py', '61b8258595a298231679362cb3974ae176b6970e7e4475388252d59da545fcdc', 4912),\n    ('models/sherlock/qa/check.py', '004646fb8a5dcd7666d209360bf932c67920226d50a638500d51a8f95b83b8c5', 81758),\n    ('models/sherlock/oracles/normal-programs.json', 'ef87f94f7e5d22a75b1c2e5e61af016b08175beee9a3599e3e69ddf92945d32f', 10202),\n    ('models/sherlock/oracles/extra-normal-programs.json', 'dd85e5d400f24e9be5e2ff017f4b8c141a0bf6e4270053917b735cbe5153f153', 3721),\n    ('models/sherlock/oracles/normal-prefixes.json', 'dca67b553d7483fdf7d9148e7f4bf1a6022b42b8843635f33f23c58a2415d56d', 53119),\n    ('models/sherlock/oracles/extra-normal-prefixes.json', 'acf460094b258910bad0499fb8feda0cd85b680023939800ad714d2cb71bee16', 80130),\n)"
    },
    {
      "kind": "Assign",
      "line": 174,
      "endLine": 174,
      "text": "K_SRC = STORE + 'x3ybp2gyrf0vlzzf02s959skd08wn5r6-source'"
    },
    {
      "kind": "Assign",
      "line": 175,
      "endLine": 175,
      "text": "KORE_PKG = STORE + 'pmjs0mz53bz7p8jzzqx4nba1pfwyhf39-kore'"
    },
    {
      "kind": "Assign",
      "line": 176,
      "endLine": 176,
      "text": "KORE_SRC = KORE_PKG + '/src/Kore'"
    },
    {
      "kind": "Assign",
      "line": 177,
      "endLine": 177,
      "text": "LLVM_SRC = STORE + '4k1n4sga1z2pp4iji230aisw4z6al044-source'"
    },
    {
      "kind": "Assign",
      "line": 178,
      "endLine": 216,
      "text": "PRIMARY_SOURCES = (\n    (K_ROOT + '/lib/kframework/checkJava', 'ca205adcbd0aaede282b0ee2251c15fd1dc0806bcd946d8a8971cdedeeed5571', 2257),\n    (K_ROOT + '/lib/kframework/setenv', 'fa8d26333cf0d1ef90ba3c6cfc85cd9f63ff23088bfaa61f6a9c6c69c9629688', 891),\n    (K_LIBRARY, 'd56ba8f42a320cab88708456ec2721ab71b0d49e8b1bad42d47b497b34fda66c', 1115),\n    (K_ROOT + '/bin-unwrapped/krun', '80dea6c5e96142084fe7b4514a22f883db906daef63701b2bcad949d1ff5d743', 21662),\n    (K_ROOT + '/bin-unwrapped/kparse', '72df487e5571f6db94beea880ce43ae87d3c1a3db13c5cd308c23ffdaf130484', 4543),\n    (K_KORE_PRINT_UNWRAPPED, 'f1956617796796855e288760d88c524074b5da17b4da606dfd0ebff9565a0dc0', 4770),\n    (KORE_EXEC_WRAPPER, 'f73768989745e8d108d80906c158fe406942173b104ad2e81b8e8349da6d504d', 395),\n    (K_SRC + '/haskell-backend/src/main/java/org/kframework/backend/haskell/HaskellBackend.java',\n     'ad044efecdb6679f0cc6ff9929717411f17c5f5f54b33dd3b87e25d938d5b9b4', 2977),\n    (K_SRC + '/haskell-backend/src/main/java/org/kframework/backend/haskell/HaskellKompileOptions.java',\n     '32534c3b27236d491091555fe053f7f147e9b4822f7faefea31a489f7d41a60a', 986),\n    (K_SRC + '/k-frontend/src/main/java/org/kframework/parser/inner/kernel/Scanner.java',\n     '32451e633f48e573813e94726e7e9695dffd455aceb9b4665540cd20508fb142', 19129),\n    (K_SRC + '/k-frontend/src/main/java/org/kframework/parser/inner/disambiguation/TypeInferencer.java',\n     '64ab4933ffeff6790cbadfbaccd31df569e0aaba457475f846dd1665e82042bc', 34641),\n    (K_SRC + '/k-frontend/src/main/java/org/kframework/utils/file/JarInfo.java',\n     '0dad79688d7c283e013200db422ccf4aee1344fb160c76add78be24ff670f8d4', 3593),\n    (K_SRC + '/k-frontend/src/main/java/org/kframework/kast/KastOptions.java',\n     'fb4af35d462b18577c47d2fd082fe094c159fd27ebccaf897bb0ddd5b82312fd', 6564),\n    (K_SRC + '/k-frontend/src/main/java/org/kframework/kast/KastFrontEnd.java',\n     '1eee80a1c242754333f6cad6b83aa1e76f322bbfc3a3d58c627abc81e7621f7c', 10518),\n    (K_SRC + '/k-frontend/src/main/java/org/kframework/utils/options/DefinitionLoadingOptions.java',\n     '45621d8dc601e1048903e9d568ac56cfe55e177cc0d2a3feba2e70ec6565f2b1', 403),\n    (K_SRC + '/k-frontend/src/main/java/org/kframework/unparser/KPrint.java',\n     '48ea5a40e2111c49cd7de2934962f170ab66d4b6da6aefe429b8c3a1edadfd76', 14966),\n    (KORE_PKG + '/app/exec/Main.hs', 'd25081c4a4929e27ad37130963f16646503eb79f4350833f65dc740fecfab191', 31463),\n    (KORE_PKG + '/app/share/GlobalMain.hs', '1084b9ce08eaf67006f87e0891a8ca214485ffa9e9d30e247b1de737d3aa5998', 22981),\n    (KORE_PKG + '/src/Options/SMT.hs', '089081433908d5e8d708b15bbf0c69343aa1d447992bee9306d35a05bdf68a43', 7346),\n    (KORE_SRC + '/Log.hs', '3b8f1f93a06bb3cb0b351dc76a61f2d4e8c4db8da6a1d0b8079374890224b545', 13206),\n    (KORE_SRC + '/Log/DebugAppliedRewriteRules.hs', '6372c03b66df87d812dd3a07d05cf08ed3d1a4006b7ce3eca7da9d38bb4b08aa', 4599),\n    (KORE_SRC + '/Log/DebugRewriteTrace.hs', 'a481f4d0d30646162317396af9995576ef8b807481b111df429b8abbd8e0b2ac', 8030),\n    (KORE_SRC + '/Log/InfoExecDepth.hs', 'd7f94b700089936425f6d16f82101199176d9cb8df612fc59fa88c5cd0280091', 1428),\n    (KORE_SRC + '/Log/WarnDepthLimitExceeded.hs', '097c76c49a00a8a6da763b85580fc16a8808defbb0746b5e4c399a961f896663', 1227),\n    (KORE_SRC + '/Log/KoreLogOptions.hs', '58729e884c907d3d5a3c5f375e6be9e76aca45ce219bdd97acd28ef743378af0', 28018),\n    (KORE_SRC + '/Attribute/SourceLocation.hs', '7f77fefdcbb3d464c2d35c1a28e1812ca7209a94d8439d8adb0c043da4908983', 2794),\n    (LLVM_SRC + '/tools/kprint/main.cpp', '26a79f90483e57d8b2e6684148cbb6f7076de1da02d0af7f716cd61652321ec1', 1237),\n    (LLVM_SRC + '/lib/printer/printer.cpp', 'b0c486fba7dd6cc7d55431662ae8fc7f6096bae83b747ae2e3c8f3ed7f4b2d52', 11616),\n)"
    },
    {
      "kind": "Assign",
      "line": 217,
      "endLine": 223,
      "text": "PINNED_FILES = (\n    (JAVA, '2a065ca5589bc80168f45166653c6e58d97ce63bbd7407c85eb5fed6622a5740'),\n    (JRE_ROOT + '/lib/server/libjvm.so', 'c0e8d7fff0018efb9f157593f0ce1bb646b30f3702e9149ed76bf13f6b56151c'),\n    (K_JARS + '/k-frontend-1.0-SNAPSHOT.jar', '6505360d7b472d9802d857452f29722d09424985bb224585c68c37741b65d30a'),\n    (Z3_ROOT + '/bin/z3', '2a5132e5f73510ab0ebb61fa8996bfa303f5473a85add71eedbd9c6819ff43ef'),\n    (KORE_EXEC, KORE_EXEC_SHA256),\n)"
    },
    {
      "kind": "Assign",
      "line": 224,
      "endLine": 247,
      "text": "COMPILE_TREE = {  # Exact attempt-compile-01 tree: postflight inventory plus its receipt.\n    '.': ('dir', '0o700', None, None),\n    'compile.stderr': ('file', '0o600', EMPTY_SHA256, 0),\n    'compile.stdout': ('file', '0o600', EMPTY_SHA256, 0),\n    'home': ('dir', '0o700', None, None),\n    'tmp': ('dir', '0o700', None, None),\n    'main-kompiled': ('dir', '0o700', None, None),\n    'receipt.json': ('file', '0o600', COMPILE_RECEIPT_SHA256, 146103),\n    'main-kompiled/README.md': ('file', '0o600', '7202c455a322f60276c475075cc7f76c08065b6ef12b4312181038a9f8cb2120', 2886),\n    'main-kompiled/allRules.txt': ('file', '0o600', '69b5134df15c11cd46479edfcae9e4a29f16617f9c1ff1facb0a054b1d10debd', 45466),\n    'main-kompiled/backend.txt': ('file', '0o600', 'd11158b53adecdbfce1ad5c64d1adb628145cac84e958b1bf6fed68be5a6b64c', 7),\n    'main-kompiled/cache.bin': ('file', '0o600', 'f9e86595d5fad9b57b34eeb8fe4877914e1b5fc6803d5866665baa125dd3029a', 1819101),\n    'main-kompiled/compiled.bin': ('file', '0o600', '240b25ee04a90b2acab436a84337790db1bcb753bef133bb79949416f9b7ee18', 2269799),\n    'main-kompiled/compiled.txt': ('file', '0o600', 'de7467e2f30d78ba430216cec744f2c27336b54f06cccd7d4fe3ac67cc135d36', 306675),\n    'main-kompiled/configVars.sh': ('file', '0o600', '17f3b5a540bd9eec8af0e7d466f45216d790eeec1e2984a9c66ed538bf5ff1fc', 84),\n    'main-kompiled/definition.kore': ('file', '0o600', 'd795e32885e5651b49ea59eef7b57595a431a6908ef8e9c36901a5ec5e43b6e4', 1338414),\n    'main-kompiled/macros.kore': ('file', '0o600', '3585c084b81281ec26971b2e42c56b9968a802c5d645a81062296350493491cf', 10),\n    'main-kompiled/mainModule.txt': ('file', '0o600', '992498a9233bcf21e517704684f47da3e756a39476e69a4bddc966631597b340', 11),\n    'main-kompiled/mainSyntaxModule.txt': ('file', '0o600', 'c3da043df6c82c2bae1c1051598d9c67e64b10eda617b7027a28620d63b27697', 18),\n    'main-kompiled/parsed.txt': ('file', '0o600', '956e8e6b96f414990c22d2f555353d81280599fc0f48be25283fba968b67aabb', 247593),\n    'main-kompiled/scanner': ('file', '0o700', '6a60181404da4c20f8a34deecb8f2d5a48e9226e6f223e5913d241855405a432', 354784),\n    'main-kompiled/syntaxDefinition.kore': ('file', '0o600', '39c69c19a5c8763d2aec7847fb603401c1f7f41cf0ef7a5dc4367e4c00d35ba8', 225240),\n    'main-kompiled/timestamp': ('file', '0o600', '55800d7983a2a9904d34a306a176e303c5cd2b75dd99b8a761e92140ef9d4510', 7),\n}"
    },
    {
      "kind": "Assign",
      "line": 248,
      "endLine": 249,
      "text": "COMPILE_INPUT_SHAPE = [('.', 'dir'), ('models', 'dir'), ('models/sherlock', 'dir'),\n                       ('models/sherlock/k', 'dir'), (MAIN_REL, 'file')]"
    },
    {
      "kind": "Assign",
      "line": 252,
      "endLine": 253,
      "text": "UIRUN_OPEN = (b\"LbluiRun'LParUndsCommUndsCommUndsCommUndsRParUnds'MORIARTY-UI-SYNTAX'Unds'UIRun\"\n              b\"'Unds'UIFuns'Unds'UIExpr'Unds'Int'Unds'Int{}(\")"
    },
    {
      "kind": "Assign",
      "line": 254,
      "endLine": 263,
      "text": "DEFINITION_MARKERS = (\n    b'module MORIARTY-UI',\n    b'sort SortKConfigVar{}',\n    b'symbol LblinitGeneratedTopCell{}(SortMap{}) : SortGeneratedTopCell{}',\n    b\"hooked-symbol Lbl'UndsPipe'-'-GT-Unds'{}(SortKItem{}, SortKItem{}) : SortMap{}\",\n    b'symbol ' + UIRUN_OPEN[:-1] + b'(SortUIFuns{}, SortUIExpr{}, SortInt{}, SortInt{}) : SortUIRun{}',\n    b'\\\\dv{SortKConfigVar{}}(\"$PGM\")',\n    b'subsort{SortUIRun{}, SortKItem{}}()',\n    b'subsort{SortKConfigVar{}, SortKItem{}}()',\n)"
    },
    {
      "kind": "Assign",
      "line": 264,
      "endLine": 266,
      "text": "INIT_PREFIX = (b\"LblinitGeneratedTopCell{}(Lbl'UndsPipe'-'-GT-Unds'{}(\"\n               b'inj{SortKConfigVar{}, SortKItem{}}(\\\\dv{SortKConfigVar{}}(\"$PGM\")),'\n               b'inj{SortUIRun{}, SortKItem{}}(')"
    },
    {
      "kind": "Assign",
      "line": 267,
      "endLine": 267,
      "text": "INIT_SUFFIX = b')))\\n'"
    },
    {
      "kind": "Assign",
      "line": 268,
      "endLine": 268,
      "text": "PARSED_LIMIT = 64 * 1024"
    },
    {
      "kind": "Assign",
      "line": 269,
      "endLine": 269,
      "text": "LOG_ENTRIES = 'DebugAppliedRewriteRules,InfoExecDepth'"
    },
    {
      "kind": "Assign",
      "line": 271,
      "endLine": 271,
      "text": "STAGE_KAST = 'kast'"
    },
    {
      "kind": "Assign",
      "line": 272,
      "endLine": 272,
      "text": "STAGE_INIT = 'initializer'"
    },
    {
      "kind": "Assign",
      "line": 273,
      "endLine": 273,
      "text": "ENGINE_STAGE_MAX_INDEX = 96"
    },
    {
      "kind": "Assign",
      "line": 274,
      "endLine": 276,
      "text": "ENGINE_STAGES = (('exec-000', 0),) + tuple(\n    (f'exec-{idx:03d}', 1) for idx in range(1, ENGINE_STAGE_MAX_INDEX + 1)\n)"
    },
    {
      "kind": "Assign",
      "line": 277,
      "endLine": 277,
      "text": "PRINT_STAGES = tuple(f'print-{idx:03d}' for idx in range(ENGINE_STAGE_MAX_INDEX + 1))"
    },
    {
      "kind": "Assign",
      "line": 278,
      "endLine": 278,
      "text": "CHILD_STAGE_NAMES = (STAGE_KAST,) + tuple(name for name, _ in ENGINE_STAGES) + PRINT_STAGES"
    },
    {
      "kind": "Assign",
      "line": 279,
      "endLine": 279,
      "text": "STAGE_NAMES = [STAGE_KAST, STAGE_INIT] + [name for name, _ in ENGINE_STAGES] + list(PRINT_STAGES)"
    },
    {
      "kind": "Assign",
      "line": 281,
      "endLine": 477,
      "text": "PROSPECTIVE_STAGE_TOKENS = {\n    'kast': '99f8a3fe858fa21acf9b7871aad9d20e',\n    'exec-000': '3e1a59c24a3fa726bb9c66f2ffe44ba7',\n    'exec-001': 'fb2ff9bd36478857dc1318d3f1e947a2',\n    'exec-002': 'b34de597fe2155a9aa856c26ce06ad04',\n    'exec-003': '6c401b4f59496cba18d6f0b2d5c936a4',\n    'exec-004': 'f6b698d35cfa9c29834118993e5bdb6d',\n    'exec-005': '400c7482d3f79526d6137ad294fafbb7',\n    'exec-006': 'c0b50375111cc2209c5af03aca1c10df',\n    'exec-007': '3419d51b3e9c2ac048cc3289f437bdec',\n    'exec-008': 'acd3720e4f176d8dec944bc3a5d9d00d',\n    'exec-009': '8f98f6e307f716ea379f5d172820db31',\n    'exec-010': 'd83af94b4f71f45e647b69402df79108',\n    'exec-011': '10ebd99170149a001247642f2a500b44',\n    'exec-012': '432bcf3babcc8b1eeaafa94dab6b48b2',\n    'exec-013': 'b91abf5c3bbeae6111903d2c357bd9ae',\n    'exec-014': '8094ae13a426013307b5fbea889b9b6b',\n    'exec-015': '3595abeb94ca70506f3dc6f1fa3a8ffc',\n    'exec-016': '3361fe81fc34c52613ed347aa9f66eee',\n    'exec-017': '921d204e94cc59a114a709d8ec5acc56',\n    'exec-018': '8e27cc7ab14436e4de434f8fcd9cce52',\n    'exec-019': '9ef7361b20d85d7adfd93a6c86480bc6',\n    'exec-020': '6f188aa0a5e5cf7f63c1cdd61d15efec',\n    'exec-021': '9cf9f724796f653bc881fa1ade6e90e9',\n    'exec-022': '9094958c51061a65aaad1e5bd4f33c61',\n    'exec-023': '692ae63e3e3102323c033a3f8aa801a2',\n    'exec-024': '0fc947f1510770c560628d995f66dcd0',\n    'exec-025': 'b0e7cf25fece76f06d9015dc1de3e46f',\n    'exec-026': '0d6901f8b97a553ef3190250eb9435a0',\n    'exec-027': 'efa35213f574b0d43ac08f761fb845e4',\n    'exec-028': '3931ca24d8f665b1ddc44c0f498e4614',\n    'exec-029': '9e1e41f8d1317d5ad88658547dc90e16',\n    'exec-030': 'be940b0119e1fb5516e7cf3ce8491d9c',\n    'exec-031': '2d0e86565b87a234261d135c0aad3d5d',\n    'exec-032': 'ff0cadbf8154e334b4d43d055aab9f33',\n    'exec-033': '0a1b4a1af2316d05b88705755accba2e',\n    'exec-034': 'cec922b78f571735cfcd303b150e8ad5',\n    'exec-035': 'b04d932b93af5d70b927e5a3296d0397',\n    'exec-036': '2fd978cd30bfe6169533d9218cad4397',\n    'exec-037': '1fd6b9e286dbf94be630fc10d51f67b7',\n    'exec-038': '572cdd0c7171fce0efb7a9b1756cebd5',\n    'exec-039': '9793af06618232183981c6d93537505c',\n    'exec-040': '0911dbed37750344566ef6dee076f6bf',\n    'exec-041': '49c6305b6fe978ffa180678a4a2ee8e6',\n    'exec-042': '40101768487f8f3a1998b6af464a10f0',\n    'exec-043': 'aa6298037726d694eff594f9f25bee6b',\n    'exec-044': '08a91587f262342ada3047d52fcda43e',\n    'exec-045': 'aa1cf12b87097801268711a08c030142',\n    'exec-046': 'c76ff9302357b8e614ddd376a8b91c54',\n    'exec-047': '5117a37c4d5d332cc12660e150c937ca',\n    'exec-048': '636e37abdefee5231f1796e363d6819b',\n    'exec-049': 'c5d916f662de08e27206384485e42825',\n    'exec-050': 'e1b53353ef94d395ea8d1bd5021cdef3',\n    'exec-051': 'ea900256db0547327f577961132d7f96',\n    'exec-052': 'b525cb798433c7ed584154010a13ebc3',\n    'exec-053': '44949b5458e693eda36a3f2e1d901f9d',\n    'exec-054': 'fb8d17e1910c989e4fb0e25872d57d4d',\n    'exec-055': '7b34f7af58d96ea8220dcf1c34bbf9fa',\n    'exec-056': 'dcab699359058f6a4648bac3a91092a9',\n    'exec-057': 'e74f74fa679908586fbc20ef2be4f5d2',\n    'exec-058': '473ebc8ac151b7ecdaf314543ac60f7d',\n    'exec-059': 'ce33f3d1066f57e8c3741a461330141c',\n    'exec-060': '8d4ebae8946744ee77271afca26c0c1b',\n    'exec-061': '395ec3d9f58928ad5e6eac537b596598',\n    'exec-062': 'cfefd9b42efd9d329fd76278453e1b9d',\n    'exec-063': '23af250e2ab06b49559ff92422de1413',\n    'exec-064': '67c593afcb38949e42e61a5184bc3437',\n    'exec-065': 'eecc3ba133b58ba0d914231463df8279',\n    'exec-066': '43e053a519dd54300e7f00538e18b687',\n    'exec-067': 'a66765d276b35eb3f1edb8bfbeab5f97',\n    'exec-068': '48241aaff5331e2ff7fbd3875fb7565c',\n    'exec-069': 'dd936c00add067f9aa5974e7ff8389d5',\n    'exec-070': 'a72f947d6f863452ea63c816d6770593',\n    'exec-071': '38017dc4dd4e4313adafae3f0443e0a0',\n    'exec-072': '64f7f9041b7a8f2b76bec326e2c8a86a',\n    'exec-073': 'aedd69b6acab327c35efa4fcc1a4809a',\n    'exec-074': '547d426af65b508fdf82ee45d28bdc10',\n    'exec-075': '0a4423d79ae67fa6cb8f293aa0c1b291',\n    'exec-076': '7d0598e6ede27e78bb619294ad2a6ac9',\n    'exec-077': 'bb3ebb2151ee939ca5bddbcebc6a3082',\n    'exec-078': '2a762183d1cea519f910934b0982b0c0',\n    'exec-079': 'd07cbd11030d1dd345fe8310a4e6a420',\n    'exec-080': '7add05940ae20a4e06e93a5684f3d9b6',\n    'exec-081': '39405d7af1ea78974f190db43d3b1945',\n    'exec-082': 'd33499008eafcc54afd71a7c0e341458',\n    'exec-083': 'cce0adfc544056b8a5198a6e2d1b6cb3',\n    'exec-084': 'b27e6257e07951f79baff1106479cb6c',\n    'exec-085': '5be15088d29a7d5c13ebf2a309acf80a',\n    'exec-086': '5343002b6216e2735960fe4c260c6165',\n    'exec-087': 'c9d8f78cd213096d941490df1039efcb',\n    'exec-088': 'c0c64bce53217a88919befa06dc5e31d',\n    'exec-089': 'c39228a1d7281b66962346b45c26565e',\n    'exec-090': '02d75a8cf61a572c9f85097ca1c4286c',\n    'exec-091': '8e3caac6c3bfc87b0972d3bed8a55fb1',\n    'exec-092': '9de489f541a23c00f55f85e7956aa0c2',\n    'exec-093': '51bae582b7e93b25af0e69bb7e07692d',\n    'exec-094': '310ef6ac5f0e0c807dc1fe981732a0a5',\n    'exec-095': '59d3d72101dcf65f2b402d211cffe544',\n    'exec-096': '03ceb29ea3ec88c7b6159a32d2a264d2',\n    'print-000': 'a39defa106312bf091758781881ffd8c',\n    'print-001': '9a69aab97847fbda11b83e50698a90a5',\n    'print-002': '6e70eac69000e9c822669ad53454e296',\n    'print-003': '4eb96461c7510c1c099d7518eb6e50b4',\n    'print-004': 'a63f4c5061747d60c41fe624847a13f5',\n    'print-005': 'acc935b585ab1a819bb7850a04edab4f',\n    'print-006': '43827ae08daaed2c8db9595122bd5db8',\n    'print-007': '2274ea4e467d98d65df7bd16a7312cd8',\n    'print-008': 'c1159011fadade7e7dd8bddc2e97485a',\n    'print-009': '388f9ba2e1d0c9ffb8b633ccc2fad4ac',\n    'print-010': 'f5fd9f62dce4a486d5c0e0aac1da9309',\n    'print-011': 'eeb8eae45f55f2850871fc5dfe0f8d42',\n    'print-012': 'ab4d6f6fabfb9c130648685d74eb818e',\n    'print-013': 'd79271521e70d1a48bb8e83c6922e683',\n    'print-014': '42b0ed5b22a701d801c3df256db78d77',\n    'print-015': 'ce83f0fdb9cab3faab4ea275ecf2b256',\n    'print-016': '26bf146917e4e70544cb1d90177acc94',\n    'print-017': 'dd30bfc6ae9ac25f3abf1cdeda968bd0',\n    'print-018': '8f36cf31ae888a8cbf635da20847169e',\n    'print-019': 'fced5231a97a980da8d29e5a06e8c788',\n    'print-020': 'b96f4e09907206c0af5aa03af97db68a',\n    'print-021': '28c23ceba0c329f099850a9d1ec1bf7a',\n    'print-022': 'eaa16c070049435e17adeb8858e2b35f',\n    'print-023': '038b67d711285a3981da7ed9beb0cac9',\n    'print-024': '8c46fb1a786cc474ed6ebe34da06ad6b',\n    'print-025': '97236b6f5871f39cf0a8ff87270cf987',\n    'print-026': '48d905f2f3b7a12f39e4a27d25f1c18f',\n    'print-027': '551f279458b5c6b5c01bc37ac3e2a43d',\n    'print-028': '0bc25e46d989492d754973074f8f08c2',\n    'print-029': 'b9f37fbb909d42d52fd1b587b9f5885f',\n    'print-030': '74712e11a7876b0b2c28f1e4a8eabc85',\n    'print-031': '823a5aebd4ff34ce38bc3a3a54881ec0',\n    'print-032': 'ad8005ea54b0922a5bf48fb16fdfb6d8',\n    'print-033': 'acfa54b3d48de18bddba2d5a82361214',\n    'print-034': 'b3e1168ddeb027901a175dd6fc71b36e',\n    'print-035': '47f0133efd934c4c1bcd0b1c3104b4df',\n    'print-036': 'da22d38d18955905d9532ec180ce9871',\n    'print-037': 'b4d186a10e08ba5512dba392734c9b75',\n    'print-038': '2b9709df86daa3c9c37711bc8d0376ad',\n    'print-039': '56be1e5375631de21dce04447100afa7',\n    'print-040': '8443f0f7201b317c628f17bb8936873f',\n    'print-041': '15758f0cfd2510106afebaa295e11012',\n    'print-042': '865a9820958fde11dcf701799ce286bc',\n    'print-043': '0cd55709f4c609029e6667e6e08f8e67',\n    'print-044': '227011a264e3528ecb926e9785918a43',\n    'print-045': '1b822632f2bfc8161fa11e05f866ec65',\n    'print-046': '01f65c6ab97086dea553af94dfbff0e3',\n    'print-047': 'efe6bd6c3f21804bb9c2cf56850cff60',\n    'print-048': '539117e98f83c80199027a9272833fb2',\n    'print-049': '421a37ef1a4ce2e994d1873832980060',\n    'print-050': '731f9e740ade79dc2f63438cb9516b00',\n    'print-051': '6ba2ab81c7504914384526c14cc711e0',\n    'print-052': '6bd6343b71b1e9b5523bd69d08cff4f4',\n    'print-053': '2d9e8c1c4c8f20e7153c8fccc4653d8f',\n    'print-054': '0792dadf7e4d1a0a14e26291d4621cd2',\n    'print-055': 'e472481c6b016b31cde9aa1a0e6300cb',\n    'print-056': '220219880d1a7f17f756f478d0212bce',\n    'print-057': '711c8938f7b55faa14ddd0ff934698b4',\n    'print-058': '50846a85a6e85618af3c98baba7871e2',\n    'print-059': '92b71191f18af99882c4250a574d8df0',\n    'print-060': '79b304a052a475c0039c97ec7f666927',\n    'print-061': '47a2de65862fcfcd4325479a2ad125d8',\n    'print-062': 'acaf8403c8439e9d0a796e62417fc5e1',\n    'print-063': 'ac00d2cc8a37f4ad3c54782d4a7d3259',\n    'print-064': '1e23202187993079eb57a1e4f7aba711',\n    'print-065': '13873605e376647f0c81d953d4c0d88f',\n    'print-066': '5d46d73906bbf40ca8a1cce5ceb00cc0',\n    'print-067': '4421c6fc6d64f2925fd25f9a5f4e9ea2',\n    'print-068': '9a1c7b04b20d92b3c43d92abffb8d5b4',\n    'print-069': '6efc1ed92f9d2536472b608d4ee98d64',\n    'print-070': '44435ff689857d4b5f84156c529ac2fe',\n    'print-071': '46dcbedcae514e546b18d11a2deb3e42',\n    'print-072': '63fe1820524e391f3aaa47cdebd66123',\n    'print-073': 'e185bd63a10924eb4ba2b281ef4f9851',\n    'print-074': '95c60d57e52bd702e88141e0883f8f30',\n    'print-075': '573128d2076e40c00724873a6d48409e',\n    'print-076': 'd16a912b7c2f512e5943c286d0044710',\n    'print-077': 'b65492e01dd0bdb3d6ee2b23002836e0',\n    'print-078': '4b5bbd51af775f4610a2792d5bd56431',\n    'print-079': 'e395c4be445ab0340dba6abad87cf9dc',\n    'print-080': '12e5e7a392b87e0b51a44481c0eac461',\n    'print-081': '8ab932bb1eff1d710f2d33e8c7fda1b7',\n    'print-082': '3c90b53a17f53735290ce844d316b3d4',\n    'print-083': '7fc6d59bf362bdb055b67e5eaa91ba85',\n    'print-084': '63619cd6da341fd563e00077cc7d4d46',\n    'print-085': '7176f258010caebeb08989e580416d15',\n    'print-086': '34edb3df7bc84d18cb6f87d83aa6508c',\n    'print-087': '539d021b54acf6dc8177e0d61abd78ff',\n    'print-088': '002238199f548c1f42eae13ad0cb962d',\n    'print-089': 'e2a6a941da8b9dfffba21a6535fb3cc6',\n    'print-090': '12b7773051039763a6afa81a60da77c4',\n    'print-091': 'a94af0430749a55a778a512774df7f16',\n    'print-092': '792eaa2d783d4747b7d7ef2be7dedaa8',\n    'print-093': '338ba3d13d142e596d9e0f5f106cb7bb',\n    'print-094': '622ca05375669eaf885fd7c1d4bb1701',\n    'print-095': '91d92818b78465923531f543e83afef0',\n    'print-096': 'b5c0c728f8f510563aaacb6cc150944d',\n}"
    },
    {
      "kind": "Assign",
      "line": 479,
      "endLine": 492,
      "text": "STAGE_GEOMETRY = dict(\n    total_child_commands=PROSPECTIVE_K_COMMANDS_COUNT,\n    kast_children=1,\n    local_initializer_stages=1,\n    kore_exec_children=97,\n    kprint_children=97,\n    prestartup_raw=('kast', 'initializer', 'exec-000', 'print-000'),\n    startup_probe=('exec-001', 'print-001'),\n    post_startup_state_prints='print-001..print-095 (95 states)',\n    charged_transitions='exec-002..exec-094 (93 charged steps)',\n    free_publication_transition=('exec-095', 'print-095'),\n    terminal_probe=('exec-096', 'print-096'),\n    arithmetic_child_wall_cap_sum_seconds=PROSPECTIVE_K_COMMANDS_COUNT * CHILD_SECONDS,\n)"
    },
    {
      "kind": "Assign",
      "line": 493,
      "endLine": 495,
      "text": "LIMITS = dict(wall_seconds=CHILD_SECONDS, sweep_seconds=SWEEP_SECONDS, rlimit_core=0, umask='0o077',\n              process_group='new session; SIGKILL to group at deadline and after exit; token sweep',\n              memory_cpu='tool defaults, as for the admitted native compile children; only the JVM is bounded')"
    },
    {
      "kind": "Assign",
      "line": 496,
      "endLine": 496,
      "text": "JVM_LIMITS = dict(jvm_heap='64m..512m', jvm_stack='32m', jvm_active_processors=2)"
    },
    {
      "kind": "Assign",
      "line": 497,
      "endLine": 502,
      "text": "EXPECTATIONS = ('expectation only, never asserted, authored or used to branch: exec-000/print-000 '\n                'normalises the initializer outside post-startup states; exec-001/print-001 is the '\n                'startup transition (rule 74) and initial post-startup state; exec-002..exec-094 are '\n                '93 charged transitions; exec-095/print-095 is the 0-charge publication transition '\n                '(rule 80) completing 95 post-startup states (print-001..print-095); exec-096/print-096 '\n                'is the separate terminal no-rule replay probe. Identities are only what raw logs show.')"
    },
    {
      "kind": "Assign",
      "line": 503,
      "endLine": 506,
      "text": "SCOPE = ('one-case F03 raw K capture: kast, driver-only $PGM binding, kore-exec depth 0 (exec-000) '\n         'then 96 fixed depth-1 steps (exec-001..exec-096), kprint on 97 states (print-000..print-096); '\n         'no recompile, kparse, krun, llvm-krun, SDK, native, decoder, assembler, oracle, comparison, '\n         'retry, install or network')"
    },
    {
      "kind": "Assign",
      "line": 507,
      "endLine": 508,
      "text": "IDENTITY_KEYS = ('interpreter', 'sources', 'primary_sources', 'pinned_files', 'tools', 'elf',\n                 'packaging_evidence', 'kprint_linkage', 'native_refs', 'compiler_closure', 'inventory')"
    },
    {
      "kind": "FunctionDef",
      "line": 511,
      "endLine": 512,
      "text": "utc"
    },
    {
      "kind": "FunctionDef",
      "line": 515,
      "endLine": 519,
      "text": "environment"
    },
    {
      "kind": "FunctionDef",
      "line": 522,
      "endLine": 527,
      "text": "sha256_file"
    },
    {
      "kind": "FunctionDef",
      "line": 530,
      "endLine": 534,
      "text": "file_digest"
    },
    {
      "kind": "FunctionDef",
      "line": 537,
      "endLine": 552,
      "text": "read_exact"
    },
    {
      "kind": "FunctionDef",
      "line": 555,
      "endLine": 560,
      "text": "read_store"
    },
    {
      "kind": "FunctionDef",
      "line": 563,
      "endLine": 564,
      "text": "open_exclusive"
    },
    {
      "kind": "FunctionDef",
      "line": 567,
      "endLine": 575,
      "text": "write_exclusive"
    },
    {
      "kind": "FunctionDef",
      "line": 578,
      "endLine": 585,
      "text": "append_ledger"
    },
    {
      "kind": "FunctionDef",
      "line": 588,
      "endLine": 602,
      "text": "entry"
    },
    {
      "kind": "FunctionDef",
      "line": 605,
      "endLine": 614,
      "text": "tree"
    },
    {
      "kind": "FunctionDef",
      "line": 617,
      "endLine": 631,
      "text": "check_sources"
    },
    {
      "kind": "FunctionDef",
      "line": 634,
      "endLine": 646,
      "text": "check_primary"
    },
    {
      "kind": "FunctionDef",
      "line": 649,
      "endLine": 663,
      "text": "check_pinned"
    },
    {
      "kind": "FunctionDef",
      "line": 666,
      "endLine": 671,
      "text": "store_executable"
    },
    {
      "kind": "FunctionDef",
      "line": 674,
      "endLine": 683,
      "text": "elf_magic"
    },
    {
      "kind": "FunctionDef",
      "line": 686,
      "endLine": 700,
      "text": "store_refs"
    },
    {
      "kind": "FunctionDef",
      "line": 703,
      "endLine": 726,
      "text": "packaging_evidence"
    },
    {
      "kind": "FunctionDef",
      "line": 729,
      "endLine": 742,
      "text": "kprint_linkage"
    },
    {
      "kind": "FunctionDef",
      "line": 745,
      "endLine": 769,
      "text": "nix_support_flags"
    },
    {
      "kind": "FunctionDef",
      "line": 772,
      "endLine": 779,
      "text": "locate"
    },
    {
      "kind": "FunctionDef",
      "line": 782,
      "endLine": 800,
      "text": "compiler_closure"
    },
    {
      "kind": "FunctionDef",
      "line": 803,
      "endLine": 811,
      "text": "compile_attempt_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 814,
      "endLine": 819,
      "text": "compile_input_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 822,
      "endLine": 842,
      "text": "candidate_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 845,
      "endLine": 859,
      "text": "input_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 862,
      "endLine": 886,
      "text": "prospective_plan_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 889,
      "endLine": 902,
      "text": "compiled_content_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 905,
      "endLine": 907,
      "text": "pinned_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 910,
      "endLine": 924,
      "text": "compile_ledger_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 927,
      "endLine": 939,
      "text": "engine_ledger_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 942,
      "endLine": 964,
      "text": "runtime_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 967,
      "endLine": 980,
      "text": "protected_snapshot"
    },
    {
      "kind": "FunctionDef",
      "line": 983,
      "endLine": 988,
      "text": "inventories"
    },
    {
      "kind": "FunctionDef",
      "line": 991,
      "endLine": 996,
      "text": "identity"
    },
    {
      "kind": "FunctionDef",
      "line": 999,
      "endLine": 1036,
      "text": "preflight"
    },
    {
      "kind": "FunctionDef",
      "line": 1039,
      "endLine": 1066,
      "text": "processes"
    },
    {
      "kind": "FunctionDef",
      "line": 1069,
      "endLine": 1073,
      "text": "kill_group"
    },
    {
      "kind": "FunctionDef",
      "line": 1076,
      "endLine": 1091,
      "text": "sweep"
    },
    {
      "kind": "FunctionDef",
      "line": 1094,
      "endLine": 1135,
      "text": "launch"
    },
    {
      "kind": "FunctionDef",
      "line": 1138,
      "endLine": 1143,
      "text": "protected_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 1146,
      "endLine": 1171,
      "text": "stage_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 1174,
      "endLine": 1211,
      "text": "child_stage"
    },
    {
      "kind": "FunctionDef",
      "line": 1214,
      "endLine": 1247,
      "text": "parsed_problem"
    },
    {
      "kind": "FunctionDef",
      "line": 1250,
      "endLine": 1281,
      "text": "initializer_stage"
    },
    {
      "kind": "FunctionDef",
      "line": 1284,
      "endLine": 1292,
      "text": "kast_command"
    },
    {
      "kind": "FunctionDef",
      "line": 1295,
      "endLine": 1300,
      "text": "exec_command"
    },
    {
      "kind": "FunctionDef",
      "line": 1303,
      "endLine": 1304,
      "text": "kprint_command"
    },
    {
      "kind": "FunctionDef",
      "line": 1307,
      "endLine": 1357,
      "text": "expected_prospective_k_commands"
    },
    {
      "kind": "FunctionDef",
      "line": 1360,
      "endLine": 1392,
      "text": "run_stages"
    },
    {
      "kind": "FunctionDef",
      "line": 1395,
      "endLine": 1415,
      "text": "postflight"
    },
    {
      "kind": "FunctionDef",
      "line": 1418,
      "endLine": 1431,
      "text": "persist"
    },
    {
      "kind": "FunctionDef",
      "line": 1434,
      "endLine": 1482,
      "text": "execute"
    },
    {
      "kind": "FunctionDef",
      "line": 1485,
      "endLine": 1499,
      "text": "main"
    },
    {
      "kind": "If",
      "line": 1502,
      "endLine": 1503,
      "text": "if __name__ == '__main__':\n    sys.exit(main())"
    }
  ],
  "selected_functions": [
    "utc",
    "open_exclusive",
    "processes",
    "kill_group",
    "sweep",
    "launch"
  ],
  "selected_globals": {
    "CHILD_SECONDS": 30,
    "SWEEP_SECONDS": 3,
    "TOKEN_NAME": "SHERLOCK_K_ATTEMPT_TOKEN"
  },
  "not_called": [
    "main",
    "execute",
    "child_stage",
    "preflight",
    "any old ledger/reset"
  ]
}

===== END BODY 7 =====

===== COMPLETE BODY 8 Full historical passiveREAD-IMPORT-PINS metadata =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/UIREQ021-F03-K-caller-materialized-review/F03-next-capture-and-projection/PASSIVE-READ-IMPORT-PINS.json
BYTES 137390 SHA256 6334fcc0e2900b282611ad5fa11d2150a68070bb87e534de104326d81cae3905
{
  "count": 514,
  "files": [
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/models/sherlock/qa/k_capture_observations.py",
      "bytes": 41478,
      "sha256": "2260ebb2d2bbfc6d1cb3f6d2a6715f023637c6d76e401fe105c42616053ab8ac"
    },
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/models/sherlock/qa/k_observations.py",
      "bytes": 7686,
      "sha256": "540128fdb7f693a7b1f415898fd74bd6c1918df50a7a48ce602471b6e85f9b07"
    },
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/models/sherlock/qa/k_terms.py",
      "bytes": 5666,
      "sha256": "c79a852cbda9259c736d36da29132486d10903007fd3adc755e7d0585b8366ca"
    },
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/models/sherlock/qa/quint_observations.py",
      "bytes": 16774,
      "sha256": "595a4f272ea2a8fee898ed72afa03f4212ad50f94eecf6a8bc4372a8e128bf48"
    },
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/models/sherlock/qa/check.py",
      "bytes": 81758,
      "sha256": "004646fb8a5dcd7666d209360bf932c67920226d50a638500d51a8f95b83b8c5"
    },
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/models/sherlock/qa/host_observations.py",
      "bytes": 4912,
      "sha256": "61b8258595a298231679362cb3974ae176b6970e7e4475388252d59da545fcdc"
    },
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/models/sherlock/qa/source_reference_facts.py",
      "bytes": 1484,
      "sha256": "b4603118a977db9f21012907361349e5c29fd24346e04cecf5ea018f81048fde"
    },
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/models/sherlock/reference/check-reference.py",
      "bytes": 13260,
      "sha256": "1b22a0c4dc14ac0dabd5fe4e8c5ca5ff85485e9b22dd2673a4645f5145cfa94b"
    },
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/models/sherlock/k/main.k",
      "bytes": 16249,
      "sha256": "b3746ff51dd7999b046ccb23237595605420adcfeebc0c04c0ad0f1396b11d41"
    },
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/crates/mori-core/src/sherlock/normal_oracles.rs",
      "bytes": 39165,
      "sha256": "3421828bada394a5f1aa7b9ccc2fa52182db88adf7f2bfd58bf1d871e9d6bbe5"
    },
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/crates/mori-core/src/sherlock/extra_normal_oracles.rs",
      "bytes": 63959,
      "sha256": "ce0e83e6fc09507f88c2bd2a523514ed087f14c15d75d1ed58ab84427b5a7b00"
    },
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/models/sherlock/oracles/normal-programs.json",
      "bytes": 10202,
      "sha256": "ef87f94f7e5d22a75b1c2e5e61af016b08175beee9a3599e3e69ddf92945d32f"
    },
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/models/sherlock/oracles/normal-prefixes.json",
      "bytes": 53119,
      "sha256": "dca67b553d7483fdf7d9148e7f4bf1a6022b42b8843635f33f23c58a2415d56d"
    },
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/models/sherlock/oracles/extra-normal-programs.json",
      "bytes": 3721,
      "sha256": "dd85e5d400f24e9be5e2ff017f4b8c141a0bf6e4270053917b735cbe5153f153"
    },
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/models/sherlock/oracles/extra-normal-prefixes.json",
      "bytes": 80130,
      "sha256": "acf460094b258910bad0499fb8feda0cd85b680023939800ad714d2cb71bee16"
    },
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/docs/audits/2026-10-16/sherlock-full-original-fixtures/frozen/fixture-oracle-data-01/fixture-normal-programs.json",
      "bytes": 4420,
      "sha256": "71e780f207c862e6b7061b9b24cb51c3f5243874e256442d46d009e9fc937113"
    },
    {
      "path": "/home/charl/Moriarty/.worktrees/sherlock-parallel-implementation-20261016/docs/audits/2026-10-16/sherlock-full-original-fixtures/frozen/fixture-oracle-data-01/fixture-normal-prefixes.json",
      "bytes": 165696,
      "sha256": "13d00607c8eac53d6d607502e00395b50f6a2f2a9be386f2ba8bbc5bb167a49b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/328-F03-corrected-unadopted-assembler-review/source-only-inspection/models/sherlock/qa/assemble_k_f03_observations.py",
      "bytes": 63677,
      "sha256": "4dcbd830ded58c7161c455a8988b553f1bc490e14a86077ecc92a687116a3d1a"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/UIREQ021-F03-K-caller-materialized-review/F03-next-capture-and-projection/test_actual_f03_passive_api.proposed.py",
      "bytes": 5785,
      "sha256": "2947e035111b3e6a37f554f62e913a3a42c25ca82933d7cd6a3a14ae67181b4d"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/receipt.json",
      "bytes": 1642368,
      "sha256": "c745f760ce9ead61d53dcc02a3a0faedd2306688366f3f8530e5f2d258f56b5f"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/K-COMMANDS.json",
      "bytes": 413065,
      "sha256": "db62fb14ce8d80e024dfb1d29e1b64dcbe264815690dee6c98619b6e90463110"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/input/F03-fuel093-stack064.ui",
      "bytes": 359,
      "sha256": "c1ab51c62fc70ea5693e1d9046445cba6a03eb3222273c045b511913c0f6b91b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-parallel-20261016/k-actual-01/COMPILED-MAIN-RULE-SPANS-01.json",
      "bytes": 85954,
      "sha256": "9e77ddfe74acaa1e2deccaa1fcde70794494dd3583362b3f9a6f58473d9e941c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-parallel-20261016/k-actual-01/compile-input/models/sherlock/k/main.k",
      "bytes": 16249,
      "sha256": "b3746ff51dd7999b046ccb23237595605420adcfeebc0c04c0ad0f1396b11d41"
    },
    {
      "path": "/usr/bin/python3",
      "bytes": 7477160,
      "sha256": "52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41"
    },
    {
      "path": "/usr/bin/timeout",
      "bytes": 11807104,
      "sha256": "f84e76ea4da1e0c4e92254bd0d7dccdabe2c8b3098e734f27997dae3ee5d8e02"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-000/state.kore",
      "bytes": 6229,
      "sha256": "3fd874c1c331d99133ec0486adaf9109084701408ab6b874c1a482129cc59959"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-000/stderr",
      "bytes": 152,
      "sha256": "8a23f256a5bb1b5195afd568ce2ad5b399b27129f3d356ddbe3597f54b39c345"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-000/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-001/state.kore",
      "bytes": 6284,
      "sha256": "b2e5d98b7677a624f5bc99a949fd45b11a0d7b4fc9c93a1c280e728326996096"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-001/stderr",
      "bytes": 8755,
      "sha256": "e87a7f93afe95a2b26feb5770c7f123080d9a55fa77d4493b1e08c3fc2bb3687"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-001/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-002/state.kore",
      "bytes": 6448,
      "sha256": "3c64e2045d1a8b8723189eca4d99b69805105fde731d88f9974bdbb026deeb54"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-002/stderr",
      "bytes": 7937,
      "sha256": "1ae11cbef8556b69478e992b39552473694f534561f933659107e69c92101510"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-002/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-003/state.kore",
      "bytes": 6225,
      "sha256": "f373c2682d42bcfca86f9562dbb292d3e5a144ccd098d7ea6d32392bb11a13a3"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-003/stderr",
      "bytes": 8131,
      "sha256": "d265cba4b49f054a40f274b45a0e9c7eb81cfd015492e5ae92c0e3b1f728f879"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-003/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-004/state.kore",
      "bytes": 6034,
      "sha256": "028e0f1e972f89406cbc68c5c4fcbeb898d10ad896643f4d920eefb303d7f351"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-004/stderr",
      "bytes": 7898,
      "sha256": "73aaf60c77533fb653fb52250ef9d12833e49bb3718be0c63b94cae1b1c6c9ad"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-004/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-005/state.kore",
      "bytes": 5883,
      "sha256": "4aec62794e2d5b757fa0e826afd8ceca25cf125ef59f866d52720dda564cd22b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-005/stderr",
      "bytes": 7687,
      "sha256": "8df090e2a7c86b354ca31dd2473b4be9b7fbaab3520073fc3b31d78980afb36f"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-005/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-006/state.kore",
      "bytes": 9733,
      "sha256": "3b04f677cfadefabd6249acadbbf71df9d73b99de2d8458e2f552547f3c48ee2"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-006/stderr",
      "bytes": 7496,
      "sha256": "b4475f99cab51c792bd111ff664ecded4ebe2d03a81bcdb5fdf4d23df86b0c4e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-006/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-007/state.kore",
      "bytes": 8935,
      "sha256": "657bf5f3d0c28018e11005576f38c97683e14b8981a78be325c63cbdb4264664"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-007/stderr",
      "bytes": 11816,
      "sha256": "a5d1dd7f9885d92e7002ae04fc6f0446d8e4ec3190aab7b93179194d8ed8079b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-007/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-008/state.kore",
      "bytes": 9181,
      "sha256": "f810eb87cc0ae28b27d43da6f4814e02d1c807d00de422b9e0870e7128cc16a4"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-008/stderr",
      "bytes": 10958,
      "sha256": "acb2f92c93ea77c77b4a036b0f6367e64bc2ac8e0bf64127bee609ef81ad7b6b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-008/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-009/state.kore",
      "bytes": 8626,
      "sha256": "978f5ba2998643378d7e5ad02e91a4d6fa7fe86cd5f18cd055e1cafd338b6161"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-009/stderr",
      "bytes": 11234,
      "sha256": "8e3fdd7a34df3d06728a0d9b19f0c44c8963504c9d313ce698f506f9270ce327"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-009/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-010/state.kore",
      "bytes": 11994,
      "sha256": "1ed64b15902256a01a973cb648bb254e54e3eba82c3ed70f5f625fae450fc84e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-010/stderr",
      "bytes": 10719,
      "sha256": "4c73449f8eea4d69d9fb6f9b43faae5c4cba23661fe83678f5cea84c946a1481"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-010/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-011/state.kore",
      "bytes": 9900,
      "sha256": "e9c64e0c4ba7e62f44ea92c3271dd8291b77ad82faf595f2f9f4ccdedfaceaa7"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-011/stderr",
      "bytes": 14567,
      "sha256": "2c83ac11cec5d1004e3f1820c1acc97a72259d2c7a4790716af36acc8072d027"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-011/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-012/state.kore",
      "bytes": 10988,
      "sha256": "d8750c3feca3a3a6a762243a3a87433ee8edf9817dc57f0b811ab890016d93a2"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-012/stderr",
      "bytes": 12289,
      "sha256": "b5635dccdab64eaef4e95e1f7180c3a2de330e5148418dec1c025384ea30fdc9"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-012/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-013/state.kore",
      "bytes": 11043,
      "sha256": "abe49ecc480a45cf1b28b3c1b6c6d986125e143e04e5d21b57388555c49d2206"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-013/stderr",
      "bytes": 13527,
      "sha256": "7c7a557ef16e0815d93f534f2651509093ff66e264193996ba6f86960a0a10cb"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-013/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-014/state.kore",
      "bytes": 10809,
      "sha256": "a919aae782d9c340f681d9aec527757a5e99ca6fc5a99186b544238891698678"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-014/stderr",
      "bytes": 13496,
      "sha256": "2b7a15d3f847c20188fddc24415c96f3d92462e193113bea10890ef5d3a5cc96"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-014/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-015/state.kore",
      "bytes": 10289,
      "sha256": "71ed5050adc4fc23b06d5bad2ae301f86a5cdd6e720bf084525031d4f35a413c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-015/stderr",
      "bytes": 13242,
      "sha256": "e0775b2dd01f51e4c531af56659f1c56186d2cf3ce793ed894ca789bb2453032"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-015/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-016/state.kore",
      "bytes": 13736,
      "sha256": "587ec276d87dd86c90c95e7ee2745cce467f688d974c5b4e3a7f5b18b0d22a36"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-016/stderr",
      "bytes": 12642,
      "sha256": "0c02de7e7bc531f500209833b47df13037e9864a44f9e8c87f8e457023e1c67d"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-016/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-017/state.kore",
      "bytes": 12404,
      "sha256": "fb393e5ef0bd9902eb6dc85f06c4ebe112448aaf70629f0e8e439cf581750d98"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-017/stderr",
      "bytes": 16589,
      "sha256": "fa900f8f8ddc7d12c0e275700a40c7ccd857ee944cb0402fd46fccc6dfd9f193"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-017/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-018/state.kore",
      "bytes": 10062,
      "sha256": "c1b0b0a109ae5d9bd82e294fed39fe44a2702dd5138d28f124cb043a8b147285"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-018/stderr",
      "bytes": 15087,
      "sha256": "1bd707577ea07a142aacfb870a8dce5112b09cf4a83fcabca564899f1eef9e71"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-018/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-019/state.kore",
      "bytes": 17486,
      "sha256": "40a83b977aa17b64a5c58006ea484c9d189f75ce50e05850ea825ab2b1b5e45f"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-019/stderr",
      "bytes": 12645,
      "sha256": "214b7fe909006db9e5fdbd65049d17d5e578556eccbc52e227550fd9894e891e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-019/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-020/state.kore",
      "bytes": 13553,
      "sha256": "eb9adac4c03b9d75cf218912a073460dada78df466d927b67cf4a212883c3802"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-020/stderr",
      "bytes": 21169,
      "sha256": "34fcbb8ea943e4b6b0e612d49c73c69abebb9f7c3a42acd13cb8b19076568bae"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-020/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-021/state.kore",
      "bytes": 13650,
      "sha256": "b0de2df01599ea8659b0f4c0f214ce6d61605658ebf6a103c6f46ec14859a8ca"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-021/stderr",
      "bytes": 16650,
      "sha256": "d5b8da1d870a872052317fc2cfa014e25dcc5c34e3f6632396994eb6f098562c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-021/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-022/state.kore",
      "bytes": 10334,
      "sha256": "a7a0a08912c0d41c346f706833a0b815f263ebb2f54b749b39a78ce3f98fa7b9"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-022/stderr",
      "bytes": 16767,
      "sha256": "3b531c5ede686ff65cda5906f003bf33cf8abff7f208237050c1758303b741dd"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-022/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-023/state.kore",
      "bytes": 17730,
      "sha256": "87041c0969640d99985ff13ed830fa42642c24cbb7b27e746f389d53eb0f17f0"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-023/stderr",
      "bytes": 12911,
      "sha256": "9889ccf9a361deb6d13f58b447e29b7dd67e46ec928591a30fc0564ede7722c2"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-023/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-024/state.kore",
      "bytes": 13847,
      "sha256": "2260fcc15be08500348bb955cdb12197e03a0ba67bfdc7bf6a4b644bb8effeed"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-024/stderr",
      "bytes": 21397,
      "sha256": "9fae6a9992a356240c447950358836777da39b03c1346f7452d97bceadc88745"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-024/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-025/state.kore",
      "bytes": 14560,
      "sha256": "cc706fc813210926f17572cc186421c9363e7e437a5b8e1549e501531d2ab12a"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-025/stderr",
      "bytes": 16974,
      "sha256": "09fed4acb9f5a876ee07b4821ed7ed5dc3a3489a1288120a33340fafa9d345e6"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-025/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-026/state.kore",
      "bytes": 10953,
      "sha256": "5b9d8ac06e01e9f5a4b075774aa745af5ffcdb2acd5d1157d03f0d337676419a"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-026/stderr",
      "bytes": 17787,
      "sha256": "2caeea12bc96f7caf0f12f37e4d0917eac80b048e6094f3ccec7872231f9a959"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-026/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-027/state.kore",
      "bytes": 14803,
      "sha256": "a3838a1c1c992d5df8ee21f1e4c9c31d4fca6f3b3865bbbe81c530592fb1fd1f"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-027/stderr",
      "bytes": 13610,
      "sha256": "554f51d7b802cd8d14b0f6048c6ff5c260af90922f0ed6554f60c22e0904693a"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-027/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-028/state.kore",
      "bytes": 13985,
      "sha256": "d97d9d4804ff585381d3b03664baf6d7e0fa15c95c5356a9abe76b93e1486209"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-028/stderr",
      "bytes": 17930,
      "sha256": "1bc991890063b4946a57d8968fea27b0f8c77191bcfc886e5279da4a5b8bb9cb"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-028/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-029/state.kore",
      "bytes": 17939,
      "sha256": "1c7f3d0e8ae98d50782cff9ed086c21a9e5b5d15dfe2fc4b03e90f4e4fbfa8de"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-029/stderr",
      "bytes": 17052,
      "sha256": "d717230c433e22360e4216538e8e404e95400cfccd4c53e3043e34662cf5afdb"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-029/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-030/state.kore",
      "bytes": 14452,
      "sha256": "60a9cd2585f3da770312d775ecb390d8b3c2933723eeb25e65e6ab3935534219"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-030/stderr",
      "bytes": 21566,
      "sha256": "a2ffc885776d1aea3951cc40bded1ef1c12d6c3385dede5660887fc652ce9208"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-030/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-031/state.kore",
      "bytes": 17010,
      "sha256": "95d38ea62a8837c3ce75de327f4b235b2123b65979b98b97fc11429611ba52e2"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-031/stderr",
      "bytes": 17455,
      "sha256": "97b3276d6be7e4402bb7e83f1c9babc03f364fcc0756bcea408cdb3344221074"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-031/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-032/state.kore",
      "bytes": 15735,
      "sha256": "1a680101bc056720e3f44364190cdfe0002d5334adc66dbeabe6df236585f5c6"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-032/stderr",
      "bytes": 20393,
      "sha256": "321a4ef8babf59bf45d77d809a5c54919f34a84196fe567ac839045b290a9590"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-032/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-033/state.kore",
      "bytes": 16448,
      "sha256": "1f5184c54716bdd403b4af07c30ec38f46b49ee460797d397296f936dcf794d9"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-033/stderr",
      "bytes": 18984,
      "sha256": "f8d68340f7f03c65ddfd29ded57ea270e0a8e2bcdec4d20508e4d8954ba2d725"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-033/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-034/state.kore",
      "bytes": 16099,
      "sha256": "85d4d34e75619c0b627bf8b4750d10401f935edabc04ceaa5ab78fd07e7f4ef5"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-034/stderr",
      "bytes": 19797,
      "sha256": "99e43db70b0eed270914539dc259e402c917148f603a26701b62b70fa34a67f5"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-034/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-035/state.kore",
      "bytes": 15865,
      "sha256": "e689e7fa64c2f46ca4c9475f805a4c1bbed3fe71ca3cf8acff28b05e8de9d30a"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-035/stderr",
      "bytes": 19362,
      "sha256": "d63bbca553608686535855e234bad3dab4719aa1f3d6708b99ce077f0a0c9818"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-035/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-036/state.kore",
      "bytes": 15345,
      "sha256": "c7c840cadff93d650780a766241fec36a9276500c6cf5789ec1e39bb50b4be55"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-036/stderr",
      "bytes": 19108,
      "sha256": "a8e32c4089ac0d5040461161f583c53c436d1a67fd0885a2cece50469b038ac1"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-036/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-037/state.kore",
      "bytes": 17942,
      "sha256": "8c829fb74cf0b66f1438df5c9e0922c2cf67ea9bc077e0dd2830702ae4805f6c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-037/stderr",
      "bytes": 18508,
      "sha256": "2bc06a1b0b889ef8cf83ac22d1fd2839d0c2e2f19f3cc8f1755598a8fae90e29"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-037/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-038/state.kore",
      "bytes": 17005,
      "sha256": "06821bc047ac72a35feb71e45013f4813ef146d72cf98d36bf5023157eabe24f"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-038/stderr",
      "bytes": 21505,
      "sha256": "5d85d47717bdfa94c7c24b69cf3bf7d38a5e6e4f005462aa419aa06dc38b43ed"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-038/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-039/state.kore",
      "bytes": 15542,
      "sha256": "5528d34a6dca16b6bd72cf60a7061e89f61df5550da3b656702a562f2518f22f"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-039/stderr",
      "bytes": 20448,
      "sha256": "5b00bba779487584b1a403de53f1517e9de90780293d4fdeacc36cf31184f780"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-039/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-040/state.kore",
      "bytes": 21306,
      "sha256": "3ddcb616ae0dc852d80498c7399d6a117213b0ef4358ae6e31d81e6540f2193b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-040/stderr",
      "bytes": 18935,
      "sha256": "554456c01be0e95f3afee76db5bdf9d055ae65833533fd40586b04b31a85c04a"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-040/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-041/state.kore",
      "bytes": 18627,
      "sha256": "53cfe9352bcbf0bce3d67eea4a380ba27480d9a016b96870fbe14d5564533817"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-041/stderr",
      "bytes": 25599,
      "sha256": "c2d4ac0320b575f5a3241ca139b5813422a2f9ed6aee78255f5c81daa7f48eb0"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-041/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-042/state.kore",
      "bytes": 18724,
      "sha256": "3d77d59368a26ac60d1ae94e18b3f774b9e5f5fa71ce474d638811f929be480d"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-042/stderr",
      "bytes": 22434,
      "sha256": "cb7baa08d9ff89806a520eb7ce7e1579d089e302e7d1003576cf743cdc41dd89"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-042/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-043/state.kore",
      "bytes": 16178,
      "sha256": "e30858c78117351ab01714170a3d32c570d849833b368f3c55e7f1750f1a532f"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-043/stderr",
      "bytes": 22551,
      "sha256": "b400a94a4c7bc44c04e707b625095ddc05b028d6e63ce8e7c10ac5eb1e3c93f6"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-043/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-044/state.kore",
      "bytes": 21914,
      "sha256": "2b8b7347db0e9481a38835eff2ce3e5388c9454343d927f2cac8a84729f8f772"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-044/stderr",
      "bytes": 19565,
      "sha256": "e3f8cefd4aed96ca0e22c91d161b60d65b80d530064c7b2872c0faa981a2f99e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-044/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-045/state.kore",
      "bytes": 19285,
      "sha256": "b3084b21aaa59736ef1a7132f5882a120148a04f54adba95492ab586843f754e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-045/stderr",
      "bytes": 26191,
      "sha256": "74fb3edaca1ba0bf67c827f111943b3dbe4c45221e8bcf618658427e943046fd"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-045/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-046/state.kore",
      "bytes": 19643,
      "sha256": "3c64b5bf5b2425e8baea9cd7dd83d0c70f948a2434cc76e2cefec51416d4528d"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-046/stderr",
      "bytes": 23122,
      "sha256": "1437f7e72a6f91d12fbc69ba51cdbc8017d9b0a7de496effcade5c646f388865"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-046/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-047/state.kore",
      "bytes": 16422,
      "sha256": "b424a98150ccef5a9eb1308b40df4feaf1553fc791814cb492c92eb5dd75b1c9"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-047/stderr",
      "bytes": 23530,
      "sha256": "5a65a613d4e6ee8259c099318a596b2381cf8a47a1581f351969fcba8327d12e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-047/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-048/state.kore",
      "bytes": 20272,
      "sha256": "0251af949af07385785ac5cf42eb6c076f841049e9be8c8eb999e9c1f6f9c30b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-048/stderr",
      "bytes": 19839,
      "sha256": "d9ef519986ddf782952592bdc669f26f448f774f7f15c79535d66bb61897ea71"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-048/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-049/state.kore",
      "bytes": 19434,
      "sha256": "594ef8ab6dc1ce8148c80ffde48b1f2698a688184d255b119622a609b5c53224"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-049/stderr",
      "bytes": 24159,
      "sha256": "07918898303692eaa04014d55d71af2b6d557400dca9033f91a0c49b3b26d238"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-049/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-050/state.kore",
      "bytes": 22558,
      "sha256": "7af71c79ff83ac2dbc2f136f3153fe1f25cf872b456496e76fd813a05b23e3c5"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-050/stderr",
      "bytes": 23261,
      "sha256": "cd218934782c5511817f077ef8c4105aa45ed88c3b19ad9070336ea0c7b47154"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-050/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-051/state.kore",
      "bytes": 20265,
      "sha256": "69a6f61e08cefb6e80aed794e7f99582ddac1d0371e72bc978780799ee1f033f"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-051/stderr",
      "bytes": 26845,
      "sha256": "9e5249982a042338fb2c735da6a3470cff58103d7eb7e225c35927d7d7290712"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-051/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-052/state.kore",
      "bytes": 22053,
      "sha256": "064beffdbb60c36ee98649c7678854ecae9688f92b76e97ae1c4db695b7abe0a"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-052/stderr",
      "bytes": 24028,
      "sha256": "89295b3963cd9f7ac2ad1740706b42efcdd8c186145f73acaef0a254528a385e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-052/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-053/state.kore",
      "bytes": 21517,
      "sha256": "eb63f2f5a6af286740b3cc2b757c5f83419acdadaf55601037e5fbf50973cd6d"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-053/stderr",
      "bytes": 26096,
      "sha256": "e4b1fe602b7b5266ef23c6e7108da1c7885d597ece934e4c4589c7a156f27029"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-053/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-054/state.kore",
      "bytes": 21875,
      "sha256": "215c9dafb53a23460c655ad93c1b81b2e97bc2270e6f8d06ea2f34b62c38b6a6"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-054/stderr",
      "bytes": 25476,
      "sha256": "18242a43b6c764f933f34bcde2eb063bf884f027567811125ac046902067e48e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-054/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-055/state.kore",
      "bytes": 21182,
      "sha256": "bba6fea37222526673b30a227ab58fb19055f091f7e0a137160eed19fbad2a2a"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-055/stderr",
      "bytes": 25884,
      "sha256": "fa6beaca85472e4a099d7354da205003662615a268b2bb93c6967b568eeb2b7d"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-055/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-056/state.kore",
      "bytes": 20948,
      "sha256": "bcbc8fa0b4e9b32defb169f2a7ef53e09488a564e64414dc77dfb74cd121ef38"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-056/stderr",
      "bytes": 25105,
      "sha256": "cc7797d281df3b49cc9e010f7716c0a254de0b2698599793da79ab6cd03c4a03"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-056/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-057/state.kore",
      "bytes": 20428,
      "sha256": "03774e380042833d9fc914325a5afb9028da093230aa87bce4b6bc412ae75719"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-057/stderr",
      "bytes": 24851,
      "sha256": "0e93976543af7896ed66de5516d603a93870327d59ccc0523e71fb280fbea40a"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-057/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-058/state.kore",
      "bytes": 22215,
      "sha256": "b3347caa126e5e38b393126eb54b7ed19bc0ea8928b027b2599485fae0673cc5"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-058/stderr",
      "bytes": 24251,
      "sha256": "a9a2c825a15afe6e706e8ed6525fa0f3bb669b48f5bdb96338d9b625fd5b0ff7"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-058/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-059/state.kore",
      "bytes": 21653,
      "sha256": "84840ce66c70f70909733a0deb42cc5349c7b576d5076256ab2afad913540386"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-059/stderr",
      "bytes": 26338,
      "sha256": "1d832cdbec3d8713ab0405e1b3e58aba86cc81567ec3ba9734af06e7c8023414"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-059/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-060/state.kore",
      "bytes": 20989,
      "sha256": "9e033bd966a65d21e610e92ea430d0f94e433f57b0a555cbbf07f7d4c8f7cc47"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-060/stderr",
      "bytes": 25706,
      "sha256": "5b04d144e7ee942368784b34089f3b7ee15a5218b5cc6d277007f01ae1eb6560"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-060/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-061/state.kore",
      "bytes": 25173,
      "sha256": "fdcd50901a5f38b577d73c00b68c9c09a5c8724c1db5c03099260b41d8f5066b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-061/stderr",
      "bytes": 25042,
      "sha256": "c968e3cff2ab39302abbebc07561a575b24ad79e134756c184c7a461eceb5a9f"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-061/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-062/state.kore",
      "bytes": 23648,
      "sha256": "d0070e68353f07526f79a229dd82d0692f920e36633c1b67c722917c76e075c3"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-062/stderr",
      "bytes": 29926,
      "sha256": "fa66c7831a0416a87a16fd2033a728e3fac2a904ef65a229d7292d02f1daabb1"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-062/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-063/state.kore",
      "bytes": 23745,
      "sha256": "f1d8093c2e7eb8970b4768e0aab48b0f682f906ae62a1b641970b321fda3d40a"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-063/stderr",
      "bytes": 28015,
      "sha256": "978b8ecdcde119861879c778f540dd8057c027b1160ee35d27fbaf927197212d"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-063/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-064/state.kore",
      "bytes": 21929,
      "sha256": "e0ccfb313d959ef50eb46d5daef3d99594d305bb5ae1c912948a1b53774cf7d5"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-064/stderr",
      "bytes": 28132,
      "sha256": "574daf3cb688e8aa5f3eb108e8949becb51613c83586e87ec677db1509888389"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-064/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-065/state.kore",
      "bytes": 26085,
      "sha256": "f75f13cb8d514c8827fd6a9088807b23d7c6653caf2d543efef1c3628952d1d4"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-065/stderr",
      "bytes": 25976,
      "sha256": "be733c6c40645640135f3f825d6744f85a679de4a840ee6e5117bd02d33c009d"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-065/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-066/state.kore",
      "bytes": 24611,
      "sha256": "fdebcd935da9d47718f099867446409e5f84f275b1aba043619d10a17f5b8584"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-066/stderr",
      "bytes": 30822,
      "sha256": "cb37072df0417135e5effbd051231f488ee31371b5a3eac569199e8f4675be54"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-066/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-067/state.kore",
      "bytes": 24634,
      "sha256": "54e26525dd155fe58b9053c291ac86dfa4e31d089cf8ba6fa58e817a771090f4"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-067/stderr",
      "bytes": 29008,
      "sha256": "f0e773372a8fa606e772a527427056b96f4c5b3bded95d1b186a446111247461"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-067/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-068/state.kore",
      "bytes": 21818,
      "sha256": "9372129e7699e1e52b08fd16ef60155d58a13ea81d3e3ca0388a85b97d5a75ae"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-068/stderr",
      "bytes": 29031,
      "sha256": "b818b366fb31a1a940c6eb35ef93223e14c17f47cd23313adc0e9c7d7f470f78"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-068/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-069/state.kore",
      "bytes": 25668,
      "sha256": "6789db98a1371179afd090cca09a99a95fa4c6ac42232cb635d4a9a0a5ffb4a9"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-069/stderr",
      "bytes": 25845,
      "sha256": "d74af48d69b53eb52cb08da2f373ccbc060681a62d54c39b54e719cbc16e1096"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-069/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-070/state.kore",
      "bytes": 24810,
      "sha256": "80d5a444e1633e2ef8b7c29c1e3a9c46318ccf5aa55b748f9c89c234456bce5e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-070/stderr",
      "bytes": 30165,
      "sha256": "4c5c49ee748755e6659b3ef40698b5d90b5aaac4bbab4c7813e4d7725d8e9757"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-070/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-071/state.kore",
      "bytes": 27144,
      "sha256": "782904db5cc3fd5cfbdf990df1093a576121d06f9a8512b94008678fda3d65b2"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-071/stderr",
      "bytes": 29247,
      "sha256": "016ccd4eb316104b0126903873dd9f0b339f3f8f90fb13abf41559c5ae3b112d"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-071/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-072/state.kore",
      "bytes": 25946,
      "sha256": "ec10672b238af6ed20d7504b40302b2200d6bbc36dfe36772cf71d01b8d60078"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-072/stderr",
      "bytes": 31941,
      "sha256": "79461347382b3d75eaeee3f6459b3a4aec82cd716675941246750470cb5210c5"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-072/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-073/state.kore",
      "bytes": 27004,
      "sha256": "826bfc9da04c26cb2297464ea81caaddb4304ed8c3231dabb7be0a7778c6c677"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-073/stderr",
      "bytes": 30319,
      "sha256": "3bc8c4cf2a45a4af3e4e780e440f4c8df0291175e09315e450bc8c16bc6c797c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-073/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-074/state.kore",
      "bytes": 27127,
      "sha256": "bf23d778919e3fce04ad8fe74f26f5a949f50353010c77c8403983931e4405f0"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-074/stderr",
      "bytes": 31557,
      "sha256": "df887fc05877d6bbab603f8fb5b0ac88961c036eb1b81834948deebecd692716"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-074/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-075/state.kore",
      "bytes": 27150,
      "sha256": "75cf69e1440968da8f4aecb8bfa8e9bbe9b360d340093ce22f2f73572284b191"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-075/stderr",
      "bytes": 31646,
      "sha256": "9d6b0d4f941088c75449c1b18018ba36075c2ab531dc5db5233281d733aaf2d6"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-075/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-076/state.kore",
      "bytes": 26173,
      "sha256": "e0bcb333098ba56e9a6aa8e6f62cb4a6a9904e1aae59f12d150433aa7ebba251"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-076/stderr",
      "bytes": 31669,
      "sha256": "c79afbe5cc5c064ed3f5c1959104bc70b8ba78e385eae433e5f53fd6867cfb4a"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-076/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-077/state.kore",
      "bytes": 26445,
      "sha256": "730b0797144957389df61629d43d44ae2f25523cd1c5444a2123e8b41a477910"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-077/stderr",
      "bytes": 30606,
      "sha256": "ba082de0db687a7d2db5dfe44f88e1bf21399f4f11cbe6887c3134a01a42a4e6"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-077/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-078/state.kore",
      "bytes": 24774,
      "sha256": "9ca3403cfb056de23b1ff7d5c07237cba10b87faa705462176a1e043306e953b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-078/stderr",
      "bytes": 30948,
      "sha256": "4daffb7e7604699af7d8706c9c3e6897dc7a02c94fa413966874081efce7539b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-078/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-079/state.kore",
      "bytes": 25137,
      "sha256": "a89d7121cf8b2176f75372f7afc6c4e82ee13da6cb0203b3aa90b59052def7da"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-079/stderr",
      "bytes": 29047,
      "sha256": "d5e265f730e1d75f3181e4127c6d939eeae57f6f31c2a464ac8022ac6ead49be"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-079/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-080/state.kore",
      "bytes": 24998,
      "sha256": "67533c0fc4b7fb0c3550d82f275edd3c654d40c4e2fa24dc3facb1dd58187685"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-080/stderr",
      "bytes": 29376,
      "sha256": "d90bfd0aa370838a5e0c19acf6d95ce94df387346600e13f69ed4a7da46f9c1b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-080/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-081/state.kore",
      "bytes": 23433,
      "sha256": "253d54fe4bab12d651dd03f4aa3bb25187f8baea72d1772992981be211c1cf2a"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-081/stderr",
      "bytes": 29217,
      "sha256": "53047d9b01b223a7fe1880c8f36dc5718a621ac4e3827d973e2e991b475e7d98"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-081/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-082/state.kore",
      "bytes": 21588,
      "sha256": "cf1e9d2d1199c24e35dda7121d06335e8459de67045bdc5f2f6d1d8061c30c32"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-082/stderr",
      "bytes": 27486,
      "sha256": "ad0e47fd640b0d183bd21c0cbab31076ba0be510d21671aca9a32bb01c67bce7"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-082/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-083/state.kore",
      "bytes": 20359,
      "sha256": "f9edc8078941ca142fd22e68f8db94f05ccc172544ae8ba132201ee29df76f4d"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-083/stderr",
      "bytes": 25595,
      "sha256": "fdd867a102924b6eeaeb4805d078735271617eeb256b872d065451cef74ff6aa"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-083/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-084/state.kore",
      "bytes": 20209,
      "sha256": "c6745b347656235b4a516efa1ea770f1d426557385d5b0559480034f92a88d2b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-084/stderr",
      "bytes": 24332,
      "sha256": "df0ee0da989dcf72c8ef52325f5d7fd2d048038fcd451b1296767f86ed694b9f"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-084/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-085/state.kore",
      "bytes": 17751,
      "sha256": "16e9199d54930aa46e8784541bf907e459baac3411d088e0d616aebcfe312b57"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-085/stderr",
      "bytes": 24162,
      "sha256": "ba0493aa79db9b595a20200842ca7bf7c936267665515e8adcd342e0674f6c49"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-085/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-086/state.kore",
      "bytes": 15836,
      "sha256": "8558f94540a60c91f2571c0f878ed476e967ed2a63ee4c68a2d552fb506fa260"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-086/stderr",
      "bytes": 21194,
      "sha256": "b3f3ad3669b9fcf9e4cc61feb0c7fc1362f9fe65d7590bdb1e76149e30613102"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-086/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-087/state.kore",
      "bytes": 14911,
      "sha256": "b113a5ca062bc29201bab3f88cf01554aa0a1bdc91db9e431fa05d0a5c021455"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-087/stderr",
      "bytes": 19183,
      "sha256": "358a436aa7c8104d4dc9a8d731ba4013446252388b9ac2a224d5801e9ba56425"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-087/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-088/state.kore",
      "bytes": 14761,
      "sha256": "515b913d1a7bb5a0b5def9635a8cc1f9a351c2f54b1d5673f956d33358adf991"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-088/stderr",
      "bytes": 18224,
      "sha256": "4cf6dee9be0837ffa741ef3ef3c3c12bf080fcf6e9cad68efab84d96cb0c942b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-088/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-089/state.kore",
      "bytes": 11938,
      "sha256": "0559b6227cc6e41875552eb5800df35f0eedbce85edd9a6b255d480d3abeb37b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-089/stderr",
      "bytes": 18054,
      "sha256": "20d479147e49c69215db405b4454f3d38d8e15fbf687a3c2dc8bedeb712ab468"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-089/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-090/state.kore",
      "bytes": 9992,
      "sha256": "6e9f195174a5a503a2c8977dbb9c916d5900ed3ce2809fe4289de2198092b365"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-090/stderr",
      "bytes": 14621,
      "sha256": "14407c7315dadf9bcb57d1b2a6fd3d13dce5b6c2b09c6022ba077843a0694c80"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-090/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-091/state.kore",
      "bytes": 9431,
      "sha256": "d2cbeae4665f631a8c70624c581f04b0a07616227da68ea7b023db54fc9d37ad"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-091/stderr",
      "bytes": 12529,
      "sha256": "78ab334bdf3b8b5191e457d8e3b4c4eb26ed26a5fddbea7422b987502a319748"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-091/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-092/state.kore",
      "bytes": 9281,
      "sha256": "13daf6f5d60ad6414c490cb3e094fa150fb22d0ca33ced3f952820b69b7ba69c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-092/stderr",
      "bytes": 11934,
      "sha256": "63686be9df0c70f7a41cfb51803c608640f99397367b3af851d69a8231582cb8"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-092/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-093/state.kore",
      "bytes": 6112,
      "sha256": "bd2d523374354069561b3039c4383b9b508665cf82eb88bd08e8ddafb230044c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-093/stderr",
      "bytes": 11764,
      "sha256": "0d35cc7faa469ffa888c471aac7c9f2e70aa23900112bc4152354f791f6f500c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-093/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-094/state.kore",
      "bytes": 4527,
      "sha256": "2d321ff9569ba94f3ca52e5000d510da87e60b50fa2963b8a4affab677cb1e17"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-094/stderr",
      "bytes": 7885,
      "sha256": "be50b15ae0b19317ba7ab20330afd552b046aae7846ca4c59dd69d82057fbe1e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-094/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-095/state.kore",
      "bytes": 4290,
      "sha256": "e1c80e3c7b04750398ad530946c9213a8b2892a976ad613fca15b79288cd38f2"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-095/stderr",
      "bytes": 5968,
      "sha256": "865472fb63435babb0fbad3cf11d89ce24116190bc0fdcabefc22f0833c03016"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-095/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-096/state.kore",
      "bytes": 4290,
      "sha256": "e1c80e3c7b04750398ad530946c9213a8b2892a976ad613fca15b79288cd38f2"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-096/stderr",
      "bytes": 5420,
      "sha256": "5e565a754d226791b720e22c67453b79efcdb7ecc0d8937dda75e01aa353600c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/exec-096/stdout",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/initializer/initializer.kore",
      "bytes": 3444,
      "sha256": "db26f75e08bd9048009707bf4a2fead2cf3216d5fdd2627e61836a6602ee7cfa"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/kast/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/kast/stdout",
      "bytes": 3291,
      "sha256": "30e34d5936ecb9e771c4b02a5c5a6b465d0b7aacc0ae7d055fbd65c97183b913"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-000/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-000/stdout",
      "bytes": 512,
      "sha256": "5500c86175883c0d6eb27eab0e54de727807733bfa78f5d29e3bf9eb7a26ad78"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-001/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-001/stdout",
      "bytes": 776,
      "sha256": "194eef61dab0cc95dff7f104a855579a0f12cae3cd38ae1adcf81330016e5378"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-002/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-002/stdout",
      "bytes": 808,
      "sha256": "72b24c0dbfe63ab2c303fb04af1f3f8d1580a6ff8fb311db67a200dafc098fb1"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-003/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-003/stdout",
      "bytes": 802,
      "sha256": "9fa362281c507299f5aeb1ca24751242fe26475feb63cd6f0cb0cfa2fcaea3ed"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-004/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-004/stdout",
      "bytes": 787,
      "sha256": "3e4a730d544a0fdbdee83d30d17aad931b832eda8242917aac9d5f43b2a716cf"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-005/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-005/stdout",
      "bytes": 755,
      "sha256": "7493c36643a9a37132b3dc09a8f8263fe02b42dcc9985b28057925642cf9805c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-006/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-006/stdout",
      "bytes": 1043,
      "sha256": "29a53b90974307da2aa778e9db8440d5b6d7e1c8c7838389b0d8aa62dcb6773c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-007/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-007/stdout",
      "bytes": 974,
      "sha256": "98ee2e0ce7d7d936d9768ae410c9689185dd56b2ce425b581acaa4d379e7ae9c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-008/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-008/stdout",
      "bytes": 990,
      "sha256": "c16a360e7a698736582e19f1a2f676f840c6a45cf3aeb3d4aa2a105f8809b245"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-009/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-009/stdout",
      "bytes": 984,
      "sha256": "b6780b68612ffc05787b13181dd0d794a453a95fd3056787e918cbc1f061db2b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-010/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-010/stdout",
      "bytes": 1170,
      "sha256": "afc2c7baac45a2d4fec3c78e0ce6e30c00464b8eb07ac661e0ba82681fdde9f9"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-011/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-011/stdout",
      "bytes": 1084,
      "sha256": "0e30eae554e1c266c207e50d011bc87028f37cbeb989fe3709c8b7d125e3925c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-012/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-012/stdout",
      "bytes": 1150,
      "sha256": "00e207b33a1c6d616f97e62d54f2ce74818920139357a98bb45bc2733aaf5462"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-013/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-013/stdout",
      "bytes": 1127,
      "sha256": "745cb094ab107e4da5fdf8b697fd1a9ed3fbd513855a62d7121cd1932fdcb9a5"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-014/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-014/stdout",
      "bytes": 1124,
      "sha256": "40283af6961850a06569be85bc6d7141279d53def0e096e42753104d5ae8c932"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-015/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-015/stdout",
      "bytes": 1077,
      "sha256": "5ada917f23e6a57463a536f6a9f8f17e8dfac2e1b08558f2edcac2f1229db598"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-016/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-016/stdout",
      "bytes": 1238,
      "sha256": "7f6901de872009a7562adaf08ca1e4cb7f079f518e36426bdd0334f55463d0ba"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-017/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-017/stdout",
      "bytes": 1145,
      "sha256": "427fd9d2ba8c9c2ab02ca25934e3486a224f6498e020a0f0e5cbbe2a407022f2"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-018/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-018/stdout",
      "bytes": 1059,
      "sha256": "fcc2c171b210e2146577c7110425243b901bf3ef4f6799fd23be914bfb5b1280"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-019/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-019/stdout",
      "bytes": 1415,
      "sha256": "30ae02fef6acb5e8a198fbce69cb0d133bc1125c88688a09cd8c4aeda03d711b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-020/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-020/stdout",
      "bytes": 1243,
      "sha256": "17dab1b7e2ce4b56f5efa9d4333c33a861782466858ed351e5eb9bbaca133e01"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-021/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-021/stdout",
      "bytes": 1240,
      "sha256": "0a368d86976e4d2228eda28aa71f0aa762638d48e921915bb14d897cf4278ce6"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-022/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-022/stdout",
      "bytes": 1069,
      "sha256": "49823b98539e64eb6ab17bcf1c98453a26c0e99938b9044963a2cf3a226a11cc"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-023/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-023/stdout",
      "bytes": 1433,
      "sha256": "e46045857c0680cbc89306ac6ff6e4803cd49cfcb27d73502552f1f5baf88c8c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-024/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-024/stdout",
      "bytes": 1261,
      "sha256": "044334cac10f0a123d014d5b7f3a55894d3da7a76622b9ce980410b2c01a2b64"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-025/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-025/stdout",
      "bytes": 1304,
      "sha256": "a15cb0e4a8ab50608cbd6b26ce2628bafe8c2fa7823d500ab424261ea4f33f42"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-026/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-026/stdout",
      "bytes": 1106,
      "sha256": "e0dadeb3f35ce33603a870bbb17b5217aa3be857fb25e89cfbeab756060581cc"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-027/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-027/stdout",
      "bytes": 1394,
      "sha256": "0c7609d2b99d0959ddfd84f67aa9b4f4f6d87da98bc730fe6e6f0e1c65fa3c81"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-028/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-028/stdout",
      "bytes": 1325,
      "sha256": "16129ac97ea2d7ffb102364ac6b22c1e2ecab89abe5998d115b7e3ac3db8e3c4"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-029/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-029/stdout",
      "bytes": 1507,
      "sha256": "0ab0d188260396e684c4f538d1bc13d08301f2a110bf1ba2b1832094fe04cdfa"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-030/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-030/stdout",
      "bytes": 1335,
      "sha256": "12f20ab9f19fe1a21531c5b5cf42aef755da852165c8ea83f99ba4ec9cbd5b6d"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-031/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-031/stdout",
      "bytes": 1475,
      "sha256": "73bde3e536cc985d33cb80545006ed090ca34df87b9e21c581eab9273f63d1b0"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-032/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-032/stdout",
      "bytes": 1412,
      "sha256": "656c11da85b59c31f86fb735bfb2d333fca3bc4dd59769a7ea483cbb15796108"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-033/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-033/stdout",
      "bytes": 1455,
      "sha256": "e87bf946cdeb32affd67799f6ecf03a1d73fb7102fc207b29daf7bd1bfceeb44"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-034/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-034/stdout",
      "bytes": 1432,
      "sha256": "e5de58fcd556a5d20464a737e9463f9c1d080ecaf5cd35d18f343cd0b468a308"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-035/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-035/stdout",
      "bytes": 1429,
      "sha256": "fcd3e9bb51a5f29dcd53a1f33a7acc8655d8383edd84decfa7979024c99efd6a"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-036/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-036/stdout",
      "bytes": 1382,
      "sha256": "faa5c35182c347c20e4ff0f0610975fd53ef1468a4b1ed83a770bb7501fa5ca6"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-037/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-037/stdout",
      "bytes": 1497,
      "sha256": "edbe11d1eb236791f7d414c1300b112b708ef484bc3a4c7100312fdbd6e18129"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-038/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-038/stdout",
      "bytes": 1427,
      "sha256": "a77e9d6028e511a48364891ea5b5f22b03fe22b528f7f426c650e4c25e1ae55c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-039/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-039/stdout",
      "bytes": 1364,
      "sha256": "4ff27e3f4a83f462ed3fb5170cfbfc0949992d17f8e0e630740cdb6ca8c47383"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-040/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-040/stdout",
      "bytes": 1628,
      "sha256": "08f111b5e1ed314dbc334057996a89aa0aeb94d995fbb2f4ae777e9b2804486c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-041/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-041/stdout",
      "bytes": 1502,
      "sha256": "d49611d2b097af90eb7b72d13f08c5617a23157fe871acce6df8f01e8781859d"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-042/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-042/stdout",
      "bytes": 1499,
      "sha256": "74a5511f07e5625dfd133ceb55d517c3666ecd6a41c7b6a2bb99338fb006f1d2"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-043/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-043/stdout",
      "bytes": 1374,
      "sha256": "39844a772600d08f6424d4f1afcae3480c8f5cb5698464a6627c715339889ab7"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-044/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-044/stdout",
      "bytes": 1646,
      "sha256": "c3e25a11e83b2164ac016b8e041436ee95cbb2e8f30ca56bbc55cbd2ad974627"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-045/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-045/stdout",
      "bytes": 1520,
      "sha256": "519d90b0836bd76963dd5fde87e60ca948544067c2b1cb1e76f4bb8964268ca2"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-046/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-046/stdout",
      "bytes": 1540,
      "sha256": "b489127b24eb232f1ed0c6c825dfaec7f344124c3fdc1c3c8c1ae06a9a649416"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-047/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-047/stdout",
      "bytes": 1388,
      "sha256": "941b8629ca3aa7b8b88e84a6968aa429248af6ba3c8bc4ef816f54527e6b169c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-048/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-048/stdout",
      "bytes": 1676,
      "sha256": "6be45dba30d2a55449716c08f6ac3791ae3f1ce2a67dd53dc478a74e548ac46e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-049/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-049/stdout",
      "bytes": 1607,
      "sha256": "ccb17e6e136956ee5e706dc275aa5561d5e20d8ae4c22b10bdadfb075c7ba8e0"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-050/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-050/stdout",
      "bytes": 1743,
      "sha256": "b11751d523b96154c7beafb234fcb97c6d28530dc19515b18c2ed9e638ce4555"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-051/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-051/stdout",
      "bytes": 1617,
      "sha256": "de5d596ab3f930a63ba7903a45ad2865fb5541d4a71b8acf5f555fc5357a029a"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-052/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-052/stdout",
      "bytes": 1711,
      "sha256": "9c35cf725d5ad78778c1bc6e578f926e234f0047702a4aa7fb69d9ea53766f79"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-053/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-053/stdout",
      "bytes": 1671,
      "sha256": "383fa4612abef8672e568e5955d5bd966c8bac69a968271d16825002b01c5a17"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-054/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-054/stdout",
      "bytes": 1691,
      "sha256": "2ff471e54c863293bcc276df0e24aa52be0dde2feee6fcab23605fb087e03331"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-055/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-055/stdout",
      "bytes": 1668,
      "sha256": "ea038fdbfa3711a7ea64752f83dabb09a195e48b6b731bdc1a9741cdad98ad9e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-056/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-056/stdout",
      "bytes": 1665,
      "sha256": "376d30c23de3b1a5b28c56876f944ff80541754176c7e14b5b9bbf15adf308f1"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-057/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-057/stdout",
      "bytes": 1618,
      "sha256": "0600adb1818ba2e0357941d2b8d121340139317ad08c126b68008712ddcee017"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-058/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-058/stdout",
      "bytes": 1687,
      "sha256": "8c558805e5e12433e61b4a15fb37a6933fe5b9a70bd704c3b76bf442038e16cd"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-059/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-059/stdout",
      "bytes": 1640,
      "sha256": "d8880d17c87b9c866a7192ee9f431dddf8503a87761f1503760aa71a2d72f67b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-060/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-060/stdout",
      "bytes": 1600,
      "sha256": "801fa46a97ba1fcb579d20fd1efebaadeec59a7353cb94afe03fdbc19e612989"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-061/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-061/stdout",
      "bytes": 1772,
      "sha256": "f904f1f5504fbeec4e42f82d9f7da8d97ba61bce2391a50ad7c7b05625972fc0"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-062/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-062/stdout",
      "bytes": 1692,
      "sha256": "ce26705c7d1dd72bb4e0cd6a68e64e4e809053bca31ad68beb2911e8f34493bf"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-063/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-063/stdout",
      "bytes": 1689,
      "sha256": "f4f8741833056852a08583264b1f8e0e632705a8cf456d2f430946611c7a600a"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-064/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-064/stdout",
      "bytes": 1610,
      "sha256": "32fbaf5605b170a01aebc6c5c35badec40b69911e727e9a532c9512683f0d406"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-065/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-065/stdout",
      "bytes": 1790,
      "sha256": "21864554a8f830a7bccacf0bbc79bebb4de3b52b1473cefc49dd93328ebf37f3"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-066/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-066/stdout",
      "bytes": 1711,
      "sha256": "0058e3631a19488ae615531f9bdb9641fafd59dc01782125b9761ab11a7f1f56"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-067/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-067/stdout",
      "bytes": 1708,
      "sha256": "84a7464095e08fe9657e81f104c14e50b19fe03fe2ee435770ff49fdcb362f70"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-068/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-068/stdout",
      "bytes": 1601,
      "sha256": "365928adf56ce2977f4f8f2156b12bbd0c13729236239ff70b0c0012d3357d3f"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-069/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-069/stdout",
      "bytes": 1889,
      "sha256": "4ec0c7d0931c4bd57f16f8adddf8008fb7dcca029b5cabfb7b8023261ea04f7e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-070/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-070/stdout",
      "bytes": 1820,
      "sha256": "280c7d51c8acfa66a5aa9883bbbaa920f9f9c12215dcffdfb9393c7696d55750"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-071/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-071/stdout",
      "bytes": 1910,
      "sha256": "580bff69ee9d5c0ef0146609d6cd3b8de2a63114f5d1028b9e35c6fa2558dcf1"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-072/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-072/stdout",
      "bytes": 1831,
      "sha256": "b0792c39ce3fc20d6d7eddb6dce2a2dc19bd41b753dc0bea122172cf3867a998"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-073/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-073/stdout",
      "bytes": 1879,
      "sha256": "e5ed3f4e79702c84bad11f23afc09e430f7b8d8682f05445ace76e483b3c21b0"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-074/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-074/stdout",
      "bytes": 1862,
      "sha256": "5889eb504e5ef610801e773b97e829c60dc1a64c6c637b2e5fc63802df494490"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-075/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-075/stdout",
      "bytes": 1859,
      "sha256": "d85a6edf195e8e108a1746e9a283a5d4b90593048a899dfc89ca3f944166df04"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-076/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-076/stdout",
      "bytes": 1836,
      "sha256": "80c5b3ab4bb9a777719e5b6877ffc6d5a81d437e777dc1f2c8426638d9b31b05"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-077/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-077/stdout",
      "bytes": 1849,
      "sha256": "f2a3665e33537ec78b3487cf4e1ec6bd3dd07ca64cc022725ef126e7cf1b8d56"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-078/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-078/stdout",
      "bytes": 1699,
      "sha256": "f9174e0469b816fc39498dc44ea769792cbf953c003fb7e3d1e991c62c8ed40f"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-079/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-079/stdout",
      "bytes": 1682,
      "sha256": "005f7c1b76430bd59d14394e8100ca7ee3c7d4faf432e5f83d0e06e5bd138129"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-080/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-080/stdout",
      "bytes": 1667,
      "sha256": "8ebf5893b8ed76bd380ad9869a5cc7692a410c657a3b40f2b1be012fc220063d"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-081/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-081/stdout",
      "bytes": 1624,
      "sha256": "2467d8a5048be92619953f1fa2d12b8bf11153a7022ccd49200cb383c7c331c1"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-082/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-082/stdout",
      "bytes": 1565,
      "sha256": "6171089445c2c25432c79d289e0f620ea9c745e0b36f2347d3e7a696e6d0fe05"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-083/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-083/stdout",
      "bytes": 1539,
      "sha256": "b59cdcdfa3e8922af1acd63667cac8df4868d85eb570187f66288ef6e6672c53"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-084/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-084/stdout",
      "bytes": 1516,
      "sha256": "86adae66c892ba2e88cf3e399dcbbc75d6e6da12b7fae348f65f2df7d3de93f6"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-085/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-085/stdout",
      "bytes": 1409,
      "sha256": "69b1ba7525955f775f9773e25e8cfffa32ec8aadd4454cc375f48b71cd32f62f"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-086/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-086/stdout",
      "bytes": 1328,
      "sha256": "de1c5f9f5cb33211131879ba8d07e4e89bc11fc951e4810fadec3513c884ae0c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-087/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-087/stdout",
      "bytes": 1302,
      "sha256": "4cd6abe7b21e2498a34500efeaba5c215852fced51df6238b930ce323875e8b0"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-088/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-088/stdout",
      "bytes": 1279,
      "sha256": "d744e6d5935257c86ea6c27782b7d7365ca2d8d4ca095797a5f65c8c3c00fc07"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-089/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-089/stdout",
      "bytes": 1127,
      "sha256": "5097982f659a4e48e00ed8c4f860144acd494dcfac88c165ce02966feb4141de"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-090/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-090/stdout",
      "bytes": 1023,
      "sha256": "ce470b953dd632446f61c48bcebf5e040c4dd7efa9a69d6f5745d68debdc8c0a"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-091/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-091/stdout",
      "bytes": 997,
      "sha256": "31bc1d64adeada6e726a0a48ee3c181b255a1afc0062f0b8bf36500029fd1bdf"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-092/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-092/stdout",
      "bytes": 974,
      "sha256": "8f3da75cf07ea8f2c4f33b6665254628a51231fe5b0de75ed15bee9cbe889d33"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-093/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-093/stdout",
      "bytes": 776,
      "sha256": "ee13dd0d2392bf3a0786e16a21cb65ad5c85abc1ffbff239dcd39c3a9a1a3d79"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-094/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-094/stdout",
      "bytes": 649,
      "sha256": "51fd4994bef7a0205900c24f1f9a2b9b4dc0446bc1ea390f8496ef7f8690c657"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-095/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-095/stdout",
      "bytes": 633,
      "sha256": "b553b705e391f993a54d355217af972167c36841805a084a893fd004120beb4e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-096/stderr",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/actual/k/print-096/stdout",
      "bytes": 633,
      "sha256": "b553b705e391f993a54d355217af972167c36841805a084a893fd004120beb4e"
    }
  ],
  "stdlib": "ExistingPythonstandardlibrary/runtime trustedlocalclosure; no newinstalledwrapperorwholehostattestation claimed.",
  "futureInputs": "QuintITF and projectedbundles notyetavailable; bindactualRoot outputreceipts beforelaterconsumption."
}

===== END BODY 8 =====

===== COMPLETE BODY 9 Read/importscopeandremaininghostpremises =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/revision02-phase01-import-and-actual-premises/READ-IMPORT-SCOPE-QUALIFICATIONS.json
BYTES 1383 SHA256 32e4310e0c56f534ab5242d8723e4e754b43e2700634676bbba3a8e2610803ad
{
  "supplied_full_passive_read_import_manifest": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/UIREQ021-F03-K-caller-materialized-review/F03-next-capture-and-projection/PASSIVE-READ-IMPORT-PINS.json",
    "bytes": 137390,
    "sha256": "6334fcc0e2900b282611ad5fa11d2150a68070bb87e534de104326d81cae3905"
  },
  "original_registered_full_manifest_descriptor": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/READ-IMPORT-PINS.json",
    "bytes": 1274580,
    "sha256": "2427379d20bb32c0c9a5d9f77b49c5bac39d1bd67fa39b7664c96cc85c2a6289"
  },
  "full_passive_metadata_rows": 514,
  "stdlib_qualification": "ExistingPythonstandardlibrary/runtime trustedlocalclosure; no newinstalledwrapperorwholehostattestation claimed.",
  "scope": "This oldmanifest mixes unused historicalmodel/source/operationinputs and toolpins; listing it does not claim all514filesarecurrentorreadbyselectedlaunch. No protected oracle bodies opened. Existingusedtool/JARclosure remains pinned in original sourceaudit; exactmissingKorePATHalias entries are separately bound.",
  "no_hidden_import_execution": true,
  "no_extra_dynamic_library_inventory": "No ldd/tools/imports/librarycodeexecuted here. SharedlibraryandPythonstdlib trustedlocalpremises remain explicit as in existingregisteredroute."
}

===== END BODY 9 =====

===== COMPLETE BODY 10 Actual adapter/rawhelper/kompiled/PATHdirectorylistings =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/revision02-phase01-import-and-actual-premises/CURRENT-IMMEDIATE-DIRECTORY-LISTINGS.json
BYTES 27021 SHA256 7ed6ebc26adfd5e34996ce40519125855ac03c0631b265e7a103d0df72edae37
{
  "status": "READONLY_CURRENT_SNAPSHOT_NOT_FUTURE_ATTESTATION",
  "directories": [
    {
      "directory": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter",
      "entries": [
        {
          "name": "complete_k_wire.py",
          "kind": "regular",
          "mode": "0o644",
          "bytes": 13453,
          "mtime_ns": 1792403136491913846,
          "device": 2096,
          "inode": 69597620,
          "nlink": 1
        },
        {
          "name": "nominal_trace_codec.py",
          "kind": "regular",
          "mode": "0o644",
          "bytes": 14258,
          "mtime_ns": 1792403136491823211,
          "device": 2096,
          "inode": 69597617,
          "nlink": 1
        },
        {
          "name": "render_input.py",
          "kind": "regular",
          "mode": "0o644",
          "bytes": 7417,
          "mtime_ns": 1792403136491870802,
          "device": 2096,
          "inode": 69597619,
          "nlink": 1
        }
      ]
    },
    {
      "directory": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/actual-c6-schedule-first-arm-continuation-20261019/source",
      "entries": [
        {
          "name": "compare_prefix.py",
          "kind": "regular",
          "mode": "0o644",
          "bytes": 3207,
          "mtime_ns": 1792383594883625720,
          "device": 2096,
          "inode": 69407911,
          "nlink": 1
        },
        {
          "name": "complete_chunk_wire.py",
          "kind": "regular",
          "mode": "0o644",
          "bytes": 3245,
          "mtime_ns": 1792383594883708358,
          "device": 2096,
          "inode": 69407913,
          "nlink": 1
        },
        {
          "name": "complete_k_wire.py",
          "kind": "regular",
          "mode": "0o644",
          "bytes": 13275,
          "mtime_ns": 1792383594883582953,
          "device": 2096,
          "inode": 69407910,
          "nlink": 1
        },
        {
          "name": "decode_continuation.py",
          "kind": "regular",
          "mode": "0o644",
          "bytes": 4794,
          "mtime_ns": 1792383711526893736,
          "device": 2096,
          "inode": 69408417,
          "nlink": 1
        },
        {
          "name": "decode_prefix.py",
          "kind": "regular",
          "mode": "0o644",
          "bytes": 4434,
          "mtime_ns": 1792383594883661694,
          "device": 2096,
          "inode": 69407912,
          "nlink": 1
        },
        {
          "name": "kore_continuation.py",
          "kind": "regular",
          "mode": "0o644",
          "bytes": 5112,
          "mtime_ns": 1792383594883317770,
          "device": 2096,
          "inode": 69407907,
          "nlink": 1
        },
        {
          "name": "match_scope_evidence.py",
          "kind": "regular",
          "mode": "0o644",
          "bytes": 8105,
          "mtime_ns": 1792383624426903094,
          "device": 2096,
          "inode": 69407931,
          "nlink": 1
        },
        {
          "name": "nominal_trace_codec.py",
          "kind": "regular",
          "mode": "0o644",
          "bytes": 14188,
          "mtime_ns": 1792383594883384303,
          "device": 2096,
          "inode": 69407908,
          "nlink": 1
        },
        {
          "name": "prepare_continuation.py",
          "kind": "regular",
          "mode": "0o644",
          "bytes": 2423,
          "mtime_ns": 1792383711526893736,
          "device": 2096,
          "inode": 69408415,
          "nlink": 1
        },
        {
          "name": "primary_relation.py",
          "kind": "regular",
          "mode": "0o644",
          "bytes": 18723,
          "mtime_ns": 1792383594883923999,
          "device": 2096,
          "inode": 69407906,
          "nlink": 1
        },
        {
          "name": "render_input.py",
          "kind": "regular",
          "mode": "0o644",
          "bytes": 7374,
          "mtime_ns": 1792383594883503587,
          "device": 2096,
          "inode": 69407909,
          "nlink": 1
        }
      ]
    },
    {
      "directory": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled",
      "entries": [
        {
          "name": "README.md",
          "kind": "regular",
          "mode": "0o600",
          "bytes": 2886,
          "mtime_ns": 1792405210624964533,
          "device": 2096,
          "inode": 69612752,
          "nlink": 1
        },
        {
          "name": "allRules.txt",
          "kind": "regular",
          "mode": "0o600",
          "bytes": 63345,
          "mtime_ns": 1792405210609399128,
          "device": 2096,
          "inode": 69612748,
          "nlink": 1
        },
        {
          "name": "backend.txt",
          "kind": "regular",
          "mode": "0o600",
          "bytes": 7,
          "mtime_ns": 1792405210850248967,
          "device": 2096,
          "inode": 69612754,
          "nlink": 1
        },
        {
          "name": "cache.bin",
          "kind": "regular",
          "mode": "0o600",
          "bytes": 2307754,
          "mtime_ns": 1792405208456682340,
          "device": 2096,
          "inode": 69612745,
          "nlink": 1
        },
        {
          "name": "compiled.bin",
          "kind": "regular",
          "mode": "0o600",
          "bytes": 2974054,
          "mtime_ns": 1792405210844682107,
          "device": 2096,
          "inode": 69612753,
          "nlink": 1
        },
        {
          "name": "compiled.txt",
          "kind": "regular",
          "mode": "0o600",
          "bytes": 380620,
          "mtime_ns": 1792405210548662773,
          "device": 2096,
          "inode": 69612747,
          "nlink": 1
        },
        {
          "name": "configVars.sh",
          "kind": "regular",
          "mode": "0o600",
          "bytes": 84,
          "mtime_ns": 1792405210623806490,
          "device": 2096,
          "inode": 69612749,
          "nlink": 1
        },
        {
          "name": "definition.kore",
          "kind": "regular",
          "mode": "0o600",
          "bytes": 1903957,
          "mtime_ns": 1792405211568713149,
          "device": 2096,
          "inode": 69612757,
          "nlink": 1
        },
        {
          "name": "macros.kore",
          "kind": "regular",
          "mode": "0o600",
          "bytes": 10,
          "mtime_ns": 1792405211567083076,
          "device": 2096,
          "inode": 69612756,
          "nlink": 1
        },
        {
          "name": "mainModule.txt",
          "kind": "regular",
          "mode": "0o600",
          "bytes": 32,
          "mtime_ns": 1792405210624010349,
          "device": 2096,
          "inode": 69612750,
          "nlink": 1
        },
        {
          "name": "mainSyntaxModule.txt",
          "kind": "regular",
          "mode": "0o600",
          "bytes": 32,
          "mtime_ns": 1792405210624073011,
          "device": 2096,
          "inode": 69612751,
          "nlink": 1
        },
        {
          "name": "parsed.txt",
          "kind": "regular",
          "mode": "0o600",
          "bytes": 346528,
          "mtime_ns": 1792405208548944170,
          "device": 2096,
          "inode": 69612746,
          "nlink": 1
        },
        {
          "name": "scanner",
          "kind": "regular",
          "mode": "0o700",
          "bytes": 342496,
          "mtime_ns": 1792405205238584807,
          "device": 2096,
          "inode": 69612737,
          "nlink": 1
        },
        {
          "name": "syntaxDefinition.kore",
          "kind": "regular",
          "mode": "0o600",
          "bytes": 270085,
          "mtime_ns": 1792405211566784381,
          "device": 2096,
          "inode": 69612755,
          "nlink": 1
        },
        {
          "name": "timestamp",
          "kind": "regular",
          "mode": "0o600",
          "bytes": 7,
          "mtime_ns": 1792405212696681888,
          "device": 2096,
          "inode": 69612758,
          "nlink": 1
        }
      ]
    },
    {
      "directory": "/nix/store/5p6kb76qjrdwjvjmm6l7l2683k41ay1r-kore-38afc81/bin",
      "entries": [
        {
          "name": ".booster-dev-wrapped",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 80,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35321822,
          "nlink": 1,
          "link_text": "/nix/store/6n4b11ja48g8qkgfwmgdb82s0f6rpvws-booster-dev/bin/.booster-dev-wrapped",
          "resolved": "/nix/store/6n4b11ja48g8qkgfwmgdb82s0f6rpvws-booster-dev/bin/.booster-dev-wrapped"
        },
        {
          "name": ".kore-exec-wrapped",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 76,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35321823,
          "nlink": 1,
          "link_text": "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/.kore-exec-wrapped",
          "resolved": "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/.kore-exec-wrapped"
        },
        {
          "name": ".kore-match-disjunction-wrapped",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 102,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35321824,
          "nlink": 1,
          "link_text": "/nix/store/y8348y9l3ds02gx5k2jbad5f6b15mlih-kore-match-disjunction/bin/.kore-match-disjunction-wrapped",
          "resolved": "/nix/store/y8348y9l3ds02gx5k2jbad5f6b15mlih-kore-match-disjunction/bin/.kore-match-disjunction-wrapped"
        },
        {
          "name": ".kore-parser-wrapped",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 80,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35321825,
          "nlink": 1,
          "link_text": "/nix/store/1dv9hhwm4pylfmn4jxjais8rzf2g3lnh-kore-parser/bin/.kore-parser-wrapped",
          "resolved": "/nix/store/1dv9hhwm4pylfmn4jxjais8rzf2g3lnh-kore-parser/bin/.kore-parser-wrapped"
        },
        {
          "name": ".kore-repl-wrapped",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 76,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35321826,
          "nlink": 1,
          "link_text": "/nix/store/4ilkcxv27h36kqgf7x4rcmw9jizaam8m-kore-repl/bin/.kore-repl-wrapped",
          "resolved": "/nix/store/4ilkcxv27h36kqgf7x4rcmw9jizaam8m-kore-repl/bin/.kore-repl-wrapped"
        },
        {
          "name": ".kore-rpc-booster-wrapped",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 90,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35321827,
          "nlink": 1,
          "link_text": "/nix/store/35i1ik5ph9mvn8ppqpncrz8741gwiv5k-kore-rpc-booster/bin/.kore-rpc-booster-wrapped",
          "resolved": "/nix/store/35i1ik5ph9mvn8ppqpncrz8741gwiv5k-kore-rpc-booster/bin/.kore-rpc-booster-wrapped"
        },
        {
          "name": ".kore-rpc-client-wrapped",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 88,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35321828,
          "nlink": 1,
          "link_text": "/nix/store/785xkw1fw2znfal5xcfigyn93lgas1xr-kore-rpc-client/bin/.kore-rpc-client-wrapped",
          "resolved": "/nix/store/785xkw1fw2znfal5xcfigyn93lgas1xr-kore-rpc-client/bin/.kore-rpc-client-wrapped"
        },
        {
          "name": ".kore-rpc-wrapped",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 74,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35321829,
          "nlink": 1,
          "link_text": "/nix/store/wij5nr1s0q3ksvyng4lcybhy467bn9gh-kore-rpc/bin/.kore-rpc-wrapped",
          "resolved": "/nix/store/wij5nr1s0q3ksvyng4lcybhy467bn9gh-kore-rpc/bin/.kore-rpc-wrapped"
        },
        {
          "name": "booster-dev",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 71,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35321830,
          "nlink": 1,
          "link_text": "/nix/store/6n4b11ja48g8qkgfwmgdb82s0f6rpvws-booster-dev/bin/booster-dev",
          "resolved": "/nix/store/6n4b11ja48g8qkgfwmgdb82s0f6rpvws-booster-dev/bin/booster-dev"
        },
        {
          "name": "kore-exec",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 67,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35321831,
          "nlink": 1,
          "link_text": "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/kore-exec",
          "resolved": "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/kore-exec"
        },
        {
          "name": "kore-match-disjunction",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 93,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35321832,
          "nlink": 1,
          "link_text": "/nix/store/y8348y9l3ds02gx5k2jbad5f6b15mlih-kore-match-disjunction/bin/kore-match-disjunction",
          "resolved": "/nix/store/y8348y9l3ds02gx5k2jbad5f6b15mlih-kore-match-disjunction/bin/kore-match-disjunction"
        },
        {
          "name": "kore-parser",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 71,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35321833,
          "nlink": 1,
          "link_text": "/nix/store/1dv9hhwm4pylfmn4jxjais8rzf2g3lnh-kore-parser/bin/kore-parser",
          "resolved": "/nix/store/1dv9hhwm4pylfmn4jxjais8rzf2g3lnh-kore-parser/bin/kore-parser"
        },
        {
          "name": "kore-repl",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 67,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35321834,
          "nlink": 1,
          "link_text": "/nix/store/4ilkcxv27h36kqgf7x4rcmw9jizaam8m-kore-repl/bin/kore-repl",
          "resolved": "/nix/store/4ilkcxv27h36kqgf7x4rcmw9jizaam8m-kore-repl/bin/kore-repl"
        },
        {
          "name": "kore-rpc",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 65,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35321835,
          "nlink": 1,
          "link_text": "/nix/store/wij5nr1s0q3ksvyng4lcybhy467bn9gh-kore-rpc/bin/kore-rpc",
          "resolved": "/nix/store/wij5nr1s0q3ksvyng4lcybhy467bn9gh-kore-rpc/bin/kore-rpc"
        },
        {
          "name": "kore-rpc-booster",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 81,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35321836,
          "nlink": 1,
          "link_text": "/nix/store/35i1ik5ph9mvn8ppqpncrz8741gwiv5k-kore-rpc-booster/bin/kore-rpc-booster",
          "resolved": "/nix/store/35i1ik5ph9mvn8ppqpncrz8741gwiv5k-kore-rpc-booster/bin/kore-rpc-booster"
        },
        {
          "name": "kore-rpc-client",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 79,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35321837,
          "nlink": 1,
          "link_text": "/nix/store/785xkw1fw2znfal5xcfigyn93lgas1xr-kore-rpc-client/bin/kore-rpc-client",
          "resolved": "/nix/store/785xkw1fw2znfal5xcfigyn93lgas1xr-kore-rpc-client/bin/kore-rpc-client"
        }
      ]
    },
    {
      "directory": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/bin",
      "entries": [
        {
          "name": "addr2line",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 79,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263480,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/addr2line",
          "resolved": "/nix/store/bgcaxhhxswzvmxjbbgvvaximm5hwghz1-binutils-2.41/bin/addr2line"
        },
        {
          "name": "ar",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 72,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263481,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/ar",
          "resolved": "/nix/store/bgcaxhhxswzvmxjbbgvvaximm5hwghz1-binutils-2.41/bin/ar"
        },
        {
          "name": "as",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 72,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263482,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/as",
          "resolved": "/nix/store/bgcaxhhxswzvmxjbbgvvaximm5hwghz1-binutils-2.41/bin/as"
        },
        {
          "name": "c++",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 3,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263483,
          "nlink": 1,
          "link_text": "g++",
          "resolved": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/bin/g++"
        },
        {
          "name": "c++filt",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 77,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263484,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/c++filt",
          "resolved": "/nix/store/bgcaxhhxswzvmxjbbgvvaximm5hwghz1-binutils-2.41/bin/c++filt"
        },
        {
          "name": "cc",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 3,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263485,
          "nlink": 1,
          "link_text": "gcc",
          "resolved": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/bin/gcc"
        },
        {
          "name": "cpp",
          "kind": "regular",
          "mode": "0o555",
          "bytes": 10094,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263486,
          "nlink": 1
        },
        {
          "name": "dwp",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 73,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263487,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/dwp",
          "resolved": "/nix/store/bgcaxhhxswzvmxjbbgvvaximm5hwghz1-binutils-2.41/bin/dwp"
        },
        {
          "name": "elfedit",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 77,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263488,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/elfedit",
          "resolved": "/nix/store/bgcaxhhxswzvmxjbbgvvaximm5hwghz1-binutils-2.41/bin/elfedit"
        },
        {
          "name": "g++",
          "kind": "regular",
          "mode": "0o555",
          "bytes": 10094,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263489,
          "nlink": 1
        },
        {
          "name": "gcc",
          "kind": "regular",
          "mode": "0o555",
          "bytes": 10094,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263490,
          "nlink": 1
        },
        {
          "name": "gprof",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 75,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263491,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/gprof",
          "resolved": "/nix/store/bgcaxhhxswzvmxjbbgvvaximm5hwghz1-binutils-2.41/bin/gprof"
        },
        {
          "name": "ld",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 72,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263492,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/ld",
          "resolved": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/ld"
        },
        {
          "name": "ld.bfd",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 76,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263493,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/ld.bfd",
          "resolved": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/ld.bfd"
        },
        {
          "name": "ld.gold",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 77,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263494,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/ld.gold",
          "resolved": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/ld.gold"
        },
        {
          "name": "nm",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 72,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263495,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/nm",
          "resolved": "/nix/store/bgcaxhhxswzvmxjbbgvvaximm5hwghz1-binutils-2.41/bin/nm"
        },
        {
          "name": "objcopy",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 77,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263496,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/objcopy",
          "resolved": "/nix/store/bgcaxhhxswzvmxjbbgvvaximm5hwghz1-binutils-2.41/bin/objcopy"
        },
        {
          "name": "objdump",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 77,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263497,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/objdump",
          "resolved": "/nix/store/bgcaxhhxswzvmxjbbgvvaximm5hwghz1-binutils-2.41/bin/objdump"
        },
        {
          "name": "ranlib",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 76,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263498,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/ranlib",
          "resolved": "/nix/store/bgcaxhhxswzvmxjbbgvvaximm5hwghz1-binutils-2.41/bin/ranlib"
        },
        {
          "name": "readelf",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 77,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263499,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/readelf",
          "resolved": "/nix/store/bgcaxhhxswzvmxjbbgvvaximm5hwghz1-binutils-2.41/bin/readelf"
        },
        {
          "name": "size",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 74,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263500,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/size",
          "resolved": "/nix/store/bgcaxhhxswzvmxjbbgvvaximm5hwghz1-binutils-2.41/bin/size"
        },
        {
          "name": "strings",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 77,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263501,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/strings",
          "resolved": "/nix/store/bgcaxhhxswzvmxjbbgvvaximm5hwghz1-binutils-2.41/bin/strings"
        },
        {
          "name": "strip",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 75,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35263502,
          "nlink": 1,
          "link_text": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/strip",
          "resolved": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/strip"
        }
      ]
    },
    {
      "directory": "/nix/store/ih51sgk8g57fnkbd5r82ddi8k5vln8cl-z3-4.13.4/bin",
      "entries": [
        {
          "name": "z3",
          "kind": "regular",
          "mode": "0o555",
          "bytes": 33796736,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35302589,
          "nlink": 1
        }
      ]
    },
    {
      "directory": "/nix/store/z1fkfc5ca0rra7m5zrh8i92mx18w9i00-flex-2.6.4/bin",
      "entries": [
        {
          "name": "flex",
          "kind": "regular",
          "mode": "0o555",
          "bytes": 354336,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35301662,
          "nlink": 1
        },
        {
          "name": "flex++",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 4,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35301666,
          "nlink": 1,
          "link_text": "flex",
          "resolved": "/nix/store/z1fkfc5ca0rra7m5zrh8i92mx18w9i00-flex-2.6.4/bin/flex"
        },
        {
          "name": "lex",
          "kind": "symlink",
          "mode": "0o777",
          "bytes": 4,
          "mtime_ns": 1000000000,
          "device": 2096,
          "inode": 35301667,
          "nlink": 1,
          "link_text": "flex",
          "resolved": "/nix/store/z1fkfc5ca0rra7m5zrh8i92mx18w9i00-flex-2.6.4/bin/flex"
        }
      ]
    }
  ],
  "adapter_exact3_no_extra_modules_or_pycache": true,
  "raw_helper_exact11_named_pyfiles_no_pycache": true,
  "raw_helper_parent_not_inserted_into_sys_path": "Helper loaded by exactspecfile; existing adjacent11 source names retained, not treated as missing/forbidden.",
  "kompiled_exact15files_no_extra_dirs": true,
  "Root_before_after": "Repeat exact names/types/sourcepins/compiled15 and fullkompiled membership before/after everyphase. No arbitrary hostPIDabsence check."
}

===== END BODY 10 =====

===== COMPLETE BODY 11 Actual missingKorePATHaliases andtargetpins =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/revision02-phase01-import-and-actual-premises/MISSING-KORE-PATH-ENTRY-PINS.json
BYTES 11756 SHA256 5944e228a0d1ce3e0c1823fcf60dc04e09e783b9952a4d3bf92670d638f6d70e
{
  "basis": "Reviewer namedmissing PATH aliasdirectory. All16 immediate public toolentries nowresolveandhash; no executable/libraryrun or dependencywalk.",
  "directory": "/nix/store/5p6kb76qjrdwjvjmm6l7l2683k41ay1r-kore-38afc81/bin",
  "entries": [
    {
      "entry": {
        "name": ".booster-dev-wrapped",
        "kind": "symlink",
        "mode": "0o777",
        "bytes": 80,
        "mtime_ns": 1000000000,
        "device": 2096,
        "inode": 35321822,
        "nlink": 1,
        "link_text": "/nix/store/6n4b11ja48g8qkgfwmgdb82s0f6rpvws-booster-dev/bin/.booster-dev-wrapped",
        "resolved": "/nix/store/6n4b11ja48g8qkgfwmgdb82s0f6rpvws-booster-dev/bin/.booster-dev-wrapped"
      },
      "resolved_file": {
        "path": "/nix/store/6n4b11ja48g8qkgfwmgdb82s0f6rpvws-booster-dev/bin/.booster-dev-wrapped",
        "bytes": 8873528,
        "sha256": "daa8ce3b29f50d79f85560ac5ceb163edbf6745f99d064e05db549d7ea27baeb"
      }
    },
    {
      "entry": {
        "name": ".kore-exec-wrapped",
        "kind": "symlink",
        "mode": "0o777",
        "bytes": 76,
        "mtime_ns": 1000000000,
        "device": 2096,
        "inode": 35321823,
        "nlink": 1,
        "link_text": "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/.kore-exec-wrapped",
        "resolved": "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/.kore-exec-wrapped"
      },
      "resolved_file": {
        "path": "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/.kore-exec-wrapped",
        "bytes": 15356472,
        "sha256": "4ebe3cd5b32864352247b954c2d0fb90a7a5730e519a6c4516bb2b5a2c315429"
      }
    },
    {
      "entry": {
        "name": ".kore-match-disjunction-wrapped",
        "kind": "symlink",
        "mode": "0o777",
        "bytes": 102,
        "mtime_ns": 1000000000,
        "device": 2096,
        "inode": 35321824,
        "nlink": 1,
        "link_text": "/nix/store/y8348y9l3ds02gx5k2jbad5f6b15mlih-kore-match-disjunction/bin/.kore-match-disjunction-wrapped",
        "resolved": "/nix/store/y8348y9l3ds02gx5k2jbad5f6b15mlih-kore-match-disjunction/bin/.kore-match-disjunction-wrapped"
      },
      "resolved_file": {
        "path": "/nix/store/y8348y9l3ds02gx5k2jbad5f6b15mlih-kore-match-disjunction/bin/.kore-match-disjunction-wrapped",
        "bytes": 13152304,
        "sha256": "d43a5062e446dcc29449f7b22a594ca7600a0b65e05932a38f28fcb66043cd60"
      }
    },
    {
      "entry": {
        "name": ".kore-parser-wrapped",
        "kind": "symlink",
        "mode": "0o777",
        "bytes": 80,
        "mtime_ns": 1000000000,
        "device": 2096,
        "inode": 35321825,
        "nlink": 1,
        "link_text": "/nix/store/1dv9hhwm4pylfmn4jxjais8rzf2g3lnh-kore-parser/bin/.kore-parser-wrapped",
        "resolved": "/nix/store/1dv9hhwm4pylfmn4jxjais8rzf2g3lnh-kore-parser/bin/.kore-parser-wrapped"
      },
      "resolved_file": {
        "path": "/nix/store/1dv9hhwm4pylfmn4jxjais8rzf2g3lnh-kore-parser/bin/.kore-parser-wrapped",
        "bytes": 6081344,
        "sha256": "3d803dba81e22009a7391917df0712404b0b879844d50164f1ca899c9b05eda2"
      }
    },
    {
      "entry": {
        "name": ".kore-repl-wrapped",
        "kind": "symlink",
        "mode": "0o777",
        "bytes": 76,
        "mtime_ns": 1000000000,
        "device": 2096,
        "inode": 35321826,
        "nlink": 1,
        "link_text": "/nix/store/4ilkcxv27h36kqgf7x4rcmw9jizaam8m-kore-repl/bin/.kore-repl-wrapped",
        "resolved": "/nix/store/4ilkcxv27h36kqgf7x4rcmw9jizaam8m-kore-repl/bin/.kore-repl-wrapped"
      },
      "resolved_file": {
        "path": "/nix/store/4ilkcxv27h36kqgf7x4rcmw9jizaam8m-kore-repl/bin/.kore-repl-wrapped",
        "bytes": 17885272,
        "sha256": "2c20b39b4bf0118e2319ded86d4df993ed61064a01c97c787b6d0dc2be97d01d"
      }
    },
    {
      "entry": {
        "name": ".kore-rpc-booster-wrapped",
        "kind": "symlink",
        "mode": "0o777",
        "bytes": 90,
        "mtime_ns": 1000000000,
        "device": 2096,
        "inode": 35321827,
        "nlink": 1,
        "link_text": "/nix/store/35i1ik5ph9mvn8ppqpncrz8741gwiv5k-kore-rpc-booster/bin/.kore-rpc-booster-wrapped",
        "resolved": "/nix/store/35i1ik5ph9mvn8ppqpncrz8741gwiv5k-kore-rpc-booster/bin/.kore-rpc-booster-wrapped"
      },
      "resolved_file": {
        "path": "/nix/store/35i1ik5ph9mvn8ppqpncrz8741gwiv5k-kore-rpc-booster/bin/.kore-rpc-booster-wrapped",
        "bytes": 18898616,
        "sha256": "59943ee40f9a9f2c425145095157a6df4dd13e2a48dcc96490ea5ff3fa5fee07"
      }
    },
    {
      "entry": {
        "name": ".kore-rpc-client-wrapped",
        "kind": "symlink",
        "mode": "0o777",
        "bytes": 88,
        "mtime_ns": 1000000000,
        "device": 2096,
        "inode": 35321828,
        "nlink": 1,
        "link_text": "/nix/store/785xkw1fw2znfal5xcfigyn93lgas1xr-kore-rpc-client/bin/.kore-rpc-client-wrapped",
        "resolved": "/nix/store/785xkw1fw2znfal5xcfigyn93lgas1xr-kore-rpc-client/bin/.kore-rpc-client-wrapped"
      },
      "resolved_file": {
        "path": "/nix/store/785xkw1fw2znfal5xcfigyn93lgas1xr-kore-rpc-client/bin/.kore-rpc-client-wrapped",
        "bytes": 5506416,
        "sha256": "3d514b092d4eaba96c925ecafe71f9449c82e904d88fde5ea8dd778c7dd00aee"
      }
    },
    {
      "entry": {
        "name": ".kore-rpc-wrapped",
        "kind": "symlink",
        "mode": "0o777",
        "bytes": 74,
        "mtime_ns": 1000000000,
        "device": 2096,
        "inode": 35321829,
        "nlink": 1,
        "link_text": "/nix/store/wij5nr1s0q3ksvyng4lcybhy467bn9gh-kore-rpc/bin/.kore-rpc-wrapped",
        "resolved": "/nix/store/wij5nr1s0q3ksvyng4lcybhy467bn9gh-kore-rpc/bin/.kore-rpc-wrapped"
      },
      "resolved_file": {
        "path": "/nix/store/wij5nr1s0q3ksvyng4lcybhy467bn9gh-kore-rpc/bin/.kore-rpc-wrapped",
        "bytes": 16547512,
        "sha256": "53020403af7d52f7cba065d46b3c1bb146db2f3c461ca716c37dae644642c5d9"
      }
    },
    {
      "entry": {
        "name": "booster-dev",
        "kind": "symlink",
        "mode": "0o777",
        "bytes": 71,
        "mtime_ns": 1000000000,
        "device": 2096,
        "inode": 35321830,
        "nlink": 1,
        "link_text": "/nix/store/6n4b11ja48g8qkgfwmgdb82s0f6rpvws-booster-dev/bin/booster-dev",
        "resolved": "/nix/store/6n4b11ja48g8qkgfwmgdb82s0f6rpvws-booster-dev/bin/booster-dev"
      },
      "resolved_file": {
        "path": "/nix/store/6n4b11ja48g8qkgfwmgdb82s0f6rpvws-booster-dev/bin/booster-dev",
        "bytes": 399,
        "sha256": "49a404425650035184bae0a6aa6f4bef1b7d00521cf6c9354641cdf78cc6015e"
      }
    },
    {
      "entry": {
        "name": "kore-exec",
        "kind": "symlink",
        "mode": "0o777",
        "bytes": 67,
        "mtime_ns": 1000000000,
        "device": 2096,
        "inode": 35321831,
        "nlink": 1,
        "link_text": "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/kore-exec",
        "resolved": "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/kore-exec"
      },
      "resolved_file": {
        "path": "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/kore-exec",
        "bytes": 395,
        "sha256": "f73768989745e8d108d80906c158fe406942173b104ad2e81b8e8349da6d504d"
      }
    },
    {
      "entry": {
        "name": "kore-match-disjunction",
        "kind": "symlink",
        "mode": "0o777",
        "bytes": 93,
        "mtime_ns": 1000000000,
        "device": 2096,
        "inode": 35321832,
        "nlink": 1,
        "link_text": "/nix/store/y8348y9l3ds02gx5k2jbad5f6b15mlih-kore-match-disjunction/bin/kore-match-disjunction",
        "resolved": "/nix/store/y8348y9l3ds02gx5k2jbad5f6b15mlih-kore-match-disjunction/bin/kore-match-disjunction"
      },
      "resolved_file": {
        "path": "/nix/store/y8348y9l3ds02gx5k2jbad5f6b15mlih-kore-match-disjunction/bin/kore-match-disjunction",
        "bytes": 421,
        "sha256": "cae870de317d291724b37930e48773f838af31036b2f4bfb662a7d84f0cc3baa"
      }
    },
    {
      "entry": {
        "name": "kore-parser",
        "kind": "symlink",
        "mode": "0o777",
        "bytes": 71,
        "mtime_ns": 1000000000,
        "device": 2096,
        "inode": 35321833,
        "nlink": 1,
        "link_text": "/nix/store/1dv9hhwm4pylfmn4jxjais8rzf2g3lnh-kore-parser/bin/kore-parser",
        "resolved": "/nix/store/1dv9hhwm4pylfmn4jxjais8rzf2g3lnh-kore-parser/bin/kore-parser"
      },
      "resolved_file": {
        "path": "/nix/store/1dv9hhwm4pylfmn4jxjais8rzf2g3lnh-kore-parser/bin/kore-parser",
        "bytes": 399,
        "sha256": "97daf7aca0986dc248de390d4e8c37da80b350691a530d0ca8e0220d1ba85412"
      }
    },
    {
      "entry": {
        "name": "kore-repl",
        "kind": "symlink",
        "mode": "0o777",
        "bytes": 67,
        "mtime_ns": 1000000000,
        "device": 2096,
        "inode": 35321834,
        "nlink": 1,
        "link_text": "/nix/store/4ilkcxv27h36kqgf7x4rcmw9jizaam8m-kore-repl/bin/kore-repl",
        "resolved": "/nix/store/4ilkcxv27h36kqgf7x4rcmw9jizaam8m-kore-repl/bin/kore-repl"
      },
      "resolved_file": {
        "path": "/nix/store/4ilkcxv27h36kqgf7x4rcmw9jizaam8m-kore-repl/bin/kore-repl",
        "bytes": 395,
        "sha256": "b8fbec28ec94a59b35bac393a5736ecd94b3f5e4c181dac8bb7af9a555c4c106"
      }
    },
    {
      "entry": {
        "name": "kore-rpc",
        "kind": "symlink",
        "mode": "0o777",
        "bytes": 65,
        "mtime_ns": 1000000000,
        "device": 2096,
        "inode": 35321835,
        "nlink": 1,
        "link_text": "/nix/store/wij5nr1s0q3ksvyng4lcybhy467bn9gh-kore-rpc/bin/kore-rpc",
        "resolved": "/nix/store/wij5nr1s0q3ksvyng4lcybhy467bn9gh-kore-rpc/bin/kore-rpc"
      },
      "resolved_file": {
        "path": "/nix/store/wij5nr1s0q3ksvyng4lcybhy467bn9gh-kore-rpc/bin/kore-rpc",
        "bytes": 393,
        "sha256": "9bac312641781abfad1aee58925a5feae7d4102ad4ab5ef57e28357a5422d456"
      }
    },
    {
      "entry": {
        "name": "kore-rpc-booster",
        "kind": "symlink",
        "mode": "0o777",
        "bytes": 81,
        "mtime_ns": 1000000000,
        "device": 2096,
        "inode": 35321836,
        "nlink": 1,
        "link_text": "/nix/store/35i1ik5ph9mvn8ppqpncrz8741gwiv5k-kore-rpc-booster/bin/kore-rpc-booster",
        "resolved": "/nix/store/35i1ik5ph9mvn8ppqpncrz8741gwiv5k-kore-rpc-booster/bin/kore-rpc-booster"
      },
      "resolved_file": {
        "path": "/nix/store/35i1ik5ph9mvn8ppqpncrz8741gwiv5k-kore-rpc-booster/bin/kore-rpc-booster",
        "bytes": 409,
        "sha256": "66b332be411293e2a58b90d533dee6a04feda16921812c9be6f5ff0beeb1ac0d"
      }
    },
    {
      "entry": {
        "name": "kore-rpc-client",
        "kind": "symlink",
        "mode": "0o777",
        "bytes": 79,
        "mtime_ns": 1000000000,
        "device": 2096,
        "inode": 35321837,
        "nlink": 1,
        "link_text": "/nix/store/785xkw1fw2znfal5xcfigyn93lgas1xr-kore-rpc-client/bin/kore-rpc-client",
        "resolved": "/nix/store/785xkw1fw2znfal5xcfigyn93lgas1xr-kore-rpc-client/bin/kore-rpc-client"
      },
      "resolved_file": {
        "path": "/nix/store/785xkw1fw2znfal5xcfigyn93lgas1xr-kore-rpc-client/bin/kore-rpc-client",
        "bytes": 407,
        "sha256": "5b0cfde77cd6f47ae3d84a851cde546653d680b8298a76b365cfabdfac0acad9"
      }
    }
  ],
  "direct_plan_koreexec": "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/.kore-exec-wrapped already in originaltoolmanifest",
  "remaining_host_premise": "Trusted local immutableNix dynamic-library/JAR/Pythonstdlib basis remains explicit; no whole-host safety/closure proof or expanded resource authority."
}

===== END BODY 11 =====

===== COMPLETE BODY 12 Actual rawhelperlabels matched compiled definition =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/revision02-phase01-import-and-actual-premises/RAW-LABELS-ACTUAL-COMPILED-DEFINITION.json
BYTES 3280 SHA256 54484004b7661e10427d75dee66b499af5ed5b893f951f2fc026288625182cdd
{
  "helper": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/actual-c6-schedule-first-arm-continuation-20261019/source/kore_continuation.py",
    "bytes": 5112,
    "sha256": "3fc617c748f93d2cc99c9d97453b4d64ee11b1b0a4bbe9fffe8127d40bef6e5c"
  },
  "definition": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/definition.kore",
    "bytes": 1903957,
    "sha256": "456fdb3b375761cc2adbb857b143e0c002ec1d6dc01210a07d7456bc4302d246"
  },
  "labels": [
    {
      "name": "OBSERVE",
      "literal": "LblngObserve'LParUndsCommUndsRParUnds'SHERLOCK-NOMINAL-PRODUCT-OBSERVATIONS'Unds'NGTape'Unds'NGState'Unds'Int{}",
      "full_byte_occurrences": 2,
      "exact_symbol_declaration": "  symbol LblngObserve'LParUndsCommUndsRParUnds'SHERLOCK-NOMINAL-PRODUCT-OBSERVATIONS'Unds'NGTape'Unds'NGState'Unds'Int{}(SortNGState{}, SortInt{}) : SortNGTape{} [function{}(), org'Stop'kframework'Stop'attributes'Stop'Location{}(\"Location(8,20,8,54)\"), org'Stop'kframework'Stop'attributes'Stop'Source{}(\"Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/source/normal-trace-observations.k)\")]"
    },
    {
      "name": "TAPE",
      "literal": "LblngTape'LParUndsCommUndsCommUndsRParUnds'SHERLOCK-NOMINAL-PRODUCT-OBSERVATIONS'Unds'NGTape'Unds'NGState'Unds'NGStates'Unds'NGState{}",
      "full_byte_occurrences": 8,
      "exact_symbol_declaration": "  symbol LblngTape'LParUndsCommUndsCommUndsRParUnds'SHERLOCK-NOMINAL-PRODUCT-OBSERVATIONS'Unds'NGTape'Unds'NGState'Unds'NGStates'Unds'NGState{}(SortNGState{}, SortNGStates{}, SortNGState{}) : SortNGTape{} [constructor{}(), functional{}(), injective{}(), org'Stop'kframework'Stop'attributes'Stop'Location{}(\"Location(7,21,7,55)\"), org'Stop'kframework'Stop'attributes'Stop'Source{}(\"Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/source/normal-trace-observations.k)\")]"
    },
    {
      "name": "STATE",
      "literal": "LblngState'LParUndsCommUndsCommUndsCommUndsCommUndsRParUnds'SHERLOCK-NOMINAL-PRODUCT-SYNTAX'Unds'NGState'Unds'NGProgram'Unds'NGControl'Unds'Map'Unds'NGFrames'Unds'NGEvents{}",
      "full_byte_occurrences": 89,
      "exact_symbol_declaration": "  symbol LblngState'LParUndsCommUndsCommUndsCommUndsCommUndsRParUnds'SHERLOCK-NOMINAL-PRODUCT-SYNTAX'Unds'NGState'Unds'NGProgram'Unds'NGControl'Unds'Map'Unds'NGFrames'Unds'NGEvents{}(SortNGProgram{}, SortNGControl{}, SortMap{}, SortNGFrames{}, SortNGEvents{}) : SortNGState{} [constructor{}(), functional{}(), injective{}(), org'Stop'kframework'Stop'attributes'Stop'Location{}(\"Location(83,22,83,76)\"), org'Stop'kframework'Stop'attributes'Stop'Source{}(\"Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/source/nominal-product-syntax.k)\")]"
    }
  ],
  "all3exact_heads_present": true,
  "only_public_definition_bytes_checked_no_K_evaluation": true
}

===== END BODY 12 =====

===== COMPLETE BODY 13 Rootactualcallbackchecks/durablebarrier/stops =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/revision02-phase01-import-and-actual-premises/ROOT-ACTUAL-CALLBACK-PREPOSTCONDITIONS.md
BYTES 2514 SHA256 a9a16bdba912b0f97df69366c0d0b2eb84b759c96d9a6f728fd9419e97c210f5
# Root pre/postconditions for the actual F03 callback

The reviewer/source did not supply a new orchestration driver; Root uses its existing capture/save/pin/fsync calls and exact F03.launch. No new runner or process-absence gate is proposed.

Before every selected phase: check exact current source6/API/syntax/inputs/adapter3/rawhelper/linker/F03source/plan/tools/JARs/compiled15 pins; full immediate adapter/rawhelper/PATH listings and recursivekompiled listing remain unchanged/no added __pycache__ or shadowmodules. The current adapter has exactly3 files, raw helper parent11 known .py files and no cache, compiled directory15 files. Recheck this actual state before import, not merely this snapshot. No source-side chmod/delete or cachecleaning is authorized by this metadata.

Create only fresh0700 stage/home/tmp and require absentstdout/stderr/declaredproducts. The exactstage file-set includes these directories, F03-created stdout/stderr and the declaredproducts; any undeclaredtool output or compiled-directory modification is a fail-stop fact, not silently normalized away. Record/hash/fsync every actualstage product and directory.

F03.launch does NOT itself reject nonzero or launch errors. Root must require returnedrecord contains actual fields and exact values: returncode==0, timed_out is False, outcome=='exited', remaining==[], containment_breach is False; absence of any field fails, never defaults to success. It already waits and does ownprocess-group/token cleanup. Preserve group_members_after_exit/swept/elapsed/terminal fields and raw stdout/stderr; do not infer child success from outercontrollerexit or an unrelated actual_exit/exitCode key. No globalPIDabsence rule is added. Stop laterphaseson any error/pindrift/unexpectedfile/remaining child.

Before secondreduce: actual carryreceipt actual_tape_sha256 equals pinned first result.kore, next_query_sha256 equals actualsecond.query.kore; full actual state remains rawbytecarried, not expected/JSONgenerated.

After phase09: durablyfreeze BOTH rawwindows/prints/commands/receipts/carryquery+receipt/completewires+joinedwire and all source/tool/compiledpins first. ONLYthen recheck SAFE-HANDOFF and read/verify protected freeze and EXPECTED-JOINED bytes/SHA against SAFEdescriptors, then select10. Verify expected and joinedactual again after10; no expectedread/stat/hash beforethis barrier. Recheck source06–10unchanged and no compiled mutation. Allnormalwall/sweep/CORE/FSIZE/umask/JVM limits, stop/no retry/no recompile apply.

===== END BODY 13 =====

===== COMPLETE BODY 14 Full immediateadapter render_input.py =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter/render_input.py
BYTES 7417 SHA256 ff05d40bab66ab5a7838c306c992f00a075023ad58a83b452eb9a48394ec7943
"""Serialize a complete declared NGProgram input; never evaluate a K step.

This renderer covers the declared common positive wire, including Let and If.
It does not call the predecessor codec's obsolete encode/Map render functions.
An independently implemented, already used parser/complete decoder checks the
entire serialized input before the files are created.
"""
import argparse
import hashlib
import json
from pathlib import Path

import nominal_trace_codec as parser
from complete_k_wire import CompleteKWire


def same(a, b):
    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return a.keys() == b.keys() and all(same(a[k], b[k]) for k in a)
    if type(a) is list:
        return len(a) == len(b) and all(same(x, y) for x, y in zip(a, b))
    return a == b


def fields(value, keys):
    if type(value) is not dict or set(value) != set(keys):
        raise ValueError("Unexpected complete input fields: " + str(keys))
    return value


def nat(value):
    if type(value) is not int or value < 0:
        raise ValueError("Expected a nonnegative integer, not Bool")
    return str(value)


def call(name, *args):
    return name + "(" + ",".join(args) + ")"


def chain(rows, empty, name, encode):
    tail = call(empty)
    for row in reversed(rows):
        tail = call(name, *encode(row), tail)
    return tail


def tagged(value):
    if type(value) is not dict or len(value) != 1:
        raise ValueError("Expected exactly one declared variant")
    return next(iter(value.items()))


def value(v):
    tag, payload = tagged(v)
    if tag == "UInt":
        return call("ngUInt", nat(payload))
    if tag == "Bool":
        if type(payload) is not bool:
            raise ValueError("Expected Bool")
        return call("ngBool", str(payload).lower())
    if tag == "Nominal":
        fields(payload, ("type_id", "ctor_id", "fields"))
        return call("ngNominal", nat(payload["type_id"]), nat(payload["ctor_id"]), values(payload["fields"]))
    raise ValueError("Unsupported value variant: " + str(tag))


def values(rows):
    return chain(rows, "ngNoValues", "ngValue", lambda row: [value(row)])


def ints(rows, empty, name):
    return chain(rows, empty, name, lambda row: [nat(row)])


def pattern(p):
    tag, payload = tagged(p)
    if tag == "Wildcard":
        fields(payload, ())
        return call("ngWildcard")
    if tag == "Bind":
        return call("ngBind", nat(payload))
    if tag == "Constructor":
        fields(payload, ("type_id", "ctor_id", "fields"))
        children = chain(payload["fields"], "ngNoPatterns", "ngPattern", lambda row: [pattern(row)])
        return call("ngConstructorPattern", nat(payload["type_id"]), nat(payload["ctor_id"]), children)
    raise ValueError("Unsupported pattern variant: " + str(tag))


def arms(rows):
    def row(a):
        fields(a, ("source_arm_id", "pattern", "body"))
        return [nat(a["source_arm_id"]), pattern(a["pattern"]), nat(a["body"])]
    return chain(rows, "ngNoArms", "ngArm", row)


def expression(node):
    fields(node, ("id", "occurrence", "kind"))
    occ = nat(node["occurrence"])
    tag, v = tagged(node["kind"])
    if tag == "Literal":
        return call("ngLiteral", occ, value(v))
    spec = {
        "Variable": ("ngVariable", ("name_id",)),
        "Add": ("ngAdd", ("left", "right")),
        "Lt": ("ngLt", ("left", "right")),
        "Construct": ("ngConstruct", ("type_id", "ctor_id", "fields")),
        "Call": ("ngCall", ("name_id", "arguments")),
        "Match": ("ngMatch", ("scrutinee", "arms")),
        "Let": ("ngLet", ("binder", "bound_expr", "body_expr")),
        "If": ("ngIf", ("condition_expr", "yes_expr", "no_expr")),
    }
    if tag not in spec:
        raise ValueError("Unsupported expression variant: " + str(tag))
    name, keys = spec[tag]
    fields(v, keys)
    args = [occ]
    for key in keys:
        if key in ("fields", "arguments"):
            args.append(ints(v[key], "ngNoExprs", "ngExprId"))
        elif key == "arms":
            args.append(arms(v[key]))
        else:
            args.append(nat(v[key]))
    return call(name, *args)


def program(p):
    fields(p, ("declarations", "expressions", "functions", "entry"))
    def ctor(c):
        fields(c, ("type_id", "ctor_id", "source_order", "field_types"))
        return call("ngCtor", nat(c["type_id"]), nat(c["ctor_id"]), nat(c["source_order"]), ints(c["field_types"], "ngNoTypes", "ngType"))
    def decl(d):
        fields(d, ("type_id", "recursive_group", "ctors"))
        cs = chain(d["ctors"], "ngNoCtors", "ngCtorRow", lambda c: [ctor(c)])
        return [nat(d["type_id"]), nat(d["recursive_group"]), cs]
    def parameter(row):
        fields(row, ("name_id", "type_id"))
        return [nat(row["name_id"]), nat(row["type_id"])]
    def function(f):
        fields(f, ("name_id", "parameters", "return_type_id", "body"))
        ps = chain(f["parameters"], "ngNoParams", "ngParam", parameter)
        return [call("ngFunction", nat(f["name_id"]), ps, nat(f["return_type_id"]), nat(f["body"]))]
    return call("ngProgram", chain(p["declarations"], "ngNoDecls", "ngDecl", decl),
        chain(p["expressions"], "ngNoNodes", "ngNode", lambda row: [nat(row["id"]), expression(row)]),
        chain(p["functions"], "ngNoFunctions", "ngFunctionRow", function), nat(p["entry"]))


def environment(rows):
    names = set()
    out = []
    for row in rows:
        fields(row, ("name_id", "value"))
        key = nat(row["name_id"])
        if key in names:
            raise ValueError("Duplicate extensional environment key")
        names.add(key)
        out.append(key + " |-> " + value(row["value"]))
    # This is the already observed MAP surface form; no extra Map parentheses.
    return " ".join(out) if out else ".Map"


def write(path, raw):
    with Path(path).open("xb") as stream:
        stream.write(raw)
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--input", type=Path, required=True)
    cli.add_argument("--api", type=Path, required=True)
    cli.add_argument("--syntax", type=Path, required=True)
    cli.add_argument("--output-dir", type=Path, required=True)
    args = cli.parse_args()
    source = json.loads(args.input.read_bytes())
    initial = call("ngInitial", program(source["ng_program"]), environment(source["initial_environment"]))
    parser.configure(args.api, args.syntax)
    decoded = parser.parse_printed(initial, sort="NGState")
    if decoded.name != "ngInitial":
        raise ValueError("Input serializer changed ngInitial")
    adapter = CompleteKWire(parser.API, parser.REG)
    if not same(adapter.decode(decoded.args[0]), source["ng_program"]) or not same(adapter.decode(decoded.args[1]), source["initial_environment"]):
        raise ValueError("Complete Program/Map inverse differs; no input emitted")
    budget = nat(source["observation_budget"])
    initial_pin = write(args.output_dir / "initial.ng", (initial + "\n").encode())
    query_pin = write(args.output_dir / "query.term", (call("ngObserve", initial, budget) + "\n").encode())
    print(json.dumps({"status": "PASS_COMPLETE_INPUT_SERIALIZATION_INVERSE", "initial": initial_pin,
        "query": query_pin, "model_steps_evaluated": 0, "expected_documents_opened": 0}))


if __name__ == "__main__":
    main()

===== END BODY 14 =====

===== COMPLETE BODY 15 Full immediateadapter nominal_trace_codec.py =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter/nominal_trace_codec.py
BYTES 14258 SHA256 4cc8826bc9c06c9d56217387a21fba15bb568cccfdffb02d4765c6c001be191b
"""Complete nominal tape data codec; no evaluator or source transition rules."""
from dataclasses import dataclass
from pathlib import Path
import json
import re
API = {}
REG = {}
def configure(api_path, syntax_path):
    global API, REG
    API = json.loads(Path(api_path).read_text())
    syntax = re.sub(r'//[^\n]*', '', Path(syntax_path).read_text())
    REG = {}
    for sort, body in re.findall(r'syntax\s+(\w+)\s*::=\s*(.*?)(?=\n\s*syntax|\nendmodule)', syntax, re.S):
        for name, args in re.findall(r'(\w+)\(([^()]*)\)', body):
            REG[name] = (sort, tuple(x.strip() for x in args.split(',') if x.strip()))
    REG.update({'ngNoStates': ('NGStates', ()), 'ngStateRow': ('NGStates', ('NGState', 'NGStates')), 'ngTape': ('NGTape', ('NGState', 'NGStates', 'NGState')), 'ngInitial': ('NGState', ('NGProgram', 'Map'))})

@dataclass(frozen=True)
class T:
    sort: str
    name: str
    args: tuple

def C(name, *args):
    sort, sorts = REG[name]
    assert tuple(a.sort for a in args) == sorts, (name, tuple(a.sort for a in args), sorts)
    return T(sort, name, tuple(args))

def atom(sort, value):
    return T(sort, '@' + sort, (value,))

def chain(items, empty, row, before=None):
    tail = C(empty)
    for x in reversed(items):
        args = before(x) if before else [x]
        tail = C(row, *args, tail)
    return tail

GROUPS = {'NGControl': 'control_payload_order', 'NGFrame': 'frame_payload_order', 'NGEvent': 'event_payload_order'}

def arms_index(program):
    return {a['source_arm_id']: a for n in program['expressions'] if 'Match' in n['kind'] for a in n['kind']['Match']['arms']}

def encode(sort, value, ctx):
    if sort in ('Int', 'Bool', 'String'):
        return atom(sort, value)
    if sort == 'Map':
        return T('Map', '@Map', tuple((encode('Int', x['name_id'], ctx), encode('NGValue', x['value'], ctx)) for x in value))
    if sort == 'NGValue':
        tag, v = next(iter(value.items()))
        if tag == 'UInt': return C('ngUInt', encode('Int', v, ctx))
        if tag == 'Bool': return C('ngBool', encode('Bool', v, ctx))
        return C('ngNominal', encode('Int', v['type_id'], ctx), encode('Int', v['ctor_id'], ctx), encode('NGValues', v['fields'], ctx))
    lists = {'NGValues': ('NGValue', 'ngNoValues', 'ngValue'), 'NGTypes': ('Int', 'ngNoTypes', 'ngType'), 'NGExprIds': ('Int', 'ngNoExprs', 'ngExprId'), 'NGPatterns': ('NGPattern', 'ngNoPatterns', 'ngPattern'), 'NGFrames': ('NGFrame', 'ngNoFrames', 'ngFrame'), 'NGEvents': ('NGEvent', 'ngNoEvents', 'ngEvent'), 'NGStates': ('NGState', 'ngNoStates', 'ngStateRow'), 'NGCtors': ('NGCtor', 'ngNoCtors', 'ngCtorRow'), 'NGFunctions': ('NGFunction', 'ngNoFunctions', 'ngFunctionRow')}
    if sort in lists:
        sub, empty, row = lists[sort]
        return chain([encode(sub, x, ctx) for x in value], empty, row)
    if sort == 'NGPath':
        return chain([encode('Int', x, ctx) for x in value], 'ngRoot', 'ngAt')
    if sort == 'NGPattern':
        tag, v = next(iter(value.items()))
        if tag == 'Wildcard': return C('ngWildcard')
        if tag == 'Bind': return C('ngBind', encode('Int', v, ctx))
        return C('ngConstructorPattern', encode('Int', v['type_id'], ctx), encode('Int', v['ctor_id'], ctx), encode('NGPatterns', v['fields'], ctx))
    if sort == 'NGArms':
        rows = [ctx['arms'][v] if isinstance(v, int) else v for v in value]
        return chain(rows, 'ngNoArms', 'ngArm', lambda v: [encode('Int', v['source_arm_id'], ctx), encode('NGPattern', v['pattern'], ctx), encode('Int', v['body'], ctx)])
    if sort == 'NGBindings':
        fields = ['name_id', 'match_expr_id', 'source_arm_id', 'field_path', 'value']
        return chain(value, 'ngNoBindings', 'ngBinding', lambda v: [encode(s, v[k], ctx) for s, k in zip(REG['ngBinding'][1][:-1], fields)])
    if sort in GROUPS:
        if sort == 'NGEvent': name, payload = value['event'], {k: v for k, v in value.items() if k != 'event'}
        else: name, payload = next(iter(value.items()))
        keys = API[GROUPS[sort]][name]
        assert set(payload) == set(keys)
        return C(name, *(encode(s, payload[k], ctx) for s, k in zip(REG[name][1], keys)))
    if sort == 'NGExpr':
        i, occ, kinds = value['id'], value['occurrence'], value['kind']
        tag, v = next(iter(kinds.items()))
        if tag == 'Literal': return C('ngLiteral', encode('Int', occ, ctx), encode('NGValue', v, ctx))
        config = {'Variable': ('ngVariable', ['name_id']), 'Add': ('ngAdd', ['left', 'right']), 'Lt': ('ngLt', ['left', 'right']), 'Construct': ('ngConstruct', ['type_id', 'ctor_id', 'fields']), 'Call': ('ngCall', ['name_id', 'arguments']), 'Match': ('ngMatch', ['scrutinee', 'arms'])}
        name, keys = config[tag]
        return C(name, encode('Int', occ, ctx), *(encode(s, v[k], ctx) for s, k in zip(REG[name][1][1:], keys)))
    if sort == 'NGNodes':
        return chain(value, 'ngNoNodes', 'ngNode', lambda v: [encode('Int', v['id'], ctx), encode('NGExpr', v, ctx)])
    if sort == 'NGParams':
        return chain(value, 'ngNoParams', 'ngParam', lambda v: [encode('Int', v['name_id'], ctx), encode('Int', v['type_id'], ctx)])
    if sort == 'NGFunction':
        return C('ngFunction', encode('Int', value['name_id'], ctx), encode('NGParams', value['parameters'], ctx), encode('Int', value['return_type_id'], ctx), encode('Int', value['body'], ctx))
    if sort == 'NGCtor':
        return C('ngCtor', *(encode(s, value[k], ctx) for s, k in zip(REG['ngCtor'][1], ['type_id', 'ctor_id', 'source_order', 'field_types'])))
    if sort == 'NGDecls':
        return chain(value, 'ngNoDecls', 'ngDecl', lambda v: [encode('Int', v['type_id'], ctx), encode('Int', v['recursive_group'], ctx), encode('NGCtors', v['ctors'], ctx)])
    if sort == 'NGProgram':
        return C('ngProgram', *(encode(s, value[k], ctx) for s, k in zip(REG['ngProgram'][1], ['declarations', 'expressions', 'functions', 'entry'])))
    if sort == 'NGState':
        return C('ngState', encode('NGProgram', value['program'], ctx), encode('NGControl', value['control'], ctx), encode('Map', value['environment'], ctx), encode('NGFrames', value['frames_top_first'], ctx), encode('NGEvents', value['events'], ctx))
    raise ValueError(sort)

def unchain(t):
    out = []
    while t.args:
        out.append(t.args[:-1]); t = t.args[-1]
    return out

def decode(t, ctx):
    s, name, args = t.sort, t.name, t.args
    if name in ('@Int', '@Bool', '@String'): return args[0]
    if name == '@Map': return sorted([{'name_id': decode(k, ctx), 'value': decode(v, ctx)} for k, v in args], key=lambda row: row['name_id'])
    if s == 'NGValue':
        if name == 'ngUInt': return {'UInt': decode(args[0], ctx)}
        if name == 'ngBool': return {'Bool': decode(args[0], ctx)}
        return {'Nominal': dict(zip(['type_id', 'ctor_id', 'fields'], [decode(a, ctx) for a in args]))}
    lists = {'NGValues', 'NGTypes', 'NGExprIds', 'NGPatterns', 'NGFrames', 'NGEvents', 'NGStates', 'NGCtors', 'NGFunctions', 'NGPath'}
    if s in lists: return [decode(row[0], ctx) for row in unchain(t)]
    if s == 'NGPattern':
        if name == 'ngWildcard': return {'Wildcard': {}}
        if name == 'ngBind': return {'Bind': decode(args[0], ctx)}
        return {'Constructor': dict(zip(['type_id', 'ctor_id', 'fields'], [decode(a, ctx) for a in args]))}
    if s == 'NGArms': return [dict(zip(['source_arm_id', 'pattern', 'body'], [decode(a, ctx) for a in row])) for row in unchain(t)]
    if s == 'NGBindings': return [dict(zip(['name_id', 'match_expr_id', 'source_arm_id', 'field_path', 'value'], [decode(a, ctx) for a in row])) for row in unchain(t)]
    if s in GROUPS:
        keys = API[GROUPS[s]][name]; payload = {}
        for k, a in zip(keys, args):
            v = decode(a, ctx)
            if k in ('source_arms', 'remaining_source_arms'):
                assert all(ctx['arms'][v0['source_arm_id']] == v0 for v0 in v)
                v = [v0['source_arm_id'] for v0 in v]
            payload[k] = v
        return {'event': name, **payload} if s == 'NGEvent' else {name: payload}
    if s == 'NGExpr':
        occ = decode(args[0], ctx)
        if name == 'ngLiteral': return {'occurrence': occ, 'kind': {'Literal': decode(args[1], ctx)}}
        cfg = {'ngVariable': ('Variable', ['name_id']), 'ngAdd': ('Add', ['left', 'right']), 'ngLt': ('Lt', ['left', 'right']), 'ngConstruct': ('Construct', ['type_id', 'ctor_id', 'fields']), 'ngCall': ('Call', ['name_id', 'arguments']), 'ngMatch': ('Match', ['scrutinee', 'arms'])}
        tag, keys = cfg[name]
        return {'occurrence': occ, 'kind': {tag: dict(zip(keys, [decode(a, ctx) for a in args[1:]]))}}
    if s == 'NGNodes': return [{'id': decode(row[0], ctx), **decode(row[1], ctx)} for row in unchain(t)]
    if s == 'NGParams': return [dict(zip(['name_id', 'type_id'], [decode(a, ctx) for a in row])) for row in unchain(t)]
    if s == 'NGFunction': return dict(zip(['name_id', 'parameters', 'return_type_id', 'body'], [decode(a, ctx) for a in args]))
    if s == 'NGCtor': return dict(zip(['type_id', 'ctor_id', 'source_order', 'field_types'], [decode(a, ctx) for a in args]))
    if s == 'NGDecls': return [dict(zip(['type_id', 'recursive_group', 'ctors'], [decode(a, ctx) for a in row])) for row in unchain(t)]
    if s == 'NGProgram': return dict(zip(['declarations', 'expressions', 'functions', 'entry'], [decode(a, ctx) for a in args]))
    if s == 'NGState': return dict(zip(['program', 'control', 'environment', 'frames_top_first', 'events'], [decode(a, ctx) for a in args]))
    if s == 'NGTape': return {'initial': decode(args[0], ctx), 'after_each_event': decode(args[1], ctx), 'final': decode(args[2], ctx)}
    raise ValueError(s)

def render(t):
    if t.name == '@Int': return str(t.args[0])
    if t.name == '@Bool': return str(t.args[0]).lower()
    if t.name == '@String': return json.dumps(t.args[0])
    if t.name == '@Map':
        return '.Map' if not t.args else '(.Map ' + ' '.join('(' + render(k) + ' |-> ' + render(v) + ')' for k, v in t.args) + ')'
    if t.name == '@Ref': return t.args[0] + '()'
    return t.name + '(' + ','.join(render(a) for a in t.args) + ')'

# Source-format data parsing only. No token, state, frame, or event is skipped.
# Parentheses/whitespace and Map's declared AC/unit syntax are presentation.
LEX = re.compile(r'\s*(\.Map|\|->|-?\d+|true\b|false\b|"(?:[^"\\]|\\.)*"|[A-Za-z][A-Za-z0-9]*|[(),])')

class PrintedTermParser:
    def __init__(self, text):
        self.tokens = []
        self.at = 0
        pos = 0
        while pos < len(text):
            found = LEX.match(text, pos)
            if found is None:
                if text[pos:].strip() == '': break
                raise ValueError('Unparsed printed byte at ' + str(pos))
            self.tokens.append(found.group(1))
            pos = found.end()

    def peek(self):
        return self.tokens[self.at] if self.at < len(self.tokens) else None

    def take(self, expected=None):
        token = self.peek()
        if token is None: raise ValueError('Unexpected end of complete tape')
        self.at += 1
        if expected is not None and token != expected:
            raise ValueError('Expected ' + expected + ', got ' + token)
        return token

    def term(self, sort):
        if sort == 'Map': return self.map_term()
        if self.peek() == '(':
            self.take('(')
            value = self.term(sort)
            self.take(')')
            return value
        token = self.take()
        if sort == 'Int':
            if re.fullmatch(r'-?\d+', token) is None: raise ValueError('Expected Int')
            return atom('Int', int(token))
        if sort == 'Bool':
            if token not in ('true', 'false'): raise ValueError('Expected Bool')
            return atom('Bool', token == 'true')
        if sort == 'String': return atom('String', json.loads(token))
        if token not in REG or REG[token][0] != sort:
            raise ValueError('Unknown constructor/sort ' + str((token, sort)))
        self.take('(')
        values = []
        for i, child_sort in enumerate(REG[token][1]):
            if i: self.take(',')
            values.append(self.term(child_sort))
        self.take(')')
        return C(token, *values)

    def map_term(self):
        rows = []
        saw_item = False
        while True:
            if self.peek() == '.Map':
                self.take('.Map'); saw_item = True
                continue
            checkpoint = self.at
            # Source environments have Int name IDs and NGValue bindings.
            # Optional key parentheses are surface formatting only.
            try:
                key = self.term('Int')
            except ValueError:
                self.at = checkpoint
                key = None
            if key is not None and self.peek() == '|->':
                self.take('|->')
                rows.append((key, self.term('NGValue')))
                saw_item = True
                continue
            self.at = checkpoint
            if self.peek() == '(':
                self.take('(')
                group = self.map_term()
                self.take(')')
                rows.extend(group.args)
                saw_item = True
                continue
            break
        if not saw_item: raise ValueError('Expected complete finite environment Map')
        # Retain all bindings, including any repeated rows; no dict overwrite.
        return T('Map', '@Map', tuple(sorted(rows, key=lambda row: row[0].args[0])))

    def complete(self, sort='NGTape'):
        value = self.term(sort)
        if self.at != len(self.tokens): raise ValueError('Trailing printed tape tokens')
        return value

def parse_printed(text, sort='NGTape'):
    return PrintedTermParser(text).complete(sort)

def expanded_expected(fixture):
    def state(s):
        return {'program': fixture['shared_program'], 'control': s['control'],
                'environment': s['environment'], 'frames_top_first': s['frames_top_first'],
                'events': fixture['expected_events'][:s['events_prefix_length']]}
    return {'initial': state(fixture['initial_state']),
            'after_each_event': [state(s) for s in fixture['after_each_event']],
            'final': state(fixture['expected_final_state'])}


===== END BODY 15 =====

===== COMPLETE BODY 16 Full immediateadapter complete_k_wire.py =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter/complete_k_wire.py
BYTES 13453 SHA256 983e35bebc4f880922daa8c89a3e093391e736ba90e32fa67cb1e27646e5a524
"""Complete structural observation export; no evaluator, parser or file access.

The selected consumer supplies a complete typed term from the existing parser,
the approved public payload API, and that parser's constructor registry.  This
module does not import the parser or consume independent expected data.
"""

from typing import Any, Iterable, Mapping, Protocol, Sequence


class Term(Protocol):
    sort: str
    name: str
    args: tuple


class ObservationFormatError(ValueError):
    """The supplied object is not the complete declared observation format."""


class CompleteKWire:
    SCHEMA = "independent-nominal-full-state/1"
    GROUPS = {
        "NGControl": "control_payload_order",
        "NGFrame": "frame_payload_order",
        "NGEvent": "event_payload_order",
    }
    SEQUENCES = {
        "NGValues": ("ngNoValues", "ngValue"),
        "NGTypes": ("ngNoTypes", "ngType"),
        "NGExprIds": ("ngNoExprs", "ngExprId"),
        "NGPatterns": ("ngNoPatterns", "ngPattern"),
        "NGFrames": ("ngNoFrames", "ngFrame"),
        "NGEvents": ("ngNoEvents", "ngEvent"),
        "NGStates": ("ngNoStates", "ngStateRow"),
        "NGCtors": ("ngNoCtors", "ngCtorRow"),
        "NGFunctions": ("ngNoFunctions", "ngFunctionRow"),
        "NGPath": ("ngRoot", "ngAt"),
    }
    EXPRESSIONS = {
        "ngLiteral": ("Literal", ("value",)),
        "ngVariable": ("Variable", ("name_id",)),
        "ngAdd": ("Add", ("left", "right")),
        "ngLt": ("Lt", ("left", "right")),
        "ngConstruct": ("Construct", ("type_id", "ctor_id", "fields")),
        "ngCall": ("Call", ("name_id", "arguments")),
        "ngMatch": ("Match", ("scrutinee", "arms")),
        "ngLet": ("Let", ("binder", "bound_expr", "body_expr")),
        "ngIf": ("If", ("condition_expr", "yes_expr", "no_expr")),
    }

    def __init__(
        self,
        public_api: Mapping[str, Any],
        registry: Mapping[str, tuple[str, Sequence[str]]],
    ) -> None:
        # Copy declarations once: decoding does not mutate shared codec globals.
        self.registry = {
            name: (sort, tuple(children))
            for name, (sort, children) in registry.items()
        }
        self.fields = {
            sort: {
                name: tuple(fields)
                for name, fields in public_api[group].items()
            }
            for sort, group in self.GROUPS.items()
        }
        for sort, constructors in self.fields.items():
            for name, fields in constructors.items():
                declaration = self.registry.get(name)
                if declaration is None or declaration[0] != sort:
                    raise ObservationFormatError("Missing declared variant: " + name)
                if len(fields) != len(declaration[1]):
                    raise ObservationFormatError("Payload arity differs: " + name)
                if len(set(fields)) != len(fields):
                    raise ObservationFormatError("Repeated payload field: " + name)

    def _args(
        self, term: Term, sort: str, name: str | None = None
    ) -> tuple:
        if term.sort != sort or (name is not None and term.name != name):
            raise ObservationFormatError(
                "Expected " + str((sort, name))
                + ", received " + str((term.sort, term.name))
            )
        declaration = self.registry.get(term.name)
        if declaration is None or declaration[0] != sort:
            raise ObservationFormatError("Unknown constructor: " + term.name)
        children = declaration[1]
        if len(term.args) != len(children):
            raise ObservationFormatError("Constructor arity differs: " + term.name)
        for argument, child_sort in zip(term.args, children):
            if argument.sort != child_sort:
                raise ObservationFormatError("Child sort differs: " + term.name)
        return term.args

    def _record(self, keys: Sequence[str], values: Sequence[Any]) -> dict:
        if len(keys) != len(values):
            raise ObservationFormatError("Record field count differs")
        return dict(zip(keys, values))

    def _rows(self, term: Term, empty: str, row: str) -> list[tuple]:
        sort = term.sort
        rows = []
        current = term
        while True:
            args = self._args(current, sort)
            if current.name == empty:
                if args:
                    raise ObservationFormatError("Nonempty list terminator")
                return rows
            if current.name != row or not args:
                raise ObservationFormatError("Unexpected list constructor")
            rows.append(args[:-1])
            current = args[-1]

    def _decode_rows(
        self, term: Term, empty: str, row: str, fields: Sequence[str]
    ) -> list[dict]:
        return [
            self._record(fields, [self.decode(child) for child in payload])
            for payload in self._rows(term, empty, row)
        ]

    def decode(self, term: Term) -> Any:
        """Decode all supplied fields; function expressions remain unacceptable."""
        sort, name, args = term.sort, term.name, term.args
        scalar_types = {"Int": int, "Bool": bool, "String": str}
        if sort in scalar_types:
            if (
                name != "@" + sort
                or len(args) != 1
                or type(args[0]) is not scalar_types[sort]
            ):
                raise ObservationFormatError("Unexpected scalar representation")
            return args[0]
        if sort == "Map":
            if name != "@Map":
                raise ObservationFormatError("Expected complete parsed Map")
            rows = []
            for pair in args:
                if len(pair) != 2 or pair[0].sort != "Int" or pair[1].sort != "NGValue":
                    raise ObservationFormatError("Map binding shape differs")
                rows.append({
                    "name_id": self.decode(pair[0]),
                    "value": self.decode(pair[1]),
                })
            # Preserve every row.  In particular there is no dict overwrite.
            return sorted(rows, key=lambda binding: binding["name_id"])
        if sort in self.SEQUENCES:
            empty, row = self.SEQUENCES[sort]
            result = []
            for payload in self._rows(term, empty, row):
                if len(payload) != 1:
                    raise ObservationFormatError("Sequence element arity differs")
                result.append(self.decode(payload[0]))
            return result
        if sort in self.GROUPS:
            actual = self._args(term, sort)
            keys = self.fields[sort].get(name)
            if keys is None:
                raise ObservationFormatError("Variant absent from public API: " + name)
            # Exact arity is checked before pairing; no payload tail disappears.
            payload = self._record(keys, [self.decode(child) for child in actual])
            return {name: payload}
        if sort == "NGValue":
            actual = self._args(term, sort)
            values = [self.decode(child) for child in actual]
            if name == "ngUInt":
                return {"UInt": self._single(values)}
            if name == "ngBool":
                return {"Bool": self._single(values)}
            if name == "ngNominal":
                return {"Nominal": self._record(("type_id", "ctor_id", "fields"), values)}
        elif sort == "NGPattern":
            values = [self.decode(child) for child in self._args(term, sort)]
            if name == "ngWildcard" and not values:
                return {"Wildcard": {}}
            if name == "ngBind":
                return {"Bind": self._single(values)}
            if name == "ngConstructorPattern":
                return {"Constructor": self._record(("type_id", "ctor_id", "fields"), values)}
        elif sort == "NGExpr":
            actual = self._args(term, sort)
            declaration = self.EXPRESSIONS.get(name)
            if declaration is None or not actual:
                raise ObservationFormatError("Expression form is not declared")
            tag, fields = declaration
            occurrence = self.decode(actual[0])
            values = [self.decode(child) for child in actual[1:]]
            payload = self._record(fields, values)
            return {
                "occurrence": occurrence,
                "kind": {tag: payload["value"] if tag == "Literal" else payload},
            }
        elif sort == "NGNodes":
            nodes = []
            for payload in self._rows(term, "ngNoNodes", "ngNode"):
                if len(payload) != 2:
                    raise ObservationFormatError("Expression row arity differs")
                nodes.append({"id": self.decode(payload[0]), **self.decode(payload[1])})
            return nodes
        elif sort == "NGDecls":
            return self._decode_rows(
                term, "ngNoDecls", "ngDecl", ("type_id", "recursive_group", "ctors")
            )
        elif sort == "NGParams":
            return self._decode_rows(
                term, "ngNoParams", "ngParam", ("name_id", "type_id")
            )
        elif sort == "NGArms":
            return self._decode_rows(
                term, "ngNoArms", "ngArm", ("source_arm_id", "pattern", "body")
            )
        elif sort == "NGBindings":
            return self._decode_rows(
                term, "ngNoBindings", "ngBinding",
                ("name_id", "match_expr_id", "source_arm_id", "field_path", "value"),
            )
        else:
            records = {
                "NGCtor": ("ngCtor", ("type_id", "ctor_id", "source_order", "field_types")),
                "NGFunction": ("ngFunction", ("name_id", "parameters", "return_type_id", "body")),
                "NGProgram": ("ngProgram", ("declarations", "expressions", "functions", "entry")),
                "NGState": ("ngState", ("program", "control", "environment", "frames_top_first", "events")),
                "NGTape": ("ngTape", ("initial", "after_each_event", "final")),
            }
            if sort in records:
                constructor, fields = records[sort]
                values = [self.decode(child) for child in self._args(term, sort, constructor)]
                return self._record(fields, values)
        raise ObservationFormatError("Undecoded declared datum: " + str((sort, name)))

    @staticmethod
    def _single(values: Sequence[Any]) -> Any:
        if len(values) != 1:
            raise ObservationFormatError("Expected exactly one payload")
        return values[0]

    def complete_states(self, tape: Term) -> list[dict]:
        """Decode and validate every actual snapshot without expected metadata."""
        decoded = self.decode(tape)
        if tape.sort != "NGTape" or tape.name != "ngTape":
            raise ObservationFormatError("Expected a fully evaluated ngTape")
        states = [decoded["initial"], *decoded["after_each_event"]]
        if decoded["final"] != states[-1]:
            raise ObservationFormatError("Final differs from last returned state")
        program = states[0]["program"]
        for current in states:
            if current["program"] != program:
                raise ObservationFormatError("Observed immutable Program changed")
        for previous, current in zip(states, states[1:]):
            prior_tag = next(iter(previous["control"]))
            if (prior_tag in ("ngHalted", "ngOutsideModel")
                    or (prior_tag == "ngLtError" and previous["control"][prior_tag]["code"] == 11)):
                raise ObservationFormatError("An observation followed a terminal state")
            prior_events, events = previous["events"], current["events"]
            if len(events) != len(prior_events) + 1 or events[:-1] != prior_events:
                raise ObservationFormatError("Cumulative event continuity differs")
        return states

    def bind_shared_wire(
        self,
        states: list[dict],
        *,
        case_id: str,
        profile: str,
        terminal_step_contract: str,
        observer_cuts: Iterable[int],
    ) -> dict:
        """Bind public metadata to already decoded complete actual states."""
        if not states:
            raise ObservationFormatError("Complete observations include an initial state")
        cuts = list(observer_cuts)
        if any(type(cut) is not int or cut < 0 or cut >= len(states) for cut in cuts):
            raise ObservationFormatError("Cut ordinal is outside the observed prefix")
        if any(type(text) is not str for text in (case_id, profile, terminal_step_contract)):
            raise ObservationFormatError("Public wire metadata must be strings")
        return {
            "schema": self.SCHEMA,
            "profile": profile,
            "caseId": case_id,
            "states": states,
            "terminalStepContract": terminal_step_contract,
            "observerCuts": cuts,
        }

    def to_shared_wire(
        self,
        tape: Term,
        *,
        case_id: str,
        profile: str,
        terminal_step_contract: str,
        observer_cuts: Iterable[int],
    ) -> dict:
        """Export complete observations with explicitly supplied public metadata."""
        return self.bind_shared_wire(
            self.complete_states(tape),
            case_id=case_id,
            profile=profile,
            terminal_step_contract=terminal_step_contract,
            observer_cuts=observer_cuts,
        )

===== END BODY 16 =====

===== COMPLETE BODY 17 Complete unchangedF03launch callable =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-product-model-v2-review-operation-20261018/context/EXISTING-LAUNCH-CALLABLE-CLOSURE.py.txt
BYTES 4228 SHA256 996aadee88cf0ac4688925789676dcc9e407cbd3d7c15b912f25204b10861242
import argparse

import datetime

import hashlib

import json

import os

import re

import resource

import secrets

import signal

import stat

import subprocess

import sys

import time

CHILD_SECONDS = 30

SWEEP_SECONDS = 3

TOKEN_NAME = 'SHERLOCK_K_ATTEMPT_TOKEN'

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def open_exclusive(path, mode=0o600):
    return os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)

def processes(pgid, token):
    marker = (TOKEN_NAME + '=' + token).encode()
    found = []
    for name in os.listdir('/proc'):
        if not name.isdigit() or int(name) == os.getpid():
            continue
        pid = int(name)
        try:
            with open(f'/proc/{pid}/stat', 'rb') as handle:
                fields = handle.read().rsplit(b')', 1)[1].split()
            state, group = fields[0].decode(), int(fields[2])
        except (OSError, IndexError, ValueError):
            continue
        tagged = False
        try:
            with open(f'/proc/{pid}/environ', 'rb') as handle:
                tagged = marker in handle.read().split(b'\0')
        except OSError:
            pass
        if group == pgid or tagged:
            try:
                with open(f'/proc/{pid}/cmdline', 'rb') as handle:
                    cmdline = [part.decode('utf-8', 'replace') for part in handle.read().split(b'\0') if part]
            except OSError:
                cmdline = []
            found.append(dict(pid=pid, pgid=group, state=state, tagged=tagged,
                              in_group=group == pgid, cmdline=cmdline))
    return found

def kill_group(pgid):
    try:
        os.killpg(pgid, signal.SIGKILL)
    except ProcessLookupError:
        pass

def sweep(pgid, token):
    killed = []
    deadline = time.monotonic() + SWEEP_SECONDS
    while True:
        live = [row for row in processes(pgid, token) if row['state'] != 'Z']
        if not live:
            return killed, []
        killed.extend(live)
        for row in live:
            try:
                os.kill(row['pid'], signal.SIGKILL)
            except ProcessLookupError:
                pass
        if time.monotonic() >= deadline:
            return killed, live
        time.sleep(0.1)

def launch(record, command, env, cwd, token, fsize):
    def limit_child():
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        resource.setrlimit(resource.RLIMIT_FSIZE, (fsize, fsize))
        os.umask(0o077)

    out_fd, err_fd = open_exclusive(cwd + '/stdout'), open_exclusive(cwd + '/stderr')
    proc = None
    try:
        record['started_utc'] = utc()
        started = time.monotonic()
        try:
            proc = subprocess.Popen(command, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                                    stdout=out_fd, stderr=err_fd, close_fds=True,
                                    start_new_session=True, preexec_fn=limit_child)
        except (OSError, subprocess.SubprocessError) as error:
            record.update(outcome='launch-error', launch_error=f'{type(error).__name__}: {error}')
            return
        record['pid'] = proc.pid
        timed_out = False
        try:
            proc.wait(timeout=max(0.0, started + CHILD_SECONDS - time.monotonic()))
        except subprocess.TimeoutExpired:
            timed_out = True
            kill_group(proc.pid)
            proc.wait()
        code = proc.returncode
        record.update(elapsed_seconds=round(time.monotonic() - started, 3), ended_utc=utc(),
                      returncode=code, timed_out=timed_out,
                      outcome='timeout-killed' if timed_out else ('exited' if code >= 0 else 'signaled'))
    finally:
        if proc is not None:
            if proc.returncode is None:
                kill_group(proc.pid)
                proc.wait()
            record['group_members_after_exit'] = processes(proc.pid, token)
            kill_group(proc.pid)
            killed, remaining = sweep(proc.pid, token)
            record.update(swept=killed, remaining=remaining,
                          containment_breach=bool(remaining) or any(not row['in_group'] for row in killed))
        os.close(out_fd)
        os.close(err_fd)

===== END BODY 17 =====

===== COMPLETE BODY 18 SAFEoraclemetadata only =====
SOURCE /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/SAFE-HANDOFF.json
BYTES 3099 SHA256 eb0ef778c7bf770840b9001ec3a95ab633f2a3419698fcfb0d748884fc59910c
{
  "status": "SAFE-HANDOFF",
  "directory": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R",
  "freeze": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTATION-FREEZE.json",
    "bytes": 5251,
    "sha256": "3b42b93bd9903379f39c6760ade58f9ae5647dd87cf7f423570c1d26bfc461c4"
  },
  "protected_artifacts": [
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTED-JOINED.json",
      "bytes": 5006,
      "sha256": "7b78225b8a699046d7c4164f6b242522a78dfc2f4b7fa8b87b21f6cb99053b53"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTED-WINDOW-01.json",
      "bytes": 3059,
      "sha256": "67018b69e12e5108f2758c2de69ad7b5f3771ed76a39e4d42683757dcdf27230"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTED-WINDOW-02.json",
      "bytes": 4003,
      "sha256": "7ecd4423a13aca680c35db0058421f77385bd9f3249a94e619f55b45e97c255e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/NATURAL-SEMANTIC-DERIVATION.md",
      "bytes": 2429,
      "sha256": "131076100deb4ca536e66fe6043ead36e3fb441e5553118dc48ca2080af3514e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/IDENTITY-AND-EXPOSURE.json",
      "bytes": 1275,
      "sha256": "da0ec122d08c7b1967b9adb1452311c3f6f549c3a8a66897133b647085c50bad"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/SOURCE-RETENTION-LEDGER.json",
      "bytes": 4572,
      "sha256": "79ba9e17c5b443f0cb303dd4c1db2944f712413bb9c65e997590e2775be2ce53"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/AUTHORING-VALIDATION.json",
      "bytes": 537,
      "sha256": "77333dd80e342a60203a8f6826cf06471874f2d6f35f12d7505831ee5bc22d59"
    }
  ],
  "limitations": [
    "No actual runtime evidence, implementation-validity/security verdict or native admission",
    "observerCuts uses zero-based local positions; packet omits explicit numeric-base/locality declaration",
    "Two safe bodies lack separate original pins; exact embedded retained bytes pinned"
  ],
  "no_expected_body_in_handoff": true
}

===== END BODY 18 =====
