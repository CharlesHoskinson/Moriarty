# Fresh nonauthor Opus5.5 HIGH source and exact10-operation opinion — two linked uncharged Add windows

Root requests an independent source/ordinary-operation review, NOT source authorship or execution. You are not the K model/adapter/linker/glue/oracle author. Requested route claude-opus-5-5/high; actual returned identity, effort/coverage limits and terminal govern. No tools, shell, provider subcalls, edits or execution. Complete relevant bodies are inline below; this is one focused read, not a replay of old12/21 operations. If delivery or a required callable is missing, name it and abstain for that predicate, without inventing sources or APIs. No report-size or byte-count approval gate.

The different independent author privately froze the oracle BEFORE runtime. This packet contains only SAFE-HANDOFF metadata and safe input/declarations. Do not request/read/derive protected expected, derivation, identity/exposure, source-retention or freeze bodies. Their published hashes are external commitments, not freshly inspected evidence. Do not infer oracle semantic adequacy from hashes. Its complete expected trace will be read only after all actual windows/rawcarry/joinedwire/receipts are durably frozen.

Concrete new capability: actual K computes first ngObserve(ngInitial(exactAddinput,map),1), then existing balanced helper carries the actual raw NGState verbatim into a second ngObserve(rawfinal,1). Both complete states/windows and raw command/output receipts are retained. Existing consumer links whole typed equal boundaries, preserving all3 chronological positions. That consumer is NOT a runtime/recursive proof verifier. Phase10 compares the joined full wire against the independently prefrozen full3-position trace only after the barrier. It is NOT result-only, event-count-only or identity-only evidence. No A/B charged-step, Kwork/fuel, production endpoint/root/height/hash/proof equivalence is proposed.

Review exactly: model6 unchanged K bodies incl imported Add/Literal+observer+Lt boundary; all3 adapters; balanced raw resume helper; linker; full new inline phase5/8/10 glue; launch callback+all import-time statement/call-bearing membership; exact10argv/env/cwd; existing tools/JAR/compiled15 pins. Full legacy F03 source is externally pinned f1bcf0a0… but its old main/ledger/195-case stages are NEVER called; full selected callable closure/import-time membership is provided. Do not confuse comments about old195 stages with this exact10-operation proposal.

The public combined constructor syntax is exactly base syntax+LF+Lt syntax (both complete bodies inline); reconstruction/hash proof is included, avoiding duplicate6KB body. The oracle-bound plan changes only the phase10 EXPECTED operand from nonexistent UNISSUED path to the real protected EXPECTED-JOINED path supplied by SAFE-HANDOFF, plus truthful metadata statuses/barrier. Assertions/model/decoder/link logic and first9argv are unchanged. Original plan and literal diff remain preserved. Clarify the safe handoff's declared limitation: zero-based local observerCuts is existing consumer/decoder behavior, not a new semantic expectation adjustment.

Existing limits only: each child30s wall+3s token/process sweep, CORE0, FSIZE536870912,umask077; JVM heap512MiB/stack32MiB/processors2; no aggregateCPU/RSS/disk cap is established. F03.launch new-session cleanup unchanged. No new compile, model/helper/guard change, old passingprefix, protected source/counter/resource change, native/SDK/proof/ledger operation or network. Root alone selects and executes only after an adequate review and actual source/tool/oracle bindings. All stages prospectively UNRUN.

Questions (concise verdicts with concrete consumers/findings):
1. SOURCE: are the complete unchanged6K+3adapters/rawresume/linker plus new inline glue/API composition correct for full-state two-window Add observation? Check ngObserve/NGTape parsing, actual map/program/frame/event preservation, source IDs/occurrences, first query budget1 versus wholecase2, real raw continuation, no terminal stutter invention, exact consumer six-field schema, and integer/Bool distinctions. Explicitly identify any missing whole function or unsupported API.
2. OPERATIONS01..10: ELIGIBLE/CHANGES_REQUIRED/ABSTAIN individually under these exact existing controls? Check Java kast module/sort and compiled cohort, depth1 reductions, full kprint capture/parser, module imports through-I/-S/sys.path, tool/JAR closure, output paths/freshness and delayed phase10. State the minimum Root obligations: fresh0700 stage dirs, all before/after source/input/compiled/tools checks, safe oracle metadata pin, expected body/SHA verification ONLY after actual-all-freeze, exact actual generated-output pins/fsync before expected comparison, stop on nonzero/pindrift/remainingchild. No automatic eligibility from the old compile.
3. SCOPE: distinguish K semantic reductions plus independent complete-trace observation from boundary-only identity; neither establishes production charged clock/recursive-child/public-state/proof equivalence. Production Rust endpoint source/mapping remains pending its owner. No native/security/adoption grant or new review ritual.
4. COVERAGE: identify what complete bodies you actually reviewed, any omitted source/schema/tool premise and oracle-body abstention. Preserve precise dissent and unavailable premises rather than approving on identity/count alone.


===== COMPLETE BODY 1 Exact current ten-operation plan (complete argv/env/CWD/inline glue) =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/PROPOSED-TEN-PHASES.ORACLE-BOUND.json
BYTES: 29314 SHA256: 6e12ba39d8b1a2d9b2078380443675a14a5b287db3420cfd02f7f971a65a2442
{
  "status": "ORACLE_PRIVATELY_PREFROZEN_SAFE_METADATA_ONLY_SOURCE_TEN_OPERATION_REVIEW_PENDING",
  "phases": [
    {
      "id": "01-render-first-window",
      "kind": "data-render",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "f4a1c45fbdc8a2eef169625da351c929"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/usr/bin/python3",
        "-I",
        "-B",
        "-S",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter/render_input.py",
        "--input",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/inputs/ADD-ENTRY.first-window.input.json",
        "--api",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/PUBLIC-LT-API.json",
        "--syntax",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/COMPLETE-LT-CONSTRUCTOR-SYNTAX.k.txt",
        "--output-dir",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window"
      ],
      "expected_exit_code": 0,
      "products": [],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "02-kast-first-window",
      "kind": "kast",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/02-kast-first-window",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/02-kast-first-window/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/02-kast-first-window/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "7a77fe0de855e05024f96c2cde84a11a",
        "PATH": "/nix/store/5p6kb76qjrdwjvjmm6l7l2683k41ay1r-kore-38afc81/bin:/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/bin:/nix/store/z1fkfc5ca0rra7m5zrh8i92mx18w9i00-flex-2.6.4/bin:/nix/store/ih51sgk8g57fnkbd5r82ddi8k5vln8cl-z3-4.13.4/bin"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/bin/java",
        "-Xms64m",
        "-Xmx512m",
        "-Xss32m",
        "-XX:ActiveProcessorCount=2",
        "-XX:+ExitOnOutOfMemoryError",
        "-XX:-UsePerfData",
        "-XX:+DisableAttachMechanism",
        "-XX:ErrorFile=/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/02-kast-first-window/hs_err_pid%p.log",
        "-Dfile.encoding=UTF-8",
        "-Djava.awt.headless=true",
        "-Djava.io.tmpdir=/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/02-kast-first-window/tmp",
        "-Duser.home=/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/02-kast-first-window/home",
        "-ea",
        "-cp",
        "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/*",
        "org.kframework.main.Main",
        "-kast",
        "--definition",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled",
        "--module",
        "SHERLOCK-NOMINAL-LT-OBSERVATIONS",
        "--sort",
        "NGTape",
        "--input",
        "program",
        "--output",
        "kore",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/01-render-first-window/query.term"
      ],
      "expected_exit_code": 0,
      "products": [],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "03-reduce-first-window",
      "kind": "reduce",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/03-reduce-first-window",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/03-reduce-first-window/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/03-reduce-first-window/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "1d2ca6ba0a470bfd78dcdbf224a69a3d",
        "PATH": "/nix/store/ih51sgk8g57fnkbd5r82ddi8k5vln8cl-z3-4.13.4/bin"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/.kore-exec-wrapped",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/definition.kore",
        "--module",
        "SHERLOCK-NOMINAL-LT-OBSERVATIONS",
        "--pattern",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/02-kast-first-window/stdout",
        "--output",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/03-reduce-first-window/result.kore",
        "--depth",
        "1",
        "--smt",
        "none",
        "--log-format",
        "standard",
        "--disable-log-timestamps"
      ],
      "expected_exit_code": 0,
      "products": [
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/03-reduce-first-window/result.kore"
      ],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "04-print-first-window",
      "kind": "print",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/04-print-first-window",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/04-print-first-window/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/04-print-first-window/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "c8ed57eb9ca965c8de5fca16ebe22f4d"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/nix/store/p7hjh21dj4bc1s6kfcdwk45knp5n4cc0-llvm-backend-0.1.140/bin/kprint",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/03-reduce-first-window/result.kore",
        "false",
        "false"
      ],
      "expected_exit_code": 0,
      "products": [],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "05-decode-first-and-carry",
      "kind": "data-decode-raw-carry",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "d756f97a24695d6086a35fd6c699cbee"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/usr/bin/python3",
        "-I",
        "-B",
        "-S",
        "-c",
        "RAW_HELPER='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/actual-c6-schedule-first-arm-continuation-20261019/source/kore_continuation.py'\nRAW_FIRST='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/03-reduce-first-window/result.kore'\nNEXT_QUERY='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/second.query.kore'\nCARRY_RECEIPT='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/carry-receipt.json'\nADAPTER='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter'\nAPI='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/PUBLIC-LT-API.json'\nSYNTAX='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/COMPLETE-LT-CONSTRUCTOR-SYNTAX.k.txt'\nINPUT='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/safe-inputs/ADD-ENTRY.input.json'\nPRINTED='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/04-print-first-window/stdout'\nOUTPUT='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/first.complete-wire.json'\nimport sys,json,importlib.util\nfrom pathlib import Path\nsys.path.insert(0,ADAPTER)\nimport nominal_trace_codec as parser\nfrom complete_k_wire import CompleteKWire\nparser.configure(Path(API),Path(SYNTAX))\nspec=json.loads(Path(INPUT).read_bytes())\ntape=parser.parse_printed(Path(PRINTED).read_text())\nadapter=CompleteKWire(parser.API,parser.REG)\nstates=adapter.complete_states(tape)\nwire=adapter.bind_shared_wire(states,case_id=spec['case_id'],profile=spec['profile'],terminal_step_contract=spec['terminalStepContract'],observer_cuts=list(range(len(states))))\nraw=(json.dumps(wire,indent=2,ensure_ascii=False,allow_nan=False)+'\\n').encode()\nwith Path(OUTPUT).open('xb') as f:f.write(raw)\n\ns=importlib.util.spec_from_file_location('existing_kore_continuation',RAW_HELPER)\nm=importlib.util.module_from_spec(s);s.loader.exec_module(m)\nquery,receipt=m.resume_query(Path(RAW_FIRST).read_bytes(),1)\nwith Path(NEXT_QUERY).open('xb') as f:f.write(query)\nwith Path(CARRY_RECEIPT).open('x') as f:json.dump(receipt,f,indent=2);f.write('\\n')\n"
      ],
      "expected_exit_code": 0,
      "products": [
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/first.complete-wire.json",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/second.query.kore",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/carry-receipt.json"
      ],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "06-reduce-second-window",
      "kind": "reduce",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/06-reduce-second-window",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/06-reduce-second-window/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/06-reduce-second-window/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "855b7b7cb0fada585d1c067dd45ba809",
        "PATH": "/nix/store/ih51sgk8g57fnkbd5r82ddi8k5vln8cl-z3-4.13.4/bin"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/.kore-exec-wrapped",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/definition.kore",
        "--module",
        "SHERLOCK-NOMINAL-LT-OBSERVATIONS",
        "--pattern",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/second.query.kore",
        "--output",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/06-reduce-second-window/result.kore",
        "--depth",
        "1",
        "--smt",
        "none",
        "--log-format",
        "standard",
        "--disable-log-timestamps"
      ],
      "expected_exit_code": 0,
      "products": [
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/06-reduce-second-window/result.kore"
      ],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "07-print-second-window",
      "kind": "print",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/07-print-second-window",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/07-print-second-window/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/07-print-second-window/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "bb8dab9bd32ace9f100fdc7503d349f8"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/nix/store/p7hjh21dj4bc1s6kfcdwk45knp5n4cc0-llvm-backend-0.1.140/bin/kprint",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/06-reduce-second-window/result.kore",
        "false",
        "false"
      ],
      "expected_exit_code": 0,
      "products": [],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "08-decode-second-window",
      "kind": "data-decode",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/08-decode-second-window",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/08-decode-second-window/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/08-decode-second-window/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "5a87f7e2c70a801634b563137d9fcebd"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/usr/bin/python3",
        "-I",
        "-B",
        "-S",
        "-c",
        "ADAPTER='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter'\nAPI='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/PUBLIC-LT-API.json'\nSYNTAX='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/COMPLETE-LT-CONSTRUCTOR-SYNTAX.k.txt'\nINPUT='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/safe-inputs/ADD-ENTRY.input.json'\nPRINTED='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/07-print-second-window/stdout'\nOUTPUT='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/08-decode-second-window/second.complete-wire.json'\nimport sys,json,importlib.util\nfrom pathlib import Path\nsys.path.insert(0,ADAPTER)\nimport nominal_trace_codec as parser\nfrom complete_k_wire import CompleteKWire\nparser.configure(Path(API),Path(SYNTAX))\nspec=json.loads(Path(INPUT).read_bytes())\ntape=parser.parse_printed(Path(PRINTED).read_text())\nadapter=CompleteKWire(parser.API,parser.REG)\nstates=adapter.complete_states(tape)\nwire=adapter.bind_shared_wire(states,case_id=spec['case_id'],profile=spec['profile'],terminal_step_contract=spec['terminalStepContract'],observer_cuts=list(range(len(states))))\nraw=(json.dumps(wire,indent=2,ensure_ascii=False,allow_nan=False)+'\\n').encode()\nwith Path(OUTPUT).open('xb') as f:f.write(raw)\n"
      ],
      "expected_exit_code": 0,
      "products": [
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/08-decode-second-window/second.complete-wire.json"
      ],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "09-link-whole-boundaries",
      "kind": "existing-data-link",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/09-link-whole-boundaries",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/09-link-whole-boundaries/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/09-link-whole-boundaries/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "b5c825740238aeebaba6aa2935d6c907"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/usr/bin/python3",
        "-I",
        "-B",
        "-S",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/source/link_two_k_windows.py",
        "--first",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/05-decode-first-and-carry/first.complete-wire.json",
        "--second",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/08-decode-second-window/second.complete-wire.json",
        "--input",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/safe-inputs/ADD-ENTRY.input.json",
        "--output-dir",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/09-link-whole-boundaries"
      ],
      "expected_exit_code": 0,
      "products": [
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/09-link-whole-boundaries/linked.complete-wire.json",
        "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/09-link-whole-boundaries/link-readback.json"
      ],
      "status": "PROSPECTIVE_UNSELECTED"
    },
    {
      "id": "10-independent-whole-trace-comparison",
      "kind": "independent-comparison-after-durable-freeze",
      "cwd": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/10-independent-whole-trace-comparison",
      "environment": {
        "HOME": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/10-independent-whole-trace-comparison/home",
        "TMPDIR": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/10-independent-whole-trace-comparison/tmp",
        "LANG": "C",
        "LC_ALL": "C",
        "SHERLOCK_K_ATTEMPT_TOKEN": "7be4c9040d73a438e7ec7267bc43943f"
      },
      "inherit_environment": false,
      "stdin": "DEVNULL",
      "argv": [
        "/usr/bin/python3",
        "-I",
        "-B",
        "-S",
        "-c",
        "ACTUAL='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/09-link-whole-boundaries/linked.complete-wire.json'\nEXPECTED='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTED-JOINED.json'\nimport json\nfrom pathlib import Path\ndef same(a,b):\n if type(a) is not type(b):return False\n if type(a) is dict:return a.keys()==b.keys() and all(same(a[k],b[k]) for k in a)\n if type(a) is list:return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))\n return a==b\na=json.loads(Path(ACTUAL).read_bytes());e=json.loads(Path(EXPECTED).read_bytes())\nif not same(a,e):raise SystemExit('FAIL_COMPLETE_INDEPENDENT_K_TRACE_EQUALITY')\nprint('PASS_COMPLETE_INDEPENDENT_K_TRACE_EQUALITY')\n"
      ],
      "expected_exit_code": 0,
      "products": [],
      "status": "PROSPECTIVE_UNSELECTED"
    }
  ],
  "callback": {
    "fullsource": {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/UIREQ021-F03-K-caller-materialized-review/source/k_engine_attempt_f03_01.py",
      "bytes": 73962,
      "sha256": "f1bcf0a0d21b4a7aaedd2f2aae1a1e9e5b62219271eb41b3f71ed97d5a0bc24d"
    },
    "full_callable_closure": {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-product-model-v2-review-operation-20261018/context/EXISTING-LAUNCH-CALLABLE-CLOSURE.py.txt",
      "bytes": 4228,
      "sha256": "996aadee88cf0ac4688925789676dcc9e407cbd3d7c15b912f25204b10861242"
    },
    "full_import_projection": {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-product-model-v2-review-operation-20261018/context/IMPORT-TIME-AST-REVIEW-PROJECTION.json",
      "bytes": 55525,
      "sha256": "9f9e9188139ea024008f204dd9f45d8c4eb119ba2837127fce83ea67b860d4b1"
    },
    "entry": "F03.launch(record,phase.argv,dict(phase.environment),phase.cwd,phase.environment[SHERLOCK_K_ATTEMPT_TOKEN],536870912)",
    "oldmain_ledger_retry_unselected": true
  },
  "limits": {
    "wall_seconds": 30,
    "sweep_seconds": 3,
    "rlimit_core": 0,
    "rlimit_fsize": 536870912,
    "umask": "0o077",
    "JVM_heap_MiB": 512,
    "JVM_stack_MiB": 32,
    "JVM_processors": 2,
    "no_aggregate_CPU_RSS_disk_cap": true,
    "cleanup": "unchanged F03 processgroup+token sweep"
  },
  "new_compile_operations": 0,
  "Kast_operations": 1,
  "K_reduce_windows": 2,
  "new_observation_steps": 2,
  "model_or_guard_changes": false,
  "old_12_source_21_operation_prefix_replayed": false,
  "raw_carry": "Existing resume_query extracts all five actual NGState arguments verbatim from first raw tape into second query, not JSON/expected reconstruction.",
  "independent_barrier": "Different independent author privately prefroze expectations per SAFE-HANDOFF. No protected freeze/expected/derivation/exposure/source-retention body is read before all actual data are frozen. Root durably freezes first+second complete tapes/rawprints/querycarry/joinedwire/sourcecompiledtoolpins/receipts/fsync before ONLY phase10 may read EXPECTED-JOINED; no evaluator/K rerun for comparison.",
  "new_inline_code_scope": "Only ordinary glue invoking existing decoder/raw-carry APIs and full typed equality; AST-parsed only. Fresh nonauthor source/operation audit includes these exact -c bodies and unchanged helper closure.",
  "future_expected": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTED-JOINED.json",
    "bytes": 5006,
    "sha256": "7b78225b8a699046d7c4164f6b242522a78dfc2f4b7fa8b87b21f6cb99053b53",
    "status": "AUTHOR_PRIVATELY_FROZEN_BODY_UNREAD_BY_ROOT_PREPARER_REVIEWER",
    "freeze_metadata": {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTATION-FREEZE.json",
      "bytes": 5251,
      "sha256": "3b42b93bd9903379f39c6760ade58f9ae5647dd87cf7f423570c1d26bfc461c4"
    },
    "safe_handoff": {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/SAFE-HANDOFF.json",
      "bytes": 3099,
      "sha256": "eb0ef778c7bf770840b9001ec3a95ab633f2a3419698fcfb0d748884fc59910c"
    },
    "verify_before_phase10_only": "After all actual windows/rawcarry/joinedwire/receipts are durably frozen, Root verifies exact protected expected bytes/SHA through existing metadata checks before comparison; never prehash/read it before barrier."
  },
  "meaning": "K-only uncharged complete-state link+independent whole-trace equality. NOT primary chargedA/Bsteps, recursiveproofvalidity/circuit endpoints, fuel/work or host/K equivalence.",
  "next_production_mapping": "Owner must supply actual Rust two-step/recursive-child public-state endpoint API and full source closure before any cross-layer relation assertion.",
  "stop": "Any failed phase/pin/containment/output/schema stops remaining UNRUN; no retry/capchange/recompile/sourcefitting; retain available raw.",
  "safe_oracle_limitations": [
    "No actual runtime evidence, implementation-validity/security verdict or native admission",
    "observerCuts uses zero-based local positions; packet omits explicit numeric-base/locality declaration",
    "Two safe bodies lack separate original pins; exact embedded retained bytes pinned"
  ],
  "Root_selection_still_required": true
}

===== END BODY 1 =====

===== COMPLETE BODY 2 Oracle operand binding diff only =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/ORACLE-OPERAND-ONLY.diff
BYTES: 6258 SHA256: acf33cb8a56b5f35c2d2628253d208dcccd6aa7ab7212998f43392fc25158263
--- PROPOSED-TEN-PHASES.original
+++ PROPOSED-TEN-PHASES.ORACLE-BOUND
@@ -1,5 +1,5 @@
 {
-  "status": "EXACT_NEW_RUNTIME_PROPOSAL_NOT_ELIGIBLE_UNTIL_EXISTING_SOURCE_REVIEW_AND_INDEPENDENT_FREEZE",
+  "status": "ORACLE_PRIVATELY_PREFROZEN_SAFE_METADATA_ONLY_SOURCE_TEN_OPERATION_REVIEW_PENDING",
   "phases": [
     {
       "id": "01-render-first-window",
@@ -314,7 +314,7 @@
         "-B",
         "-S",
         "-c",
-        "ACTUAL='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/09-link-whole-boundaries/linked.complete-wire.json'\nEXPECTED='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/oracle-private/EXPECTED.joined.complete-wire.json'\nimport json\nfrom pathlib import Path\ndef same(a,b):\n if type(a) is not type(b):return False\n if type(a) is dict:return a.keys()==b.keys() and all(same(a[k],b[k]) for k in a)\n if type(a) is list:return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))\n return a==b\na=json.loads(Path(ACTUAL).read_bytes());e=json.loads(Path(EXPECTED).read_bytes())\nif not same(a,e):raise SystemExit('FAIL_COMPLETE_INDEPENDENT_K_TRACE_EQUALITY')\nprint('PASS_COMPLETE_INDEPENDENT_K_TRACE_EQUALITY')\n"
+        "ACTUAL='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/actual-attempt-01/09-link-whole-boundaries/linked.complete-wire.json'\nEXPECTED='/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTED-JOINED.json'\nimport json\nfrom pathlib import Path\ndef same(a,b):\n if type(a) is not type(b):return False\n if type(a) is dict:return a.keys()==b.keys() and all(same(a[k],b[k]) for k in a)\n if type(a) is list:return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))\n return a==b\na=json.loads(Path(ACTUAL).read_bytes());e=json.loads(Path(EXPECTED).read_bytes())\nif not same(a,e):raise SystemExit('FAIL_COMPLETE_INDEPENDENT_K_TRACE_EQUALITY')\nprint('PASS_COMPLETE_INDEPENDENT_K_TRACE_EQUALITY')\n"
       ],
       "expected_exit_code": 0,
       "products": [],
@@ -359,14 +359,32 @@
   "model_or_guard_changes": false,
   "old_12_source_21_operation_prefix_replayed": false,
   "raw_carry": "Existing resume_query extracts all five actual NGState arguments verbatim from first raw tape into second query, not JSON/expected reconstruction.",
-  "independent_barrier": "Root must first select a different oracle author from safe packet. Freeze exact complete expectations/derivation privately before runtime. Root freezes all actual windows/raw/query/receipt/first+second+joined wires and their hashes/fsyncs BEFORE selecting child10 or reading expected.",
+  "independent_barrier": "Different independent author privately prefroze expectations per SAFE-HANDOFF. No protected freeze/expected/derivation/exposure/source-retention body is read before all actual data are frozen. Root durably freezes first+second complete tapes/rawprints/querycarry/joinedwire/sourcecompiledtoolpins/receipts/fsync before ONLY phase10 may read EXPECTED-JOINED; no evaluator/K rerun for comparison.",
   "new_inline_code_scope": "Only ordinary glue invoking existing decoder/raw-carry APIs and full typed equality; AST-parsed only. Fresh nonauthor source/operation audit includes these exact -c bodies and unchanged helper closure.",
   "future_expected": {
-    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/oracle-private/EXPECTED.joined.complete-wire.json",
-    "status": "UNISSUED",
-    "required_freeze": "Root inserts real different-author freeze/expected pins; placeholders do not establish eligibility."
+    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTED-JOINED.json",
+    "bytes": 5006,
+    "sha256": "7b78225b8a699046d7c4164f6b242522a78dfc2f4b7fa8b87b21f6cb99053b53",
+    "status": "AUTHOR_PRIVATELY_FROZEN_BODY_UNREAD_BY_ROOT_PREPARER_REVIEWER",
+    "freeze_metadata": {
+      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTATION-FREEZE.json",
+      "bytes": 5251,
+      "sha256": "3b42b93bd9903379f39c6760ade58f9ae5647dd87cf7f423570c1d26bfc461c4"
+    },
+    "safe_handoff": {
+      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/SAFE-HANDOFF.json",
+      "bytes": 3099,
+      "sha256": "eb0ef778c7bf770840b9001ec3a95ab633f2a3419698fcfb0d748884fc59910c"
+    },
+    "verify_before_phase10_only": "After all actual windows/rawcarry/joinedwire/receipts are durably frozen, Root verifies exact protected expected bytes/SHA through existing metadata checks before comparison; never prehash/read it before barrier."
   },
   "meaning": "K-only uncharged complete-state link+independent whole-trace equality. NOT primary chargedA/Bsteps, recursiveproofvalidity/circuit endpoints, fuel/work or host/K equivalence.",
   "next_production_mapping": "Owner must supply actual Rust two-step/recursive-child public-state endpoint API and full source closure before any cross-layer relation assertion.",
-  "stop": "Any failed phase/pin/containment/output/schema stops remaining UNRUN; no retry/capchange/recompile/sourcefitting; retain available raw."
+  "stop": "Any failed phase/pin/containment/output/schema stops remaining UNRUN; no retry/capchange/recompile/sourcefitting; retain available raw.",
+  "safe_oracle_limitations": [
+    "No actual runtime evidence, implementation-validity/security verdict or native admission",
+    "observerCuts uses zero-based local positions; packet omits explicit numeric-base/locality declaration",
+    "Two safe bodies lack separate original pins; exact embedded retained bytes pinned"
+  ],
+  "Root_selection_still_required": true
 }

===== END BODY 2 =====

===== COMPLETE BODY 3 Safe independent oracle metadata ONLY, never protected bodies =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/SAFE-HANDOFF.json
BYTES: 3099 SHA256: eb0ef778c7bf770840b9001ec3a95ab633f2a3419698fcfb0d748884fc59910c
{
  "status": "SAFE-HANDOFF",
  "directory": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R",
  "freeze": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTATION-FREEZE.json",
    "bytes": 5251,
    "sha256": "3b42b93bd9903379f39c6760ade58f9ae5647dd87cf7f423570c1d26bfc461c4"
  },
  "protected_artifacts": [
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTED-JOINED.json",
      "bytes": 5006,
      "sha256": "7b78225b8a699046d7c4164f6b242522a78dfc2f4b7fa8b87b21f6cb99053b53"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTED-WINDOW-01.json",
      "bytes": 3059,
      "sha256": "67018b69e12e5108f2758c2de69ad7b5f3771ed76a39e4d42683757dcdf27230"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/EXPECTED-WINDOW-02.json",
      "bytes": 4003,
      "sha256": "7ecd4423a13aca680c35db0058421f77385bd9f3249a94e619f55b45e97c255e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/NATURAL-SEMANTIC-DERIVATION.md",
      "bytes": 2429,
      "sha256": "131076100deb4ca536e66fe6043ead36e3fb441e5553118dc48ca2080af3514e"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/IDENTITY-AND-EXPOSURE.json",
      "bytes": 1275,
      "sha256": "da0ec122d08c7b1967b9adb1452311c3f6f549c3a8a66897133b647085c50bad"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/SOURCE-RETENTION-LEDGER.json",
      "bytes": 4572,
      "sha256": "79ba9e17c5b443f0cb303dd4c1db2944f712413bb9c65e997590e2775be2ce53"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/independent-oracle-01/R/AUTHORING-VALIDATION.json",
      "bytes": 537,
      "sha256": "77333dd80e342a60203a8f6826cf06471874f2d6f35f12d7505831ee5bc22d59"
    }
  ],
  "limitations": [
    "No actual runtime evidence, implementation-validity/security verdict or native admission",
    "observerCuts uses zero-based local positions; packet omits explicit numeric-base/locality declaration",
    "Two safe bodies lack separate original pins; exact embedded retained bytes pinned"
  ],
  "no_expected_body_in_handoff": true
}

===== END BODY 3 =====

===== COMPLETE BODY 4 Existing safe author contract (input/declarations/uncharged/barrier) =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/safe-inputs/SAFE-INDEPENDENT-ORACLE-CONTRACT.json
BYTES: 3446 SHA256: 8eef90e28d395876e9395679a16baa228a542c8b44294ce621f03215d1428069
{
  "status": "INPUT_ONLY_NO_EXPECTED_STATES_DIFFERENT_AUTHOR_PREFREEZE_REQUIRED",
  "case": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/safe-inputs/ADD-ENTRY.input.json",
    "bytes": 961,
    "sha256": "be54de3e112b9c34505be47949d7ef383cafc83b0d9ffdae5948bfb974eaa18c"
  },
  "declarations": [
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/PUBLIC-LT-API.json",
      "bytes": 14506,
      "sha256": "a4031743f3a27eafeacb04f1def037ae07de231391b61774c47210ebeb42ca24"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/COMPLETE-LT-CONSTRUCTOR-SYNTAX.k.txt",
      "bytes": 6161,
      "sha256": "fd0e9ac0978d326c071b5ece6428d4b2903b2447b0698c3b384e742b40ef6d7e"
    }
  ],
  "query_contract": [
    "First query ngObserve(ngInitial(exactprogram,exactinitialmap),1).",
    "Second query ngObserve(VERBATIM actual first tape final NGState,1). Only existing balanced raw-state extractor may splice; no JSON reconstruction/evaluation/replay."
  ],
  "oracle_task": "Independently derive full initial/after-each/final K wire for overall observation budget2 from initial input and public natural semantics. Every snapshot retains program/control/map/top-first frames/cumulativeevents and scalar kinds. No populated primary or K actual/oldprivategolden/modelimplementation/renderer/consumer reading.",
  "initial_declarations": "ngInitial(P,map) is ngState(P,ngEval(P.entry),map,ngNoFrames(),ngNoEvents()). Add is strict left-before-right; ngAddStarted retains source IDs/occurrence/right-expression/saved map, ngLiteralEvaluated retains literal ExprId/occurrence/value; see corrected API for frame/event payload order. No concrete afterstate, result or terminal disposition supplied.",
  "root_metadata": {
    "schema": "independent-nominal-full-state/1",
    "profile": "K-uncharged-two-linked-boundaries/1",
    "caseId": "k-two-linked-Add-entry-01",
    "terminalStepContract": "Terminal ngStep/ngAdvance preserve complete state without appending events; ngObserve emits no terminal-stutter row.",
    "states": "every complete observed state from initial, every advancing afterstate, final without duplicate final",
    "observerCuts": "derive all ordinals independently from own states, before actual access; actual derives separately before golden access"
  },
  "frozen_pairing_rule": "Exactly two ordered one-advancing-step actual windows, first.final==second.initial under whole typed JSON equality. All three distinct chronological boundary positions retained; shared middle only duplicated in inputs, removed once in joined wire.",
  "admission": "Finite closed typed positive Add/Literal NGProgram, admitted canonical UInt128 operands and unchanged initial map; K-assigned IDs, no production compiler-ID mapping.",
  "scope": "K-only uncharged logical trace composition, not two B/interpreter proof steps, not recursive verifier/circuit/ledger endpoint identity or cryptographic validity. No Kwork/fuel/cost identity.",
  "barrier": "Different independent author privately freezes expected full trace before Root runtime selection. Persist both complete windows/raw receipts and joinedactual before first expected read. Earlier same-author Ltledgers not reusable."
}

===== END BODY 4 =====

===== COMPLETE BODY 5 Exact original complete case input, overall bound2 =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/safe-inputs/ADD-ENTRY.input.json
BYTES: 961 SHA256: be54de3e112b9c34505be47949d7ef383cafc83b0d9ffdae5948bfb974eaa18c
{
  "case_id": "k-two-linked-Add-entry-01",
  "profile": "K-uncharged-two-linked-boundaries/1",
  "terminalStepContract": "Terminal ngStep/ngAdvance preserve complete state without appending events; ngObserve emits no terminal-stutter row.",
  "ng_program": {
    "declarations": [],
    "expressions": [
      {
        "id": 10,
        "occurrence": 10010,
        "kind": {
          "Add": {
            "left": 11,
            "right": 12
          }
        }
      },
      {
        "id": 11,
        "occurrence": 10011,
        "kind": {
          "Literal": {
            "UInt": 17
          }
        }
      },
      {
        "id": 12,
        "occurrence": 10012,
        "kind": {
          "Literal": {
            "UInt": 25
          }
        }
      }
    ],
    "functions": [],
    "entry": 10
  },
  "initial_environment": [
    {
      "name_id": 900,
      "value": {
        "UInt": 7
      }
    }
  ],
  "observation_budget": 2
}

===== END BODY 5 =====

===== COMPLETE BODY 6 First render input, only observer bound1 =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/inputs/ADD-ENTRY.first-window.input.json
BYTES: 961 SHA256: bf5d9ebeaa627e76720bfcc2f6f091ab907674c90b49061b907b215bc8a9fdc6
{
  "case_id": "k-two-linked-Add-entry-01",
  "profile": "K-uncharged-two-linked-boundaries/1",
  "terminalStepContract": "Terminal ngStep/ngAdvance preserve complete state without appending events; ngObserve emits no terminal-stutter row.",
  "ng_program": {
    "declarations": [],
    "expressions": [
      {
        "id": 10,
        "occurrence": 10010,
        "kind": {
          "Add": {
            "left": 11,
            "right": 12
          }
        }
      },
      {
        "id": 11,
        "occurrence": 10011,
        "kind": {
          "Literal": {
            "UInt": 17
          }
        }
      },
      {
        "id": 12,
        "occurrence": 10012,
        "kind": {
          "Literal": {
            "UInt": 25
          }
        }
      }
    ],
    "functions": [],
    "entry": 10
  },
  "initial_environment": [
    {
      "name_id": 900,
      "value": {
        "UInt": 7
      }
    }
  ],
  "observation_budget": 1
}

===== END BODY 6 =====

===== COMPLETE BODY 7 Public complete typed-wire declaration, no afterstates =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/safe-oracle-inputs/COMPLETE-WIRE-DECLARATION.json
BYTES: 1578 SHA256: a52de710d41f7f14383772ef2010fe2560cd302fd18403c7dbfd1c6de2ceefe6
{
  "status": "DECLARATION_ONLY_NO_AFTERSTATES",
  "schema": "independent-nominal-full-state/1",
  "root_fields": [
    "schema",
    "profile",
    "caseId",
    "states",
    "terminalStepContract",
    "observerCuts"
  ],
  "state_fields": [
    "program",
    "control",
    "environment",
    "frames_top_first",
    "events"
  ],
  "program": "Whole exact ng_program input object in every state.",
  "constructor_wire": "NGControl/NGFrame/NGEvent each is one-key object {constructor_name: {each declared payload name: recursively decoded value}}; exact payload names/orders from PUBLIC-LT-API.",
  "values": {
    "UInt": "JSON integer in one-key UInt object",
    "Bool": "JSON boolean in one-key Bool object",
    "Nominal": "one-key Nominal object with type_id,ctor_id,ordered fields"
  },
  "map": "All bindings as array of {name_id:integer,value:NGValue}, sorted by integer name_id; no deletion/overwrite.",
  "sequences": "All ordered rows retained; frames top-first; events cumulative append order.",
  "scalar_distinction": "Integer/Boolean are different types; no float/finite-value coercion.",
  "states": "Every complete chronological boundary from initial through after-each and final, without duplicated final.",
  "expected_ordinal_authoring": "Oracle author independently derives ordinal array from own complete states; do not obtain it from actual wire.",
  "no_state_values_or_terminal_result_supplied": true,
  "basis": "Public constructor declarations and existing CompleteKWire representation contract; no model rule or semantic evaluator supplied."
}

===== END BODY 7 =====

===== COMPLETE BODY 8 Public API all frame/event/control payloads incl Lt boundary =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/PUBLIC-LT-API.json
BYTES: 14506 SHA256: a4031743f3a27eafeacb04f1def037ae07de231391b61774c47210ebeb42ca24
{
  "status": "DECLARATION_ONLY_SAFE_FOR_INDEPENDENT_ORACLE_AUTHOR_NO_RULES_OR_EXPECTED_OUTPUTS",
  "syntax_source": "context/COMPLETE-LT-CONSTRUCTOR-SYNTAX.k.txt",
  "state_fields": [
    "program",
    "control",
    "environment",
    "frames_top_first",
    "events"
  ],
  "entrypoints": {
    "ngInitial": "(NGProgram,Map)->NGState",
    "ngStep": "NGState->NGState",
    "ngAdvance": "(NGState,nonnegative observation microstep count)->NGState; zero returns exact pending state, no semantic exhaustion"
  },
  "frame_payload_order": {
    "ngAddLeft": [
      "expr_id",
      "occurrence",
      "right_expr_id",
      "saved_environment"
    ],
    "ngAddRight": [
      "expr_id",
      "occurrence",
      "left_value",
      "saved_environment"
    ],
    "ngArguments": [
      "call_expr_id",
      "call_occurrence",
      "function_name_id",
      "argument_cursor",
      "active_expr_id",
      "evaluated_prefix",
      "remaining_expr_ids",
      "saved_environment"
    ],
    "ngFunctionReturn": [
      "call_expr_id",
      "call_occurrence",
      "function_name_id",
      "return_type_id",
      "saved_environment"
    ],
    "ngConstructorFields": [
      "constructor_expr_id",
      "constructor_occurrence",
      "type_id",
      "ctor_id",
      "field_types",
      "field_cursor",
      "active_expr_id",
      "evaluated_prefix",
      "remaining_expr_ids",
      "saved_environment"
    ],
    "ngScrutinee": [
      "match_expr_id",
      "match_occurrence",
      "source_arms",
      "saved_environment"
    ],
    "ngArmScope": [
      "match_expr_id",
      "match_occurrence",
      "source_arm_id",
      "saved_environment"
    ],
    "ngLetValue": [
      "source_expr",
      "occurrence",
      "binder",
      "bound_expr",
      "body_expr",
      "saved_environment"
    ],
    "ngLetScope": [
      "source_expr",
      "occurrence",
      "binder",
      "saved_environment"
    ],
    "ngCondition": [
      "source_expr",
      "occurrence",
      "condition_expr",
      "yes_expr",
      "no_expr",
      "saved_environment"
    ],
    "ngLtLeft": [
      "expr_id",
      "occurrence",
      "right_expr_id",
      "saved_environment"
    ],
    "ngLtRight": [
      "expr_id",
      "occurrence",
      "left_value",
      "saved_environment"
    ]
  },
  "event_payload_order": {
    "ngLiteralEvaluated": [
      "expr_id",
      "occurrence",
      "value"
    ],
    "ngVariableRead": [
      "expr_id",
      "occurrence",
      "name_id",
      "value"
    ],
    "ngAddStarted": [
      "expr_id",
      "occurrence",
      "left_expr_id",
      "right_expr_id",
      "saved_environment"
    ],
    "ngAddRightRequested": [
      "expr_id",
      "occurrence",
      "left_value",
      "right_expr_id",
      "saved_environment"
    ],
    "ngAdded": [
      "expr_id",
      "occurrence",
      "left_value",
      "right_value",
      "result"
    ],
    "ngConstructorStarted": [
      "expr_id",
      "occurrence",
      "type_id",
      "ctor_id",
      "field_expr_ids",
      "field_types",
      "saved_environment"
    ],
    "ngConstructorFieldReturned": [
      "constructor_expr_id",
      "constructor_occurrence",
      "field_cursor",
      "completed_expr_id",
      "completed_expr_occurrence",
      "value",
      "prefix_after",
      "remaining_expr_ids_after",
      "saved_environment"
    ],
    "ngConstructorBuilt": [
      "constructor_expr_id",
      "constructor_occurrence",
      "type_id",
      "ctor_id",
      "value",
      "saved_environment"
    ],
    "ngCallStarted": [
      "call_expr_id",
      "call_occurrence",
      "function_name_id",
      "argument_expr_ids",
      "saved_environment"
    ],
    "ngArgumentReturned": [
      "call_expr_id",
      "call_occurrence",
      "argument_cursor",
      "completed_expr_id",
      "value",
      "prefix_after",
      "remaining_expr_ids_after",
      "saved_environment"
    ],
    "ngFunctionEntered": [
      "call_expr_id",
      "call_occurrence",
      "function_name_id",
      "arguments",
      "bound_environment",
      "return_type_id"
    ],
    "ngFunctionReturned": [
      "call_expr_id",
      "call_occurrence",
      "function_name_id",
      "value",
      "restored_environment"
    ],
    "ngMatchStarted": [
      "match_expr_id",
      "match_occurrence",
      "scrutinee_expr_id",
      "source_arms",
      "saved_environment"
    ],
    "ngScrutineeReturned": [
      "match_expr_id",
      "match_occurrence",
      "value",
      "source_arms",
      "saved_environment"
    ],
    "ngArmMiss": [
      "match_expr_id",
      "match_occurrence",
      "source_arm_id",
      "scrutinee_value"
    ],
    "ngArmSelected": [
      "match_expr_id",
      "match_occurrence",
      "source_arm_id",
      "bindings",
      "body_expr_id",
      "body_environment"
    ],
    "ngArmBodyReturned": [
      "match_expr_id",
      "match_occurrence",
      "source_arm_id",
      "value",
      "restored_environment"
    ],
    "ngFinished": [
      "value"
    ],
    "ngOutsideEvent": [
      "reason"
    ],
    "ngLetStarted": [
      "source_expr",
      "occurrence",
      "binder",
      "bound_expr",
      "body_expr",
      "saved_environment"
    ],
    "ngLetBound": [
      "source_expr",
      "occurrence",
      "binder",
      "bound_expr",
      "bound_occurrence",
      "bound_value",
      "body_expr",
      "saved_environment",
      "extended_environment"
    ],
    "ngLetBodyReturned": [
      "source_expr",
      "occurrence",
      "binder",
      "returned_value",
      "restored_environment"
    ],
    "ngIfStarted": [
      "source_expr",
      "occurrence",
      "condition_expr",
      "yes_expr",
      "no_expr",
      "saved_environment"
    ],
    "ngBranchSelected": [
      "source_expr",
      "occurrence",
      "condition_expr",
      "condition_occurrence",
      "choice_bool",
      "selected_expr",
      "restored_environment"
    ],
    "ngLtStarted": [
      "expr_id",
      "occurrence",
      "left_expr_id",
      "right_expr_id",
      "saved_environment"
    ],
    "ngLtRightRequested": [
      "expr_id",
      "occurrence",
      "left_value",
      "right_expr_id",
      "saved_environment"
    ],
    "ngLtCompared": [
      "expr_id",
      "occurrence",
      "left_value",
      "right_value",
      "result",
      "saved_environment"
    ],
    "ngLtSortFailed": [
      "expr_id",
      "occurrence",
      "left_value",
      "right_value",
      "code",
      "saved_environment"
    ],
    "ngLtPrimitiveReturned": [
      "expr_id",
      "occurrence",
      "value",
      "environment"
    ],
    "ngLtPrimitiveFailed": [
      "expr_id",
      "occurrence",
      "code",
      "environment"
    ]
  },
  "source_bindings": "ngBinding(name_id,match_expr_id,source_arm_id,field_path,value,tail); match occurrence remains in ArmSelected event",
  "constructor_convention": "cursor is active source field index; active_expr_id separate, remaining_expr_ids excludes active field; evaluated_prefix contains already completed values. Actual tail frames are caller return_context. A Return control before consume retains this frame unchanged. Materialize is separate post-last-return control.",
  "events_granularity": "Exactly one appended operation-specific event per advancing ngStep; terminal ngHalted(_), ngOutsideModel(_) and ngLtError(_,_,11) ngStep is the identical complete state with no appended event; ngAdvance at these terminals also preserves state (including any positive observation bound), and ngObserve stops without a terminal-stutter row. ngAdvance observer count is not A/B/fuel/work. Add/Call/Match/Construct each have explicit start events; fields/args/scrutinee/body/function returns are separate events. Arm selection attempts one source arm per ngStep, emitting miss or selected; selected body actually evaluated. ngFinished publishes top-level Return without claiming A80 charge.",
  "input_domain": {
    "type_id": 20,
    "recursive_group": 9,
    "ctors": {
      "Done": 21,
      "Pay": 22,
      "Both": 23
    },
    "functions": {
      "sum": 50,
      "first": 51,
      "copy": 52
    },
    "source_ids": "Input ExprIds and explicit occurrence integers remain separate; no source remapping."
  },
  "no_semantic_outputs_in_this_file": true,
  "control_payload_order": {
    "ngEval": [
      "expr_id"
    ],
    "ngReturn": [
      "value"
    ],
    "ngApply": [
      "call_expr_id",
      "call_occurrence",
      "function_name_id",
      "arguments"
    ],
    "ngChoose": [
      "match_expr_id",
      "match_occurrence",
      "scrutinee_value",
      "remaining_source_arms",
      "saved_environment"
    ],
    "ngMaterialize": [
      "constructor_expr_id",
      "constructor_occurrence",
      "type_id",
      "ctor_id",
      "ordered_values"
    ],
    "ngHalted": [
      "value"
    ],
    "ngOutsideModel": [
      "reason"
    ],
    "ngLtPrimitiveValue": [
      "expr_id",
      "occurrence",
      "value"
    ],
    "ngLtPrimitiveError": [
      "expr_id",
      "occurrence",
      "code"
    ],
    "ngLtError": [
      "expr_id",
      "occurrence",
      "code"
    ]
  },
  "return_event_remainder_convention": "remaining_expr_ids_after is new pending frame tail-only remainder after selecting new active next expression; final return uses[]. completed_expr_id/occurrence name original active field/argument source expression, never a callee body leaf.",
  "call_environment_convention": "Callee body receives parameter bindings only; FunctionReturn saves caller environment; match body extends saved current environment, ArmScope restores it.",
  "kind": "DECLARATION_ONLY_SOURCE_SUCCESSOR_NO_EXPECTED_OUTPUTS",
  "predecessor_public_api": "generic-nominal-product-model-v2-review-operation-20261018/context/PUBLIC-API.json",
  "let_if_extension": {
    "kind": "DECLARATION_ONLY_NO_EXPECTED_OUTPUTS",
    "profile": "proposed uncharged nominal reference successor; no A/B clock equivalence",
    "state": "ngState(NGProgram,NGControl,Map,NGFrames,NGEvents)",
    "observer": "ngObserve(NGState,Int) => NGTape(initial,ordered each-after,final); budget0 exact unchanged state; no terminal stutter records",
    "new_expressions": {
      "ngLet": [
        "occurrence",
        "binder",
        "bound_expr",
        "body_expr"
      ],
      "ngIf": [
        "occurrence",
        "condition_expr",
        "yes_expr",
        "no_expr"
      ]
    },
    "new_frames": {
      "ngLetValue": [
        "source_expr",
        "occurrence",
        "binder",
        "bound_expr",
        "body_expr",
        "saved_environment"
      ],
      "ngLetScope": [
        "source_expr",
        "occurrence",
        "binder",
        "saved_environment"
      ],
      "ngCondition": [
        "source_expr",
        "occurrence",
        "condition_expr",
        "yes_expr",
        "no_expr",
        "saved_environment"
      ]
    },
    "new_events": {
      "ngLetStarted": [
        "source_expr",
        "occurrence",
        "binder",
        "bound_expr",
        "body_expr",
        "saved_environment"
      ],
      "ngLetBound": [
        "source_expr",
        "occurrence",
        "binder",
        "bound_expr",
        "bound_occurrence",
        "bound_value",
        "body_expr",
        "saved_environment",
        "extended_environment"
      ],
      "ngLetBodyReturned": [
        "source_expr",
        "occurrence",
        "binder",
        "returned_value",
        "restored_environment"
      ],
      "ngIfStarted": [
        "source_expr",
        "occurrence",
        "condition_expr",
        "yes_expr",
        "no_expr",
        "saved_environment"
      ],
      "ngBranchSelected": [
        "source_expr",
        "occurrence",
        "condition_expr",
        "condition_occurrence",
        "choice_bool",
        "selected_expr",
        "restored_environment"
      ]
    },
    "control_changes": [],
    "state_field_changes": [],
    "event_contract": "Exactly one event per advancing ngStep; terminal ngStep unchanged; ngFinished is separate uncharged publication",
    "admission_premises": "finite closed expression/function tables, unique source/name/definition mapping where required, typed normal operands, binder-linear patterns, existing extensional finite-value domain",
    "execution": "NONE"
  },
  "extension_profile": {
    "name": "K-uncharged-nominal-Lt-completion/1",
    "P1_error_publication": "UNMODELED; ngLtError11 is a stable error-control observation boundary",
    "source_admission": "Existing closed/canonical/admitted NGProgram and nominal-value premises. No malformed nominal/admission/error-policy guard claim.",
    "steps": "Lt expression left/right strict evaluation, source-bearing typed completion, separate primitive return/error; no work/fuel/cap carrier.",
    "terminal_controls": [
      "ngHalted(_)",
      "ngOutsideModel(_)",
      "ngLtError(_,_,11)"
    ],
    "Lt_error_boundary_stutter": {
      "ngStep": "ngStep(ngState(P,ngLtError(E,O,11),Rho,Fs,Es)) is exactly ngState(P,ngLtError(E,O,11),Rho,Fs,Es); no event appended.",
      "ngAdvance": "ngAdvance at bound0 returns exact input; any positive bound on ngLtError(E,O,11) returns the identical complete state; no event appended.",
      "ngObserve": "Stops upon ngTerminal(ngLtError(E,O,11)) and returns the complete tape without invoking ngStep on that boundary and without a terminal-stutter state row.",
      "scope": "Error-control observation boundary only, not P1 Rejected publication."
    },
    "nonterminal_Lt_controls": {
      "ngLtPrimitiveValue(E,O,V)": "Always nonterminal. Bool V steps to ngReturn(V) with ngLtPrimitiveReturned event; non-Bool V steps to OutsideModel using declared reason token.",
      "ngLtPrimitiveError(E,O,Code)": "Always nonterminal. Code11 steps to terminal ngLtError(E,O,11) with ngLtPrimitiveFailed event; any other code steps to OutsideModel using declared reason token.",
      "ngLtError(E,O,Code) when Code != 11": "Nonterminal; one ngStep goes to OutsideModel using declared reason token."
    },
    "OutsideModel_reason_tokens": {
      "malformed_scalar_operand": "lt_operand_outside_UInt128_admitted_domain",
      "nonBool_primitive_value_carrier": "lt_primitive_value_carrier_not_Bool",
      "non11_primitive_error_carrier": "lt_primitive_error_code_outside_profile",
      "non11_error_boundary_carrier": "lt_error_boundary_code_outside_profile"
    }
  }
}

===== END BODY 8 =====

===== COMPLETE BODY 9 Existing zero-local-index clarification, no expected changes =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/OBSERVER-CUT-DECLARATION-CLARIFICATION.json
BYTES: 763 SHA256: f68e203908f2ad3b1a0a1f0cfa5a81073fb6ef8bd9cf9a87b9707db08f6b48e1
{
  "kind": "SOURCE_DERIVED_REPRESENTATION_CLARIFICATION_NO_GOLDEN_OR_SOURCE_EDIT",
  "window_ordinal_convention": "Existing consumer checked_window requires [0,1]; existing raw decoder supplies list(range(len(actual_states))); these are zero-based local window ordinals.",
  "joined_ordinal_convention": "Existing link outputs [0,1,2] for the three chronological complete positions.",
  "safe_author_metadata": "SAFE-HANDOFF explicitly says oracle observerCuts uses zero-based local positions and flags lack of explicit numeric-base/locality in original packet.",
  "scope": "Representational indexing only; no expected state/event/value is read, derived from actual or changed. Reviewer must assess applicability rather than infer an expectation-body audit."
}

===== END BODY 9 =====

===== COMPLETE BODY 10 COMPLETE K SOURCE nominal-product-syntax.k =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/source/nominal-product-syntax.k
BYTES: 5090 SHA256: 750f9b820a672865b2a1abc50bef4f417f2c6c02e7b77f661a0431388dacab8c
requires "domains.md"

module SHERLOCK-NOMINAL-PRODUCT-SYNTAX
  imports DOMAINS-SYNTAX
  imports MAP

  syntax NGValue ::= ngUInt(Int) | ngBool(Bool) | ngNominal(Int, Int, NGValues)
  syntax NGValues ::= ngNoValues() | ngValue(NGValue, NGValues)
  syntax NGTypes ::= ngNoTypes() | ngType(Int, NGTypes)
  syntax NGExprIds ::= ngNoExprs() | ngExprId(Int, NGExprIds)
  syntax NGCtor ::= ngCtor(Int, Int, Int, NGTypes)
  syntax NGCtors ::= ngNoCtors() | ngCtorRow(NGCtor, NGCtors)
  syntax NGDecls ::= ngNoDecls() | ngDecl(Int, Int, NGCtors, NGDecls)
  syntax NGPattern ::= ngWildcard() | ngBind(Int)
                     | ngConstructorPattern(Int, Int, NGPatterns)
  syntax NGPatterns ::= ngNoPatterns() | ngPattern(NGPattern, NGPatterns)
  syntax NGArms ::= ngNoArms() | ngArm(Int, NGPattern, Int, NGArms)
  // Every expression carries a source occurrence independent of its table ID.
  syntax NGExpr ::= ngLiteral(Int, NGValue) | ngVariable(Int, Int)
                  | ngAdd(Int, Int, Int) | ngConstruct(Int, Int, Int, NGExprIds)
                  | ngCall(Int, Int, NGExprIds) | ngMatch(Int, Int, NGArms)
                  | ngLet(Int, Int, Int, Int) | ngIf(Int, Int, Int, Int)
  syntax NGNodes ::= ngNoNodes() | ngNode(Int, NGExpr, NGNodes)
  syntax NGParams ::= ngNoParams() | ngParam(Int, Int, NGParams)
  syntax NGFunction ::= ngFunction(Int, NGParams, Int, Int)
  syntax NGFunctions ::= ngNoFunctions() | ngFunctionRow(NGFunction, NGFunctions)
  syntax NGProgram ::= ngProgram(NGDecls, NGNodes, NGFunctions, Int)

  syntax NGPath ::= ngRoot() | ngAt(Int, NGPath)
  // name, match expression, source arm, source field path, value
  syntax NGBindings ::= ngNoBindings()
                      | ngBinding(Int, Int, Int, NGPath, NGValue, NGBindings)
  syntax NGMatching ::= ngMatched(NGBindings) | ngMiss()
  syntax NGEnvironment ::= ngBoundEnvironment(Map) | ngBadBindings()
  syntax NGExprLookup ::= ngFoundExpr(NGExpr) | ngMissingExpr()
  syntax NGFunctionLookup ::= ngFoundFunction(NGFunction) | ngMissingFunction()
  syntax NGCtorLookup ::= ngFoundCtor(NGCtor) | ngMissingCtor()

  syntax NGFrame ::= ngAddLeft(Int, Int, Int, Map)
                   | ngAddRight(Int, Int, NGValue, Map)
                   | ngArguments(Int, Int, Int, Int, Int, NGValues, NGExprIds, Map)
                   | ngFunctionReturn(Int, Int, Int, Int, Map)
                   | ngConstructorFields(Int, Int, Int, Int, NGTypes, Int, Int,
                                         NGValues, NGExprIds, Map)
                   | ngScrutinee(Int, Int, NGArms, Map)
                   | ngArmScope(Int, Int, Int, Map)
                   | ngLetValue(Int, Int, Int, Int, Int, Map)
                   | ngLetScope(Int, Int, Int, Map)
                   | ngCondition(Int, Int, Int, Int, Int, Map)
  syntax NGFrames ::= ngNoFrames() | ngFrame(NGFrame, NGFrames)
  syntax NGControl ::= ngEval(Int) | ngReturn(NGValue)
                     | ngApply(Int, Int, Int, NGValues)
                     | ngChoose(Int, Int, NGValue, NGArms, Map)
                     | ngMaterialize(Int, Int, Int, Int, NGValues)
                     | ngHalted(NGValue) | ngOutsideModel(String)
  // Trace identity is separate from extensional immutable NGValue.
  syntax NGEvent ::= ngLiteralEvaluated(Int, Int, NGValue)
                   | ngVariableRead(Int, Int, Int, NGValue)
                   | ngAddStarted(Int, Int, Int, Int, Map)
                   | ngAddRightRequested(Int, Int, NGValue, Int, Map)
                   | ngAdded(Int, Int, NGValue, NGValue, NGValue)
                   | ngConstructorStarted(Int, Int, Int, Int, NGExprIds, NGTypes, Map)
                   | ngConstructorFieldReturned(Int, Int, Int, Int, Int, NGValue,
                                                 NGValues, NGExprIds, Map)
                   | ngConstructorBuilt(Int, Int, Int, Int, NGValue, Map)
                   | ngCallStarted(Int, Int, Int, NGExprIds, Map)
                   | ngArgumentReturned(Int, Int, Int, Int, NGValue, NGValues,
                                         NGExprIds, Map)
                   | ngFunctionEntered(Int, Int, Int, NGValues, Map, Int)
                   | ngFunctionReturned(Int, Int, Int, NGValue, Map)
                   | ngMatchStarted(Int, Int, Int, NGArms, Map)
                   | ngScrutineeReturned(Int, Int, NGValue, NGArms, Map)
                   | ngArmMiss(Int, Int, Int, NGValue)
                   | ngArmSelected(Int, Int, Int, NGBindings, Int, Map)
                   | ngArmBodyReturned(Int, Int, Int, NGValue, Map)
                   | ngLetStarted(Int, Int, Int, Int, Int, Map)
                   | ngLetBound(Int, Int, Int, Int, Int, NGValue, Int, Map, Map)
                   | ngLetBodyReturned(Int, Int, Int, NGValue, Map)
                   | ngIfStarted(Int, Int, Int, Int, Int, Map)
                   | ngBranchSelected(Int, Int, Int, Int, Bool, Int, Map)
                   | ngFinished(NGValue) | ngOutsideEvent(String)
  syntax NGEvents ::= ngNoEvents() | ngEvent(NGEvent, NGEvents)
  syntax NGState ::= ngState(NGProgram, NGControl, Map, NGFrames, NGEvents)
endmodule

===== END BODY 10 =====

===== COMPLETE BODY 11 COMPLETE K SOURCE nominal-product.k =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/source/nominal-product.k
BYTES: 21856 SHA256: 29da74d7ab2b89cb23155521b94ffb6880920befcbf9806941ba97826d47b197
requires "nominal-product-syntax.k"

// Positive admitted-domain reference only. New uncharged microsteps; no A39,
// B helper clock, product diagnostic, capacity/guard or financial policy.
module SHERLOCK-NOMINAL-PRODUCT
  imports SHERLOCK-NOMINAL-PRODUCT-SYNTAX
  imports DOMAINS

  syntax NGNodes ::= ngNodes(NGProgram) [function]
  rule ngNodes(ngProgram(_, Ns, _, _)) => Ns
  syntax NGFunctions ::= ngFunctions(NGProgram) [function]
  rule ngFunctions(ngProgram(_, _, Fs, _)) => Fs
  syntax NGDecls ::= ngDeclarations(NGProgram) [function]
  rule ngDeclarations(ngProgram(Ds, _, _, _)) => Ds
  syntax NGExprLookup ::= ngFindExpr(Int, NGNodes) [function]
  rule ngFindExpr(_, ngNoNodes()) => ngMissingExpr()
  rule ngFindExpr(E, ngNode(E, X, _)) => ngFoundExpr(X)
  rule ngFindExpr(E, ngNode(F, _, Rest)) => ngFindExpr(E, Rest)
    requires E =/=Int F
  syntax Int ::= ngOccurrence(NGExprLookup) [function]
  rule ngOccurrence(ngFoundExpr(ngLiteral(O, _))) => O
  rule ngOccurrence(ngFoundExpr(ngVariable(O, _))) => O
  rule ngOccurrence(ngFoundExpr(ngAdd(O, _, _))) => O
  rule ngOccurrence(ngFoundExpr(ngConstruct(O, _, _, _))) => O
  rule ngOccurrence(ngFoundExpr(ngCall(O, _, _))) => O
  rule ngOccurrence(ngFoundExpr(ngMatch(O, _, _))) => O
  rule ngOccurrence(ngFoundExpr(ngLet(O, _, _, _))) => O
  rule ngOccurrence(ngFoundExpr(ngIf(O, _, _, _))) => O
  syntax NGFunctionLookup ::= ngFindFunction(Int, NGFunctions) [function]
  rule ngFindFunction(_, ngNoFunctions()) => ngMissingFunction()
  rule ngFindFunction(F, ngFunctionRow(ngFunction(F, Ps, T, B), _))
    => ngFoundFunction(ngFunction(F, Ps, T, B))
  rule ngFindFunction(F, ngFunctionRow(ngFunction(G, _, _, _), Rest))
    => ngFindFunction(F, Rest) requires F =/=Int G
  syntax NGCtorLookup ::= ngFindCtor(Int, Int, NGDecls) [function]
                       | ngFindCtorRow(Int, Int, NGCtors) [function]
  rule ngFindCtor(_, _, ngNoDecls()) => ngMissingCtor()
  rule ngFindCtor(T, C, ngDecl(T, _, Cs, _)) => ngFindCtorRow(T, C, Cs)
  rule ngFindCtor(T, C, ngDecl(U, _, _, Rest)) => ngFindCtor(T, C, Rest)
    requires T =/=Int U
  rule ngFindCtorRow(_, _, ngNoCtors()) => ngMissingCtor()
  rule ngFindCtorRow(T, C, ngCtorRow(ngCtor(T, C, S, Ts), _))
    => ngFoundCtor(ngCtor(T, C, S, Ts))
  rule ngFindCtorRow(T, C, ngCtorRow(ngCtor(U, D, _, _), Rest))
    => ngFindCtorRow(T, C, Rest) requires T =/=Int U orBool C =/=Int D
  syntax Int ::= ngTypeOf(NGValue) [function]
  rule ngTypeOf(ngUInt(_)) => 0
  rule ngTypeOf(ngBool(_)) => 1
  rule ngTypeOf(ngNominal(T, _, _)) => T
  syntax Bool ::= ngIsUInt(NGValue) [function]
  rule ngIsUInt(ngUInt(_)) => true
  rule ngIsUInt(ngBool(_)) => false
  rule ngIsUInt(ngNominal(_, _, _)) => false
  syntax Bool ::= ngIsBool(NGValue) [function]
  rule ngIsBool(ngBool(_)) => true
  rule ngIsBool(ngUInt(_)) => false
  rule ngIsBool(ngNominal(_, _, _)) => false
  syntax Int ::= ngTypeCount(NGTypes) [function]
               | ngExprCount(NGExprIds) [function]
               | ngTypeAt(NGTypes, Int) [function]
  rule ngTypeCount(ngNoTypes()) => 0
  rule ngTypeCount(ngType(_, Ts)) => 1 +Int ngTypeCount(Ts)
  rule ngExprCount(ngNoExprs()) => 0
  rule ngExprCount(ngExprId(_, Es)) => 1 +Int ngExprCount(Es)
  rule ngTypeAt(ngType(T, _), 0) => T
  rule ngTypeAt(ngType(_, Ts), I) => ngTypeAt(Ts, I -Int 1) requires I >Int 0
  syntax NGValues ::= ngAppendValue(NGValues, NGValue) [function]
  rule ngAppendValue(ngNoValues(), V) => ngValue(V, ngNoValues())
  rule ngAppendValue(ngValue(H, T), V) => ngValue(H, ngAppendValue(T, V))
  syntax NGEvents ::= ngAppendEvent(NGEvents, NGEvent) [function]
  rule ngAppendEvent(ngNoEvents(), E) => ngEvent(E, ngNoEvents())
  rule ngAppendEvent(ngEvent(H, T), E) => ngEvent(H, ngAppendEvent(T, E))

  // Parameter bindings have only parameters, never the caller environment.
  // Unique names, closed code and binder-linear patterns remain input premises.
  syntax NGEnvironment ::= ngBindParameters(NGParams, NGValues) [function]
                         | ngBindParameter(Int, Int, NGValue, NGEnvironment) [function]
  rule ngBindParameters(ngNoParams(), ngNoValues()) => ngBoundEnvironment(.Map)
  rule ngBindParameters(ngParam(N, T, Ps), ngValue(V, Vs))
    => ngBindParameter(N, T, V, ngBindParameters(Ps, Vs))
  rule ngBindParameters(ngNoParams(), ngValue(_, _)) => ngBadBindings()
  rule ngBindParameters(ngParam(_, _, _), ngNoValues()) => ngBadBindings()
  rule ngBindParameter(N, T, V, ngBoundEnvironment(Rho))
    => ngBoundEnvironment(Rho[N <- V])
    requires ngTypeOf(V) ==Int T andBool notBool N in_keys(Rho)
  rule ngBindParameter(_, _, _, ngBadBindings()) => ngBadBindings()
  rule ngBindParameter(N, T, V, ngBoundEnvironment(Rho)) => ngBadBindings()
    requires ngTypeOf(V) =/=Int T orBool N in_keys(Rho)

  syntax NGPath ::= ngChildPath(NGPath, Int) [function]
  rule ngChildPath(ngRoot(), I) => ngAt(I, ngRoot())
  rule ngChildPath(ngAt(H, T), I) => ngAt(H, ngChildPath(T, I))
  syntax NGBindings ::= ngJoinBindings(NGBindings, NGBindings) [function]
  rule ngJoinBindings(ngNoBindings(), Bs) => Bs
  rule ngJoinBindings(ngBinding(N, M, A, P, V, Rest), Bs)
    => ngBinding(N, M, A, P, V, ngJoinBindings(Rest, Bs))
  syntax NGMatching ::= ngCombineMatches(NGMatching, NGMatching) [function]
  rule ngCombineMatches(ngMatched(A), ngMatched(B)) => ngMatched(ngJoinBindings(A, B))
  rule ngCombineMatches(ngMiss(), _) => ngMiss()
  rule ngCombineMatches(ngMatched(_), ngMiss()) => ngMiss()
  syntax NGMatching ::= ngMatchPattern(NGPattern, NGValue, Int, Int, NGPath) [function]
                      | ngMatchFields(NGPatterns, NGValues, Int, Int, NGPath, Int) [function]
  rule ngMatchPattern(ngWildcard(), _, _, _, _) => ngMatched(ngNoBindings())
  rule ngMatchPattern(ngBind(N), V, M, A, Path)
    => ngMatched(ngBinding(N, M, A, Path, V, ngNoBindings()))
  rule ngMatchPattern(ngConstructorPattern(T, C, Ps), ngNominal(T, C, Vs), M, A, Path)
    => ngMatchFields(Ps, Vs, M, A, Path, 0)
  rule ngMatchPattern(ngConstructorPattern(T, C, _), ngNominal(U, D, _), _, _, _)
    => ngMiss() requires T =/=Int U orBool C =/=Int D
  rule ngMatchPattern(ngConstructorPattern(_, _, _), ngUInt(_), _, _, _) => ngMiss()
  rule ngMatchPattern(ngConstructorPattern(_, _, _), ngBool(_), _, _, _) => ngMiss()
  rule ngMatchFields(ngNoPatterns(), ngNoValues(), _, _, _, _) => ngMatched(ngNoBindings())
  rule ngMatchFields(ngPattern(P, Ps), ngValue(V, Vs), M, A, Path, I)
    => ngCombineMatches(ngMatchPattern(P, V, M, A, ngChildPath(Path, I)),
                         ngMatchFields(Ps, Vs, M, A, Path, I +Int 1))
  rule ngMatchFields(ngNoPatterns(), ngValue(_, _), _, _, _, _) => ngMiss()
  rule ngMatchFields(ngPattern(_, _), ngNoValues(), _, _, _, _) => ngMiss()
  syntax Map ::= ngExtendEnvironment(NGBindings, Map) [function]
  rule ngExtendEnvironment(ngNoBindings(), Rho) => Rho
  rule ngExtendEnvironment(ngBinding(N, _, _, _, V, Bs), Rho)
    => ngExtendEnvironment(Bs, Rho[N <- V])

  syntax NGState ::= ngInitial(NGProgram, Map) [function]
                  | ngStep(NGState) [function]
                  | ngAdvance(NGState, Int) [function]
                  | ngOutside(NGState, String) [function]
  rule ngInitial(ngProgram(Ds, Ns, Fs, E), Rho)
    => ngState(ngProgram(Ds, Ns, Fs, E), ngEval(E), Rho, ngNoFrames(), ngNoEvents())
  rule ngOutside(ngState(P, _, Rho, Fs, Es), Reason)
    => ngState(P, ngOutsideModel(Reason), Rho, Fs,
               ngAppendEvent(Es, ngOutsideEvent(Reason)))
  rule ngStep(ngState(P, ngHalted(V), Rho, Fs, Es))
    => ngState(P, ngHalted(V), Rho, Fs, Es)
  rule ngStep(ngState(P, ngOutsideModel(S), Rho, Fs, Es))
    => ngState(P, ngOutsideModel(S), Rho, Fs, Es)
  // Observer cuts preserve pending controls/frames/events; no exhaustion/fuel.
  rule ngAdvance(S, 0) => S
  rule ngAdvance(ngState(P, ngHalted(V), Rho, Fs, Es), N)
    => ngState(P, ngHalted(V), Rho, Fs, Es) requires N >Int 0
  rule ngAdvance(ngState(P, ngOutsideModel(S), Rho, Fs, Es), N)
    => ngState(P, ngOutsideModel(S), Rho, Fs, Es) requires N >Int 0
  syntax Bool ::= ngTerminal(NGControl) [function]
  rule ngTerminal(ngHalted(_)) => true
  rule ngTerminal(ngOutsideModel(_)) => true
  rule ngTerminal(ngEval(_)) => false
  rule ngTerminal(ngReturn(_)) => false
  rule ngTerminal(ngApply(_, _, _, _)) => false
  rule ngTerminal(ngChoose(_, _, _, _, _)) => false
  rule ngTerminal(ngMaterialize(_, _, _, _, _)) => false
  rule ngAdvance(ngState(P, C, Rho, Fs, Es), N)
    => ngAdvance(ngStep(ngState(P, C, Rho, Fs, Es)), N -Int 1)
    requires N >Int 0 andBool notBool ngTerminal(C)

  syntax NGState ::= ngEvaluate(NGExprLookup, Int, NGProgram, Map, NGFrames, NGEvents) [function]
  rule ngStep(ngState(P, ngEval(E), Rho, Fs, Es))
    => ngEvaluate(ngFindExpr(E, ngNodes(P)), E, P, Rho, Fs, Es)
  rule ngEvaluate(ngMissingExpr(), E, P, Rho, Fs, Es)
    => ngOutside(ngState(P, ngEval(E), Rho, Fs, Es), "missing_expression")
  rule ngEvaluate(ngFoundExpr(ngLiteral(O, V)), E, P, Rho, Fs, Es)
    => ngState(P, ngReturn(V), Rho, Fs,
               ngAppendEvent(Es, ngLiteralEvaluated(E, O, V)))
  rule ngEvaluate(ngFoundExpr(ngVariable(O, X)), E, P,
                  (X |-> V:NGValue) Rho:Map, Fs, Es)
    => ngState(P, ngReturn(V), (X |-> V) Rho, Fs,
               ngAppendEvent(Es, ngVariableRead(E, O, X, V)))
  rule ngEvaluate(ngFoundExpr(ngVariable(O, X)), E, P, Rho, Fs, Es)
    => ngOutside(ngState(P, ngEval(E), Rho, Fs, Es), "unbound_name")
    requires notBool X in_keys(Rho)
  rule ngEvaluate(ngFoundExpr(ngAdd(O, L, R)), E, P, Rho, Fs, Es)
    => ngState(P, ngEval(L), Rho, ngFrame(ngAddLeft(E, O, R, Rho), Fs),
               ngAppendEvent(Es, ngAddStarted(E, O, L, R, Rho)))
  rule ngEvaluate(ngFoundExpr(ngLet(O, X, Bound, Body)), E, P, Rho, Fs, Es)
    => ngState(P, ngEval(Bound), Rho,
         ngFrame(ngLetValue(E, O, X, Bound, Body, Rho), Fs),
         ngAppendEvent(Es, ngLetStarted(E, O, X, Bound, Body, Rho)))
  rule ngEvaluate(ngFoundExpr(ngIf(O, Condition, Yes, No)), E, P, Rho, Fs, Es)
    => ngState(P, ngEval(Condition), Rho,
         ngFrame(ngCondition(E, O, Condition, Yes, No, Rho), Fs),
         ngAppendEvent(Es, ngIfStarted(E, O, Condition, Yes, No, Rho)))
  rule ngEvaluate(ngFoundExpr(ngCall(O, F, ngNoExprs())), E, P, Rho, Fs, Es)
    => ngState(P, ngApply(E, O, F, ngNoValues()), Rho, Fs,
               ngAppendEvent(Es, ngCallStarted(E, O, F, ngNoExprs(), Rho)))
  rule ngEvaluate(ngFoundExpr(ngCall(O, F, ngExprId(A, Rest))), E, P, Rho, Fs, Es)
    => ngState(P, ngEval(A), Rho,
         ngFrame(ngArguments(E, O, F, 0, A, ngNoValues(), Rest, Rho), Fs),
         ngAppendEvent(Es, ngCallStarted(E, O, F, ngExprId(A, Rest), Rho)))
  rule ngEvaluate(ngFoundExpr(ngMatch(O, X, As)), E, P, Rho, Fs, Es)
    => ngState(P, ngEval(X), Rho, ngFrame(ngScrutinee(E, O, As, Rho), Fs),
               ngAppendEvent(Es, ngMatchStarted(E, O, X, As, Rho)))
  rule ngEvaluate(ngFoundExpr(ngConstruct(O, T, C, Xs)), E, P, Rho, Fs, Es)
    => ngStartConstructor(ngFindCtor(T, C, ngDeclarations(P)), E, O, T, C, Xs,
                           P, Rho, Fs, Es)

  syntax NGState ::= ngStartConstructor(NGCtorLookup, Int, Int, Int, Int, NGExprIds,
                                        NGProgram, Map, NGFrames, NGEvents) [function]
  rule ngStartConstructor(ngMissingCtor(), E, _, _, _, _, P, Rho, Fs, Es)
    => ngOutside(ngState(P, ngEval(E), Rho, Fs, Es), "constructor_not_declared")
  rule ngStartConstructor(ngFoundCtor(ngCtor(T, C, _, ngNoTypes())), E, O, T, C,
                           ngNoExprs(), P, Rho, Fs, Es)
    => ngState(P, ngMaterialize(E, O, T, C, ngNoValues()), Rho, Fs,
         ngAppendEvent(Es, ngConstructorStarted(E, O, T, C, ngNoExprs(), ngNoTypes(), Rho)))
  rule ngStartConstructor(ngFoundCtor(ngCtor(T, C, _, Ts)), E, O, T, C,
                           ngExprId(X, Rest), P, Rho, Fs, Es)
    => ngState(P, ngEval(X), Rho,
         ngFrame(ngConstructorFields(E, O, T, C, Ts, 0, X, ngNoValues(), Rest, Rho), Fs),
         ngAppendEvent(Es, ngConstructorStarted(E, O, T, C, ngExprId(X, Rest), Ts, Rho)))
    requires ngTypeCount(Ts) ==Int ngExprCount(ngExprId(X, Rest))
  rule ngStartConstructor(ngFoundCtor(ngCtor(_, _, _, Ts)), E, _, _, _, Xs, P, Rho, Fs, Es)
    => ngOutside(ngState(P, ngEval(E), Rho, Fs, Es), "constructor_arity_outside_model")
    requires ngTypeCount(Ts) =/=Int ngExprCount(Xs)

  rule ngStep(ngState(P, ngReturn(V), Rho, ngNoFrames(), Es))
    => ngState(P, ngHalted(V), Rho, ngNoFrames(), ngAppendEvent(Es, ngFinished(V)))
  // The bound expression is evaluated in its original environment. Its result
  // enters a new lexical scope; the original binding is restored on body return.
  rule ngStep(ngState(P, ngReturn(V), _,
         ngFrame(ngLetValue(E, O, X, Bound, Body, Saved), Fs), Es))
    => ngState(P, ngEval(Body), Saved[X <- V],
         ngFrame(ngLetScope(E, O, X, Saved), Fs),
         ngAppendEvent(Es, ngLetBound(E, O, X, Bound,
           ngOccurrence(ngFindExpr(Bound, ngNodes(P))), V, Body, Saved, Saved[X <- V])))
  rule ngStep(ngState(P, ngReturn(V), _,
         ngFrame(ngLetScope(E, O, X, Saved), Fs), Es))
    => ngState(P, ngReturn(V), Saved, Fs,
         ngAppendEvent(Es, ngLetBodyReturned(E, O, X, V, Saved)))
  // Only the selected branch is requested, after one condition evaluation.
  syntax NGState ::= ngChooseBranch(NGValue, Int, Int, Int, Int, Int,
                                     NGProgram, Map, NGFrames, NGEvents) [function]
  rule ngStep(ngState(P, ngReturn(V), _,
         ngFrame(ngCondition(E, O, Condition, Yes, No, Saved), Fs), Es))
    => ngChooseBranch(V, E, O, Condition, Yes, No, P, Saved, Fs, Es)
  rule ngChooseBranch(ngBool(true), E, O, Condition, Yes, _, P, Saved, Fs, Es)
    => ngState(P, ngEval(Yes), Saved, Fs,
         ngAppendEvent(Es, ngBranchSelected(E, O, Condition,
           ngOccurrence(ngFindExpr(Condition, ngNodes(P))), true, Yes, Saved)))
  rule ngChooseBranch(ngBool(false), E, O, Condition, _, No, P, Saved, Fs, Es)
    => ngState(P, ngEval(No), Saved, Fs,
         ngAppendEvent(Es, ngBranchSelected(E, O, Condition,
           ngOccurrence(ngFindExpr(Condition, ngNodes(P))), false, No, Saved)))
  rule ngChooseBranch(V, E, O, Condition, Yes, No, P, Saved, Fs, Es)
    => ngOutside(ngState(P, ngReturn(V), Saved,
         ngFrame(ngCondition(E, O, Condition, Yes, No, Saved), Fs), Es),
         "condition_type_outside_model") requires notBool ngIsBool(V)
  rule ngStep(ngState(P, ngReturn(V), _, ngFrame(ngAddLeft(E, O, R, Saved), Fs), Es))
    => ngState(P, ngEval(R), Saved, ngFrame(ngAddRight(E, O, V, Saved), Fs),
               ngAppendEvent(Es, ngAddRightRequested(E, O, V, R, Saved)))
  syntax NGState ::= ngFinishAdd(NGValue, NGValue, Int, Int, NGProgram, Map,
                                 NGFrames, NGEvents) [function]
  rule ngStep(ngState(P, ngReturn(V), _, ngFrame(ngAddRight(E, O, L, Saved), Fs), Es))
    => ngFinishAdd(L, V, E, O, P, Saved, Fs, Es)
  rule ngFinishAdd(ngUInt(L), ngUInt(R), E, O, P, Saved, Fs, Es)
    => ngState(P, ngReturn(ngUInt(L +Int R)), Saved, Fs,
               ngAppendEvent(Es, ngAdded(E, O, ngUInt(L), ngUInt(R), ngUInt(L +Int R))))
    requires L >=Int 0 andBool R >=Int 0
      andBool L +Int R <Int 340282366920938463463374607431768211456
  rule ngFinishAdd(ngUInt(L), ngUInt(R), E, O, P, Saved, Fs, Es)
    => ngOutside(ngState(P, ngReturn(ngUInt(R)), Saved,
                         ngFrame(ngAddRight(E, O, ngUInt(L), Saved), Fs), Es),
                  "addition_outside_UInt128_normal_domain")
    requires L <Int 0 orBool R <Int 0
      orBool L +Int R >=Int 340282366920938463463374607431768211456
  rule ngFinishAdd(L, R, E, O, P, Saved, Fs, Es)
    => ngOutside(ngState(P, ngReturn(R), Saved,
                         ngFrame(ngAddRight(E, O, L, Saved), Fs), Es), "addition_type_outside_model")
    requires notBool (ngIsUInt(L) andBool ngIsUInt(R))

  rule ngStep(ngState(P, ngReturn(V), _,
         ngFrame(ngArguments(E, O, F, I, Active, Prefix, ngExprId(X, Rest), Saved), Fs), Es))
    => ngState(P, ngEval(X), Saved,
         ngFrame(ngArguments(E, O, F, I +Int 1, X, ngAppendValue(Prefix, V), Rest, Saved), Fs),
         ngAppendEvent(Es, ngArgumentReturned(E, O, I, Active, V,
                                               ngAppendValue(Prefix, V), Rest, Saved)))
  rule ngStep(ngState(P, ngReturn(V), _,
         ngFrame(ngArguments(E, O, F, I, Active, Prefix, ngNoExprs(), Saved), Fs), Es))
    => ngState(P, ngApply(E, O, F, ngAppendValue(Prefix, V)), Saved, Fs,
         ngAppendEvent(Es, ngArgumentReturned(E, O, I, Active, V,
                                               ngAppendValue(Prefix, V), ngNoExprs(), Saved)))
  syntax NGState ::= ngEnterFunction(NGFunctionLookup, Int, Int, Int, NGValues,
                                      NGProgram, Map, NGFrames, NGEvents) [function]
                   | ngEnterBindings(NGEnvironment, Int, Int, Int, Int, Int, NGValues,
                                      NGProgram, Map, NGFrames, NGEvents) [function]
  rule ngStep(ngState(P, ngApply(E, O, F, Vs), Rho, Fs, Es))
    => ngEnterFunction(ngFindFunction(F, ngFunctions(P)), E, O, F, Vs, P, Rho, Fs, Es)
  rule ngEnterFunction(ngMissingFunction(), E, O, F, Vs, P, Rho, Fs, Es)
    => ngOutside(ngState(P, ngApply(E, O, F, Vs), Rho, Fs, Es), "missing_function")
  rule ngEnterFunction(ngFoundFunction(ngFunction(F, Ps, T, Body)), E, O, F, Vs,
                        P, Rho, Fs, Es)
    => ngEnterBindings(ngBindParameters(Ps, Vs), E, O, F, T, Body, Vs, P, Rho, Fs, Es)
  rule ngEnterBindings(ngBoundEnvironment(New), E, O, F, T, Body, Vs, P, Rho, Fs, Es)
    => ngState(P, ngEval(Body), New,
         ngFrame(ngFunctionReturn(E, O, F, T, Rho), Fs),
         ngAppendEvent(Es, ngFunctionEntered(E, O, F, Vs, New, T)))
  rule ngEnterBindings(ngBadBindings(), E, O, F, _, _, Vs, P, Rho, Fs, Es)
    => ngOutside(ngState(P, ngApply(E, O, F, Vs), Rho, Fs, Es), "function_binding_outside_model")
  rule ngStep(ngState(P, ngReturn(V), _,
                      ngFrame(ngFunctionReturn(E, O, F, T, Saved), Fs), Es))
    => ngState(P, ngReturn(V), Saved, Fs,
               ngAppendEvent(Es, ngFunctionReturned(E, O, F, V, Saved)))
    requires ngTypeOf(V) ==Int T
  rule ngStep(ngState(P, ngReturn(V), Rho,
                      ngFrame(ngFunctionReturn(E, O, F, T, Saved), Fs), Es))
    => ngOutside(ngState(P, ngReturn(V), Rho,
                         ngFrame(ngFunctionReturn(E, O, F, T, Saved), Fs), Es),
                  "function_return_type_outside_model") requires ngTypeOf(V) =/=Int T

  // The active expression belongs to the caller's field source. Nested callee
  // returns cannot replace its identity with the last callee body expression.
  rule ngStep(ngState(P, ngReturn(V), _,
         ngFrame(ngConstructorFields(E, O, T, C, Ts, I, Active, Prefix,
                                      ngExprId(X, Rest), Saved), Fs), Es))
    => ngState(P, ngEval(X), Saved,
         ngFrame(ngConstructorFields(E, O, T, C, Ts, I +Int 1, X,
                                      ngAppendValue(Prefix, V), Rest, Saved), Fs),
         ngAppendEvent(Es, ngConstructorFieldReturned(E, O, I, Active,
           ngOccurrence(ngFindExpr(Active, ngNodes(P))), V,
           ngAppendValue(Prefix, V), Rest, Saved)))
    requires ngTypeOf(V) ==Int ngTypeAt(Ts, I)
  rule ngStep(ngState(P, ngReturn(V), _,
         ngFrame(ngConstructorFields(E, O, T, C, Ts, I, Active, Prefix,
                                      ngNoExprs(), Saved), Fs), Es))
    => ngState(P, ngMaterialize(E, O, T, C, ngAppendValue(Prefix, V)), Saved, Fs,
         ngAppendEvent(Es, ngConstructorFieldReturned(E, O, I, Active,
           ngOccurrence(ngFindExpr(Active, ngNodes(P))), V,
           ngAppendValue(Prefix, V), ngNoExprs(), Saved)))
    requires ngTypeOf(V) ==Int ngTypeAt(Ts, I)
  rule ngStep(ngState(P, ngReturn(V), Rho,
         ngFrame(ngConstructorFields(E, O, T, C, Ts, I, Active, Prefix, Rest, Saved), Fs), Es))
    => ngOutside(ngState(P, ngReturn(V), Rho,
         ngFrame(ngConstructorFields(E, O, T, C, Ts, I, Active, Prefix, Rest, Saved), Fs), Es),
                  "constructor_field_type_outside_model")
    requires ngTypeOf(V) =/=Int ngTypeAt(Ts, I)
  rule ngStep(ngState(P, ngMaterialize(E, O, T, C, Vs), Rho, Fs, Es))
    => ngState(P, ngReturn(ngNominal(T, C, Vs)), Rho, Fs,
         ngAppendEvent(Es, ngConstructorBuilt(E, O, T, C, ngNominal(T, C, Vs), Rho)))

  rule ngStep(ngState(P, ngReturn(V), _, ngFrame(ngScrutinee(E, O, As, Saved), Fs), Es))
    => ngState(P, ngChoose(E, O, V, As, Saved), Saved, Fs,
               ngAppendEvent(Es, ngScrutineeReturned(E, O, V, As, Saved)))
  syntax NGState ::= ngSelectArm(NGMatching, Int, Int, NGValue, Int, Int, NGArms,
                                  NGProgram, Map, NGFrames, NGEvents) [function]
  rule ngStep(ngState(P, ngChoose(E, O, V, ngArm(A, Pat, Body, Rest), Saved), _, Fs, Es))
    => ngSelectArm(ngMatchPattern(Pat, V, E, A, ngRoot()), E, O, V, A, Body, Rest,
                     P, Saved, Fs, Es)
  rule ngSelectArm(ngMiss(), E, O, V, A, _, Rest, P, Saved, Fs, Es)
    => ngState(P, ngChoose(E, O, V, Rest, Saved), Saved, Fs,
               ngAppendEvent(Es, ngArmMiss(E, O, A, V)))
  rule ngSelectArm(ngMatched(Bs), E, O, _, A, Body, _, P, Saved, Fs, Es)
    => ngState(P, ngEval(Body), ngExtendEnvironment(Bs, Saved),
         ngFrame(ngArmScope(E, O, A, Saved), Fs),
         ngAppendEvent(Es, ngArmSelected(E, O, A, Bs, Body, ngExtendEnvironment(Bs, Saved))))
  rule ngStep(ngState(P, ngChoose(E, O, V, ngNoArms(), Saved), Rho, Fs, Es))
    => ngOutside(ngState(P, ngChoose(E, O, V, ngNoArms(), Saved), Rho, Fs, Es),
                  "no_matching_arm_in_selected_normal_model")
  rule ngStep(ngState(P, ngReturn(V), _, ngFrame(ngArmScope(E, O, A, Saved), Fs), Es))
    => ngState(P, ngReturn(V), Saved, Fs,
               ngAppendEvent(Es, ngArmBodyReturned(E, O, A, V, Saved)))
endmodule

===== END BODY 11 =====

===== COMPLETE BODY 12 COMPLETE K SOURCE normal-lt-observations.k =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/source/normal-lt-observations.k
BYTES: 272 SHA256: 5b5cf8667af2ee29477d3d7fee6e566dea50c70edc8808f0b7824bc73750c0ea
requires "normal-trace-observations.k"
requires "normal-lt.k"

// Reuse the complete chronological observer; never substitute result-only data.
module SHERLOCK-NOMINAL-LT-OBSERVATIONS
  imports SHERLOCK-NOMINAL-PRODUCT-OBSERVATIONS
  imports SHERLOCK-NOMINAL-LT
endmodule

===== END BODY 12 =====

===== COMPLETE BODY 13 COMPLETE K SOURCE normal-lt-syntax.k =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/source/normal-lt-syntax.k
BYTES: 1070 SHA256: 814208b14f265534b5bbf0f0264267fc8af76fb7d01d2610c4e02faf7a56d972
requires "nominal-product-syntax.k"

// Additive observation profile, not a change to the retained positive model.
module SHERLOCK-NOMINAL-LT-SYNTAX
  imports SHERLOCK-NOMINAL-PRODUCT-SYNTAX
  syntax NGExpr ::= ngLt(Int, Int, Int)
  syntax NGFrame ::= ngLtLeft(Int, Int, Int, Map)
                   | ngLtRight(Int, Int, NGValue, Map)
  // These source-bearing controls expose completion/primitive boundaries.
  // ngLtError(11) is an error-control observation boundary, not P1 Rejected.
  syntax NGControl ::= ngLtPrimitiveValue(Int, Int, NGValue)
                     | ngLtPrimitiveError(Int, Int, Int)
                     | ngLtError(Int, Int, Int)
  syntax NGEvent ::= ngLtStarted(Int, Int, Int, Int, Map)
                   | ngLtRightRequested(Int, Int, NGValue, Int, Map)
                   | ngLtCompared(Int, Int, NGValue, NGValue, NGValue, Map)
                   | ngLtSortFailed(Int, Int, NGValue, NGValue, Int, Map)
                   | ngLtPrimitiveReturned(Int, Int, NGValue, Map)
                   | ngLtPrimitiveFailed(Int, Int, Int, Map)
endmodule

===== END BODY 13 =====

===== COMPLETE BODY 14 COMPLETE K SOURCE normal-lt.k =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/source/normal-lt.k
BYTES: 4566 SHA256: c3f7b2d8266e0f0aeeda02149cc149ee1c042a94de52d4e5bdf8c68f4e79abec
requires "nominal-product.k"
requires "normal-lt-syntax.k"

// Uncharged ordinary semantic counterpart only. Scalar Lt mode3/op4 is a
// correspondence label, never an identity with B helper/cost clocks.
module SHERLOCK-NOMINAL-LT
  imports SHERLOCK-NOMINAL-PRODUCT
  imports SHERLOCK-NOMINAL-LT-SYNTAX

  rule ngOccurrence(ngFoundExpr(ngLt(O, _, _))) => O
  rule ngEvaluate(ngFoundExpr(ngLt(O, L, R)), E, P, Rho, Fs, Es)
    => ngState(P, ngEval(L), Rho, ngFrame(ngLtLeft(E, O, R, Rho), Fs),
         ngAppendEvent(Es, ngLtStarted(E, O, L, R, Rho)))
  rule ngStep(ngState(P, ngReturn(V), _, ngFrame(ngLtLeft(E, O, R, Saved), Fs), Es))
    => ngState(P, ngEval(R), Saved, ngFrame(ngLtRight(E, O, V, Saved), Fs),
         ngAppendEvent(Es, ngLtRightRequested(E, O, V, R, Saved)))

  // Nominal values are admitted/canonical by the existing input premise.
  // This checks only the scalar UInt representation, not an admission policy.
  syntax Bool ::= ngLtMalformedUInt(NGValue) [function]
  rule ngLtMalformedUInt(ngUInt(N))
    => N <Int 0 orBool N >=Int 340282366920938463463374607431768211456
  rule ngLtMalformedUInt(ngBool(_)) => false
  rule ngLtMalformedUInt(ngNominal(_, _, _)) => false

  syntax NGState ::= ngCompleteLt(NGValue, NGValue, Int, Int, NGProgram, Map,
                                  NGFrames, NGEvents) [function]
  rule ngStep(ngState(P, ngReturn(R), _, ngFrame(ngLtRight(E, O, L, Saved), Fs), Es))
    => ngCompleteLt(L, R, E, O, P, Saved, Fs, Es)
  // Pop only the Lt frame. Every enclosing caller/field/scope frame survives.
  rule ngCompleteLt(ngUInt(L), ngUInt(R), E, O, P, Saved, Fs, Es)
    => ngState(P, ngLtPrimitiveValue(E, O, ngBool(L <Int R)), Saved, Fs,
         ngAppendEvent(Es, ngLtCompared(E, O, ngUInt(L), ngUInt(R),
                                       ngBool(L <Int R), Saved)))
    requires L >=Int 0 andBool R >=Int 0
      andBool L <Int 340282366920938463463374607431768211456
      andBool R <Int 340282366920938463463374607431768211456
  // Wrong canonical kind is source sort error11, never overflow10.
  rule ngCompleteLt(L, R, E, O, P, Saved, Fs, Es)
    => ngState(P, ngLtPrimitiveError(E, O, 11), Saved, Fs,
         ngAppendEvent(Es, ngLtSortFailed(E, O, L, R, 11, Saved)))
    requires notBool ngLtMalformedUInt(L) andBool notBool ngLtMalformedUInt(R)
      andBool notBool (ngIsUInt(L) andBool ngIsUInt(R))
  // Malformed raw scalar Int is outside the admitted UInt128 profile. Keep
  // the pending LtRight carrier rather than publish error11 or clamp values.
  rule ngCompleteLt(L, R, E, O, P, Saved, Fs, Es)
    => ngOutside(ngState(P, ngReturn(R), Saved,
         ngFrame(ngLtRight(E, O, L, Saved), Fs), Es),
         "lt_operand_outside_UInt128_admitted_domain")
    requires ngLtMalformedUInt(L) orBool ngLtMalformedUInt(R)

  // Separate primitive value/error steps retain complete current environments
  // and outer frames. Existing typed FunctionReturn/ConstructorFields rules
  // subsequently consume Bool success. Error does not unwind caller frames.
  rule ngStep(ngState(P, ngLtPrimitiveValue(E, O, ngBool(B)), Rho, Fs, Es))
    => ngState(P, ngReturn(ngBool(B)), Rho, Fs,
         ngAppendEvent(Es, ngLtPrimitiveReturned(E, O, ngBool(B), Rho)))
  rule ngStep(ngState(P, ngLtPrimitiveValue(E, O, V), Rho, Fs, Es))
    => ngOutside(ngState(P, ngLtPrimitiveValue(E, O, V), Rho, Fs, Es),
                  "lt_primitive_value_carrier_not_Bool")
    requires notBool ngIsBool(V)
  rule ngStep(ngState(P, ngLtPrimitiveError(E, O, 11), Rho, Fs, Es))
    => ngState(P, ngLtError(E, O, 11), Rho, Fs,
         ngAppendEvent(Es, ngLtPrimitiveFailed(E, O, 11, Rho)))
  rule ngStep(ngState(P, ngLtPrimitiveError(E, O, Code), Rho, Fs, Es))
    => ngOutside(ngState(P, ngLtPrimitiveError(E, O, Code), Rho, Fs, Es),
                  "lt_primitive_error_code_outside_profile") requires Code =/=Int 11

  rule ngTerminal(ngLtPrimitiveValue(_, _, _)) => false
  rule ngTerminal(ngLtPrimitiveError(_, _, _)) => false
  rule ngTerminal(ngLtError(_, _, 11)) => true
  rule ngTerminal(ngLtError(_, _, Code)) => false requires Code =/=Int 11
  rule ngStep(ngState(P, ngLtError(E, O, 11), Rho, Fs, Es))
    => ngState(P, ngLtError(E, O, 11), Rho, Fs, Es)
  rule ngAdvance(ngState(P, ngLtError(E, O, 11), Rho, Fs, Es), N)
    => ngState(P, ngLtError(E, O, 11), Rho, Fs, Es) requires N >Int 0
  rule ngStep(ngState(P, ngLtError(E, O, Code), Rho, Fs, Es))
    => ngOutside(ngState(P, ngLtError(E, O, Code), Rho, Fs, Es),
                  "lt_error_boundary_code_outside_profile") requires Code =/=Int 11
endmodule

===== END BODY 14 =====

===== COMPLETE BODY 15 COMPLETE K SOURCE normal-trace-observations.k =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/source/normal-trace-observations.k
BYTES: 1735 SHA256: 6cd7fc81c394a06ed7a963f8be21a36a57dbeead252820203e65de618a795af0
requires "nominal-product.k"

// Test-only complete-state observer. No expected data enters ngStep.
module SHERLOCK-NOMINAL-PRODUCT-OBSERVATIONS
  imports SHERLOCK-NOMINAL-PRODUCT
  syntax NGStates ::= ngNoStates() | ngStateRow(NGState, NGStates)
  syntax NGTape ::= ngTape(NGState, NGStates, NGState)
                 | ngObserve(NGState, Int) [function]
                 | ngObserveLoop(NGState, NGState, NGStates, Int) [function]
                 | ngObserveNext(NGState, NGState, NGStates, Int) [function]
  syntax NGStates ::= ngAppendState(NGStates, NGState) [function]
  rule ngAppendState(ngNoStates(), S) => ngStateRow(S, ngNoStates())
  rule ngAppendState(ngStateRow(S, Ss), T)
    => ngStateRow(S, ngAppendState(Ss, T))
  // Internal history is newest-first; emit the same chronological tape once.
  syntax NGStates ::= ngReverseStates(NGStates, NGStates) [function]
  rule ngReverseStates(ngNoStates(), Acc) => Acc
  rule ngReverseStates(ngStateRow(S, Ss), Acc)
    => ngReverseStates(Ss, ngStateRow(S, Acc))
  rule ngObserve(S, N) => ngObserveLoop(S, S, ngNoStates(), N)
  rule ngObserveLoop(Initial, Current, States, 0)
    => ngTape(Initial, ngReverseStates(States, ngNoStates()), Current)
  rule ngObserveLoop(Initial, ngState(P, C, Rho, Fs, Es), States, N)
    => ngTape(Initial, ngReverseStates(States, ngNoStates()), ngState(P, C, Rho, Fs, Es))
    requires N >Int 0 andBool ngTerminal(C)
  rule ngObserveLoop(Initial, ngState(P, C, Rho, Fs, Es), States, N)
    => ngObserveNext(Initial, ngStep(ngState(P, C, Rho, Fs, Es)), States, N -Int 1)
    requires N >Int 0 andBool notBool ngTerminal(C)
  rule ngObserveNext(Initial, Next, States, N)
    => ngObserveLoop(Initial, Next, ngStateRow(Next, States), N)
endmodule

===== END BODY 15 =====

===== COMPLETE BODY 16 COMPLETE unchanged adapter render_input.py =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter/render_input.py
BYTES: 7417 SHA256: ff05d40bab66ab5a7838c306c992f00a075023ad58a83b452eb9a48394ec7943
"""Serialize a complete declared NGProgram input; never evaluate a K step.

This renderer covers the declared common positive wire, including Let and If.
It does not call the predecessor codec's obsolete encode/Map render functions.
An independently implemented, already used parser/complete decoder checks the
entire serialized input before the files are created.
"""
import argparse
import hashlib
import json
from pathlib import Path

import nominal_trace_codec as parser
from complete_k_wire import CompleteKWire


def same(a, b):
    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return a.keys() == b.keys() and all(same(a[k], b[k]) for k in a)
    if type(a) is list:
        return len(a) == len(b) and all(same(x, y) for x, y in zip(a, b))
    return a == b


def fields(value, keys):
    if type(value) is not dict or set(value) != set(keys):
        raise ValueError("Unexpected complete input fields: " + str(keys))
    return value


def nat(value):
    if type(value) is not int or value < 0:
        raise ValueError("Expected a nonnegative integer, not Bool")
    return str(value)


def call(name, *args):
    return name + "(" + ",".join(args) + ")"


def chain(rows, empty, name, encode):
    tail = call(empty)
    for row in reversed(rows):
        tail = call(name, *encode(row), tail)
    return tail


def tagged(value):
    if type(value) is not dict or len(value) != 1:
        raise ValueError("Expected exactly one declared variant")
    return next(iter(value.items()))


def value(v):
    tag, payload = tagged(v)
    if tag == "UInt":
        return call("ngUInt", nat(payload))
    if tag == "Bool":
        if type(payload) is not bool:
            raise ValueError("Expected Bool")
        return call("ngBool", str(payload).lower())
    if tag == "Nominal":
        fields(payload, ("type_id", "ctor_id", "fields"))
        return call("ngNominal", nat(payload["type_id"]), nat(payload["ctor_id"]), values(payload["fields"]))
    raise ValueError("Unsupported value variant: " + str(tag))


def values(rows):
    return chain(rows, "ngNoValues", "ngValue", lambda row: [value(row)])


def ints(rows, empty, name):
    return chain(rows, empty, name, lambda row: [nat(row)])


def pattern(p):
    tag, payload = tagged(p)
    if tag == "Wildcard":
        fields(payload, ())
        return call("ngWildcard")
    if tag == "Bind":
        return call("ngBind", nat(payload))
    if tag == "Constructor":
        fields(payload, ("type_id", "ctor_id", "fields"))
        children = chain(payload["fields"], "ngNoPatterns", "ngPattern", lambda row: [pattern(row)])
        return call("ngConstructorPattern", nat(payload["type_id"]), nat(payload["ctor_id"]), children)
    raise ValueError("Unsupported pattern variant: " + str(tag))


def arms(rows):
    def row(a):
        fields(a, ("source_arm_id", "pattern", "body"))
        return [nat(a["source_arm_id"]), pattern(a["pattern"]), nat(a["body"])]
    return chain(rows, "ngNoArms", "ngArm", row)


def expression(node):
    fields(node, ("id", "occurrence", "kind"))
    occ = nat(node["occurrence"])
    tag, v = tagged(node["kind"])
    if tag == "Literal":
        return call("ngLiteral", occ, value(v))
    spec = {
        "Variable": ("ngVariable", ("name_id",)),
        "Add": ("ngAdd", ("left", "right")),
        "Lt": ("ngLt", ("left", "right")),
        "Construct": ("ngConstruct", ("type_id", "ctor_id", "fields")),
        "Call": ("ngCall", ("name_id", "arguments")),
        "Match": ("ngMatch", ("scrutinee", "arms")),
        "Let": ("ngLet", ("binder", "bound_expr", "body_expr")),
        "If": ("ngIf", ("condition_expr", "yes_expr", "no_expr")),
    }
    if tag not in spec:
        raise ValueError("Unsupported expression variant: " + str(tag))
    name, keys = spec[tag]
    fields(v, keys)
    args = [occ]
    for key in keys:
        if key in ("fields", "arguments"):
            args.append(ints(v[key], "ngNoExprs", "ngExprId"))
        elif key == "arms":
            args.append(arms(v[key]))
        else:
            args.append(nat(v[key]))
    return call(name, *args)


def program(p):
    fields(p, ("declarations", "expressions", "functions", "entry"))
    def ctor(c):
        fields(c, ("type_id", "ctor_id", "source_order", "field_types"))
        return call("ngCtor", nat(c["type_id"]), nat(c["ctor_id"]), nat(c["source_order"]), ints(c["field_types"], "ngNoTypes", "ngType"))
    def decl(d):
        fields(d, ("type_id", "recursive_group", "ctors"))
        cs = chain(d["ctors"], "ngNoCtors", "ngCtorRow", lambda c: [ctor(c)])
        return [nat(d["type_id"]), nat(d["recursive_group"]), cs]
    def parameter(row):
        fields(row, ("name_id", "type_id"))
        return [nat(row["name_id"]), nat(row["type_id"])]
    def function(f):
        fields(f, ("name_id", "parameters", "return_type_id", "body"))
        ps = chain(f["parameters"], "ngNoParams", "ngParam", parameter)
        return [call("ngFunction", nat(f["name_id"]), ps, nat(f["return_type_id"]), nat(f["body"]))]
    return call("ngProgram", chain(p["declarations"], "ngNoDecls", "ngDecl", decl),
        chain(p["expressions"], "ngNoNodes", "ngNode", lambda row: [nat(row["id"]), expression(row)]),
        chain(p["functions"], "ngNoFunctions", "ngFunctionRow", function), nat(p["entry"]))


def environment(rows):
    names = set()
    out = []
    for row in rows:
        fields(row, ("name_id", "value"))
        key = nat(row["name_id"])
        if key in names:
            raise ValueError("Duplicate extensional environment key")
        names.add(key)
        out.append(key + " |-> " + value(row["value"]))
    # This is the already observed MAP surface form; no extra Map parentheses.
    return " ".join(out) if out else ".Map"


def write(path, raw):
    with Path(path).open("xb") as stream:
        stream.write(raw)
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--input", type=Path, required=True)
    cli.add_argument("--api", type=Path, required=True)
    cli.add_argument("--syntax", type=Path, required=True)
    cli.add_argument("--output-dir", type=Path, required=True)
    args = cli.parse_args()
    source = json.loads(args.input.read_bytes())
    initial = call("ngInitial", program(source["ng_program"]), environment(source["initial_environment"]))
    parser.configure(args.api, args.syntax)
    decoded = parser.parse_printed(initial, sort="NGState")
    if decoded.name != "ngInitial":
        raise ValueError("Input serializer changed ngInitial")
    adapter = CompleteKWire(parser.API, parser.REG)
    if not same(adapter.decode(decoded.args[0]), source["ng_program"]) or not same(adapter.decode(decoded.args[1]), source["initial_environment"]):
        raise ValueError("Complete Program/Map inverse differs; no input emitted")
    budget = nat(source["observation_budget"])
    initial_pin = write(args.output_dir / "initial.ng", (initial + "\n").encode())
    query_pin = write(args.output_dir / "query.term", (call("ngObserve", initial, budget) + "\n").encode())
    print(json.dumps({"status": "PASS_COMPLETE_INPUT_SERIALIZATION_INVERSE", "initial": initial_pin,
        "query": query_pin, "model_steps_evaluated": 0, "expected_documents_opened": 0}))


if __name__ == "__main__":
    main()

===== END BODY 16 =====

===== COMPLETE BODY 17 COMPLETE unchanged adapter nominal_trace_codec.py =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter/nominal_trace_codec.py
BYTES: 14258 SHA256: 4cc8826bc9c06c9d56217387a21fba15bb568cccfdffb02d4765c6c001be191b
"""Complete nominal tape data codec; no evaluator or source transition rules."""
from dataclasses import dataclass
from pathlib import Path
import json
import re
API = {}
REG = {}
def configure(api_path, syntax_path):
    global API, REG
    API = json.loads(Path(api_path).read_text())
    syntax = re.sub(r'//[^\n]*', '', Path(syntax_path).read_text())
    REG = {}
    for sort, body in re.findall(r'syntax\s+(\w+)\s*::=\s*(.*?)(?=\n\s*syntax|\nendmodule)', syntax, re.S):
        for name, args in re.findall(r'(\w+)\(([^()]*)\)', body):
            REG[name] = (sort, tuple(x.strip() for x in args.split(',') if x.strip()))
    REG.update({'ngNoStates': ('NGStates', ()), 'ngStateRow': ('NGStates', ('NGState', 'NGStates')), 'ngTape': ('NGTape', ('NGState', 'NGStates', 'NGState')), 'ngInitial': ('NGState', ('NGProgram', 'Map'))})

@dataclass(frozen=True)
class T:
    sort: str
    name: str
    args: tuple

def C(name, *args):
    sort, sorts = REG[name]
    assert tuple(a.sort for a in args) == sorts, (name, tuple(a.sort for a in args), sorts)
    return T(sort, name, tuple(args))

def atom(sort, value):
    return T(sort, '@' + sort, (value,))

def chain(items, empty, row, before=None):
    tail = C(empty)
    for x in reversed(items):
        args = before(x) if before else [x]
        tail = C(row, *args, tail)
    return tail

GROUPS = {'NGControl': 'control_payload_order', 'NGFrame': 'frame_payload_order', 'NGEvent': 'event_payload_order'}

def arms_index(program):
    return {a['source_arm_id']: a for n in program['expressions'] if 'Match' in n['kind'] for a in n['kind']['Match']['arms']}

def encode(sort, value, ctx):
    if sort in ('Int', 'Bool', 'String'):
        return atom(sort, value)
    if sort == 'Map':
        return T('Map', '@Map', tuple((encode('Int', x['name_id'], ctx), encode('NGValue', x['value'], ctx)) for x in value))
    if sort == 'NGValue':
        tag, v = next(iter(value.items()))
        if tag == 'UInt': return C('ngUInt', encode('Int', v, ctx))
        if tag == 'Bool': return C('ngBool', encode('Bool', v, ctx))
        return C('ngNominal', encode('Int', v['type_id'], ctx), encode('Int', v['ctor_id'], ctx), encode('NGValues', v['fields'], ctx))
    lists = {'NGValues': ('NGValue', 'ngNoValues', 'ngValue'), 'NGTypes': ('Int', 'ngNoTypes', 'ngType'), 'NGExprIds': ('Int', 'ngNoExprs', 'ngExprId'), 'NGPatterns': ('NGPattern', 'ngNoPatterns', 'ngPattern'), 'NGFrames': ('NGFrame', 'ngNoFrames', 'ngFrame'), 'NGEvents': ('NGEvent', 'ngNoEvents', 'ngEvent'), 'NGStates': ('NGState', 'ngNoStates', 'ngStateRow'), 'NGCtors': ('NGCtor', 'ngNoCtors', 'ngCtorRow'), 'NGFunctions': ('NGFunction', 'ngNoFunctions', 'ngFunctionRow')}
    if sort in lists:
        sub, empty, row = lists[sort]
        return chain([encode(sub, x, ctx) for x in value], empty, row)
    if sort == 'NGPath':
        return chain([encode('Int', x, ctx) for x in value], 'ngRoot', 'ngAt')
    if sort == 'NGPattern':
        tag, v = next(iter(value.items()))
        if tag == 'Wildcard': return C('ngWildcard')
        if tag == 'Bind': return C('ngBind', encode('Int', v, ctx))
        return C('ngConstructorPattern', encode('Int', v['type_id'], ctx), encode('Int', v['ctor_id'], ctx), encode('NGPatterns', v['fields'], ctx))
    if sort == 'NGArms':
        rows = [ctx['arms'][v] if isinstance(v, int) else v for v in value]
        return chain(rows, 'ngNoArms', 'ngArm', lambda v: [encode('Int', v['source_arm_id'], ctx), encode('NGPattern', v['pattern'], ctx), encode('Int', v['body'], ctx)])
    if sort == 'NGBindings':
        fields = ['name_id', 'match_expr_id', 'source_arm_id', 'field_path', 'value']
        return chain(value, 'ngNoBindings', 'ngBinding', lambda v: [encode(s, v[k], ctx) for s, k in zip(REG['ngBinding'][1][:-1], fields)])
    if sort in GROUPS:
        if sort == 'NGEvent': name, payload = value['event'], {k: v for k, v in value.items() if k != 'event'}
        else: name, payload = next(iter(value.items()))
        keys = API[GROUPS[sort]][name]
        assert set(payload) == set(keys)
        return C(name, *(encode(s, payload[k], ctx) for s, k in zip(REG[name][1], keys)))
    if sort == 'NGExpr':
        i, occ, kinds = value['id'], value['occurrence'], value['kind']
        tag, v = next(iter(kinds.items()))
        if tag == 'Literal': return C('ngLiteral', encode('Int', occ, ctx), encode('NGValue', v, ctx))
        config = {'Variable': ('ngVariable', ['name_id']), 'Add': ('ngAdd', ['left', 'right']), 'Lt': ('ngLt', ['left', 'right']), 'Construct': ('ngConstruct', ['type_id', 'ctor_id', 'fields']), 'Call': ('ngCall', ['name_id', 'arguments']), 'Match': ('ngMatch', ['scrutinee', 'arms'])}
        name, keys = config[tag]
        return C(name, encode('Int', occ, ctx), *(encode(s, v[k], ctx) for s, k in zip(REG[name][1][1:], keys)))
    if sort == 'NGNodes':
        return chain(value, 'ngNoNodes', 'ngNode', lambda v: [encode('Int', v['id'], ctx), encode('NGExpr', v, ctx)])
    if sort == 'NGParams':
        return chain(value, 'ngNoParams', 'ngParam', lambda v: [encode('Int', v['name_id'], ctx), encode('Int', v['type_id'], ctx)])
    if sort == 'NGFunction':
        return C('ngFunction', encode('Int', value['name_id'], ctx), encode('NGParams', value['parameters'], ctx), encode('Int', value['return_type_id'], ctx), encode('Int', value['body'], ctx))
    if sort == 'NGCtor':
        return C('ngCtor', *(encode(s, value[k], ctx) for s, k in zip(REG['ngCtor'][1], ['type_id', 'ctor_id', 'source_order', 'field_types'])))
    if sort == 'NGDecls':
        return chain(value, 'ngNoDecls', 'ngDecl', lambda v: [encode('Int', v['type_id'], ctx), encode('Int', v['recursive_group'], ctx), encode('NGCtors', v['ctors'], ctx)])
    if sort == 'NGProgram':
        return C('ngProgram', *(encode(s, value[k], ctx) for s, k in zip(REG['ngProgram'][1], ['declarations', 'expressions', 'functions', 'entry'])))
    if sort == 'NGState':
        return C('ngState', encode('NGProgram', value['program'], ctx), encode('NGControl', value['control'], ctx), encode('Map', value['environment'], ctx), encode('NGFrames', value['frames_top_first'], ctx), encode('NGEvents', value['events'], ctx))
    raise ValueError(sort)

def unchain(t):
    out = []
    while t.args:
        out.append(t.args[:-1]); t = t.args[-1]
    return out

def decode(t, ctx):
    s, name, args = t.sort, t.name, t.args
    if name in ('@Int', '@Bool', '@String'): return args[0]
    if name == '@Map': return sorted([{'name_id': decode(k, ctx), 'value': decode(v, ctx)} for k, v in args], key=lambda row: row['name_id'])
    if s == 'NGValue':
        if name == 'ngUInt': return {'UInt': decode(args[0], ctx)}
        if name == 'ngBool': return {'Bool': decode(args[0], ctx)}
        return {'Nominal': dict(zip(['type_id', 'ctor_id', 'fields'], [decode(a, ctx) for a in args]))}
    lists = {'NGValues', 'NGTypes', 'NGExprIds', 'NGPatterns', 'NGFrames', 'NGEvents', 'NGStates', 'NGCtors', 'NGFunctions', 'NGPath'}
    if s in lists: return [decode(row[0], ctx) for row in unchain(t)]
    if s == 'NGPattern':
        if name == 'ngWildcard': return {'Wildcard': {}}
        if name == 'ngBind': return {'Bind': decode(args[0], ctx)}
        return {'Constructor': dict(zip(['type_id', 'ctor_id', 'fields'], [decode(a, ctx) for a in args]))}
    if s == 'NGArms': return [dict(zip(['source_arm_id', 'pattern', 'body'], [decode(a, ctx) for a in row])) for row in unchain(t)]
    if s == 'NGBindings': return [dict(zip(['name_id', 'match_expr_id', 'source_arm_id', 'field_path', 'value'], [decode(a, ctx) for a in row])) for row in unchain(t)]
    if s in GROUPS:
        keys = API[GROUPS[s]][name]; payload = {}
        for k, a in zip(keys, args):
            v = decode(a, ctx)
            if k in ('source_arms', 'remaining_source_arms'):
                assert all(ctx['arms'][v0['source_arm_id']] == v0 for v0 in v)
                v = [v0['source_arm_id'] for v0 in v]
            payload[k] = v
        return {'event': name, **payload} if s == 'NGEvent' else {name: payload}
    if s == 'NGExpr':
        occ = decode(args[0], ctx)
        if name == 'ngLiteral': return {'occurrence': occ, 'kind': {'Literal': decode(args[1], ctx)}}
        cfg = {'ngVariable': ('Variable', ['name_id']), 'ngAdd': ('Add', ['left', 'right']), 'ngLt': ('Lt', ['left', 'right']), 'ngConstruct': ('Construct', ['type_id', 'ctor_id', 'fields']), 'ngCall': ('Call', ['name_id', 'arguments']), 'ngMatch': ('Match', ['scrutinee', 'arms'])}
        tag, keys = cfg[name]
        return {'occurrence': occ, 'kind': {tag: dict(zip(keys, [decode(a, ctx) for a in args[1:]]))}}
    if s == 'NGNodes': return [{'id': decode(row[0], ctx), **decode(row[1], ctx)} for row in unchain(t)]
    if s == 'NGParams': return [dict(zip(['name_id', 'type_id'], [decode(a, ctx) for a in row])) for row in unchain(t)]
    if s == 'NGFunction': return dict(zip(['name_id', 'parameters', 'return_type_id', 'body'], [decode(a, ctx) for a in args]))
    if s == 'NGCtor': return dict(zip(['type_id', 'ctor_id', 'source_order', 'field_types'], [decode(a, ctx) for a in args]))
    if s == 'NGDecls': return [dict(zip(['type_id', 'recursive_group', 'ctors'], [decode(a, ctx) for a in row])) for row in unchain(t)]
    if s == 'NGProgram': return dict(zip(['declarations', 'expressions', 'functions', 'entry'], [decode(a, ctx) for a in args]))
    if s == 'NGState': return dict(zip(['program', 'control', 'environment', 'frames_top_first', 'events'], [decode(a, ctx) for a in args]))
    if s == 'NGTape': return {'initial': decode(args[0], ctx), 'after_each_event': decode(args[1], ctx), 'final': decode(args[2], ctx)}
    raise ValueError(s)

def render(t):
    if t.name == '@Int': return str(t.args[0])
    if t.name == '@Bool': return str(t.args[0]).lower()
    if t.name == '@String': return json.dumps(t.args[0])
    if t.name == '@Map':
        return '.Map' if not t.args else '(.Map ' + ' '.join('(' + render(k) + ' |-> ' + render(v) + ')' for k, v in t.args) + ')'
    if t.name == '@Ref': return t.args[0] + '()'
    return t.name + '(' + ','.join(render(a) for a in t.args) + ')'

# Source-format data parsing only. No token, state, frame, or event is skipped.
# Parentheses/whitespace and Map's declared AC/unit syntax are presentation.
LEX = re.compile(r'\s*(\.Map|\|->|-?\d+|true\b|false\b|"(?:[^"\\]|\\.)*"|[A-Za-z][A-Za-z0-9]*|[(),])')

class PrintedTermParser:
    def __init__(self, text):
        self.tokens = []
        self.at = 0
        pos = 0
        while pos < len(text):
            found = LEX.match(text, pos)
            if found is None:
                if text[pos:].strip() == '': break
                raise ValueError('Unparsed printed byte at ' + str(pos))
            self.tokens.append(found.group(1))
            pos = found.end()

    def peek(self):
        return self.tokens[self.at] if self.at < len(self.tokens) else None

    def take(self, expected=None):
        token = self.peek()
        if token is None: raise ValueError('Unexpected end of complete tape')
        self.at += 1
        if expected is not None and token != expected:
            raise ValueError('Expected ' + expected + ', got ' + token)
        return token

    def term(self, sort):
        if sort == 'Map': return self.map_term()
        if self.peek() == '(':
            self.take('(')
            value = self.term(sort)
            self.take(')')
            return value
        token = self.take()
        if sort == 'Int':
            if re.fullmatch(r'-?\d+', token) is None: raise ValueError('Expected Int')
            return atom('Int', int(token))
        if sort == 'Bool':
            if token not in ('true', 'false'): raise ValueError('Expected Bool')
            return atom('Bool', token == 'true')
        if sort == 'String': return atom('String', json.loads(token))
        if token not in REG or REG[token][0] != sort:
            raise ValueError('Unknown constructor/sort ' + str((token, sort)))
        self.take('(')
        values = []
        for i, child_sort in enumerate(REG[token][1]):
            if i: self.take(',')
            values.append(self.term(child_sort))
        self.take(')')
        return C(token, *values)

    def map_term(self):
        rows = []
        saw_item = False
        while True:
            if self.peek() == '.Map':
                self.take('.Map'); saw_item = True
                continue
            checkpoint = self.at
            # Source environments have Int name IDs and NGValue bindings.
            # Optional key parentheses are surface formatting only.
            try:
                key = self.term('Int')
            except ValueError:
                self.at = checkpoint
                key = None
            if key is not None and self.peek() == '|->':
                self.take('|->')
                rows.append((key, self.term('NGValue')))
                saw_item = True
                continue
            self.at = checkpoint
            if self.peek() == '(':
                self.take('(')
                group = self.map_term()
                self.take(')')
                rows.extend(group.args)
                saw_item = True
                continue
            break
        if not saw_item: raise ValueError('Expected complete finite environment Map')
        # Retain all bindings, including any repeated rows; no dict overwrite.
        return T('Map', '@Map', tuple(sorted(rows, key=lambda row: row[0].args[0])))

    def complete(self, sort='NGTape'):
        value = self.term(sort)
        if self.at != len(self.tokens): raise ValueError('Trailing printed tape tokens')
        return value

def parse_printed(text, sort='NGTape'):
    return PrintedTermParser(text).complete(sort)

def expanded_expected(fixture):
    def state(s):
        return {'program': fixture['shared_program'], 'control': s['control'],
                'environment': s['environment'], 'frames_top_first': s['frames_top_first'],
                'events': fixture['expected_events'][:s['events_prefix_length']]}
    return {'initial': state(fixture['initial_state']),
            'after_each_event': [state(s) for s in fixture['after_each_event']],
            'final': state(fixture['expected_final_state'])}


===== END BODY 17 =====

===== COMPLETE BODY 18 COMPLETE unchanged adapter complete_k_wire.py =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/adapter/complete_k_wire.py
BYTES: 13453 SHA256: 983e35bebc4f880922daa8c89a3e093391e736ba90e32fa67cb1e27646e5a524
"""Complete structural observation export; no evaluator, parser or file access.

The selected consumer supplies a complete typed term from the existing parser,
the approved public payload API, and that parser's constructor registry.  This
module does not import the parser or consume independent expected data.
"""

from typing import Any, Iterable, Mapping, Protocol, Sequence


class Term(Protocol):
    sort: str
    name: str
    args: tuple


class ObservationFormatError(ValueError):
    """The supplied object is not the complete declared observation format."""


class CompleteKWire:
    SCHEMA = "independent-nominal-full-state/1"
    GROUPS = {
        "NGControl": "control_payload_order",
        "NGFrame": "frame_payload_order",
        "NGEvent": "event_payload_order",
    }
    SEQUENCES = {
        "NGValues": ("ngNoValues", "ngValue"),
        "NGTypes": ("ngNoTypes", "ngType"),
        "NGExprIds": ("ngNoExprs", "ngExprId"),
        "NGPatterns": ("ngNoPatterns", "ngPattern"),
        "NGFrames": ("ngNoFrames", "ngFrame"),
        "NGEvents": ("ngNoEvents", "ngEvent"),
        "NGStates": ("ngNoStates", "ngStateRow"),
        "NGCtors": ("ngNoCtors", "ngCtorRow"),
        "NGFunctions": ("ngNoFunctions", "ngFunctionRow"),
        "NGPath": ("ngRoot", "ngAt"),
    }
    EXPRESSIONS = {
        "ngLiteral": ("Literal", ("value",)),
        "ngVariable": ("Variable", ("name_id",)),
        "ngAdd": ("Add", ("left", "right")),
        "ngLt": ("Lt", ("left", "right")),
        "ngConstruct": ("Construct", ("type_id", "ctor_id", "fields")),
        "ngCall": ("Call", ("name_id", "arguments")),
        "ngMatch": ("Match", ("scrutinee", "arms")),
        "ngLet": ("Let", ("binder", "bound_expr", "body_expr")),
        "ngIf": ("If", ("condition_expr", "yes_expr", "no_expr")),
    }

    def __init__(
        self,
        public_api: Mapping[str, Any],
        registry: Mapping[str, tuple[str, Sequence[str]]],
    ) -> None:
        # Copy declarations once: decoding does not mutate shared codec globals.
        self.registry = {
            name: (sort, tuple(children))
            for name, (sort, children) in registry.items()
        }
        self.fields = {
            sort: {
                name: tuple(fields)
                for name, fields in public_api[group].items()
            }
            for sort, group in self.GROUPS.items()
        }
        for sort, constructors in self.fields.items():
            for name, fields in constructors.items():
                declaration = self.registry.get(name)
                if declaration is None or declaration[0] != sort:
                    raise ObservationFormatError("Missing declared variant: " + name)
                if len(fields) != len(declaration[1]):
                    raise ObservationFormatError("Payload arity differs: " + name)
                if len(set(fields)) != len(fields):
                    raise ObservationFormatError("Repeated payload field: " + name)

    def _args(
        self, term: Term, sort: str, name: str | None = None
    ) -> tuple:
        if term.sort != sort or (name is not None and term.name != name):
            raise ObservationFormatError(
                "Expected " + str((sort, name))
                + ", received " + str((term.sort, term.name))
            )
        declaration = self.registry.get(term.name)
        if declaration is None or declaration[0] != sort:
            raise ObservationFormatError("Unknown constructor: " + term.name)
        children = declaration[1]
        if len(term.args) != len(children):
            raise ObservationFormatError("Constructor arity differs: " + term.name)
        for argument, child_sort in zip(term.args, children):
            if argument.sort != child_sort:
                raise ObservationFormatError("Child sort differs: " + term.name)
        return term.args

    def _record(self, keys: Sequence[str], values: Sequence[Any]) -> dict:
        if len(keys) != len(values):
            raise ObservationFormatError("Record field count differs")
        return dict(zip(keys, values))

    def _rows(self, term: Term, empty: str, row: str) -> list[tuple]:
        sort = term.sort
        rows = []
        current = term
        while True:
            args = self._args(current, sort)
            if current.name == empty:
                if args:
                    raise ObservationFormatError("Nonempty list terminator")
                return rows
            if current.name != row or not args:
                raise ObservationFormatError("Unexpected list constructor")
            rows.append(args[:-1])
            current = args[-1]

    def _decode_rows(
        self, term: Term, empty: str, row: str, fields: Sequence[str]
    ) -> list[dict]:
        return [
            self._record(fields, [self.decode(child) for child in payload])
            for payload in self._rows(term, empty, row)
        ]

    def decode(self, term: Term) -> Any:
        """Decode all supplied fields; function expressions remain unacceptable."""
        sort, name, args = term.sort, term.name, term.args
        scalar_types = {"Int": int, "Bool": bool, "String": str}
        if sort in scalar_types:
            if (
                name != "@" + sort
                or len(args) != 1
                or type(args[0]) is not scalar_types[sort]
            ):
                raise ObservationFormatError("Unexpected scalar representation")
            return args[0]
        if sort == "Map":
            if name != "@Map":
                raise ObservationFormatError("Expected complete parsed Map")
            rows = []
            for pair in args:
                if len(pair) != 2 or pair[0].sort != "Int" or pair[1].sort != "NGValue":
                    raise ObservationFormatError("Map binding shape differs")
                rows.append({
                    "name_id": self.decode(pair[0]),
                    "value": self.decode(pair[1]),
                })
            # Preserve every row.  In particular there is no dict overwrite.
            return sorted(rows, key=lambda binding: binding["name_id"])
        if sort in self.SEQUENCES:
            empty, row = self.SEQUENCES[sort]
            result = []
            for payload in self._rows(term, empty, row):
                if len(payload) != 1:
                    raise ObservationFormatError("Sequence element arity differs")
                result.append(self.decode(payload[0]))
            return result
        if sort in self.GROUPS:
            actual = self._args(term, sort)
            keys = self.fields[sort].get(name)
            if keys is None:
                raise ObservationFormatError("Variant absent from public API: " + name)
            # Exact arity is checked before pairing; no payload tail disappears.
            payload = self._record(keys, [self.decode(child) for child in actual])
            return {name: payload}
        if sort == "NGValue":
            actual = self._args(term, sort)
            values = [self.decode(child) for child in actual]
            if name == "ngUInt":
                return {"UInt": self._single(values)}
            if name == "ngBool":
                return {"Bool": self._single(values)}
            if name == "ngNominal":
                return {"Nominal": self._record(("type_id", "ctor_id", "fields"), values)}
        elif sort == "NGPattern":
            values = [self.decode(child) for child in self._args(term, sort)]
            if name == "ngWildcard" and not values:
                return {"Wildcard": {}}
            if name == "ngBind":
                return {"Bind": self._single(values)}
            if name == "ngConstructorPattern":
                return {"Constructor": self._record(("type_id", "ctor_id", "fields"), values)}
        elif sort == "NGExpr":
            actual = self._args(term, sort)
            declaration = self.EXPRESSIONS.get(name)
            if declaration is None or not actual:
                raise ObservationFormatError("Expression form is not declared")
            tag, fields = declaration
            occurrence = self.decode(actual[0])
            values = [self.decode(child) for child in actual[1:]]
            payload = self._record(fields, values)
            return {
                "occurrence": occurrence,
                "kind": {tag: payload["value"] if tag == "Literal" else payload},
            }
        elif sort == "NGNodes":
            nodes = []
            for payload in self._rows(term, "ngNoNodes", "ngNode"):
                if len(payload) != 2:
                    raise ObservationFormatError("Expression row arity differs")
                nodes.append({"id": self.decode(payload[0]), **self.decode(payload[1])})
            return nodes
        elif sort == "NGDecls":
            return self._decode_rows(
                term, "ngNoDecls", "ngDecl", ("type_id", "recursive_group", "ctors")
            )
        elif sort == "NGParams":
            return self._decode_rows(
                term, "ngNoParams", "ngParam", ("name_id", "type_id")
            )
        elif sort == "NGArms":
            return self._decode_rows(
                term, "ngNoArms", "ngArm", ("source_arm_id", "pattern", "body")
            )
        elif sort == "NGBindings":
            return self._decode_rows(
                term, "ngNoBindings", "ngBinding",
                ("name_id", "match_expr_id", "source_arm_id", "field_path", "value"),
            )
        else:
            records = {
                "NGCtor": ("ngCtor", ("type_id", "ctor_id", "source_order", "field_types")),
                "NGFunction": ("ngFunction", ("name_id", "parameters", "return_type_id", "body")),
                "NGProgram": ("ngProgram", ("declarations", "expressions", "functions", "entry")),
                "NGState": ("ngState", ("program", "control", "environment", "frames_top_first", "events")),
                "NGTape": ("ngTape", ("initial", "after_each_event", "final")),
            }
            if sort in records:
                constructor, fields = records[sort]
                values = [self.decode(child) for child in self._args(term, sort, constructor)]
                return self._record(fields, values)
        raise ObservationFormatError("Undecoded declared datum: " + str((sort, name)))

    @staticmethod
    def _single(values: Sequence[Any]) -> Any:
        if len(values) != 1:
            raise ObservationFormatError("Expected exactly one payload")
        return values[0]

    def complete_states(self, tape: Term) -> list[dict]:
        """Decode and validate every actual snapshot without expected metadata."""
        decoded = self.decode(tape)
        if tape.sort != "NGTape" or tape.name != "ngTape":
            raise ObservationFormatError("Expected a fully evaluated ngTape")
        states = [decoded["initial"], *decoded["after_each_event"]]
        if decoded["final"] != states[-1]:
            raise ObservationFormatError("Final differs from last returned state")
        program = states[0]["program"]
        for current in states:
            if current["program"] != program:
                raise ObservationFormatError("Observed immutable Program changed")
        for previous, current in zip(states, states[1:]):
            prior_tag = next(iter(previous["control"]))
            if (prior_tag in ("ngHalted", "ngOutsideModel")
                    or (prior_tag == "ngLtError" and previous["control"][prior_tag]["code"] == 11)):
                raise ObservationFormatError("An observation followed a terminal state")
            prior_events, events = previous["events"], current["events"]
            if len(events) != len(prior_events) + 1 or events[:-1] != prior_events:
                raise ObservationFormatError("Cumulative event continuity differs")
        return states

    def bind_shared_wire(
        self,
        states: list[dict],
        *,
        case_id: str,
        profile: str,
        terminal_step_contract: str,
        observer_cuts: Iterable[int],
    ) -> dict:
        """Bind public metadata to already decoded complete actual states."""
        if not states:
            raise ObservationFormatError("Complete observations include an initial state")
        cuts = list(observer_cuts)
        if any(type(cut) is not int or cut < 0 or cut >= len(states) for cut in cuts):
            raise ObservationFormatError("Cut ordinal is outside the observed prefix")
        if any(type(text) is not str for text in (case_id, profile, terminal_step_contract)):
            raise ObservationFormatError("Public wire metadata must be strings")
        return {
            "schema": self.SCHEMA,
            "profile": profile,
            "caseId": case_id,
            "states": states,
            "terminalStepContract": terminal_step_contract,
            "observerCuts": cuts,
        }

    def to_shared_wire(
        self,
        tape: Term,
        *,
        case_id: str,
        profile: str,
        terminal_step_contract: str,
        observer_cuts: Iterable[int],
    ) -> dict:
        """Export complete observations with explicitly supplied public metadata."""
        return self.bind_shared_wire(
            self.complete_states(tape),
            case_id=case_id,
            profile=profile,
            terminal_step_contract=terminal_step_contract,
            observer_cuts=observer_cuts,
        )

===== END BODY 18 =====

===== COMPLETE BODY 19 COMPLETE existing balanced raw continuation helper =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/actual-c6-schedule-first-arm-continuation-20261019/source/kore_continuation.py
BYTES: 5112 SHA256: 3fc617c748f93d2cc99c9d97453b4d64ee11b1b0a4bbe9fffe8127d40bef6e5c
"""Carry an actual ground NGState between K queries without interpreting it.

This module launches nothing and reads no expected data. All state bytes come
from the final argument of a completed actual ngTape, never from its JSON wire.
"""
import hashlib
import json

OBSERVE = b"LblngObserve'LParUndsCommUndsRParUnds'SHERLOCK-NOMINAL-PRODUCT-OBSERVATIONS'Unds'NGTape'Unds'NGState'Unds'Int{}"
TAPE = b"LblngTape'LParUndsCommUndsCommUndsRParUnds'SHERLOCK-NOMINAL-PRODUCT-OBSERVATIONS'Unds'NGTape'Unds'NGState'Unds'NGStates'Unds'NGState{}"
STATE = b"LblngState'LParUndsCommUndsCommUndsCommUndsCommUndsRParUnds'SHERLOCK-NOMINAL-PRODUCT-SYNTAX'Unds'NGState'Unds'NGProgram'Unds'NGControl'Unds'Map'Unds'NGFrames'Unds'NGEvents{}"
INT = b"\\dv{SortInt{}}"


def _trim(data, left, right):
    while left < right and data[left] in b" \t\r\n":
        left += 1
    while right > left and data[right - 1] in b" \t\r\n":
        right -= 1
    return left, right


def application(data):
    """Return the exact head and argument byte spans of one Kore application.

    Parentheses/commas within strings and sort parameters are not delimiters.
    The ground term's children stay opaque; K remains its typed verifier.
    """
    if type(data) is not bytes:
        raise TypeError("Kore input must be bytes")
    left, right = _trim(data, 0, len(data))
    brace = 0
    opening = None
    for pos in range(left, right):
        char = data[pos]
        if char == 123:
            brace += 1
        elif char == 125:
            brace -= 1
            if brace < 0:
                raise ValueError("Unbalanced sort parameters")
        elif char == 40 and brace == 0:
            opening = pos
            break
    if opening is None or opening == left:
        raise ValueError("Expected one Kore application")
    head = data[left:opening].strip()
    depth, brace, quoted, escaped = 1, 0, False, False
    start, spans = opening + 1, []
    for pos in range(start, right):
        char = data[pos]
        if quoted:
            if escaped:
                escaped = False
            elif char == 92:
                escaped = True
            elif char == 34:
                quoted = False
            continue
        if char == 34:
            quoted = True
        elif char == 123:
            brace += 1
        elif char == 125:
            brace -= 1
            if brace < 0:
                raise ValueError("Unbalanced sort parameters")
        elif char == 40:
            depth += 1
        elif char == 41:
            depth -= 1
            if depth == 0:
                if brace or data[pos + 1:right].strip():
                    raise ValueError("Trailing term or unbalanced sorts")
                span = _trim(data, start, pos)
                if span[0] != span[1]:
                    spans.append(span)
                elif spans:
                    raise ValueError("Empty final argument")
                return head, spans
        elif char == 44 and depth == 1 and brace == 0:
            span = _trim(data, start, pos)
            if span[0] == span[1]:
                raise ValueError("Empty argument")
            spans.append(span)
            start = pos + 1
    raise ValueError("Unterminated application or string")


def arguments(data, head, arity):
    actual, spans = application(data)
    if actual != head or len(spans) != arity:
        raise ValueError("Unexpected Kore carrier or arity")
    return [data[left:right] for left, right in spans], spans


def _bound(value):
    if type(value) is not int or value < 0:
        raise ValueError("Observation bound must be a nonnegative integer")
    return INT + b'("' + str(value).encode("ascii") + b'")'


def seed_query(passing_kast, bound):
    """Replace only the outer observer bound of already verified query bytes."""
    parts, spans = arguments(passing_kast, OBSERVE, 2)
    old, _ = arguments(parts[1], INT, 1)
    if type(json.loads(old[0])) is not str:
        raise ValueError("Expected an integer domain value string")
    left, right = spans[1]
    result = passing_kast[:left] + _bound(bound) + passing_kast[right:]
    assert arguments(result, OBSERVE, 2)[0][0] == parts[0]
    return result


def resume_query(actual_tape_kore, bound):
    """Use the complete actual final state verbatim as the next initial state."""
    parts, spans = arguments(actual_tape_kore, TAPE, 3)
    final = parts[2]
    arguments(final, STATE, 5)
    result = OBSERVE + b"(" + final + b"," + _bound(bound) + b")"
    assert arguments(result, OBSERVE, 2)[0][0] == final
    return result, {
        "source": "third argument of actual raw ngTape",
        "actual_tape_sha256": hashlib.sha256(actual_tape_kore).hexdigest(),
        "actual_final_byte_start": spans[2][0],
        "actual_final_byte_end_exclusive": spans[2][1],
        "actual_final_bytes": len(final),
        "actual_final_sha256": hashlib.sha256(final).hexdigest(),
        "next_query_sha256": hashlib.sha256(result).hexdigest(),
        "all_five_NGState_payloads_preserved_verbatim": True,
        "state_generated_from_JSON_or_expected": False,
    }

===== END BODY 19 =====

===== COMPLETE BODY 20 COMPLETE boundary-only link consumer =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/source/link_two_k_windows.py
BYTES: 6284 SHA256: 8b7ec9fc66971d7dfc0689f061c933369e0b043026877e0f6283c5538001fd28
"""Compare two complete, already decoded K windows; never evaluate a step.

This ordinary data consumer establishes boundary equality and history shape.
It does not verify the K relation, a production interpreter step, or a proof.
"""
import argparse
import hashlib
import json
from pathlib import Path


ROOT = {"schema", "profile", "caseId", "states", "terminalStepContract", "observerCuts"}
STATE = {"program", "control", "environment", "frames_top_first", "events"}


def same(left, right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return left.keys() == right.keys() and all(same(left[k], right[k]) for k in left)
    if type(left) is list:
        return len(left) == len(right) and all(same(a, b) for a, b in zip(left, right))
    return left == right


def json_domain(value):
    """Keep JSON integer/Boolean distinctions; reject non-finite/float carriers."""
    if type(value) in (str, int, bool) or value is None:
        return
    if type(value) is list:
        for item in value:
            json_domain(item)
        return
    if type(value) is dict and all(type(k) is str for k in value):
        for item in value.values():
            json_domain(item)
        return
    raise ValueError("Outside the declared integral JSON wire domain")


def terminal(control):
    if type(control) is not dict or len(control) != 1:
        raise ValueError("Expected one declared control constructor")
    tag, payload = next(iter(control.items()))
    return tag in {"ngHalted", "ngOutsideModel"} or (
        tag == "ngLtError" and type(payload) is dict
        and type(payload.get("code")) is int and payload["code"] == 11
    )


def checked_window(wire, source):
    json_domain(wire)
    if type(wire) is not dict or set(wire) != ROOT:
        raise ValueError("Complete six-field wire required")
    for key, wanted in (("schema", "independent-nominal-full-state/1"),
                        ("profile", source["profile"]),
                        ("caseId", source["case_id"]),
                        ("terminalStepContract", source["terminalStepContract"])):
        if type(wire[key]) is not str or wire[key] != wanted:
            raise ValueError("Unmatched frozen wire metadata: " + key)
    states = wire["states"]
    if type(states) is not list or len(states) != 2 or not same(wire["observerCuts"], [0, 1]):
        raise ValueError("Exactly one advancing step and actual local ordinals required")
    for state in states:
        if type(state) is not dict or set(state) != STATE:
            raise ValueError("Every complete five-field state required")
        if not same(state["program"], source["ng_program"]):
            raise ValueError("Entire immutable Program differs from input")
        if any(type(state[k]) is not list for k in ("environment", "frames_top_first", "events")):
            raise ValueError("Map/frame/event arrays required without projection")
    before, after = states
    if terminal(before["control"]):
        raise ValueError("No advancing query may start at a terminal boundary")
    if len(after["events"]) != len(before["events"]) + 1 or not same(
            before["events"], after["events"][:-1]):
        raise ValueError("Full cumulative event history must extend by exactly one")
    return states


def link(first, second, source):
    """Retain original state objects, removing only one equal boundary copy."""
    json_domain(source)
    if type(source) is not dict or type(source.get("observation_budget")) is not int or source["observation_budget"] != 2:
        raise ValueError("This finite task is exactly two uncharged advancing steps")
    left, right = checked_window(first, source), checked_window(second, source)
    initial = {"program": source["ng_program"],
               "control": {"ngEval": {"expr_id": source["ng_program"]["entry"]}},
               "environment": source["initial_environment"], "frames_top_first": [], "events": []}
    if not same(left[0], initial):
        raise ValueError("First complete boundary differs from the declared initial state")
    if not same(left[-1], right[0]):
        raise ValueError("Whole first output differs from whole second input")
    # No expected data, field rebuilding, state filtering or evaluation here.
    return {**{k: first[k] for k in ("schema", "profile", "caseId", "terminalStepContract")},
            "states": [*left, right[-1]], "observerCuts": [0, 1, 2]}


def read(path):
    raw = Path(path).read_bytes()
    return json.loads(raw), {"path": str(path), "bytes": len(raw),
                             "sha256": hashlib.sha256(raw).hexdigest()}


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--first", type=Path, required=True)
    cli.add_argument("--second", type=Path, required=True)
    cli.add_argument("--input", type=Path, required=True)
    cli.add_argument("--output-dir", type=Path, required=True)
    args = cli.parse_args()
    first, first_pin = read(args.first)
    second, second_pin = read(args.second)
    source, input_pin = read(args.input)
    joined = link(first, second, source)
    raw = (json.dumps(joined, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode()
    output = args.output_dir / "linked.complete-wire.json"
    with output.open("xb") as stream:
        stream.write(raw)
    receipt = {"status": "PASS_COMPLETE_K_BOUNDARY_LINK_ONLY",
               "inputs": [first_pin, second_pin, input_pin],
               "joined_actual_wire": {"path": str(output), "bytes": len(raw),
                                      "sha256": hashlib.sha256(raw).hexdigest()},
               "whole_boundary_typed_equal": True, "only_equal_middle_duplicate_removed": True,
               "complete_state_positions": 3, "observerCuts_derived_from_actual": True,
               "K_steps_evaluated_by_consumer": 0, "expected_documents_opened": 0,
               "subject_transition_validity_verified_by_consumer": False,
               "production_step_or_recursive_proof_validity_claim": False}
    with (args.output_dir / "link-readback.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()

===== END BODY 20 =====

===== COMPLETE BODY 21 COMPLETE selected existing F03.launch callable closure =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-product-model-v2-review-operation-20261018/context/EXISTING-LAUNCH-CALLABLE-CLOSURE.py.txt
BYTES: 4228 SHA256: 996aadee88cf0ac4688925789676dcc9e407cbd3d7c15b912f25204b10861242
import argparse

import datetime

import hashlib

import json

import os

import re

import resource

import secrets

import signal

import stat

import subprocess

import sys

import time

CHILD_SECONDS = 30

SWEEP_SECONDS = 3

TOKEN_NAME = 'SHERLOCK_K_ATTEMPT_TOKEN'

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def open_exclusive(path, mode=0o600):
    return os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)

def processes(pgid, token):
    marker = (TOKEN_NAME + '=' + token).encode()
    found = []
    for name in os.listdir('/proc'):
        if not name.isdigit() or int(name) == os.getpid():
            continue
        pid = int(name)
        try:
            with open(f'/proc/{pid}/stat', 'rb') as handle:
                fields = handle.read().rsplit(b')', 1)[1].split()
            state, group = fields[0].decode(), int(fields[2])
        except (OSError, IndexError, ValueError):
            continue
        tagged = False
        try:
            with open(f'/proc/{pid}/environ', 'rb') as handle:
                tagged = marker in handle.read().split(b'\0')
        except OSError:
            pass
        if group == pgid or tagged:
            try:
                with open(f'/proc/{pid}/cmdline', 'rb') as handle:
                    cmdline = [part.decode('utf-8', 'replace') for part in handle.read().split(b'\0') if part]
            except OSError:
                cmdline = []
            found.append(dict(pid=pid, pgid=group, state=state, tagged=tagged,
                              in_group=group == pgid, cmdline=cmdline))
    return found

def kill_group(pgid):
    try:
        os.killpg(pgid, signal.SIGKILL)
    except ProcessLookupError:
        pass

def sweep(pgid, token):
    killed = []
    deadline = time.monotonic() + SWEEP_SECONDS
    while True:
        live = [row for row in processes(pgid, token) if row['state'] != 'Z']
        if not live:
            return killed, []
        killed.extend(live)
        for row in live:
            try:
                os.kill(row['pid'], signal.SIGKILL)
            except ProcessLookupError:
                pass
        if time.monotonic() >= deadline:
            return killed, live
        time.sleep(0.1)

def launch(record, command, env, cwd, token, fsize):
    def limit_child():
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        resource.setrlimit(resource.RLIMIT_FSIZE, (fsize, fsize))
        os.umask(0o077)

    out_fd, err_fd = open_exclusive(cwd + '/stdout'), open_exclusive(cwd + '/stderr')
    proc = None
    try:
        record['started_utc'] = utc()
        started = time.monotonic()
        try:
            proc = subprocess.Popen(command, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                                    stdout=out_fd, stderr=err_fd, close_fds=True,
                                    start_new_session=True, preexec_fn=limit_child)
        except (OSError, subprocess.SubprocessError) as error:
            record.update(outcome='launch-error', launch_error=f'{type(error).__name__}: {error}')
            return
        record['pid'] = proc.pid
        timed_out = False
        try:
            proc.wait(timeout=max(0.0, started + CHILD_SECONDS - time.monotonic()))
        except subprocess.TimeoutExpired:
            timed_out = True
            kill_group(proc.pid)
            proc.wait()
        code = proc.returncode
        record.update(elapsed_seconds=round(time.monotonic() - started, 3), ended_utc=utc(),
                      returncode=code, timed_out=timed_out,
                      outcome='timeout-killed' if timed_out else ('exited' if code >= 0 else 'signaled'))
    finally:
        if proc is not None:
            if proc.returncode is None:
                kill_group(proc.pid)
                proc.wait()
            record['group_members_after_exit'] = processes(proc.pid, token)
            kill_group(proc.pid)
            killed, remaining = sweep(proc.pid, token)
            record.update(swept=killed, remaining=remaining,
                          containment_breach=bool(remaining) or any(not row['in_group'] for row in killed))
        os.close(out_fd)
        os.close(err_fd)

===== END BODY 21 =====

===== COMPLETE BODY 22 COMPLETE F03 import-time AST/global membership projection; old main uncalled =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-product-model-v2-review-operation-20261018/context/IMPORT-TIME-AST-REVIEW-PROJECTION.json
BYTES: 55525 SHA256: 9f9e9188139ea024008f204dd9f45d8c4eb119ba2837127fce83ea67b860d4b1
{
  "method": "complete top-level statement membership; required globals and every call-bearing assignment inline; other literal old-wrapper metadata factored by RHS digest. All function bodies except selected complete closure not re-reviewed, never called.",
  "statements": [
    {
      "kind": "Expr",
      "line": 2,
      "endLine": 37,
      "literal_source": "\"\"\"Sherlock K-A attempt-engine-F03-01: one-case F03 raw K engine capture. No recompile.\n\nDerived from the consumed attempt-engine-N01-01 driver (53993B, SHA256\naf9f49b07af4b8d16607fd7cbe01df79ff30302a782084ab502a17dda10e56d2) under\nunchanged per-child controls (30 s wall, 3 s sweep, RLIMIT_CORE 0,\nRLIMIT_FSIZE 512 MiB, umask 077, minimal environment, no host PATH).\nConsumed attempt-engine-N01-01 and its ledger remain untouched.\n\n  python3 -I -B k_engine_attempt_f03_01.py --preflight-only\n      Read-only gates and inventories. No directory, claim, ledger record or\n      child. Prints driver_sha256 and identity_sha256 for review.\n  python3 -I -B k_engine_attempt_f03_01.py --execute \\\\\n          --approved-driver-sha256 HEX --approved-identity-sha256 HEX\n      Exactly one terminal attempt-engine-F03-01 in the R251 actual/k root.\n      Never retried, never reset.\n\nFixed stages (195 child processes + 1 driver-only local initializer = 196 stages),\nstrictly in order:\n\n  kast               pinned JRE, org.kframework.main.Main -kast, frozen F03 input\n                     (F03-fuel093-stack064.ui, 359B, fuel 93, stack limit 64)\n  initializer        driver only: the parsed UIRun is bound as $PGM under the\n                     compiled LblinitGeneratedTopCell; no cell or rule is written\n  exec-000           pinned .kore-exec-wrapped depth-0 pre-startup normalization\n  exec-001           pinned .kore-exec-wrapped depth-1 startup transition\n  exec-002..exec-094 pinned .kore-exec-wrapped depth-1 steps (93 charged transitions)\n  exec-095           pinned .kore-exec-wrapped depth-1 step (free publication)\n  exec-096           pinned .kore-exec-wrapped depth-1 separate terminal probe\n  print-000..096     pinned kprint on each of the 97 states, observation only\n\nA stage is consumed once its ledger claim is appended. The first problem\n(launch error, nonzero exit, signal, timeout, containment breach, missing\nproduct, unexpected stage file, protected-tree change or captured-artifact\nchange) stops the attempt: no retry, no alternate method. Outputs are kept\nraw and hashed; nothing is decoded, matched, labelled or certified.\n\"\"\""
    },
    {
      "kind": "Import",
      "line": 38,
      "endLine": 38,
      "literal_source": "import argparse"
    },
    {
      "kind": "Import",
      "line": 39,
      "endLine": 39,
      "literal_source": "import datetime"
    },
    {
      "kind": "Import",
      "line": 40,
      "endLine": 40,
      "literal_source": "import hashlib"
    },
    {
      "kind": "Import",
      "line": 41,
      "endLine": 41,
      "literal_source": "import json"
    },
    {
      "kind": "Import",
      "line": 42,
      "endLine": 42,
      "literal_source": "import os"
    },
    {
      "kind": "Import",
      "line": 43,
      "endLine": 43,
      "literal_source": "import re"
    },
    {
      "kind": "Import",
      "line": 44,
      "endLine": 44,
      "literal_source": "import resource"
    },
    {
      "kind": "Import",
      "line": 45,
      "endLine": 45,
      "literal_source": "import secrets"
    },
    {
      "kind": "Import",
      "line": 46,
      "endLine": 46,
      "literal_source": "import signal"
    },
    {
      "kind": "Import",
      "line": 47,
      "endLine": 47,
      "literal_source": "import stat"
    },
    {
      "kind": "Import",
      "line": 48,
      "endLine": 48,
      "literal_source": "import subprocess"
    },
    {
      "kind": "Import",
      "line": 49,
      "endLine": 49,
      "literal_source": "import sys"
    },
    {
      "kind": "Import",
      "line": 50,
      "endLine": 50,
      "literal_source": "import time"
    },
    {
      "kind": "Assign",
      "line": 52,
      "endLine": 52,
      "targets": [
        "WORKSPACE"
      ],
      "rhs_sha256": "37e11659f565ece93879f6df5bceaa647845765eee6c9854068251447257c180",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 53,
      "endLine": 53,
      "targets": [
        "RUNTIME_PARENT"
      ],
      "rhs_sha256": "6a118641eb010a38c2d01476983191d0e5ad59092fcd956f4783440061244aa5",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 54,
      "endLine": 54,
      "targets": [
        "RUNTIME"
      ],
      "rhs_sha256": "668449280b2bed51d65db5ed126bedc573f21784519f5eba96b843901f20fa74",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 56,
      "endLine": 56,
      "targets": [
        "CONSUMED_N01_ATTEMPT_NAME"
      ],
      "rhs_sha256": "f5634478ea29275e35c68ba612b39d51eab00151dafe41d6816f8702db423a1d",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 57,
      "endLine": 57,
      "targets": [
        "CONSUMED_N01_ATTEMPT"
      ],
      "rhs_sha256": "34b02d8445e6303752787a7bc89e4152175632ee1cf254c3ac320b4b5ff98f30",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 58,
      "endLine": 58,
      "targets": [
        "CONSUMED_N01_LEDGER"
      ],
      "rhs_sha256": "cb3128ea33bb4a6ba34ff1cda02bdc0153082f59e288053af54f1a3cb0c7c167",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 59,
      "endLine": 59,
      "targets": [
        "HISTORICAL_N01_DRIVER_SHA256"
      ],
      "rhs_sha256": "3b3c875c59a2c5c3b54eaedd96881a5632f3facc21997dd976ae9b9bc25c09d6",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 60,
      "endLine": 60,
      "targets": [
        "HISTORICAL_N01_DRIVER_BYTES"
      ],
      "rhs_sha256": "0a212867d112323f81ae826c35c1c345ec65810d320ade84d7ba0e985e5461ca",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 62,
      "endLine": 62,
      "targets": [
        "PLAN_PARENT"
      ],
      "rhs_sha256": "127632f2ad8c6f31e98f1fad66c2aa17236bdeee09a1d470b907e206e9da9b8f",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 63,
      "endLine": 63,
      "targets": [
        "PLAN_ROOT"
      ],
      "rhs_sha256": "f23cf7b482c4c7234951e7f5228780d7e6422c0ad937b957438b64e9257ffcd9",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 64,
      "endLine": 64,
      "targets": [
        "ACTUAL_ROOT"
      ],
      "rhs_sha256": "330a7e5ba53aefe14a4bfe21e81e9a2cc5829c32cce36ba58a26802bcb60ab42",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 65,
      "endLine": 65,
      "targets": [
        "ATTEMPT_NAME"
      ],
      "rhs_sha256": "1bf2c05592c91cc9b67271425a9b097610068b5af8ec2eb32f37a14eb11462b5",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 66,
      "endLine": 66,
      "targets": [
        "ATTEMPT"
      ],
      "rhs_sha256": "e7fa89cea4ac9e5fa5145c8f586b97aff6edef934ff1a4d98546ab6a0c93b244",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 67,
      "endLine": 67,
      "targets": [
        "STAGES_DIR"
      ],
      "rhs_sha256": "4af308f2bf99cb230053c3733f39d75a926dd41b5976105c21b42ce9d5892d21",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 68,
      "endLine": 68,
      "targets": [
        "RECEIPT"
      ],
      "rhs_sha256": "2cdb1f3678d55773fcd650f0a0ee1bcb3da0a1e0d4d9939df7aa775a1b2428ff",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 69,
      "endLine": 69,
      "targets": [
        "LEDGER"
      ],
      "rhs_sha256": "8383f0fa6549b12e557a0a277d44b80b5dc13055a957af82e1cc85334a58077d",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 71,
      "endLine": 71,
      "targets": [
        "COMPILE_LEDGER"
      ],
      "rhs_sha256": "95f4140ae4c4bfcd0085027aa32a11a927d13170681884904b49535483981dec",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 72,
      "endLine": 72,
      "targets": [
        "COMPILE_ATTEMPT"
      ],
      "rhs_sha256": "8214f027f41d09eaf13e5c6e59c24d5b10b8594143f8ba068771f73232dce102",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 73,
      "endLine": 73,
      "targets": [
        "COMPILE_DRIVER_SHA256"
      ],
      "rhs_sha256": "ec07547acfd2c3bcbb2acbe769148f7392c97bf7096288064b9e67682abb146d",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 74,
      "endLine": 74,
      "targets": [
        "COMPILE_RECEIPT_SHA256"
      ],
      "rhs_sha256": "1507932371cca16dd02d301b07f05a08fe047bfa68d0c93e8f14d0b3672de553",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 75,
      "endLine": 75,
      "targets": [
        "COMPILED"
      ],
      "rhs_sha256": "b2a629e777bea67fe50546809001dc2beb81b7c49a2d5cd21e76f45f7e6980b2",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 76,
      "endLine": 76,
      "targets": [
        "DEFINITION"
      ],
      "rhs_sha256": "12bfcf3cba396f97739da32789b39c27cbdca3179ef20d738463b52695b7bd60",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 77,
      "endLine": 77,
      "targets": [
        "SYNTAX_DEFINITION"
      ],
      "rhs_sha256": "2ce5a6fc04297b67945c3411417c1ad12ad8b5b2128b1fa756a88c9c369b931c",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 78,
      "endLine": 78,
      "targets": [
        "MACROS"
      ],
      "rhs_sha256": "0c3b306e7379e8ae45455bc5165416e7694107dbb21e041d2c5a179788d53da1",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 79,
      "endLine": 79,
      "targets": [
        "COMPILE_INPUT"
      ],
      "rhs_sha256": "1333813646109763a826e87ffe7d258f05316bb21511090a4b3ce71dc0fdc4c6",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 80,
      "endLine": 80,
      "targets": [
        "CANDIDATE_SNAPSHOT"
      ],
      "rhs_sha256": "c75be73c29a4fa8081bf79db519394c4bece260cb172b981dc5565bbfdd7ae4e",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 81,
      "endLine": 81,
      "targets": [
        "CANDIDATE_RECORD"
      ],
      "rhs_sha256": "b9e6b213a4c08d8e2001a7d4719c9ab125594851bf3abbb1fa3bdbc65b0f9fa4",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 82,
      "endLine": 82,
      "targets": [
        "CANDIDATE_RECORD_SHA256"
      ],
      "rhs_sha256": "ff5829fb5526cca4f43aa7426f16e0b6dcbefb1560c018e84eb1ab77cedac602",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 84,
      "endLine": 84,
      "targets": [
        "N01_INPUTS"
      ],
      "rhs_sha256": "dd51618310ab5faa9111d8b9cca00a0cb7091149c98201fac0167123204dc1f7",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 85,
      "endLine": 85,
      "targets": [
        "N01_INPUT"
      ],
      "rhs_sha256": "ff39df6633da3a5d623097a129b5ae7975db57bda3558e38c2d1fc2330d3d59f",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 86,
      "endLine": 86,
      "targets": [
        "N01_INPUT_SHA256"
      ],
      "rhs_sha256": "5851aa23748b4510db836cc5b209d0d229a0f43db3dc61099bf988e67f541900",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 87,
      "endLine": 87,
      "targets": [
        "N01_INPUT_BYTES"
      ],
      "rhs_sha256": "44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 89,
      "endLine": 89,
      "targets": [
        "INPUTS"
      ],
      "rhs_sha256": "20a90933689eae51d1727347f7792cbb5036fc9a9ca6a3c788f116ab6a8776c9",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 90,
      "endLine": 90,
      "targets": [
        "INPUT"
      ],
      "rhs_sha256": "9d648b8f3c219353b5ab0f89415d90f5c992ca75cbd6cdce3a89d6b36822a59b",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 91,
      "endLine": 91,
      "targets": [
        "INPUT_SHA256"
      ],
      "rhs_sha256": "cfadd675f252baf750fd9466eab0f7d343586eae08c7a31209e12c7298ec4e4e",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 92,
      "endLine": 92,
      "targets": [
        "INPUT_BYTES"
      ],
      "rhs_sha256": "9197e4844abed2fea3569a2acf7b0d584c979c333ab7ae10ba6c339898776f5a",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 93,
      "endLine": 93,
      "targets": [
        "INITIAL_FUEL"
      ],
      "rhs_sha256": "6e4001871c0cf27c7634ef1dc478408f642410fd3a444e2a88e301f5c4a35a4d",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 94,
      "endLine": 94,
      "targets": [
        "STACK_LIMIT"
      ],
      "rhs_sha256": "a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 96,
      "endLine": 96,
      "targets": [
        "PROSPECTIVE_K_COMMANDS"
      ],
      "rhs_sha256": "fe4cfc9fab1dc635b5ead0252112106bf5271ed43df946494ad2343c27a2f444",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 97,
      "endLine": 97,
      "targets": [
        "PROSPECTIVE_K_COMMANDS_SHA256"
      ],
      "rhs_sha256": "02c005ac1a6689354f769cfcef03701466a9279686c527c02c955ffa43ab34c9",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 98,
      "endLine": 98,
      "targets": [
        "PROSPECTIVE_K_COMMANDS_BYTES"
      ],
      "rhs_sha256": "f7471268f8b72c33120b04f122c0a6f76cb462012a707b17a2bd43fbb6a8badb",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 99,
      "endLine": 99,
      "targets": [
        "PROSPECTIVE_K_COMMANDS_COUNT"
      ],
      "rhs_sha256": "1dfacb2ea5a03e0a915999e03b5a56196f1b1664d2f768d1b7eff60ac059789d",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 100,
      "endLine": 100,
      "targets": [
        "INITIALIZER_RECIPE_SHA256"
      ],
      "rhs_sha256": "7c2df7c9f2085ac126c0ed86e1af913ecd81973ea80034d87827c68b1b444454",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 101,
      "endLine": 101,
      "targets": [
        "INITIALIZER_RECIPE_BYTES"
      ],
      "rhs_sha256": "96382608813353bee4eeaf0635a3b3356276fece94fe8c9cf048871078f8fd14",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 102,
      "endLine": 102,
      "targets": [
        "READ_IMPORT_PINS"
      ],
      "rhs_sha256": "055b53ef429c418b54d7470587d11dad0cc572e9036f6ae0553996388ec6a21c",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 103,
      "endLine": 103,
      "targets": [
        "READ_IMPORT_PINS_SHA256"
      ],
      "rhs_sha256": "00a9e5065cbe4c23d989eabb489fb47f48b0001d7d7590f11a0b25611327211f",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 104,
      "endLine": 104,
      "targets": [
        "READ_IMPORT_PINS_BYTES"
      ],
      "rhs_sha256": "e9731841267c45a764eee59b59df31d954cb832925ead4a0f139e13524691ea8",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 106,
      "endLine": 106,
      "targets": [
        "INTERPRETER_SHA256"
      ],
      "rhs_sha256": "c1db71ab98c83fecf3ec47f3cc12fbe57c70071a0bf3d14ed8779e1ca28e9bd5",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 108,
      "endLine": 108,
      "targets": [
        "STORE"
      ],
      "rhs_sha256": "fd3b8c68d331b7a78551389c175d0fcf847f10484f95798bd5f8c53420a38db7",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 109,
      "endLine": 109,
      "targets": [
        "K_ROOT"
      ],
      "rhs_sha256": "c43f71affc265f883fef14d6c3de0494574678898eb5073190af5648746d9886",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 110,
      "endLine": 110,
      "targets": [
        "JRE_ROOT"
      ],
      "rhs_sha256": "dccec228383214ebfe6f80b5d01add72c87b13e2d1feb79568e9ebfa28e8fcaa",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 111,
      "endLine": 111,
      "targets": [
        "JAVA"
      ],
      "rhs_sha256": "e475b7bf186f82eaea0351eb55850046c8ff7ede931bf0418eda8a55aed4c1ac",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 112,
      "endLine": 112,
      "targets": [
        "K_JARS"
      ],
      "rhs_sha256": "04fe68ceb73416b7881799903fe632d7e99bfa30266748150b94cb4c3fb1c0e9",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 113,
      "endLine": 113,
      "targets": [
        "K_BUILTIN"
      ],
      "rhs_sha256": "9c230bae3ec8b807469fc146839e26fb8e2aaba42299c6f57dd688836adca66c",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 114,
      "endLine": 114,
      "targets": [
        "K_WRAPPER"
      ],
      "rhs_sha256": "5d234534f47764518336d5730da8f5144b5364fdf840379127e89f9d3b04511c",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 115,
      "endLine": 115,
      "targets": [
        "K_UNWRAPPED"
      ],
      "rhs_sha256": "442bf5dee1c27486283adbabb844fdea10af75fca08b422798d47973012868eb",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 116,
      "endLine": 116,
      "targets": [
        "K_LIBRARY"
      ],
      "rhs_sha256": "fadd2d6442b9f526cd91507cc8ab1ad2bfa196adbd844fa89a18990a164e7402",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 117,
      "endLine": 117,
      "targets": [
        "K_KAST_UNWRAPPED"
      ],
      "rhs_sha256": "adca4349fcd8dc986c5f609cb4d84f66e69897bc22bc64f19f58fd9e7a8466a6",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 118,
      "endLine": 118,
      "targets": [
        "K_KORE_PRINT_UNWRAPPED"
      ],
      "rhs_sha256": "6bd269649d5907d0b39d7f1d5e321d3a2e0bc893027f7f2e7a77e1e026dd3ffc",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 119,
      "endLine": 119,
      "targets": [
        "K_KORE_PRINT_WRAPPER"
      ],
      "rhs_sha256": "7669ff2400990d4146ab505b9a27208cc190048846d0352941336bdfca6a7d23",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 120,
      "endLine": 125,
      "targets": [
        "TOOL_ROOTS"
      ],
      "rhs_sha256": "ca2fcce0f1db235a95a247c624755c2045f69976d750b4eab658d4f8a7e23d82",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 126,
      "endLine": 126,
      "targets": [
        "GCC_ROOT"
      ],
      "rhs_sha256": "bb2a7651895eea031f85795d6a5d066da24a2fa5ee0503abc82462facf27ed5b",
      "calls": [
        "dict"
      ],
      "literal_source": "GCC_ROOT = dict(TOOL_ROOTS)['gcc']"
    },
    {
      "kind": "Assign",
      "line": 127,
      "endLine": 127,
      "targets": [
        "FLEX"
      ],
      "rhs_sha256": "a79880ca38f51337e93ac0a6d44786ac01a0ed0620892d0ffac478a6777ef8c7",
      "calls": [
        "dict"
      ],
      "literal_source": "FLEX = dict(TOOL_ROOTS)['flex'] + '/bin/flex'"
    },
    {
      "kind": "Assign",
      "line": 128,
      "endLine": 128,
      "targets": [
        "KORE_ROOT"
      ],
      "rhs_sha256": "2fad9891cc136d64b0741186d6eb31811d8256678993957c670823aa77fc0081",
      "calls": [
        "dict"
      ],
      "literal_source": "KORE_ROOT = dict(TOOL_ROOTS)['kore-parser']"
    },
    {
      "kind": "Assign",
      "line": 129,
      "endLine": 129,
      "targets": [
        "Z3_ROOT"
      ],
      "rhs_sha256": "755798e0b1f739d9d33f4da1514a3c20ef19a60b694420e9443805c4f565915d",
      "calls": [
        "dict"
      ],
      "literal_source": "Z3_ROOT = dict(TOOL_ROOTS)['z3']"
    },
    {
      "kind": "Assign",
      "line": 130,
      "endLine": 130,
      "targets": [
        "KORE_EXEC"
      ],
      "rhs_sha256": "9ce7525b444ee3e838dc0efa3a15e2587404e0a2947aa7017ecc1c8372b09733",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 131,
      "endLine": 131,
      "targets": [
        "KORE_EXEC_SHA256"
      ],
      "rhs_sha256": "213354f701a24cc4f22796c628e900abc2f9743dc3181c168f38157052aa37ce",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 132,
      "endLine": 132,
      "targets": [
        "KORE_EXEC_WRAPPER"
      ],
      "rhs_sha256": "7c28195de7eac0fdf6ff8031bf76fc44b07e7e5e60c8c5c637f67d1290ede357",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 133,
      "endLine": 133,
      "targets": [
        "LLVM_ROOT"
      ],
      "rhs_sha256": "29cb57b0125accc3d4fe58e2e5adc52f5466290066e86c3747bf13e0b17f8108",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 134,
      "endLine": 134,
      "targets": [
        "KPRINT"
      ],
      "rhs_sha256": "ca3809ac7441b404d6131df29040dd3f8c96fa49f5851ae2a8b9945df9df06ba",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 135,
      "endLine": 135,
      "targets": [
        "JAVA_PATH"
      ],
      "rhs_sha256": "ca82a612a152ccea914e9800e02306e38904a376bde3743cb9ee2b97bf31bf91",
      "calls": [
        "':'.join"
      ],
      "literal_source": "JAVA_PATH = ':'.join(root + '/bin' for _, root in TOOL_ROOTS)"
    },
    {
      "kind": "Assign",
      "line": 136,
      "endLine": 136,
      "targets": [
        "KORE_EXEC_PATH"
      ],
      "rhs_sha256": "da1b8073e3e1fe1acf7abc03c5e933a5f5b6dac320417f8679353d66fae95d59",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 138,
      "endLine": 138,
      "targets": [
        "CHILD_SECONDS"
      ],
      "rhs_sha256": "624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4",
      "calls": [],
      "literal_source": "CHILD_SECONDS = 30"
    },
    {
      "kind": "Assign",
      "line": 139,
      "endLine": 139,
      "targets": [
        "SWEEP_SECONDS"
      ],
      "rhs_sha256": "4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce",
      "calls": [],
      "literal_source": "SWEEP_SECONDS = 3"
    },
    {
      "kind": "Assign",
      "line": 140,
      "endLine": 140,
      "targets": [
        "FILE_SIZE_LIMIT"
      ],
      "rhs_sha256": "38496d62864bc2a21b9f637a8c8bc440df46a2b016939dc620d166d41bfa79d9",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 141,
      "endLine": 141,
      "targets": [
        "TOKEN_NAME"
      ],
      "rhs_sha256": "1e95b208271aa502b871bfb866ab5af92c226c08c4605fcf21472f43a18f9d4b",
      "calls": [],
      "literal_source": "TOKEN_NAME = 'SHERLOCK_K_ATTEMPT_TOKEN'"
    },
    {
      "kind": "Assign",
      "line": 142,
      "endLine": 142,
      "targets": [
        "STORE_ROOT"
      ],
      "rhs_sha256": "71bf1640ea417f9680adc2ee801bccd3f7eebc548a03c43737a85e21066e2a72",
      "calls": [
        "re.compile"
      ],
      "literal_source": "STORE_ROOT = re.compile(rb'/nix/store/[0-9a-z]{32}-[0-9A-Za-z+._?=-]+')"
    },
    {
      "kind": "Assign",
      "line": 143,
      "endLine": 143,
      "targets": [
        "EMPTY_SHA256"
      ],
      "rhs_sha256": "0bcdfc8dcd6beea3c8bb438552618e364c76f9e016e13b67c1f3821ecf9d11f7",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 145,
      "endLine": 145,
      "targets": [
        "MAIN_REL"
      ],
      "rhs_sha256": "b079b2e6d6d61fc6a2207669bcf3ab267c00a8a340426294ba21334d93ebab05",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 146,
      "endLine": 146,
      "targets": [
        "MAIN_SHA256"
      ],
      "rhs_sha256": "fbd6539fc3bbc3effa91f5814c58abe5df408eea9ef29de9f732e93d9ae8523b",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 147,
      "endLine": 147,
      "targets": [
        "MAIN_BYTES"
      ],
      "rhs_sha256": "072db31ce670255297c5d67fd00068faf81a7f50223b5a5af0f555aa69815fe0",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 148,
      "endLine": 160,
      "targets": [
        "HISTORICAL_N01_SOURCE_FILES"
      ],
      "rhs_sha256": "24f6c9416b750abaf7c015b440e27a9590d5ad6ee54ec60ed28fd597d9ea0b64",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 161,
      "endLine": 173,
      "targets": [
        "SOURCE_FILES"
      ],
      "rhs_sha256": "16cff616b295f4e69bae21247458da48eb248d0099105b27ecb71979e62f9319",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 174,
      "endLine": 174,
      "targets": [
        "K_SRC"
      ],
      "rhs_sha256": "3c9978dec3a70cebeb3e30c514ef36d7095ea47e99520c2c2cb457e712de7b75",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 175,
      "endLine": 175,
      "targets": [
        "KORE_PKG"
      ],
      "rhs_sha256": "2a1bdde327fc519c5e0eff8037005826668399ffeb4aa9d3a3b244317c2c3b47",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 176,
      "endLine": 176,
      "targets": [
        "KORE_SRC"
      ],
      "rhs_sha256": "ec6f2a90817bc9a46955083b5527c84673b9fd0a7a02dd94fd8de975f66435a0",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 177,
      "endLine": 177,
      "targets": [
        "LLVM_SRC"
      ],
      "rhs_sha256": "1aa5b6560c6d6118c81ca6ede0f21e6361107d98f5d7be5ac48b9178fc220748",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 178,
      "endLine": 216,
      "targets": [
        "PRIMARY_SOURCES"
      ],
      "rhs_sha256": "3dd27acb072c4a2c07d7c42a7c34a77ad5cf171eee1e5e35d0ed84163d8adfa0",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 217,
      "endLine": 223,
      "targets": [
        "PINNED_FILES"
      ],
      "rhs_sha256": "6a1e65e1109f88f99dcf2380c83b4e8343618ac359c68e8c64dbbb7589900160",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 224,
      "endLine": 247,
      "targets": [
        "COMPILE_TREE"
      ],
      "rhs_sha256": "00ab2897e7c453c36e408f7b98669a4013c8c78168683982c6f8771b571c7b3c",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 248,
      "endLine": 249,
      "targets": [
        "COMPILE_INPUT_SHAPE"
      ],
      "rhs_sha256": "8f17e818a0b72174d436c060289214344b12f8c895305497284dc48bd34fbf5c",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 252,
      "endLine": 253,
      "targets": [
        "UIRUN_OPEN"
      ],
      "rhs_sha256": "5533981bcd40e1f2471109f27b39c18d65a30f63c749a41d1d5e0fdc9b209971",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 254,
      "endLine": 263,
      "targets": [
        "DEFINITION_MARKERS"
      ],
      "rhs_sha256": "219d2aad6ea39fecd49c9c91e6d8acbced0892ce5197af507146179912eea669",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 264,
      "endLine": 266,
      "targets": [
        "INIT_PREFIX"
      ],
      "rhs_sha256": "336efca53f1e83bd62d7eea13a0eba8e218d10d2c301a99a50add526181df184",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 267,
      "endLine": 267,
      "targets": [
        "INIT_SUFFIX"
      ],
      "rhs_sha256": "cf70693ff4bccf40a20ef84e33f98c7b3dbda34009e43344c8db84975238a32b",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 268,
      "endLine": 268,
      "targets": [
        "PARSED_LIMIT"
      ],
      "rhs_sha256": "2acfd08aa731ac7cb3a84903b096431859617ae369863aeea33912a3220616d4",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 269,
      "endLine": 269,
      "targets": [
        "LOG_ENTRIES"
      ],
      "rhs_sha256": "c6eb2494514939463fe1b1277a7d87ecc6f00a14afd32dc3a17b88422cb9d230",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 271,
      "endLine": 271,
      "targets": [
        "STAGE_KAST"
      ],
      "rhs_sha256": "eaaccaf663fd34f0dbeecdb83abbb3b2d063b2d29bc92752750c43e31f28d49d",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 272,
      "endLine": 272,
      "targets": [
        "STAGE_INIT"
      ],
      "rhs_sha256": "f8e9ca7630b7557707975ded7213314b6bec6c66e532e84b6a0401a02abc5e5d",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 273,
      "endLine": 273,
      "targets": [
        "ENGINE_STAGE_MAX_INDEX"
      ],
      "rhs_sha256": "7b1a278f5abe8e9da907fc9c29dfd432d60dc76e17b0fabab659d2a508bc65c4",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 274,
      "endLine": 276,
      "targets": [
        "ENGINE_STAGES"
      ],
      "rhs_sha256": "878fe210bc1c281b8b7f6a6e57a13e07d4e7db8baa84a6ea91beb971626a85ca",
      "calls": [
        "tuple",
        "range"
      ],
      "literal_source": "ENGINE_STAGES = (('exec-000', 0),) + tuple(\n    (f'exec-{idx:03d}', 1) for idx in range(1, ENGINE_STAGE_MAX_INDEX + 1)\n)"
    },
    {
      "kind": "Assign",
      "line": 277,
      "endLine": 277,
      "targets": [
        "PRINT_STAGES"
      ],
      "rhs_sha256": "359c18135b5e6fea2ca34751f61f50adc7fe61a7d93ebb1b2a562864406be1b4",
      "calls": [
        "tuple",
        "range"
      ],
      "literal_source": "PRINT_STAGES = tuple(f'print-{idx:03d}' for idx in range(ENGINE_STAGE_MAX_INDEX + 1))"
    },
    {
      "kind": "Assign",
      "line": 278,
      "endLine": 278,
      "targets": [
        "CHILD_STAGE_NAMES"
      ],
      "rhs_sha256": "c5a18aad8d7faa822e2f42dc2fb83ba026b91bb0f8e378a1292e219331b9d7ee",
      "calls": [
        "tuple"
      ],
      "literal_source": "CHILD_STAGE_NAMES = (STAGE_KAST,) + tuple(name for name, _ in ENGINE_STAGES) + PRINT_STAGES"
    },
    {
      "kind": "Assign",
      "line": 279,
      "endLine": 279,
      "targets": [
        "STAGE_NAMES"
      ],
      "rhs_sha256": "4d691e1f68fb740b863e35b04661cae4fb0eb900308a8f26fd761076a807acc3",
      "calls": [
        "list"
      ],
      "literal_source": "STAGE_NAMES = [STAGE_KAST, STAGE_INIT] + [name for name, _ in ENGINE_STAGES] + list(PRINT_STAGES)"
    },
    {
      "kind": "Assign",
      "line": 281,
      "endLine": 477,
      "targets": [
        "PROSPECTIVE_STAGE_TOKENS"
      ],
      "rhs_sha256": "6dfec8533fd15c1fec3056c987cfd00fc7497f54c325810127e5be9c78596eb7",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 479,
      "endLine": 492,
      "targets": [
        "STAGE_GEOMETRY"
      ],
      "rhs_sha256": "1bf3038977eaef338f332312546c06886c44d714c3ce08679c2fb913564b5336",
      "calls": [
        "dict"
      ],
      "literal_source": "STAGE_GEOMETRY = dict(\n    total_child_commands=PROSPECTIVE_K_COMMANDS_COUNT,\n    kast_children=1,\n    local_initializer_stages=1,\n    kore_exec_children=97,\n    kprint_children=97,\n    prestartup_raw=('kast', 'initializer', 'exec-000', 'print-000'),\n    startup_probe=('exec-001', 'print-001'),\n    post_startup_state_prints='print-001..print-095 (95 states)',\n    charged_transitions='exec-002..exec-094 (93 charged steps)',\n    free_publication_transition=('exec-095', 'print-095'),\n    terminal_probe=('exec-096', 'print-096'),\n    arithmetic_child_wall_cap_sum_seconds=PROSPECTIVE_K_COMMANDS_COUNT * CHILD_SECONDS,\n)"
    },
    {
      "kind": "Assign",
      "line": 493,
      "endLine": 495,
      "targets": [
        "LIMITS"
      ],
      "rhs_sha256": "14757fecaca8e53eb7b456c0a5a00ee139c23688ad2f100bcbbdac8a9c1f9553",
      "calls": [
        "dict"
      ],
      "literal_source": "LIMITS = dict(wall_seconds=CHILD_SECONDS, sweep_seconds=SWEEP_SECONDS, rlimit_core=0, umask='0o077',\n              process_group='new session; SIGKILL to group at deadline and after exit; token sweep',\n              memory_cpu='tool defaults, as for the admitted native compile children; only the JVM is bounded')"
    },
    {
      "kind": "Assign",
      "line": 496,
      "endLine": 496,
      "targets": [
        "JVM_LIMITS"
      ],
      "rhs_sha256": "6e10476ce16fe05bb9297f118b3c13cf706ff68a9fa8b48131da79b10f50d537",
      "calls": [
        "dict"
      ],
      "literal_source": "JVM_LIMITS = dict(jvm_heap='64m..512m', jvm_stack='32m', jvm_active_processors=2)"
    },
    {
      "kind": "Assign",
      "line": 497,
      "endLine": 502,
      "targets": [
        "EXPECTATIONS"
      ],
      "rhs_sha256": "1c37a1066142f140338638542e3f19e363108350935557c9108b385ba6701f7d",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 503,
      "endLine": 506,
      "targets": [
        "SCOPE"
      ],
      "rhs_sha256": "70b774e9b08c733eb5dcb9e0374dc79d508c644a0e75bd107bff50cd1a0f2e98",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "Assign",
      "line": 507,
      "endLine": 508,
      "targets": [
        "IDENTITY_KEYS"
      ],
      "rhs_sha256": "73c108467426aea78aecce2996840a91e99a65ec9a3b57a53718189cff189061",
      "calls": [],
      "factored": "literal/container/operator expression; complete original text in IMPORT-TIME-AST.json and pinned full source; not consumed by selected callable"
    },
    {
      "kind": "FunctionDef",
      "line": 511,
      "endLine": 512,
      "definition_only": "utc"
    },
    {
      "kind": "FunctionDef",
      "line": 515,
      "endLine": 519,
      "definition_only": "environment"
    },
    {
      "kind": "FunctionDef",
      "line": 522,
      "endLine": 527,
      "definition_only": "sha256_file"
    },
    {
      "kind": "FunctionDef",
      "line": 530,
      "endLine": 534,
      "definition_only": "file_digest"
    },
    {
      "kind": "FunctionDef",
      "line": 537,
      "endLine": 552,
      "definition_only": "read_exact"
    },
    {
      "kind": "FunctionDef",
      "line": 555,
      "endLine": 560,
      "definition_only": "read_store"
    },
    {
      "kind": "FunctionDef",
      "line": 563,
      "endLine": 564,
      "definition_only": "open_exclusive"
    },
    {
      "kind": "FunctionDef",
      "line": 567,
      "endLine": 575,
      "definition_only": "write_exclusive"
    },
    {
      "kind": "FunctionDef",
      "line": 578,
      "endLine": 585,
      "definition_only": "append_ledger"
    },
    {
      "kind": "FunctionDef",
      "line": 588,
      "endLine": 602,
      "definition_only": "entry"
    },
    {
      "kind": "FunctionDef",
      "line": 605,
      "endLine": 614,
      "definition_only": "tree"
    },
    {
      "kind": "FunctionDef",
      "line": 617,
      "endLine": 631,
      "definition_only": "check_sources"
    },
    {
      "kind": "FunctionDef",
      "line": 634,
      "endLine": 646,
      "definition_only": "check_primary"
    },
    {
      "kind": "FunctionDef",
      "line": 649,
      "endLine": 663,
      "definition_only": "check_pinned"
    },
    {
      "kind": "FunctionDef",
      "line": 666,
      "endLine": 671,
      "definition_only": "store_executable"
    },
    {
      "kind": "FunctionDef",
      "line": 674,
      "endLine": 683,
      "definition_only": "elf_magic"
    },
    {
      "kind": "FunctionDef",
      "line": 686,
      "endLine": 700,
      "definition_only": "store_refs"
    },
    {
      "kind": "FunctionDef",
      "line": 703,
      "endLine": 726,
      "definition_only": "packaging_evidence"
    },
    {
      "kind": "FunctionDef",
      "line": 729,
      "endLine": 742,
      "definition_only": "kprint_linkage"
    },
    {
      "kind": "FunctionDef",
      "line": 745,
      "endLine": 769,
      "definition_only": "nix_support_flags"
    },
    {
      "kind": "FunctionDef",
      "line": 772,
      "endLine": 779,
      "definition_only": "locate"
    },
    {
      "kind": "FunctionDef",
      "line": 782,
      "endLine": 800,
      "definition_only": "compiler_closure"
    },
    {
      "kind": "FunctionDef",
      "line": 803,
      "endLine": 811,
      "definition_only": "compile_attempt_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 814,
      "endLine": 819,
      "definition_only": "compile_input_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 822,
      "endLine": 842,
      "definition_only": "candidate_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 845,
      "endLine": 859,
      "definition_only": "input_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 862,
      "endLine": 886,
      "definition_only": "prospective_plan_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 889,
      "endLine": 902,
      "definition_only": "compiled_content_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 905,
      "endLine": 907,
      "definition_only": "pinned_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 910,
      "endLine": 924,
      "definition_only": "compile_ledger_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 927,
      "endLine": 939,
      "definition_only": "engine_ledger_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 942,
      "endLine": 964,
      "definition_only": "runtime_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 967,
      "endLine": 980,
      "definition_only": "protected_snapshot"
    },
    {
      "kind": "FunctionDef",
      "line": 983,
      "endLine": 988,
      "definition_only": "inventories"
    },
    {
      "kind": "FunctionDef",
      "line": 991,
      "endLine": 996,
      "definition_only": "identity"
    },
    {
      "kind": "FunctionDef",
      "line": 999,
      "endLine": 1036,
      "definition_only": "preflight"
    },
    {
      "kind": "FunctionDef",
      "line": 1039,
      "endLine": 1066,
      "definition_only": "processes"
    },
    {
      "kind": "FunctionDef",
      "line": 1069,
      "endLine": 1073,
      "definition_only": "kill_group"
    },
    {
      "kind": "FunctionDef",
      "line": 1076,
      "endLine": 1091,
      "definition_only": "sweep"
    },
    {
      "kind": "FunctionDef",
      "line": 1094,
      "endLine": 1135,
      "definition_only": "launch"
    },
    {
      "kind": "FunctionDef",
      "line": 1138,
      "endLine": 1143,
      "definition_only": "protected_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 1146,
      "endLine": 1171,
      "definition_only": "stage_problems"
    },
    {
      "kind": "FunctionDef",
      "line": 1174,
      "endLine": 1211,
      "definition_only": "child_stage"
    },
    {
      "kind": "FunctionDef",
      "line": 1214,
      "endLine": 1247,
      "definition_only": "parsed_problem"
    },
    {
      "kind": "FunctionDef",
      "line": 1250,
      "endLine": 1281,
      "definition_only": "initializer_stage"
    },
    {
      "kind": "FunctionDef",
      "line": 1284,
      "endLine": 1292,
      "definition_only": "kast_command"
    },
    {
      "kind": "FunctionDef",
      "line": 1295,
      "endLine": 1300,
      "definition_only": "exec_command"
    },
    {
      "kind": "FunctionDef",
      "line": 1303,
      "endLine": 1304,
      "definition_only": "kprint_command"
    },
    {
      "kind": "FunctionDef",
      "line": 1307,
      "endLine": 1357,
      "definition_only": "expected_prospective_k_commands"
    },
    {
      "kind": "FunctionDef",
      "line": 1360,
      "endLine": 1392,
      "definition_only": "run_stages"
    },
    {
      "kind": "FunctionDef",
      "line": 1395,
      "endLine": 1415,
      "definition_only": "postflight"
    },
    {
      "kind": "FunctionDef",
      "line": 1418,
      "endLine": 1431,
      "definition_only": "persist"
    },
    {
      "kind": "FunctionDef",
      "line": 1434,
      "endLine": 1482,
      "definition_only": "execute"
    },
    {
      "kind": "FunctionDef",
      "line": 1485,
      "endLine": 1499,
      "definition_only": "main"
    },
    {
      "kind": "If",
      "line": 1502,
      "endLine": 1503,
      "literal_source": "if __name__ == '__main__':\n    sys.exit(main())"
    }
  ],
  "full_projection": "context/IMPORT-TIME-AST.json",
  "selected_closure": "context/EXISTING-LAUNCH-CALLABLE-CLOSURE.py.txt",
  "execution": "ast.parse only, module not imported"
}

===== END BODY 22 =====

===== COMPLETE BODY 23 Current six-source and15compiled hashes; syntax reconstruction =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-Add-independent-oracle-and-runtime-task-20261019/source-operation-review-01/CURRENT-PINS-AND-SYNTAX-RECONSTRUCTION.json
BYTES: 7802 SHA256: 79b9285b41b28fa688a87d2eed4dc22fcfa39954c904438d3a4ee36af0dcc8c7
{
  "model_source6_current": [
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/source/nominal-product-syntax.k",
      "bytes": 5090,
      "sha256": "750f9b820a672865b2a1abc50bef4f417f2c6c02e7b77f661a0431388dacab8c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/source/nominal-product.k",
      "bytes": 21856,
      "sha256": "29da74d7ab2b89cb23155521b94ffb6880920befcbf9806941ba97826d47b197"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/source/normal-lt-observations.k",
      "bytes": 272,
      "sha256": "5b5cf8667af2ee29477d3d7fee6e566dea50c70edc8808f0b7824bc73750c0ea"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/source/normal-lt-syntax.k",
      "bytes": 1070,
      "sha256": "814208b14f265534b5bbf0f0264267fc8af76fb7d01d2610c4e02faf7a56d972"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/source/normal-lt.k",
      "bytes": 4566,
      "sha256": "c3f7b2d8266e0f0aeeda02149cc149ee1c042a94de52d4e5bdf8c68f4e79abec"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/source/normal-trace-observations.k",
      "bytes": 1735,
      "sha256": "6cd7fc81c394a06ed7a963f8be21a36a57dbeead252820203e65de618a795af0"
    }
  ],
  "compiled15_current": [
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/README.md",
      "bytes": 2886,
      "sha256": "7202c455a322f60276c475075cc7f76c08065b6ef12b4312181038a9f8cb2120"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/allRules.txt",
      "bytes": 63345,
      "sha256": "1260ff32186b21b714b2cd7ec1aaa11824a0f1ea93f998fdfa6691f3190dbd9d"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/backend.txt",
      "bytes": 7,
      "sha256": "d11158b53adecdbfce1ad5c64d1adb628145cac84e958b1bf6fed68be5a6b64c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/cache.bin",
      "bytes": 2307754,
      "sha256": "fbe30ba674bff5665bab7e8810bc78758e66c61e23ccfbf390cf6d9e97f29500"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/compiled.bin",
      "bytes": 2974054,
      "sha256": "0605df15efc98ca3ed6e2342df7750ec247b1457ed4a9cbaff26275b75a29b5b"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/compiled.txt",
      "bytes": 380620,
      "sha256": "980b967cf9d795ec08beb0b8e31a911e967b8826491c3b8c5f6bee74e5619e8f"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/configVars.sh",
      "bytes": 84,
      "sha256": "d32f0ab8ed82e7ec0e4f8a0715efac85e8abcb89ef4d32eb5c50e31426f1de83"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/definition.kore",
      "bytes": 1903957,
      "sha256": "456fdb3b375761cc2adbb857b143e0c002ec1d6dc01210a07d7456bc4302d246"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/macros.kore",
      "bytes": 10,
      "sha256": "3585c084b81281ec26971b2e42c56b9968a802c5d645a81062296350493491cf"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/mainModule.txt",
      "bytes": 32,
      "sha256": "f2b4c63def9218d8c8483ed3c1d73909ce1b858242c34ddfada68d697d59420c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/mainSyntaxModule.txt",
      "bytes": 32,
      "sha256": "f2b4c63def9218d8c8483ed3c1d73909ce1b858242c34ddfada68d697d59420c"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/parsed.txt",
      "bytes": 346528,
      "sha256": "ed924dd3448ab49c5140fc2bcfe8ff3ed1fdb821665484c58e48ffa5e7dcbd2f"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/scanner",
      "bytes": 342496,
      "sha256": "04748ff6a91e5b7de1a176b36c27e2e5048d298b7cfca9bf09971bdc4e371054"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/syntaxDefinition.kore",
      "bytes": 270085,
      "sha256": "717e3c01d2c9fecf740a3af765666e6b5b492aa11292e1a60a68ddc9f237a8f7"
    },
    {
      "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/nominal-lt-kompiled/timestamp",
      "bytes": 7,
      "sha256": "55800d7983a2a9904d34a306a176e303c5cd2b75dd99b8a761e92140ef9d4510"
    }
  ],
  "original_compile_receipt": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/00-compile/RESULT.json",
    "bytes": 414,
    "sha256": "5cf6b8797352e2dcf9ff93cdde092c96ecefe986291137a75f3ff809819f28f5"
  },
  "combined_syntax": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-two-linked-uncharged-boundaries-20261019/context/COMPLETE-LT-CONSTRUCTOR-SYNTAX.k.txt",
    "bytes": 6161,
    "sha256": "fd0e9ac0978d326c071b5ece6428d4b2903b2447b0698c3b384e742b40ef6d7e"
  },
  "construction": "Complete nominal-product-syntax.k + literal LF + complete normal-lt-syntax.k, both included as full source bodies.",
  "combined_byte_equality": true,
  "protected_oracle_files": "Never opened, hashed or stat-scanned; descriptors only from SAFE-HANDOFF.",
  "no_compile_or_K_runtime_execution": true
}

===== END BODY 23 =====

===== COMPLETE BODY 24 Existing full tool-entry identity manifest incl JVM controls =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/compile-only/TOOL-ENTRY-PINS.json
BYTES: 45447 SHA256: f93c73ffbb5b0cca5244b4c61aaa14172eaa357e4f29fb978e03b0d0cc8d628b
{
  "status": "READONLY_CURRENT_ENTRIES_JAR_MEMBERSHIP_NO_TOOL_EXECUTION",
  "entries": [
    {
      "path": "/usr/bin/python3",
      "bytes": 7477160,
      "sha256": "52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41",
      "resolved_path": "/usr/bin/python3.14"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/bin/java",
      "bytes": 14440,
      "sha256": "2a065ca5589bc80168f45166653c6e58d97ce63bbd7407c85eb5fed6622a5740",
      "resolved_path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/bin/java"
    },
    {
      "path": "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/.kore-exec-wrapped",
      "bytes": 15356472,
      "sha256": "4ebe3cd5b32864352247b954c2d0fb90a7a5730e519a6c4516bb2b5a2c315429",
      "resolved_path": "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/.kore-exec-wrapped"
    },
    {
      "path": "/nix/store/p7hjh21dj4bc1s6kfcdwk45knp5n4cc0-llvm-backend-0.1.140/bin/kprint",
      "bytes": 2650880,
      "sha256": "5d7094f9c36d7967144dbb6c10168eb6ba402bb869ead438ae9e326c81e2c7ec",
      "resolved_path": "/nix/store/p7hjh21dj4bc1s6kfcdwk45knp5n4cc0-llvm-backend-0.1.140/bin/kprint"
    }
  ],
  "classpath_pattern": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/*",
  "classpath_jar_membership": [
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/JavaEWAH-1.2.3.jar",
      "bytes": 170567,
      "sha256": "d65226949713c4c61a784f41c51167e7b0316f93764398ebba9e4336b3d954c2"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/annotations-24.0.1.jar",
      "bytes": 30651,
      "sha256": "61666dbce7e42e6c85b43c04fcfb8293a21dcb55b3c80e869270ce42c01a6b35"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/aopalliance-1.0.jar",
      "bytes": 4467,
      "sha256": "0addec670fedcd3f113c5c8091d783280d23f75e3acb841b61a9cdb079376a08"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/autolink-0.6.0.jar",
      "bytes": 16098,
      "sha256": "a80be030f6386f18111cad9161c0b6983157352a1b59a59e6002172f0d321c04"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/automaton-1.11-8.jar",
      "bytes": 176285,
      "sha256": "a24475f6ccfe1cc7a4fe9e34e05ce687b0ce0c6e8cb781e0eced3b186482c61e"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/checker-qual-3.37.0.jar",
      "bytes": 224460,
      "sha256": "e4ce1376cc2735e1dde220b62ad0913f51297704daad155a33f386bc5db0d9f7"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/common_2.13-4.8.14.jar",
      "bytes": 2463771,
      "sha256": "49b5831bf995c88ee69681c5c198a6219ceeeb7c894eef0670078dc030055b5c"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/commons-codec-1.13.jar",
      "bytes": 344339,
      "sha256": "61f7a3079e92b9fdd605238d0295af5fd11ac411a0a0af48deace1f6c5ffa072"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/commons-collections4-4.3.jar",
      "bytes": 753996,
      "sha256": "62f8db7da73e551f82d70fd533834177af6bd953de4b5e85c44dc2100de4beb8"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/commons-io-2.7.jar",
      "bytes": 276413,
      "sha256": "4547858fff38bbf15262d520685b184a3dce96897bc1844871f055b96e8f6e95"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/commons-lang3-3.3.2.jar",
      "bytes": 412739,
      "sha256": "6b81d10754dadf184d386011486e6509c2cc0c3d33565ced4fb4402b9413d47d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/commons-logging-1.2.jar",
      "bytes": 61829,
      "sha256": "daddea1ea0be0f56978ab3006b8ac92834afeefbd9b7e4e6316fca57df0fa636"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/compiler-bridge_2.13-1.8.0.jar",
      "bytes": 243207,
      "sha256": "2e483a3ea4dc3a4a29f1ccf6ee8326e4f403db122f16cb5426f5e5f11d99ff6e"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/compiler-interface-1.8.0.jar",
      "bytes": 112407,
      "sha256": "a7f1fec73e53a9796bcfd8d41c490d61dd70141604752e6e75b2e755f044fe8f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/concurrent-trees-2.6.1.jar",
      "bytes": 119854,
      "sha256": "04e3724984e2a5cbf55606cfa372a5bd3d3c5d2a21533a7004e3cde539761fa5"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/config-1.4.1.jar",
      "bytes": 295197,
      "sha256": "4c0aa7e223c75c8840c41fc183d4cd3118140a1ee503e3e08ce66ed2794c948f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/durian-collect-1.2.0.jar",
      "bytes": 1212833,
      "sha256": "b194c0b88021cc116c21c1dc76f49c2c1fe175af5bcb74c8ba67b9dbbf9a48cc"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/durian-core-1.2.0.jar",
      "bytes": 343717,
      "sha256": "17ed0aacb3a3c16323332168bbdead8694f32800b2b47d69d4a4c49b114d5dae"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/durian-io-1.2.0.jar",
      "bytes": 186776,
      "sha256": "095fd1dc77888c073f0be39a018156ee526722798b09de9e285ef2135e16eac4"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/durian-swt.os-4.2.1.jar",
      "bytes": 13251,
      "sha256": "4075cef438707d669b8d468500289af99fe87cb3fa69b7f564d9cefa4c838b30"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/error_prone_annotations-2.21.1.jar",
      "bytes": 16830,
      "sha256": "d1f3c66aa91ac52549e00ae3b208ba4b9af7d72d68f230643553beb38e6118ac"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/failureaccess-1.0.1.jar",
      "bytes": 4617,
      "sha256": "a171ee4c734dd2da837e4b16be9df4661afab72a41adaf31eb84dfdaf936ca26"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/fansi_2.13-0.4.0.jar",
      "bytes": 65146,
      "sha256": "0eb11a2a905d608033ec1642b0a9f0d8444daa4ad465f684b50bdc7e7a41bf53"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-0.64.6.jar",
      "bytes": 446356,
      "sha256": "59952315c6f3365b37a72215cc721de9c6be4a4812730056e7ee0930b14a099c"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-all-0.64.6.jar",
      "bytes": 2171,
      "sha256": "3aad26a3130e7b5222c0be838eb364ae20a7401e8a7b71188c39b6a22dca7434"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-abbreviation-0.64.6.jar",
      "bytes": 26361,
      "sha256": "3333cb402db0628659b5c35c4a8914e9acebbda43319638a32e1dc8cfc2a1e6d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-admonition-0.64.6.jar",
      "bytes": 31613,
      "sha256": "4cf0ce44b704e9be414f8fbf8f7083db5ecd5d3f6b3622715a51c082e7af942f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-anchorlink-0.64.6.jar",
      "bytes": 12062,
      "sha256": "7fb47642bf8cb0a8a7ea7b6db408cc316b48fe1f5a97a6133472ba1450da4ea0"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-aside-0.64.6.jar",
      "bytes": 17668,
      "sha256": "72c0fa2cf25ef0d3efd0ca07b967093eaa41687aa820ae6e2437f0c6f7ecb800"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-attributes-0.64.6.jar",
      "bytes": 49661,
      "sha256": "e1e72e653731eabeee83e921bccdc9530d35e7e5638e74dfc727a78ecb64736f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-autolink-0.64.6.jar",
      "bytes": 9647,
      "sha256": "a814a58b6c26594b073223291ecbd0d719eb1f6e9baeafed5c1ef69fb23f76ae"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-definition-0.64.6.jar",
      "bytes": 31783,
      "sha256": "defb936a49a185b2c106f3e1b00a7dee0d6333dfa7048bb4d29edbf4bfa60ab6"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-emoji-0.64.6.jar",
      "bytes": 72143,
      "sha256": "ef6f3e843202a9938fbdbd44f4a981e71fa9dca00a4d0a1ccfdcd5d858c217fa"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-enumerated-reference-0.64.6.jar",
      "bytes": 49144,
      "sha256": "de6a5057468b55c817cadbd2ed0adfcb44e0f2383cb60726e6b55e2271f47537"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-escaped-character-0.64.6.jar",
      "bytes": 11904,
      "sha256": "978d098f5d34f10ce50bbbbe3d2657dc509619c1a1cd2740bc31c52964c12d39"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-footnotes-0.64.6.jar",
      "bytes": 30516,
      "sha256": "04f421b30cbe48b143dc0f26239fdcee7e0e4a8f7ee3a5e998264fe65b5decd1"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-gfm-issues-0.64.6.jar",
      "bytes": 14400,
      "sha256": "d5e5f9bb0bba16d1cec6d5ea3c3a4e19c0a27aacbd46d76cedac6aa85a010cf6"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-gfm-strikethrough-0.64.6.jar",
      "bytes": 23263,
      "sha256": "0441a29727d355b99b12b2b003482d40e0d8e33a547c3d7dd2457a18fe0c7857"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-gfm-tasklist-0.64.6.jar",
      "bytes": 22741,
      "sha256": "8a5059f728e2382081604fe6304cd072362e5d899588c22d111f6ae695ef12a6"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-gfm-users-0.64.6.jar",
      "bytes": 14626,
      "sha256": "7976ff0e740032358b71e52b5004531a5bd400db1529dc72c37f64191789858a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-gitlab-0.64.6.jar",
      "bytes": 31839,
      "sha256": "f44c944a4c77377918506d1346879e6557099b815e128e1130aaa1a2eb7d7b6a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-ins-0.64.6.jar",
      "bytes": 11571,
      "sha256": "e0e9d2dd4000b30757b324cd15bcdb1b2c9648a801026f25386da5a62811fb84"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-jekyll-front-matter-0.64.6.jar",
      "bytes": 15428,
      "sha256": "b70dd5b10feb8039f42481a8be8b1f054f94253ee9accfff6f8d3717a752c347"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-jekyll-tag-0.64.6.jar",
      "bytes": 27736,
      "sha256": "29edc1b4b7c862b903b25115a67971e068c62fcca6eb5b1e0b993551834cbeed"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-macros-0.64.6.jar",
      "bytes": 28409,
      "sha256": "2510e13c542effd4e8e2c9fab9cd37b2ed4e518c6409d1eff7b807d4dfd49f98"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-media-tags-0.64.6.jar",
      "bytes": 19988,
      "sha256": "8656bec1d7560e7c11d2f9ab2b451624f16b5f9a420bc433d0b1e07041f163c2"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-resizable-image-0.64.6.jar",
      "bytes": 11155,
      "sha256": "7e7ac5785b9cd76908416633fe91f33495876128afe660b0e037be03cad9ef66"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-superscript-0.64.6.jar",
      "bytes": 12043,
      "sha256": "a0605ff1389fdedf9af0aafc373077d738753af5004f37a6d3b51824cd8de517"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-tables-0.64.6.jar",
      "bytes": 47409,
      "sha256": "ea550a31e06c3412717501cbcae973591ea1140cc2cf7e43052952c732d759de"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-toc-0.64.6.jar",
      "bytes": 84145,
      "sha256": "872c839c9f9aaa65f3532314dac952cb5b78590a4fb2580ff5433bb30151bf58"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-typographic-0.64.6.jar",
      "bytes": 20270,
      "sha256": "fa491351f27cb7e7d10327f067d9f6f94d08281b6f91f2c2e6f7a4d24f585caf"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-wikilink-0.64.6.jar",
      "bytes": 29955,
      "sha256": "3a2cf7e983b470d0c4a6029b46a3cbd33444f2ac7617da5b07638041e63fa9c9"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-xwiki-macros-0.64.6.jar",
      "bytes": 26569,
      "sha256": "7656966dbb9d28e37b0d0297397135c076241a764e8b6f3f191abf1048c34231"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-yaml-front-matter-0.64.6.jar",
      "bytes": 16150,
      "sha256": "5bc227cace85cda4f870d54f7ae061c2b43b9c8eeab01db9d8968cf534febb0a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-youtube-embedded-0.64.6.jar",
      "bytes": 11631,
      "sha256": "4a92dfeefa1dae49c8f9034bb01a3d799b36cfaa88871280456724d54fe35d3f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-html2md-converter-0.64.6.jar",
      "bytes": 81309,
      "sha256": "f39391369856b4f184b3b6ab4f2edd41344e6c3d73f9ccbcbee566759021acbe"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-jira-converter-0.64.6.jar",
      "bytes": 12095,
      "sha256": "7a5d676e618684a2e828b3c702270b07f2bbbe921f41e72f166562afb739a3ed"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-pdf-converter-0.64.6.jar",
      "bytes": 6399,
      "sha256": "5109fd035d871b36f6adb5119176381d90799da042ba9f76069f4a106aca4519"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-profile-pegdown-0.64.6.jar",
      "bytes": 6323,
      "sha256": "c52e7888eac47780cb7efccf39d31c000adbb93238816d96bf7c9205fdde858f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-0.64.6.jar",
      "bytes": 1829,
      "sha256": "9f7f593994634b3089b98abaf2fc79d40229291a53dc70fe31a804eaaf8a1c60"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-ast-0.64.6.jar",
      "bytes": 65820,
      "sha256": "8de31baa91056fc53d1e5ad4f4250d8bc69e3d9a7b865eece65ec44cb6db595d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-builder-0.64.6.jar",
      "bytes": 5179,
      "sha256": "fa9bc46a13d9a91878f215eceab2a3de2b4e6b75be66bc9a041e4a701c40b3c3"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-collection-0.64.6.jar",
      "bytes": 66711,
      "sha256": "2c57f72daf777e2029c38e4617642742ae03cdfd99d5de6e8f0a466cb7f62d7e"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-data-0.64.6.jar",
      "bytes": 25102,
      "sha256": "8b5b2a75772eb916b676f44715ce915451e1dca609de246bc030eb9fd0cca7e9"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-dependency-0.64.6.jar",
      "bytes": 16350,
      "sha256": "3f80172b2e58a07ba5d6167147d43f79663a42f381074231ded59759d1e26284"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-format-0.64.6.jar",
      "bytes": 109830,
      "sha256": "82c32ec7e2fe19c943175da22aab5d05de2d4ee1ede68c6e19729b3dacece126"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-html-0.64.6.jar",
      "bytes": 44429,
      "sha256": "46fa16af14934bd6973db5ffe7923f056bfec0c0b4d459194db6900c08631fa6"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-misc-0.64.6.jar",
      "bytes": 59478,
      "sha256": "406422641dfa7074181ba2a7d59d057a7f5c462a3904fb623ca541f596f387af"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-options-0.64.6.jar",
      "bytes": 11779,
      "sha256": "f4c1592be07f0d500b10e68543c3767f54149dae4efd639e874ec33d3603f8c9"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-sequence-0.64.6.jar",
      "bytes": 236743,
      "sha256": "8eff1485bdf83c370ea85dfffc3070be97b93580141ab15e61d116e58de2e1f7"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-visitor-0.64.6.jar",
      "bytes": 6663,
      "sha256": "0852be987d45bcddb3fde735a75de2ace0863398dcca822a3658a7553f1b846f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-youtrack-converter-0.64.6.jar",
      "bytes": 12683,
      "sha256": "ca47b7412779c0caf550f4b72d571d80afeb842e47159cb8427df1d0c65e23af"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/fontbox-2.0.24.jar",
      "bytes": 1564111,
      "sha256": "2e8c0a569a90b04734fbc0c805d77f4ec03f98c11f5705055ccd7718c1953d68"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/google-java-format-1.28.0.jar",
      "bytes": 280969,
      "sha256": "41dfe4d1012794ed15e0ffd70f89fd4fa65d5f15ce0bc0c70f8c2c127d6d010d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/graphics2d-0.32.jar",
      "bytes": 73911,
      "sha256": "37f8f387395f96c214ac44f7475c7a2e1f832dfc1de289a3610e0ffbf728f679"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/gson-2.9.1.jar",
      "bytes": 265030,
      "sha256": "378534e339e6e6d50b1736fb3abb76f1c15d1be3f4c13cec6d536412e23da603"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/guava-32.1.3-jre.jar",
      "bytes": 3043932,
      "sha256": "6d4e2b5a118aab62e6e5e29d185a0224eed82c85c40ac3d33cf04a270c3b3744"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/guice-4.0-no_aop.jar",
      "bytes": 423560,
      "sha256": "19393891be59b6feaf7e308bd8a3843b4e552c10cdb687ebffd7695634a250a8"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/guice-assistedinject-4.0.jar",
      "bytes": 43425,
      "sha256": "ed44e4d809e6b3bc41ccd6e8b5acf43fb517234f4ac4c1125d7a82c44826f147"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/guice-grapher-4.0.jar",
      "bytes": 53973,
      "sha256": "83bcdc6a0c9458ebe7c4e294561ebf49f1ea46bde4462a5e353e874745e50851"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/guice-multibindings-4.0.jar",
      "bytes": 81388,
      "sha256": "79d1d122ce059ed2c55d5acfd77eb31e3891f6a4aa997257ec0e7aec3d10f078"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/guice-throwingproviders-4.0.jar",
      "bytes": 33251,
      "sha256": "749e58cbee46d3ab5e46f82bfd12f9fd606c835f490063a247ed7b1f693a7099"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/haskell-backend-1.0-SNAPSHOT.jar",
      "bytes": 25391,
      "sha256": "697f6b4558b0efc520ef605b2fe4280f7ced7b3a4d9c78098af44df88bea240d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/hawtjni-runtime-1.18.jar",
      "bytes": 23287,
      "sha256": "136d57b533518a6bd37784af6bac3b79309808d595f17af4e18e7863f73c29a9"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/icu4j-72.1.jar",
      "bytes": 14386028,
      "sha256": "3df572b240a68d13b5cd778ad2393e885d26411434cd8f098ac5987ea2e64ce3"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/j2objc-annotations-2.8.jar",
      "bytes": 9301,
      "sha256": "f02a95fa1a5e95edb3ed859fd0fb7df709d121a35290eff8b74dce2ab7f4d6ed"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/jansi-2.4.0.jar",
      "bytes": 221009,
      "sha256": "6cd91991323dd7b2fb28ca93d7ac12af5a86a2f53279e2b35827b30313fd0b9f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/java-diff-utils-4.12.jar",
      "bytes": 72305,
      "sha256": "9990a2039778f6b4cc94790141c2868864eacee0620c6c459451121a901cd5b5"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/javax.inject-1.jar",
      "bytes": 2497,
      "sha256": "91c77044a50c481636c32d916fd89c9118a72195390452c81065080f957de7ff"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/javax.json-1.0.4.jar",
      "bytes": 85147,
      "sha256": "0e1dec40a1ede965941251eda968aeee052cc4f50378bc316cc48e8159bdbeb4"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/jcommander-1.78.jar",
      "bytes": 83782,
      "sha256": "7891debb84b5f83e9bd57593ebece3399abbe0fd938cf306b3534c57913b9615"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/jline-3.21.0.jar",
      "bytes": 994664,
      "sha256": "1e7d63a2bd1c26354ca1987e55469ea4327c4a3845c10d7a7790ca9729c49c02"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/jna-5.13.0.jar",
      "bytes": 1879325,
      "sha256": "66d4f819a062a51a1d5627bffc23fac55d1677f0e0a1feba144aabdd670a64bb"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/jsoup-1.15.4.jar",
      "bytes": 440209,
      "sha256": "006830d0797710408de5589c18d864343c0ef1a3a0c603c9cb138c943b67d9a4"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/jsr305-3.0.0.jar",
      "bytes": 33031,
      "sha256": "bec0b24dcb23f9670172724826584802b80ae6cbdaba03bdebdef9327b962f6a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/jung-api-2.1.1.jar",
      "bytes": 42221,
      "sha256": "6cb735963c36d5155d0de5f19a03485b9a26e67550e160b3dd89009a6f51694e"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/jung-graph-impl-2.1.1.jar",
      "bytes": 66031,
      "sha256": "4911da04d77b4f7bb465a65ae3cc3a000cae4d52b587911e3c0b4c4b643493c1"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/k-frontend-1.0-SNAPSHOT.jar",
      "bytes": 1729665,
      "sha256": "6505360d7b472d9802d857452f29722d09424985bb224585c68c37741b65d30a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/kotlin-stdlib-1.6.20.jar",
      "bytes": 1509405,
      "sha256": "eeb51c2b67b26233fd81d0bc4f8044ec849718890905763ceffd84a31e2cb799"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/kotlin-stdlib-common-1.6.20.jar",
      "bytes": 200631,
      "sha256": "8da40a2520d30dcb1012176fe93d24e82d08a3e346c37e0343b0fb6f64f6be01"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/kotlin-stdlib-jdk7-1.6.20.jar",
      "bytes": 23898,
      "sha256": "aa2fa2e81355c4d98dd97da2169bf401f842261378f5b1cbea1aa11855d67620"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/kotlin-stdlib-jdk8-1.6.20.jar",
      "bytes": 17773,
      "sha256": "fdab1bf120e2b5e7ab6d7888e9ebc024ec6b8ca729361296395dab634b213695"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/listenablefuture-9999.0-empty-to-avoid-conflict-with-guava.jar",
      "bytes": 2199,
      "sha256": "b372a037d4230aa57fbeffdef30fd6123f9c0c2db85d0aced00c91b974f33f99"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/llvm-backend-1.0-SNAPSHOT.jar",
      "bytes": 14951,
      "sha256": "c3451f3e3acd1bfc0f42ba6b6ddbbfd5e5490edc596daff607eb72f87d01a88a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/llvm-backend-matching-1.0-SNAPSHOT.jar",
      "bytes": 623366,
      "sha256": "1dcad59f81086c049f6080fd0c873c66ba32c01da7113e04adc7709d6c805ad2"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/mdoc-parser_2.13-2.5.0.jar",
      "bytes": 32831,
      "sha256": "aa15d2d203f72614dc7d804e90065778403420fe0b7dc3e9ad3172b309331e32"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/metaconfig-core_2.13-0.12.0.jar",
      "bytes": 527448,
      "sha256": "2c91199ae5b206afdd52538f8c4da67c1794bcce0b5b06cf25679db00cf32c19"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/metaconfig-pprint_2.13-0.12.0.jar",
      "bytes": 33848,
      "sha256": "6d8b0b4279116c11d4f29443bd2a9411bedb3d86ccaf964599a9420f530ed062"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/metaconfig-typesafe-config_2.13-0.12.0.jar",
      "bytes": 17265,
      "sha256": "b4c5dbf863dadde363d8bd24333ce1091fec94fc5b88efd04607a26f3eab61b8"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/mpfr_java-1.4-linux64.jar",
      "bytes": 540038,
      "sha256": "45ebb07edcfc74cfb560a41ab67309903543b49fcaf2aa8beda1e7abf954da11"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/mpfr_java-1.4-osx.jar",
      "bytes": 570258,
      "sha256": "ed582e3f6a97c6971de4f74acc71bbd9141af3f16da611837d938f5d8a54167d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/mpfr_java-1.4.jar",
      "bytes": 46717,
      "sha256": "2e04f00638e04286c854f9c4799784d5542906f1c756954c0ad0701073ead19e"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/nailgun-server-1.0.0-SNAPSHOT.jar",
      "bytes": 52797,
      "sha256": "2dc5e947a069de0f613f00a6492d2345cd392d9ccebd8a323327716dec264930"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/okhttp-4.11.0.jar",
      "bytes": 786969,
      "sha256": "ee8f6bd6cd1257013d748330f4ca147638a9fbcb52fb388d5ac93cf53408745d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/okio-3.2.0.jar",
      "bytes": 25503,
      "sha256": "dca932cb2029b6c9e26770f87db08b14d481ffe8131a59f369a2385c11be4e2d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/okio-jvm-3.2.0.jar",
      "bytes": 345115,
      "sha256": "b642baef4c570055de4cb3d1667b2b16dced901ff8066345a063691aa06025a4"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/openhtmltopdf-core-1.0.10.jar",
      "bytes": 1030009,
      "sha256": "3e6fd2250d833d500b7cd48b7a896700d0c33bd9f77a219e820493b01566eda3"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/openhtmltopdf-pdfbox-1.0.10.jar",
      "bytes": 259478,
      "sha256": "7de90df1b3ecf84e6f0daf808d724c11142007a2f22bff1936479bf17251d31a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/openhtmltopdf-rtl-support-1.0.10.jar",
      "bytes": 24956,
      "sha256": "5675c0b56d613b15446f9d0922d89781af48f05331326a87bdb3d1775c703215"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/org.eclipse.jgit-6.7.0.202309050840-r.jar",
      "bytes": 3139434,
      "sha256": "b564477d092241aaab50c84ac5dd1ac375c0182044d7e5659d3a60a90e2e801a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/org.eclipse.lsp4j-0.19.0.jar",
      "bytes": 1142037,
      "sha256": "d432390fd296f862f8813d6a8f0559bde3a5e4a54e123b7ab970f0b05ce2f128"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/org.eclipse.lsp4j.generator-0.19.0.jar",
      "bytes": 54035,
      "sha256": "6b3758e4f6eecbf48bfcb6e9c4f860bd1455c5c3852cd807460b6b2623d9b634"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/org.eclipse.lsp4j.jsonrpc-0.19.0.jar",
      "bytes": 137423,
      "sha256": "a3361392fbfb934a6c09e5ff3db48cdff065d7ba93deea57dedaedeb996633d2"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/org.eclipse.osgi-3.18.300.jar",
      "bytes": 1539745,
      "sha256": "bab943e58edd17309238672dba7a45aec9e2dacbdddb818a8cf17723ea13fa22"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/org.eclipse.xtend.lib-2.28.0.jar",
      "bytes": 112545,
      "sha256": "e18b609a3f99ece787443efd231504232f4b6179e9cc1c7b0905361dd31c8fdf"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/org.eclipse.xtend.lib.macro-2.28.0.jar",
      "bytes": 79739,
      "sha256": "623a312c0bd6341fecbb72eba6c011f326561d451426fb957a4b18ba076c17c6"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/org.eclipse.xtext.xbase.lib-2.28.0.jar",
      "bytes": 166255,
      "sha256": "2e81c2ad0b4e48b0b1ba2e5873a06bb877dfbbcb0651c1ed0988ee15c6ebbdfe"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/paiges-core_2.13-0.4.3.jar",
      "bytes": 119538,
      "sha256": "4daa8b180b466634b66be040e1097c107981c0ba0b7c605e2f7c0b66ae1b99b5"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/parsers_2.13-4.8.14.jar",
      "bytes": 867250,
      "sha256": "47030b6edede54f7aa480ba12155677a6c553de74d34265792bca02ea813256b"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/pcollections-2.1.2.jar",
      "bytes": 39146,
      "sha256": "29c8ffcc5c6a97f059941148593ad00fe2cdf78af1d88d46bcf0d1bb703606c2"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/pdfbox-2.0.24.jar",
      "bytes": 2745079,
      "sha256": "3c2c0553ec0e7533c490b4c952e1af113621de5275af6e380e11d0d9a0a4f3d6"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/plexus-build-api-0.0.7.jar",
      "bytes": 8482,
      "sha256": "934171640fbd3d2495c50b79b0d9adb11e2c83e65bad157df8fe34bcac0ff798"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/plexus-resources-1.2.0.jar",
      "bytes": 22918,
      "sha256": "898fc46841ce7defce320b78b748e285cc4790f9db931045d1f4b139a35f065d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/plexus-utils-3.4.1.jar",
      "bytes": 263876,
      "sha256": "52d85e04b3918722af11d12855b4a8257df96a0e76c8f4e3852e6faa851f357b"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scala-collection-compat_2.13-2.11.0.jar",
      "bytes": 7090,
      "sha256": "0c1108883b7b97851750e8932f9584346ccb23f1260c197f97295ac2e6c56cec"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scala-compiler-2.13.12.jar",
      "bytes": 12200301,
      "sha256": "583adb1ffa7b29fdbfdd6f4c97a396af06a8a91625d059823bba1b7172242d6a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scala-kore-0.3.3.jar",
      "bytes": 263871,
      "sha256": "c30416a73d357749c950f6db06eab51995dd46bf875b874f0daae01e57d97447"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scala-library-2.13.13.jar",
      "bytes": 5922756,
      "sha256": "b58b223f9b59f88d04c9dc9ec26f4b463e93e6f296de5663dbd710a7dfce2743"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scala-parallel-collections_2.13-1.0.4.jar",
      "bytes": 1127123,
      "sha256": "68f266c4fa37cb20a76e905ad940e241190ce288b7e4a9877f1dd1261cd1a9a7"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scala-reflect-2.13.13.jar",
      "bytes": 3788215,
      "sha256": "8e7fa6fd2f9682035bfeae45160afa38ca67aec7dfc614146a758efdeb2ffafc"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scalafmt-config_2.13-3.7.17.jar",
      "bytes": 9396,
      "sha256": "cfa4bed5a3944ffd435f583d27b2fdd05dd194066523234d9b11a26c1189f1a4"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scalafmt-core_2.13-3.7.17.jar",
      "bytes": 2065804,
      "sha256": "7cb60b9f89579e87f52504760752abb77fa82be5d7a97b5d81e79e744a54e08c"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scalafmt-sysops_2.13-3.7.17.jar",
      "bytes": 49816,
      "sha256": "e3b382902ba5ffd86f43ebafe1a01eef868bc61e52d5f53898086db19773cc3f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scalameta_2.13-4.8.14.jar",
      "bytes": 810656,
      "sha256": "d6cd45cfd609064969922ee8e33863842347533f9a8daf6b059a54c29226dac2"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scalap-2.13.12.jar",
      "bytes": 527354,
      "sha256": "ba4152ca85f42f04d76d903e006f9848f4e7d0629791d016953f05a5a04954c8"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/slf4j-api-1.7.32.jar",
      "bytes": 41513,
      "sha256": "3624f8474c1af46d75f98bc097d7864a323c81b3808aa43689a6e1c601c027be"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/snakeyaml-2.0.jar",
      "bytes": 334803,
      "sha256": "880c9d896e4b74a06c549c15ca496450165d6909fa15d7e662bee8f6a66d7afa"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/solstice-1.7.4.jar",
      "bytes": 410589,
      "sha256": "1288c1010299cb8434218e370f2291f2d6ea49b3ccb34b5082080f7c270a254c"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/sourcecode_2.13-0.3.0.jar",
      "bytes": 119136,
      "sha256": "6e5b2d55e942b450a222bfd3ebc23e99ca03716e42da25af1b2c8cde038100f5"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/spotless-lib-2.43.1.jar",
      "bytes": 471112,
      "sha256": "a8fb74a173700ed3ce4d87a2b2a8125e7fb68bd2b95c99e2da5112ccbd53cd31"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/spotless-lib-extra-2.43.1.jar",
      "bytes": 79022,
      "sha256": "94f5c1a68630bbb16343522157b414f3f7558307479bbf658df886e3b8dc81c4"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/spotless-maven-plugin-2.41.1.jar",
      "bytes": 124396,
      "sha256": "25bba0363ba305daf50fc31d8241655241723e218b424b1f4c255ff0b6331612"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/trees_2.13-4.8.14.jar",
      "bytes": 6740138,
      "sha256": "798493812b8d2a61381de0645f1630cc47eba6a20bbfeb713c636f6b9609d714"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/util-interface-1.8.0.jar",
      "bytes": 3345,
      "sha256": "5760f47ecbdf1cd61db2c1b433a711ede09b3cabc30626c4ba36fe463b323a26"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/xmpbox-2.0.24.jar",
      "bytes": 132350,
      "sha256": "27383df2285b9e228c39f2c755adeebbef774793d33c4f20f0dc99e9ebaaf673"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/xz-1.9.jar",
      "bytes": 116013,
      "sha256": "211b306cfc44f8f96df3a0a3ddaf75ba8c5289eed77d60d72f889bb855f535e5"
    }
  ],
  "immutable_tool_roots_and_transitive_dependency_basis": "Existing registered F03 approved tool roots/importreadset; entry+classpath pins are not a new full system-library proof.",
  "registered_original_import_manifest": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/READ-IMPORT-PINS.json",
    "bytes": 1274580,
    "sha256": "2427379d20bb32c0c9a5d9f77b49c5bac39d1bd67fa39b7664c96cc85c2a6289"
  }
}

===== END BODY 24 =====

===== COMPLETE BODY 25 Existing full K/JAR/tool dependency pin manifest =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/compile-only/EXISTING-K-TOOL-CLOSURE-PINS.json
BYTES: 73807 SHA256: b88dfeb16de28599e485fa1cc7fd4a7ec9987fa16daa712e0256067acde6418a
{
  "registered_original_import_manifest": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/251-f03-paired-model-operation-proposal/READ-IMPORT-PINS.json",
    "bytes": 1274580,
    "sha256": "2427379d20bb32c0c9a5d9f77b49c5bac39d1bd67fa39b7664c96cc85c2a6289"
  },
  "original_inventory_source": {
    "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-parallel-20261016/k-actual-01/ENGINE-PREFLIGHT-01.stdout",
    "bytes": 215119,
    "sha256": "603a50490426908e138844fc5037c2a547d049ac1ea7778d7389903a0f0d9bcb"
  },
  "files": [
    {
      "path": "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/kore-exec",
      "bytes": 395,
      "sha256": "f73768989745e8d108d80906c158fe406942173b104ad2e81b8e8349da6d504d"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/bin/cpp",
      "bytes": 10094,
      "sha256": "d89b009350d3d8c55e79a5e1f4b34976455269a637551907a494b04b645ca2bc"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/bin/g++",
      "bytes": 10094,
      "sha256": "7c8ce58cb3c0ebb71a0afad6155a5958f0bf0d1eba84ab2a67bcb3f2dee961a3"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/bin/gcc",
      "bytes": 10094,
      "sha256": "af59edee4fe892f231beaece0f6c83631e4fecfcda74d7539bc79899580ac5ee"
    },
    {
      "path": "/nix/store/bgcaxhhxswzvmxjbbgvvaximm5hwghz1-binutils-2.41/bin/as",
      "bytes": 779536,
      "sha256": "99d53495e50622f8eb89a8a7d3c3466f72e65ba8cd40e48c23507a58a975e4d1"
    },
    {
      "path": "/nix/store/kln7kinji3b7sz8r50h4gn9yy6k1js9a-binutils-wrapper-2.41/bin/ld",
      "bytes": 10093,
      "sha256": "0b1bbaa024ca31f4fbe62ba932635f6cc098ba8772f6ea09e55efb5170d23a14"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/nix-support/add-flags.sh",
      "bytes": 4595,
      "sha256": "d6dfaf714b5f511d23367c8a3accf0f6ea67a4c4d816fc94fa8a7809bf18f13c"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/nix-support/add-hardening.sh",
      "bytes": 4883,
      "sha256": "341eb748035a8626cc235b4f1d9b4bb81995933ac1847b6dfbf248bf08a5cf17"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/nix-support/cc-cflags",
      "bytes": 66,
      "sha256": "24d6f15ccedf58f10fc7aead04135fab851e98e4962305ac44245ac40ff7c52d"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/nix-support/cc-ldflags",
      "bytes": 228,
      "sha256": "0ecc21317d972c92c01e05d1c91602eb2cf09712002f80e734a09ad004e59394"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/nix-support/libc-cflags",
      "bytes": 201,
      "sha256": "b8e589f53230a4b51ae773d05d20fff8df9226c0910e91e87e4647285d5cab19"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/nix-support/libc-crt1-cflags",
      "bytes": 65,
      "sha256": "6cdf11e2750ef1f50d7e922fa2cdbddfb55fffb610d3dc7b977ea630a4221438"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/nix-support/libc-ldflags",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/nix-support/libcxx-cxxflags",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/nix-support/libcxx-ldflags",
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/nix-support/orig-cc",
      "bytes": 55,
      "sha256": "8fa3639c4c02ebdad6a9ab6c2bc753635eff8d2c5fab098fa3c64bf121112525"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/nix-support/orig-libc",
      "bytes": 58,
      "sha256": "947c393d18d7806380d66983bdf2f78a498427b14266d6953105cb633aaed04a"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/nix-support/orig-libc-dev",
      "bytes": 62,
      "sha256": "3b1b028a67a01b60c898ec7618565c63bd43d1d24961f8aabad5957a4be09654"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/nix-support/propagated-build-inputs",
      "bytes": 66,
      "sha256": "94bfe554dbec8717d19190354638aee72e7f8c78014df536f343bdb9cc459d5c"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/nix-support/setup-hook",
      "bytes": 7288,
      "sha256": "e48751cca3561b4d1f57e28b1476362d664ff81071abad5511e88aec6e49022e"
    },
    {
      "path": "/nix/store/9bv7dcvmfcjnmg5mnqwqlq2wxfn8d7yi-gcc-wrapper-13.2.0/nix-support/utils.bash",
      "bytes": 5111,
      "sha256": "81f87cbd25843b0c856e79a4106f9ac69d096024792f83d8acf4ec759814e591"
    },
    {
      "path": "/nix/store/fwh4fxd747m0py3ib3s5abamia9nrf90-glibc-2.39-52-dev/include/fcntl.h",
      "bytes": 11442,
      "sha256": "0a8ec5ef69559544b9da26b7d5ebee07f4ee43baa3cc9e9f35f8a33d4f157676"
    },
    {
      "path": "/nix/store/fwh4fxd747m0py3ib3s5abamia9nrf90-glibc-2.39-52-dev/include/stdio.h",
      "bytes": 34649,
      "sha256": "b4f6709d12c8493e2a42f740845abe2994deb27fc78fb85fcaa6e27228a87d62"
    },
    {
      "path": "/nix/store/ih51sgk8g57fnkbd5r82ddi8k5vln8cl-z3-4.13.4/bin/z3",
      "bytes": 33796736,
      "sha256": "2a5132e5f73510ab0ebb61fa8996bfa303f5473a85add71eedbd9c6819ff43ef"
    },
    {
      "path": "/nix/store/k7zgvzp2r31zkg9xqgjim7mbknryv6bs-glibc-2.39-52/lib/crt1.o",
      "bytes": 1960,
      "sha256": "20453b401ee6a1ab8e5de964e508be2f2a9bc1c343e2546629b8dc63e012e308"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/release",
      "bytes": 111,
      "sha256": "f0a069a278b500415b5c4787a0f6dc6235614c91908170ede30b669837c02cb5"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/bin/java",
      "bytes": 14440,
      "sha256": "2a065ca5589bc80168f45166653c6e58d97ce63bbd7407c85eb5fed6622a5740"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/bin/keytool",
      "bytes": 14464,
      "sha256": "3bc2f43deac6149ed2752f47c6d5b7ac24be25099626efd1ab04e3851c1ae8dc"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/bin/rmiregistry",
      "bytes": 14488,
      "sha256": "8cc141e7247fadafdc057997db52f59a46c18ac9ab7915d9f775f4a7710d7bec"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/conf/jaxp.properties",
      "bytes": 7302,
      "sha256": "7d95c49465d0c836d608d02856d3b097934dfb5dc4bd2279affaf337d045b708"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/conf/logging.properties",
      "bytes": 2732,
      "sha256": "b62d2733ab99556b108a1951d894c5a8d76b1ac7a00c02c388f9eb9be046c56f"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/conf/net.properties",
      "bytes": 6608,
      "sha256": "a88eeb56c61c0df79c8d000a43de10dba48c77130c8ada1af942c9a8ce29a787"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/conf/sound.properties",
      "bytes": 1210,
      "sha256": "299c2360b6155eb28990ec49cd21753f97e43442fe8fab03e04f3e213df43a66"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/conf/sdp/sdp.conf.template",
      "bytes": 1455,
      "sha256": "e9441e51f0d29e25313d33a9005640f11ad93c27f01bc46a34bf02f2a98ffd6b"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/conf/security/java.policy",
      "bytes": 2294,
      "sha256": "d51bcab7ed301caeff3779a5e777e6019864cecee5e2abc102ef991b0de77af2"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/conf/security/java.security",
      "bytes": 64249,
      "sha256": "78f06ea1ce6fe10c188c99f6e4ca5631060e6e1b193ae598c0dfc6f3c3b6ac75"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/conf/security/policy/README.txt",
      "bytes": 2390,
      "sha256": "6da0747334b0fea7592fd92614b2bbc8b126535e129b1fee483774d914e98eb5"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/conf/security/policy/limited/default_US_export.policy",
      "bytes": 146,
      "sha256": "758b930a526fc670ab7537f8c26321527050a31f5f42149a2dda623c56a0a1a9"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/conf/security/policy/limited/default_local.policy",
      "bytes": 647,
      "sha256": "2b2627548e61316150d47ffc3e6cad465ca05b3cccd4785eb7d21aa7baa0f441"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/conf/security/policy/limited/exempt_local.policy",
      "bytes": 566,
      "sha256": "8c3d7648abcd95a272ce12db870082937f4d7f6878d730d83cb7fbb31eb8b2c9"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/conf/security/policy/unlimited/default_US_export.policy",
      "bytes": 146,
      "sha256": "758b930a526fc670ab7537f8c26321527050a31f5f42149a2dda623c56a0a1a9"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/conf/security/policy/unlimited/default_local.policy",
      "bytes": 193,
      "sha256": "8d8a318e6d90dfd7e26612d2b6385aa704f686ca6134c551f8928418d92b851a"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/include/classfile_constants.h",
      "bytes": 22155,
      "sha256": "7056263197c68eb8493f53d88020aa550985e64816afd776e509d6bf8cf0b4a0"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/include/jawt.h",
      "bytes": 12458,
      "sha256": "85101d07928a589accfef9d7c261850faa8d5afc8ef262af7ec9734008f6f2f5"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/include/jni.h",
      "bytes": 76018,
      "sha256": "99e64ebbe749e6df284f852f11b3c73f6ea97baf15120428f40f887fe0616e61"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/include/jvmti.h",
      "bytes": 83067,
      "sha256": "78dcca2689f42937c3b5e54eaf7ed2e4674cd808d1d6fd5fbd10f83829e577e8"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/include/jvmticmlr.h",
      "bytes": 4771,
      "sha256": "6ee3e52d24bdb4f4d0312dfbab3d47bd524cbdac5540a4d790cac0620c59b3c8"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/include/linux/jawt_md.h",
      "bytes": 1965,
      "sha256": "656d0a92cd0774facb79662a261ec96043f284e145ce4f8fde1e08e8e28775d2"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/include/linux/jni_md.h",
      "bytes": 2208,
      "sha256": "88cb5c33e306900dd35a78d5a439087123b8e91b0986bb5acb42cc9bd2fcc42e"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.base/ADDITIONAL_LICENSE_INFO",
      "bytes": 2114,
      "sha256": "a69bce275ba7a3570af6579cb0f55682cd75fedfcd49e0e8e9022270c447c916"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.base/ASSEMBLY_EXCEPTION",
      "bytes": 1514,
      "sha256": "75292f03bf23d3db7c985aecc191029b93883200721ed23ed34a2e601463df33"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.base/LICENSE",
      "bytes": 19274,
      "sha256": "4b9abebc4338048a7c2dc184e9f800deb349366bdf28eb23c2677a77b4c87726"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.base/aes.md",
      "bytes": 1444,
      "sha256": "45c6d4da48325edfbff3dcf71c704e504c057904435ed23c6d57046d551eb69d"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.base/asm.md",
      "bytes": 1582,
      "sha256": "683be15695bd248272d60f5b7fbe5e126a935ea6bf231a624a9aa164733e1d1d"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.base/c-libutl.md",
      "bytes": 1556,
      "sha256": "bef40679922d6fdfb7e4ddb223ad6722300f6054ba737bbf6188d60fcec517f9"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.base/cldr.md",
      "bytes": 9601,
      "sha256": "19515e14a240e022640e95b61b5095127fa9690755950b4a2b0a02e783e08163"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.base/icu.md",
      "bytes": 30197,
      "sha256": "1bf28459c6e0af9f3429f4f8becd1668d6544055f8df240277456bc4b3d8a752"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.base/public_suffix.md",
      "bytes": 17783,
      "sha256": "e662969300048d914f80265eb516021ad2b0015c7e7eedd45c93655f11f256d7"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.base/unicode.md",
      "bytes": 9078,
      "sha256": "6f72f10d166b2c2e8a395e03e734c5afc852b59aeca73ced124f6b9c96268d53"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.desktop/colorimaging.md",
      "bytes": 167,
      "sha256": "04d61e3e8e71dd452ebe52008af5378d9f6640d14578aeb515dc5375973b0189"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.desktop/harfbuzz.md",
      "bytes": 3314,
      "sha256": "a73cc87c16567c41180d2045d7e0076d41e07ff5dc27aa95fbc3721af5bc73b8"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.desktop/mesa3d.md",
      "bytes": 5732,
      "sha256": "63f4e6f75caebbccb95d903fb43e46ac7111b3624d0a34f146b276d7d9e7b152"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.desktop/pipewire.md",
      "bytes": 1414,
      "sha256": "7c0494d35e85e5f33bb1a6b061a84b7b745904764c3b7bac7d7d8b817a6ca2d6"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.desktop/xwd.md",
      "bytes": 1348,
      "sha256": "1d4ffa93c87f35084b02a7aa90a21084b4019db4fe1003c2e5ce775b4a384f59"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.xml/bcel.md",
      "bytes": 11195,
      "sha256": "853a1e7ce397bb10de0e2b3bde0844bcc651f17d983decd07d2d003c0304c311"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.xml/dom.md",
      "bytes": 3761,
      "sha256": "6686e8877667584a3a7c07344baadca1a03e29f677162d87c3c0811e990d1148"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.xml/jcup.md",
      "bytes": 1448,
      "sha256": "8d5dcfdf50455a3c34c753a98f21e953248af200415a9084e3f102cb6c43b8bf"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.xml/xalan.md",
      "bytes": 13477,
      "sha256": "c27eb875da4be683d4d7422be986e5e30f636ede31958ff1d39f9cd6109e7a00"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/legal/java.xml/xerces.md",
      "bytes": 11848,
      "sha256": "4a6bf6b367193ee68681cb2d9fed30ffc5d62dd2d477bd62e0271707d71b3244"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/classlist",
      "bytes": 78876,
      "sha256": "0cd0cc7b1546e4a7a6eabf096b93fec6c80d351035f927e9994dc47f46fe1755"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/jexec",
      "bytes": 14440,
      "sha256": "4d93257cadbf06705b26df3ff01304abb7c2904ae79ef7e524b464cc8166f7a8"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/jrt-fs.jar",
      "bytes": 110119,
      "sha256": "0c268e7d1f8eec9f28393070e511cb372efa4a562d5423e6a4742e8331abbb5e"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/jspawnhelper",
      "bytes": 22704,
      "sha256": "b9421dbda0f572214d640ce3fc0bbbec85aefe028ed74337063c6433357afddc"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/jvm.cfg",
      "bytes": 29,
      "sha256": "aa9efb969444c1484e29adecab55a122458090616e766b2f1230ef05bc3867e0"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libawt.so",
      "bytes": 847744,
      "sha256": "b842f945cfa29edeb38745c862f4337e1fd754cdbbfa921cafa7dd902a7e952d"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libawt_headless.so",
      "bytes": 39000,
      "sha256": "821e2c608bfa89607d1c660c12590640f3a68ae117964f7ad4a34ef4caee526e"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libfontmanager.so",
      "bytes": 2106232,
      "sha256": "613037807b30f9692a8270c67429d2d5d7f414ed549de02fc67af91dc1628a3c"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libjava.so",
      "bytes": 145328,
      "sha256": "59336d6854177ae5fafedc348d42b57805b073eb5f27e73ae47e5873a9ed2a17"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libjavajpeg.so",
      "bytes": 47048,
      "sha256": "aff6ef0d78e33f17b09d80c8c19a94ed7dd280f485e5824775b76d8245929ca2"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libjawt.so",
      "bytes": 14136,
      "sha256": "11c93adb4bf764e2383e9eac1744423e4ebb81a0f2ecedb7bc6ff590a35b77b5"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libjimage.so",
      "bytes": 30856,
      "sha256": "9d54add943f3ffed55feb9aecc1c22283241083deff255f1a4c725cd639c5fd0"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libjli.so",
      "bytes": 71712,
      "sha256": "b21a8697a683b96bec0aa131bfb107a13d6fb84a284193179c1a890998387c8a"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libjsig.so",
      "bytes": 14280,
      "sha256": "20c35bf3f7b2d864acd4d50667547a727cfbbb4fc22f0c440789d51f4e81b147"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libjsound.so",
      "bytes": 67528,
      "sha256": "7bdb48773cee99984b45f2e7b53a36767e5a352d8206bf1b5080bb8492d5080e"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/liblcms.so",
      "bytes": 22472,
      "sha256": "ae9cb0a6f72f45dfed6a678a3be889bd91e2d15c3dc7896951903be5d2ad08ec"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libmlib_image.so",
      "bytes": 509976,
      "sha256": "1e7c8eb5ff4f082956f04e0693677cd5db0a7761b3cbe80d5e8e8165a3603538"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libnet.so",
      "bytes": 51144,
      "sha256": "a69c1f144b3414365f75f8a070f44060d20957a65d0a16ce9c1a0d1fe5b18520"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libnio.so",
      "bytes": 92112,
      "sha256": "1f8cae24451514bbf7d218061559d426bdfba37feba66aaa83a4f92773e82f80"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libprefs.so",
      "bytes": 14208,
      "sha256": "38028fa6563d15f7700c713beab2f080462bf87a7386c79fe1c046494db6f0e6"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/librmi.so",
      "bytes": 14208,
      "sha256": "6d32b762e7f3053062c3bbdf90964f051b9368506b803d7c467eeb4082041227"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libsyslookup.so",
      "bytes": 14208,
      "sha256": "b36b77abec6b7e0c5f6ac509faaa16b7eb6d1f6d2c3f220bde6a0d7ceabec1b2"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libverify.so",
      "bytes": 63512,
      "sha256": "f76587d85eb7a1382b4c9f039ed8aea3d74967ac6c580e6597b909c77d484a4e"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/libzip.so",
      "bytes": 38856,
      "sha256": "9b57e0f647869d351a119d9e150012a328d20fa231d68976759fb2d2a206a049"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/modules",
      "bytes": 65047555,
      "sha256": "f46016bb0c937aa7b05d9ccc9c8de3572a2ae7689bf189f41550facc31ee6243"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/psfont.properties.ja",
      "bytes": 3793,
      "sha256": "5a4bd51b969bf187ff86d94f4a71fdfbfa602762975fa3c73d264b4575f7c78f"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/psfontj2d.properties",
      "bytes": 11390,
      "sha256": "780c565d5af3ee6f68b887b75c041cdf46a0592f67012f12eeb691283e92630a"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/tzdb.dat",
      "bytes": 103785,
      "sha256": "b7dba25abdfee317daa042c89b01e5711f5781d020dd733ba411760b72addb93"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/security/blocked.certs",
      "bytes": 2488,
      "sha256": "96572f243f31c2ef81a6e627542e596f6a9295cff3c7ae095c1b595cb1457ded"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/security/cacerts",
      "bytes": 118125,
      "sha256": "88d674274258d3c740b2d724934b092d6cc1eb6a6d6aad3d72d0df8db759998e"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/security/default.policy",
      "bytes": 10657,
      "sha256": "2bd418aab30b091b136962f80be7ddf39dcba85f082a558a6993848ae65366ae"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/security/public_suffix_list.dat",
      "bytes": 229405,
      "sha256": "00ca9e095528e79cdcffcf6fec30c4c8c1fe45edf168e715cc89ab39b5c487b4"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/server/libjsig.so",
      "bytes": 14280,
      "sha256": "20c35bf3f7b2d864acd4d50667547a727cfbbb4fc22f0c440789d51f4e81b147"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/lib/server/libjvm.so",
      "bytes": 21621816,
      "sha256": "c0e8d7fff0018efb9f157593f0ce1bb646b30f3702e9149ed76bf13f6b56151c"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/share/man/man1/java.1.gz",
      "bytes": 48624,
      "sha256": "04d6e1ce6f14260f4b6c8c054eb9848732131794b538a878d2aefb380ce4d99d"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/share/man/man1/keytool.1.gz",
      "bytes": 26437,
      "sha256": "c3b24b4055d60ccb3432917c43bae043569d4d8d8ae5b629f37c215331604835"
    },
    {
      "path": "/nix/store/kjb3a2ip8ydb3zm604agim5ccjja3vfj-openjdk-headless-minimal-jre-21+35/share/man/man1/rmiregistry.1.gz",
      "bytes": 1582,
      "sha256": "93e2c5d7e488ee1132df5aa72f3c4afc9f14b18ba1295b7e99a452f8a800e3a4"
    },
    {
      "path": "/nix/store/n7z2j8ahz76wsy0357m38kzrl0qmp5bm-gnum4-1.4.19/bin/m4",
      "bytes": 305984,
      "sha256": "4c422b2324a4ab62874106fd1616897502b2e0d5c58f61fc0fa4df5595ba4496"
    },
    {
      "path": "/nix/store/p7hjh21dj4bc1s6kfcdwk45knp5n4cc0-llvm-backend-0.1.140/bin/kprint",
      "bytes": 2650880,
      "sha256": "5d7094f9c36d7967144dbb6c10168eb6ba402bb869ead438ae9e326c81e2c7ec"
    },
    {
      "path": "/nix/store/qb0m8rd0c3b90dfbz8fwlczd3kc3828z-kore-exec/bin/.kore-exec-wrapped",
      "bytes": 15356472,
      "sha256": "4ebe3cd5b32864352247b954c2d0fb90a7a5730e519a6c4516bb2b5a2c315429"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/bin-unwrapped/kast",
      "bytes": 114,
      "sha256": "49464094561435eb94f883dc23442b128e6e2b5ac1bf2b85d88cd514a1d429e5"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/bin-unwrapped/kompile",
      "bytes": 117,
      "sha256": "f5fa362e4d604e18c79409db645154ad32c07e59fa9696d3374086fef4631c0d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/bin-unwrapped/kore-print",
      "bytes": 4770,
      "sha256": "f1956617796796855e288760d88c524074b5da17b4da606dfd0ebff9565a0dc0"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/bin/kompile",
      "bytes": 3293,
      "sha256": "386e0502d63a10a6b0e9ddb46ef842a97be7bc61c4d4149ce66f51b3f3548632"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/bin/kore-print",
      "bytes": 3296,
      "sha256": "dc631491283f1f8e0efba6c41c7e14e2c725c779825e984ef2173c373d0f986b"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/include/kframework/builtin/domains.md",
      "bytes": 123428,
      "sha256": "eb5b7c3cd001d5fe3cbd481598bb53c3abfd417c409135276008d50edf79aa0d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/include/kframework/builtin/ffi.md",
      "bytes": 8401,
      "sha256": "9715ca4b6424dc2d2c7145b356dd78138350d8ac7b7d42bd735b909582efa6aa"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/include/kframework/builtin/json.md",
      "bytes": 1616,
      "sha256": "f167dae52f2fb2cc0f87631b93b0bb5425f5f8adeb61d666126ddae25e6d12fa"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/include/kframework/builtin/kast.md",
      "bytes": 22493,
      "sha256": "42c815ea80ed522dde962e231bdacc3d0d7e643016f8d649eab8d4be1d570040"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/include/kframework/builtin/prelude.md",
      "bytes": 812,
      "sha256": "60abd2e7ee255b202dd95f50f760ab09b71a78547454d99a8a3d0fc33020172c"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/include/kframework/builtin/rat.md",
      "bytes": 7545,
      "sha256": "685711fa32c16b27f4e4e9da20b2a9ea0d2a63a7dba566eba711e35dde31fd03"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/include/kframework/builtin/substitution.md",
      "bytes": 3844,
      "sha256": "c7e3fe10066a8b0cb8dcfd60c2b8e9bda78914b1e8d488ceeeacd16f231e293e"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/include/kframework/builtin/timer.md",
      "bytes": 259,
      "sha256": "4b718e4ac1929f5bf9ccdb1f27a7998870c5105aeaeb300358a8a1fc601605e4"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/include/kframework/builtin/unification.k",
      "bytes": 805,
      "sha256": "4a6fc7b72406d14a26c584366e8395b93071f6377ca8ca44aeba3edea5da8dbd"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/JavaEWAH-1.2.3.jar",
      "bytes": 170567,
      "sha256": "d65226949713c4c61a784f41c51167e7b0316f93764398ebba9e4336b3d954c2"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/annotations-24.0.1.jar",
      "bytes": 30651,
      "sha256": "61666dbce7e42e6c85b43c04fcfb8293a21dcb55b3c80e869270ce42c01a6b35"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/aopalliance-1.0.jar",
      "bytes": 4467,
      "sha256": "0addec670fedcd3f113c5c8091d783280d23f75e3acb841b61a9cdb079376a08"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/autolink-0.6.0.jar",
      "bytes": 16098,
      "sha256": "a80be030f6386f18111cad9161c0b6983157352a1b59a59e6002172f0d321c04"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/automaton-1.11-8.jar",
      "bytes": 176285,
      "sha256": "a24475f6ccfe1cc7a4fe9e34e05ce687b0ce0c6e8cb781e0eced3b186482c61e"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/checker-qual-3.37.0.jar",
      "bytes": 224460,
      "sha256": "e4ce1376cc2735e1dde220b62ad0913f51297704daad155a33f386bc5db0d9f7"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/common_2.13-4.8.14.jar",
      "bytes": 2463771,
      "sha256": "49b5831bf995c88ee69681c5c198a6219ceeeb7c894eef0670078dc030055b5c"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/commons-codec-1.13.jar",
      "bytes": 344339,
      "sha256": "61f7a3079e92b9fdd605238d0295af5fd11ac411a0a0af48deace1f6c5ffa072"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/commons-collections4-4.3.jar",
      "bytes": 753996,
      "sha256": "62f8db7da73e551f82d70fd533834177af6bd953de4b5e85c44dc2100de4beb8"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/commons-io-2.7.jar",
      "bytes": 276413,
      "sha256": "4547858fff38bbf15262d520685b184a3dce96897bc1844871f055b96e8f6e95"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/commons-lang3-3.3.2.jar",
      "bytes": 412739,
      "sha256": "6b81d10754dadf184d386011486e6509c2cc0c3d33565ced4fb4402b9413d47d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/commons-logging-1.2.jar",
      "bytes": 61829,
      "sha256": "daddea1ea0be0f56978ab3006b8ac92834afeefbd9b7e4e6316fca57df0fa636"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/compiler-bridge_2.13-1.8.0.jar",
      "bytes": 243207,
      "sha256": "2e483a3ea4dc3a4a29f1ccf6ee8326e4f403db122f16cb5426f5e5f11d99ff6e"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/compiler-interface-1.8.0.jar",
      "bytes": 112407,
      "sha256": "a7f1fec73e53a9796bcfd8d41c490d61dd70141604752e6e75b2e755f044fe8f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/concurrent-trees-2.6.1.jar",
      "bytes": 119854,
      "sha256": "04e3724984e2a5cbf55606cfa372a5bd3d3c5d2a21533a7004e3cde539761fa5"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/config-1.4.1.jar",
      "bytes": 295197,
      "sha256": "4c0aa7e223c75c8840c41fc183d4cd3118140a1ee503e3e08ce66ed2794c948f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/durian-collect-1.2.0.jar",
      "bytes": 1212833,
      "sha256": "b194c0b88021cc116c21c1dc76f49c2c1fe175af5bcb74c8ba67b9dbbf9a48cc"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/durian-core-1.2.0.jar",
      "bytes": 343717,
      "sha256": "17ed0aacb3a3c16323332168bbdead8694f32800b2b47d69d4a4c49b114d5dae"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/durian-io-1.2.0.jar",
      "bytes": 186776,
      "sha256": "095fd1dc77888c073f0be39a018156ee526722798b09de9e285ef2135e16eac4"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/durian-swt.os-4.2.1.jar",
      "bytes": 13251,
      "sha256": "4075cef438707d669b8d468500289af99fe87cb3fa69b7f564d9cefa4c838b30"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/error_prone_annotations-2.21.1.jar",
      "bytes": 16830,
      "sha256": "d1f3c66aa91ac52549e00ae3b208ba4b9af7d72d68f230643553beb38e6118ac"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/failureaccess-1.0.1.jar",
      "bytes": 4617,
      "sha256": "a171ee4c734dd2da837e4b16be9df4661afab72a41adaf31eb84dfdaf936ca26"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/fansi_2.13-0.4.0.jar",
      "bytes": 65146,
      "sha256": "0eb11a2a905d608033ec1642b0a9f0d8444daa4ad465f684b50bdc7e7a41bf53"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-0.64.6.jar",
      "bytes": 446356,
      "sha256": "59952315c6f3365b37a72215cc721de9c6be4a4812730056e7ee0930b14a099c"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-all-0.64.6.jar",
      "bytes": 2171,
      "sha256": "3aad26a3130e7b5222c0be838eb364ae20a7401e8a7b71188c39b6a22dca7434"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-abbreviation-0.64.6.jar",
      "bytes": 26361,
      "sha256": "3333cb402db0628659b5c35c4a8914e9acebbda43319638a32e1dc8cfc2a1e6d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-admonition-0.64.6.jar",
      "bytes": 31613,
      "sha256": "4cf0ce44b704e9be414f8fbf8f7083db5ecd5d3f6b3622715a51c082e7af942f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-anchorlink-0.64.6.jar",
      "bytes": 12062,
      "sha256": "7fb47642bf8cb0a8a7ea7b6db408cc316b48fe1f5a97a6133472ba1450da4ea0"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-aside-0.64.6.jar",
      "bytes": 17668,
      "sha256": "72c0fa2cf25ef0d3efd0ca07b967093eaa41687aa820ae6e2437f0c6f7ecb800"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-attributes-0.64.6.jar",
      "bytes": 49661,
      "sha256": "e1e72e653731eabeee83e921bccdc9530d35e7e5638e74dfc727a78ecb64736f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-autolink-0.64.6.jar",
      "bytes": 9647,
      "sha256": "a814a58b6c26594b073223291ecbd0d719eb1f6e9baeafed5c1ef69fb23f76ae"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-definition-0.64.6.jar",
      "bytes": 31783,
      "sha256": "defb936a49a185b2c106f3e1b00a7dee0d6333dfa7048bb4d29edbf4bfa60ab6"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-emoji-0.64.6.jar",
      "bytes": 72143,
      "sha256": "ef6f3e843202a9938fbdbd44f4a981e71fa9dca00a4d0a1ccfdcd5d858c217fa"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-enumerated-reference-0.64.6.jar",
      "bytes": 49144,
      "sha256": "de6a5057468b55c817cadbd2ed0adfcb44e0f2383cb60726e6b55e2271f47537"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-escaped-character-0.64.6.jar",
      "bytes": 11904,
      "sha256": "978d098f5d34f10ce50bbbbe3d2657dc509619c1a1cd2740bc31c52964c12d39"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-footnotes-0.64.6.jar",
      "bytes": 30516,
      "sha256": "04f421b30cbe48b143dc0f26239fdcee7e0e4a8f7ee3a5e998264fe65b5decd1"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-gfm-issues-0.64.6.jar",
      "bytes": 14400,
      "sha256": "d5e5f9bb0bba16d1cec6d5ea3c3a4e19c0a27aacbd46d76cedac6aa85a010cf6"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-gfm-strikethrough-0.64.6.jar",
      "bytes": 23263,
      "sha256": "0441a29727d355b99b12b2b003482d40e0d8e33a547c3d7dd2457a18fe0c7857"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-gfm-tasklist-0.64.6.jar",
      "bytes": 22741,
      "sha256": "8a5059f728e2382081604fe6304cd072362e5d899588c22d111f6ae695ef12a6"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-gfm-users-0.64.6.jar",
      "bytes": 14626,
      "sha256": "7976ff0e740032358b71e52b5004531a5bd400db1529dc72c37f64191789858a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-gitlab-0.64.6.jar",
      "bytes": 31839,
      "sha256": "f44c944a4c77377918506d1346879e6557099b815e128e1130aaa1a2eb7d7b6a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-ins-0.64.6.jar",
      "bytes": 11571,
      "sha256": "e0e9d2dd4000b30757b324cd15bcdb1b2c9648a801026f25386da5a62811fb84"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-jekyll-front-matter-0.64.6.jar",
      "bytes": 15428,
      "sha256": "b70dd5b10feb8039f42481a8be8b1f054f94253ee9accfff6f8d3717a752c347"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-jekyll-tag-0.64.6.jar",
      "bytes": 27736,
      "sha256": "29edc1b4b7c862b903b25115a67971e068c62fcca6eb5b1e0b993551834cbeed"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-macros-0.64.6.jar",
      "bytes": 28409,
      "sha256": "2510e13c542effd4e8e2c9fab9cd37b2ed4e518c6409d1eff7b807d4dfd49f98"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-media-tags-0.64.6.jar",
      "bytes": 19988,
      "sha256": "8656bec1d7560e7c11d2f9ab2b451624f16b5f9a420bc433d0b1e07041f163c2"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-resizable-image-0.64.6.jar",
      "bytes": 11155,
      "sha256": "7e7ac5785b9cd76908416633fe91f33495876128afe660b0e037be03cad9ef66"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-superscript-0.64.6.jar",
      "bytes": 12043,
      "sha256": "a0605ff1389fdedf9af0aafc373077d738753af5004f37a6d3b51824cd8de517"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-tables-0.64.6.jar",
      "bytes": 47409,
      "sha256": "ea550a31e06c3412717501cbcae973591ea1140cc2cf7e43052952c732d759de"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-toc-0.64.6.jar",
      "bytes": 84145,
      "sha256": "872c839c9f9aaa65f3532314dac952cb5b78590a4fb2580ff5433bb30151bf58"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-typographic-0.64.6.jar",
      "bytes": 20270,
      "sha256": "fa491351f27cb7e7d10327f067d9f6f94d08281b6f91f2c2e6f7a4d24f585caf"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-wikilink-0.64.6.jar",
      "bytes": 29955,
      "sha256": "3a2cf7e983b470d0c4a6029b46a3cbd33444f2ac7617da5b07638041e63fa9c9"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-xwiki-macros-0.64.6.jar",
      "bytes": 26569,
      "sha256": "7656966dbb9d28e37b0d0297397135c076241a764e8b6f3f191abf1048c34231"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-yaml-front-matter-0.64.6.jar",
      "bytes": 16150,
      "sha256": "5bc227cace85cda4f870d54f7ae061c2b43b9c8eeab01db9d8968cf534febb0a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-ext-youtube-embedded-0.64.6.jar",
      "bytes": 11631,
      "sha256": "4a92dfeefa1dae49c8f9034bb01a3d799b36cfaa88871280456724d54fe35d3f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-html2md-converter-0.64.6.jar",
      "bytes": 81309,
      "sha256": "f39391369856b4f184b3b6ab4f2edd41344e6c3d73f9ccbcbee566759021acbe"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-jira-converter-0.64.6.jar",
      "bytes": 12095,
      "sha256": "7a5d676e618684a2e828b3c702270b07f2bbbe921f41e72f166562afb739a3ed"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-pdf-converter-0.64.6.jar",
      "bytes": 6399,
      "sha256": "5109fd035d871b36f6adb5119176381d90799da042ba9f76069f4a106aca4519"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-profile-pegdown-0.64.6.jar",
      "bytes": 6323,
      "sha256": "c52e7888eac47780cb7efccf39d31c000adbb93238816d96bf7c9205fdde858f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-0.64.6.jar",
      "bytes": 1829,
      "sha256": "9f7f593994634b3089b98abaf2fc79d40229291a53dc70fe31a804eaaf8a1c60"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-ast-0.64.6.jar",
      "bytes": 65820,
      "sha256": "8de31baa91056fc53d1e5ad4f4250d8bc69e3d9a7b865eece65ec44cb6db595d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-builder-0.64.6.jar",
      "bytes": 5179,
      "sha256": "fa9bc46a13d9a91878f215eceab2a3de2b4e6b75be66bc9a041e4a701c40b3c3"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-collection-0.64.6.jar",
      "bytes": 66711,
      "sha256": "2c57f72daf777e2029c38e4617642742ae03cdfd99d5de6e8f0a466cb7f62d7e"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-data-0.64.6.jar",
      "bytes": 25102,
      "sha256": "8b5b2a75772eb916b676f44715ce915451e1dca609de246bc030eb9fd0cca7e9"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-dependency-0.64.6.jar",
      "bytes": 16350,
      "sha256": "3f80172b2e58a07ba5d6167147d43f79663a42f381074231ded59759d1e26284"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-format-0.64.6.jar",
      "bytes": 109830,
      "sha256": "82c32ec7e2fe19c943175da22aab5d05de2d4ee1ede68c6e19729b3dacece126"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-html-0.64.6.jar",
      "bytes": 44429,
      "sha256": "46fa16af14934bd6973db5ffe7923f056bfec0c0b4d459194db6900c08631fa6"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-misc-0.64.6.jar",
      "bytes": 59478,
      "sha256": "406422641dfa7074181ba2a7d59d057a7f5c462a3904fb623ca541f596f387af"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-options-0.64.6.jar",
      "bytes": 11779,
      "sha256": "f4c1592be07f0d500b10e68543c3767f54149dae4efd639e874ec33d3603f8c9"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-sequence-0.64.6.jar",
      "bytes": 236743,
      "sha256": "8eff1485bdf83c370ea85dfffc3070be97b93580141ab15e61d116e58de2e1f7"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-util-visitor-0.64.6.jar",
      "bytes": 6663,
      "sha256": "0852be987d45bcddb3fde735a75de2ace0863398dcca822a3658a7553f1b846f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/flexmark-youtrack-converter-0.64.6.jar",
      "bytes": 12683,
      "sha256": "ca47b7412779c0caf550f4b72d571d80afeb842e47159cb8427df1d0c65e23af"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/fontbox-2.0.24.jar",
      "bytes": 1564111,
      "sha256": "2e8c0a569a90b04734fbc0c805d77f4ec03f98c11f5705055ccd7718c1953d68"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/google-java-format-1.28.0.jar",
      "bytes": 280969,
      "sha256": "41dfe4d1012794ed15e0ffd70f89fd4fa65d5f15ce0bc0c70f8c2c127d6d010d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/graphics2d-0.32.jar",
      "bytes": 73911,
      "sha256": "37f8f387395f96c214ac44f7475c7a2e1f832dfc1de289a3610e0ffbf728f679"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/gson-2.9.1.jar",
      "bytes": 265030,
      "sha256": "378534e339e6e6d50b1736fb3abb76f1c15d1be3f4c13cec6d536412e23da603"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/guava-32.1.3-jre.jar",
      "bytes": 3043932,
      "sha256": "6d4e2b5a118aab62e6e5e29d185a0224eed82c85c40ac3d33cf04a270c3b3744"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/guice-4.0-no_aop.jar",
      "bytes": 423560,
      "sha256": "19393891be59b6feaf7e308bd8a3843b4e552c10cdb687ebffd7695634a250a8"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/guice-assistedinject-4.0.jar",
      "bytes": 43425,
      "sha256": "ed44e4d809e6b3bc41ccd6e8b5acf43fb517234f4ac4c1125d7a82c44826f147"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/guice-grapher-4.0.jar",
      "bytes": 53973,
      "sha256": "83bcdc6a0c9458ebe7c4e294561ebf49f1ea46bde4462a5e353e874745e50851"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/guice-multibindings-4.0.jar",
      "bytes": 81388,
      "sha256": "79d1d122ce059ed2c55d5acfd77eb31e3891f6a4aa997257ec0e7aec3d10f078"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/guice-throwingproviders-4.0.jar",
      "bytes": 33251,
      "sha256": "749e58cbee46d3ab5e46f82bfd12f9fd606c835f490063a247ed7b1f693a7099"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/haskell-backend-1.0-SNAPSHOT.jar",
      "bytes": 25391,
      "sha256": "697f6b4558b0efc520ef605b2fe4280f7ced7b3a4d9c78098af44df88bea240d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/hawtjni-runtime-1.18.jar",
      "bytes": 23287,
      "sha256": "136d57b533518a6bd37784af6bac3b79309808d595f17af4e18e7863f73c29a9"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/icu4j-72.1.jar",
      "bytes": 14386028,
      "sha256": "3df572b240a68d13b5cd778ad2393e885d26411434cd8f098ac5987ea2e64ce3"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/j2objc-annotations-2.8.jar",
      "bytes": 9301,
      "sha256": "f02a95fa1a5e95edb3ed859fd0fb7df709d121a35290eff8b74dce2ab7f4d6ed"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/jansi-2.4.0.jar",
      "bytes": 221009,
      "sha256": "6cd91991323dd7b2fb28ca93d7ac12af5a86a2f53279e2b35827b30313fd0b9f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/java-diff-utils-4.12.jar",
      "bytes": 72305,
      "sha256": "9990a2039778f6b4cc94790141c2868864eacee0620c6c459451121a901cd5b5"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/javax.inject-1.jar",
      "bytes": 2497,
      "sha256": "91c77044a50c481636c32d916fd89c9118a72195390452c81065080f957de7ff"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/javax.json-1.0.4.jar",
      "bytes": 85147,
      "sha256": "0e1dec40a1ede965941251eda968aeee052cc4f50378bc316cc48e8159bdbeb4"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/jcommander-1.78.jar",
      "bytes": 83782,
      "sha256": "7891debb84b5f83e9bd57593ebece3399abbe0fd938cf306b3534c57913b9615"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/jline-3.21.0.jar",
      "bytes": 994664,
      "sha256": "1e7d63a2bd1c26354ca1987e55469ea4327c4a3845c10d7a7790ca9729c49c02"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/jna-5.13.0.jar",
      "bytes": 1879325,
      "sha256": "66d4f819a062a51a1d5627bffc23fac55d1677f0e0a1feba144aabdd670a64bb"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/jsoup-1.15.4.jar",
      "bytes": 440209,
      "sha256": "006830d0797710408de5589c18d864343c0ef1a3a0c603c9cb138c943b67d9a4"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/jsr305-3.0.0.jar",
      "bytes": 33031,
      "sha256": "bec0b24dcb23f9670172724826584802b80ae6cbdaba03bdebdef9327b962f6a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/jung-api-2.1.1.jar",
      "bytes": 42221,
      "sha256": "6cb735963c36d5155d0de5f19a03485b9a26e67550e160b3dd89009a6f51694e"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/jung-graph-impl-2.1.1.jar",
      "bytes": 66031,
      "sha256": "4911da04d77b4f7bb465a65ae3cc3a000cae4d52b587911e3c0b4c4b643493c1"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/k-frontend-1.0-SNAPSHOT.jar",
      "bytes": 1729665,
      "sha256": "6505360d7b472d9802d857452f29722d09424985bb224585c68c37741b65d30a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/kotlin-stdlib-1.6.20.jar",
      "bytes": 1509405,
      "sha256": "eeb51c2b67b26233fd81d0bc4f8044ec849718890905763ceffd84a31e2cb799"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/kotlin-stdlib-common-1.6.20.jar",
      "bytes": 200631,
      "sha256": "8da40a2520d30dcb1012176fe93d24e82d08a3e346c37e0343b0fb6f64f6be01"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/kotlin-stdlib-jdk7-1.6.20.jar",
      "bytes": 23898,
      "sha256": "aa2fa2e81355c4d98dd97da2169bf401f842261378f5b1cbea1aa11855d67620"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/kotlin-stdlib-jdk8-1.6.20.jar",
      "bytes": 17773,
      "sha256": "fdab1bf120e2b5e7ab6d7888e9ebc024ec6b8ca729361296395dab634b213695"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/listenablefuture-9999.0-empty-to-avoid-conflict-with-guava.jar",
      "bytes": 2199,
      "sha256": "b372a037d4230aa57fbeffdef30fd6123f9c0c2db85d0aced00c91b974f33f99"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/llvm-backend-1.0-SNAPSHOT.jar",
      "bytes": 14951,
      "sha256": "c3451f3e3acd1bfc0f42ba6b6ddbbfd5e5490edc596daff607eb72f87d01a88a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/llvm-backend-matching-1.0-SNAPSHOT.jar",
      "bytes": 623366,
      "sha256": "1dcad59f81086c049f6080fd0c873c66ba32c01da7113e04adc7709d6c805ad2"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/mdoc-parser_2.13-2.5.0.jar",
      "bytes": 32831,
      "sha256": "aa15d2d203f72614dc7d804e90065778403420fe0b7dc3e9ad3172b309331e32"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/metaconfig-core_2.13-0.12.0.jar",
      "bytes": 527448,
      "sha256": "2c91199ae5b206afdd52538f8c4da67c1794bcce0b5b06cf25679db00cf32c19"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/metaconfig-pprint_2.13-0.12.0.jar",
      "bytes": 33848,
      "sha256": "6d8b0b4279116c11d4f29443bd2a9411bedb3d86ccaf964599a9420f530ed062"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/metaconfig-typesafe-config_2.13-0.12.0.jar",
      "bytes": 17265,
      "sha256": "b4c5dbf863dadde363d8bd24333ce1091fec94fc5b88efd04607a26f3eab61b8"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/mpfr_java-1.4-linux64.jar",
      "bytes": 540038,
      "sha256": "45ebb07edcfc74cfb560a41ab67309903543b49fcaf2aa8beda1e7abf954da11"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/mpfr_java-1.4-osx.jar",
      "bytes": 570258,
      "sha256": "ed582e3f6a97c6971de4f74acc71bbd9141af3f16da611837d938f5d8a54167d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/mpfr_java-1.4.jar",
      "bytes": 46717,
      "sha256": "2e04f00638e04286c854f9c4799784d5542906f1c756954c0ad0701073ead19e"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/nailgun-server-1.0.0-SNAPSHOT.jar",
      "bytes": 52797,
      "sha256": "2dc5e947a069de0f613f00a6492d2345cd392d9ccebd8a323327716dec264930"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/okhttp-4.11.0.jar",
      "bytes": 786969,
      "sha256": "ee8f6bd6cd1257013d748330f4ca147638a9fbcb52fb388d5ac93cf53408745d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/okio-3.2.0.jar",
      "bytes": 25503,
      "sha256": "dca932cb2029b6c9e26770f87db08b14d481ffe8131a59f369a2385c11be4e2d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/okio-jvm-3.2.0.jar",
      "bytes": 345115,
      "sha256": "b642baef4c570055de4cb3d1667b2b16dced901ff8066345a063691aa06025a4"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/openhtmltopdf-core-1.0.10.jar",
      "bytes": 1030009,
      "sha256": "3e6fd2250d833d500b7cd48b7a896700d0c33bd9f77a219e820493b01566eda3"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/openhtmltopdf-pdfbox-1.0.10.jar",
      "bytes": 259478,
      "sha256": "7de90df1b3ecf84e6f0daf808d724c11142007a2f22bff1936479bf17251d31a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/openhtmltopdf-rtl-support-1.0.10.jar",
      "bytes": 24956,
      "sha256": "5675c0b56d613b15446f9d0922d89781af48f05331326a87bdb3d1775c703215"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/org.eclipse.jgit-6.7.0.202309050840-r.jar",
      "bytes": 3139434,
      "sha256": "b564477d092241aaab50c84ac5dd1ac375c0182044d7e5659d3a60a90e2e801a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/org.eclipse.lsp4j-0.19.0.jar",
      "bytes": 1142037,
      "sha256": "d432390fd296f862f8813d6a8f0559bde3a5e4a54e123b7ab970f0b05ce2f128"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/org.eclipse.lsp4j.generator-0.19.0.jar",
      "bytes": 54035,
      "sha256": "6b3758e4f6eecbf48bfcb6e9c4f860bd1455c5c3852cd807460b6b2623d9b634"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/org.eclipse.lsp4j.jsonrpc-0.19.0.jar",
      "bytes": 137423,
      "sha256": "a3361392fbfb934a6c09e5ff3db48cdff065d7ba93deea57dedaedeb996633d2"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/org.eclipse.osgi-3.18.300.jar",
      "bytes": 1539745,
      "sha256": "bab943e58edd17309238672dba7a45aec9e2dacbdddb818a8cf17723ea13fa22"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/org.eclipse.xtend.lib-2.28.0.jar",
      "bytes": 112545,
      "sha256": "e18b609a3f99ece787443efd231504232f4b6179e9cc1c7b0905361dd31c8fdf"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/org.eclipse.xtend.lib.macro-2.28.0.jar",
      "bytes": 79739,
      "sha256": "623a312c0bd6341fecbb72eba6c011f326561d451426fb957a4b18ba076c17c6"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/org.eclipse.xtext.xbase.lib-2.28.0.jar",
      "bytes": 166255,
      "sha256": "2e81c2ad0b4e48b0b1ba2e5873a06bb877dfbbcb0651c1ed0988ee15c6ebbdfe"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/paiges-core_2.13-0.4.3.jar",
      "bytes": 119538,
      "sha256": "4daa8b180b466634b66be040e1097c107981c0ba0b7c605e2f7c0b66ae1b99b5"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/parsers_2.13-4.8.14.jar",
      "bytes": 867250,
      "sha256": "47030b6edede54f7aa480ba12155677a6c553de74d34265792bca02ea813256b"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/pcollections-2.1.2.jar",
      "bytes": 39146,
      "sha256": "29c8ffcc5c6a97f059941148593ad00fe2cdf78af1d88d46bcf0d1bb703606c2"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/pdfbox-2.0.24.jar",
      "bytes": 2745079,
      "sha256": "3c2c0553ec0e7533c490b4c952e1af113621de5275af6e380e11d0d9a0a4f3d6"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/plexus-build-api-0.0.7.jar",
      "bytes": 8482,
      "sha256": "934171640fbd3d2495c50b79b0d9adb11e2c83e65bad157df8fe34bcac0ff798"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/plexus-resources-1.2.0.jar",
      "bytes": 22918,
      "sha256": "898fc46841ce7defce320b78b748e285cc4790f9db931045d1f4b139a35f065d"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/plexus-utils-3.4.1.jar",
      "bytes": 263876,
      "sha256": "52d85e04b3918722af11d12855b4a8257df96a0e76c8f4e3852e6faa851f357b"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scala-collection-compat_2.13-2.11.0.jar",
      "bytes": 7090,
      "sha256": "0c1108883b7b97851750e8932f9584346ccb23f1260c197f97295ac2e6c56cec"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scala-compiler-2.13.12.jar",
      "bytes": 12200301,
      "sha256": "583adb1ffa7b29fdbfdd6f4c97a396af06a8a91625d059823bba1b7172242d6a"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scala-kore-0.3.3.jar",
      "bytes": 263871,
      "sha256": "c30416a73d357749c950f6db06eab51995dd46bf875b874f0daae01e57d97447"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scala-library-2.13.13.jar",
      "bytes": 5922756,
      "sha256": "b58b223f9b59f88d04c9dc9ec26f4b463e93e6f296de5663dbd710a7dfce2743"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scala-parallel-collections_2.13-1.0.4.jar",
      "bytes": 1127123,
      "sha256": "68f266c4fa37cb20a76e905ad940e241190ce288b7e4a9877f1dd1261cd1a9a7"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scala-reflect-2.13.13.jar",
      "bytes": 3788215,
      "sha256": "8e7fa6fd2f9682035bfeae45160afa38ca67aec7dfc614146a758efdeb2ffafc"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scalafmt-config_2.13-3.7.17.jar",
      "bytes": 9396,
      "sha256": "cfa4bed5a3944ffd435f583d27b2fdd05dd194066523234d9b11a26c1189f1a4"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scalafmt-core_2.13-3.7.17.jar",
      "bytes": 2065804,
      "sha256": "7cb60b9f89579e87f52504760752abb77fa82be5d7a97b5d81e79e744a54e08c"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scalafmt-sysops_2.13-3.7.17.jar",
      "bytes": 49816,
      "sha256": "e3b382902ba5ffd86f43ebafe1a01eef868bc61e52d5f53898086db19773cc3f"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scalameta_2.13-4.8.14.jar",
      "bytes": 810656,
      "sha256": "d6cd45cfd609064969922ee8e33863842347533f9a8daf6b059a54c29226dac2"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/scalap-2.13.12.jar",
      "bytes": 527354,
      "sha256": "ba4152ca85f42f04d76d903e006f9848f4e7d0629791d016953f05a5a04954c8"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/slf4j-api-1.7.32.jar",
      "bytes": 41513,
      "sha256": "3624f8474c1af46d75f98bc097d7864a323c81b3808aa43689a6e1c601c027be"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/snakeyaml-2.0.jar",
      "bytes": 334803,
      "sha256": "880c9d896e4b74a06c549c15ca496450165d6909fa15d7e662bee8f6a66d7afa"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/solstice-1.7.4.jar",
      "bytes": 410589,
      "sha256": "1288c1010299cb8434218e370f2291f2d6ea49b3ccb34b5082080f7c270a254c"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/sourcecode_2.13-0.3.0.jar",
      "bytes": 119136,
      "sha256": "6e5b2d55e942b450a222bfd3ebc23e99ca03716e42da25af1b2c8cde038100f5"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/spotless-lib-2.43.1.jar",
      "bytes": 471112,
      "sha256": "a8fb74a173700ed3ce4d87a2b2a8125e7fb68bd2b95c99e2da5112ccbd53cd31"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/spotless-lib-extra-2.43.1.jar",
      "bytes": 79022,
      "sha256": "94f5c1a68630bbb16343522157b414f3f7558307479bbf658df886e3b8dc81c4"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/spotless-maven-plugin-2.41.1.jar",
      "bytes": 124396,
      "sha256": "25bba0363ba305daf50fc31d8241655241723e218b424b1f4c255ff0b6331612"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/trees_2.13-4.8.14.jar",
      "bytes": 6740138,
      "sha256": "798493812b8d2a61381de0645f1630cc47eba6a20bbfeb713c636f6b9609d714"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/util-interface-1.8.0.jar",
      "bytes": 3345,
      "sha256": "5760f47ecbdf1cd61db2c1b433a711ede09b3cabc30626c4ba36fe463b323a26"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/xmpbox-2.0.24.jar",
      "bytes": 132350,
      "sha256": "27383df2285b9e228c39f2c755adeebbef774793d33c4f20f0dc99e9ebaaf673"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/java/xz-1.9.jar",
      "bytes": 116013,
      "sha256": "211b306cfc44f8f96df3a0a3ddaf75ba8c5289eed77d60d72f889bb855f535e5"
    },
    {
      "path": "/nix/store/y63xkr8pk2bqd5lh4889rlwldw26v9f4-k-7.1.337-4a46d1231473b599c699160132fd6e76a5c46406/lib/kframework/k",
      "bytes": 1115,
      "sha256": "d56ba8f42a320cab88708456ec2721ab71b0d49e8b1bad42d47b497b34fda66c"
    },
    {
      "path": "/nix/store/z1fkfc5ca0rra7m5zrh8i92mx18w9i00-flex-2.6.4/bin/flex",
      "bytes": 354336,
      "sha256": "918b825418307f5f7f9bfb57951559607090766fb38757be4b349300be1843bb"
    }
  ],
  "current_regular_files_equal": true,
  "qualification": "Conservative source-available historical closure; existence checked only. Includes K JRE/JAR/builtin/tool resources; no new host dependency probe or binary semantic reread. Keep symlink/layout rows in referenced original inventory too.",
  "scope": "Inherited conservative Kcompile tool/resource closure, not a new wholehost/systemlibrary proof; no tool executed."
}

===== END BODY 25 =====

===== COMPLETE BODY 26 Actual reusable compile-only receipt, no runtime =====
SOURCE: /home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/generic-nominal-lt-operational-counterpart-20261019/revision02-metadata-corrections/actual/00-compile/RESULT.json
BYTES: 414 SHA256: 5cf6b8797352e2dcf9ff93cdde092c96ecefe986291137a75f3ff809819f28f5
{
  "id": "00-compile",
  "scope": "compileONLY6Kfiles, no runtime or independentexpectedoutputs",
  "started_utc": "2026-10-19T10:19:56.879719+00:00",
  "pid": 2370810,
  "elapsed_seconds": 15.911,
  "ended_utc": "2026-10-19T10:20:12.790595+00:00",
  "returncode": 0,
  "timed_out": false,
  "outcome": "exited",
  "group_members_after_exit": [],
  "swept": [],
  "remaining": [],
  "containment_breach": false
}

===== END BODY 26 =====
