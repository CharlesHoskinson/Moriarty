#!/usr/bin/env python3
"""Positive and hostile unit tests for Source10 NI/NP/Not K query and receiver.

UNRUN in designated author session per execution boundary; prepared for Root
execution after fresh independent security review.
"""

from __future__ import annotations

import copy
from pathlib import Path
import sys
import unittest

THIS_DIR = Path(__file__).resolve().parent
if str(THIS_DIR) not in sys.path:
    sys.path.insert(0, str(THIS_DIR))

import source10_receiving as s10  # noqa: E402

INPUTS_DIR = Path(
    "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/"
    "doctorwatson-stagenet-four-milestone-audit-20261020/"
    "k-next-public-nominal-identity-source10/inputs"
)


def load_input(case_name: str) -> dict:
    return s10.load(INPUTS_DIR / f"{case_name}.json")


class Source10ReceivingSecurityTests(unittest.TestCase):
    def test_01_registry_182_validation_and_split(self) -> None:
        self.assertEqual(len(s10.ALL_SYMBOLS), 182)
        self.assertEqual(len(s10.DATA_REG), 130)
        self.assertEqual(len(s10.QUERY_REG), 131)
        self.assertIn("niRun", s10.QUERY_REG)
        self.assertNotIn("niRun", s10.DATA_REG)

        function_names = [
            name
            for name, meta in s10.ALL_SYMBOLS.items()
            if meta["kind"] == "function"
        ]
        self.assertEqual(len(function_names), 52)
        for fn_name in function_names:
            self.assertNotIn(fn_name, s10.DATA_REG)
            if fn_name != "niRun":
                self.assertNotIn(fn_name, s10.QUERY_REG)

        for name in s10.EXPECTED_NEW19_SURFACE_NAMES:
            self.assertIn(name, s10.ALL_SYMBOLS)
            self.assertIn(
                s10.ALL_SYMBOLS[name]["declaring_module"],
                (
                    "SHERLOCK-PROGRAMVIEW-IDENTITY-SOURCE10",
                    "SHERLOCK-PROGRAMVIEW-IDENTITY-SOURCE10-LAWS",
                ),
            )

        raw_reg = s10.loads(s10.checked(s10.ACTUAL_182_REGISTRY_PIN))
        def_lines = (
            s10.checked(s10.DEFINITION_KORE_PIN).decode("utf-8").splitlines()
        )
        validated = s10.validate_receiving_registry(
            raw_reg, definition_lines=def_lines
        )
        self.assertEqual(len(validated["all_symbols"]), 182)

        bad_count = copy.deepcopy(raw_reg)
        bad_count["count"] = 181
        with self.assertRaises(s10.ObservationFormatError):
            s10.validate_receiving_registry(bad_count, definition_lines=def_lines)

        bad_label = copy.deepcopy(raw_reg)
        bad_label["rows"][0][4] = "ngAdd(_,_,_)_WRONG_MODULE_NGExpr_Int_Int_Int"
        with self.assertRaises(s10.ObservationFormatError):
            s10.validate_receiving_registry(bad_label, definition_lines=def_lines)

        bad_line = copy.deepcopy(raw_reg)
        bad_line["rows"][0][9] += 1
        with self.assertRaises(s10.ObservationFormatError):
            s10.validate_receiving_registry(bad_line, definition_lines=def_lines)

        bad_kind = copy.deepcopy(raw_reg)
        bad_kind["rows"][0][3] = "function"
        with self.assertRaises(s10.ObservationFormatError):
            s10.validate_receiving_registry(bad_kind, definition_lines=def_lines)

    def test_02_render_source10_map_queue_and_mirror_arbor_roundtrips(self) -> None:
        for case_name, expected_type_ids, expected_type_arg_kinds in (
            ("map-queue", [4, 1], ["Nominal", "Bool"]),
            ("mirror-arbor", [4, 0], ["Nominal", "UInt"]),
        ):
            doc = load_input(case_name)
            saved = copy.deepcopy(doc)
            rendered = s10.render_source10(doc, 512)
            self.assertTrue(s10.same(doc, saved))
            self.assertEqual(rendered["schema"], s10.RENDER_SCHEMA)
            self.assertTrue(rendered["inverse_verified"])
            self.assertEqual(rendered["model_steps_evaluated"], 0)
            self.assertEqual(rendered["expected_documents_opened"], 0)
            self.assertEqual(
                [
                    x["runtime_type_id"]
                    for x in rendered["ported"]["type_rows"][-1]["type"]["arguments"]
                ],
                expected_type_ids,
            )

            kast = rendered["kast_jsonv4"]
            self.assertEqual(kast["format"], "KAST")
            self.assertEqual(kast["version"], 4)
            self.assertEqual(kast["term"]["node"], "KApply")
            self.assertEqual(
                kast["term"]["label"]["name"],
                s10.LABELS["niRun"],
            )
            self.assertEqual(kast["term"]["arity"], 5)

            query_term = s10.from_source10_ast(
                rendered["query_ast"], allow_root_query=True
            )
            self.assertEqual(
                s10.decode_query_document(kast, "NIObservation"),
                query_term,
            )
            self.assertEqual(
                s10.parse_printed(
                    rendered["printed_query"],
                    "NIObservation",
                    registry=s10.QUERY_REG,
                ),
                query_term,
            )

            decoded_type_rows = s10.WIRE.decode(query_term.args[2])
            self.assertEqual(
                [arg["kind"] for arg in decoded_type_rows[-1]["type"]["arguments"]],
                expected_type_arg_kinds,
            )

        arbor_rendered = s10.render_source10(load_input("mirror-arbor"), 256)
        arbor_term = s10.from_source10_ast(
            arbor_rendered["query_ast"], allow_root_query=True
        )
        arbor_prog = s10.WIRE.decode(arbor_term.args[1])
        self.assertEqual(
            arbor_prog["expressions"][12],
            {"id": 12, "occurrence": 12, "kind": {"Not": {"operand": 13}}},
        )
        arbor_ctors = s10.WIRE.decode(arbor_term.args[3])
        self.assertEqual(arbor_ctors[5]["fields"], ["z_left", "a_right"])

    def test_03_nijson_types_some_zero_null_empty_and_unicode(self) -> None:
        sample = {
            "null_field": None,
            "zero_int": 0,
            "zero_str": "0",
            "empty_str": "",
            "bool_true": True,
            "bool_false": False,
            "negative_int": -42,
            "empty_list": [],
            "empty_obj": {},
            "unicode": "αβ\n\"\\t",
            "slice": {"start": "5", "len": "0", "decl": "0", "none": None},
            "items": [None, False, True, 0, "0", [], {}],
        }
        ast_node = s10._port10.json_ast(sample)
        term = s10.from_source10_ast(ast_node)
        self.assertEqual(term.sort, "NIJSON")
        printed = s10.render_term(term)
        reparsed = s10.parse_printed(printed, "NIJSON")
        self.assertEqual(reparsed, term)
        kast_doc = s10.envelope(term)
        self.assertEqual(s10.decode_document(kast_doc, "NIJSON"), term)
        decoded = s10.WIRE.decode(term)
        self.assertTrue(s10.same(decoded, sample))
        self.assertFalse(s10.same(0, False))
        self.assertFalse(s10.same(1, True))
        self.assertFalse(s10.same("0", 0))
        self.assertFalse(s10.same(None, 0))

    def test_04_np_types_values_and_declared_field_order(self) -> None:
        printed_np = (
            'npNominal('
            'npNominalType("Stamp",npType(npNominalType("Arbor",npType(npUIntType(),npNoTypes())),npType(npBoolType(),npNoTypes()))),'
            '"Seal",'
            'npField("z_left",npUInt(0),npField("a_right",npBool(false),npNoFields()))'
            ')'
        )
        term = s10.parse_printed(printed_np, "NPValue")
        self.assertEqual(s10.render_term(term), printed_np)
        decoded = s10.WIRE.decode(term)
        self.assertEqual(
            decoded,
            {
                "Nominal": {
                    "type": {
                        "kind": "Nominal",
                        "name": "Stamp",
                        "arguments": [
                            {
                                "kind": "Nominal",
                                "name": "Arbor",
                                "arguments": [{"kind": "UInt"}],
                            },
                            {"kind": "Bool"},
                        ],
                    },
                    "constructor": "Seal",
                    "fields": [
                        {"name": "z_left", "value": {"UInt": 0}},
                        {"name": "a_right", "value": {"Bool": False}},
                    ],
                }
            },
        )

        dup_fields = (
            'npNominal(npUIntType(),"Bad",'
            'npField("dup",npUInt(1),npField("dup",npUInt(2),npNoFields())))'
        )
        dup_term = s10.parse_printed(dup_fields, "NPValue")
        with self.assertRaises(s10.ObservationFormatError):
            s10.WIRE.decode(dup_term)

    def test_05_decode_source10_complete_state_env_frames_and_not_events(self) -> None:
        doc = load_input("mirror-arbor")
        rendered = s10.render_source10(doc, 64)
        query_term = s10.from_source10_ast(
            rendered["query_ast"], allow_root_query=True
        )
        source_printed = s10.render_term(query_term.args[0])
        prog_printed = s10.render_term(query_term.args[1])

        state_printed = (
            f"ngState({prog_printed},"
            "ngHalted(ngBool(false)),"
            "(.Map (11 |-> ngBool(true)) (12 |-> ngUInt(0))),"
            "ngFrame(ngNotArgument(12,12,(.Map (11 |-> ngBool(false)))),"
            "ngFrame(ngArmScope(9,9,0,(.Map (7 |-> ngUInt(2)))),ngNoFrames())),"
            "ngEvent(ngLiteralEvaluated(3,3,ngUInt(0)),"
            "ngEvent(ngNotStarted(12,12,13,(.Map (11 |-> ngBool(false)))),"
            "ngEvent(ngNotReturned(12,12,ngBool(true),ngBool(false),(.Map (11 |-> ngBool(false)))),"
            "ngEvent(ngFinished(ngBool(false)),ngNoEvents())))))"
        )
        np_val_printed = (
            'npNominal(npNominalType("Stamp",npType(npNominalType("Arbor",npType(npUIntType(),npNoTypes())),npType(npUIntType(),npNoTypes()))),'
            '"Seal",'
            'npField("z_tree",npBool(false),npField("a_code",npUInt(0),npNoFields())))'
        )
        raw_kprint = (
            "<generatedTop>\n  <k>\n    "
            f"niObserved({source_printed},npObserved({state_printed},{np_val_printed}))"
            " ~> .K\n  </k>\n</generatedTop>\n"
        )

        decoded = s10.decode_source10(doc, raw_kprint)
        self.assertEqual(decoded["schema"], s10.DECODE_SCHEMA)
        self.assertTrue(decoded["source_identity_verified"])
        self.assertTrue(s10.same(decoded["source_document"], doc))
        self.assertEqual(decoded["raw_typed_ast"]["sort"], "NIObservation")
        self.assertEqual(decoded["raw_typed_ast"]["constructor"], "niObserved")

        ng_state = decoded["ng_state"]
        self.assertTrue(
            s10.same(ng_state["program"], rendered["ported"]["ng_program"])
        )
        self.assertEqual(ng_state["control"], {"ngHalted": {"value": {"Bool": False}}})
        self.assertEqual(
            ng_state["environment"],
            [
                {"name_id": 11, "value": {"Bool": True}},
                {"name_id": 12, "value": {"UInt": 0}},
            ],
        )
        self.assertEqual(
            ng_state["frames_top_first"],
            [
                {
                    "ngNotArgument": {
                        "expr_id": 12,
                        "occurrence": 12,
                        "saved_environment": [
                            {"name_id": 11, "value": {"Bool": False}}
                        ],
                    }
                },
                {
                    "ngArmScope": {
                        "match_expr_id": 9,
                        "match_occurrence": 9,
                        "source_arm_id": 0,
                        "saved_environment": [
                            {"name_id": 7, "value": {"UInt": 2}}
                        ],
                    }
                },
            ],
        )
        self.assertEqual(
            [ next(iter(ev)) for ev in ng_state["events"] ],
            [
                "ngLiteralEvaluated",
                "ngNotStarted",
                "ngNotReturned",
                "ngFinished",
            ],
        )
        self.assertEqual(
            ng_state["events"][1],
            {
                "ngNotStarted": {
                    "expr_id": 12,
                    "occurrence": 12,
                    "operand_expr_id": 13,
                    "saved_environment": [
                        {"name_id": 11, "value": {"Bool": False}}
                    ],
                }
            },
        )
        self.assertEqual(
            ng_state["events"][2],
            {
                "ngNotReturned": {
                    "expr_id": 12,
                    "occurrence": 12,
                    "operand_value": {"Bool": True},
                    "result": {"Bool": False},
                    "restored_environment": [
                        {"name_id": 11, "value": {"Bool": False}}
                    ],
                }
            },
        )
        self.assertEqual(
            [f["name"] for f in decoded["np_value"]["Nominal"]["fields"]],
            ["z_tree", "a_code"],
        )

        # Tampering with bound source document must be rejected.
        tampered = copy.deepcopy(doc)
        tampered["source"]["name"] = "DifferentName"
        with self.assertRaises(s10.ObservationFormatError):
            s10.decode_source10(tampered, raw_kprint)

    def test_06_reject_residual_functions_and_unreduced_k_cells(self) -> None:
        doc = load_input("map-queue")
        rendered = s10.render_source10(doc, 16)
        with self.assertRaises(s10.ObservationFormatError):
            s10.decode_source10(doc, f"<k> {rendered['printed_query']} ~> .K </k>")

        for residual in (
            "niLawRawPresence()",
            "niSource(niObserved(niNull(),npObserved(ngState(ngProgram(ngNoDecls(),ngNoNodes(),ngNoFunctions(),0),ngHalted(ngBool(true)),.Map,ngNoFrames(),ngNoEvents()),npBool(true))))",
            "npRunReference(ngProgram(ngNoDecls(),ngNoNodes(),ngNoFunctions(),0),npNoTypeRows(),npNoCtorRows(),1)",
        ):
            with self.assertRaises(s10.ObservationFormatError):
                s10.parse_printed(residual, registry=s10.DATA_REG)

        for bad_frame in (
            "",
            "<k> niNull()",
            "niNull() </k>",
            "<generatedTop> niNull() </generatedTop>",
            "<generatedTop> <k> niNull() </k> <extra> 1 </extra> </generatedTop>",
            "<k> ~> .K </k>",
        ):
            with self.assertRaises(s10.ObservationFormatError):
                s10.complete_term(bad_frame)

        with self.assertRaises(s10.ObservationFormatError):
            s10.parse_printed("niNull() ~> .K", "NIJSON")

    def test_07_reject_r2_value_ast_and_bare_or_parametric_kast_labels(self) -> None:
        with self.assertRaises(s10.ObservationFormatError):
            s10.from_source10_ast({"sort": "Int", "value": 1})

        with self.assertRaises(s10.ObservationFormatError):
            s10.from_source10_ast(
                {"sort": "Map", "entries": []}, allow_map=False
            )
        empty_map_term = s10.from_source10_ast(
            {"sort": "Map", "entries": []}, allow_map=True
        )
        self.assertEqual(s10.WIRE.decode(empty_map_term), [])

        valid_kast = s10.envelope(s10.make_term("niNull"))
        bare_kast = copy.deepcopy(valid_kast)
        bare_kast["term"]["label"]["name"] = "niNull"
        with self.assertRaises(s10.ObservationFormatError):
            s10.decode_document(bare_kast, "NIJSON")

        kore_kast = copy.deepcopy(valid_kast)
        kore_kast["term"]["label"]["name"] = s10.ALL_SYMBOLS["niNull"]["raw_kore_label"]
        with self.assertRaises(s10.ObservationFormatError):
            s10.decode_document(kore_kast, "NIJSON")

        param_kast = copy.deepcopy(valid_kast)
        param_kast["term"]["label"]["params"] = ["SortNIJSON"]
        with self.assertRaises(s10.ObservationFormatError):
            s10.decode_document(param_kast, "NIJSON")

        for bad_int_token in ("01", "+1", "-0", "1 ", "true"):
            bad_tok_doc = {
                "format": "KAST",
                "version": 4,
                "term": {
                    "node": "KToken",
                    "sort": {"node": "KSort", "name": "Int", "params": []},
                    "token": bad_int_token,
                },
            }
            with self.assertRaises(s10.ObservationFormatError):
                s10.decode_document(bad_tok_doc, "Int")

    def test_08_reject_bool_int_confusion_and_integer_ranges(self) -> None:
        with self.assertRaises(s10.ObservationFormatError):
            s10.from_source10_ast({"sort": "Int", "literal": True})
        with self.assertRaises(s10.ObservationFormatError):
            s10.from_source10_ast({"sort": "Bool", "literal": 1})

        max_u128 = (1 << 128) - 1
        self.assertEqual(
            s10.WIRE.decode(s10.parse_printed(f"ngUInt({max_u128})", "NGValue")),
            {"UInt": max_u128},
        )
        self.assertEqual(
            s10.WIRE.decode(s10.parse_printed(f"npUInt({max_u128})", "NPValue")),
            {"UInt": max_u128},
        )
        for bad_u128 in (-1, 1 << 128):
            with self.assertRaises(s10.ObservationFormatError):
                s10.WIRE.decode(
                    s10.parse_printed(f"ngUInt({bad_u128})", "NGValue")
                )
            with self.assertRaises(s10.ObservationFormatError):
                s10.WIRE.decode(
                    s10.parse_printed(f"npUInt({bad_u128})", "NPValue")
                )

        for bad_idx in (-1, 1 << 64):
            with self.assertRaises(s10.ObservationFormatError):
                s10.WIRE.decode(
                    s10.parse_printed(f"ngEval({bad_idx})", "NGControl")
                )

        for bad_ni_int in (-(1 << 128), 1 << 128):
            with self.assertRaises(s10.ObservationFormatError):
                s10.parse_printed(f"niInt({bad_ni_int})", "NIJSON")

    def test_09_reject_duplicate_keys_and_enforced_decode_budgets(self) -> None:
        with self.assertRaises(s10.ObservationFormatError):
            s10.loads('{"dup": 1, "dup": 2}')
        with self.assertRaises(s10.ObservationFormatError):
            s10.loads('{"bad": NaN}')

        dup_nijson = s10.parse_printed(
            'niObject(niField("k",niNull(),niField("k",niBool(true),niNoFields())))',
            "NIJSON",
        )
        with self.assertRaises(s10.ObservationFormatError):
            s10.WIRE.decode(dup_nijson)

        with self.assertRaises(s10.ObservationFormatError):
            s10.parse_printed(
                "(.Map (4 |-> ngBool(true)) (4 |-> ngBool(false)))", "Map"
            )

        dup_type_rows = s10.parse_printed(
            "npTypeRow(0,npUIntType(),npTypeRow(0,npBoolType(),npNoTypeRows()))",
            "NPTypeRows",
        )
        with self.assertRaises(s10.ObservationFormatError):
            s10.WIRE.decode(dup_type_rows)

        dup_ctor_rows = s10.parse_printed(
            'npCtorRow(4,0,"A",npNoFieldNames(),npCtorRow(4,0,"B",npNoFieldNames(),npNoCtorRows()))',
            "NPCtorRows",
        )
        with self.assertRaises(s10.ObservationFormatError):
            s10.WIRE.decode(dup_ctor_rows)

        tiny_bytes = s10.DecodeBudget(max_bytes=8)
        with self.assertRaises(s10.ObservationFormatError):
            s10.loads('{"long_key": "value"}', budget=tiny_bytes)

        tiny_tokens = s10.DecodeBudget(max_tokens=4)
        with self.assertRaises(s10.ObservationFormatError):
            s10.parse_printed(
                "niArray(niItem(niNull(),niNoItems()))",
                "NIJSON",
                budget=tiny_tokens,
            )

        tiny_depth = s10.DecodeBudget(max_depth=3)
        deep_printed = (
            "niArray(niItem(niArray(niItem(niArray(niNoItems()),niNoItems())),niNoItems()))"
        )
        with self.assertRaises(s10.ObservationFormatError):
            s10.parse_printed(deep_printed, "NIJSON", budget=tiny_depth)

        tiny_rows = s10.DecodeBudget(max_rows=2)
        three_items = s10.parse_printed(
            "niArray(niItem(niNull(),niItem(niNull(),niItem(niNull(),niNoItems()))))",
            "NIJSON",
        )
        with self.assertRaises(s10.ObservationFormatError):
            s10.WIRE.decode(three_items, budget=tiny_rows)

        tiny_nodes = s10.DecodeBudget(max_nodes=3)
        with self.assertRaises(s10.ObservationFormatError):
            s10.WIRE.decode(three_items, budget=tiny_nodes)

    def test_10_reject_nested_nirun_sort_arity_and_ng_duplicates(self) -> None:
        doc = load_input("map-queue")
        rendered = s10.render_source10(doc, 32)
        bad_query_ast = copy.deepcopy(rendered["query_ast"])
        bad_query_ast["arguments"][0] = copy.deepcopy(rendered["query_ast"])
        with self.assertRaises(s10.ObservationFormatError):
            s10.from_source10_ast(bad_query_ast, allow_root_query=True)

        null_term = s10.make_term("niNull")
        with self.assertRaises(s10.ObservationFormatError):
            s10.encode_query_envelope(null_term)
        with self.assertRaises(s10.ObservationFormatError):
            s10.decode_query_document(s10.envelope(null_term), "NIJSON")

        with self.assertRaises(s10.ObservationFormatError):
            s10.make_term("niBool")
        with self.assertRaises(s10.ObservationFormatError):
            s10.make_term("niBool", s10.atom("Int", 1))

        for sort_name, dup_printed in (
            (
                "NGDecls",
                "ngDecl(2,0,ngNoCtors(),ngDecl(2,0,ngNoCtors(),ngNoDecls()))",
            ),
            (
                "NGNodes",
                "ngNode(0,ngLiteral(0,ngBool(true)),ngNode(0,ngLiteral(1,ngBool(false)),ngNoNodes()))",
            ),
            (
                "NGParams",
                "ngParam(1,0,ngParam(1,1,ngNoParams()))",
            ),
            (
                "NGArms",
                "ngArm(0,ngWildcard(),1,ngArm(0,ngWildcard(),2,ngNoArms()))",
            ),
            (
                "NGBindings",
                "ngBinding(5,0,0,ngRoot(),ngUInt(1),ngBinding(5,0,0,ngRoot(),ngUInt(2),ngNoBindings()))",
            ),
        ):
            term = s10.parse_printed(dup_printed, sort_name)
            with self.assertRaises(s10.ObservationFormatError):
                s10.WIRE.decode(term)


if __name__ == "__main__":
    unittest.main()
