from pathlib import Path
import sys,os,json,hashlib,runpy,datetime,glob
sys.dont_write_bytecode=True
A=Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020')
D=A/'k-next-public-nominal-identity-source10';C=A/'k-source10-NI-NP-Not-existing-receiver-security-source01'
H=C/'prospective-existing-F03-two-whole-observations-DATA01';root=C/'actual-two-whole-observations01'
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checked(r):
 a=pin(r['path']);assert a==r,(a,r);return a
def load(p):return json.loads(Path(p).read_bytes())
def syncdir(p):
 fd=os.open(p,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
def save(p,v):
 b=(json.dumps(v,indent=2)+'\n').encode();fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb')as f:f.write(b);f.flush();os.fsync(f.fileno())
 syncdir(p.parent)
def inventory(p):return {str(x.relative_to(p)):('directory'if x.is_dir()else'file')for x in sorted(p.rglob('*'))}
data=H/'PROPOSED-EXISTING-F03-2-OBSERVATIONS-10-PHASES.DATA.json'
assert pin(data)==dict(path=str(data),bytes=56011,sha256='7c9d90122bfc0157852a6b5d41be74ba4f5dd0c740ccf914afe3494713e749c9')
card=load(data);assert len(card['phases'])==10 and len(card['cases'])==2
assert [x['case_id']for x in card['cases']]==['map-queue','mirror-arbor']and all(type(x['observation_cut'])is int and x['observation_cut']==512 for x in card['cases'])
assert [x['step']for x in card['phases']]==['render','kast-json','depth1-reduce','full-print','whole-decode']*2
source=load(D/'SOURCE-FREEZE.json');reuse=load(card['compiled_reuse']['path']);checked(card['compiled_reuse']);tools=load(card['tools']['path']);checked(card['tools'])
rows=load(card['staticClosure']['path'])['members'];checked(card['staticClosure']);rows+=card['compiled15']
for k in ['source','tests','pure10PASS','review','registry182']:rows.append(card[k])
rows+=[pin(data),pin(__file__),pin(C/'actual-pure10-01/ALL-ACTUAL-FILES-FROZEN.json')]
for c in card['cases']:rows.append(c['source_input'])
rows=sorted({r['path']:r for r in rows}.values(),key=lambda r:r['path'])
def memberships():
 out={}
 for folder,expected in [(D/'source',[x['path']for x in source['members']if '/source/'in x['path']]),(D/'tests',[x['path']for x in source['members']if '/tests/'in x['path']]),(D/'actual/programview-identity-source10-kompiled',[x['path']for x in reuse['products']])]:
  got=sorted(str(x)for x in folder.rglob('*'));assert got==sorted(expected),(str(folder),got);out[str(folder)]=got
 assert sorted(glob.glob(tools['classpath_pattern']))==sorted(x['path']for x in tools['classpath_jar_membership'])
 for x in tools['entries']:assert str(Path(x['path']).resolve(strict=True))==x['resolved_path']
 out['classpath156']=True;out['resolved4']=True;return out
pre=[checked(r)for r in rows];mem=memberships();assert not root.exists()
for p in card['phases']:
 assert not Path(p['cwd']).exists()
 assert p['limits']['wall_seconds']==30 and p['limits']['sweep_seconds']==3 and p['limits']['rlimit_fsize']==536870912
 assert p['environment']['HOME']==p['cwd']+'/home'and p['environment']['TMPDIR']==p['cwd']+'/tmp'
 assert p['inherit_environment']is False
root.mkdir(mode=0o700);syncdir(C)
save(root/'OPERATOR-SELECTION.json',dict(selectedBy='Root explicit instruction delegated exact two whole observations cut512',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),manual=pin(__file__),phasecard=pin(data),sourceApprovalSeparate=True,tenNewChildrenOnly=True,noCompileOrTestsOrLawReplay=True,privateExpectedReads=0,scope=card['scope']))
save(root/'STATIC-PINS.json',dict(members=pre,membership=mem,stdlibHistoricalQualificationUnchanged=True))
api=runpy.run_path(card['callback']['fullsource']['path'],run_name='selected_nonmain_existing_F03_source10_whole2');assert api['CHILD_SECONDS']==30 and api['SWEEP_SECONDS']==3
dynamic=[];completed=[];observations=[];failure_class='INFRASTRUCTURE_STOP'
try:
 for phase in card['phases']:
  pre=[checked(r)for r in rows];prior=[checked(r)for r in dynamic];mem=memberships()
  cwd=Path(phase['cwd']);assert not cwd.exists();cwd.mkdir(parents=True,mode=0o700)
  for k in ['HOME','TMPDIR']:Path(phase['environment'][k]).mkdir(mode=0o700)
  save(root/(phase['id']+'-PRE.json'),dict(static_members=pre,prior_products=prior,membership=mem))
  save(cwd/'COMMAND.json',phase)
  record={};api['launch'](record,phase['argv'],dict(phase['environment']),phase['cwd'],phase['environment']['SHERLOCK_K_ATTEMPT_TOKEN'],536870912)
  save(cwd/'RESULT.json',record)
  files=sorted(p for p in cwd.rglob('*')if p.is_file())
  for p in files:
   with p.open('rb')as f:os.fsync(f.fileno())
  for p in sorted([cwd]+[p for p in cwd.rglob('*')if p.is_dir()],key=lambda p:len(p.parts),reverse=True):syncdir(p)
  syncdir(cwd.parent);syncdir(root);syncdir(C)
  produced=[pin(p)for p in files];save(root/(phase['id']+'-RAW-FROZEN.json'),dict(record=record,files=produced,classificationNotYetPerformed=True))
  post=[checked(r)for r in rows];postprior=[checked(r)for r in dynamic];memberships();inv=inventory(cwd)
  wanted={x:'directory'for x in ['home','tmp']};wanted.update({x:'file'for x in ['COMMAND.json','RESULT.json','stdout','stderr']});wanted.update({Path(x).name:'file'for x in phase['products']})
  save(root/(phase['id']+'-POST.json'),dict(static_members=post,prior_products=postprior,inventory=inv,expectedInventory=wanted,rawDurableBeforeClassification=True))
  err=Path(phase['stderr']).read_bytes();print(json.dumps(dict(phase=phase['id'],record=record,stderr_full=err.decode('utf-8','replace'))),flush=True)
  assert inv==wanted,('inventory',phase['id'],inv)
  assert record.get('returncode')==0 and record.get('outcome')=='exited'and not any(record.get(k)for k in ['timed_out','containment_breach','swept','remaining','group_members_after_exit']),record
  assert not err,('nonempty stderr retained; diagnostic classification required',phase['id'])
  for p in phase['products']:assert Path(p).is_file()and Path(p).stat().st_size>0
  if phase['step']in ['kast-json','full-print']:assert Path(phase['stdout']).stat().st_size>0
  if phase['step']in ['render','whole-decode']:
   failure_class='RECEIVER_OR_SOURCE_IDENTITY_FORMAT_FAILURE';report=load(phase['stdout']);assert report['status']=='DATA_PERSISTED'and report['action']==('render'if phase['step']=='render'else'decode')and type(report['expected_documents_opened'])is int and report['expected_documents_opened']==0
   if phase['step']=='render':assert type(report['model_steps_evaluated'])is int and report['model_steps_evaluated']==0
   assert sorted(r['path']for r in report['products'].values())==sorted(phase['products'])
   for r in report['products'].values():checked(r)
   print(json.dumps(dict(phase=phase['id'],full_cli_stdout=report)),flush=True)
   if phase['step']=='whole-decode':observations.append(dict(case_id=phase['case_id'],products=report['products'],privateExpectedReads=0))
   failure_class='INFRASTRUCTURE_STOP'
  dynamic+=produced
  for name in [phase['id']+'-PRE.json',phase['id']+'-RAW-FROZEN.json',phase['id']+'-POST.json']:dynamic.append(pin(root/name))
  completed.append(dict(id=phase['id'],case_id=phase['case_id'],record=record,files=produced))
  save(root/(phase['id']+'-ACCEPTED.json'),dict(status='PASS_SCOPED_PHASE',record=record));print('ACCEPTED '+phase['id'],flush=True)
 assert len(completed)==10 and len(observations)==2
 [checked(r)for r in rows];[checked(r)for r in dynamic];memberships()
 save(root/'AGGREGATE.json',dict(status='PASS_TWO_COMPLETE_NI_NP_OBSERVATIONS_CAPTURED_AND_DECODED',operations=completed,observations=observations,staticPins=len(rows),totalChildSeconds=sum(x['record']['elapsed_seconds']for x in completed),privateExpectedReads=0,comparisonSelected=False,scope=card['scope']))
 allfiles=sorted(p for p in root.rglob('*')if p.is_file())
 for p in allfiles:
  with p.open('rb')as f:os.fsync(f.fileno())
 for p in sorted([root]+[p for p in root.rglob('*')if p.is_dir()],key=lambda p:len(p.parts),reverse=True):syncdir(p)
 syncdir(C);save(root/'BOTH-ACTUAL-OBSERVATIONS-FROZEN-BEFORE-ANY-PRIVATE-COMPARISON.json',dict(files=[pin(p)for p in allfiles],streams=20,children=10,observations=2,allContentsAndDirsFsynced=True,privateExpectedReads=0,comparisonSelected=False))
 print('PASS_TWO_COMPLETE_NI_NP_OBSERVATIONS_CAPTURED_AND_DECODED',flush=True)
except BaseException as e:
 save(root/'FAILURE.json',dict(status=failure_class,error=type(e).__name__+': '+str(e),completed=[x['id']for x in completed],lastAttempt=phase['id'],record=record,observations=observations,noRetry=True,privateExpectedReads=0))
 allfiles=sorted(p for p in root.rglob('*')if p.is_file())
 for p in allfiles:
  with p.open('rb')as f:os.fsync(f.fileno())
 for p in sorted([root]+[p for p in root.rglob('*')if p.is_dir()],key=lambda p:len(p.parts),reverse=True):syncdir(p)
 syncdir(C);save(root/'ALL-FAILURE-ACTUAL-FILES-FROZEN.json',dict(files=[pin(p)for p in allfiles],privateExpectedReads=0,noRetry=True));raise
