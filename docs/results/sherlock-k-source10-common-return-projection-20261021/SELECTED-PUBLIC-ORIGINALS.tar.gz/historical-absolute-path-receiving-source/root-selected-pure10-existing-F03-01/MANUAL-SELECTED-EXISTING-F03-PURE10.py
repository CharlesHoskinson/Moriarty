from pathlib import Path
import os,sys,json,hashlib,runpy,datetime,glob,ast
sys.dont_write_bytecode=True
A=Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020')
D=A/'k-next-public-nominal-identity-source10'; C=A/'k-source10-NI-NP-Not-existing-receiver-security-source01'
H=C/'root-selected-pure10-existing-F03-01';root=C/'actual-pure10-01';cwd=root/'00-pure10'
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checked(r):
 a=pin(r['path']);assert a==r,(a,r);return a
def load(p):return json.loads(Path(p).read_bytes())
def syncdir(p):
 fd=os.open(p,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
def save(p,v):
 b=(json.dumps(v,indent=2)+'\n').encode();fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb')as f:f.write(b);f.flush();os.fsync(f.fileno())
 syncdir(p.parent)
def inventory(p):return {str(x.relative_to(p)):('directory'if x.is_dir()else'file')for x in sorted(p.rglob('*'))}
proposal=load(D/'PROPOSED-ONE-EXISTING-F03-COMPILE-DATA.json');tools=load(proposal['tools']['path']);reuse=load(D/'postcompile-actual-qualification01/COMPILED-REUSE-EXACT15.json');source=load(D/'SOURCE-FREEZE.json')
# Original expected bodies are irrelevant to these pure receiver tests and are not opened or hashed.
oldrows=load(D/'actual/FLAT-INPUT-PINS.json')['members'];excluded=[r for r in oldrows if Path(r['path']).name.startswith('EXPECTED-')];assert len(oldrows)==317 and len(excluded)==3
rows=[r for r in oldrows if r not in excluded]+reuse['products']
for n in ast.parse((C/'source10_receiving.py').read_text()).body:
 if isinstance(n,ast.Assign)and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)and(n.targets[0].id.endswith('_PIN')or n.targets[0].id=='K_SOURCE_PINS'):
  v=ast.literal_eval(n.value);rows.extend(v if isinstance(v,tuple)else[v])
for p in [C/'source10_receiving.py',C/'test_source10_receiving.py',C/'REPORT.md',C/'MACHINE-PIN-MAP-AND-DIFF-INVERSE.json',A/'k-source10-receiving-fresh-security-review01/REPORT.md',A/'k-source10-receiving-fresh-security-review01/FINDINGS.json',Path(__file__),Path('/usr/bin/python3').resolve()]:rows.append(pin(p))
assert pin(C/'source10_receiving.py')['sha256']=='5f651f3fa9ee2a8efdd4a37a7b2c3bd7096e49ee10c5cd132d1b5fbfa061bf27'
assert pin(C/'test_source10_receiving.py')['sha256']=='397dd6f3d88b3cf27f34f85e85e93b5392e2d718a0a4c99fcd65d3fc8cf185f9'
rows=sorted({r['path']:r for r in rows}.values(),key=lambda r:r['path'])
def memberships():
 out={}
 for folder,expected in [(D/'source',[r['path']for r in source['members']if '/source/'in r['path']]),(D/'tests',[r['path']for r in source['members']if '/tests/'in r['path']]),(D/'actual/programview-identity-source10-kompiled',[r['path']for r in reuse['products']])]:
  got=sorted(str(p)for p in folder.rglob('*'));assert got==sorted(expected),(str(folder),got);out[str(folder)]=got
 assert sorted(glob.glob(tools['classpath_pattern']))==sorted(r['path']for r in tools['classpath_jar_membership'])
 for r in tools['entries']:assert str(Path(r['path']).resolve(strict=True))==r['resolved_path']
 out['classpath156']=True;out['resolved4']=True;return out
pre=[checked(r)for r in rows];mem=memberships();assert not root.exists();root.mkdir(mode=0o700);cwd.mkdir(mode=0o700)
for name in ['home','tmp']:(cwd/name).mkdir(mode=0o700)
token='source10-receiver-pure10-once-20261020'
env=dict(LANG='C',LC_ALL='C',HOME=str(cwd/'home'),TMPDIR=str(cwd/'tmp'),SHERLOCK_K_ATTEMPT_TOKEN=token)
argv=['/usr/bin/python3','-I','-B','-S','-m','unittest','discover','-s',str(C),'-p','test_source10_receiving.py','-v']
command=dict(argv=argv,environment=env,cwd=str(cwd),callback=proposal['callback'],fsize=536870912,wall_seconds=30,sweep_seconds=3,noAggregateMemoryOrCpuClaim=True)
save(root/'OPERATOR-SELECTION.json',dict(selectedBy='Root explicit delegated pure10 instruction',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),manual=pin(__file__),sourceReview=pin(A/'k-source10-receiving-fresh-security-review01/REPORT.md'),exactNewPythonProcesses=1,noKNoOldPrefix=True,privateExpectedReads=0,excludedExpectedBodies=[r['path']for r in excluded],stdlibHistoricalUnpinned=True))
save(root/'PRE.json',dict(members=pre,membership=mem,python3Resolved=str(Path('/usr/bin/python3').resolve()),freshInventory=inventory(cwd)))
save(cwd/'COMMAND.json',command);syncdir(cwd);syncdir(root);syncdir(C)
api=runpy.run_path(proposal['callback']['fullsource']['path'],run_name='selected_nonmain_existing_F03_pure10');assert api['CHILD_SECONDS']==30 and api['SWEEP_SECONDS']==3
record={};api['launch'](record,argv,env,str(cwd),token,536870912);save(cwd/'RESULT.json',record)
files=sorted(p for p in cwd.rglob('*')if p.is_file())
for p in files:
 with p.open('rb')as f:os.fsync(f.fileno())
for p in [cwd/'home',cwd/'tmp',cwd,root,C]:syncdir(p)
save(root/'RAW-FROZEN-BEFORE-CLASSIFICATION.json',dict(files=[pin(p)for p in files],record=record,classificationPerformed=False))
post=[checked(r)for r in rows];mem=memberships();inv=inventory(cwd)
save(root/'POST.json',dict(members=post,membership=mem,inventory=inv))
out=(cwd/'stdout').read_bytes();err=(cwd/'stderr').read_bytes();print('FULL_STDOUT',repr(out));print('FULL_STDERR',err.decode('utf-8'));print('FULL_RECORD',json.dumps(record))
clean=record.get('returncode')==0 and record.get('outcome')=='exited'and not any(record.get(k)for k in ['timed_out','containment_breach','swept','remaining','group_members_after_exit'])
import re
ok=clean and out==b''and re.search(rb'Ran 10 tests in [0-9.]+s',err)is not None and err.rstrip().endswith(b'OK')and b'FAILED'not in err
wanted={x:'directory'for x in ['home','tmp']};wanted.update({x:'file'for x in ['COMMAND.json','RESULT.json','stdout','stderr']});ok=ok and inv==wanted
save(root/'CLASSIFICATION.json',dict(status='PASS_10_PURE_RECEIVER_TESTS'if ok else'FAIL_STOP_NO_RETRY',record=record,tests=10,stdout=pin(cwd/'stdout'),stderr=pin(cwd/'stderr'),staticPins=len(rows),allPrePostEqual=pre==post,rawDurableBeforeClassification=True,allRawStreamsRead=True,privateExpectedReads=0,noKRuntime=True,scope='bounded positive admitted-profile receiving codec tests; no model result, Core admission, native, refinement or EARS'))
save(root/'ALL-ACTUAL-FILES-FROZEN.json',dict(files=[pin(p)for p in sorted(root.rglob('*'))if p.is_file()],allContentsAndDirsFsynced=True))
for p in [cwd/'home',cwd/'tmp',cwd,root,C]:syncdir(p)
if not ok:raise SystemExit(1)
print('PASS_10_PURE_RECEIVER_TESTS')
