# Source10 NI/NP/Not K Query Renderer and Receiver Security Adaptation Report

## 1. Authoring Authority and Scope
- **Designated Security/Source Author**: `gemini-4-argon-high` (via AGY standing Opus outage fallback).
- **Write Root**: `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/k-source10-NI-NP-Not-existing-receiver-security-source01`
- **Scope**: Additive Source10 `NI`/`NP`/`Not` K query renderer (`render_source10`) and whole-observation receiver (`decode_source10`) plus positive and hostile unit tests (`test_source10_receiving.py`). No new runner/factory, no K/Cargo/SDK/native execution, and no claim of arbitrary untrusted admission, Core workclock equivalence, prefix refinement, or EARS closure.

## 2. Implementation Summary (`source10_receiving.py`)
- **Pin & Dependency Binding**: Verifies exact `bytes`/`sha256` pins before loading `ACTUAL-182-COMPILED-KLABEL-RECEIVING-REGISTRY.DATA.json`, `definition.kore`, `PUBLIC-API.json`, the 5 `.k` source files, and existing modules (`complete_k_wire.py` and `nominal_trace_codec.py` from `models/sherlock/k/nominal-full-state-20261018/capture`, plus `positive_identity_port.py` and `program_view_to_ngprogram.py` from `k-next-public-nominal-identity-source10/source`). Does not mix the two `nominal_trace_codec.py` files or trigger `c6_data.py`/`jsonv4_transport.py` import-time global side effects.
- **182-Symbol Compiled Registry Split (`validate_receiving_registry`)**: Cross-checks all 182 symbols (including the 19 new Source10 declarations) against `definition.kore` symbol headers, argument/return sorts, `[constructor{}()]` vs `[function{}()]` attributes, `Source(...)`, and `Location(...)`. Partitions symbols into `DATA_REG` (130 constructors) and `QUERY_REG` (`DATA_REG` + root-only `niRun`). Rejects all 52 function symbols in output observations and non-root query positions.
- **Bounded Explicit-Stack Codec & Guards (`DecodeBudget`)**: Enforces `max_bytes`, `max_tokens`, `max_nodes`, `max_depth`, and `max_rows` across JSON loading (`loads`/`unique_object`), `<generatedTop>/<k>` framing (`complete_term`), printed parsing (`Source10PrintedParser`), `literal`-keyed AST conversion (`from_source10_ast`/`to_source10_ast`), R2 KAST JSONv4 transport (`encode_node`/`decode_node`/`encode_query_envelope`/`decode_query_document`), and structural decoding (`Source10KWire.decode`) without Python recursion.
- **Type, Range, Order & Identity Preservation**:
  - Preserves `bool` vs `int` distinction (`same`), `None` (`niNull`), `"0"` vs `0`, empty slices/lists/objects, ordered `NPType` generic arguments, and declared `NPFields` order without sorting field names.
  - Enforces integer bounds (`UInt128` in `[0, 2**128)`, `index64` in `[0, 2**64)`, `niInt` in `(-2**128, 2**128)`) and rejects duplicate keys across JSON objects, `NIJSON` objects, `Map` environments, `NPFields`, `NPTypeRows`, `NPCtorRows`, `NGDecls`, `NGNodes`, `NGParams`, `NGArms`, and `NGBindings`.
  - Extends `Source10KWire` and `PUBLIC_API` with `ngNot`, `ngNotArgument`, `ngNotStarted`, and `ngNotReturned`, plus full `NIObservation`, `NPObservation`, `NPValue`, `NPType`, `NPCtorSchema`, and `NIJSON` decoding.

## 3. Explicit New API Inventory
- `DecodeBudget(max_bytes, max_tokens, max_nodes, max_depth, max_rows)`
- `pin(path)`, `checked(row)`, `write(path, raw)`, `unique_object(pairs)`, `loads(text, *, budget)`, `load(path, *, budget)`, `same(a, b)`
- `kore_label(raw)`, `validate_receiving_registry(data, *, definition_lines)`
- `make_term(name, *args, registry)`, `render_term(term, *, budget)`, `complete_term(text, *, budget)`
- `Source10PrintedParser(text, *, registry, budget)` and `parse_printed(text, sort, *, registry, budget)`
- `from_source10_ast(tree, *, allow_root_query, allow_map, budget)` and `to_source10_ast(term, *, allow_map, budget)`
- `encode_node(term, *, allow_root_query, budget)`, `envelope(term, *, allow_root_query, budget)`, `encode_query_envelope(term, *, budget)`
- `decode_node(value, sort, *, allow_root_query, budget)`, `decode_document(value, sort, *, allow_root_query, budget)`, `decode_query_document(value, sort, *, budget)`
- `Source10KWire(public_api, registry)` and `WIRE`
- `render_source10(source_document, observation_cut, *, budget)`
- `decode_source10(source_document, raw_kprint_text, *, budget)`
- `main(argv)` (`render` and `decode` CLI subcommands)

## 4. Wire Test Inventory (`test_source10_receiving.py`)
1. `test_01_registry_182_validation_and_split`: 182-symbol `definition.kore` check, 130 constructor vs 52 function split, 19 new Source10 symbols, and tamper rejections.
2. `test_02_render_source10_map_queue_and_mirror_arbor_roundtrips`: `render_source10` on `map-queue.json` and `mirror-arbor.json`, KAST JSONv4/AST/printed roundtrips, `[4, 1]` vs `[4, 0]` generic arg order, `Not` expression 12, and `["z_left", "a_right"]` field order.
3. `test_03_nijson_types_some_zero_null_empty_and_unicode`: `NIJSON` roundtrips for `None`, `0`, `"0"`, `bool`, empty rows/slices, and Unicode/escaped strings.
4. `test_04_np_types_values_and_declared_field_order`: Nested `NPType` and `NPFields` order preservation plus duplicate field rejection.
5. `test_05_decode_source10_complete_state_env_frames_and_not_events`: Whole `niObserved` decode with distinct live/saved `Map` environments, `ngNotArgument` + `ngArmScope` frames, `ngLiteralEvaluated` + `ngNotStarted` + `ngNotReturned` + `ngFinished` events, and source mismatch rejection.
6. `test_06_reject_residual_functions_and_unreduced_k_cells`: Rejects residual functions (`niRun`, `npRunReference`, `niSource`, `niLawRawPresence`) and malformed/unreduced `<k>` cells.
7. `test_07_reject_r2_value_ast_and_bare_or_parametric_kast_labels`: Rejects R2 `value`-keyed AST, bare/raw-KORE/parametric `KLabel`s, and noncanonical `KToken` lexemes.
8. `test_08_reject_bool_int_confusion_and_integer_ranges`: Rejects `bool`/`int` confusion and `UInt128`/`index64`/`niInt` out-of-range integers.
9. `test_09_reject_duplicate_keys_and_enforced_decode_budgets`: Rejects duplicate keys (`JSON`, `NIJSON`, `Map`, `NPTypeRows`, `NPCtorRows`) and `DecodeBudget` breaches (`max_bytes`, `max_tokens`, `max_depth`, `max_rows`, `max_nodes`).
10. `test_10_reject_nested_nirun_sort_arity_and_ng_duplicates`: Rejects nested `niRun`, non-`niRun` query roots, sort/arity mismatches, and duplicate IDs in `NGDecls`/`NGNodes`/`NGParams`/`NGArms`/`NGBindings`.

## 5. Evidence vs Acceptance Status
- **Implementation**: Complete in candidate directory; all 25 inline preimages, `SOURCE-FREEZE.json`, and 15 compiled products verified byte-unchanged; 0 private expected semantic return files opened.
- **Observed Validation**: Static Python `ast.parse` and SHA-256 pin verification passed. Existing 8 positive Python tests passed previously under Root (`root-actual-positive-python8-01`) and were not re-run. All 10 new unit tests in `test_source10_receiving.py`, the 3 K structural laws, and the 2 whole NI observations remain **UNRUN**.
- **Acceptance**: Pending fresh independent security audit and Root execution selection.
