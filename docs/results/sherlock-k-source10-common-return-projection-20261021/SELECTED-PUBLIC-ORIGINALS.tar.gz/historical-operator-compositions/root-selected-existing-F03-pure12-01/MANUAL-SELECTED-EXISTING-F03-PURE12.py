from pathlib import Path
import os,sys,json,hashlib,runpy,datetime,glob,ast
sys.dont_write_bytecode=True
A=Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020')
D=A/'k-next-public-nominal-identity-source10'; C=A/'k-source10-NI-NP-Not-existing-receiver-security-source01'
H=C/'root-selected-pure10-existing-F03-01';root=C/'actual-pure10-01';cwd=root/'00-pure10'
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checked(r):
 a=pin(r['path']);assert a==r,(a,r);return a
def load(p):return json.loads(Path(p).read_bytes())
def syncdir(p):
 fd=os.open(p,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
def save(p,v):
 b=(json.dumps(v,indent=2)+'\n').encode();fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb')as f:f.write(b);f.flush();os.fsync(f.fileno())
 syncdir(p.parent)
def inventory(p):return {str(x.relative_to(p)):('directory'if x.is_dir()else'file')for x in sorted(p.rglob('*'))}
N=A/'k-source10-common-return-semantic-projection-source02'; C=A/'k-source10-NI-NP-Not-existing-receiver-security-source01'
H=N/'root-selected-existing-F03-pure12-01';root=N/'actual-pure12-01';cwd=root/'00-pure12'
proposal=load(D/'PROPOSED-ONE-EXISTING-F03-COMPILE-DATA.json');tools=load(proposal['tools']['path']);reuse=load(D/'postcompile-actual-qualification01/COMPILED-REUSE-EXACT15.json');source=load(D/'SOURCE-FREEZE.json')
freeze=load(N/'FINAL-SOURCE-FREEZE.json');mapping=load(N/'FINAL-ADD-ONLY-MAP-AND-INVERSE.json');assert len(freeze['members'])==10 and len(mapping['members'])==11
rows=load(C/'actual-pure10-01/POST.json')['members']+[x['after']for x in mapping['members']]
for p in [N/'FINAL-ADD-ONLY-MAP-AND-INVERSE.json',A/'k-source10-common-return-projection-fresh-review01/FINAL-RESPONSE.txt',Path(__file__)]:rows.append(pin(p))
rows=sorted({r['path']:r for r in rows}.values(),key=lambda r:r['path'])
assert pin(N/'source/common_return_projection.py')['sha256']=='643b83f11cc622cb806f46c18f735718e79a68d1747551be017122ae8f5579ea'
assert pin(N/'tests/test_common_return_projection.py')['sha256']=='438859dbbc1999d6ac0e6f72d34ef12ee54457535f6d7b9c063a7f3b6239a021'
assert pin(A/'k-source10-common-return-projection-fresh-review01/FINAL-RESPONSE.txt')['sha256']=='9f00293b3993a5984f81822d8128274aa02c3e3212c7cc5fce1c5fb3865a1bd7'
def memberships():
 out={}
 for folder,expected in [(D/'source',[r['path']for r in source['members']if '/source/'in r['path']]),(D/'tests',[r['path']for r in source['members']if '/tests/'in r['path']]),(D/'actual/programview-identity-source10-kompiled',[r['path']for r in reuse['products']])]:
  got=sorted(str(p)for p in folder.rglob('*'));assert got==sorted(expected);out[str(folder)]=got
 assert sorted(str(p)for p in(N/'source').rglob('*'))==[str(N/'source/common_return_projection.py')]
 assert sorted(str(p)for p in(N/'tests').rglob('*'))==[str(N/'tests/test_common_return_projection.py')]
 assert sorted(glob.glob(tools['classpath_pattern']))==sorted(r['path']for r in tools['classpath_jar_membership'])
 for r in tools['entries']:assert str(Path(r['path']).resolve(strict=True))==r['resolved_path']
 return out
pre=[checked(r)for r in rows];mem=memberships();assert not root.exists();root.mkdir(mode=0o700);cwd.mkdir(mode=0o700)
for name in ['home','tmp']:(cwd/name).mkdir(mode=0o700)
token='source10-common-return-pure12-once-20261021';env=dict(LANG='C',LC_ALL='C',HOME=str(cwd/'home'),TMPDIR=str(cwd/'tmp'),SHERLOCK_K_ATTEMPT_TOKEN=token)
argv=['/usr/bin/python3','-I','-B','-S','-m','unittest','discover','-s',str(N/'tests'),'-p','test_common_return_projection.py','-v']
save(root/'OPERATOR-SELECTION.json',dict(selectedBy='Root explicit new12-only instruction',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),manual=pin(__file__),review=pin(A/'k-source10-common-return-projection-fresh-review01/FINAL-RESPONSE.txt'),privateExpectedReads=0,sourceApprovalSeparate=True,freezeNonselfMembers=10,mappedFilesIncludingFreeze=11,noPrefixReplay=True))
save(root/'PRE.json',dict(members=pre,membership=mem));save(cwd/'COMMAND.json',dict(argv=argv,environment=env,cwd=str(cwd),callback=proposal['callback'],wall_seconds=30,sweep_seconds=3,fsize=536870912))
api=runpy.run_path(proposal['callback']['fullsource']['path'],run_name='selected_nonmain_existing_F03_projection_pure12');assert api['CHILD_SECONDS']==30 and api['SWEEP_SECONDS']==3
record={};api['launch'](record,argv,env,str(cwd),token,536870912);save(cwd/'RESULT.json',record)
files=sorted(p for p in cwd.rglob('*')if p.is_file())
for p in files:
 with p.open('rb')as f:os.fsync(f.fileno())
for p in [cwd/'home',cwd/'tmp',cwd,root,N]:syncdir(p)
save(root/'RAW-FROZEN-BEFORE-CLASSIFICATION.json',dict(files=[pin(p)for p in files],record=record,classificationPerformed=False))
post=[checked(r)for r in rows];mem=memberships();inv=inventory(cwd);save(root/'POST.json',dict(members=post,membership=mem,inventory=inv))
out=(cwd/'stdout').read_bytes();err=(cwd/'stderr').read_bytes();print('FULL_STDOUT',repr(out));print('FULL_STDERR',err.decode());print('FULL_RECORD',json.dumps(record))
clean=record.get('returncode')==0 and record.get('outcome')=='exited'and not any(record.get(k)for k in ['timed_out','containment_breach','swept','remaining','group_members_after_exit'])
import re
wanted={x:'directory'for x in ['home','tmp']};wanted.update({x:'file'for x in ['COMMAND.json','RESULT.json','stdout','stderr']})
ok=clean and inv==wanted and out==b''and re.search(rb'Ran 12 tests in [0-9.]+s',err)is not None and err.rstrip().endswith(b'OK')and b'FAILED'not in err
save(root/'CLASSIFICATION.json',dict(status='PASS_12_PURE_RETURN_PROJECTION_TESTS'if ok else'FAIL_STOP_NO_RETRY',record=record,tests=12,positiveCases=10,stdout=pin(cwd/'stdout'),stderr=pin(cwd/'stderr'),staticPins=len(rows),allPrePostEqual=pre==post,rawDurableBeforeClassification=True,allRawStreamsRead=True,privateExpectedReads=0,scope='same-author synthetic ordinary positive return projection only; no state/event/admission/refinement/native/EARS'))
save(root/'ALL-ACTUAL-FILES-FROZEN.json',dict(files=[pin(p)for p in sorted(root.rglob('*'))if p.is_file()],allContentsAndDirsFsynced=True))
for p in [cwd/'home',cwd/'tmp',cwd,root,N]:syncdir(p)
if not ok:raise SystemExit(1)
print('PASS_12_PURE_RETURN_PROJECTION_TESTS')
