"""Root-selected finite call composition of already reviewed pure functions."""
from pathlib import Path
import sys,runpy,json
sys.dont_write_bytecode=True
A=Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020');D=A/'k-next-public-nominal-identity-source10';N=A/'k-source10-common-return-semantic-projection-source02';C=A/'k-source10-NI-NP-Not-existing-receiver-security-source01';E=A/'nominal-programview-identity-independent-expectations01';T=C/'actual-two-whole-observations01';OUT=N/'actual-return-only-comparison01/00-existing-project-and-compare'
wire=runpy.run_path(str(C/'source10_receiving.py'),run_name='root_selected_existing_receiver_functions')
project=runpy.run_path(str(N/'source/common_return_projection.py'),run_name='root_selected_reviewed_pure_projection')['project_return_pair']
load=wire['load'];same=wire['same'];checked=wire['checked'];write=wire['write']
barrier=load(T/'BOTH-ACTUAL-OBSERVATIONS-FROZEN-BEFORE-ANY-PRIVATE-COMPARISON.json');assert len(barrier['files'])==95
for row in barrier['files']:checked(row)
manifest=load(E/'MANIFEST.json')
for row in manifest['members']:checked(dict(path=str(E/row['path']),bytes=row['bytes'],sha256=row['sha256']))
opened=[];completed=[];status='RETURN_COMPARISON_INFRASTRUCTURE_FAILURE';first_difference=None
try:
 opened.append('EXPECTED-COMPLETE-LOGICAL-RETURNS.json');expected=load(E/'EXPECTED-COMPLETE-LOGICAL-RETURNS.json')
 for index,name in enumerate(['map-queue','mirror-arbor']):
  opened.append('EXPECTED-'+name+'-BINDINGS.json');binding=load(E/('EXPECTED-'+name+'-BINDINGS.json'))
  actual_path=T/(str(index).zfill(2)+'-'+name)/'04-whole-decode/complete-observation.json';actual=load(actual_path);original_input=load(D/'inputs'/(name+'.json'))
  identity=same(actual['source_document'],original_input)
  source23=same(actual['source_document']['program_view'],binding['originalProgramViewExact'])
  source_digest=same(actual['source_document']['source_digest'],binding['sourceSha256'])
  retained_np=same(actual['np_observation']['value'],actual['np_value'])
  retained_state=same(actual['np_observation']['state'],actual['ng_state'])
  if not all([identity,source23,source_digest,retained_np,retained_state]):
   first_difference={'case_id':name,'selector':'source_identity_or_retained_complete_capture_fields'};status='SOURCE_OR_CAPTURE_IDENTITY_MISMATCH';raise RuntimeError('Existing identity equality failed; no values disclosed')
  ported=wire['_port10'].port_positive(actual['source_document'])
  projected=project(actual['np_value'],actual['ng_state']['control']['ngHalted']['value'],ported)
  output=write(OUT/('ACTUAL-PROJECTED-'+name+'.json'),(json.dumps(projected,indent=2,allow_nan=False)+'\n').encode())
  expected_case=next(row for row in expected['cases']if row['case']==name)
  equal=same(projected,expected_case['result'])
  result=dict(case_id=name,wholeRecursiveLogicalReturnEqual=equal,source23Exact=source23,wholeSourceIdentityExact=identity,sourceDigestExact=source_digest,retainedNPAndNGStateIdentityExact=retained_np and retained_state,actualProjection=output,actualCapture=wire['pin'](actual_path),expectedBodyPublished=False)
  completed.append(result)
  if not equal:
   first_difference={'case_id':name,'selector':'independent .cases[case].result vs complete ACTUAL-PROJECTED result root; existing equality returns Bool only'};status='WHOLE_TYPED_RETURN_MISMATCH';raise RuntimeError('Existing strict typed whole-return equality failed; no values disclosed')
 status='PASS_BOTH_COMPLETE_LOGICAL_RETURN_TREES_AND_SOURCE23_IDENTITY'
except BaseException:
 report=dict(status=status,cases=completed,firstDifference=first_difference,privateExpectedSemanticReads=len(opened),openedPrivateBasenames=opened,all95FrozenActualsCheckedBeforePrivateRead=True,noWholeStateOrEventOracle=True,authorExposed=True,noKOrOwnerExecution=True)
 write(OUT/'COMPARISON-REPORT.json',(json.dumps(report,indent=2)+'\n').encode());raise
report=dict(status=status,cases=completed,firstDifference=None,privateExpectedSemanticReads=len(opened),openedPrivateBasenames=opened,all95FrozenActualsCheckedBeforePrivateRead=True,noWholeStateOrEventOracle=True,authorExposed=True,noKOrOwnerExecution=True,scope='Complete recursive source logical return and source23 identity only; retained logical state/events not independently compared, not Core fuel/workclock/admission/StepInv/refinement/native/EARS')
product=write(OUT/'COMPARISON-REPORT.json',(json.dumps(report,indent=2)+'\n').encode())
print(json.dumps(dict(status=status,cases=completed,privateExpectedSemanticReads=len(opened),report=product,noWholeStateOrEventOracle=True)))
