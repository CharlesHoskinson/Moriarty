from pathlib import Path
import os,sys,json,hashlib,runpy,datetime,glob,ast
sys.dont_write_bytecode=True
A=Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020')
D=A/'k-next-public-nominal-identity-source10'; C=A/'k-source10-NI-NP-Not-existing-receiver-security-source01'
H=C/'root-selected-pure10-existing-F03-01';root=C/'actual-pure10-01';cwd=root/'00-pure10'
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checked(r):
 a=pin(r['path']);assert a==r,(a,r);return a
def load(p):return json.loads(Path(p).read_bytes())
def syncdir(p):
 fd=os.open(p,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
def save(p,v):
 b=(json.dumps(v,indent=2)+'\n').encode();fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb')as f:f.write(b);f.flush();os.fsync(f.fileno())
 syncdir(p.parent)
def inventory(p):return {str(x.relative_to(p)):('directory'if x.is_dir()else'file')for x in sorted(p.rglob('*'))}
N=A/'k-source10-common-return-semantic-projection-source02';C=A/'k-source10-NI-NP-Not-existing-receiver-security-source01';E=A/'nominal-programview-identity-independent-expectations01';T=C/'actual-two-whole-observations01'
H=N/'root-selected-existing-return-comparison01';root=N/'actual-return-only-comparison01';cwd=root/'00-existing-project-and-compare';call=H/'EXISTING-PROJECT-AND-TYPED-SAME-CALLS.revision02-source-path.py'
proposal=load(D/'PROPOSED-ONE-EXISTING-F03-COMPILE-DATA.json');barrier=load(T/'BOTH-ACTUAL-OBSERVATIONS-FROZEN-BEFORE-ANY-PRIVATE-COMPARISON.json');assert len(barrier['files'])==95
assert load(N/'actual-pure12-01/CLASSIFICATION.json')['status']=='PASS_12_PURE_RETURN_PROJECTION_TESTS'
manifest=load(E/'MANIFEST.json');oracleRows=[dict(path=str(E/r['path']),bytes=r['bytes'],sha256=r['sha256'])for r in manifest['members']]
rows=load(N/'actual-pure12-01/POST.json')['members']+barrier['files']+oracleRows
for p in [Path(__file__),call,H/'PRESELECTION-CALL-DATA-KEY-CORRECTION.json',T/'BOTH-ACTUAL-OBSERVATIONS-FROZEN-BEFORE-ANY-PRIVATE-COMPARISON.json',N/'actual-pure12-01/CLASSIFICATION.json',E/'MANIFEST.json',E/'EXPECTATION-FREEZE.json']:rows.append(pin(p))
rows=sorted({r['path']:r for r in rows}.values(),key=lambda r:r['path'])
pre=[checked(r)for r in rows];assert not root.exists();root.mkdir(mode=0o700);cwd.mkdir(mode=0o700)
for name in ['home','tmp']:(cwd/name).mkdir(mode=0o700)
token='source10-both-complete-return-only-compare-once-20261021';env=dict(LANG='C',LC_ALL='C',HOME=str(cwd/'home'),TMPDIR=str(cwd/'tmp'),SHERLOCK_K_ATTEMPT_TOKEN=token);argv=['/usr/bin/python3','-I','-B','-S',str(call)]
save(root/'OPERATOR-SELECTION.json',dict(selectedBy='Root explicit after-new12-pass return-only comparison instruction',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),manual=pin(__file__),call=pin(call),all95ActualsCurrentBeforeExpectedSemanticRead=True,prePrivateExpectedHashesOnly=True,sourceExposed=True,noKOrOwnerOrPrefixRerun=True,noNewComparator=True,existingTypedEquality='source10_receiving.same',projection='reviewed project_return_pair',noWholeStateOrEventOracle=True))
save(root/'PRE.json',dict(members=pre,actual95Current=True,originalOracle11Current=True));save(cwd/'COMMAND.json',dict(argv=argv,environment=env,cwd=str(cwd),callback=proposal['callback'],wall_seconds=30,sweep_seconds=3,fsize=536870912))
api=runpy.run_path(proposal['callback']['fullsource']['path'],run_name='selected_nonmain_existing_F03_return_only_compare');assert api['CHILD_SECONDS']==30 and api['SWEEP_SECONDS']==3
record={};api['launch'](record,argv,env,str(cwd),token,536870912);save(cwd/'RESULT.json',record)
files=sorted(p for p in cwd.rglob('*')if p.is_file())
for p in files:
 with p.open('rb')as f:os.fsync(f.fileno())
for p in [cwd/'home',cwd/'tmp',cwd,root,N]:syncdir(p)
save(root/'RAW-FROZEN-BEFORE-CLASSIFICATION.json',dict(files=[pin(p)for p in files],record=record,classificationPerformed=False))
post=[checked(r)for r in rows];inv=inventory(cwd);save(root/'POST.json',dict(members=post,inventory=inv,privateExpectedPinsUnchanged=True,all95ActualPinsUnchanged=True))
out=(cwd/'stdout').read_bytes();err=(cwd/'stderr').read_bytes();print('FULL_STDOUT',out.decode());print('FULL_STDERR',err.decode());print('FULL_RECORD',json.dumps(record))
clean=record.get('returncode')==0 and record.get('outcome')=='exited'and not any(record.get(k)for k in ['timed_out','containment_breach','swept','remaining','group_members_after_exit'])
report=load(cwd/'COMPARISON-REPORT.json')if(cwd/'COMPARISON-REPORT.json').exists()else None
ok=clean and not err and report is not None and report['status']=='PASS_BOTH_COMPLETE_LOGICAL_RETURN_TREES_AND_SOURCE23_IDENTITY'
if ok:
 stdout=json.loads(out);assert stdout['status']==report['status']and len(report['cases'])==2
 for result in report['cases']:
  assert all(result[k]is True for k in ['wholeRecursiveLogicalReturnEqual','source23Exact','wholeSourceIdentityExact','sourceDigestExact','retainedNPAndNGStateIdentityExact']);checked(result['actualProjection']);checked(result['actualCapture'])
 assert report['privateExpectedSemanticReads']==3 and report['noWholeStateOrEventOracle']is True
wanted={x:'directory'for x in ['home','tmp']};wanted.update({x:'file'for x in ['COMMAND.json','RESULT.json','stdout','stderr','COMPARISON-REPORT.json','ACTUAL-PROJECTED-map-queue.json','ACTUAL-PROJECTED-mirror-arbor.json']});ok=ok and inv==wanted
save(root/'CLASSIFICATION.json',dict(status='PASS_BOTH_COMPLETE_RETURN_TREES_AND_SOURCE23_IDENTITY_ONLY'if ok else'FAIL_STOP_NO_RETRY',record=record,comparisonReport=pin(cwd/'COMPARISON-REPORT.json')if report else None,staticPins=len(rows),allPrePostEqual=pre==post,privateExpectedSemanticReads=report.get('privateExpectedSemanticReads')if report else'UNKNOWN_EXCEPTION_RETAINED_FULL_STREAMS',allRawStreamsRead=True,rawDurableBeforeClassification=True,sourceExposed=True,noWholeStateOrEventOracle=True,scope='complete recursively ordered typed return and source23 identity only; no logical state/event oracle, Core admission/fuel/workclock, StepInv/refinement/native/EARS'))
save(root/'ALL-ACTUAL-FILES-FROZEN.json',dict(files=[pin(p)for p in sorted(root.rglob('*'))if p.is_file()],allContentsAndDirsFsynced=True))
for p in [cwd/'home',cwd/'tmp',cwd,root,N]:syncdir(p)
if not ok:raise SystemExit(1)
print('PASS_BOTH_COMPLETE_RETURN_TREES_AND_SOURCE23_IDENTITY_ONLY')
