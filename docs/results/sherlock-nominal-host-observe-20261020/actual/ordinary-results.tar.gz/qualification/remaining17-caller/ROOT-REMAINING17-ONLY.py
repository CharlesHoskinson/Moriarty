"""Literal Root composition for original operations02..18 only; UNSELECTED.
Reuses unchanged existing capture/static/pin/dep functions. No Core dispatch,
private expected access, normalization, provider, SDK/native or subprocess code.
"""
from pathlib import Path
import argparse, hashlib, json, os, re, runpy, stat, sys
sys.dont_write_bytecode = True
B = Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/public-nominal-observe-source-plan-20261020/ordinary-build-and-capture-preparation-01')
P = B / 'remaining17-retained-composition-01'
A = B / 'actual-remaining17-01'
CONFIG = dict(path=str(P / 'INPUTS.json'), bytes=14283,
              sha256='9c6c9c40229fd92596a5470a0dae78dc756f9cd9662ac0e1e1484ae493782c59')


def load(path):
    return json.loads(Path(path).read_text())


def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def check(row):
    actual = pin(row['path'])
    if any(actual[k] != row[k] for k in ('path', 'bytes', 'sha256')):
        raise ValueError('pin drift: ' + row['path'])
    if 'mode' in row and stat.S_IMODE(Path(row['path']).lstat().st_mode) != int(row['mode'], 8):
        raise ValueError('mode drift: ' + row['path'])
    return actual


def syncdir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def freeze(path, mode=0o400):
    path = Path(path)
    path.chmod(mode)
    with path.open('rb') as stream:
        os.fsync(stream.fileno())


def put(path, value):
    path = Path(path)
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode())
        stream.flush()
        os.fsync(stream.fileno())
    freeze(path)
    syncdir(path.parent)


def external_inventory(spec):
    answer = []
    for dr in spec['directories']:
        path = Path(dr['directory'])
        if sorted(x.name for x in path.iterdir()) != sorted(x['name'] for x in dr['entries']):
            raise ValueError('external L membership drift: ' + str(path))
        for row in dr['entries']:
            item = path / row['name']
            info = item.lstat()
            if (stat.S_ISLNK(info.st_mode) != row['symlink']
                    or stat.S_ISREG(info.st_mode) != row['regularFile']
                    or oct(stat.S_IMODE(info.st_mode)) != row['mode'] or info.st_size != row['size']):
                raise ValueError('external L entry drift: ' + str(item))
            if row['symlink'] and os.readlink(item) != row['linkTarget']:
                raise ValueError('external L link drift: ' + str(item))
            if 'qualifiedLibrary' in row:
                check(row['qualifiedLibrary'])
        answer.append(dict(directory=str(path), count=len(dr['entries']), exact=True))
    return answer


def exact_test(op, phase):
    name = op['expected']['selected']
    filtered = op['expected']['filteredOut']
    if (phase / 'stderr.bin').read_bytes() != b'':
        raise ValueError('unexpected selected-test stderr')
    # Existing serial libtest envelope, with this selected consumer's9/20 count.
    pattern = (r'\nrunning 1 test\ntest ' + re.escape(name) + r' \.\.\. ok\n\n'
               r'test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; '
               + str(filtered) + r' filtered out; finished in \d+\.\d+s\n\n')
    if re.fullmatch(pattern, (phase / 'stdout.bin').read_text()) is None:
        raise ValueError('not exact selected-test envelope: ' + name)
    return dict(selected=name, passed=1, failed=0, ignored=0, measured=0, filteredOut=filtered)


def main(selection_path):
    if Path(selection_path) != P / 'ROOT-REMAINING17-SELECTION.json':
        raise ValueError('not retained Root selection path')
    selection = load(selection_path)
    if not (selection['authorized_remaining17_once'] is True
            and selection['Root_read_retained_caller'] is True
            and selection['Root_read_full_review'] is True
            and selection['no_Core_prefix_replay'] is True
            and selection['private_expected_bodies_unread'] is True
            and selection['same_existing_ordinary_caps'] is True):
        raise ValueError('not separately selected exact remainder')
    check(selection['caller'])
    if selection['caller'] != pin(__file__) or selection['inputs'] != CONFIG:
        raise ValueError('caller/config binding mismatch')
    check(CONFIG)
    config = load(CONFIG['path'])
    for row in config['controls'] + config['basis_sources']:
        check(row)
    check(config['helper'])
    if config['helper']['sha256'] != '713119d9400f82d559967e4296313cec8cde7125dc91a74152500577ced00626':
        raise ValueError('not unchanged accepted capture helper')
    if selection['review'] != config['review_report']:
        raise ValueError('not the actual fresh remaining17 review')
    rv = load(config['review_result']['path'])
    if (rv['actualExit'] != 0 or rv['terminal']['terminal'] != 'completed'
            or rv['finalSHA'] != 'fbff91f3982e9af9ddb59b222ea59ec3074b7cf0df3f7d3c5b86f8906eb887ae'
            or rv['requestedModel'] != 'muse-wonder-1.0' or rv['effort'] != 'high'
            or 'APPROVE_ELIGIBLE_WITH_LIMITS' not in Path(config['review_report']['path']).read_text()):
        raise ValueError('fresh actual Muse review is not eligible')
    old = load(config['original_operations']['path'])['operations']
    ops = load(config['remaining_operations']['path'])['operations']
    if (len(ops) != 17 or ops != old[1:] or [x['id'] for x in ops] != config['operation_ids']
            or selection['selected_operation_ids'] != config['operation_ids']):
        raise ValueError('must select exactly original02..18, noCore')
    for op in ops:
        if (op['wallSeconds'] != 30 or op['cpuSeconds'] != 25
                or op['addressSpaceBytes'] != 2147483648 or op['fileSizeBytes'] != 67108864
                or op['keptBytesPerStream'] != 131072 or not op['serialFailStopNoRetry']
                or op['stdin'] != 'DEVNULL'):
            raise ValueError('original ordinary limits changed')
    core = load(config['Core_outcome']['path'])
    core_freeze = load(config['Core_freeze']['path'])
    if (not core['accepted'] or core['actual']['actual_exit'] != 0
            or core['actual']['controller_failure'] is not None
            or core['normalDependencies'] != 115 or core['staticPins'] != 687
            or core_freeze['status'] != 'ACCEPTED_NEW_CORE_AND_DEPINFO_FROZEN_0400'
            or core_freeze['files'] != config['qualified_Core']):
        raise ValueError('new normal Core is not qualified/frozen')
    h = runpy.run_path(config['helper']['path'], run_name='root_existing_capture_functions_only')
    flat = load(config['static']['path'])['files']
    if len(flat) != 687:
        raise ValueError('not exact687 source/tool/current-public closure')
    external = load(config['external_L']['path'])
    if len(external['directories']) != 3:
        raise ValueError('not three fixed external inventories')
    consumers = load(config['consumer_deps']['path'])['consumers']
    stable = {x['path']: x for x in config['qualified_Core']}
    generated = {}
    artifacts = []
    cwd = Path(ops[0]['cwd'])
    build = cwd / 'build'

    def readback(pending=()):
        for row in config['controls'] + config['basis_sources']:
            check(row)
        current = h['static_check'](flat)
        fixed = external_inventory(external)
        outputs = [check(x) for x in list(stable.values()) + list(generated.values()) + artifacts]
        accepted = set(stable) | set(generated)
        names = {str(x) for x in build.iterdir()}
        # Pending link names are not accepted or hashed until rawsuccess+deps.
        if not accepted <= names or not names <= accepted | set(pending):
            raise ValueError('unexpected generated L directory membership')
        for name in names:
            if not stat.S_ISREG(Path(name).lstat().st_mode):
                raise ValueError('generated member not regular: ' + name)
        return dict(all_match=current['all_match'], static=current, externalL=fixed,
                    actualGeneratedMembers=sorted(names), pendingUnqualifiedNames=list(pending),
                    acceptedOutputs=outputs)

    if A.exists() or A.is_symlink():
        raise ValueError('remaining17 actual attempt already exists; no retry')
    if {str(x) for x in build.iterdir()} != set(stable):
        raise ValueError('initial build is not exact accepted Core pair')
    for row in stable.values():
        check(row)
    for op in ops:
        if op['cwd'] != str(cwd) or set(op['environment']) != {'PATH', 'LANG', 'TMPDIR'}:
            raise ValueError('not declared ordinary cwd/environment')
        if op['environment']['PATH'] != '/usr/bin:/bin' or op['environment']['LANG'] != 'C.UTF-8':
            raise ValueError('not exact clean environment')
        for output in op['outputs']:
            if Path(output).exists() or Path(output).is_symlink():
                raise ValueError('remaining output already exists: ' + output)
    for op in ops[-2:]:
        if Path(op['argv'][-1]).exists() or Path(op['argv'][-1]).is_symlink():
            raise ValueError('final capture NEWDIR already exists')
    initial = readback()
    if not initial['all_match']:
        raise ValueError('initial static drift')
    # Existing Core/build/tmp/core retained; only absent container paths created.
    dirs = load(config['mode_directory_data']['path'])['create_if_absent_container_paths']
    for name in dirs:
        path = Path(name)
        if path.exists():
            if not path.is_dir() or path.is_symlink() or any(path.iterdir()):
                raise ValueError('ordinary container not empty regular directory: ' + name)
        else:
            path.mkdir(mode=0o700)
        syncdir(path)
        syncdir(path.parent)
    A.mkdir(mode=0o700)
    syncdir(A.parent)
    put(A / 'ROOT-SELECTION.json', dict(selection=selection, caller=pin(__file__), config=CONFIG,
        exactOriginalOperationObjects=ops, helper=config['helper'], review=config['review_report'],
        qualifiedCore=config['qualified_Core'], noCoreReplay=True, privateExpectedBodiesRead=False,
        sameExistingOrdinaryCaps=True, scope='Remaining17 ordinary handlers/captures only'))
    put(A / 'INITIAL-READBACK.json', initial)
    receipts = []
    listed = False
    failure = None
    try:
        for op in ops:
            number = int(op['id'][:2])
            phase = A / f'{number:02d}'
            phase.mkdir(mode=0o700)
            pre = readback()
            put(phase / 'PRE-PIN-CHECK.json', pre)
            if not pre['all_match']:
                raise ValueError('pre-operation drift')
            is_link = number in (2, 14, 16)
            if is_link:
                for output in op['outputs']:
                    if Path(output).exists() or Path(output).is_symlink():
                        raise ValueError('link output exists before its operation')
            else:
                binary = op['argv'][op['argv'].index('--') + 1]
                if binary not in generated:
                    raise ValueError('consumer binary not actually qualified')
                check(generated[binary])
            if 4 <= number <= 13 and not listed:
                raise ValueError('exact10 list not yet accepted')
            raw = h['capture'](op, phase)
            put(phase / 'RESULT.json', raw)
            receipts.append(raw)
            # Complete command/streams/raw RESULT fsync BEFORE any assertions.
            for item in phase.iterdir():
                if item.is_file():
                    freeze(item)
            syncdir(phase)
            post = readback(op['outputs'] if is_link else ())
            put(phase / 'POST-PIN-CHECK.json', post)
            if not post['all_match']:
                raise ValueError('post-operation source/tool drift')
            if (raw['actual_exit'] != 0 or raw['controller_failure'] is not None
                    or len(raw['streams']) != 2
                    or not all(x['full_stream_retained'] and x['bytes'] == x['bytes_seen'] == x['bytes_retained']
                               for x in raw['streams'])):
                raise ValueError('raw child/controller/stream failure')
            details = {}
            if is_link:
                if (phase / 'stdout.bin').read_bytes() != b'':
                    raise ValueError('unexpected compiler stdout')
                binary, dep = map(Path, op['outputs'])
                for item in (binary, dep):
                    if not stat.S_ISREG(item.lstat().st_mode) or not 0 < item.stat().st_size <= 67108864:
                        raise ValueError('missing/nonregular/empty/oversized link output')
                consumer = binary.name
                spec = consumers[consumer]
                expected_count = 8 if number == 16 else 9
                if spec['count'] != expected_count:
                    raise ValueError('not reviewed consumer dep count')
                allowed = {str(Path(x['path']).resolve(strict=True)): x for x in spec['files']}
                if len(allowed) != expected_count:
                    raise ValueError('not exact consumer source membership')
                rows = h['dep_inputs'](dep, allowed)
                canonical = {str(Path(x['selected_binding']).resolve(strict=True)) for x in rows}
                if canonical != set(allowed):
                    raise ValueError('actual canonical selected_binding coverage mismatch')
                put(phase / 'ACTUAL-CONSUMER-DEPENDENCIES.json', dict(
                    literalRows=rows, canonicalSelectedBindings=sorted(canonical),
                    exactCanonicalSourceCount=expected_count, noEnvDeps=True, aliasesPreserved=True))
                freeze(binary, 0o500)
                freeze(dep)
                syncdir(build)
                new = [dict(pin(binary), mode='0500'), dict(pin(dep), mode='0400')]
                generated.update({x['path']: x for x in new})
                details['qualifiedConsumerOutputs'] = new
            elif number == 3:
                if (phase / 'stderr.bin').read_bytes() != b'':
                    raise ValueError('unexpected list stderr')
                lines = (phase / 'stdout.bin').read_text().splitlines()
                names = [x[:-6] for x in lines if x.endswith(': test')]
                rest = [x for x in lines if x and not x.endswith(': test')]
                if (len(names) != 10 or len(set(names)) != 10
                        or set(names) != set(op['expected']['exactTestNames'])
                        or rest != ['10 tests, 0 benchmarks']):
                    raise ValueError('actual list not exact10/zero benchmarks')
                listed = True
                details['actualExactTenTestNames'] = names
            elif 4 <= number <= 13 or number == 15:
                details['actualExactTest'] = exact_test(op, phase)
            else:
                artifact = Path(op['outputs'][0])
                if not stat.S_ISREG(artifact.lstat().st_mode) or artifact.stat().st_size == 0:
                    raise ValueError('missing/nonregular/empty full publication')
                if {x.name for x in artifact.parent.iterdir()} != {'sherlock-artifact.json'}:
                    raise ValueError('publication contains missing/extra/staging files')
                # Freeze and sync whole original file BEFORE byte correspondence.
                freeze(artifact)
                syncdir(artifact.parent)
                syncdir(artifact.parent.parent)
                if (phase / 'stdout.bin').read_bytes() != artifact.read_bytes() + b'\n':
                    raise ValueError('stdout not full original artifact+one newline')
                row = dict(pin(artifact), mode='0400')
                artifacts.append(row)
                details['fullPublishedArtifact'] = row
                details['independentComparison'] = 'NOT_PERFORMED; no private bodies read'
            details['finalReadback'] = readback()
            if not details['finalReadback']['all_match']:
                raise ValueError('acceptance currentness drift')
            put(phase / 'ACCEPTANCE.json', details)
            print(json.dumps(dict(id=op['id'], status='PASS', seconds=raw['elapsed_seconds'])), flush=True)
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        put(A / 'FAILURE.json', dict(error=failure, noRetry=True, noCoreReplay=True,
                                   expectedBodiesRead=False, rawReceiptsUnchanged=True))
    finally:
        partials = []
        if failure:
            known = set(stable) | set(generated) | {x['path'] for x in artifacts}
            for directory in (build, cwd / 'tmp', cwd / 'retained-artifacts'):
                if directory.exists():
                    for item in sorted(directory.rglob('*')):
                        info = item.lstat()
                        if stat.S_ISREG(info.st_mode) and str(item) not in known:
                            freeze(item)
                            partials.append(dict(path=str(item), bytes=info.st_size, mode='0400',
                                                 status='UNHASHED_UNCONSUMED_NON_ARTIFACT'))
        passed = failure is None and len(receipts) == 17 and len(generated) == 6 and len(artifacts) == 2 and listed
        put(A / 'ROOT-RESULT.json', dict(status='PASS_REMAINING17_ONLY' if passed else 'STOPPED',
            failure=failure, observedOperations=len(receipts), selectedOperations=17, rawReceipts=receipts,
            qualifiedCore=list(stable.values()), generated=list(generated.values()),
            completeArtifacts=artifacts, partialNonArtifacts=partials, noCoreReplay=True,
            expectedBodiesRead=False, independentComparison='NOT_PERFORMED', semanticAcceptance=False))
        frozen = []
        for item in sorted(A.rglob('*')):
            if item.is_file():
                freeze(item)
                frozen.append(dict(pin(item), mode='0400'))
        put(A / 'ACTUAL-FREEZE.json', dict(receipts=frozen, qualifiedCore=list(stable.values()),
            generated=list(generated.values()), completeArtifacts=artifacts, partialNonArtifacts=partials,
            allActualsFrozenBeforeAnyProtectedExpectedRead=passed, expectedBodiesRead=False,
            noCoreReplay=True, caller=pin(__file__), inputs=CONFIG,
            actualClaim='Full retained terminal diagnostic artifacts; no independent equality yet'))
        for directory in sorted((x for x in A.rglob('*') if x.is_dir()), reverse=True):
            syncdir(directory)
        for directory in [A, build, cwd / 'tmp', cwd / 'retained-artifacts', A.parent]:
            syncdir(directory)
        print(json.dumps(dict(status='PASS_REMAINING17_ONLY' if passed else 'STOPPED',
            freeze=pin(A / 'ACTUAL-FREEZE.json'), expectedBodiesRead=False)), flush=True)
    if not passed:
        raise SystemExit(1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--selection', required=True)
    main(parser.parse_args().selection)
