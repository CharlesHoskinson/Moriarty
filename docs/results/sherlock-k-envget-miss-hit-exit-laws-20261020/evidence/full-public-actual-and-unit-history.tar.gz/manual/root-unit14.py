from pathlib import Path
import sys,os,json,hashlib,runpy,datetime
sys.dont_write_bytecode=True
N=next(Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017').glob('k-C6*/**/literal-owner-corrected-root-carrier-candidate03'))
H=N/'root-manual-exact1-new14-unit-data-handoff01'
def readj(p): return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checked(row):
 actual=pin(row['path'])
 assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],actual
 return actual
def save(p,x):
 p=Path(p)
 data=(json.dumps(x,indent=2,ensure_ascii=False,default=str)+'\n').encode()
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
def syncdir(p):
 fd=os.open(p,os.O_DIRECTORY|os.O_RDONLY)
 try:os.fsync(fd)
 finally:os.close(fd)
def inventory(p):
 return [dict(path=str(x),kind='directory' if x.is_dir() else 'file',**({} if x.is_dir() else {k:v for k,v in pin(x).items() if k!='path'})) for x in sorted(Path(p).rglob('*'))]
cardpin=pin(H/'SINGLE-APPROVED-NEW14-UNIT-PHASE-CARD.json')
assert cardpin['bytes']==23779 and cardpin['sha256']=='dbc4a18e90ab592d95060b9b4d48524b2419d6aa318dc7fb2ac198e0d5e95735'
card=readj(cardpin['path']);phase=card['phase']
assert phase['expected_unit_methods']==14 and phase['expected_exit_code']==0
[checked(x) for x in card['review']];checked(card['exact_owner_readset']);checked(card['sourcefreeze']);checked(card['plan']);checked(card['existing_F03']['fullsource'])
flatpin=pin(H/'EXACT628-PREPOST-PIN-ROWS.json')
assert flatpin['bytes']==166439 and flatpin['sha256']=='3c20c3b7f369f2391db0aa5bafe9acba5635967f833504ce299d32391589fde2'
rows=readj(flatpin['path'])['members'];assert len(rows)==628
def memberships():
 for key in ['source_directory_membership','test_directory_membership']:
  want=card[key];parent=Path(want[0]).parent
  assert sorted(str(x) for x in parent.rglob('*'))==sorted(want),key
 compiled=card['compiled_directory_membership'];parent=Path(compiled[0]['path']).parent
 assert sorted(str(x) for x in parent.rglob('*'))==sorted(x['path'] for x in compiled),'compiled'
 return dict(source=card['source_directory_membership'],tests=card['test_directory_membership'],compiled=card['compiled_directory_membership'])
pre=[checked(x) for x in rows];members=memberships()
root=N/'actual-units01';cwd=Path(phase['cwd'])
assert not root.exists()
root.mkdir(mode=0o700);cwd.mkdir(mode=0o700)
for key in ['HOME','TMPDIR']:Path(phase['environment'][key]).mkdir(mode=0o700)
manualpin=pin(__file__)
save(root/'ROOT-SELECTION.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),selectedBy='Root',manualSource=manualpin,phaseCard=cardpin,plan=card['plan'],review=card['review'],exactOperations=1,expectedMethods=14,currentSourceCaption='source3/test1',actualSourceFiles=3,actualTestFiles=1,realRuntime=False))
save(root/'ROOT-PRE-PINS.json',dict(pins=pre,membership=members))
save(cwd/'COMMAND.json',phase)
syncdir(cwd);syncdir(root)
api=runpy.run_path(card['existing_F03']['fullsource']['path'],run_name='Root_nonmain_new14_diagnostic_units')
assert api['CHILD_SECONDS']==30 and api['SWEEP_SECONDS']==3
record={}
api['launch'](record,phase['argv'],dict(phase['environment']),phase['cwd'],phase['environment']['SHERLOCK_K_ATTEMPT_TOKEN'],536870912)
save(cwd/'RESULT.json',record)
for name in ['stdout','stderr']:
 p=cwd/name
 with p.open('rb') as f:os.fsync(f.fileno())
post=[checked(x) for x in rows];postmembers=memberships()
save(root/'ROOT-POST-PINS.json',dict(pins=post,membership=postmembers))
save(root/'ROOT-CWD-HOME-TMP-INVENTORY.json',dict(cwd=inventory(cwd),home=inventory(phase['environment']['HOME']),tmp=inventory(phase['environment']['TMPDIR'])))
save(root/'ROOT-RAW-STREAMS-FROZEN.json',dict(stdout=pin(cwd/'stdout'),stderr=pin(cwd/'stderr'),record=pin(cwd/'RESULT.json'),command=pin(cwd/'COMMAND.json'),classified=False))
for p in [Path(phase['environment']['HOME']),Path(phase['environment']['TMPDIR']),cwd,root]:syncdir(p)
print(json.dumps(dict(status='RAW_ACTUAL_FROZEN_ROOT_CLASSIFICATION_PENDING',root=str(root),record=record,stdout=pin(cwd/'stdout'),stderr=pin(cwd/'stderr'))),flush=True)
