from pathlib import Path
import sys,os,json,hashlib,runpy,datetime
sys.dont_write_bytecode=True
R=Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017')
H=next(R.glob('k-C6*/**/literal-owner-corrected-root-carrier-candidate03/actual-six-K-laws-procedure-source-api-operation-review-preparation01/root-manual-exact25-data-handoff01'))
def pin(p):
 p=Path(p);b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checked(r):
 a=pin(r['path']);assert a['bytes']==r['bytes'] and a['sha256']==r['sha256'],a
 return a
def load(p):return json.loads(Path(p).read_bytes())
def save(p,v):
 p=Path(p);b=(json.dumps(v,indent=2,ensure_ascii=False,default=str)+'\n').encode()
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
def syncdir(p):
 fd=os.open(p,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
def syncfile(p):
 with Path(p).open('rb') as f:os.fsync(f.fileno())
def inventory(p):
 return {str(x.relative_to(p)):('directory' if x.is_dir() else 'file') for x in sorted(Path(p).rglob('*'))}
hp=pin(H/'HANDOFF.json');assert hp['bytes']==9869 and hp['sha256']=='bfdc672b7cc3621b454f7ac3d00b402c77bc31b70df81cb4b593c400d1988fe0'
h=load(hp['path'])
for k in ['approved_phasecards','static637','mandatory_prefirstK_and_dynamic_contracts','phase_inventory_contracts','fullreview','plan']:checked(h[k])
card=load(h['approved_phasecards']['path']);plan=load(h['plan']['path'])
assert card['phases']==plan['phases'] and len(card['phases'])==25
rows=load(h['static637']['path'])['members'];assert len(rows)==637
contracts=load(h['mandatory_prefirstK_and_dynamic_contracts']['path'])
invcontracts=load(h['phase_inventory_contracts']['path'])['members']
checked(card['existing_F03']['fullsource']);checked(card['diagnostic'])
pre=[checked(x) for x in rows]
unitcard=load(H.parent.parent/'root-manual-exact1-new14-unit-data-handoff01/SINGLE-APPROVED-NEW14-UNIT-PHASE-CARD.json')
def memberships():
 for key in ['source_directory_membership','test_directory_membership']:
  want=unitcard[key];assert sorted(str(x) for x in Path(want[0]).parent.rglob('*'))==sorted(want)
 want=unitcard['compiled_directory_membership'];assert sorted(str(x) for x in Path(want[0]['path']).parent.rglob('*'))==sorted(x['path'] for x in want)
 return dict(source=unitcard['source_directory_membership'],tests=unitcard['test_directory_membership'],compiled=want)
memberships()
root=Path(card['phases'][0]['cwd']).parent
assert not root.exists()
for phase in card['phases']:
 assert not Path(phase['cwd']).exists() and len(phase['environment']) in [5,6]
 assert phase['limits']['wall_seconds']==30 and phase['limits']['sweep_seconds']==3
root.mkdir(mode=0o700)
save(root/'ROOT-SELECTION.json',dict(selectedBy='Root',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),manual=pin(__file__),handoff=hp,card=h['approved_phasecards'],review=h['fullreview'],exact25OnceSequential=True,firstRenderLaw1ThenRemainingSameSelection=True,noPrefixReplay=True,scope='finite synthetic UNADMITTED source assertions only'))
save(root/'ROOT-INITIAL-STATIC-PINS.json',dict(pins=pre,membership=memberships()))
syncdir(root)
api=runpy.run_path(card['existing_F03']['fullsource']['path'],run_name='Root_nonmain_six_laws')
assert api['CHILD_SECONDS']==30 and api['SWEEP_SECONDS']==3
diag=runpy.run_path(card['diagnostic']['path'],run_name='Root_existing_complete_data_API_only')
whole=diag['runtime'].same_whole
readvalue=lambda p:diag['base'].loads(Path(p).read_bytes())
dynamic=[];completed=[];lawresults=[]
try:
 for index,phase in enumerate(card['phases']):
  pre=[checked(x) for x in rows];prior=[checked(x) for x in dynamic];members=memberships()
  for p in phase.get('consumes',[]):assert str(p) in {x['path'] for x in dynamic},p
  cwd=Path(phase['cwd']);cwd.mkdir(mode=0o700)
  for key in ['HOME','TMPDIR']:Path(phase['environment'][key]).mkdir(mode=0o700)
  save(root/(phase['id']+'-PRE.json'),dict(pins=pre,dynamic=prior,membership=members))
  save(cwd/'COMMAND.json',phase);syncdir(cwd);syncdir(root)
  record={}
  api['launch'](record,phase['argv'],dict(phase['environment']),phase['cwd'],phase['environment']['SHERLOCK_K_ATTEMPT_TOKEN'],536870912)
  save(cwd/'RESULT.json',record)
  actualfiles=[p for p in cwd.rglob('*') if p.is_file()]
  for p in actualfiles:syncfile(p)
  for p in sorted([x for x in cwd.rglob('*') if x.is_dir()],key=lambda x:len(x.parts),reverse=True):syncdir(p)
  syncdir(cwd)
  produced=[pin(p) for p in sorted(actualfiles)]
  save(root/(phase['id']+'-RAW-FROZEN.json'),dict(record=record,files=produced,classified=False))
  syncdir(root)
  post=[checked(x) for x in rows];postprior=[checked(x) for x in dynamic];memberships()
  inv=inventory(cwd);wanted=invcontracts[index]['child_expected_relative_paths']
  wanted={k:('directory' if v=='directory' else 'file') for k,v in wanted.items()}
  save(root/(phase['id']+'-POST.json'),dict(pins=post,dynamic=postprior,inventory=inv,expectedInventory=wanted,record=record,rawDurableFirst=True))
  assert inv==wanted,('inventory',phase['id'],inv)
  assert record['outcome']=='exited' and not any(record[k] for k in ['timed_out','containment_breach','swept','remaining','group_members_after_exit']),record
  for p in phase['products']:assert Path(p).is_file() and Path(p).stat().st_size>0,p
  assert not Path(phase['stderr']).read_bytes(),('nonempty stderr retained; Root classification required',phase['id'])
  if index==0:
   assert record['returncode']==0
   m=readvalue(contracts['manifest_path']);assert set(m)==set(contracts['manifest_exact_root_keys'])
   for k,v in contracts['manifest_literals'].items():assert whole(m[k],v),(k,m[k])
   out=readvalue(phase['stdout']);assert set(out)==set(contracts['render_stdout_exact_keys'])
   assert out['status']==contracts['render_status'];checked(out['manifest']);assert out['manifest']['path']==contracts['manifest_path']
   assert len(m['entries'])==6
   assert set(phase['products'])==set(contracts['real_products_exact13'])
   compared=[]
   for entry,want in zip(m['entries'],contracts['six_exact_entries'],strict=True):
    assert set(entry)==set(contracts['entry_exact_keys'])
    for k in ['index','law','input_variant','compiled_klabel','root_sort']:assert whole(entry[k],want[k]),k
    for k in ['input','query']:
     row=entry[k];assert set(row)==set(contracts['pin_exact_keys']) and type(row['bytes']) is int
     assert row['path']==want[k+'_path'];checked(row)
    checked(want['frozen_complete_input'])
    assert whole(readvalue(entry['input']['path']),readvalue(want['frozen_complete_input']['path'])),entry['law']
    compared.append(dict(law=entry['law'],completeInput=entry['input'],frozen=want['frozen_complete_input'],strictWhole=True))
   save(root/'ROOT-ALL6-INPUTS-MANIFEST-VALIDATED-BEFORE-FIRST-K.json',dict(status='PASS_BEFORE_FIRST_K',manifest=pin(contracts['manifest_path']),inputs=compared,queryPins=[x['query'] for x in m['entries']],syntheticUnadmitted=True))
  elif phase['id'].endswith('bool-audit'):
   report=readvalue(phase['products'][0]);out=readvalue(phase['stdout'])
   assert set(report)==set(contracts['Bool_report_exact_keys']) and set(out)==set(contracts['Bool_stdout_exact_keys'])
   for k,v in contracts['Bool_report_common'].items():assert whole(report[k],v),k
   assert report['law']==phase['law'] and report['printed']==pin(phase['consumes'][0])
   checked(report['printed']);checked(out['report']);assert out['report']['path']==phase['products'][0] and out['status']==report['status']
   lawresults.append(report)
   save(root/(phase['id']+'-BOOL-CLASSIFICATION.json'),dict(record=record,report=report,scope='finite source assertion only'))
   assert record['returncode']==0 and report['status']=='LAW_PASS' and report['bool_value'] is True and report['error_type'] is None,('semantic law failure or Bool parse refusal; preserved full report',report)
  else:
   assert record['returncode']==0,record
   if phase['id'].endswith('kast-json') or phase['id'].endswith('full-print'):assert Path(phase['stdout']).stat().st_size>0
  dynamic.extend(produced)
  for name in [phase['id']+'-PRE.json',phase['id']+'-RAW-FROZEN.json',phase['id']+'-POST.json']:
   dynamic.append(pin(root/name))
  completed.append(dict(id=phase['id'],record=record,products=produced))
  save(root/(phase['id']+'-ACCEPTED.json'),dict(status='PASS_SCOPED_PHASE',phase=phase['id'],record=record))
  print(json.dumps(dict(phase=phase['id'],exit=record['returncode'],seconds=record['elapsed_seconds'],lawsPassed=len(lawresults))),flush=True)
 assert len(completed)==25 and len(lawresults)==6
 [checked(x) for x in rows];[checked(x) for x in dynamic];memberships()
 save(root/'ROOT-AGGREGATE.json',dict(status='PASS_SIX_FINITE_SYNTHETIC_K_LAWS',operations=completed,laws=lawresults,staticPins=637,scope='six PUBLIC UNADMITTED source assertions only; no genuine/admission/StepInv/native/refinement/EARS'))
 syncdir(root)
 print('PASS_SIX_FINITE_SYNTHETIC_K_LAWS',flush=True)
except BaseException as e:
 save(root/'ROOT-FAILURE.json',dict(status='FAIL_STOP_NO_RETRY',error=type(e).__name__+': '+str(e),completed=[x['id'] for x in completed],lawResults=lawresults,noCapChange=True))
 syncdir(root)
 raise
