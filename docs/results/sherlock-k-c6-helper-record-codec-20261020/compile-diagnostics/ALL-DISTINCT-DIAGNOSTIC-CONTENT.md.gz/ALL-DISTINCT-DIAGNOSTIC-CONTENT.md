# Complete diagnostic content catalog

All330 diagnostics are included below. Two common message templates are shown once; every dynamic label/variable, source location and exact indicated source line is retained. This is a readable factoring of messages, not a semantic model transformation. Complete raw renderer/caret text and wrapping remain in stderr.original and DIAGNOSTIC-MEMBERSHIP.json.
## Templates

D: `[Warning] Compiler: Attribute klabel(_) is deprecated. Either remove klabel(LABEL), or replace it by symbol(LABEL).`

U: `[Warning] Compiler: Variable VARIABLE defined but not used. Prefix variable name with underscore if this is intentional.`

Original backticks, quote punctuation and wrapping are preserved per record in the JSON membership.
## Source aliases

- S1: `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-helper-control-result-codec-20261019/source/c6-helper-codec.k`; SHA256 `2780caf66a4e4e97c20b13cc16b946c99ac51675ddcc9ba16cdea2fa16a264cc`.

- S2: `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-helper-control-result-codec-20261019/source/c6-helper-syntax.k`; SHA256 `982c0f490e849460253aebbdda9a3aaed9a56dff36821897638a7b8678db78f3`.

- S3: `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-helper-control-result-codec-20261019/source/c6-typed-root-codec.k`; SHA256 `e182f3f1a1143b4e342eaa073ee17681009dca93dfe02a5fdfcb5a55aecead7f`.

- S4: `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-helper-control-result-codec-20261019/source/c6-typed-root-syntax.k`; SHA256 `53e3abab6d1bfb253fd47e74119aeac4efb660c098da95dff571fa74d90ebbbd`.

## All deprecation sites

| Diagnostic | Source | Location (startLine,startCol,endLine,endCol) | Label |
|---:|---|---|---|
| 1 | S1 | 11,18,11,65 | `chSiteTag` |
| 2 | S1 | 12,21,12,71 | `chSiteDecode` |
| 3 | S1 | 67,18,67,65 | `chModeTag` |
| 4 | S1 | 68,21,68,71 | `chModeDecode` |
| 5 | S1 | 89,18,89,86 | `chScalarPhaseTag` |
| 6 | S1 | 90,28,90,92 | `chScalarPhaseDecode` |
| 7 | S1 | 97,18,97,65 | `chNodeTag` |
| 8 | S1 | 98,21,98,71 | `chNodeDecode` |
| 9 | S1 | 105,18,105,77 | `chSelectorTag` |
| 10 | S1 | 106,25,106,83 | `chSelectorDecode` |
| 11 | S1 | 113,18,113,62 | `chTriTag` |
| 12 | S1 | 114,20,114,68 | `chTriDecode` |
| 13 | S1 | 121,18,121,80 | `chBindPhaseTag` |
| 14 | S1 | 122,26,122,86 | `chBindPhaseDecode` |
| 15 | S1 | 135,18,135,83 | `chBindStatusTag` |
| 16 | S1 | 136,27,136,89 | `chBindStatusDecode` |
| 17 | S1 | 141,18,141,86 | `chAppendPhaseTag` |
| 18 | S1 | 142,28,142,92 | `chAppendPhaseDecode` |
| 19 | S1 | 149,18,149,83 | `chMatchPhaseTag` |
| 20 | S1 | 150,27,150,89 | `chMatchPhaseDecode` |
| 21 | S1 | 167,18,167,80 | `chPlanPhaseTag` |
| 22 | S1 | 168,26,168,86 | `chPlanPhaseDecode` |
| 23 | S1 | 181,18,181,80 | `chAfterWalkTag` |
| 24 | S1 | 182,26,182,86 | `chAfterWalkDecode` |
| 25 | S1 | 187,18,187,83 | `chBuildPhaseTag` |
| 26 | S1 | 188,27,188,89 | `chBuildPhaseDecode` |
| 27 | S1 | 193,18,193,74 | `chPatternTag` |
| 28 | S1 | 194,24,194,80 | `chPatternDecode` |
| 29 | S1 | 209,18,209,68 | `chIndexTag` |
| 30 | S1 | 210,18,210,72 | `chIndexIndex` |
| 31 | S1 | 211,22,211,79 | `chIndexDecode` |
| 32 | S1 | 218,18,218,71 | `chResumeTag` |
| 33 | S1 | 219,18,219,75 | `chResumeIndex` |
| 34 | S1 | 220,23,220,82 | `chResumeDecode` |
| 35 | S1 | 227,18,227,65 | `chTypeTag` |
| 36 | S1 | 228,18,228,69 | `chTypeIndex` |
| 37 | S1 | 229,21,229,76 | `chTypeDecode` |
| 38 | S1 | 236,18,236,81 | `chOptRefPresence` |
| 39 | S1 | 237,18,237,71 | `chOptRefTag` |
| 40 | S1 | 238,18,238,75 | `chOptRefIndex` |
| 41 | S1 | 239,23,239,87 | `chOptRefDecode` |
| 42 | S1 | 248,18,248,75 | `chCommonLane0` |
| 45 | S1 | 250,18,250,75 | `chCommonLane1` |
| 48 | S1 | 252,18,252,75 | `chCommonLane2` |
| 51 | S1 | 254,18,254,75 | `chCommonLane3` |
| 54 | S1 | 257,18,257,71 | `chStagedTag` |
| 55 | S1 | 258,18,258,79 | `chStagedPayload` |
| 56 | S1 | 259,23,259,82 | `chStagedDecode` |
| 63 | S1 | 281,22,281,87 | `chEncodeHelper` |
| 64 | S1 | 282,29,282,87 | `chDecodeHelper` |
| 65 | S1 | 285,22,285,87 | `chEncodeResult` |
| 66 | S1 | 286,29,286,87 | `chDecodeResult` |
| 67 | S1 | 349,23,349,98 | `chObserveHelper` |
| 68 | S1 | 350,23,350,121 | `chObserveHelperEncoded` |
| 69 | S1 | 353,23,353,98 | `chObserveResult` |
| 70 | S1 | 354,23,354,121 | `chObserveResultEncoded` |
| 71 | S1 | 357,24,357,80 | `chObserveAll` |
| 72 | S2 | 5,21,5,68 | `chSiteEvalLiteral` |
| 73 | S2 | 6,21,6,60 | `chSiteEvalVar` |
| 74 | S2 | 7,21,7,60 | `chSiteEvalLet` |
| 75 | S2 | 8,21,8,66 | `chSiteEvalBinary` |
| 76 | S2 | 9,21,9,64 | `chSiteEvalUnary` |
| 77 | S2 | 10,21,10,58 | `chSiteEvalIf` |
| 78 | S2 | 11,21,11,64 | `chSiteEvalMatch` |
| 79 | S2 | 12,21,12,62 | `chSiteEvalCall` |
| 80 | S2 | 13,21,13,54 | `chSitePush` |
| 81 | S2 | 14,21,14,58 | `chSiteRetLet` |
| 82 | S2 | 15,21,15,60 | `chSiteRetLeft` |
| 83 | S2 | 16,21,16,62 | `chSiteRetRight` |
| 84 | S2 | 17,21,17,62 | `chSiteRetUnary` |
| 85 | S2 | 18,21,18,56 | `chSiteRetIf` |
| 86 | S2 | 19,21,19,62 | `chSiteRetMatch` |
| 87 | S2 | 20,21,20,60 | `chSiteRetArgs` |
| 88 | S2 | 21,21,21,60 | `chSiteRetCall` |
| 89 | S2 | 22,21,22,62 | `chSiteRetScope` |
| 90 | S2 | 23,21,23,58 | `chSiteInvoke` |
| 91 | S2 | 24,21,24,56 | `chSiteEnter` |
| 92 | S2 | 25,21,25,56 | `chSiteBound` |
| 93 | S2 | 26,21,26,56 | `chSiteCases` |
| 94 | S2 | 27,21,27,66 | `chSiteCaseResult` |
| 95 | S2 | 28,21,28,54 | `chSitePrim` |
| 96 | S2 | 29,21,29,72 | `chSiteEvalConstruct` |
| 97 | S2 | 30,21,30,72 | `chSiteRetCtorFields` |
| 98 | S2 | 31,21,31,68 | `chSiteMaterialize` |
| 99 | S2 | 32,21,32,52 | `chModeAdd` |
| 100 | S2 | 33,21,33,52 | `chModeSub` |
| 101 | S2 | 34,21,34,52 | `chModeMul` |
| 102 | S2 | 35,21,35,50 | `chModeLt` |
| 103 | S2 | 36,21,36,54 | `chModeCons` |
| 104 | S2 | 37,21,37,58 | `chModeBranch` |
| 105 | S2 | 38,21,38,54 | `chModeLeaf` |
| 106 | S2 | 39,21,39,52 | `chModeNot` |
| 107 | S2 | 40,21,40,62 | `chModeTestBool` |
| 108 | S2 | 41,21,41,62 | `chModeTestType` |
| 109 | S2 | 42,28,42,77 | `chScalarPhaseFirst` |
| 110 | S2 | 43,28,43,79 | `chScalarPhaseSecond` |
| 111 | S2 | 44,28,44,75 | `chScalarPhaseDone` |
| 112 | S2 | 45,21,45,54 | `chNodeCons` |
| 113 | S2 | 46,21,46,54 | `chNodeLeaf` |
| 114 | S2 | 47,21,47,58 | `chNodeBranch` |
| 115 | S2 | 48,25,48,66 | `chSelectorTrue` |
| 116 | S2 | 49,25,49,68 | `chSelectorFalse` |
| 117 | S2 | 50,25,50,72 | `chSelectorNotBool` |
| 118 | S2 | 51,20,51,57 | `chTriPending` |
| 119 | S2 | 52,20,52,59 | `chTriPositive` |
| 120 | S2 | 53,20,53,59 | `chTriNegative` |
| 121 | S2 | 54,26,54,75 | `chBindPhasePairing` |
| 122 | S2 | 55,26,55,81 | `chBindPhaseUnwindType` |
| 123 | S2 | 56,26,56,79 | `chBindPhaseUnwindDup` |
| 124 | S2 | 57,26,57,85 | `chBindPhaseUnwindInsert` |
| 125 | S2 | 58,26,58,79 | `chBindPhasePropagate` |
| 126 | S2 | 59,26,59,77 | `chBindPhaseFinished` |
| 127 | S2 | 60,27,60,68 | `chBindStatusOk` |
| 128 | S2 | 61,27,61,70 | `chBindStatusBad` |
| 129 | S2 | 62,28,62,75 | `chAppendPhaseCopy` |
| 130 | S2 | 63,28,63,75 | `chAppendPhaseTail` |
| 131 | S2 | 64,28,64,75 | `chAppendPhaseDone` |
| 132 | S2 | 65,27,65,70 | `chMatchPhaseArm` |
| 133 | S2 | 66,27,66,70 | `chMatchPhaseTag` |
| 134 | S2 | 67,27,67,80 | `chMatchPhaseDistinct` |
| 135 | S2 | 68,27,68,74 | `chMatchPhaseField` |
| 136 | S2 | 69,27,69,72 | `chMatchPhaseBind` |
| 137 | S2 | 70,27,70,74 | `chMatchPhaseReady` |
| 138 | S2 | 71,27,71,88 | `chMatchPhaseNoMatchReady` |
| 139 | S2 | 72,27,72,72 | `chMatchPhaseDone` |
| 140 | S2 | 73,26,73,69 | `chPlanPhaseWalk` |
| 141 | S2 | 74,26,74,69 | `chPlanPhaseTest` |
| 142 | S2 | 75,26,75,69 | `chPlanPhaseBind` |
| 143 | S2 | 76,26,76,71 | `chPlanPhaseReady` |
| 144 | S2 | 77,26,77,85 | `chPlanPhaseNoMatchReady` |
| 145 | S2 | 78,26,78,69 | `chPlanPhaseDone` |
| 146 | S2 | 79,26,79,69 | `chAfterWalkTest` |
| 147 | S2 | 80,26,80,69 | `chAfterWalkBind` |
| 148 | S2 | 81,27,81,72 | `chBuildPhaseCopy` |
| 149 | S2 | 82,27,82,72 | `chBuildPhaseDone` |
| 150 | S2 | 83,24,83,63 | `chPatternPVar` |
| 151 | S2 | 84,24,84,63 | `chPatternPNil` |
| 152 | S2 | 85,24,85,65 | `chPatternPCons` |
| 153 | S2 | 86,24,86,65 | `chPatternPLeaf` |
| 154 | S2 | 87,24,87,69 | `chPatternPBranch` |
| 155 | S2 | 88,24,88,105 | `chPatternWildcardExtensionReserved` |
| 156 | S2 | 89,24,89,111 | `chPatternConstructorExtensionReserved` |
| 157 | S2 | 90,22,90,57 | `chIndexNone` |
| 158 | S2 | 91,22,91,60 | `chIndexSome` |
| 159 | S2 | 92,23,92,60 | `chResumeNone` |
| 160 | S2 | 93,23,93,63 | `chResumeSome` |
| 161 | S2 | 94,21,94,54 | `chTypeNone` |
| 162 | S2 | 95,21,95,57 | `chTypeSome` |
| 163 | S2 | 96,23,96,54 | `chRefNone` |
| 164 | S2 | 97,23,97,59 | `chRefSome` |
| 165 | S2 | 98,23,98,73 | `chCommon` |
| 166 | S2 | 99,23,99,60 | `chStagedNone` |
| 167 | S2 | 100,23,100,73 | `chStagedU128Value` |
| 168 | S2 | 101,23,101,74 | `chStagedBoolValue` |
| 169 | S2 | 102,23,102,80 | `chStagedPendingNode` |
| 170 | S2 | 103,23,103,73 | `chStagedPrimError` |
| 171 | S2 | 104,23,104,78 | `chStagedSelector` |
| 172 | S2 | 105,23,105,72 | `chStagedTypeTest` |
| 173 | S2 | 106,23,106,123 | `chScalar` |
| 174 | S2 | 107,23,107,91 | `chEnvGet` |
| 175 | S2 | 108,23,108,95 | `chEnvPut` |
| 176 | S2 | 109,23,109,82 | `chFind` |
| 177 | S2 | 110,23,110,132 | `chBind` |
| 178 | S2 | 111,23,111,111 | `chAppend` |
| 179 | S2 | 112,23,112,78 | `chValidate` |
| 180 | S2 | 113,23,113,79 | `chEqual` |
| 181 | S2 | 114,23,114,141 | `chMatch` |
| 182 | S2 | 115,23,115,150 | `chPlan` |
| 183 | S2 | 116,23,116,121 | `chBuild` |
| 184 | S2 | 117,23,117,74 | `chResultValidated` |
| 185 | S2 | 118,23,118,73 | `chResultEnvFound` |
| 186 | S2 | 119,23,119,72 | `chResultEnvMissing` |
| 187 | S2 | 120,23,120,75 | `chResultEnvUpdated` |
| 188 | S2 | 121,23,121,73 | `chResultFindFound` |
| 189 | S2 | 122,23,122,74 | `chResultFindMissing` |
| 190 | S2 | 123,23,123,69 | `chResultBindOk` |
| 191 | S2 | 124,23,124,66 | `chResultBindBad` |
| 192 | S2 | 125,23,125,79 | `chResultAppendDone` |
| 193 | S2 | 126,23,126,79 | `chResultScalarValue` |
| 194 | S2 | 127,23,127,77 | `chResultScalarError` |
| 195 | S2 | 128,23,128,90 | `chResultScalarSelector` |
| 196 | S2 | 129,23,129,84 | `chResultScalarTypeTest` |
| 197 | S2 | 130,23,130,75 | `chResultEqualDone` |
| 198 | S2 | 131,23,131,81 | `chResultMatchMatched` |
| 199 | S2 | 132,23,132,76 | `chResultMatchNoMatch` |
| 200 | S2 | 133,23,133,84 | `chResultPlanMatched` |
| 201 | S2 | 134,23,134,74 | `chResultPlanNoMatch` |
| 202 | S2 | 135,23,135,75 | `chResultBuildDone` |
| 203 | S2 | 136,29,136,62 | `chNoHelper` |
| 204 | S2 | 137,29,137,74 | `chSomeHelper` |
| 205 | S2 | 138,29,138,62 | `chNoResult` |
| 206 | S2 | 139,29,139,74 | `chSomeResult` |
| 207 | S2 | 140,23,140,111 | `chHelperAnswer` |
| 208 | S2 | 141,23,141,111 | `chResultAnswer` |
| 209 | S2 | 142,24,142,59 | `chNoQueries` |
| 210 | S2 | 143,24,143,96 | `chHelperQuery` |
| 211 | S2 | 144,24,144,96 | `chResultQuery` |
| 212 | S2 | 145,24,145,59 | `chNoAnswers` |
| 213 | S2 | 146,24,146,78 | `chAnswerRow` |
| 214 | S3 | 10,22,10,73 | `ctJoin` |
| 215 | S3 | 13,18,13,60 | `ctSize` |
| 216 | S3 | 16,22,16,69 | `ctTake` |
| 217 | S3 | 17,22,17,69 | `ctDrop` |
| 218 | S3 | 18,18,18,61 | `ctAt` |
| 219 | S3 | 25,18,25,62 | `ctEnvTag` |
| 220 | S3 | 26,18,26,66 | `ctEnvIndex` |
| 221 | S3 | 27,18,27,77 | `ctFunctionTag` |
| 222 | S3 | 28,18,28,81 | `ctFunctionIndex` |
| 223 | S3 | 29,18,29,62 | `ctRefTag` |
| 224 | S3 | 30,18,30,66 | `ctRefIndex` |
| 225 | S3 | 31,18,31,57 | `ctBool` |
| 226 | S3 | 46,20,46,73 | `ctEnvDecode` |
| 227 | S3 | 47,25,47,88 | `ctFunctionDecode` |
| 228 | S3 | 48,20,48,73 | `ctRefDecode` |
| 229 | S3 | 55,19,55,69 | `ctBoolDecode` |
| 230 | S3 | 58,18,58,65 | `ctBinary` |
| 231 | S3 | 59,23,59,77 | `ctBinaryDecode` |
| 232 | S3 | 74,18,74,62 | `ctUnary` |
| 233 | S3 | 75,22,75,74 | `ctUnaryDecode` |
| 234 | S3 | 80,18,80,68 | `ctExhaust` |
| 235 | S3 | 81,24,81,80 | `ctExhaustDecode` |
| 236 | S3 | 96,18,96,72 | `ctSliceStart` |
| 237 | S3 | 97,18,97,68 | `ctSliceLen` |
| 238 | S3 | 100,22,100,78 | `ctEncodeFrame` |
| 239 | S3 | 101,22,101,78 | `ctDecodeFrame` |
| 240 | S3 | 122,22,122,82 | `ctBindingLanes` |
| 241 | S3 | 123,22,123,85 | `ctMatchingLanes` |
| 242 | S3 | 124,22,124,88 | `ctPrimitiveLanes` |
| 243 | S3 | 125,22,125,82 | `ctOutcomeLanes` |
| 244 | S3 | 136,24,136,90 | `ctBindingDecode` |
| 245 | S3 | 137,25,137,93 | `ctMatchingDecode` |
| 246 | S3 | 138,26,138,96 | `ctPrimitiveDecode` |
| 247 | S3 | 139,24,139,90 | `ctOutcomeDecode` |
| 248 | S3 | 150,22,150,84 | `ctEncodeControl` |
| 249 | S3 | 151,24,151,84 | `ctDecodeControl` |
| 250 | S3 | 174,18,174,73 | `ctFrameCount` |
| 251 | S3 | 177,22,177,81 | `ctEncodeFrames` |
| 252 | S3 | 180,23,180,86 | `ctDecodeFrames` |
| 253 | S3 | 183,18,183,64 | `ctAlloc0` |
| 254 | S3 | 185,18,185,64 | `ctAlloc1` |
| 255 | S3 | 187,18,187,64 | `ctAlloc2` |
| 256 | S3 | 189,18,189,67 | `ctActive0` |
| 257 | S3 | 191,18,191,67 | `ctActive1` |
| 258 | S3 | 193,18,193,67 | `ctActive2` |
| 259 | S3 | 195,18,195,67 | `ctActive3` |
| 260 | S3 | 197,22,197,75 | `ctEncodeRoot` |
| 261 | S3 | 198,21,198,75 | `ctDecodeRoot` |
| 262 | S3 | 201,23,201,86 | `ctObserveRoot` |
| 263 | S3 | 202,23,202,101 | `ctObserveEncoded` |
| 264 | S3 | 205,24,205,80 | `ctObserveAll` |
| 265 | S4 | 7,20,7,50 | `ctConst` |
| 266 | S4 | 8,22,8,50 | `ctData` |
| 267 | S4 | 9,20,9,51 | `ctEnvNone` |
| 268 | S4 | 10,22,10,56 | `ctEnvSome` |
| 269 | S4 | 11,25,11,66 | `ctFunctionNone` |
| 270 | S4 | 12,27,12,71 | `ctFunctionSome` |
| 271 | S4 | 13,22,13,57 | `ctSlice` |
| 272 | S4 | 14,23,14,46 | `ctAdd` |
| 273 | S4 | 15,25,15,48 | `ctSub` |
| 274 | S4 | 16,25,16,48 | `ctMul` |
| 275 | S4 | 17,25,17,46 | `ctEq` |
| 276 | S4 | 18,25,18,46 | `ctLt` |
| 277 | S4 | 19,25,19,50 | `ctCons` |
| 278 | S4 | 20,25,20,54 | `ctBranch` |
| 279 | S4 | 21,22,21,47 | `ctLeaf` |
| 280 | S4 | 22,24,22,47 | `ctNot` |
| 281 | S4 | 23,22,23,67 | `ctLetF` |
| 282 | S4 | 24,24,24,76 | `ctLeftF` |
| 283 | S4 | 25,24,25,73 | `ctRightF` |
| 284 | S4 | 26,24,26,65 | `ctUnaryF` |
| 285 | S4 | 27,24,27,67 | `ctIfF` |
| 286 | S4 | 28,24,28,72 | `ctMatchF` |
| 287 | S4 | 29,24,29,84 | `ctArgsF` |
| 288 | S4 | 30,24,30,70 | `ctReturnF` |
| 289 | S4 | 31,24,31,63 | `ctScopeF` |
| 290 | S4 | 32,24,32,131 | `ctConstructorFieldsF` |
| 291 | S4 | 33,23,33,56 | `ctNoFrames` |
| 292 | S4 | 34,25,34,69 | `ctFrame` |
| 293 | S4 | 35,24,35,61 | `ctBindingBad` |
| 294 | S4 | 36,26,36,66 | `ctBindingOk` |
| 295 | S4 | 37,25,37,56 | `ctNoMatch` |
| 296 | S4 | 38,27,38,63 | `ctMatched` |
| 297 | S4 | 39,26,39,66 | `ctPrimValue` |
| 298 | S4 | 40,28,40,66 | `ctPrimError` |
| 299 | S4 | 41,24,41,52 | `ctEval` |
| 300 | S4 | 42,26,42,60 | `ctReturn` |
| 301 | S4 | 43,26,43,86 | `ctScheduleNext` |
| 302 | S4 | 44,26,44,67 | `ctInvoke` |
| 303 | S4 | 45,26,45,72 | `ctEnter` |
| 304 | S4 | 46,26,46,72 | `ctBound` |
| 305 | S4 | 47,26,47,74 | `ctCases` |
| 306 | S4 | 48,26,48,101 | `ctCaseResult` |
| 307 | S4 | 49,26,49,74 | `ctPrimResult` |
| 308 | S4 | 50,26,50,56 | `ctError` |
| 309 | S4 | 51,26,51,82 | `ctMaterialize` |
| 310 | S4 | 52,24,52,49 | `ctFuel` |
| 311 | S4 | 53,26,53,61 | `ctDataNodes` |
| 312 | S4 | 54,26,54,63 | `ctDataFields` |
| 313 | S4 | 55,26,55,75 | `ctEnvironmentCells` |
| 314 | S4 | 56,26,56,65 | `ctHelperTasks` |
| 315 | S4 | 57,26,57,63 | `ctHelperWork` |
| 316 | S4 | 58,26,58,79 | `ctSerializationBytes` |
| 317 | S4 | 59,24,59,55 | `ctRunning` |
| 318 | S4 | 60,26,60,60 | `ctHalted` |
| 319 | S4 | 61,26,61,62 | `ctRejected` |
| 320 | S4 | 62,26,62,70 | `ctExhausted` |
| 321 | S4 | 63,22,63,62 | `ctAlloc` |
| 322 | S4 | 64,23,64,70 | `ctActive` |
| 323 | S4 | 65,21,65,166 | `ctRoot` |
| 324 | S4 | 66,22,66,53 | `ctNoLanes` |
| 325 | S4 | 67,24,67,61 | `ctLane` |
| 326 | S4 | 68,23,68,83 | `ctAnswer` |
| 327 | S4 | 69,24,69,59 | `ctNoQueries` |
| 328 | S4 | 70,26,70,78 | `ctQuery` |
| 329 | S4 | 71,24,71,59 | `ctNoAnswers` |
| 330 | S4 | 72,26,72,80 | `ctAnswerRow` |

## All unused-variable sites and indicated rules

Diagnostic 43: U, variable `O`, S1 Location(249,34,249,35).

```k
  rule chCommonLane0(chCommon(S, O, P)) => chSiteTag(S)
```

Diagnostic 44: U, variable `P`, S1 Location(249,37,249,38).

```k
  rule chCommonLane0(chCommon(S, O, P)) => chSiteTag(S)
```

Diagnostic 46: U, variable `S`, S1 Location(251,31,251,32).

```k
  rule chCommonLane1(chCommon(S, O, P)) => O
```

Diagnostic 47: U, variable `P`, S1 Location(251,37,251,38).

```k
  rule chCommonLane1(chCommon(S, O, P)) => O
```

Diagnostic 49: U, variable `S`, S1 Location(253,31,253,32).

```k
  rule chCommonLane2(chCommon(S, O, P)) => chResumeTag(P)
```

Diagnostic 50: U, variable `O`, S1 Location(253,34,253,35).

```k
  rule chCommonLane2(chCommon(S, O, P)) => chResumeTag(P)
```

Diagnostic 52: U, variable `S`, S1 Location(255,31,255,32).

```k
  rule chCommonLane3(chCommon(S, O, P)) => chResumeIndex(P)
```

Diagnostic 53: U, variable `O`, S1 Location(255,34,255,35).

```k
  rule chCommonLane3(chCommon(S, O, P)) => chResumeIndex(P)
```

Diagnostic 57: U, variable `I`, S1 Location(263,38,263,39).

```k
  rule chStagedTag(chStagedU128Value(I)) => 1
```

Diagnostic 58: U, variable `B`, S1 Location(266,38,266,39).

```k
  rule chStagedTag(chStagedBoolValue(B)) => 2
```

Diagnostic 59: U, variable `T`, S1 Location(269,40,269,41).

```k
  rule chStagedTag(chStagedPendingNode(T)) => 3
```

Diagnostic 60: U, variable `C`, S1 Location(272,38,272,39).

```k
  rule chStagedTag(chStagedPrimError(C)) => 4
```

Diagnostic 61: U, variable `S`, S1 Location(275,37,275,38).

```k
  rule chStagedTag(chStagedSelector(S)) => 5
```

Diagnostic 62: U, variable `B`, S1 Location(278,37,278,38).

```k
  rule chStagedTag(chStagedTypeTest(B)) => 6
```

## Every indicated declaration source line (complete)

The following is exact current pinned source text for every D site. Diagnostic ordinals distinguish repeated bare label spellings in different roles.

D1 S1 Location(11,18,11,65)

```k
  syntax Int ::= chSiteTag(CHSite) [function, klabel(chSiteTag)]
```

D2 S1 Location(12,21,12,71)

```k
  syntax CHSite ::= chSiteDecode(Int) [function, klabel(chSiteDecode)]
```

D3 S1 Location(67,18,67,65)

```k
  syntax Int ::= chModeTag(CHMode) [function, klabel(chModeTag)]
```

D4 S1 Location(68,21,68,71)

```k
  syntax CHMode ::= chModeDecode(Int) [function, klabel(chModeDecode)]
```

D5 S1 Location(89,18,89,86)

```k
  syntax Int ::= chScalarPhaseTag(CHScalarPhase) [function, klabel(chScalarPhaseTag)]
```

D6 S1 Location(90,28,90,92)

```k
  syntax CHScalarPhase ::= chScalarPhaseDecode(Int) [function, klabel(chScalarPhaseDecode)]
```

D7 S1 Location(97,18,97,65)

```k
  syntax Int ::= chNodeTag(CHNode) [function, klabel(chNodeTag)]
```

D8 S1 Location(98,21,98,71)

```k
  syntax CHNode ::= chNodeDecode(Int) [function, klabel(chNodeDecode)]
```

D9 S1 Location(105,18,105,77)

```k
  syntax Int ::= chSelectorTag(CHSelector) [function, klabel(chSelectorTag)]
```

D10 S1 Location(106,25,106,83)

```k
  syntax CHSelector ::= chSelectorDecode(Int) [function, klabel(chSelectorDecode)]
```

D11 S1 Location(113,18,113,62)

```k
  syntax Int ::= chTriTag(CHTri) [function, klabel(chTriTag)]
```

D12 S1 Location(114,20,114,68)

```k
  syntax CHTri ::= chTriDecode(Int) [function, klabel(chTriDecode)]
```

D13 S1 Location(121,18,121,80)

```k
  syntax Int ::= chBindPhaseTag(CHBindPhase) [function, klabel(chBindPhaseTag)]
```

D14 S1 Location(122,26,122,86)

```k
  syntax CHBindPhase ::= chBindPhaseDecode(Int) [function, klabel(chBindPhaseDecode)]
```

D15 S1 Location(135,18,135,83)

```k
  syntax Int ::= chBindStatusTag(CHBindStatus) [function, klabel(chBindStatusTag)]
```

D16 S1 Location(136,27,136,89)

```k
  syntax CHBindStatus ::= chBindStatusDecode(Int) [function, klabel(chBindStatusDecode)]
```

D17 S1 Location(141,18,141,86)

```k
  syntax Int ::= chAppendPhaseTag(CHAppendPhase) [function, klabel(chAppendPhaseTag)]
```

D18 S1 Location(142,28,142,92)

```k
  syntax CHAppendPhase ::= chAppendPhaseDecode(Int) [function, klabel(chAppendPhaseDecode)]
```

D19 S1 Location(149,18,149,83)

```k
  syntax Int ::= chMatchPhaseTag(CHMatchPhase) [function, klabel(chMatchPhaseTag)]
```

D20 S1 Location(150,27,150,89)

```k
  syntax CHMatchPhase ::= chMatchPhaseDecode(Int) [function, klabel(chMatchPhaseDecode)]
```

D21 S1 Location(167,18,167,80)

```k
  syntax Int ::= chPlanPhaseTag(CHPlanPhase) [function, klabel(chPlanPhaseTag)]
```

D22 S1 Location(168,26,168,86)

```k
  syntax CHPlanPhase ::= chPlanPhaseDecode(Int) [function, klabel(chPlanPhaseDecode)]
```

D23 S1 Location(181,18,181,80)

```k
  syntax Int ::= chAfterWalkTag(CHAfterWalk) [function, klabel(chAfterWalkTag)]
```

D24 S1 Location(182,26,182,86)

```k
  syntax CHAfterWalk ::= chAfterWalkDecode(Int) [function, klabel(chAfterWalkDecode)]
```

D25 S1 Location(187,18,187,83)

```k
  syntax Int ::= chBuildPhaseTag(CHBuildPhase) [function, klabel(chBuildPhaseTag)]
```

D26 S1 Location(188,27,188,89)

```k
  syntax CHBuildPhase ::= chBuildPhaseDecode(Int) [function, klabel(chBuildPhaseDecode)]
```

D27 S1 Location(193,18,193,74)

```k
  syntax Int ::= chPatternTag(CHPattern) [function, klabel(chPatternTag)]
```

D28 S1 Location(194,24,194,80)

```k
  syntax CHPattern ::= chPatternDecode(Int) [function, klabel(chPatternDecode)]
```

D29 S1 Location(209,18,209,68)

```k
  syntax Int ::= chIndexTag(CHIndex) [function, klabel(chIndexTag)]
```

D30 S1 Location(210,18,210,72)

```k
  syntax Int ::= chIndexIndex(CHIndex) [function, klabel(chIndexIndex)]
```

D31 S1 Location(211,22,211,79)

```k
  syntax CHIndex ::= chIndexDecode(Int, Int) [function, klabel(chIndexDecode)]
```

D32 S1 Location(218,18,218,71)

```k
  syntax Int ::= chResumeTag(CHResume) [function, klabel(chResumeTag)]
```

D33 S1 Location(219,18,219,75)

```k
  syntax Int ::= chResumeIndex(CHResume) [function, klabel(chResumeIndex)]
```

D34 S1 Location(220,23,220,82)

```k
  syntax CHResume ::= chResumeDecode(Int, Int) [function, klabel(chResumeDecode)]
```

D35 S1 Location(227,18,227,65)

```k
  syntax Int ::= chTypeTag(CHType) [function, klabel(chTypeTag)]
```

D36 S1 Location(228,18,228,69)

```k
  syntax Int ::= chTypeIndex(CHType) [function, klabel(chTypeIndex)]
```

D37 S1 Location(229,21,229,76)

```k
  syntax CHType ::= chTypeDecode(Int, Int) [function, klabel(chTypeDecode)]
```

D38 S1 Location(236,18,236,81)

```k
  syntax Int ::= chOptRefPresence(CHOptRef) [function, klabel(chOptRefPresence)]
```

D39 S1 Location(237,18,237,71)

```k
  syntax Int ::= chOptRefTag(CHOptRef) [function, klabel(chOptRefTag)]
```

D40 S1 Location(238,18,238,75)

```k
  syntax Int ::= chOptRefIndex(CHOptRef) [function, klabel(chOptRefIndex)]
```

D41 S1 Location(239,23,239,87)

```k
  syntax CHOptRef ::= chOptRefDecode(Int, Int, Int) [function, klabel(chOptRefDecode)]
```

D42 S1 Location(248,18,248,75)

```k
  syntax Int ::= chCommonLane0(CHCommon) [function, klabel(chCommonLane0)]
```

D45 S1 Location(250,18,250,75)

```k
  syntax Int ::= chCommonLane1(CHCommon) [function, klabel(chCommonLane1)]
```

D48 S1 Location(252,18,252,75)

```k
  syntax Int ::= chCommonLane2(CHCommon) [function, klabel(chCommonLane2)]
```

D51 S1 Location(254,18,254,75)

```k
  syntax Int ::= chCommonLane3(CHCommon) [function, klabel(chCommonLane3)]
```

D54 S1 Location(257,18,257,71)

```k
  syntax Int ::= chStagedTag(CHStaged) [function, klabel(chStagedTag)]
```

D55 S1 Location(258,18,258,79)

```k
  syntax Int ::= chStagedPayload(CHStaged) [function, klabel(chStagedPayload)]
```

D56 S1 Location(259,23,259,82)

```k
  syntax CHStaged ::= chStagedDecode(Int, Int) [function, klabel(chStagedDecode)]
```

D63 S1 Location(281,22,281,87)

```k
  syntax CTLanes ::= chEncodeHelper(CHHelperOption) [function, klabel(chEncodeHelper)]
```

D64 S1 Location(282,29,282,87)

```k
  syntax CHHelperOption ::= chDecodeHelper(CTLanes) [function, klabel(chDecodeHelper)]
```

D65 S1 Location(285,22,285,87)

```k
  syntax CTLanes ::= chEncodeResult(CHResultOption) [function, klabel(chEncodeResult)]
```

D66 S1 Location(286,29,286,87)

```k
  syntax CHResultOption ::= chDecodeResult(CTLanes) [function, klabel(chDecodeResult)]
```

D67 S1 Location(349,23,349,98)

```k
  syntax CHAnswer ::= chObserveHelper(String, CHHelperOption) [function, klabel(chObserveHelper)]
```

D68 S1 Location(350,23,350,121)

```k
  syntax CHAnswer ::= chObserveHelperEncoded(String, CHHelperOption, CTLanes) [function, klabel(chObserveHelperEncoded)]
```

D69 S1 Location(353,23,353,98)

```k
  syntax CHAnswer ::= chObserveResult(String, CHResultOption) [function, klabel(chObserveResult)]
```

D70 S1 Location(354,23,354,121)

```k
  syntax CHAnswer ::= chObserveResultEncoded(String, CHResultOption, CTLanes) [function, klabel(chObserveResultEncoded)]
```

D71 S1 Location(357,24,357,80)

```k
  syntax CHAnswers ::= chObserveAll(CHQueries) [function, klabel(chObserveAll)]
```

D72 S2 Location(5,21,5,68)

```k
  syntax CHSite ::= chSiteEvalLiteral() [klabel(chSiteEvalLiteral)]
```

D73 S2 Location(6,21,6,60)

```k
  syntax CHSite ::= chSiteEvalVar() [klabel(chSiteEvalVar)]
```

D74 S2 Location(7,21,7,60)

```k
  syntax CHSite ::= chSiteEvalLet() [klabel(chSiteEvalLet)]
```

D75 S2 Location(8,21,8,66)

```k
  syntax CHSite ::= chSiteEvalBinary() [klabel(chSiteEvalBinary)]
```

D76 S2 Location(9,21,9,64)

```k
  syntax CHSite ::= chSiteEvalUnary() [klabel(chSiteEvalUnary)]
```

D77 S2 Location(10,21,10,58)

```k
  syntax CHSite ::= chSiteEvalIf() [klabel(chSiteEvalIf)]
```

D78 S2 Location(11,21,11,64)

```k
  syntax CHSite ::= chSiteEvalMatch() [klabel(chSiteEvalMatch)]
```

D79 S2 Location(12,21,12,62)

```k
  syntax CHSite ::= chSiteEvalCall() [klabel(chSiteEvalCall)]
```

D80 S2 Location(13,21,13,54)

```k
  syntax CHSite ::= chSitePush() [klabel(chSitePush)]
```

D81 S2 Location(14,21,14,58)

```k
  syntax CHSite ::= chSiteRetLet() [klabel(chSiteRetLet)]
```

D82 S2 Location(15,21,15,60)

```k
  syntax CHSite ::= chSiteRetLeft() [klabel(chSiteRetLeft)]
```

D83 S2 Location(16,21,16,62)

```k
  syntax CHSite ::= chSiteRetRight() [klabel(chSiteRetRight)]
```

D84 S2 Location(17,21,17,62)

```k
  syntax CHSite ::= chSiteRetUnary() [klabel(chSiteRetUnary)]
```

D85 S2 Location(18,21,18,56)

```k
  syntax CHSite ::= chSiteRetIf() [klabel(chSiteRetIf)]
```

D86 S2 Location(19,21,19,62)

```k
  syntax CHSite ::= chSiteRetMatch() [klabel(chSiteRetMatch)]
```

D87 S2 Location(20,21,20,60)

```k
  syntax CHSite ::= chSiteRetArgs() [klabel(chSiteRetArgs)]
```

D88 S2 Location(21,21,21,60)

```k
  syntax CHSite ::= chSiteRetCall() [klabel(chSiteRetCall)]
```

D89 S2 Location(22,21,22,62)

```k
  syntax CHSite ::= chSiteRetScope() [klabel(chSiteRetScope)]
```

D90 S2 Location(23,21,23,58)

```k
  syntax CHSite ::= chSiteInvoke() [klabel(chSiteInvoke)]
```

D91 S2 Location(24,21,24,56)

```k
  syntax CHSite ::= chSiteEnter() [klabel(chSiteEnter)]
```

D92 S2 Location(25,21,25,56)

```k
  syntax CHSite ::= chSiteBound() [klabel(chSiteBound)]
```

D93 S2 Location(26,21,26,56)

```k
  syntax CHSite ::= chSiteCases() [klabel(chSiteCases)]
```

D94 S2 Location(27,21,27,66)

```k
  syntax CHSite ::= chSiteCaseResult() [klabel(chSiteCaseResult)]
```

D95 S2 Location(28,21,28,54)

```k
  syntax CHSite ::= chSitePrim() [klabel(chSitePrim)]
```

D96 S2 Location(29,21,29,72)

```k
  syntax CHSite ::= chSiteEvalConstruct() [klabel(chSiteEvalConstruct)]
```

D97 S2 Location(30,21,30,72)

```k
  syntax CHSite ::= chSiteRetCtorFields() [klabel(chSiteRetCtorFields)]
```

D98 S2 Location(31,21,31,68)

```k
  syntax CHSite ::= chSiteMaterialize() [klabel(chSiteMaterialize)]
```

D99 S2 Location(32,21,32,52)

```k
  syntax CHMode ::= chModeAdd() [klabel(chModeAdd)]
```

D100 S2 Location(33,21,33,52)

```k
  syntax CHMode ::= chModeSub() [klabel(chModeSub)]
```

D101 S2 Location(34,21,34,52)

```k
  syntax CHMode ::= chModeMul() [klabel(chModeMul)]
```

D102 S2 Location(35,21,35,50)

```k
  syntax CHMode ::= chModeLt() [klabel(chModeLt)]
```

D103 S2 Location(36,21,36,54)

```k
  syntax CHMode ::= chModeCons() [klabel(chModeCons)]
```

D104 S2 Location(37,21,37,58)

```k
  syntax CHMode ::= chModeBranch() [klabel(chModeBranch)]
```

D105 S2 Location(38,21,38,54)

```k
  syntax CHMode ::= chModeLeaf() [klabel(chModeLeaf)]
```

D106 S2 Location(39,21,39,52)

```k
  syntax CHMode ::= chModeNot() [klabel(chModeNot)]
```

D107 S2 Location(40,21,40,62)

```k
  syntax CHMode ::= chModeTestBool() [klabel(chModeTestBool)]
```

D108 S2 Location(41,21,41,62)

```k
  syntax CHMode ::= chModeTestType() [klabel(chModeTestType)]
```

D109 S2 Location(42,28,42,77)

```k
  syntax CHScalarPhase ::= chScalarPhaseFirst() [klabel(chScalarPhaseFirst)]
```

D110 S2 Location(43,28,43,79)

```k
  syntax CHScalarPhase ::= chScalarPhaseSecond() [klabel(chScalarPhaseSecond)]
```

D111 S2 Location(44,28,44,75)

```k
  syntax CHScalarPhase ::= chScalarPhaseDone() [klabel(chScalarPhaseDone)]
```

D112 S2 Location(45,21,45,54)

```k
  syntax CHNode ::= chNodeCons() [klabel(chNodeCons)]
```

D113 S2 Location(46,21,46,54)

```k
  syntax CHNode ::= chNodeLeaf() [klabel(chNodeLeaf)]
```

D114 S2 Location(47,21,47,58)

```k
  syntax CHNode ::= chNodeBranch() [klabel(chNodeBranch)]
```

D115 S2 Location(48,25,48,66)

```k
  syntax CHSelector ::= chSelectorTrue() [klabel(chSelectorTrue)]
```

D116 S2 Location(49,25,49,68)

```k
  syntax CHSelector ::= chSelectorFalse() [klabel(chSelectorFalse)]
```

D117 S2 Location(50,25,50,72)

```k
  syntax CHSelector ::= chSelectorNotBool() [klabel(chSelectorNotBool)]
```

D118 S2 Location(51,20,51,57)

```k
  syntax CHTri ::= chTriPending() [klabel(chTriPending)]
```

D119 S2 Location(52,20,52,59)

```k
  syntax CHTri ::= chTriPositive() [klabel(chTriPositive)]
```

D120 S2 Location(53,20,53,59)

```k
  syntax CHTri ::= chTriNegative() [klabel(chTriNegative)]
```

D121 S2 Location(54,26,54,75)

```k
  syntax CHBindPhase ::= chBindPhasePairing() [klabel(chBindPhasePairing)]
```

D122 S2 Location(55,26,55,81)

```k
  syntax CHBindPhase ::= chBindPhaseUnwindType() [klabel(chBindPhaseUnwindType)]
```

D123 S2 Location(56,26,56,79)

```k
  syntax CHBindPhase ::= chBindPhaseUnwindDup() [klabel(chBindPhaseUnwindDup)]
```

D124 S2 Location(57,26,57,85)

```k
  syntax CHBindPhase ::= chBindPhaseUnwindInsert() [klabel(chBindPhaseUnwindInsert)]
```

D125 S2 Location(58,26,58,79)

```k
  syntax CHBindPhase ::= chBindPhasePropagate() [klabel(chBindPhasePropagate)]
```

D126 S2 Location(59,26,59,77)

```k
  syntax CHBindPhase ::= chBindPhaseFinished() [klabel(chBindPhaseFinished)]
```

D127 S2 Location(60,27,60,68)

```k
  syntax CHBindStatus ::= chBindStatusOk() [klabel(chBindStatusOk)]
```

D128 S2 Location(61,27,61,70)

```k
  syntax CHBindStatus ::= chBindStatusBad() [klabel(chBindStatusBad)]
```

D129 S2 Location(62,28,62,75)

```k
  syntax CHAppendPhase ::= chAppendPhaseCopy() [klabel(chAppendPhaseCopy)]
```

D130 S2 Location(63,28,63,75)

```k
  syntax CHAppendPhase ::= chAppendPhaseTail() [klabel(chAppendPhaseTail)]
```

D131 S2 Location(64,28,64,75)

```k
  syntax CHAppendPhase ::= chAppendPhaseDone() [klabel(chAppendPhaseDone)]
```

D132 S2 Location(65,27,65,70)

```k
  syntax CHMatchPhase ::= chMatchPhaseArm() [klabel(chMatchPhaseArm)]
```

D133 S2 Location(66,27,66,70)

```k
  syntax CHMatchPhase ::= chMatchPhaseTag() [klabel(chMatchPhaseTag)]
```

D134 S2 Location(67,27,67,80)

```k
  syntax CHMatchPhase ::= chMatchPhaseDistinct() [klabel(chMatchPhaseDistinct)]
```

D135 S2 Location(68,27,68,74)

```k
  syntax CHMatchPhase ::= chMatchPhaseField() [klabel(chMatchPhaseField)]
```

D136 S2 Location(69,27,69,72)

```k
  syntax CHMatchPhase ::= chMatchPhaseBind() [klabel(chMatchPhaseBind)]
```

D137 S2 Location(70,27,70,74)

```k
  syntax CHMatchPhase ::= chMatchPhaseReady() [klabel(chMatchPhaseReady)]
```

D138 S2 Location(71,27,71,88)

```k
  syntax CHMatchPhase ::= chMatchPhaseNoMatchReady() [klabel(chMatchPhaseNoMatchReady)]
```

D139 S2 Location(72,27,72,72)

```k
  syntax CHMatchPhase ::= chMatchPhaseDone() [klabel(chMatchPhaseDone)]
```

D140 S2 Location(73,26,73,69)

```k
  syntax CHPlanPhase ::= chPlanPhaseWalk() [klabel(chPlanPhaseWalk)]
```

D141 S2 Location(74,26,74,69)

```k
  syntax CHPlanPhase ::= chPlanPhaseTest() [klabel(chPlanPhaseTest)]
```

D142 S2 Location(75,26,75,69)

```k
  syntax CHPlanPhase ::= chPlanPhaseBind() [klabel(chPlanPhaseBind)]
```

D143 S2 Location(76,26,76,71)

```k
  syntax CHPlanPhase ::= chPlanPhaseReady() [klabel(chPlanPhaseReady)]
```

D144 S2 Location(77,26,77,85)

```k
  syntax CHPlanPhase ::= chPlanPhaseNoMatchReady() [klabel(chPlanPhaseNoMatchReady)]
```

D145 S2 Location(78,26,78,69)

```k
  syntax CHPlanPhase ::= chPlanPhaseDone() [klabel(chPlanPhaseDone)]
```

D146 S2 Location(79,26,79,69)

```k
  syntax CHAfterWalk ::= chAfterWalkTest() [klabel(chAfterWalkTest)]
```

D147 S2 Location(80,26,80,69)

```k
  syntax CHAfterWalk ::= chAfterWalkBind() [klabel(chAfterWalkBind)]
```

D148 S2 Location(81,27,81,72)

```k
  syntax CHBuildPhase ::= chBuildPhaseCopy() [klabel(chBuildPhaseCopy)]
```

D149 S2 Location(82,27,82,72)

```k
  syntax CHBuildPhase ::= chBuildPhaseDone() [klabel(chBuildPhaseDone)]
```

D150 S2 Location(83,24,83,63)

```k
  syntax CHPattern ::= chPatternPVar() [klabel(chPatternPVar)]
```

D151 S2 Location(84,24,84,63)

```k
  syntax CHPattern ::= chPatternPNil() [klabel(chPatternPNil)]
```

D152 S2 Location(85,24,85,65)

```k
  syntax CHPattern ::= chPatternPCons() [klabel(chPatternPCons)]
```

D153 S2 Location(86,24,86,65)

```k
  syntax CHPattern ::= chPatternPLeaf() [klabel(chPatternPLeaf)]
```

D154 S2 Location(87,24,87,69)

```k
  syntax CHPattern ::= chPatternPBranch() [klabel(chPatternPBranch)]
```

D155 S2 Location(88,24,88,105)

```k
  syntax CHPattern ::= chPatternWildcardExtensionReserved() [klabel(chPatternWildcardExtensionReserved)]
```

D156 S2 Location(89,24,89,111)

```k
  syntax CHPattern ::= chPatternConstructorExtensionReserved() [klabel(chPatternConstructorExtensionReserved)]
```

D157 S2 Location(90,22,90,57)

```k
  syntax CHIndex ::= chIndexNone() [klabel(chIndexNone)]
```

D158 S2 Location(91,22,91,60)

```k
  syntax CHIndex ::= chIndexSome(Int) [klabel(chIndexSome)]
```

D159 S2 Location(92,23,92,60)

```k
  syntax CHResume ::= chResumeNone() [klabel(chResumeNone)]
```

D160 S2 Location(93,23,93,63)

```k
  syntax CHResume ::= chResumeSome(Int) [klabel(chResumeSome)]
```

D161 S2 Location(94,21,94,54)

```k
  syntax CHType ::= chTypeNone() [klabel(chTypeNone)]
```

D162 S2 Location(95,21,95,57)

```k
  syntax CHType ::= chTypeSome(Int) [klabel(chTypeSome)]
```

D163 S2 Location(96,23,96,54)

```k
  syntax CHOptRef ::= chRefNone() [klabel(chRefNone)]
```

D164 S2 Location(97,23,97,59)

```k
  syntax CHOptRef ::= chRefSome(CTRef) [klabel(chRefSome)]
```

D165 S2 Location(98,23,98,73)

```k
  syntax CHCommon ::= chCommon(CHSite, Int, CHResume) [klabel(chCommon)]
```

D166 S2 Location(99,23,99,60)

```k
  syntax CHStaged ::= chStagedNone() [klabel(chStagedNone)]
```

D167 S2 Location(100,23,100,73)

```k
  syntax CHStaged ::= chStagedU128Value(Int) [klabel(chStagedU128Value)]
```

D168 S2 Location(101,23,101,74)

```k
  syntax CHStaged ::= chStagedBoolValue(Bool) [klabel(chStagedBoolValue)]
```

D169 S2 Location(102,23,102,80)

```k
  syntax CHStaged ::= chStagedPendingNode(CHNode) [klabel(chStagedPendingNode)]
```

D170 S2 Location(103,23,103,73)

```k
  syntax CHStaged ::= chStagedPrimError(Int) [klabel(chStagedPrimError)]
```

D171 S2 Location(104,23,104,78)

```k
  syntax CHStaged ::= chStagedSelector(CHSelector) [klabel(chStagedSelector)]
```

D172 S2 Location(105,23,105,72)

```k
  syntax CHStaged ::= chStagedTypeTest(Bool) [klabel(chStagedTypeTest)]
```

D173 S2 Location(106,23,106,123)

```k
  syntax CHHelper ::= chScalar(CHCommon, CHMode, CTRef, CHOptRef, CHType, CHScalarPhase, Int, CHStaged) [klabel(chScalar)]
```

D174 S2 Location(107,23,107,91)

```k
  syntax CHHelper ::= chEnvGet(CHCommon, Int, CHIndex, CHOptRef, CHTri) [klabel(chEnvGet)]
```

D175 S2 Location(108,23,108,95)

```k
  syntax CHHelper ::= chEnvPut(CHCommon, Int, CTRef, CTEnv, CHIndex, CHTri) [klabel(chEnvPut)]
```

D176 S2 Location(109,23,109,82)

```k
  syntax CHHelper ::= chFind(CHCommon, Int, Int, CHIndex, CHTri) [klabel(chFind)]
```

D177 S2 Location(110,23,110,132)

```k
  syntax CHHelper ::= chBind(CHCommon, Int, CTSlice, CTSlice, Int, Int, CTEnv, CHIndex, CHBindPhase, CHBindStatus) [klabel(chBind)]
```

D178 S2 Location(111,23,111,111)

```k
  syntax CHHelper ::= chAppend(CHCommon, CTSlice, CTRef, Int, Int, CHOptRef, CHAppendPhase) [klabel(chAppend)]
```

D179 S2 Location(112,23,112,78)

```k
  syntax CHHelper ::= chValidate(CHCommon, CTRef, CHTri) [klabel(chValidate)]
```

D180 S2 Location(113,23,113,79)

```k
  syntax CHHelper ::= chEqual(CHCommon, CTRef, CTRef, CHTri) [klabel(chEqual)]
```

D181 S2 Location(114,23,114,141)

```k
  syntax CHHelper ::= chMatch(CHCommon, CTRef, Int, CTEnv, CTEnv, CHPattern, Int, Int, Int, CHOptRef, CHMatchPhase, CHTri) [klabel(chMatch)]
```

D182 S2 Location(115,23,115,150)

```k
  syntax CHHelper ::= chPlan(CHCommon, Int, CTRef, CTEnv, CTEnv, Int, CHPlanPhase, CHAfterWalk, CTRef, CTSlice, Int, CHIndex, CHTri) [klabel(chPlan)]
```

D183 S2 Location(116,23,116,121)

```k
  syntax CHHelper ::= chBuild(CHCommon, Int, Int, CTSlice, Int, Int, CHOptRef, CHOptRef, CHBuildPhase) [klabel(chBuild)]
```

D184 S2 Location(117,23,117,74)

```k
  syntax CHResult ::= chResultValidated(Bool) [klabel(chResultValidated)]
```

D185 S2 Location(118,23,118,73)

```k
  syntax CHResult ::= chResultEnvFound(CTRef) [klabel(chResultEnvFound)]
```

D186 S2 Location(119,23,119,72)

```k
  syntax CHResult ::= chResultEnvMissing() [klabel(chResultEnvMissing)]
```

D187 S2 Location(120,23,120,75)

```k
  syntax CHResult ::= chResultEnvUpdated(Int) [klabel(chResultEnvUpdated)]
```

D188 S2 Location(121,23,121,73)

```k
  syntax CHResult ::= chResultFindFound(Int) [klabel(chResultFindFound)]
```

D189 S2 Location(122,23,122,74)

```k
  syntax CHResult ::= chResultFindMissing() [klabel(chResultFindMissing)]
```

D190 S2 Location(123,23,123,69)

```k
  syntax CHResult ::= chResultBindOk(CTEnv) [klabel(chResultBindOk)]
```

D191 S2 Location(124,23,124,66)

```k
  syntax CHResult ::= chResultBindBad() [klabel(chResultBindBad)]
```

D192 S2 Location(125,23,125,79)

```k
  syntax CHResult ::= chResultAppendDone(CTSlice) [klabel(chResultAppendDone)]
```

D193 S2 Location(126,23,126,79)

```k
  syntax CHResult ::= chResultScalarValue(CTRef) [klabel(chResultScalarValue)]
```

D194 S2 Location(127,23,127,77)

```k
  syntax CHResult ::= chResultScalarError(Int) [klabel(chResultScalarError)]
```

D195 S2 Location(128,23,128,90)

```k
  syntax CHResult ::= chResultScalarSelector(CHSelector) [klabel(chResultScalarSelector)]
```

D196 S2 Location(129,23,129,84)

```k
  syntax CHResult ::= chResultScalarTypeTest(Bool) [klabel(chResultScalarTypeTest)]
```

D197 S2 Location(130,23,130,75)

```k
  syntax CHResult ::= chResultEqualDone(CTRef) [klabel(chResultEqualDone)]
```

D198 S2 Location(131,23,131,81)

```k
  syntax CHResult ::= chResultMatchMatched(CTEnv) [klabel(chResultMatchMatched)]
```

D199 S2 Location(132,23,132,76)

```k
  syntax CHResult ::= chResultMatchNoMatch() [klabel(chResultMatchNoMatch)]
```

D200 S2 Location(133,23,133,84)

```k
  syntax CHResult ::= chResultPlanMatched(Int, CTEnv) [klabel(chResultPlanMatched)]
```

D201 S2 Location(134,23,134,74)

```k
  syntax CHResult ::= chResultPlanNoMatch() [klabel(chResultPlanNoMatch)]
```

D202 S2 Location(135,23,135,75)

```k
  syntax CHResult ::= chResultBuildDone(CTRef) [klabel(chResultBuildDone)]
```

D203 S2 Location(136,29,136,62)

```k
  syntax CHHelperOption ::= chNoHelper() [klabel(chNoHelper)]
```

D204 S2 Location(137,29,137,74)

```k
  syntax CHHelperOption ::= chSomeHelper(CHHelper) [klabel(chSomeHelper)]
```

D205 S2 Location(138,29,138,62)

```k
  syntax CHResultOption ::= chNoResult() [klabel(chNoResult)]
```

D206 S2 Location(139,29,139,74)

```k
  syntax CHResultOption ::= chSomeResult(CHResult) [klabel(chSomeResult)]
```

D207 S2 Location(140,23,140,111)

```k
  syntax CHAnswer ::= chHelperAnswer(String, CHHelperOption, CTLanes, CHHelperOption) [klabel(chHelperAnswer)]
```

D208 S2 Location(141,23,141,111)

```k
  syntax CHAnswer ::= chResultAnswer(String, CHResultOption, CTLanes, CHResultOption) [klabel(chResultAnswer)]
```

D209 S2 Location(142,24,142,59)

```k
  syntax CHQueries ::= chNoQueries() [klabel(chNoQueries)]
```

D210 S2 Location(143,24,143,96)

```k
  syntax CHQueries ::= chHelperQuery(String, CHHelperOption, CHQueries) [klabel(chHelperQuery)]
```

D211 S2 Location(144,24,144,96)

```k
  syntax CHQueries ::= chResultQuery(String, CHResultOption, CHQueries) [klabel(chResultQuery)]
```

D212 S2 Location(145,24,145,59)

```k
  syntax CHAnswers ::= chNoAnswers() [klabel(chNoAnswers)]
```

D213 S2 Location(146,24,146,78)

```k
  syntax CHAnswers ::= chAnswerRow(CHAnswer, CHAnswers) [klabel(chAnswerRow)]
```

D214 S3 Location(10,22,10,73)

```k
  syntax CTLanes ::= ctJoin(CTLanes, CTLanes) [function, klabel(ctJoin)]
```

D215 S3 Location(13,18,13,60)

```k
  syntax Int ::= ctSize(CTLanes) [function, klabel(ctSize)]
```

D216 S3 Location(16,22,16,69)

```k
  syntax CTLanes ::= ctTake(Int, CTLanes) [function, klabel(ctTake)]
```

D217 S3 Location(17,22,17,69)

```k
  syntax CTLanes ::= ctDrop(Int, CTLanes) [function, klabel(ctDrop)]
```

D218 S3 Location(18,18,18,61)

```k
  syntax Int ::= ctAt(Int, CTLanes) [function, klabel(ctAt)]
```

D219 S3 Location(25,18,25,62)

```k
  syntax Int ::= ctEnvTag(CTEnv) [function, klabel(ctEnvTag)]
```

D220 S3 Location(26,18,26,66)

```k
  syntax Int ::= ctEnvIndex(CTEnv) [function, klabel(ctEnvIndex)]
```

D221 S3 Location(27,18,27,77)

```k
  syntax Int ::= ctFunctionTag(CTFunction) [function, klabel(ctFunctionTag)]
```

D222 S3 Location(28,18,28,81)

```k
  syntax Int ::= ctFunctionIndex(CTFunction) [function, klabel(ctFunctionIndex)]
```

D223 S3 Location(29,18,29,62)

```k
  syntax Int ::= ctRefTag(CTRef) [function, klabel(ctRefTag)]
```

D224 S3 Location(30,18,30,66)

```k
  syntax Int ::= ctRefIndex(CTRef) [function, klabel(ctRefIndex)]
```

D225 S3 Location(31,18,31,57)

```k
  syntax Int ::= ctBool(Bool) [function, klabel(ctBool)]
```

D226 S3 Location(46,20,46,73)

```k
  syntax CTEnv ::= ctEnvDecode(Int, Int) [function, klabel(ctEnvDecode)]
```

D227 S3 Location(47,25,47,88)

```k
  syntax CTFunction ::= ctFunctionDecode(Int, Int) [function, klabel(ctFunctionDecode)]
```

D228 S3 Location(48,20,48,73)

```k
  syntax CTRef ::= ctRefDecode(Int, Int) [function, klabel(ctRefDecode)]
```

D229 S3 Location(55,19,55,69)

```k
  syntax Bool ::= ctBoolDecode(Int) [function, klabel(ctBoolDecode)]
```

D230 S3 Location(58,18,58,65)

```k
  syntax Int ::= ctBinary(CTBinary) [function, klabel(ctBinary)]
```

D231 S3 Location(59,23,59,77)

```k
  syntax CTBinary ::= ctBinaryDecode(Int) [function, klabel(ctBinaryDecode)]
```

D232 S3 Location(74,18,74,62)

```k
  syntax Int ::= ctUnary(CTUnary) [function, klabel(ctUnary)]
```

D233 S3 Location(75,22,75,74)

```k
  syntax CTUnary ::= ctUnaryDecode(Int) [function, klabel(ctUnaryDecode)]
```

D234 S3 Location(80,18,80,68)

```k
  syntax Int ::= ctExhaust(CTExhaust) [function, klabel(ctExhaust)]
```

D235 S3 Location(81,24,81,80)

```k
  syntax CTExhaust ::= ctExhaustDecode(Int) [function, klabel(ctExhaustDecode)]
```

D236 S3 Location(96,18,96,72)

```k
  syntax Int ::= ctSliceStart(CTSlice) [function, klabel(ctSliceStart)]
```

D237 S3 Location(97,18,97,68)

```k
  syntax Int ::= ctSliceLen(CTSlice) [function, klabel(ctSliceLen)]
```

D238 S3 Location(100,22,100,78)

```k
  syntax CTLanes ::= ctEncodeFrame(CTFrame) [function, klabel(ctEncodeFrame)]
```

D239 S3 Location(101,22,101,78)

```k
  syntax CTFrame ::= ctDecodeFrame(CTLanes) [function, klabel(ctDecodeFrame)]
```

D240 S3 Location(122,22,122,82)

```k
  syntax CTLanes ::= ctBindingLanes(CTBinding) [function, klabel(ctBindingLanes)]
```

D241 S3 Location(123,22,123,85)

```k
  syntax CTLanes ::= ctMatchingLanes(CTMatching) [function, klabel(ctMatchingLanes)]
```

D242 S3 Location(124,22,124,88)

```k
  syntax CTLanes ::= ctPrimitiveLanes(CTPrimitive) [function, klabel(ctPrimitiveLanes)]
```

D243 S3 Location(125,22,125,82)

```k
  syntax CTLanes ::= ctOutcomeLanes(CTOutcome) [function, klabel(ctOutcomeLanes)]
```

D244 S3 Location(136,24,136,90)

```k
  syntax CTBinding ::= ctBindingDecode(Int, Int, Int) [function, klabel(ctBindingDecode)]
```

D245 S3 Location(137,25,137,93)

```k
  syntax CTMatching ::= ctMatchingDecode(Int, Int, Int) [function, klabel(ctMatchingDecode)]
```

D246 S3 Location(138,26,138,96)

```k
  syntax CTPrimitive ::= ctPrimitiveDecode(Int, Int, Int) [function, klabel(ctPrimitiveDecode)]
```

D247 S3 Location(139,24,139,90)

```k
  syntax CTOutcome ::= ctOutcomeDecode(Int, Int, Int) [function, klabel(ctOutcomeDecode)]
```

D248 S3 Location(150,22,150,84)

```k
  syntax CTLanes ::= ctEncodeControl(CTControl) [function, klabel(ctEncodeControl)]
```

D249 S3 Location(151,24,151,84)

```k
  syntax CTControl ::= ctDecodeControl(CTLanes) [function, klabel(ctDecodeControl)]
```

D250 S3 Location(174,18,174,73)

```k
  syntax Int ::= ctFrameCount(CTFrames) [function, klabel(ctFrameCount)]
```

D251 S3 Location(177,22,177,81)

```k
  syntax CTLanes ::= ctEncodeFrames(CTFrames) [function, klabel(ctEncodeFrames)]
```

D252 S3 Location(180,23,180,86)

```k
  syntax CTFrames ::= ctDecodeFrames(Int, CTLanes) [function, klabel(ctDecodeFrames)]
```

D253 S3 Location(183,18,183,64)

```k
  syntax Int ::= ctAlloc0(CTAlloc) [function, klabel(ctAlloc0)]
```

D254 S3 Location(185,18,185,64)

```k
  syntax Int ::= ctAlloc1(CTAlloc) [function, klabel(ctAlloc1)]
```

D255 S3 Location(187,18,187,64)

```k
  syntax Int ::= ctAlloc2(CTAlloc) [function, klabel(ctAlloc2)]
```

D256 S3 Location(189,18,189,67)

```k
  syntax Int ::= ctActive0(CTActive) [function, klabel(ctActive0)]
```

D257 S3 Location(191,18,191,67)

```k
  syntax Int ::= ctActive1(CTActive) [function, klabel(ctActive1)]
```

D258 S3 Location(193,18,193,67)

```k
  syntax Int ::= ctActive2(CTActive) [function, klabel(ctActive2)]
```

D259 S3 Location(195,18,195,67)

```k
  syntax Int ::= ctActive3(CTActive) [function, klabel(ctActive3)]
```

D260 S3 Location(197,22,197,75)

```k
  syntax CTLanes ::= ctEncodeRoot(CTRoot) [function, klabel(ctEncodeRoot)]
```

D261 S3 Location(198,21,198,75)

```k
  syntax CTRoot ::= ctDecodeRoot(CTLanes) [function, klabel(ctDecodeRoot)]
```

D262 S3 Location(201,23,201,86)

```k
  syntax CTAnswer ::= ctObserveRoot(String, CTRoot) [function, klabel(ctObserveRoot)]
```

D263 S3 Location(202,23,202,101)

```k
  syntax CTAnswer ::= ctObserveEncoded(String, CTRoot, CTLanes) [function, klabel(ctObserveEncoded)]
```

D264 S3 Location(205,24,205,80)

```k
  syntax CTAnswers ::= ctObserveAll(CTQueries) [function, klabel(ctObserveAll)]
```

D265 S4 Location(7,20,7,50)

```k
  syntax CTRef ::= ctConst(Int) [klabel(ctConst)]
```

D266 S4 Location(8,22,8,50)

```k
                   | ctData(Int) [klabel(ctData)]
```

D267 S4 Location(9,20,9,51)

```k
  syntax CTEnv ::= ctEnvNone() [klabel(ctEnvNone)]
```

D268 S4 Location(10,22,10,56)

```k
                   | ctEnvSome(Int) [klabel(ctEnvSome)]
```

D269 S4 Location(11,25,11,66)

```k
  syntax CTFunction ::= ctFunctionNone() [klabel(ctFunctionNone)]
```

D270 S4 Location(12,27,12,71)

```k
                        | ctFunctionSome(Int) [klabel(ctFunctionSome)]
```

D271 S4 Location(13,22,13,57)

```k
  syntax CTSlice ::= ctSlice(Int, Int) [klabel(ctSlice)]
```

D272 S4 Location(14,23,14,46)

```k
  syntax CTBinary ::= ctAdd() [klabel(ctAdd)]
```

D273 S4 Location(15,25,15,48)

```k
                      | ctSub() [klabel(ctSub)]
```

D274 S4 Location(16,25,16,48)

```k
                      | ctMul() [klabel(ctMul)]
```

D275 S4 Location(17,25,17,46)

```k
                      | ctEq() [klabel(ctEq)]
```

D276 S4 Location(18,25,18,46)

```k
                      | ctLt() [klabel(ctLt)]
```

D277 S4 Location(19,25,19,50)

```k
                      | ctCons() [klabel(ctCons)]
```

D278 S4 Location(20,25,20,54)

```k
                      | ctBranch() [klabel(ctBranch)]
```

D279 S4 Location(21,22,21,47)

```k
  syntax CTUnary ::= ctLeaf() [klabel(ctLeaf)]
```

D280 S4 Location(22,24,22,47)

```k
                     | ctNot() [klabel(ctNot)]
```

D281 S4 Location(23,22,23,67)

```k
  syntax CTFrame ::= ctLetF(Int, Int, CTEnv, Int) [klabel(ctLetF)]
```

D282 S4 Location(24,24,24,76)

```k
                     | ctLeftF(CTBinary, Int, CTEnv, Int) [klabel(ctLeftF)]
```

D283 S4 Location(25,24,25,73)

```k
                     | ctRightF(CTBinary, CTRef, Int) [klabel(ctRightF)]
```

D284 S4 Location(26,24,26,65)

```k
                     | ctUnaryF(CTUnary, Int) [klabel(ctUnaryF)]
```

D285 S4 Location(27,24,27,67)

```k
                     | ctIfF(Int, Int, CTEnv, Int) [klabel(ctIfF)]
```

D286 S4 Location(28,24,28,72)

```k
                     | ctMatchF(CTSlice, CTEnv, Int) [klabel(ctMatchF)]
```

D287 S4 Location(29,24,29,84)

```k
                     | ctArgsF(Int, CTSlice, CTSlice, CTEnv, Int) [klabel(ctArgsF)]
```

D288 S4 Location(30,24,30,70)

```k
                     | ctReturnF(Int, CTEnv, Int) [klabel(ctReturnF)]
```

D289 S4 Location(31,24,31,63)

```k
                     | ctScopeF(CTEnv, Int) [klabel(ctScopeF)]
```

D290 S4 Location(32,24,32,131)

```k
                     | ctConstructorFieldsF(Int, Int, Int, Int, Bool, CTSlice, CTSlice, CTEnv, Int) [klabel(ctConstructorFieldsF)]
```

D291 S4 Location(33,23,33,56)

```k
  syntax CTFrames ::= ctNoFrames() [klabel(ctNoFrames)]
```

D292 S4 Location(34,25,34,69)

```k
                      | ctFrame(CTFrame, CTFrames) [klabel(ctFrame)]
```

D293 S4 Location(35,24,35,61)

```k
  syntax CTBinding ::= ctBindingBad() [klabel(ctBindingBad)]
```

D294 S4 Location(36,26,36,66)

```k
                       | ctBindingOk(CTEnv) [klabel(ctBindingOk)]
```

D295 S4 Location(37,25,37,56)

```k
  syntax CTMatching ::= ctNoMatch() [klabel(ctNoMatch)]
```

D296 S4 Location(38,27,38,63)

```k
                        | ctMatched(CTEnv) [klabel(ctMatched)]
```

D297 S4 Location(39,26,39,66)

```k
  syntax CTPrimitive ::= ctPrimValue(CTRef) [klabel(ctPrimValue)]
```

D298 S4 Location(40,28,40,66)

```k
                         | ctPrimError(Int) [klabel(ctPrimError)]
```

D299 S4 Location(41,24,41,52)

```k
  syntax CTControl ::= ctEval(Int) [klabel(ctEval)]
```

D300 S4 Location(42,26,42,60)

```k
                       | ctReturn(CTRef) [klabel(ctReturn)]
```

D301 S4 Location(43,26,43,86)

```k
                       | ctScheduleNext(CTFrame, Int, CTEnv) [klabel(ctScheduleNext)]
```

D302 S4 Location(44,26,44,67)

```k
                       | ctInvoke(Int, CTSlice) [klabel(ctInvoke)]
```

D303 S4 Location(45,26,45,72)

```k
                       | ctEnter(CTFunction, CTSlice) [klabel(ctEnter)]
```

D304 S4 Location(46,26,46,72)

```k
                       | ctBound(CTBinding, Int, Int) [klabel(ctBound)]
```

D305 S4 Location(47,26,47,74)

```k
                       | ctCases(CTRef, CTSlice, CTEnv) [klabel(ctCases)]
```

D306 S4 Location(48,26,48,101)

```k
                       | ctCaseResult(CTMatching, CTRef, Int, CTSlice, CTEnv) [klabel(ctCaseResult)]
```

D307 S4 Location(49,26,49,74)

```k
                       | ctPrimResult(CTPrimitive) [klabel(ctPrimResult)]
```

D308 S4 Location(50,26,50,56)

```k
                       | ctError(Int) [klabel(ctError)]
```

D309 S4 Location(51,26,51,82)

```k
                       | ctMaterialize(Int, Int, CTSlice) [klabel(ctMaterialize)]
```

D310 S4 Location(52,24,52,49)

```k
  syntax CTExhaust ::= ctFuel() [klabel(ctFuel)]
```

D311 S4 Location(53,26,53,61)

```k
                       | ctDataNodes() [klabel(ctDataNodes)]
```

D312 S4 Location(54,26,54,63)

```k
                       | ctDataFields() [klabel(ctDataFields)]
```

D313 S4 Location(55,26,55,75)

```k
                       | ctEnvironmentCells() [klabel(ctEnvironmentCells)]
```

D314 S4 Location(56,26,56,65)

```k
                       | ctHelperTasks() [klabel(ctHelperTasks)]
```

D315 S4 Location(57,26,57,63)

```k
                       | ctHelperWork() [klabel(ctHelperWork)]
```

D316 S4 Location(58,26,58,79)

```k
                       | ctSerializationBytes() [klabel(ctSerializationBytes)]
```

D317 S4 Location(59,24,59,55)

```k
  syntax CTOutcome ::= ctRunning() [klabel(ctRunning)]
```

D318 S4 Location(60,26,60,60)

```k
                       | ctHalted(CTRef) [klabel(ctHalted)]
```

D319 S4 Location(61,26,61,62)

```k
                       | ctRejected(Int) [klabel(ctRejected)]
```

D320 S4 Location(62,26,62,70)

```k
                       | ctExhausted(CTExhaust) [klabel(ctExhausted)]
```

D321 S4 Location(63,22,63,62)

```k
  syntax CTAlloc ::= ctAlloc(Int, Int, Int) [klabel(ctAlloc)]
```

D322 S4 Location(64,23,64,70)

```k
  syntax CTActive ::= ctActive(Int, Int, Int, Int) [klabel(ctActive)]
```

D323 S4 Location(65,21,65,166)

```k
  syntax CTRoot ::= ctRoot(CTControl, Int, CTEnv, Int, CTOutcome, Int, Int, Int, Int, Int, Int, CTAlloc, CTActive, CTActive, CTAlloc, Int, CTFrames) [klabel(ctRoot)]
```

D324 S4 Location(66,22,66,53)

```k
  syntax CTLanes ::= ctNoLanes() [klabel(ctNoLanes)]
```

D325 S4 Location(67,24,67,61)

```k
                     | ctLane(Int, CTLanes) [klabel(ctLane)]
```

D326 S4 Location(68,23,68,83)

```k
  syntax CTAnswer ::= ctAnswer(String, CTRoot, CTLanes, CTRoot) [klabel(ctAnswer)]
```

D327 S4 Location(69,24,69,59)

```k
  syntax CTQueries ::= ctNoQueries() [klabel(ctNoQueries)]
```

D328 S4 Location(70,26,70,78)

```k
                       | ctQuery(String, CTRoot, CTQueries) [klabel(ctQuery)]
```

D329 S4 Location(71,24,71,59)

```k
  syntax CTAnswers ::= ctNoAnswers() [klabel(ctNoAnswers)]
```

D330 S4 Location(72,26,72,80)

```k
                       | ctAnswerRow(CTAnswer, CTAnswers) [klabel(ctAnswerRow)]
```
