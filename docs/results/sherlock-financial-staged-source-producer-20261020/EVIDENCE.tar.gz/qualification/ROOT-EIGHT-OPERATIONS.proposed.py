"""Proposed one-use Root composition of existing ordinary capture functions.
UNSELECTED/UNRUN. Root supplies actual selection after ordinary review.
No product imports; no helper main, retries, Cargo, SDK or old-test execution.
"""
from pathlib import Path
import hashlib,json,os,re,runpy,stat,sys

B=Path(__file__).resolve().parent
load=lambda p:json.loads(Path(p).read_text())
def rawpin(p):
    p=Path(p);b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
PLAN={'path': '/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/public-financial-lowering-first-real-gap-20261020/next-real-financial-owner-entry-source-consumer-request-01/close-MP1-MP2-real-staged-source-producer-owner-request-02/literal-staged-bridge-candidate-04/ordinary-qualification-current-Core189-01/PROPOSED-EIGHT-OPERATIONS.json', 'bytes': 37588, 'sha256': 'aa5758de59e3da76054ee20f414a07141e9606e0c2b29169c3f0df7b6ede5ee0'}
FLAT={'path': '/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/public-financial-lowering-first-real-gap-20261020/next-real-financial-owner-entry-source-consumer-request-01/close-MP1-MP2-real-staged-source-producer-owner-request-02/literal-staged-bridge-candidate-04/ordinary-qualification-current-Core189-01/STATIC-PREPOST-PINS.json', 'bytes': 172292, 'sha256': 'e75d7d06cf2b56f5969287bf141caf157d319ad48929f9a2e2536a348a77184a'}
assert rawpin(PLAN['path'])==PLAN and rawpin(FLAT['path'])==FLAT
j=load(PLAN['path']);h=j['captureHelper'];assert rawpin(h['path'])==h
api=runpy.run_path(h['path'],run_name='root_fin_bridge_existing_ordinary_functions_only')
pin,check=api['pin'],api['check']
def durable(p,x):
    assert not p.exists(),str(p)
    api['save'](p,x)
    with p.open('rb') as f:os.fsync(f.fileno())
    fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
def inventory():
    out=[]
    for dr in load(B/'CORE-EXACT-L-DIRECTORY-MEMBERSHIP.json')['directories']:
        d=Path(dr['directory']);assert sorted(p.name for p in d.iterdir())==sorted(x['name'] for x in dr['entries'])
        for x in dr['entries']:
            p=d/x['name'];s=p.lstat()
            assert stat.S_ISLNK(s.st_mode)==x['symlink'] and stat.S_ISREG(s.st_mode)==x['regularFile']
            assert oct(stat.S_IMODE(s.st_mode))==x['mode'] and s.st_size==x['size']
            if x['symlink']:assert os.readlink(p)==x['linkTarget']
            if 'qualifiedLibrary' in x:check(x['qualifiedLibrary'])
        out.append(dict(directory=str(d),members=len(dr['entries']),exact=True))
    return out
def list_names(out):
    text=out.decode('utf-8',errors='strict');lines=text.splitlines()
    assert lines and all(lines)
    matches=[re.fullmatch(r'([A-Za-z_][A-Za-z0-9_:]*): test',s) for s in lines]
    assert all(matches),'unexpected benchmark, list diagnostic, summary or junk'
    names=[m.group(1) for m in matches];assert names==sorted(set(names))
    assert text==''.join(n+': test\n' for n in names)
    return names
def pretty(out,names,filtered):
    n=len(names);unit='test' if n==1 else 'tests'
    body='\nrunning '+str(n)+' '+unit+'\n'+''.join('test '+name+' ... ok\n' for name in names)
    pattern=re.escape(body)+r'\ntest result: ok\. '+str(n)+r' passed; 0 failed; 0 ignored; 0 measured; '+str(filtered)+r' filtered out; finished in \d+\.\d+s\n\n'
    assert re.fullmatch(pattern,out.decode('utf-8',errors='strict')),'not exact selected-test whole pretty envelope'
def main(selection_path):
    selection=load(selection_path)
    assert selection['RootSelectedAllEight'] is True
    assert selection['RootReadFullOrdinaryReview'] is True and selection['ordinaryReviewEligibleAllEight'] is True
    assert selection['RootReadBothSourceOpinions'] is True
    assert selection['proposal']==PLAN and selection['flat']==FLAT and selection['composition']==pin(__file__) and selection['helper']==h
    rv=selection['ordinaryReview'];check(rv)
    ops=j['operations'];assert len(ops)==8 and selection['selectedIds']==[o['id'] for o in ops]
    controls=[pin(selection_path),pin(__file__),PLAN,FLAT,h,rv]
    flat=load(FLAT['path'])['files'];assert len(flat)==458
    closures=load(B/'EXPECTED-DEP-MEMBERSHIP.json');expected=load(B/'EXPECTED-BRIDGE-TEST-NAMES.json')
    internal=expected['internalExactNames'];external=expected['externalExactNames'];prefix=expected['internalPrefix']
    assert internal==sorted(set(internal)) and len(internal)==9 and len(external)==2 and external==sorted(set(external))
    source=load(B/'SOURCE-COMPOSITION.json');canonical=[x['currentPW'] for x in source['allCurrentCanonicalMembers']];assert len(canonical)==189
    generated=[];records=[];fullnames=None;external_names=None
    def checks():
        s=api['static_check'](flat+controls+canonical+generated);d=inventory()
        assert s['all_match'],'fail-stop changed static/control/canonical/generated pin'
        return dict(static=s,LDirectories=d,staticCount=len(flat),canonicalPreimages=len(canonical),generated=len(generated))
    checks();W=Path(ops[0]['cwd']);A=B/'ordinary-QA/actual-eight-01'
    for p in [W,A]:
        assert not p.exists() and not p.is_symlink(),str(p)
        assert not any(x.is_symlink() for x in p.parents)
    for o in ops:
        assert o['wallSeconds']==30 and o['keptBytesPerStream']==131072
        for p in o['outputs']:assert not Path(p).exists()
    W.mkdir();(W/'build').mkdir()
    for name in ['normal','cfgtest','external','test']:(W/'tmp'/name).mkdir(parents=True)
    A.mkdir(parents=True);durable(A/'ROOT-SELECTION.json',selection)
    try:
        for ix,o in enumerate(ops):
            phase=A/o['id'];phase.mkdir();durable(phase/'PRECHECK.json',checks())
            raw=api['capture'](o,phase)
            # Immediately preserve the exact returned result before checks/parsing.
            durable(phase/'RESULT.json',raw)
            for name in ['COMMAND.json','stdout.bin','stderr.bin','RESULT.json']:
                with (phase/name).open('rb') as f:os.fsync(f.fileno())
            durable(phase/'POSTCHECK.json',checks())
            assert load(phase/'COMMAND.json')==o
            assert raw['actual_exit']==0 and raw['controller_failure'] is None
            assert len(raw['streams'])==2 and {Path(x['path']).name for x in raw['streams']}=={'stdout.bin','stderr.bin'}
            for x in raw['streams']:
                check(x);assert x['full_stream_retained'] and x['bytes']==x['bytes_seen']==x['bytes_retained']
            out=(phase/'stdout.bin').read_bytes();err=(phase/'stderr.bin').read_bytes()
            accepted=dict(id=o['id'],rawResult=pin(phase/'RESULT.json'),accepted=True)
            if ix in [0,1,5]:
                assert out==b'';products=[]
                for path in o['outputs']:
                    p=Path(path);assert p.is_file() and not p.is_symlink() and p.stat().st_size>0;products.append(pin(p))
                durable(phase/'ACTUAL-GENERATED-PINS.json',dict(files=products))
                key={0:'normal',1:'cfgTest',5:'externalTest'}[ix];cl=closures[key]
                allowed={str(Path(x['path']).resolve(strict=True)):x for x in cl['files']};assert len(allowed)==cl['count']=={0:117,1:188,5:1}[ix]
                deps=api['dep_inputs'](o['outputs'][1],allowed);seen={str(Path(x['selected_binding']).resolve(strict=True)) for x in deps};assert seen==set(allowed)
                if ix<2:assert any(x['path'].endswith('/shared/fin_carrier.rs') for x in deps)
                if ix==1:assert any(x['path'].endswith('/shared/fin_staged_source_tests.rs') for x in deps)
                if ix==5:
                    assert seen=={str(Path(o['sourceRoot']).resolve(strict=True))}
                    # All generated pins already rechecked before and after: in particular op01 normal rlib.
                    assert any(x['path']==o['generatedRequiredInputs'][0] for x in generated)
                durable(phase/'EXACT-DEP-MEMBERSHIP.json',dict(files=deps,canonicalCount=len(seen),expected=cl['count'],exact=True))
                for k,p in enumerate(o['outputs']):os.chmod(p,0o500 if ix in [1,5] and k==0 else 0o400)
                generated.extend(products);accepted.update(exactCanonicalDependencies=len(seen),generated=products,stderrFullRetained=True)
            else:
                assert err==b''
                if ix in [2,3,6]:
                    names=list_names(out)
                    if ix==2:
                        assert [n for n in names if prefix in n]==internal;fullnames=names
                    elif ix==3:assert names==internal
                    else:assert names==external;external_names=names
                    membership=dict(names=names,count=len(names),sourceNames=pin(B/'EXPECTED-BRIDGE-TEST-NAMES.json'),exactProjection=internal if ix<6 else external)
                    durable(phase/'FROZEN-ACTUAL-MEMBERSHIP.json',membership)
                    generated.extend([pin(phase/'stdout.bin'),pin(phase/'FROZEN-ACTUAL-MEMBERSHIP.json')]);accepted['members']=len(names)
                elif ix==4:
                    assert fullnames is not None;filtered=len(fullnames)-9;assert filtered>=0
                    pretty(out,internal,filtered);accepted.update(exactNames=internal,passed=9,failed=0,ignored=0,measured=0,filteredOut=filtered,fullListCount=len(fullnames))
                else:
                    assert ix==7 and external_names==external
                    pretty(out,external,0);accepted.update(exactNames=external,passed=2,failed=0,ignored=0,measured=0,filteredOut=0,fullListCount=2)
            durable(phase/'ACCEPTANCE.json',accepted);records.append(accepted);durable(phase/'FINAL-PIN-CHECK.json',checks())
        durable(A/'ROOT-RESULT.json',dict(allEightPassed=True,phases=records,generated=generated,canonicalCoreMembers=189,compiledCoreSnapshotMembers=190,newInternalTests=9,newExternalTests=2,legacySixteenReplayed=False,scope='Full normal Core integration and only9+2 prepared-source tests. FinAdmittedExtras not admission; same_source not target/preparation identity. No fullfinance owner/admission/genesis/runtime/MP3-7/native/proof/EARS acceptance.',retry=False))
    except BaseException as e:
        durable(A/'FAILURE.json',dict(error=type(e).__name__+': '+str(e),phasesCompleted=records,retry=False,remainingUnrun=True));raise
if __name__=='__main__':main(sys.argv[1])
