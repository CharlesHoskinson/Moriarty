All diagnostics; complete raw blocks and sources retained. Text classification only.

## 1: cxLength — c6-positive-context-laws.k:7

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxLength)`, or replace it by `symbol(cxLength)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-laws.k)
	Location(7,18,7,64)
	7 |	  syntax Int ::= cxLength(CTLanes) [function, klabel(cxLength)]
	  .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 2: cxPositiveRoundtrip — c6-positive-context-laws.k:10

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxPositiveRoundtrip)`, or replace it by `symbol(cxPositiveRoundtrip)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-laws.k)
	Location(10,19,10,89)
	10 |	  syntax Bool ::= cxPositiveRoundtrip(CXPayload) [function,
klabel(cxPositiveRoundtrip)]
	   .	                 
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 3: cxEncodedWidth — c6-positive-context-laws.k:11

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxEncodedWidth)`, or replace it by `symbol(cxEncodedWidth)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-laws.k)
	Location(11,19,11,79)
	11 |	                | cxEncodedWidth(CXPayload) [function,
klabel(cxEncodedWidth)]
	   .	                 
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 4: cxDescriptorWidth — c6-positive-context-laws.k:12

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxDescriptorWidth)`, or replace it by `symbol(cxDescriptorWidth)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-laws.k)
	Location(12,19,12,83)
	12 |	                | cxDescriptorWidth(CXInput) [function,
klabel(cxDescriptorWidth)]
	   .	                 
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 5: cxExt — c6-positive-context-syntax.k:6

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxExt)`, or replace it by `symbol(cxExt)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(6,26,6,127)
	6 |	  syntax CXExtFields ::= cxExt(Int, Int, Int, Int, Int, Int, Int, Int,
Int, Int, Int, Int, Int, Int, Int, Int) [klabel(cxExt)]
	  .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 6: cxBudgets — c6-positive-context-syntax.k:7

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxBudgets)`, or replace it by `symbol(cxBudgets)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(7,24,7,63)
	7 |	  syntax CXBudgets ::= cxBudgets(Int, Int) [klabel(cxBudgets)]
	  .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 7: cxBounds — c6-positive-context-syntax.k:8

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxBounds)`, or replace it by `symbol(cxBounds)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(8,23,8,160)
	8 |	  syntax CXBounds ::= cxBounds(Int, Int, Int, Int, Int, Int, Int, Int,
Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int)
[klabel(cxBounds)]
	  .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 8: cxLayoutCaps — c6-positive-context-syntax.k:9

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxLayoutCaps)`, or replace it by `symbol(cxLayoutCaps)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(9,27,9,82)
	9 |	  syntax CXLayoutCaps ::= cxLayoutCaps(Int, Int, Int, Int)
[klabel(cxLayoutCaps)]
	  .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 9: cxHostLimits — c6-positive-context-syntax.k:10

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxHostLimits)`, or replace it by `symbol(cxHostLimits)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(10,27,10,87)
	10 |	  syntax CXHostLimits ::= cxHostLimits(Int, Int, Int, Int, Int)
[klabel(cxHostLimits)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 10: cxPhysCaps — c6-positive-context-syntax.k:11

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxPhysCaps)`, or replace it by `symbol(cxPhysCaps)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(11,25,11,191)
	11 |	  syntax CXPhysCaps ::= cxPhysCaps(Int, Int, Int, Int, Int, Int, Int,
Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int,
Int, Int, Int, Int) [klabel(cxPhysCaps)]
	   .	                       
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 11: cxAbsent — c6-positive-context-syntax.k:12

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxAbsent)`, or replace it by `symbol(cxAbsent)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(12,20,12,49)
	12 |	  syntax CXExt ::= cxAbsent() [klabel(cxAbsent)]
	   .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 12: cxPresent — c6-positive-context-syntax.k:13

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxPresent)`, or replace it by `symbol(cxPresent)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(13,20,13,62)
	13 |	  syntax CXExt ::= cxPresent(CXExtFields) [klabel(cxPresent)]
	   .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 13: cxPayload — c6-positive-context-syntax.k:14

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxPayload)`, or replace it by `symbol(cxPayload)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(14,24,14,71)
	14 |	  syntax CXPayload ::= cxPayload(CXExt, CXBudgets) [klabel(cxPayload)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 14: cxInput — c6-positive-context-syntax.k:15

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxInput)`, or replace it by `symbol(cxInput)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(15,22,15,96)
	15 |	  syntax CXInput ::= cxInput(CXPayload, CXBounds, CXLayoutCaps,
CXHostLimits) [klabel(cxInput)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 15: cxStateCaps — c6-positive-context-syntax.k:16

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxStateCaps)`, or replace it by `symbol(cxStateCaps)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(16,26,16,81)
	16 |	  syntax CXStateCaps ::= cxStateCaps(CXPhysCaps, Int, Int)
[klabel(cxStateCaps)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 16: cxStateLimits — c6-positive-context-syntax.k:17

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxStateLimits)`, or replace it by `symbol(cxStateLimits)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(17,28,17,70)
	17 |	  syntax CXStateLimits ::= cxStateLimits(Int) [klabel(cxStateLimits)]
	   .	                           ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 17: cxStateView — c6-positive-context-syntax.k:18

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxStateView)`, or replace it by `symbol(cxStateView)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(18,26,18,93)
	18 |	  syntax CXStateView ::= cxStateView(CXStateCaps, Bool, CXStateLimits)
[klabel(cxStateView)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 18: cxObservation — c6-positive-context-syntax.k:19

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxObservation)`, or replace it by `symbol(cxObservation)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(19,28,19,120)
	19 |	  syntax CXObservation ::= cxObservation(CTLanes, CXPayload, CXExtFields,
CXStateView, CTLanes) [klabel(cxObservation)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 19: cxNoCases — c6-positive-context-syntax.k:20

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxNoCases)`, or replace it by `symbol(cxNoCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(20,22,20,53)
	20 |	  syntax CXCases ::= cxNoCases() [klabel(cxNoCases)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 20: cxCase — c6-positive-context-syntax.k:21

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxCase)`, or replace it by `symbol(cxCase)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(21,22,21,71)
	21 |	  syntax CXCases ::= cxCase(String, CXInput, CXCases) [klabel(cxCase)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 21: cxNoObservations — c6-positive-context-syntax.k:22

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxNoObservations)`, or replace it by `symbol(cxNoObservations)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(22,29,22,74)
	22 |	  syntax CXObservations ::= cxNoObservations() [klabel(cxNoObservations)]
	   .	                            ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 22: cxObservationCons — c6-positive-context-syntax.k:23

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxObservationCons)`, or replace it by `symbol(cxObservationCons)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context-syntax.k)
	Location(23,29,23,105)
	23 |	  syntax CXObservations ::= cxObservationCons(CXObservation,
CXObservations) [klabel(cxObservationCons)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 23: cxEffective — c6-positive-context.k:8

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxEffective)`, or replace it by `symbol(cxEffective)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context.k)
	Location(8,26,8,76)
	8 |	  syntax CXExtFields ::= cxEffective(CXExt) [function,
klabel(cxEffective)]
	  .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 24: cxExtPresent — c6-positive-context.k:11

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxExtPresent)`, or replace it by `symbol(cxExtPresent)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context.k)
	Location(11,19,11,71)
	11 |	  syntax Bool ::= cxExtPresent(CXExt) [function, klabel(cxExtPresent)]
	   .	                  ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 25: cxPack — c6-positive-context.k:15

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxPack)`, or replace it by `symbol(cxPack)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context.k)
	Location(15,22,15,66)
	15 |	  syntax CTLanes ::= cxPack(CXPayload) [function, klabel(cxPack)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 26: cxUnpack — c6-positive-context.k:20

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxUnpack)`, or replace it by `symbol(cxUnpack)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context.k)
	Location(20,24,20,70)
	20 |	  syntax CXPayload ::= cxUnpack(CTLanes) [function, klabel(cxUnpack)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 27: cxDeclTemplates — c6-positive-context.k:24

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxDeclTemplates)`, or replace it by `symbol(cxDeclTemplates)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context.k)
	Location(24,18,24,74)
	24 |	  syntax Int ::= cxDeclTemplates(Int) [function, klabel(cxDeclTemplates)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 28: cxDerive — c6-positive-context.k:28

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxDerive)`, or replace it by `symbol(cxDerive)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context.k)
	Location(28,26,28,72)
	28 |	  syntax CXStateView ::= cxDerive(CXInput) [function, klabel(cxDerive)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 29: cxDeriveEffective — c6-positive-context.k:29

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxDeriveEffective)`, or replace it by `symbol(cxDeriveEffective)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context.k)
	Location(29,27,29,150)
	29 |	                        | cxDeriveEffective(CXExtFields, Bool, CXBudgets,
CXBounds, CXLayoutCaps, CXHostLimits) [function, klabel(cxDeriveEffective)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 30: cxCapsOf — c6-positive-context.k:34

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxCapsOf)`, or replace it by `symbol(cxCapsOf)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context.k)
	Location(34,26,34,76)
	34 |	  syntax CXStateCaps ::= cxCapsOf(CXStateView) [function,
klabel(cxCapsOf)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 31: cxDescriptor — c6-positive-context.k:36

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxDescriptor)`, or replace it by `symbol(cxDescriptor)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context.k)
	Location(36,22,36,80)
	36 |	  syntax CTLanes ::= cxDescriptor(CXStateCaps) [function,
klabel(cxDescriptor)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 32: cxObserve — c6-positive-context.k:39

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxObserve)`, or replace it by `symbol(cxObserve)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context.k)
	Location(39,28,39,76)
	39 |	  syntax CXObservation ::= cxObserve(CXInput) [function,
klabel(cxObserve)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 33: cxObservePacked — c6-positive-context.k:40

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxObservePacked)`, or replace it by `symbol(cxObservePacked)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context.k)
	Location(40,29,40,98)
	40 |	                          | cxObservePacked(CXInput, CTLanes) [function,
klabel(cxObservePacked)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 34: cxObserveDecoded — c6-positive-context.k:41

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxObserveDecoded)`, or replace it by `symbol(cxObserveDecoded)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context.k)
	Location(41,29,41,140)
	41 |	                          | cxObserveDecoded(CTLanes, CXPayload,
CXBounds, CXLayoutCaps, CXHostLimits) [function, klabel(cxObserveDecoded)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 35: cxObserveDerived — c6-positive-context.k:42

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxObserveDerived)`, or replace it by `symbol(cxObserveDerived)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context.k)
	Location(42,29,42,115)
	42 |	                          | cxObserveDerived(CTLanes, CXPayload,
CXStateView) [function, klabel(cxObserveDerived)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 36: cxObserveAll — c6-positive-context.k:48

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(cxObserveAll)`, or replace it by `symbol(cxObserveAll)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-positive-context.k)
	Location(48,29,48,83)
	48 |	  syntax CXObservations ::= cxObserveAll(CXCases) [function,
klabel(cxObserveAll)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 37: ctConst — c6-typed-root-syntax.k:7

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctConst)`, or replace it by `symbol(ctConst)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(7,20,7,50)
	7 |	  syntax CTRef ::= ctConst(Int) [klabel(ctConst)]
	  .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 38: ctData — c6-typed-root-syntax.k:8

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctData)`, or replace it by `symbol(ctData)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(8,22,8,50)
	8 |	                   | ctData(Int) [klabel(ctData)]
	  .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 39: ctEnvNone — c6-typed-root-syntax.k:9

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvNone)`, or replace it by `symbol(ctEnvNone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(9,20,9,51)
	9 |	  syntax CTEnv ::= ctEnvNone() [klabel(ctEnvNone)]
	  .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 40: ctEnvSome — c6-typed-root-syntax.k:10

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvSome)`, or replace it by `symbol(ctEnvSome)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(10,22,10,56)
	10 |	                   | ctEnvSome(Int) [klabel(ctEnvSome)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 41: ctFunctionNone — c6-typed-root-syntax.k:11

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFunctionNone)`, or replace it by `symbol(ctFunctionNone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(11,25,11,66)
	11 |	  syntax CTFunction ::= ctFunctionNone() [klabel(ctFunctionNone)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 42: ctFunctionSome — c6-typed-root-syntax.k:12

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFunctionSome)`, or replace it by `symbol(ctFunctionSome)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(12,27,12,71)
	12 |	                        | ctFunctionSome(Int) [klabel(ctFunctionSome)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 43: ctSlice — c6-typed-root-syntax.k:13

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSlice)`, or replace it by `symbol(ctSlice)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(13,22,13,57)
	13 |	  syntax CTSlice ::= ctSlice(Int, Int) [klabel(ctSlice)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 44: ctAdd — c6-typed-root-syntax.k:14

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAdd)`, or replace it by `symbol(ctAdd)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(14,23,14,46)
	14 |	  syntax CTBinary ::= ctAdd() [klabel(ctAdd)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~


## 45: ctSub — c6-typed-root-syntax.k:15

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSub)`, or replace it by `symbol(ctSub)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(15,25,15,48)
	15 |	                      | ctSub() [klabel(ctSub)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~


## 46: ctMul — c6-typed-root-syntax.k:16

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMul)`, or replace it by `symbol(ctMul)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(16,25,16,48)
	16 |	                      | ctMul() [klabel(ctMul)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~


## 47: ctEq — c6-typed-root-syntax.k:17

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEq)`, or replace it by `symbol(ctEq)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(17,25,17,46)
	17 |	                      | ctEq() [klabel(ctEq)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~


## 48: ctLt — c6-typed-root-syntax.k:18

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLt)`, or replace it by `symbol(ctLt)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(18,25,18,46)
	18 |	                      | ctLt() [klabel(ctLt)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~


## 49: ctCons — c6-typed-root-syntax.k:19

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctCons)`, or replace it by `symbol(ctCons)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(19,25,19,50)
	19 |	                      | ctCons() [klabel(ctCons)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~


## 50: ctBranch — c6-typed-root-syntax.k:20

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBranch)`, or replace it by `symbol(ctBranch)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(20,25,20,54)
	20 |	                      | ctBranch() [klabel(ctBranch)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 51: ctLeaf — c6-typed-root-syntax.k:21

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLeaf)`, or replace it by `symbol(ctLeaf)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(21,22,21,47)
	21 |	  syntax CTUnary ::= ctLeaf() [klabel(ctLeaf)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~


## 52: ctNot — c6-typed-root-syntax.k:22

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNot)`, or replace it by `symbol(ctNot)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(22,24,22,47)
	22 |	                     | ctNot() [klabel(ctNot)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~


## 53: ctLetF — c6-typed-root-syntax.k:23

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLetF)`, or replace it by `symbol(ctLetF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(23,22,23,67)
	23 |	  syntax CTFrame ::= ctLetF(Int, Int, CTEnv, Int) [klabel(ctLetF)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 54: ctLeftF — c6-typed-root-syntax.k:24

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLeftF)`, or replace it by `symbol(ctLeftF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(24,24,24,76)
	24 |	                     | ctLeftF(CTBinary, Int, CTEnv, Int)
[klabel(ctLeftF)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 55: ctRightF — c6-typed-root-syntax.k:25

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRightF)`, or replace it by `symbol(ctRightF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(25,24,25,73)
	25 |	                     | ctRightF(CTBinary, CTRef, Int) [klabel(ctRightF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 56: ctUnaryF — c6-typed-root-syntax.k:26

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctUnaryF)`, or replace it by `symbol(ctUnaryF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(26,24,26,65)
	26 |	                     | ctUnaryF(CTUnary, Int) [klabel(ctUnaryF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 57: ctIfF — c6-typed-root-syntax.k:27

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctIfF)`, or replace it by `symbol(ctIfF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(27,24,27,67)
	27 |	                     | ctIfF(Int, Int, CTEnv, Int) [klabel(ctIfF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 58: ctMatchF — c6-typed-root-syntax.k:28

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMatchF)`, or replace it by `symbol(ctMatchF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(28,24,28,72)
	28 |	                     | ctMatchF(CTSlice, CTEnv, Int) [klabel(ctMatchF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 59: ctArgsF — c6-typed-root-syntax.k:29

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctArgsF)`, or replace it by `symbol(ctArgsF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(29,24,29,84)
	29 |	                     | ctArgsF(Int, CTSlice, CTSlice, CTEnv, Int)
[klabel(ctArgsF)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 60: ctReturnF — c6-typed-root-syntax.k:30

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctReturnF)`, or replace it by `symbol(ctReturnF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(30,24,30,70)
	30 |	                     | ctReturnF(Int, CTEnv, Int) [klabel(ctReturnF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 61: ctScopeF — c6-typed-root-syntax.k:31

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctScopeF)`, or replace it by `symbol(ctScopeF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(31,24,31,63)
	31 |	                     | ctScopeF(CTEnv, Int) [klabel(ctScopeF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 62: ctConstructorFieldsF — c6-typed-root-syntax.k:32

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctConstructorFieldsF)`, or replace it by
`symbol(ctConstructorFieldsF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(32,24,32,131)
	32 |	                     | ctConstructorFieldsF(Int, Int, Int, Int, Bool,
CTSlice, CTSlice, CTEnv, Int) [klabel(ctConstructorFieldsF)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 63: ctNoFrames — c6-typed-root-syntax.k:33

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNoFrames)`, or replace it by `symbol(ctNoFrames)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(33,23,33,56)
	33 |	  syntax CTFrames ::= ctNoFrames() [klabel(ctNoFrames)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 64: ctFrame — c6-typed-root-syntax.k:34

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFrame)`, or replace it by `symbol(ctFrame)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(34,25,34,69)
	34 |	                      | ctFrame(CTFrame, CTFrames) [klabel(ctFrame)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 65: ctBindingBad — c6-typed-root-syntax.k:35

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBindingBad)`, or replace it by `symbol(ctBindingBad)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(35,24,35,61)
	35 |	  syntax CTBinding ::= ctBindingBad() [klabel(ctBindingBad)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 66: ctBindingOk — c6-typed-root-syntax.k:36

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBindingOk)`, or replace it by `symbol(ctBindingOk)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(36,26,36,66)
	36 |	                       | ctBindingOk(CTEnv) [klabel(ctBindingOk)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 67: ctNoMatch — c6-typed-root-syntax.k:37

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNoMatch)`, or replace it by `symbol(ctNoMatch)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(37,25,37,56)
	37 |	  syntax CTMatching ::= ctNoMatch() [klabel(ctNoMatch)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 68: ctMatched — c6-typed-root-syntax.k:38

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMatched)`, or replace it by `symbol(ctMatched)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(38,27,38,63)
	38 |	                        | ctMatched(CTEnv) [klabel(ctMatched)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 69: ctPrimValue — c6-typed-root-syntax.k:39

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctPrimValue)`, or replace it by `symbol(ctPrimValue)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(39,26,39,66)
	39 |	  syntax CTPrimitive ::= ctPrimValue(CTRef) [klabel(ctPrimValue)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 70: ctPrimError — c6-typed-root-syntax.k:40

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctPrimError)`, or replace it by `symbol(ctPrimError)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(40,28,40,66)
	40 |	                         | ctPrimError(Int) [klabel(ctPrimError)]
	   .	                           ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 71: ctEval — c6-typed-root-syntax.k:41

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEval)`, or replace it by `symbol(ctEval)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(41,24,41,52)
	41 |	  syntax CTControl ::= ctEval(Int) [klabel(ctEval)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 72: ctReturn — c6-typed-root-syntax.k:42

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctReturn)`, or replace it by `symbol(ctReturn)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(42,26,42,60)
	42 |	                       | ctReturn(CTRef) [klabel(ctReturn)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 73: ctScheduleNext — c6-typed-root-syntax.k:43

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctScheduleNext)`, or replace it by `symbol(ctScheduleNext)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(43,26,43,86)
	43 |	                       | ctScheduleNext(CTFrame, Int, CTEnv)
[klabel(ctScheduleNext)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 74: ctInvoke — c6-typed-root-syntax.k:44

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctInvoke)`, or replace it by `symbol(ctInvoke)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(44,26,44,67)
	44 |	                       | ctInvoke(Int, CTSlice) [klabel(ctInvoke)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 75: ctEnter — c6-typed-root-syntax.k:45

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnter)`, or replace it by `symbol(ctEnter)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(45,26,45,72)
	45 |	                       | ctEnter(CTFunction, CTSlice) [klabel(ctEnter)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 76: ctBound — c6-typed-root-syntax.k:46

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBound)`, or replace it by `symbol(ctBound)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(46,26,46,72)
	46 |	                       | ctBound(CTBinding, Int, Int) [klabel(ctBound)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 77: ctCases — c6-typed-root-syntax.k:47

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctCases)`, or replace it by `symbol(ctCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(47,26,47,74)
	47 |	                       | ctCases(CTRef, CTSlice, CTEnv) [klabel(ctCases)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 78: ctCaseResult — c6-typed-root-syntax.k:48

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctCaseResult)`, or replace it by `symbol(ctCaseResult)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(48,26,48,101)
	48 |	                       | ctCaseResult(CTMatching, CTRef, Int, CTSlice,
CTEnv) [klabel(ctCaseResult)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 79: ctPrimResult — c6-typed-root-syntax.k:49

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctPrimResult)`, or replace it by `symbol(ctPrimResult)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(49,26,49,74)
	49 |	                       | ctPrimResult(CTPrimitive) [klabel(ctPrimResult)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 80: ctError — c6-typed-root-syntax.k:50

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctError)`, or replace it by `symbol(ctError)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(50,26,50,56)
	50 |	                       | ctError(Int) [klabel(ctError)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 81: ctMaterialize — c6-typed-root-syntax.k:51

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMaterialize)`, or replace it by `symbol(ctMaterialize)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(51,26,51,82)
	51 |	                       | ctMaterialize(Int, Int, CTSlice)
[klabel(ctMaterialize)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 82: ctFuel — c6-typed-root-syntax.k:52

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFuel)`, or replace it by `symbol(ctFuel)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(52,24,52,49)
	52 |	  syntax CTExhaust ::= ctFuel() [klabel(ctFuel)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~


## 83: ctDataNodes — c6-typed-root-syntax.k:53

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDataNodes)`, or replace it by `symbol(ctDataNodes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(53,26,53,61)
	53 |	                       | ctDataNodes() [klabel(ctDataNodes)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 84: ctDataFields — c6-typed-root-syntax.k:54

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDataFields)`, or replace it by `symbol(ctDataFields)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(54,26,54,63)
	54 |	                       | ctDataFields() [klabel(ctDataFields)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 85: ctEnvironmentCells — c6-typed-root-syntax.k:55

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvironmentCells)`, or replace it by `symbol(ctEnvironmentCells)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(55,26,55,75)
	55 |	                       | ctEnvironmentCells()
[klabel(ctEnvironmentCells)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 86: ctHelperTasks — c6-typed-root-syntax.k:56

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctHelperTasks)`, or replace it by `symbol(ctHelperTasks)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(56,26,56,65)
	56 |	                       | ctHelperTasks() [klabel(ctHelperTasks)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 87: ctHelperWork — c6-typed-root-syntax.k:57

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctHelperWork)`, or replace it by `symbol(ctHelperWork)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(57,26,57,63)
	57 |	                       | ctHelperWork() [klabel(ctHelperWork)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 88: ctSerializationBytes — c6-typed-root-syntax.k:58

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSerializationBytes)`, or replace it by
`symbol(ctSerializationBytes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(58,26,58,79)
	58 |	                       | ctSerializationBytes()
[klabel(ctSerializationBytes)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 89: ctRunning — c6-typed-root-syntax.k:59

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRunning)`, or replace it by `symbol(ctRunning)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(59,24,59,55)
	59 |	  syntax CTOutcome ::= ctRunning() [klabel(ctRunning)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 90: ctHalted — c6-typed-root-syntax.k:60

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctHalted)`, or replace it by `symbol(ctHalted)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(60,26,60,60)
	60 |	                       | ctHalted(CTRef) [klabel(ctHalted)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 91: ctRejected — c6-typed-root-syntax.k:61

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRejected)`, or replace it by `symbol(ctRejected)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(61,26,61,62)
	61 |	                       | ctRejected(Int) [klabel(ctRejected)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 92: ctExhausted — c6-typed-root-syntax.k:62

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctExhausted)`, or replace it by `symbol(ctExhausted)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(62,26,62,70)
	62 |	                       | ctExhausted(CTExhaust) [klabel(ctExhausted)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 93: ctAlloc — c6-typed-root-syntax.k:63

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAlloc)`, or replace it by `symbol(ctAlloc)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(63,22,63,62)
	63 |	  syntax CTAlloc ::= ctAlloc(Int, Int, Int) [klabel(ctAlloc)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 94: ctActive — c6-typed-root-syntax.k:64

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctActive)`, or replace it by `symbol(ctActive)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(64,23,64,70)
	64 |	  syntax CTActive ::= ctActive(Int, Int, Int, Int) [klabel(ctActive)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 95: ctRoot — c6-typed-root-syntax.k:65

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRoot)`, or replace it by `symbol(ctRoot)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(65,21,65,166)
	65 |	  syntax CTRoot ::= ctRoot(CTControl, Int, CTEnv, Int, CTOutcome, Int,
Int, Int, Int, Int, Int, CTAlloc, CTActive, CTActive, CTAlloc, Int, CTFrames)
[klabel(ctRoot)]
	   .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 96: ctNoLanes — c6-typed-root-syntax.k:66

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNoLanes)`, or replace it by `symbol(ctNoLanes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(66,22,66,53)
	66 |	  syntax CTLanes ::= ctNoLanes() [klabel(ctNoLanes)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 97: ctLane — c6-typed-root-syntax.k:67

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLane)`, or replace it by `symbol(ctLane)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(67,24,67,61)
	67 |	                     | ctLane(Int, CTLanes) [klabel(ctLane)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 98: ctAnswer — c6-typed-root-syntax.k:68

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAnswer)`, or replace it by `symbol(ctAnswer)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(68,23,68,83)
	68 |	  syntax CTAnswer ::= ctAnswer(String, CTRoot, CTLanes, CTRoot)
[klabel(ctAnswer)]
	   .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 99: ctNoQueries — c6-typed-root-syntax.k:69

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNoQueries)`, or replace it by `symbol(ctNoQueries)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(69,24,69,59)
	69 |	  syntax CTQueries ::= ctNoQueries() [klabel(ctNoQueries)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 100: ctQuery — c6-typed-root-syntax.k:70

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctQuery)`, or replace it by `symbol(ctQuery)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(70,26,70,78)
	70 |	                       | ctQuery(String, CTRoot, CTQueries)
[klabel(ctQuery)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 101: ctNoAnswers — c6-typed-root-syntax.k:71

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNoAnswers)`, or replace it by `symbol(ctNoAnswers)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(71,24,71,59)
	71 |	  syntax CTAnswers ::= ctNoAnswers() [klabel(ctNoAnswers)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


## 102: ctAnswerRow — c6-typed-root-syntax.k:72

[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAnswerRow)`, or replace it by `symbol(ctAnswerRow)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-CTX22-derived-caps29-20261020/source/c6-typed-root-syntax.k)
	Location(72,26,72,80)
	72 |	                       | ctAnswerRow(CTAnswer, CTAnswers)
[klabel(ctAnswerRow)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

