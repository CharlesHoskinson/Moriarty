from pathlib import Path
import json,hashlib,runpy,os,sys,glob
R=Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017')
B=R/'doctorwatson-stagenet-four-milestone-audit-20261020/k-next-public-nominal-identity-source10'
V=R/'doctorwatson-stagenet-four-milestone-audit-20261020/k-source10-full-identity-fresh-review01'
load=lambda p:json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p);v=p.read_bytes();return dict(path=str(p),bytes=len(v),sha256=hashlib.sha256(v).hexdigest())
def check(x):
 a=pin(x['path']);assert a['bytes']==x['bytes']and a['sha256']==x['sha256'];return a
proposal=B/'PROPOSED-ONE-EXISTING-F03-COMPILE-DATA.json'
assert pin(proposal)['sha256']=='2ebe602848f103e17c1d4acabd54b1d752648e7f1956618c06d79ad718832756'
j=load(proposal);assert len(j['phases'])==1;op=j['phases'][0]
selection_path=B/'root-selected-ordinary-checks01/ROOT-SELECTION.json'
assert pin(selection_path)['sha256']=='2ebfebca8fb5ac9f51afc59ddce4f7b4ba4dc9df261a84e2c1b7fc15248a4ed2'
selection=load(selection_path);assert selection['selectedPhase']==op
rv=load(V/'RESULT.json');assert rv['actualExit']==0 and rv['terminal']['status']=='SUCCESS'and rv['finalSHA256']=='48deb10d1734fcc736729adae1d5cc31c74a9dc5fc51d5ffc9ba35dfc10311e2'
f=load(j['source_freeze']['path']);tools=load(j['tools']['path']);closure=load(j['K_builtin_closure']['path'])
flat={}
def walk(x):
 if isinstance(x,dict):
  if {'path','bytes','sha256'}<=x.keys():
   row={k:x[k]for k in ['path','bytes','sha256']};assert row['path']not in flat or flat[row['path']]==row;flat[row['path']]=row
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
for x in [j,f,tools,closure,selection]:walk(x)
for p in [selection_path,proposal,B/'SOURCE-FREEZE.json',V/'REPORT.md',V/'RESULT.json',V/'FINDINGS.json',Path(__file__)]:walk(pin(p))
rows=sorted(flat.values(),key=lambda x:x['path'])
inventory=load(closure['original_inventory_source']['path'])['inventory']
links=[x for rs in inventory.values()for x in rs if x.get('kind')=='symlink']
def prepost():
 for directory,key in [('source','source_members'),('tests','test_members')]:
  assert sorted(str(p)for p in(B/directory).iterdir())==sorted(f[key])
 for x in links:
  assert os.path.islink(x['path']) and os.readlink(x['path'])==x['target']
  assert str(Path(x['path']).resolve(strict=True))==x['resolved']
  if 'resolved_sha256'in x:assert pin(x['resolved'])['sha256']==x['resolved_sha256']
 for x in rows:check(x)
 assert sorted(glob.glob(tools['classpath_pattern']))==sorted(x['path']for x in tools['classpath_jar_membership'])
 for x in tools['entries']:assert str(Path(x['path']).resolve(strict=True))==x['resolved_path']
 return {'all_match':True,'rows':len(rows),'classpathJars':len(tools['classpath_jar_membership']),'historicalSymlinks':len(links),'source_members':f['source_members'],'test_members':f['test_members']}
before=prepost()
check(j['callback']['fullsource'])
api=runpy.run_path(j['callback']['fullsource']['path'],run_name='root_selected_PROGRAMVIEW_IDENTITY_SOURCE10_F03_launch_only')
assert api['CHILD_SECONDS']==30 and api['SWEEP_SECONDS']==3
actual=B/'actual';assert not actual.exists()
phase=Path(op['cwd']);phase.mkdir(parents=True,mode=0o700)
for p in [phase,Path(op['environment']['HOME']),Path(op['environment']['TMPDIR'])]:
 if not p.exists():p.mkdir(mode=0o700)
 os.chmod(p,0o700)
def durable(p,x):
 assert not p.exists()
 with p.open('xb')as f:f.write((json.dumps(x,indent=2)+'\n').encode());f.flush();os.fsync(f.fileno())
 fd=os.open(p.parent,os.O_DIRECTORY|os.O_RDONLY);os.fsync(fd);os.close(fd)
durable(actual/'ROOT-SELECTION.json',{'selected':True,'RootFullSourceClosureAndReviewRead':True,'exact1CompileOnly':True,'review':pin(V/'REPORT.md'),'proposal':pin(proposal),'composition':pin(__file__),'noUnitsOrRuntimeOrExpectedInputs':True,'noRetryNoCapChange':True})
durable(actual/'FLAT-INPUT-PINS.json',{'members':rows});durable(phase/'ROOT-PRECHECK.json',before)
durable(phase/'COMMAND.json',op)
record={'id':op['id']}
print(json.dumps({'dispatch':'ONE_EXISTING_F03_LAUNCH','phase':op['id'],'composition':pin(__file__)}),flush=True)
try:
 api['launch'](record,op['argv'],dict(op['environment']),op['cwd'],op['environment']['SHERLOCK_K_ATTEMPT_TOKEN'],536870912)
 durable(phase/'RESULT.json',record)
 for n in ['stdout','stderr','RESULT.json','COMMAND.json']:
  with(phase/n).open('rb')as z:os.fsync(z.fileno())
 fd=os.open(phase,os.O_DIRECTORY|os.O_RDONLY);os.fsync(fd);os.close(fd)
 post=prepost();durable(phase/'ROOT-POSTCHECK.json',post)
 artifacts=[pin(p)for p in sorted(actual.rglob('*'))if p.is_file()and p not in [actual/'FLAT-INPUT-PINS.json']]
 products=[pin(p)for p in sorted((actual/'programview-identity-source10-kompiled').rglob('*'))if p.is_file()]
 errors=[pin(p)for p in phase.glob('hs_err_pid*.log')]
 for p in sorted(actual.rglob('*')):
  if p.is_file():
   with p.open('rb')as z:os.fsync(z.fileno())
 for p in sorted([actual]+[p for p in actual.rglob('*')if p.is_dir()],key=lambda p:len(p.parts),reverse=True):
  fd=os.open(p,os.O_DIRECTORY|os.O_RDONLY);os.fsync(fd);os.close(fd)
 fd=os.open(actual.parent,os.O_DIRECTORY|os.O_RDONLY);os.fsync(fd);os.close(fd)
 durable(actual/'ROOT-ALL-ACTUAL-PRODUCTS-FROZEN.json',{'products':products,'rawFiles':artifacts,'jvmErrorFiles':errors})
 ok=record.get('returncode')==0 and record.get('outcome')=='exited'and record.get('timed_out')is False and record.get('containment_breach')is False and not record.get('remaining')and not errors and all(Path(p).is_file()and Path(p).stat().st_size>0 for p in op['products'])
 durable(actual/'ROOT-COMPILE-RESULT.json',{'cleanProcessAndProducts':ok,'source':pin(B/'SOURCE-FREEZE.json'),'record':record,'products':products,'streams':[pin(phase/'stdout'),pin(phase/'stderr')],'fullStreamsRootReadOwed':True,'warningsUnadjudicated':True,'labelsUnqualified':True,'runtimeUnrun':True,'rows':len(rows)})
 print(json.dumps({'cleanProcessAndProducts':ok,'record':record,'streams':[pin(phase/'stdout'),pin(phase/'stderr')],'products':len(products),'rows':len(rows)}),flush=True)
except BaseException as e:
 if not(phase/'RESULT.json').exists():durable(phase/'RESULT.json',record)
 durable(actual/'ROOT-FAILURE.json',{'status':'FAIL_STOP_NO_RETRY','error':type(e).__name__+': '+str(e),'record':record});raise
