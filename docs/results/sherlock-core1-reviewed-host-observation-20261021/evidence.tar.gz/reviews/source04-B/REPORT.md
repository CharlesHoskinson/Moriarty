# Fresh Independent Security Source/API/Design Review — `core1-whole-trace-budget-gemini4-mandatory-fix-owner04` (`core1-owner04-fresh-source-review-B01`)

- **Review ID**: `core1-owner04-fresh-source-review-B01`
- **Reviewer**: `gemini-4-argon-high` via AGY (authorized standing fallback while Opus 5.5 and Muse are quota-unavailable; announced and retained with canonical identity)
- **Candidate Dir**: `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-whole-trace-budget-gemini4-mandatory-fix-owner04`
- **Author Envelope Status**: `CLI0 / ERROR (network timeout)` with complete 10-file source delivery verified by Root in `ROOT-ACTUAL-SOURCE04-PIN-READBACK.json` (`metadataDiscrepancies: []`). Not relabeled `SUCCESS`; author output is not a reviewer vote.
- **Note on Author `REPORT.md` Permanent-Lane Section**: The permanent-lane status paragraph in `core1-whole-trace-budget-gemini4-mandatory-fix-owner04/REPORT.md` is stale historical copy and is **not** adopted as current live lane state.
- **Authoritative Comparison Worktree (`PW`)**: `/home/charl/Moriarty/.worktrees/sherlock-c6-physical-host-codecs-20261019` (`HEAD` `03496846642b16154bd6573b3e40a07002b2f599`, `Cargo.lock` SHA-256 `946b8984e57b5b6b59aa28df5565564d8c37a37e58c4b5ab1ba62db007bf439a` immutable)
- **Review Mode**: Source-only (`UNCOMPILED_UNRUN`); zero compiler, test, model, subagent, SDK, native, proof, key, wallet, provider, or Git execution performed.
- **Verdict**: **`APPROVE_SOURCE_WITH_LIMITS`**

---

## 1. Executive Summary & Verdict

**Verdict: `APPROVE_SOURCE_WITH_LIMITS`**

All mandatory source/API/design defects identified in prior reviews `core1-owner03-fresh-source-review-A01` (`M1-A01`, `M2-A01`, plus non-blocking `NB1-A01`) and `core1-owner03-fresh-source-review-B01` (`F-01`, `F-02`, `F-03`, `F-04`, `F-05`) have been substantively and cleanly resolved in `core1-whole-trace-budget-gemini4-mandatory-fix-owner04`:

1. **Exact Real Core Types & Partial-Move Prevention (`F-01` resolved)**:
   - `crates/mori-core/src/sherlock/compile_artifact/core_observation.rs:14-16` imports the real `crates/mori-core/src/sherlock/helper_machine/shared.rs` types `ExpandedStepIdC` (`shared.rs:413-416`) and `RuleIdC` (`shared.rs:367-370`) instead of nonexistent `MicroRuleId`/`StepId`.
   - `TraceFailureBoundary::StepRecord` (`core_observation.rs:86-100`) stores `step_id: ExpandedStepIdC` and `micro_rule_id: RuleIdC`.
   - `Trace::push_record` (`core_observation.rs:517-527`) destructures `let CompleteStepRecord { before, event, after } = record; drop(before); drop(after);` before moving `event.step_id` and `event.micro_rule_id` into `TraceFailureBoundary::StepRecord`, avoiding any partial move out of `record` (`E0382`).
   - Focused unit and integration tests (`core_observation.rs:1205-1209`, `sherlock_core1_complete_observation.rs:289-293`) assert the real object wire shape of `failed_step_id` (`{"run_id": ..., "ordinal": ...}`).

2. **Restored Non-Offset Per-Projection Diagnostics (`M1-A01` resolved)**:
   - `BoundedJsonWriter::with_projection_budget` (`crates/mori-core/src/sherlock/compile_artifact/complete_trace_wire.rs:185-211`) saves `prev_active = self.active_limit`, sets `self.active_limit = projection_ceiling.min(prev_active)` where `projection_ceiling = self.bytes.len().saturating_add(per_projection_limit)`, executes `f(self)`, restores `self.active_limit = prev_active`, and on `result.is_err()` when `self.exceeded_limit.is_some()` overwrites `self.exceeded_limit` with `Some(per_projection_limit)` if `projection_ceiling <= prev_active` (or `Some(prev_active)` when the outer cumulative ceiling is tighter) and returns `Err(self.limit_error())` instead of the stale offset-inflated error constructed inside `f(self)`.
   - Directly regression-tested at `core_observation.rs:1264-1330` (`per_projection_limit_after_nonempty_prefix_reports_uninflated_limit`).

3. **Real CLI Error Envelope Comparison (`M2-A01` & `F-02` resolved)**:
   - `crates/mori/tests/core1_complete_observation_handler.rs:8, 39-44, 95-105, 119-137` mounts `#[path = "../src/display.rs"] mod display;`, computes `handler_failure_text` via `mori_core::json::export(failure)` and `format!("mori::command: {}", display::text(&raw))` (matching `typed_action_input_compile_handler.rs:79-81` and `crates/mori/src/commands/publish_io.rs:12-15`), parses `raw` with `mori_core::json::parse(&raw)` for structural JSON assertions, and asserts `assert_eq!(zero_err.to_string(), expected_text)` and `assert_eq!(pub_err.to_string(), expected_text)`.

4. **Elimination of $O(N^2)$ Prefix Vec Allocations & 1 MiB Happy-Path Writer Clone (`F-03` resolved)**:
   - `BoundedJsonWriter::parse_value(&self, field)` (`complete_trace_wire.rs:506-515`) parses `&self.bytes` by shared reference without consuming the writer.
   - `Trace::finish_terminal` (`core_observation.rs:550-630`) records `returned_checkpoint = self.writer.checkpoint()` before writing `returned`, closes the root object, and calls `self.writer.parse_value("complete_trace")` directly on `self.writer` with zero `self.writer.clone()` on the happy path; on error, `self.writer` and `self.returned_checkpoint = Some(returned_checkpoint)` remain populated in `BoundedTraceFailure`.
   - `BoundedTraceFailure::into_compile_failure` (`core_observation.rs:281-312`) performs lazy in-place rollback on `self.writer` from `returned_checkpoint` down through `record_checkpoints.iter().enumerate().rev()`. Because `record_checkpoints[0] < ... < record_checkpoints[k] < returned_checkpoint`, writing `TRACE_CLOSE_ROOT` (`"}"`) or `TRACE_PREFIX_CLOSE` (`"],\"terminal\":null,\"returned\":null}"`) at a later checkpoint only mutates bytes at indices $\ge$ that later checkpoint and never corrupts bytes below any earlier checkpoint.
   - Regression-tested at `core_observation.rs:1332-1377` (`rollback_falls_back_from_returned_checkpoint_to_record_prefix_in_place`).

5. **Complete Coherent 10-File Candidate Manifest (`F-04` resolved)**:
   - Includes `crates/mori/tests/typed_action_input_compile_handler.rs` (`22,831` B, `324` lines, SHA-256 `567602de73f38d63977b5930fd4dc89b35a035aa9f4715c97b0897e3be8c2270`) alongside the untouched LPW `beforeimage` (`22,702` B, `323` lines, SHA-256 `5a7566fedad0527eb86b11524c8d42c15b2ae06cc768ad3ad6a7222fb3ef8403`), matching `crates/mori/src/commands/compile_sherlock.rs` (`run_compile_sherlock_Command_with_action_inputs`).

6. **Explicit Wire Version `/2`, Re-Exported Reconstruction Helper, & Preserved Fallback Failure Metadata (`F-05` & `NB1-A01` resolved)**:
   - `TRACE_FORMAT` is `"sherlock-core1-complete-trace/2"` and `TRACE_SERIALIZATION_BUDGET` is `"per_projection:admission.bounds.serialization_bytes;whole_trace:derive_trace_serialization_budget(admission.bounds);step_boundaries:image-only-shared-admission"` (`compile_artifact.rs:53-55`).
   - `reconstruct_step_host_snapshot` is implemented at `complete_trace_wire.rs:122-130` and publicly re-exported at `compile_artifact.rs:51`.
   - `CompileFailure::export_diagnostic` (`compile_artifact.rs:189-280`) preserves `"failure_boundary"`, `"serialization_error"`, and `"violation"` in the final minimal fallback JSON object (`compile_artifact.rs:249-280`).
   - `complete_trace_wire.rs:18-22` accurately documents that `write_owner_wire` materializes bounded single-row/leaf `Value`s via `OwnerWire::owner_wire` while top-level snapshots, dynamic maps/lists, and trace arrays stream into `BoundedJsonWriter`.

---

## 2. Verification of Pin Table (22 Declared Pins Across 10 Files)

Root's `ROOT-ACTUAL-SOURCE04-PIN-READBACK.json` verified all 22 pins declared in `FILE-MAP.json` with `metadataDiscrepancies: []`:

| # | Target Path | Role | Bytes | Lines | SHA-256 |
|---|---|---|---:|---:|---|
| 1 | `crates/mori-core/src/sherlock/compile_artifact.rs` | `preimage` (`SOURCE-FREEZE-REVISION02`) | 19,371 | 403 | `a8630ea3b843b383ab05d64ef679404038ebf9bd107891fb2e0f834b0d13058e` |
| 1b | `crates/mori-core/src/sherlock/compile_artifact.rs` | `true_public_beforeimage` (`PW`) | 18,775 | 391 | `a7c841b47fe1754c308e65f41288b1ad8eae98944717e6945bc44918ca383411` |
| 1c | `crates/mori-core/src/sherlock/compile_artifact.rs` | `afterimage` | 25,315 | 534 | `926981690550aabeb504ebb47d7217dadd22d0851378936bb5108b4d08edaae5` |
| 2 | `crates/mori-core/src/sherlock/compile_artifact/complete_trace_wire.rs` | `preimage` | 7,785 | 93 | `9b2a2e3587687d8e5596f9be3fc43e5268ff5087a10c37f765e3a208e70bbf3d` |
| 2b | `crates/mori-core/src/sherlock/compile_artifact/complete_trace_wire.rs` | `afterimage` | 26,434 | 564 | `9ea305df536d26e540e3622313c3cd70ec2fa056708f72bd981e55affddea2e7` |
| 3 | `crates/mori-core/src/sherlock/compile_artifact/core_observation.rs` | `preimage` | 11,699 | 202 | `9b54bef0f7ef2063a41e8ca300594a13a64553aa1660627c7152e3cb514fb425` |
| 3b | `crates/mori-core/src/sherlock/compile_artifact/core_observation.rs` | `afterimage` | 59,722 | 1,379 | `35ddd23ac76dd671cbe12c23ba3af3ebecaae263a4f0160ee958adbd9a930efd` |
| 4 | `crates/mori-core/tests/sherlock_core1_complete_observation.rs` | `preimage` | 5,668 | 90 | `dc307949c1601f20b446cfb3c77569be9e8d1e7d4dba27c7883adb1dc2836f79` |
| 4b | `crates/mori-core/tests/sherlock_core1_complete_observation.rs` | `afterimage` | 17,947 | 389 | `47440c1a3ab7b75a9e36e01463c4e0abcb49028b10ede58370dcddca70f1dfda` |
| 5 | `crates/mori/tests/core1_complete_observation_handler.rs` | `preimage` | 3,957 | 64 | `d96119fa79ae0e2c6a7c31f036c9e2bd9d7114cc448d2780b666f34847e90076` |
| 5b | `crates/mori/tests/core1_complete_observation_handler.rs` | `afterimage` | 7,493 | 138 | `f07e5cb6d41c9ae7b86d0a9bfa021bfeb245247bc97bcafd84c46f53279767b4` |
| 6 | `crates/mori/src/commands/compile_sherlock.rs` | `preimage` (`SOURCE-FREEZE-REVISION02`) | 10,100 | 165 | `bfda5f790d59d475dec52b457f08e9055c218ca4c494391daf805c65a713ea3c` |
| 6b | `crates/mori/src/commands/compile_sherlock.rs` | `afterimage` | 9,994 | 164 | `b7a32a3216223c3c20a5561274b0cf109e2bfcc48d904e729f164080bd48f556` |
| 7 | `crates/mori/tests/typed_action_input_compile_handler.rs` | `preimage` (`SOURCE-FREEZE-REVISION02`) | 22,831 | 324 | `567602de73f38d63977b5930fd4dc89b35a035aa9f4715c97b0897e3be8c2270` |
| 7b | `crates/mori/tests/typed_action_input_compile_handler.rs` | `lpw_beforeimage` (`PW`) | 22,702 | 323 | `5a7566fedad0527eb86b11524c8d42c15b2ae06cc768ad3ad6a7222fb3ef8403` |
| 7c | `crates/mori/tests/typed_action_input_compile_handler.rs` | `afterimage` | 22,831 | 324 | `567602de73f38d63977b5930fd4dc89b35a035aa9f4715c97b0897e3be8c2270` |
| 8 | `crates/mori-core/tests/fixtures/core1-complete-observation/quote.mori` | `preimage` & `afterimage` | 142 | 1 | `e688dd8c811be803c4c3bde7a326b8f86d07e7255d7642e4b7d676f5a22a13d2` |
| 9 | `crates/mori-core/tests/fixtures/core1-complete-observation/eligible.mori` | `preimage` & `afterimage` | 201 | 1 | `358a55ca94b190408f0cd020ad26343b45e7ef53b1357034c3b147bc9ae4fd68` |
| 10 | `crates/mori-core/tests/fixtures/core1-complete-observation/eligible.inputs.json` | `preimage` & `afterimage` | 80 | 1 | `6e8cc9c547c5eccf6d443bf1664c4ece2af3733f0b659bd88a2c3ca327df9b3b` |

---

## 3. Detailed Semantic & Security Verification

### 3.1 Trace Completeness, Lossless Shared-Admission Normalization, and Non-Shortening

- **Full 23-Table Admission Preservation**: `write_program_snapshot` (`complete_trace_wire.rs:241-270`) writes all 23 fields of `ProgramSnapshot` (`functions`, `rules`, `step_plans`, `ADTs`, `types`, `const_pool`, `match_tables`, `regions`, `layouts`, `fields`, `frames`, `effects`, `Handler_tables`, `Perm_table`, `Drop_tables`, `Transfer_specs`, `Commit_specs`, `Schema_tables`, `Public_check_tables`, `Entry_table`, `Action_table`, `Verifier_bounds`, `Metadata`) in `initial`, `returned`, and `CaptureStepError` failure boundaries (`write_host_snapshot`, `complete_trace_wire.rs:230-239`).
- **Full 23-Field Dynamic Image Preservation**: `write_image_snapshot` (`complete_trace_wire.rs:272-301`) writes all 23 dynamic fields of `ImageSnapshot` (`pc`, `ctrl`, `regs`, `frame_stack`, `active_frame`, `region_heap`, `value_store`, `linear_cells`, `borrow_loans`, `handler_stack`, `ledger_view`, `clock_epoch`, `transfer_accumulator`, `commit_accumulator`, `action_state`, `event_seq`, `fuel`, `depth`, `alloc_bytes`, `step_count`, `rng_ prohibitor`, `outcome`, `violation`) at every boundary (`initial`, `records[i].before`, `records[i].after`, `terminal.before`, `terminal.after`, `returned`, and `CaptureStepError` `before`/`after`).
- **Full 28-Field Step Event Preservation**: `write_step_event` (`complete_trace_wire.rs:312-345`) writes all 28 fields of `StepEventC` without elision or truncation.
- **Exact HostSnapshot Reconstruction**: Because `HostRuntime::from_parts` clones `self.admission` identically into every `HostSnapshot` (`crates/mori-core/src/sherlock/helper_machine/shared/owner_runtime.rs:146-152`) and B micro-steps never mutate `ProgramSnapshot`, `reconstruct_step_host_snapshot(initial_admission, step_boundary)` (`complete_trace_wire.rs:122-130`) reconstructs the exact `{"admission": initial["admission"], "image": step_boundary["image"]}` map.
- **No Semantic Fuel or Observer Shortening**: `execute_core1_complete_observation` (`core_observation.rs:412-490`) runs the unmodified `CoreActionConsumer` / `CompleteRunObserver` loop (`core_action_consumer.rs`, `complete_observation.rs`) to completion or B-machine terminal/invariant stop.

### 3.2 Per-Projection, Cumulative, and Global JSON Caps

- **Unchanged Global JSON Caps**: `crates/mori-core/src/json.rs:8-10` retains `MAX_BYTES = 1_048_576` (1 MiB), `MAX_NODES = 65_536`, and `MAX_DEPTH = 32`.
- **Unchanged Per-Projection Cap**: `admission.bounds.serialization_bytes` remains `65,536` in standard configs (`crates/mori-core/tests/sherlock_compile_artifact_config.json`) and is enforced on `initial`, each `records[i].before/event/after`, `terminal.before/event/after`, `returned`, and `CaptureStepError` `before/event/after` via `BoundedJsonWriter::with_projection_budget`.
- **Honest Complete-Trace Tool Budget**: `derive_trace_serialization_budget(bounds: &BoundsC) -> usize` (`complete_trace_wire.rs:106-112`) computes:
  $$\min\bigl(\text{serialization\_bytes} \times (\text{usize::try\_from}(\text{step\_cap}).\text{unwrap\_or}(\text{usize::MAX}) + 2),\; 1{,}048{,}576\bigr)$$
  This bounds the complete-trace diagnostic/artifact JSON payload (not B runtime execution fuel/resource exhaustion, which remains `OutcomeC::Exhausted` inside `ImageSnapshot::outcome`).
- **Zero-Fuel Returned Boundary Growth**: On `QUOTE` with `fuel = 0`, step 1 transitions `image.outcome` from `"Running"` (9 ASCII bytes) to `{"Exhausted":{"reason":"Fuel"}}` (30 ASCII bytes), so `exact_returned == exact_initial + 21` and `exact_initial < exact_returned` (`core_observation.rs:1174-1179`) holds deterministically.

### 3.3 Rust API, Borrow/Move, Visibility, and Test Predicates

- All imports, struct/enum variants, method signatures, and visibility modifiers across the 10 files match the authoritative unchanged definitions in `PW`.
- Positive source predicates for the 58-step `quote.mori` trace (`sherlock_core1_complete_observation.rs:94-156`, `core1_complete_observation_handler.rs:46-83`) and 48-step `eligible.mori` trace (`sherlock_core1_complete_observation.rs:158-246`), negative budget/rollback predicates (`sherlock_core1_complete_observation.rs:248-388`, `core_observation.rs:978-1378`), and the 15 CLI handler tests in `typed_action_input_compile_handler.rs` (`324` lines) are self-contained and type-consistent.

---

## 4. Mandatory Source Fixes Required

**None.** All 5 blocking findings from `B01` and both blocking findings plus the non-blocking finding from `A01` are resolved.

---

## 5. Typed Unresolved Limits (`APPROVE_SOURCE_WITH_LIMITS`)

1. **`UNCOMPILED_UNRUN`**: This review was conducted strictly via static source/API/design inspection under the no-execution constraint. Neither `cargo check` nor `cargo test` has been executed on `core1-whole-trace-budget-gemini4-mandatory-fix-owner04`.
2. **`SECOND_INDEPENDENT_NON_AUTHOR_VOTE_REQUIRED`**: Under Moriarty governance, consequential design/resource updates require two substantive agreeing independent non-author reviews (`A01` + `B01`) before adoption.
3. **`INDEPENDENT_FULL_TRACE_SEMANTICS_ORACLE_PENDING`**: Source predicates verify structural/wire properties and step counts (58 for `quote.mori`, 48 for `eligible.mori`), while independent full-trace semantic expectations are being derived separately and are not claimed by this source review.
4. **`STALE_AUTHOR_REPORT_PERMANENT_LANE_PARAGRAPH_IGNORED`**: The permanent-lane status paragraph in `core1-whole-trace-budget-gemini4-mandatory-fix-owner04/REPORT.md` is stale historical prose and does not represent live Clean/Quint/K/circuit lane state.
5. **`SEPARATE_EVIDENCE_AND_ACCEPTANCE_GATES`**: Source approval establishes `implementation: "source_approved_with_limits"` only (`evidence: "uncompiled_unrun"`, `native: "unrun"`, `acceptance: "none"`). It does not grant test execution pass receipts, native proof/ledger qualification, or EARS requirement closure.
