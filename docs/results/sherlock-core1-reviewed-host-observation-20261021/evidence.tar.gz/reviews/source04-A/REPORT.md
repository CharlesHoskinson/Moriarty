# Independent Security, API, and Design Source Review — Candidate 04 (`core1-owner04-fresh-source-review-A01`)

## 1. Review Metadata & Verdict

- **Review ID**: `core1-owner04-fresh-source-review-A01`
- **Candidate**: `core1-whole-trace-budget-gemini4-mandatory-fix-owner04` (`SOURCE_ONLY`, `UNCOMPILED_UNRUN`, acceptance `NONE`)
- **Supersedes**: `core1-whole-trace-budget-gemini4-normalized-lossless-owner03` (and `owner01`, `owner02`)
- **Prior Reviews Verified**:
  - [`core1-owner03-fresh-source-review-A01/REPORT.md`](file:///home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-owner03-fresh-source-review-A01/REPORT.md) (`M1-A01`, `M2-A01`, `NB1-A01`, `NB2-A01`)
  - [`core1-owner03-fresh-source-review-B01/REPORT.md`](file:///home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-owner03-fresh-source-review-B01/REPORT.md) (`F-01`, `F-02`, `F-03`, `F-04`, `F-05`)
- **Reviewer Role**: Fresh independent non-author security/API/design reviewer under Gemini 4 Argon (High) via AGY (authorized Opus 5.5 outage fallback per `AGENTS.md`; author is not a vote)
- **Author Transport / Envelope Status**: `CLI0 ERROR` network timeout with complete 10-file source and metadata delivery; not relabeled `SUCCESS`. The permanent-lane paragraph in the author's `REPORT.md` is stale history and is not adopted as current lane state.
- **Active Checkout (`PW`)**: `/home/charl/Moriarty/.worktrees/sherlock-c6-physical-host-codecs-20261019` (with immutable LPW `03496` lock `946b` untouched)
- **Execution Discipline**: Zero model, compiler, `cargo`, `rustc`, test, native, SDK, proof, key, wallet, provider, subagent, or Git commands were executed during this review.
- **Verdict**: **`APPROVE_SOURCE_WITH_LIMITS`** (`0` mandatory source fixes required; explicit typed unresolved limits recorded in Section 5)

---

## 2. Inspected 22 Source Pins Across All 10 Candidate Files

All 22 declared source pins in [`FILE-MAP.json`](file:///home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-whole-trace-budget-gemini4-mandatory-fix-owner04/FILE-MAP.json) and [`ROOT-ACTUAL-SOURCE04-PIN-READBACK.json`](file:///home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-whole-trace-budget-gemini4-mandatory-fix-owner04/ROOT-ACTUAL-SOURCE04-PIN-READBACK.json) were read in full alongside the authoritative unchanged Core/shared types, `mori_core::json` caps, and CLI `display`/`source_io`/`publish_io` modules in `PW`:

| # | Repo Path | Preimage / Beforeimage Pin (Bytes / Lines / SHA-256) | Afterimage Pin (Bytes / Lines / SHA-256) |
|---|---|---|---|
| 1 | `crates/mori-core/src/sherlock/compile_artifact.rs` | Preimage: `19,371` B / `403` L / `a8630ea3b843b383ab05d64ef679404038ebf9bd107891fb2e0f834b0d13058e`<br>True public beforeimage: `18,775` B / `391` L / `a7c841b47fe1754c308e65f41288b1ad8eae98944717e6945bc44918ca383411` | `25,315` B / `534` L / `926981690550aabeb504ebb47d7217dadd22d0851378936bb5108b4d08edaae5` |
| 2 | `crates/mori-core/src/sherlock/compile_artifact/complete_trace_wire.rs` | Preimage: `7,785` B / `93` L / `9b2a2e3587687d8e5596f9be3fc43e5268ff5087a10c37f765e3a208e70bbf3d` | `26,434` B / `564` L / `9ea305df536d26e540e3622313c3cd70ec2fa056708f72bd981e55affddea2e7` |
| 3 | `crates/mori-core/src/sherlock/compile_artifact/core_observation.rs` | Preimage: `11,699` B / `202` L / `9b54bef0f7ef2063a41e8ca300594a13a64553aa1660627c7152e3cb514fb425` | `59,722` B / `1,379` L / `35ddd23ac76dd671cbe12c23ba3af3ebecaae263a4f0160ee958adbd9a930efd` |
| 4 | `crates/mori-core/tests/sherlock_core1_complete_observation.rs` | Preimage: `5,668` B / `90` L / `dc307949c1601f20b446cfb3c77569be9e8d1e7d4dba27c7883adb1dc2836f79` | `17,947` B / `389` L / `47440c1a3ab7b75a9e36e01463c4e0abcb49028b10ede58370dcddca70f1dfda` |
| 5 | `crates/mori/tests/core1_complete_observation_handler.rs` | Preimage: `3,957` B / `64` L / `d96119fa79ae0e2c6a7c31f036c9e2bd9d7114cc448d2780b666f34847e90076` | `7,493` B / `138` L / `f07e5cb6d41c9ae7b86d0a9bfa021bfeb245247bc97bcafd84c46f53279767b4` |
| 6 | `crates/mori/src/commands/compile_sherlock.rs` | Preimage: `10,100` B / `165` L / `bfda5f790d59d475dec52b457f08e9055c218ca4c494391daf805c65a713ea3c` | `9,994` B / `164` L / `b7a32a3216223c3c20a5561274b0cf109e2bfcc48d904e729f164080bd48f556` |
| 7 | `crates/mori/tests/typed_action_input_compile_handler.rs` | Preimage: `22,831` B / `324` L / `567602de73f38d63977b5930fd4dc89b35a035aa9f4715c97b0897e3be8c2270`<br>LPW beforeimage: `22,702` B / `323` L / `5a7566fedad0527eb86b11524c8d42c15b2ae06cc768ad3ad6a7222fb3ef8403` | `22,831` B / `324` L / `567602de73f38d63977b5930fd4dc89b35a035aa9f4715c97b0897e3be8c2270` |
| 8 | `crates/mori-core/tests/fixtures/core1-complete-observation/quote.mori` | Preimage: `142` B / `1` L / `e688dd8c811be803c4c3bde7a326b8f86d07e7255d7642e4b7d676f5a22a13d2` | `142` B / `1` L / `e688dd8c811be803c4c3bde7a326b8f86d07e7255d7642e4b7d676f5a22a13d2` |
| 9 | `crates/mori-core/tests/fixtures/core1-complete-observation/eligible.mori` | Preimage: `201` B / `1` L / `358a55ca94b190408f0cd020ad26343b45e7ef53b1357034c3b147bc9ae4fd68` | `201` B / `1` L / `358a55ca94b190408f0cd020ad26343b45e7ef53b1357034c3b147bc9ae4fd68` |
| 10 | `crates/mori-core/tests/fixtures/core1-complete-observation/eligible.inputs.json` | Preimage: `80` B / `1` L / `6e8cc9c547c5eccf6d443bf1664c4ece2af3733f0b659bd88a2c3ca327df9b3b` | `80` B / `1` L / `6e8cc9c547c5eccf6d443bf1664c4ece2af3733f0b659bd88a2c3ca327df9b3b` |

---

## 3. Semantic Verification of Prior Review Fixes (`A01` & `B01`)

### 3.1 `M1-A01` Resolved — Non-Offset Per-Projection Limit Diagnostics in `BoundedJsonWriter::with_projection_budget`
- **Anchor**: [`afterimages/crates/mori-core/src/sherlock/compile_artifact/complete_trace_wire.rs:185-211`](file:///home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-whole-trace-budget-gemini4-mandatory-fix-owner04/afterimages/crates/mori-core/src/sherlock/compile_artifact/complete_trace_wire.rs#L185-L211) (`return Err(self.limit_error());` at line 208).
- **Semantic Verification**:
  - When `per_projection_limit == 0`, lines 193–195 immediately set `self.exceeded_limit = Some(0)` and return `Err(self.limit_error())`.
  - When `per_projection_limit > 0`, `projection_ceiling = self.buf.len().saturating_add(per_projection_limit)` and `self.active_limit = prev_active.min(projection_ceiling)`. After `let result = f(self);`, `self.active_limit = prev_active` is restored first (line 201).
  - If `result.is_err() && self.exceeded_limit.is_some()`, lines 203–208 rewrite `self.exceeded_limit` to `Some(per_projection_limit)` when `projection_ceiling <= prev_active` (or `Some(prev_active)` when the cumulative trace ceiling was the tighter bound) and return a freshly constructed `Err(self.limit_error())` rather than the stale `result` carrying `projection_ceiling = buf.len() + per_projection_limit`.
  - Consequently, non-zero-offset projection overflows in `Trace::begin_with_limits` (`core_observation.rs:434`), `Trace::push_record` (`line 504`), `Trace::finish_terminal` (`lines 562, 591`), and `Trace::failure_checked` (`lines 667, 679, 686`) report the true `per_projection_limit` in `actual_error["failure_boundary"]["limit"]` and `actual_error["serialization_error"]["limit"]`, matching the assertions at `core_observation.rs:1054-1057` and `sherlock_core1_complete_observation.rs:209-212, 232-235`.

### 3.2 `F-01` Resolved — Real `ExpandedStepIdC` and `RuleIdC` Imports & Partial-Move Elimination
- **Anchors**:
  - [`afterimages/crates/mori-core/src/sherlock/compile_artifact/core_observation.rs:14-16, 86-100`](file:///home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-whole-trace-budget-gemini4-mandatory-fix-owner04/afterimages/crates/mori-core/src/sherlock/compile_artifact/core_observation.rs#L14-L16) (`use crate::sherlock::helper_machine::shared::{BoundsC, ExpandedStepIdC, HostViolation, RuleIdC, RunSummary, StepDisposition};`).
  - [`afterimages/crates/mori-core/src/sherlock/compile_artifact/core_observation.rs:518-527`](file:///home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-whole-trace-budget-gemini4-mandatory-fix-owner04/afterimages/crates/mori-core/src/sherlock/compile_artifact/core_observation.rs#L518-L527) (`let CompleteStepRecord { before, event, after } = record;`).
- **Semantic Verification**:
  - Verified against [`crates/mori-core/src/sherlock/helper_machine/shared.rs:131-153`](file:///home/charl/Moriarty/.worktrees/sherlock-c6-physical-host-codecs-20261019/crates/mori-core/src/sherlock/helper_machine/shared.rs#L131-L153) and [`crates/mori-core/src/sherlock/compile_artifact/wire.rs:929, 1386, 1398`](file:///home/charl/Moriarty/.worktrees/sherlock-c6-physical-host-codecs-20261019/crates/mori-core/src/sherlock/compile_artifact/wire.rs#L1398-L1403): `StepEventC.step_id` has type `ExpandedStepIdC` (`Clone`, `!Copy`, `OwnerWire` -> `{"run_id": ..., "ordinal": "..."}`), and `StepEventC.rule_id` has type `RuleIdC` (`Copy`, `OwnerWire` -> string tag).
  - In `Trace::push_record` (`lines 518-527`), `record` is destructured via `let CompleteStepRecord { before, event, after } = record; drop(before); drop(after);` before moving `event.step_id`, `event.rule_id`, and `event.disposition`, completely eliminating the `E0382` partial-move error.
  - Both test files (`core_observation.rs:1205-1209` and `sherlock_core1_complete_observation.rs:289-293`) now assert `failed_step_id.is_object()` and `failed_step_id["ordinal"].is_string()`.

### 3.3 `M2-A01` / `F-02` Resolved — Real CLI `Report` Error-Envelope Comparison in `core1_complete_observation_handler.rs`
- **Anchors**: [`afterimages/crates/mori/tests/core1_complete_observation_handler.rs:8, 39-44, 95-105, 119-137`](file:///home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-whole-trace-budget-gemini4-mandatory-fix-owner04/afterimages/crates/mori/tests/core1_complete_observation_handler.rs#L39-L44) (`fn handler_failure_text(failure: &host::CompileFailure) -> String`).
- **Semantic Verification**:
  - Verified against [`crates/mori/src/commands/source_io.rs:44-50`](file:///home/charl/Moriarty/.worktrees/sherlock-c6-physical-host-codecs-20261019/crates/mori/src/commands/source_io.rs#L44-L50) and [`crates/mori/src/display.rs:2-12`](file:///home/charl/Moriarty/.worktrees/sherlock-c6-physical-host-codecs-20261019/crates/mori/src/display.rs#L2-L12): `selected_compile::run` wraps exported diagnostics via `source_io::operation`, formatting `Report::to_string()` as `"mori::command: "` followed by `display::text(&diagnostic)`.
  - `core1_complete_observation_handler.rs` now parses the raw JSON string `mori_core::json::export(&expected).unwrap()` via `mori_core::json::parse` (lines 98–99, 127–128) and compares `zero_err.to_string()` and `pub_err.to_string()` against `handler_failure_text(&expected)` (lines 105, 137), matching `typed_action_input_compile_handler.rs:79-81, 281`.

### 3.4 `F-03` Resolved — Zero Happy-Path 1 MiB Clone, Lazy In-Place Checkpoint Rollback, and Preserved Terminal Rollback Prefix
- **Anchors**:
  - [`afterimages/crates/mori-core/src/sherlock/compile_artifact/complete_trace_wire.rs:506-514`](file:///home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-whole-trace-budget-gemini4-mandatory-fix-owner04/afterimages/crates/mori-core/src/sherlock/compile_artifact/complete_trace_wire.rs#L506-L514) (`pub(super) fn parse_value(&self, field: &'static str)`).
  - [`afterimages/crates/mori-core/src/sherlock/compile_artifact/core_observation.rs:281-312, 550-630, 1332-1377`](file:///home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-whole-trace-budget-gemini4-mandatory-fix-owner04/afterimages/crates/mori-core/src/sherlock/compile_artifact/core_observation.rs#L281-L312).
- **Semantic Verification**:
  - `Trace::finish_terminal` (`line 600`) validates the finished buffer via `self.writer.parse_value("complete_trace")` by shared reference without cloning `self.writer` on the happy path, and moves the populated `self.writer` and `returned_checkpoint` into `BoundedTraceFailure` on error (`lines 603, 617`).
  - `BoundedTraceFailure::into_compile_failure` (`lines 281-312`) eliminates the `O(N * trace_limit)` `Vec<Option<Vec<u8>>>` allocation, rolling `writer` back in-place first to `returned_checkpoint` (closing with `TRACE_CLOSE_ROOT = b"}"`) and then in reverse across `record_checkpoints.iter().enumerate().rev()` (closing with `TRACE_PREFIX_CLOSE`). Because `record_checkpoints[0] < record_checkpoints[1] < ... < returned_checkpoint`, each `writer.rollback(cp)` truncates strictly downward without corrupting any earlier checkpoint prefix.
  - The unit test at `core_observation.rs:1332-1377` directly exercises the case where `returned_checkpoint` succeeds in `finish_terminal`, `terminal` write fails, `returned` + `actual_error` envelope exceeds `tight_terminal_limit`, and `into_compile_failure` rolls back in-place from `returned_checkpoint` to `record_checkpoints[1]` (`preserved_records == "1"`, `returned` absent, `records.len() == 1`).

### 3.5 `F-04` Resolved — Self-Contained 10-File Candidate with Coherent `typed_action_input_compile_handler.rs`
- **Anchor**: [`afterimages/crates/mori/tests/typed_action_input_compile_handler.rs:279-281, 296-297`](file:///home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-whole-trace-budget-gemini4-mandatory-fix-owner04/afterimages/crates/mori/tests/typed_action_input_compile_handler.rs#L279-L281).
- **Semantic Verification**:
  - `owner04` includes the 9th `SOURCE-FREEZE-REVISION02` file `crates/mori/tests/typed_action_input_compile_handler.rs` (`22,831` B, `324` lines, SHA-256 `567602de...`) in `afterimages/`, `preimages/`, `FILE-MAP.json`, and `forward.patch`/`inverse.patch`, while retaining the LPW beforeimage (`22,702` B, `323` lines, SHA-256 `5a7566fe...`) in `beforeimages/` and leaving the frozen LPW worktree untouched. All 15 CLI handler tests align with `CompileArtifact::failure` and `compile_sherlock.rs`.

### 3.6 `F-05` & `NB1-A01` Resolved — Explicit Wire Version `/2`, Shared Admission Reconstruction, Dual Budget Metadata, and Preserved Non-Publish Fallback Fields
- **Anchors**:
  - [`afterimages/crates/mori-core/src/sherlock/compile_artifact/complete_trace_wire.rs:21, 27, 122-130`](file:///home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-whole-trace-budget-gemini4-mandatory-fix-owner04/afterimages/crates/mori-core/src/sherlock/compile_artifact/complete_trace_wire.rs#L21-L27) (`TRACE_FORMAT`, `TRACE_SERIALIZATION_BUDGET`, `reconstruct_step_host_snapshot`).
  - [`afterimages/crates/mori-core/src/sherlock/compile_artifact.rs:53-55, 108-111, 169-280`](file:///home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-whole-trace-budget-gemini4-mandatory-fix-owner04/afterimages/crates/mori-core/src/sherlock/compile_artifact.rs#L169-L280) (`CompileArtifact::manifest`, `CompileFailure::export_diagnostic`).
- **Semantic Verification**:
  - Normalized traces carry `TRACE_FORMAT = "sherlock-core1-complete-trace/2"` and `TRACE_SERIALIZATION_BUDGET = "per_projection:admission.bounds.serialization_bytes;whole_trace:derive_trace_serialization_budget(admission.bounds);step_boundaries:image-only-shared-admission"`.
  - `complete_trace["initial"]` and `complete_trace["returned"]` retain the full `HostSnapshot` (`{"admission": ..., "image": ...}` with all 23 `ProgramSnapshot` tables and all 23 `ImageSnapshot` fields), while `records[i].before/after` and `terminal.before/after` emit `{"image": ...}` (with all 23 `ImageSnapshot` fields) and all 28 `StepEventC` fields remain intact on every record. `reconstruct_step_host_snapshot(&trace["initial"]["admission"], &step_boundary)` deterministically reconstructs the exact full `HostSnapshot`.
  - Under unchanged `config.json` (`serialization_bytes = 65,536`, `step_cap = 4,096`) and unchanged `mori_core::json` limits (`MAX_BYTES = 1,048,576`, `MAX_JSON_EXPORT_NODES = 65,536`, `MAX_JSON_DEPTH = 32`), `derive_trace_serialization_budget` evaluates to `1,048,576` B, and all positive multi-step runs (58-step `quote.mori`, 48-step `eligible.mori`, 42-step `quote`, 16-step `inspect`) stay well under `18,000` JSON AST nodes and `500 KiB` pretty-printed bytes, passing `mori_core::json::export` directly on line 170 of `CompileFailure::export_diagnostic`.
  - If a caller constructs an artificially oversized `CompileFailure` (tested at `sherlock_core1_complete_observation.rs:310-389`), `CompileFailure::export_diagnostic` preserves `stage`, `evaluation_performed`, `events_forwarded`, `completed`, `message`, `failure_boundary` (trimming only oversized `before`/`after` snapshots in the final fallback at `compile_artifact.rs:265-279`), `serialization_error`, `violation`, and `diagnostic_export_error`.
  - **Substantive Design Vote**: As an independent non-author reviewer, I vote **APPROVE / CONCUR** on this normalized `sherlock-core1-complete-trace/2` + dual per-projection/cumulative budget design and implementation.

---

## 4. Non-Blocking Observations

- **`NB-01` (Minor Non-Test Unused Import Hygiene)**: In [`afterimages/crates/mori-core/src/sherlock/compile_artifact/core_observation.rs:20`](file:///home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-whole-trace-budget-gemini4-mandatory-fix-owner04/afterimages/crates/mori-core/src/sherlock/compile_artifact/core_observation.rs#L20), `TRACE_SERIALIZATION_BUDGET` is imported at module scope and used in `#[cfg(test)] mod tests` (`line 1004` via `use super::*;`), while non-test code in `core_observation.rs` uses the matching byte-slice literals `TRACE_PREFIX_CLOSE` and `TRACE_AFTER_RETURNED_SERIALIZATION_BUDGET` (`lines 43-47`). Because the workspace does not set `#[deny(unused_imports)]`, this at most emits a harmless unused-import warning when building `mori-core` without `--test`.

---

## 5. Typed Unresolved Limits (`APPROVE_SOURCE_WITH_LIMITS`)

1. **`UNCOMPILED_UNRUN`**: This review is strictly static/source-only (`compiled = false`, `sourceExecution = false`). No compiler or test runner has been executed on `owner04`.
2. **`SECOND_INDEPENDENT_VOTE_AND_EXECUTION_GATE`**: Author is not a vote; consequential design/resource adoption retains two substantive independent non-author votes before authorized ordinary test execution (`core_observation::tests`, `sherlock_core1_complete_observation`, `core1_complete_observation_handler`, and `typed_action_input_compile_handler`).
3. **`INDEPENDENT_FULLTRACE_SEMANTICS_SEPARATE`**: The positive 58-step `quote.mori` (`"59"`), 48-step `eligible.mori` (`true`), and 15 CLI handler assertions in the candidate are verified as self-contained source predicates against the existing owner API, not an independent semantic oracle; new ordinary full-trace semantic expectations are being independently derived separately.
4. **`NATIVE_TARGET_AND_EARS_ACCEPTANCE_NONE`**: Source approval does not establish test execution, native circuit/prover qualification (`evidence.native = "unrun"`, R3 `k=17` row exhaustion open), financial execution beyond genesis, Midnight Preview/Fenrir/stagenet settlement (`evidence.target = "unrun"`), or EARS requirement closure (`evidence.acceptance = "none"`).
