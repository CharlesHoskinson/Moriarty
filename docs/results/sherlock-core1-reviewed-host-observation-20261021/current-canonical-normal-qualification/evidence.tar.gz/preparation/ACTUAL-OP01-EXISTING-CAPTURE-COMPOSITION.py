from pathlib import Path
import json,hashlib,runpy,os,stat,sys,re
sys.dont_write_bytecode=True
D=Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/core1-public-complete-observation-source-20261020')
B=Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-current-canonical-production-qualification01');V=B/'data';A=B/'actual-one-01'
load=lambda p:json.loads(Path(p).read_bytes())
plan=V/'PROPOSED-ONE-CURRENT-CANONICAL-NORMAL.json'
assert hashlib.sha256(plan.read_bytes()).hexdigest()=='c094f49d7b296dc039d10e260a6c7957762be96fe7efe1b1aeda53c0f6be298e'
j=load(plan);hp=j['captureHelper']
assert hashlib.sha256(Path(hp['path']).read_bytes()).hexdigest()=='713119d9400f82d559967e4296313cec8cde7125dc91a74152500577ced00626'
h=runpy.run_path(hp['path'],run_name='existing_capture_functions_only')
adoption=V/'PARENT-DELEGATED-ONE-COMPILE.json'
assert hashlib.sha256(adoption.read_bytes()).hexdigest()=='ff50ab18e41dc1c55dbe337ec58f6da23198c10489d072d46a1b6aa79e838ca4'
ad=load(adoption);assert ad['status']=='PARENT_DELEGATED_CURRENT_CANONICAL_CORE_NORMAL_ONLY'
controls=[h['pin'](adoption),h['pin'](__file__),h['pin'](plan),h['pin'](V/'STATIC-PREPOST-PINS.prospective.json'),h['pin'](V/'ACTUAL-STAGED-SOURCE-IDENTITY.json')]
for r in ad['sourceReviewsAndDirectReadset']:h['check'](r);controls.append(r)
stage=load(V/'ACTUAL-STAGED-SOURCE-IDENTITY.json');assert len(stage['rows'])==121 and stage['fullFileMembershipExact']
for row in stage['rows']:h['check'](row['origin']);h['check'](row['actual'])
for r in load(V/'FINAL13-PROSPECTIVE-SOURCE-COPYMAP.json')['LPWPreservation']['readOnlyMetadataPins']+[load(V/'FINAL13-PROSPECTIVE-SOURCE-COPYMAP.json')['LPWPreservation']['CargoLock']]:h['check'](r);controls.append(r)
flat=load(V/'STATIC-PREPOST-PINS.prospective.json')['files'];assert len(flat)==373
INDEX = 0
op=j['operations'][INDEX];assert op['id'] in ad['selectedOperationIds'] and INDEX in (0,1);phase=A/op['id'];assert not phase.exists() and not phase.is_symlink()
prior=[];buildpins=[]
for earlier in j['operations'][:INDEX]:
 pd=A/earlier['id'];outcome=load(pd/'ROOT-OUTCOME.json');assert outcome['accepted'] is True
 h['check'](outcome['result']);rawprior=load(pd/'RESULT.json')
 assert rawprior['actual_exit']==0 and rawprior['controller_failure'] is None and load(pd/'COMMAND.json')==earlier
 for r in rawprior['streams']:h['check'](r);assert r['full_stream_retained'] and r['bytes']==r['bytes_seen']==r['bytes_retained']
 for r in outcome.get('generated',[]):h['check'](r);buildpins.append(r)
 prior.append(h['pin'](pd/'ROOT-OUTCOME.json'))
 controls += [h['pin'](p)for p in sorted(pd.iterdir())if p.is_file()]
assert all(not Path(p).exists() and not Path(p).is_symlink()for p in op['outputs'])
build=B/'prospective-ordinary/build'
assert sorted(str(p)for p in build.iterdir())==sorted(r['path']for r in buildpins)
assert Path(op['environment']['TMPDIR']).is_dir() and not list(Path(op['environment']['TMPDIR']).iterdir())
assert op['wallSeconds']==30 and op['keptBytesPerStream']==131072 and op['cpuSeconds']==25 and op['addressSpaceBytes']==2147483648 and op['fileSizeBytes']==67108864
for p in op['requiredGeneratedInputs']:assert any(r['path']==p for r in buildpins)
def durable(p,v):
 p=Path(p);assert not p.exists();h['save'](p,v)
 with p.open('rb')as f:os.fsync(f.fileno())
 fd=os.open(p.parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
def inventory():
 out=[]
 for dr in load(V/'EXACT-L-DIRECTORY-MEMBERSHIP.prospective.json')['directories']:
  d=Path(dr['directory']);assert sorted(p.name for p in d.iterdir())==sorted(x['name']for x in dr['entries'])
  for x in dr['entries']:
   p=d/x['name'];s=p.lstat();assert stat.S_ISLNK(s.st_mode)==x['symlink'] and stat.S_ISREG(s.st_mode)==x['regularFile']
   assert oct(stat.S_IMODE(s.st_mode))==x['mode'] and s.st_size==x['size']
   if x['symlink']:assert os.readlink(p)==x['linkTarget']
   if 'qualifiedLibrary'in x:h['check'](x['qualifiedLibrary'])
  out.append(dict(directory=str(d),members=len(dr['entries']),exact=True))
 return out
assert h['static_check'](flat+controls+buildpins)['all_match'];inventory()
phase.mkdir(mode=0o700)
durable(phase/'ROOT-SELECTION.json',dict(selectedIds=[op['id']],proposal=h['pin'](plan),manual=h['pin'](__file__),adoption=h['pin'](adoption),priorAccepted=prior,unchangedCaps=True,noRetry=True))
controls.append(h['pin'](phase/'ROOT-SELECTION.json'))
try:
 pre=h['static_check'](flat+controls+buildpins);durable(phase/'PRECHECK.json',pre);durable(phase/'PRE-L-INVENTORY.json',inventory());assert pre['all_match']
 raw=h['capture'](op,phase);durable(phase/'RESULT.json',raw)
 for name in ['COMMAND.json','stdout.bin','stderr.bin','RESULT.json']:
  with(phase/name).open('rb')as f:os.fsync(f.fileno())
 fd=os.open(phase,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
 observed=[]
 for p in sorted(build.iterdir()):
  assert p.is_file() and not p.is_symlink()
  with p.open('rb')as f:os.fsync(f.fileno())
  observed.append(h['pin'](p))
 fd=os.open(build,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
 durable(phase/'OBSERVED-BUILD-OUTPUTS.json',dict(files=observed,priorToAcceptance=True))
 post=h['static_check'](flat+controls+buildpins);durable(phase/'POSTCHECK.json',post);durable(phase/'POST-L-INVENTORY.json',inventory());assert post['all_match']
 assert load(phase/'COMMAND.json')==op and len(raw['streams'])==2
 for r in raw['streams']:h['check'](r);assert r['full_stream_retained'] and r['bytes']==r['bytes_seen']==r['bytes_retained']
 assert raw['actual_exit']==0 and raw['controller_failure'] is None,raw
 out=(phase/'stdout.bin').read_bytes();err=(phase/'stderr.bin').read_bytes()
 result=dict(accepted=True,id=op['id'],result=h['pin'](phase/'RESULT.json'),elapsedSeconds=raw['elapsed_seconds'],staticRows=373,prePostAllMatch=True,fullStreamsRetained=True,noRetry=True)
 assert out==b''
 text=err.decode('utf-8',errors='strict')
 diagnostic_lines=text.splitlines()
 headers=[s for s in diagnostic_lines if s.startswith('warning') and not re.fullmatch(r'warning: \d+ warnings? emitted',s)]
 errors=[s for s in diagnostic_lines if re.match(r'^(?:error(?:\[[^\]]+\])?:|LLVM ERROR:|fatal runtime error:)',s)]
 summaries=[int(m.group(1))for s in diagnostic_lines if(m:=re.fullmatch(r'warning: (\d+) warnings? emitted',s))]
 assert not errors and (summaries==[len(headers)] if headers else summaries==[])
 durable(phase/'DIAGNOSTIC-CLASSIFICATION.json',dict(stderr=h['pin'](phase/'stderr.bin'),warningCount=len(headers),warningHeaders=headers,errorCount=len(errors),errors=errors,completeStderrDecoded=True,notWarningFree=bool(headers)))
 products=[h['pin'](p)for p in op['outputs']]
 assert all(r['bytes']>0 for r in products)
 assert {r['path']for r in observed}=={r['path']for r in buildpins+products}
 durable(phase/'ACTUAL-GENERATED-PINS.json',dict(files=products))
 ex=load(V/'EXPECTED-DEP-MEMBERSHIP.prospective.json')[op['expected']['dependencySet']]
 allowed={str(Path(r['path']).resolve(strict=True)):r for r in ex['files']}
 assert len(allowed)==ex['count']==op['expected']['exactDependencies']
 deps=h['dep_inputs'](op['outputs'][1],allowed)
 seen={str(Path(r['selected_binding']).resolve(strict=True))for r in deps};assert seen==set(allowed)
 durable(phase/'EXACT-DEP-MEMBERSHIP.json',dict(files=deps,canonicalCount=len(seen),expected=ex['count'],exact=True))
 for i,p in enumerate(op['outputs']):os.chmod(p,0o500 if i==0 and '--test' in op['argv'] else 0o400)
 result.update(generated=products,exactDependencies=len(seen),warningCount=len(headers),errorCount=0,diagnostics=h['pin'](phase/'DIAGNOSTIC-CLASSIFICATION.json'),testsExecuted=0)
 final=h['static_check'](flat+controls+buildpins+result.get('generated',[]));durable(phase/'FINAL-PIN-CHECK.json',final);assert final['all_match']
 durable(phase/'ROOT-OUTCOME.json',result);print(json.dumps(result),flush=True)
except BaseException as e:
 durable(phase/'FAILURE.json',dict(error=type(e).__name__+': '+str(e),noRetry=True,remainingOperationsUnrun=True))
 raise
