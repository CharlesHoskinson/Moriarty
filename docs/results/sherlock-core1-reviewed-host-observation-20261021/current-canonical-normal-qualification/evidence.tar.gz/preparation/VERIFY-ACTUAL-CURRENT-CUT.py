from pathlib import Path
import json,hashlib,subprocess,stat,os
B=Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/core1-current-canonical-production-qualification01')
P=B/'actual-one-01/01-compile-normal'; O=B.parent/'core1-reviewed-api-mapping-publication-prep01'
PW='/home/charl/Moriarty/.worktrees/sherlock-c6-physical-host-codecs-20261019'
base='f73784fbd5c0c22a3f0d16ae31769948b6729674'
load=lambda p:json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p);d=p.read_bytes();return dict(path=str(p),bytes=len(d),sha256=hashlib.sha256(d).hexdigest())
def check(r):
 a=pin(r['path']);assert all(a[k]==r[k]for k in ('bytes','sha256'));return a

def save(p,j):
 p=Path(p);assert not p.exists();p.write_text(json.dumps(j,indent=2)+'\n')
 with p.open('rb')as f:os.fsync(f.fileno())
 fd=os.open(p.parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)

raw=load(P/'RESULT.json');out=load(P/'ROOT-OUTCOME.json');cmd=load(P/'COMMAND.json')
assert raw['actual_exit']==0 and raw['controller_failure']is None and out['accepted']is True
assert cmd==load(B/'data/PROPOSED-ONE-CURRENT-CANONICAL-NORMAL.json')['operations'][0]
for r in raw['streams']:
 check(r);assert r['bytes']==r['bytes_seen']==r['bytes_retained']and r['full_stream_retained']
assert (P/'stdout.bin').read_bytes()==b''
err=(P/'stderr.bin').read_text();assert err.endswith('warning: 34 warnings emitted\n\n')
flat=load(B/'data/STATIC-PREPOST-PINS.prospective.json')['files'];assert len(flat)==373
for r in flat:check(r)
for n in ('PRECHECK.json','POSTCHECK.json','FINAL-PIN-CHECK.json'):
 j=load(P/n);assert j['all_match']and all(r['match']for r in j['files'])
assert load(P/'PRE-L-INVENTORY.json')==load(P/'POST-L-INVENTORY.json')
li=load(B/'data/EXACT-L-DIRECTORY-MEMBERSHIP.prospective.json')['directories']
for r in li:
 d=Path(r['directory']);assert sorted(p.name for p in d.iterdir())==sorted(v['name']for v in r['entries'])
 for v in r['entries']:
  p=d/v['name'];s=p.lstat();assert oct(stat.S_IMODE(s.st_mode))==v['mode']and s.st_size==v['size']
  assert stat.S_ISREG(s.st_mode)==v['regularFile']and stat.S_ISLNK(s.st_mode)==v['symlink']
  if v['symlink']:assert os.readlink(p)==v['linkTarget']
  if 'qualifiedLibrary'in v:check(v['qualifiedLibrary'])
stage=load(B/'data/ACTUAL-STAGED-SOURCE-IDENTITY.json');rows=stage['rows'];assert len(rows)==121
snapshot=B/'snapshot';assert {str(p.relative_to(snapshot))for p in snapshot.rglob('*')if p.is_file()}=={r['relative']for r in rows}
overlays={r['target']:r for r in load(O/'COPY-MAP.json')['files']if r['kind']=='exact reviewed source'};assert len(overlays)==3
queries=''.join(base+':'+r['relative']+'\n'for r in rows)
q=subprocess.run(['git','cat-file','--batch'],cwd=PW,input=queries.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
assert q.stderr==b'';data=q.stdout;pos=0;canonical=[];different=[]
for r in rows:
 check(r['origin']);a=check(r['actual']);assert stat.S_IMODE(Path(a['path']).stat().st_mode)==0o444
 e=data.index(b'\n',pos);header=data[pos:e].decode();pos=e+1
 if header.endswith(' missing'):
  d=None
 else:
  oid,typ,sz=header.split();assert typ=='blob';sz=int(sz);d=data[pos:pos+sz];pos+=sz;assert data[pos:pos+1]==b'\n';pos+=1
 v=dict(relative=r['relative'],actual=a,canonicalExists=d is not None,canonicalSHA256=None if d is None else hashlib.sha256(d).hexdigest())
 if d is None or v['canonicalSHA256']!=a['sha256']:
  assert r['relative']in overlays;assert a['sha256']==overlays[r['relative']]['afterimage']['sha256'];different.append(r['relative']);v['classification']='exact reviewed Core1 product overlay'
 else:v['classification']='byteequal canonical source'
 canonical.append(v)
assert pos==len(data)and set(different)==set(overlays)
dep=load(P/'EXACT-DEP-MEMBERSHIP.json');assert dep['exact']and dep['canonicalCount']==dep['expected']==121
assert {str(Path(r['selected_binding']).resolve())for r in dep['files']}=={str(Path(r['actual']['path']).resolve())for r in rows}
for r in dep['files']:check(r)
generated=[]
for r in out['generated']:
 check(r);m=stat.S_IMODE(Path(r['path']).stat().st_mode);assert m==0o400;generated.append(dict(**r,mode=oct(m)))
assert len(generated)==2
for r in load(O/'COPY-MAP.json')['files']:check(r['afterimage'])
assert pin(O/'HANDOFF.json')['sha256']=='b5f137fa787307dd73efa92de0d7da04434e90f3f9a62a4346a1b9feb3cf6b74'
sourceproof=dict(canonicalBase=base,normalDepInputs=121,canonicalEqual=118,reviewedOverlays=3,reviewedOverlayPaths=different,allSourceRows=canonical,noSnapshotExtras=True,fullActualDepMembership=True,normalCfgTestFalse='--test'not in cmd['argv'],noReducedCore=True)
save(B/'ACTUAL-CANONICAL-SOURCE-EQUALITY.json',sourceproof)
receipt=dict(status='ACTUAL_CURRENT_CANONICAL_PLUS_THREE_REVIEWED_CORE1_NORMAL_COMPILE_PASS',agentReadbackOnly=True,rootAdoptionPending=True,result=pin(P/'RESULT.json'),command=pin(P/'COMMAND.json'),outcome=pin(P/'ROOT-OUTCOME.json'),elapsedSeconds=raw['elapsed_seconds'],exit=0,staticRows=373,staticRowsRehashedNow=373,qualifiedToolLibraryRows=252,sourceInputs=121,canonicalEqualSourceInputs=118,exactReviewedProductionChanges=3,fullLDistinctDirectories=3,fullLMembers=[len(r['entries'])for r in li],allPrePostFinalPinsMatch=True,allActualSourceDepsMatch=True,generated=generated,stdout=pin(P/'stdout.bin'),stderr=pin(P/'stderr.bin'),fullStdoutAndStderrRead=True,warnings=34,errors=0,sourceEquality=pin(B/'ACTUAL-CANONICAL-SOURCE-EQUALITY.json'),publication11Unchanged=True,publication11=pin(O/'HANDOFF.json'),onlyOneCompilerChildAttempt=True,prelaunchPreparationFailure=pin(B/'PRE-LAUNCH-DIRECTORY-PREPARATION-FAILURE.json'),testsRun=0,noSDKNativeCargoProviderGitMutation=True,limitations=['One exact normal sourcecut at canonical f73784fb plus three reviewed Core1 files; not all tracked files or Cargo integration.','No runtime, CLI, eligible145 export, independent full-image semantic oracle, native or EARS acceptance follows from compilation.','Original publication11 and historical failures remain unchanged.'])
save(B/'INDEPENDENT-READBACK.json',receipt)
print(json.dumps(dict(readback=pin(B/'INDEPENDENT-READBACK.json'),sourceEquality=pin(B/'ACTUAL-CANONICAL-SOURCE-EQUALITY.json'),result='PASS'),indent=2))
