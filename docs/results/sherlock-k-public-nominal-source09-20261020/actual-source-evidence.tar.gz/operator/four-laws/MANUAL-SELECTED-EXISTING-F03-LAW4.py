from pathlib import Path
import sys,os,json,hashlib,runpy,datetime,glob
sys.dont_write_bytecode=True
N=Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/doctorwatson-stagenet-four-milestone-audit-20261020/k-next-public-nominal-simulate-source09')
H=N/'ordinary-law4-selection01';root=N/'actual-laws4-01'
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checked(r):
 a=pin(r['path']);assert a==r,(a,r);return a
def load(p):return json.loads(Path(p).read_bytes())
def syncdir(p):
 fd=os.open(p,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
def save(p,v):
 b=(json.dumps(v,indent=2)+'\n').encode();fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb')as f:f.write(b);f.flush();os.fsync(f.fileno())
 syncdir(p.parent)
def inventory(p):return {str(x.relative_to(p)):('directory'if x.is_dir()else'file')for x in sorted(p.rglob('*'))}
card=load(H/'SELECTED-EXISTING-ORDINARY-12-PHASES.json');manifest=load(card['manifest']['path']);checked(card['manifest']);assert len(card['phases'])==12 and len(manifest['cases'])==4
reuse=load(N/'postcompile-actual-qualification01/COMPILED-REUSE-EXACT15.json');source=load(N/'SOURCE-FREEZE.json');rows=load(N/'actual/FLAT-INPUT-PINS.json')['members'];assert len(rows)==310
rows=rows+reuse['members']
for k in ['base','codec']:checked(card['Bool_consumer'][k]);rows.append(card['Bool_consumer'][k])
basepath=Path(card['Bool_consumer']['base']['path'])
for name in ['nominal-product-syntax.k','c6-logical-syntax.k']:rows.append(pin(basepath.parent/name))
for p in [H/'SELECTED-EXISTING-ORDINARY-12-PHASES.json',H/'PUBLIC-LAW4-QUERY-MANIFEST.json',Path(__file__),N/'postcompile-actual-qualification01/ACTUAL-COMPLETE-USER-LABEL-SORT-ARITY-MAP.json',N/'postcompile-actual-qualification01/COMPILED-REUSE-EXACT15.json',N/'actual/FINAL-COMPILE-ACCEPTANCE.json']:rows.append(pin(p))
rows+= [x['input']for x in manifest['cases']]
rows=sorted({x['path']:x for x in rows}.values(),key=lambda x:x['path'])
tools=load(N/'PROPOSED-ONE-EXISTING-F03-COMPILE-DATA.json');tools=load(tools['tools']['path'])
def memberships():
 for folder,expected in [(N/'source',[x['path']for x in source['members']if '/source/'in x['path']]),(N/'tests',[x['path']for x in source['members']if '/tests/'in x['path']]),(N/'actual/validate-entry-kompiled',[x['path']for x in reuse['members']])]:
  got=sorted(str(x)for x in folder.rglob('*'));assert got==sorted(expected),(str(folder),got)
 assert sorted(glob.glob(tools['classpath_pattern']))==sorted(x['path']for x in tools['classpath_jar_membership'])
 for x in tools['entries']:assert str(Path(x['path']).resolve(strict=True))==x['resolved_path']
 return dict(source4=True,test1=True,compiled15=True,classpath156=True,resolved4=True)
pre=[checked(x)for x in rows];memberships();assert not root.exists()
# These closed query documents are generated from actual compiled declarations only.
for index,case in enumerate(manifest['cases']):
 assert case['index']==index and case['expected_Bool']is True
 checked(case['input']);q=load(case['input']['path'])
 assert q=={'format':'KAST','version':4,'term':{'node':'KApply','label':{'node':'KLabel','name':case['compiled_klabel'],'params':[]},'arity':0,'args':[]}}
 assert type(q['version'])is int and type(q['term']['arity'])is int and type(q['term']['args'])is list and type(q['term']['label']['params'])is list
root.mkdir(mode=0o700);syncdir(N)
save(root/'OPERATOR-SELECTION.json',dict(selectedBy='Root explicit instruction; persistent K lane delegated operator',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),manual=pin(__file__),phasecard=pin(H/'SELECTED-EXISTING-ORDINARY-12-PHASES.json'),sourceApprovalSeparate=True,exact12ChildrenFor4Laws=True,scope='finite same-author synthetic UNADMITTED source assertion self-consistency only',noCompileNoOldPrefixReplay=True,expectedPrivateReads=0,pythonStdlibHistoricalUnpinnedQualification=True))
save(root/'STATIC-PINS.json',dict(members=rows,exact_membership=memberships()))
save(root/'ALL4-QUERIES-VALIDATED-BEFORE-FIRST-K.json',dict(manifest=pin(H/'PUBLIC-LAW4-QUERY-MANIFEST.json'),queries=[x['input']for x in manifest['cases']],strictNativeKindsAndSourceOrder=True,actualSymbolsOnly=True))
api=runpy.run_path(card['callback']['fullsource']['path'],run_name='selected_nonmain_existing_F03_law4')
assert api['CHILD_SECONDS']==30 and api['SWEEP_SECONDS']==3
base=runpy.run_path(str(basepath),run_name='selected_existing_complete_Bool_consumer')
codec=base['codec'];dynamic=[];completed=[];lawresults=[];failure_class='INFRASTRUCTURE_STOP'
try:
 for phase in card['phases']:
  pre=[checked(x)for x in rows];prior=[checked(x)for x in dynamic];mem=memberships()
  cwd=Path(phase['cwd']);assert not cwd.exists();cwd.mkdir(parents=True,mode=0o700)
  for k in ['HOME','TMPDIR']:Path(phase['environment'][k]).mkdir(mode=0o700)
  save(root/(phase['id']+'-PRE.json'),dict(static_members=pre,prior_products=prior,membership=mem))
  save(cwd/'COMMAND.json',phase)
  record={};api['launch'](record,phase['argv'],dict(phase['environment']),phase['cwd'],phase['environment']['SHERLOCK_K_ATTEMPT_TOKEN'],536870912)
  save(cwd/'RESULT.json',record)
  files=sorted(p for p in cwd.rglob('*')if p.is_file())
  for p in files:
   with p.open('rb')as f:os.fsync(f.fileno())
  for p in sorted([cwd]+[x for x in cwd.rglob('*')if x.is_dir()],key=lambda x:len(x.parts),reverse=True):syncdir(p)
  syncdir(cwd.parent);syncdir(root)
  produced=[pin(p)for p in files];save(root/(phase['id']+'-RAW-FROZEN.json'),dict(record=record,files=produced,classificationNotYetPerformed=True))
  post=[checked(x)for x in rows];postprior=[checked(x)for x in dynamic];memberships()
  inv=inventory(cwd);wanted={x:'directory'for x in ['home','tmp']};wanted.update({x:'file'for x in ['COMMAND.json','RESULT.json','stdout','stderr']})
  if phase['products']:wanted['result.kore']='file'
  save(root/(phase['id']+'-POST.json'),dict(static_members=post,prior_products=postprior,inventory=inv,expectedInventory=wanted,rawDurableBeforeClassification=True))
  assert inv==wanted,('inventory',phase['id'],inv)
  assert record['returncode']==0 and record['outcome']=='exited' and not any(record[k]for k in ['timed_out','containment_breach','swept','remaining','group_members_after_exit']),record
  assert not Path(phase['stderr']).read_bytes(),('nonempty stderr retained; diagnostic classification required',phase['id'])
  for p in phase['products']:assert Path(p).is_file()and Path(p).stat().st_size>0
  if phase['step']in ['00-kast-json','02-full-print']:assert Path(phase['stdout']).stat().st_size>0
  if phase['step']=='02-full-print':
   printed=Path(phase['stdout']).read_text();failure_class='BOOL_FORMAT_OR_PARSE_FAILURE'
   term=codec.parse_printed(base['complete_term'](printed),'Bool')
   assert term.sort=='Bool'and term.name=='@Bool'and len(term.args)==1 and type(term.args[0])is bool
   report=dict(law=phase['law'],status='LAW_PASS'if term.args[0]else'LAW_FALSE',bool_value=term.args[0],printed=pin(phase['stdout']),whole_print_consumed=True,rawFrozenBeforeParse=True,sameAuthorUnadmitted=True)
   save(root/(phase['law']+'-BOOL-RESULT.json'),report);lawresults.append(report)
   failure_class='SEMANTIC_LAW_FALSE';assert term.args[0]is True,report
   failure_class='INFRASTRUCTURE_STOP'
  dynamic+=produced
  for name in [phase['id']+'-PRE.json',phase['id']+'-RAW-FROZEN.json',phase['id']+'-POST.json']:dynamic.append(pin(root/name))
  completed.append(dict(id=phase['id'],law=phase['law'],record=record,files=produced))
  save(root/(phase['id']+'-ACCEPTED.json'),dict(status='PASS_SCOPED_PHASE',record=record))
  print(json.dumps(dict(phase=phase['id'],seconds=record['elapsed_seconds'],lawsPassed=len(lawresults))),flush=True)
 assert len(completed)==12 and len(lawresults)==4
 [checked(x)for x in rows];[checked(x)for x in dynamic];memberships()
 save(root/'AGGREGATE.json',dict(status='PASS_4_FINITE_PUBLIC_NOMINAL_SOURCE09_K_LAWS',operations=completed,laws=lawresults,staticPins=len(rows),totalChildSeconds=sum(x['record']['elapsed_seconds']for x in completed),expectedPrivateReads=0,scope='4 same-author finite task-local positive source assertions only; no genuine admission, native, StepInv, refinement, full39 or EARS'))
 allfiles=sorted(p for p in root.rglob('*')if p.is_file())
 for p in allfiles:
  with p.open('rb')as f:os.fsync(f.fileno())
 for p in sorted([root]+[p for p in root.rglob('*')if p.is_dir()],key=lambda x:len(x.parts),reverse=True):syncdir(p)
 syncdir(N);save(root/'ALL-ACTUAL-FILES-FROZEN.json',dict(files=[pin(p)for p in allfiles],streams=24,children=12,laws=4,allContentsAndDirsFsynced=True,privateExpectedReads=0))
 print('PASS_4_FINITE_PUBLIC_NOMINAL_SOURCE09_K_LAWS',flush=True)
except BaseException as e:
 save(root/'FAILURE.json',dict(status=failure_class,error=type(e).__name__+': '+str(e),completed=[x['id']for x in completed],lawResults=lawresults,noRetry=True))
 syncdir(root);raise
