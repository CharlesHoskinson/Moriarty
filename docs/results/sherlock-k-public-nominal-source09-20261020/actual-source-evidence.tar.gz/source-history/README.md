# Public nominal source09 counterpart

This source-only candidate translates the two new public `map-queue.mori` and `mirror-arbor.mori` inputs into explicit local K program tables. It uses the existing nominal interpreter for recursive calls, pattern bindings, addition, constructors and saved environments. The additive positive `ngNot` transition evaluates one operand, restores its saved environment and records both request and return. No fixture-specific evaluator is introduced.

The hand-derived complete return trees were frozen before the new module. Queue field order is `z_item,a_tail`, envelope order `z_items,a_marker`; Arbor order is `z_left,a_right`, stamp order `z_tree,a_code`. Type arguments remain ordered recursive type values. The typed projection pairs explicit local concrete IDs with source names and exact declaration metadata. Those IDs and occurrence numbers are manual K input identities, with no claim of equality to the compiler's canonical allocation.

`npRunReference` invokes existing `ngInitial` and `ngAdvance`; `npObserved` retains the entire final `NGState` plus its typed return projection. The model does not replace the state with a scalar or fill it from an expected result. The four unrun laws check both complete return trees, a held-out `not(false)` source case, and exact Not-step restoration with different live/saved maps and a remaining frame.

The source task performed only passive delimiter/require checks and literal constructor sort/arity checks. This is not a K parse, compile, runtime, proof or admission observation. A 512-step observer cut is proposed, without asserting that it is fuel, physical work, or a proved bound. Metadata completeness, unique IDs, typed closed source and ordinary UInt128 normal-domain premises remain external.

No Rust nominal test, new actual result, private expectation or generator body was read. The expectation author later wrote this K candidate, so this is independent of the Rust producer outputs, not independent-author corroboration. Older EnvGet actual-diagnostic exposure is historical and unrelated; no such afterstate was reused here. Complete independent prefix/event and genuine admission/native/refinement/full39/EARS obligations remain open.

Next check: fresh full source/API review, then Root may select one unchanged-class F03 compile. Qualify generated symbol names from actual products before any separate finite-law or full-observation run. Existing accepted programs and checks are not replayed.
