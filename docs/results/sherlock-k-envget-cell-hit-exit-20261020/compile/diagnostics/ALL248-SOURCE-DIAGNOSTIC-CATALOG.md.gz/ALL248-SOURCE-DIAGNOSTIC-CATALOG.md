## 1 Warning/Compiler/deprecated-klabel csUnvisited

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(10, 22, 10, 57); bytes[0,498).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csUnvisited)`, or replace it by `symbol(csUnvisited)`.
  syntax CSVisit ::= csUnvisited() [klabel(csUnvisited)]
```

## 2 Warning/Compiler/deprecated-klabel csFields

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(11, 22, 11, 51); bytes[498,978).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csFields)`, or replace it by `symbol(csFields)`.
  syntax CSVisit ::= csFields() [klabel(csFields)]
```

## 3 Warning/Compiler/deprecated-klabel csValidateTask

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(12, 21, 12, 81); bytes[978,1530).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csValidateTask)`, or replace it by `symbol(csValidateTask)`.
  syntax CSTask ::= csValidateTask(CTRef, CSVisit, Int) [klabel(csValidateTask)]
```

## 4 Warning/Compiler/deprecated-klabel csEqualTask

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(13, 21, 13, 82); bytes[1530,2078).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csEqualTask)`, or replace it by `symbol(csEqualTask)`.
  syntax CSTask ::= csEqualTask(CTRef, CTRef, CSVisit, Int) [klabel(csEqualTask)]
```

## 5 Warning/Compiler/deprecated-klabel csPairTask

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(14, 21, 14, 69); bytes[2078,2598).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csPairTask)`, or replace it by `symbol(csPairTask)`.
  syntax CSTask ::= csPairTask(Int, Int, CTRef) [klabel(csPairTask)]
```

## 6 Warning/Compiler/deprecated-klabel csNoTasks

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(15, 22, 15, 53); bytes[2598,3084).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoTasks)`, or replace it by `symbol(csNoTasks)`.
  syntax CSTasks ::= csNoTasks() [klabel(csNoTasks)]
```

## 7 Warning/Compiler/deprecated-klabel csTask

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(16, 22, 16, 62); bytes[3084,3582).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csTask)`, or replace it by `symbol(csTask)`.
  syntax CSTasks ::= csTask(CSTask, CSTasks) [klabel(csTask)]
```

## 8 Warning/Compiler/deprecated-klabel csHelperTables

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(17, 29, 17, 109); bytes[3582,4191).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperTables)`, or replace it by `symbol(csHelperTables)`.
  syntax CSHelperTables ::= csHelperTables(CHHelperOption, CHResultOption, CSTasks) [klabel(csHelperTables)]
```

## 9 Warning/Compiler/deprecated-klabel csCaps

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(18, 21, 18, 189); bytes[4191,4944).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csCaps)`, or replace it by `symbol(csCaps)`.
  syntax CSCaps ::= csCaps(Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int) [klabel(csCaps)]
```

## 10 Warning/Compiler/deprecated-klabel csLimits

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(19, 23, 19, 55); bytes[4944,5432).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csLimits)`, or replace it by `symbol(csLimits)`.
  syntax CSLimits ::= csLimits(Int) [klabel(csLimits)]
```

## 11 Warning/Compiler/deprecated-klabel csContext

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(20, 24, 20, 77); bytes[5432,5966).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csContext)`, or replace it by `symbol(csContext)`.
  syntax CSContext ::= csContext(CSCaps, Bool, CSLimits) [klabel(csContext)]
```

## 12 Warning/Compiler/deprecated-klabel csOwnedState

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(21, 27, 21, 96); bytes[5966,6544).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csOwnedState)`, or replace it by `symbol(csOwnedState)`.
  syntax CSOwnedState ::= csOwnedState(CTRoot, DPTables, CSHelperTables) [klabel(csOwnedState)]
```

## 13 Warning/Compiler/deprecated-klabel csNoStrings

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(22, 24, 22, 59); bytes[6544,7046).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoStrings)`, or replace it by `symbol(csNoStrings)`.
  syntax CSStrings ::= csNoStrings() [klabel(csNoStrings)]
```

## 14 Warning/Compiler/deprecated-klabel csString

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(23, 24, 23, 70); bytes[7046,7564).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csString)`, or replace it by `symbol(csString)`.
  syntax CSStrings ::= csString(String, CSStrings) [klabel(csString)]
```

## 15 Warning/Compiler/deprecated-klabel csCaseIds

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(24, 24, 24, 108); bytes[7564,8161).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csCaseIds)`, or replace it by `symbol(csCaseIds)`.
  syntax CSCaseIds ::= csCaseIds(CSStrings, CSStrings, CSStrings, CSStrings, CSStrings) [klabel(csCaseIds)]
```

## 16 Warning/Compiler/deprecated-klabel csHelperRecord

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(25, 29, 25, 93); bytes[8161,8737).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperRecord)`, or replace it by `symbol(csHelperRecord)`.
  syntax CSHelperRecord ::= csHelperRecord(CTLanes, CHHelperOption) [klabel(csHelperRecord)]
```

## 17 Warning/Compiler/deprecated-klabel csNoHelperRecords

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(26, 30, 26, 77); bytes[8737,9287).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoHelperRecords)`, or replace it by `symbol(csNoHelperRecords)`.
  syntax CSHelperRecords ::= csNoHelperRecords() [klabel(csNoHelperRecords)]
```

## 18 Warning/Compiler/deprecated-klabel csHelperRecordRow

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(27, 30, 27, 108); bytes[9287,9900).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperRecordRow)`, or replace it by `symbol(csHelperRecordRow)`.
  syntax CSHelperRecords ::= csHelperRecordRow(CSHelperRecord, CSHelperRecords) [klabel(csHelperRecordRow)]
```

## 19 Warning/Compiler/deprecated-klabel csResultRecord

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(28, 29, 28, 93); bytes[9900,10476).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csResultRecord)`, or replace it by `symbol(csResultRecord)`.
  syntax CSResultRecord ::= csResultRecord(CTLanes, CHResultOption) [klabel(csResultRecord)]
```

## 20 Warning/Compiler/deprecated-klabel csNoResultRecords

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(29, 30, 29, 77); bytes[10476,11026).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoResultRecords)`, or replace it by `symbol(csNoResultRecords)`.
  syntax CSResultRecords ::= csNoResultRecords() [klabel(csNoResultRecords)]
```

## 21 Warning/Compiler/deprecated-klabel csResultRecordRow

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(30, 30, 30, 108); bytes[11026,11639).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csResultRecordRow)`, or replace it by `symbol(csResultRecordRow)`.
  syntax CSResultRecords ::= csResultRecordRow(CSResultRecord, CSResultRecords) [klabel(csResultRecordRow)]
```

## 22 Warning/Compiler/deprecated-klabel csTaskRecord

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(31, 27, 31, 79); bytes[11639,12183).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csTaskRecord)`, or replace it by `symbol(csTaskRecord)`.
  syntax CSTaskRecord ::= csTaskRecord(CTLanes, CSTask) [klabel(csTaskRecord)]
```

## 23 Warning/Compiler/deprecated-klabel csNoTaskRecords

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(32, 28, 32, 71); bytes[12183,12717).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoTaskRecords)`, or replace it by `symbol(csNoTaskRecords)`.
  syntax CSTaskRecords ::= csNoTaskRecords() [klabel(csNoTaskRecords)]
```

## 24 Warning/Compiler/deprecated-klabel csTaskRecordRow

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(33, 28, 33, 98); bytes[12717,13305).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csTaskRecordRow)`, or replace it by `symbol(csTaskRecordRow)`.
  syntax CSTaskRecords ::= csTaskRecordRow(CSTaskRecord, CSTaskRecords) [klabel(csTaskRecordRow)]
```

## 25 Warning/Compiler/deprecated-klabel csTaskSpan

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(34, 25, 34, 85); bytes[13305,13857).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csTaskSpan)`, or replace it by `symbol(csTaskSpan)`.
  syntax CSTaskSpan ::= csTaskSpan(Int, Int, Int, Int, CTLanes) [klabel(csTaskSpan)]
```

## 26 Warning/Compiler/deprecated-klabel csNoTaskSpans

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(35, 26, 35, 65); bytes[13857,14375).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoTaskSpans)`, or replace it by `symbol(csNoTaskSpans)`.
  syntax CSTaskSpans ::= csNoTaskSpans() [klabel(csNoTaskSpans)]
```

## 27 Warning/Compiler/deprecated-klabel csTaskSpanRow

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(36, 26, 36, 88); bytes[14375,14939).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csTaskSpanRow)`, or replace it by `symbol(csTaskSpanRow)`.
  syntax CSTaskSpans ::= csTaskSpanRow(CSTaskSpan, CSTaskSpans) [klabel(csTaskSpanRow)]
```

## 28 Warning/Compiler/deprecated-klabel csHelperSection

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(37, 30, 37, 114); bytes[14939,15560).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperSection)`, or replace it by `symbol(csHelperSection)`.
  syntax CSHelperSection ::= csHelperSection(CTLanes, CSHelperTables, CSTaskSpans, Int) [klabel(csHelperSection)]
```

## 29 Warning/Compiler/deprecated-klabel csNoHelperSections

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(38, 31, 38, 80); bytes[15560,16118).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoHelperSections)`, or replace it by `symbol(csNoHelperSections)`.
  syntax CSHelperSections ::= csNoHelperSections() [klabel(csNoHelperSections)]
```

## 30 Warning/Compiler/deprecated-klabel csHelperSectionRow

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(39, 31, 39, 113); bytes[16118,16743).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperSectionRow)`, or replace it by `symbol(csHelperSectionRow)`.
  syntax CSHelperSections ::= csHelperSectionRow(CSHelperSection, CSHelperSections) [klabel(csHelperSectionRow)]
```

## 31 Warning/Compiler/deprecated-klabel csChildSection

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(40, 29, 40, 105); bytes[16743,17344).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csChildSection)`, or replace it by `symbol(csChildSection)`.
  syntax CSChildSection ::= csChildSection(String, Int, Int, Int, Int, CTLanes) [klabel(csChildSection)]
```

## 32 Warning/Compiler/deprecated-klabel csNoChildSections

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(41, 30, 41, 77); bytes[17344,17894).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoChildSections)`, or replace it by `symbol(csNoChildSections)`.
  syntax CSChildSections ::= csNoChildSections() [klabel(csNoChildSections)]
```

## 33 Warning/Compiler/deprecated-klabel csChildSectionRow

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(42, 30, 42, 108); bytes[17894,18507).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csChildSectionRow)`, or replace it by `symbol(csChildSectionRow)`.
  syntax CSChildSections ::= csChildSectionRow(CSChildSection, CSChildSections) [klabel(csChildSectionRow)]
```

## 34 Warning/Compiler/deprecated-klabel csStateObservation

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(43, 33, 43, 145); bytes[18507,19196).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csStateObservation)`, or replace it by `symbol(csStateObservation)`.
  syntax CSStateObservation ::= csStateObservation(CTLanes, CSOwnedState, CSContext, CTLanes, CSChildSections, Int) [klabel(csStateObservation)]
```

## 35 Warning/Compiler/deprecated-klabel csNoStateObservations

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(44, 34, 44, 89); bytes[19196,19778).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoStateObservations)`, or replace it by
`symbol(csNoStateObservations)`.
  syntax CSStateObservations ::= csNoStateObservations() [klabel(csNoStateObservations)]
```

## 36 Warning/Compiler/deprecated-klabel csStateObservationRow

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(45, 34, 45, 128); bytes[19778,20439).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csStateObservationRow)`, or replace it by
`symbol(csStateObservationRow)`.
  syntax CSStateObservations ::= csStateObservationRow(CSStateObservation, CSStateObservations) [klabel(csStateObservationRow)]
```

## 37 Warning/Compiler/deprecated-klabel csObservations

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-complete-helper-task-state-syntax.k Location(46, 29, 46, 183); bytes[20439,21196).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObservations)`, or replace it by `symbol(csObservations)`.
  syntax CSObservations ::= csObservations(String, String, CSCaseIds, CSHelperRecords, CSResultRecords, CSTaskRecords, CSHelperSections, CSStateObservations) [klabel(csObservations)]
```

## 38 Warning/Compiler/deprecated-klabel chSiteEvalLiteral

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(5, 21, 5, 68); bytes[21196,21704).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalLiteral)`, or replace it by `symbol(chSiteEvalLiteral)`.
  syntax CHSite ::= chSiteEvalLiteral() [klabel(chSiteEvalLiteral)]
```

## 39 Warning/Compiler/deprecated-klabel chSiteEvalVar

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(6, 21, 6, 60); bytes[21704,22188).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalVar)`, or replace it by `symbol(chSiteEvalVar)`.
  syntax CHSite ::= chSiteEvalVar() [klabel(chSiteEvalVar)]
```

## 40 Warning/Compiler/deprecated-klabel chSiteEvalLet

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(7, 21, 7, 60); bytes[22188,22672).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalLet)`, or replace it by `symbol(chSiteEvalLet)`.
  syntax CHSite ::= chSiteEvalLet() [klabel(chSiteEvalLet)]
```

## 41 Warning/Compiler/deprecated-klabel chSiteEvalBinary

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(8, 21, 8, 66); bytes[22672,23174).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalBinary)`, or replace it by `symbol(chSiteEvalBinary)`.
  syntax CHSite ::= chSiteEvalBinary() [klabel(chSiteEvalBinary)]
```

## 42 Warning/Compiler/deprecated-klabel chSiteEvalUnary

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(9, 21, 9, 64); bytes[23174,23670).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalUnary)`, or replace it by `symbol(chSiteEvalUnary)`.
  syntax CHSite ::= chSiteEvalUnary() [klabel(chSiteEvalUnary)]
```

## 43 Warning/Compiler/deprecated-klabel chSiteEvalIf

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(10, 21, 10, 58); bytes[23670,24152).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalIf)`, or replace it by `symbol(chSiteEvalIf)`.
  syntax CHSite ::= chSiteEvalIf() [klabel(chSiteEvalIf)]
```

## 44 Warning/Compiler/deprecated-klabel chSiteEvalMatch

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(11, 21, 11, 64); bytes[24152,24652).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalMatch)`, or replace it by `symbol(chSiteEvalMatch)`.
  syntax CHSite ::= chSiteEvalMatch() [klabel(chSiteEvalMatch)]
```

## 45 Warning/Compiler/deprecated-klabel chSiteEvalCall

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(12, 21, 12, 62); bytes[24652,25146).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalCall)`, or replace it by `symbol(chSiteEvalCall)`.
  syntax CHSite ::= chSiteEvalCall() [klabel(chSiteEvalCall)]
```

## 46 Warning/Compiler/deprecated-klabel chSitePush

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(13, 21, 13, 54); bytes[25146,25616).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSitePush)`, or replace it by `symbol(chSitePush)`.
  syntax CHSite ::= chSitePush() [klabel(chSitePush)]
```

## 47 Warning/Compiler/deprecated-klabel chSiteRetLet

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(14, 21, 14, 58); bytes[25616,26098).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetLet)`, or replace it by `symbol(chSiteRetLet)`.
  syntax CHSite ::= chSiteRetLet() [klabel(chSiteRetLet)]
```

## 48 Warning/Compiler/deprecated-klabel chSiteRetLeft

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(15, 21, 15, 60); bytes[26098,26586).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetLeft)`, or replace it by `symbol(chSiteRetLeft)`.
  syntax CHSite ::= chSiteRetLeft() [klabel(chSiteRetLeft)]
```

## 49 Warning/Compiler/deprecated-klabel chSiteRetRight

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(16, 21, 16, 62); bytes[26586,27080).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetRight)`, or replace it by `symbol(chSiteRetRight)`.
  syntax CHSite ::= chSiteRetRight() [klabel(chSiteRetRight)]
```

## 50 Warning/Compiler/deprecated-klabel chSiteRetUnary

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(17, 21, 17, 62); bytes[27080,27574).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetUnary)`, or replace it by `symbol(chSiteRetUnary)`.
  syntax CHSite ::= chSiteRetUnary() [klabel(chSiteRetUnary)]
```

## 51 Warning/Compiler/deprecated-klabel chSiteRetIf

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(18, 21, 18, 56); bytes[27574,28050).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetIf)`, or replace it by `symbol(chSiteRetIf)`.
  syntax CHSite ::= chSiteRetIf() [klabel(chSiteRetIf)]
```

## 52 Warning/Compiler/deprecated-klabel chSiteRetMatch

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(19, 21, 19, 62); bytes[28050,28544).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetMatch)`, or replace it by `symbol(chSiteRetMatch)`.
  syntax CHSite ::= chSiteRetMatch() [klabel(chSiteRetMatch)]
```

## 53 Warning/Compiler/deprecated-klabel chSiteRetArgs

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(20, 21, 20, 60); bytes[28544,29032).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetArgs)`, or replace it by `symbol(chSiteRetArgs)`.
  syntax CHSite ::= chSiteRetArgs() [klabel(chSiteRetArgs)]
```

## 54 Warning/Compiler/deprecated-klabel chSiteRetCall

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(21, 21, 21, 60); bytes[29032,29520).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetCall)`, or replace it by `symbol(chSiteRetCall)`.
  syntax CHSite ::= chSiteRetCall() [klabel(chSiteRetCall)]
```

## 55 Warning/Compiler/deprecated-klabel chSiteRetScope

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(22, 21, 22, 62); bytes[29520,30014).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetScope)`, or replace it by `symbol(chSiteRetScope)`.
  syntax CHSite ::= chSiteRetScope() [klabel(chSiteRetScope)]
```

## 56 Warning/Compiler/deprecated-klabel chSiteInvoke

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(23, 21, 23, 58); bytes[30014,30496).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteInvoke)`, or replace it by `symbol(chSiteInvoke)`.
  syntax CHSite ::= chSiteInvoke() [klabel(chSiteInvoke)]
```

## 57 Warning/Compiler/deprecated-klabel chSiteEnter

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(24, 21, 24, 56); bytes[30496,30972).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEnter)`, or replace it by `symbol(chSiteEnter)`.
  syntax CHSite ::= chSiteEnter() [klabel(chSiteEnter)]
```

## 58 Warning/Compiler/deprecated-klabel chSiteBound

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(25, 21, 25, 56); bytes[30972,31448).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteBound)`, or replace it by `symbol(chSiteBound)`.
  syntax CHSite ::= chSiteBound() [klabel(chSiteBound)]
```

## 59 Warning/Compiler/deprecated-klabel chSiteCases

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(26, 21, 26, 56); bytes[31448,31924).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteCases)`, or replace it by `symbol(chSiteCases)`.
  syntax CHSite ::= chSiteCases() [klabel(chSiteCases)]
```

## 60 Warning/Compiler/deprecated-klabel chSiteCaseResult

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(27, 21, 27, 66); bytes[31924,32430).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteCaseResult)`, or replace it by `symbol(chSiteCaseResult)`.
  syntax CHSite ::= chSiteCaseResult() [klabel(chSiteCaseResult)]
```

## 61 Warning/Compiler/deprecated-klabel chSitePrim

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(28, 21, 28, 54); bytes[32430,32900).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSitePrim)`, or replace it by `symbol(chSitePrim)`.
  syntax CHSite ::= chSitePrim() [klabel(chSitePrim)]
```

## 62 Warning/Compiler/deprecated-klabel chSiteEvalConstruct

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(29, 21, 29, 72); bytes[32900,33424).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalConstruct)`, or replace it by `symbol(chSiteEvalConstruct)`.
  syntax CHSite ::= chSiteEvalConstruct() [klabel(chSiteEvalConstruct)]
```

## 63 Warning/Compiler/deprecated-klabel chSiteRetCtorFields

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(30, 21, 30, 72); bytes[33424,33948).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetCtorFields)`, or replace it by `symbol(chSiteRetCtorFields)`.
  syntax CHSite ::= chSiteRetCtorFields() [klabel(chSiteRetCtorFields)]
```

## 64 Warning/Compiler/deprecated-klabel chSiteMaterialize

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(31, 21, 31, 68); bytes[33948,34460).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteMaterialize)`, or replace it by `symbol(chSiteMaterialize)`.
  syntax CHSite ::= chSiteMaterialize() [klabel(chSiteMaterialize)]
```

## 65 Warning/Compiler/deprecated-klabel chModeAdd

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(32, 21, 32, 52); bytes[34460,34924).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeAdd)`, or replace it by `symbol(chModeAdd)`.
  syntax CHMode ::= chModeAdd() [klabel(chModeAdd)]
```

## 66 Warning/Compiler/deprecated-klabel chModeSub

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(33, 21, 33, 52); bytes[34924,35388).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeSub)`, or replace it by `symbol(chModeSub)`.
  syntax CHMode ::= chModeSub() [klabel(chModeSub)]
```

## 67 Warning/Compiler/deprecated-klabel chModeMul

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(34, 21, 34, 52); bytes[35388,35852).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeMul)`, or replace it by `symbol(chModeMul)`.
  syntax CHMode ::= chModeMul() [klabel(chModeMul)]
```

## 68 Warning/Compiler/deprecated-klabel chModeLt

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(35, 21, 35, 50); bytes[35852,36310).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeLt)`, or replace it by `symbol(chModeLt)`.
  syntax CHMode ::= chModeLt() [klabel(chModeLt)]
```

## 69 Warning/Compiler/deprecated-klabel chModeCons

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(36, 21, 36, 54); bytes[36310,36780).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeCons)`, or replace it by `symbol(chModeCons)`.
  syntax CHMode ::= chModeCons() [klabel(chModeCons)]
```

## 70 Warning/Compiler/deprecated-klabel chModeBranch

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(37, 21, 37, 58); bytes[36780,37262).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeBranch)`, or replace it by `symbol(chModeBranch)`.
  syntax CHMode ::= chModeBranch() [klabel(chModeBranch)]
```

## 71 Warning/Compiler/deprecated-klabel chModeLeaf

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(38, 21, 38, 54); bytes[37262,37732).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeLeaf)`, or replace it by `symbol(chModeLeaf)`.
  syntax CHMode ::= chModeLeaf() [klabel(chModeLeaf)]
```

## 72 Warning/Compiler/deprecated-klabel chModeNot

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(39, 21, 39, 52); bytes[37732,38196).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeNot)`, or replace it by `symbol(chModeNot)`.
  syntax CHMode ::= chModeNot() [klabel(chModeNot)]
```

## 73 Warning/Compiler/deprecated-klabel chModeTestBool

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(40, 21, 40, 62); bytes[38196,38690).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeTestBool)`, or replace it by `symbol(chModeTestBool)`.
  syntax CHMode ::= chModeTestBool() [klabel(chModeTestBool)]
```

## 74 Warning/Compiler/deprecated-klabel chModeTestType

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(41, 21, 41, 62); bytes[38690,39184).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeTestType)`, or replace it by `symbol(chModeTestType)`.
  syntax CHMode ::= chModeTestType() [klabel(chModeTestType)]
```

## 75 Warning/Compiler/deprecated-klabel chScalarPhaseFirst

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(42, 28, 42, 77); bytes[39184,39716).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chScalarPhaseFirst)`, or replace it by `symbol(chScalarPhaseFirst)`.
  syntax CHScalarPhase ::= chScalarPhaseFirst() [klabel(chScalarPhaseFirst)]
```

## 76 Warning/Compiler/deprecated-klabel chScalarPhaseSecond

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(43, 28, 43, 79); bytes[39716,40254).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chScalarPhaseSecond)`, or replace it by `symbol(chScalarPhaseSecond)`.
  syntax CHScalarPhase ::= chScalarPhaseSecond() [klabel(chScalarPhaseSecond)]
```

## 77 Warning/Compiler/deprecated-klabel chScalarPhaseDone

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(44, 28, 44, 75); bytes[40254,40780).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chScalarPhaseDone)`, or replace it by `symbol(chScalarPhaseDone)`.
  syntax CHScalarPhase ::= chScalarPhaseDone() [klabel(chScalarPhaseDone)]
```

## 78 Warning/Compiler/deprecated-klabel chNodeCons

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(45, 21, 45, 54); bytes[40780,41250).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chNodeCons)`, or replace it by `symbol(chNodeCons)`.
  syntax CHNode ::= chNodeCons() [klabel(chNodeCons)]
```

## 79 Warning/Compiler/deprecated-klabel chNodeLeaf

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(46, 21, 46, 54); bytes[41250,41720).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chNodeLeaf)`, or replace it by `symbol(chNodeLeaf)`.
  syntax CHNode ::= chNodeLeaf() [klabel(chNodeLeaf)]
```

## 80 Warning/Compiler/deprecated-klabel chNodeBranch

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(47, 21, 47, 58); bytes[41720,42202).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chNodeBranch)`, or replace it by `symbol(chNodeBranch)`.
  syntax CHNode ::= chNodeBranch() [klabel(chNodeBranch)]
```

## 81 Warning/Compiler/deprecated-klabel chSelectorTrue

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(48, 25, 48, 66); bytes[42202,42704).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSelectorTrue)`, or replace it by `symbol(chSelectorTrue)`.
  syntax CHSelector ::= chSelectorTrue() [klabel(chSelectorTrue)]
```

## 82 Warning/Compiler/deprecated-klabel chSelectorFalse

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(49, 25, 49, 68); bytes[42704,43212).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSelectorFalse)`, or replace it by `symbol(chSelectorFalse)`.
  syntax CHSelector ::= chSelectorFalse() [klabel(chSelectorFalse)]
```

## 83 Warning/Compiler/deprecated-klabel chSelectorNotBool

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(50, 25, 50, 72); bytes[43212,43732).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSelectorNotBool)`, or replace it by `symbol(chSelectorNotBool)`.
  syntax CHSelector ::= chSelectorNotBool() [klabel(chSelectorNotBool)]
```

## 84 Warning/Compiler/deprecated-klabel chTriPending

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(51, 20, 51, 57); bytes[43732,44212).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chTriPending)`, or replace it by `symbol(chTriPending)`.
  syntax CHTri ::= chTriPending() [klabel(chTriPending)]
```

## 85 Warning/Compiler/deprecated-klabel chTriPositive

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(52, 20, 52, 59); bytes[44212,44698).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chTriPositive)`, or replace it by `symbol(chTriPositive)`.
  syntax CHTri ::= chTriPositive() [klabel(chTriPositive)]
```

## 86 Warning/Compiler/deprecated-klabel chTriNegative

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(53, 20, 53, 59); bytes[44698,45184).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chTriNegative)`, or replace it by `symbol(chTriNegative)`.
  syntax CHTri ::= chTriNegative() [klabel(chTriNegative)]
```

## 87 Warning/Compiler/deprecated-klabel chBindPhasePairing

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(54, 26, 54, 75); bytes[45184,45712).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindPhasePairing)`, or replace it by `symbol(chBindPhasePairing)`.
  syntax CHBindPhase ::= chBindPhasePairing() [klabel(chBindPhasePairing)]
```

## 88 Warning/Compiler/deprecated-klabel chBindPhaseUnwindType

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(55, 26, 55, 81); bytes[45712,46258).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindPhaseUnwindType)`, or replace it by
`symbol(chBindPhaseUnwindType)`.
  syntax CHBindPhase ::= chBindPhaseUnwindType() [klabel(chBindPhaseUnwindType)]
```

## 89 Warning/Compiler/deprecated-klabel chBindPhaseUnwindDup

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(56, 26, 56, 79); bytes[46258,46798).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindPhaseUnwindDup)`, or replace it by
`symbol(chBindPhaseUnwindDup)`.
  syntax CHBindPhase ::= chBindPhaseUnwindDup() [klabel(chBindPhaseUnwindDup)]
```

## 90 Warning/Compiler/deprecated-klabel chBindPhaseUnwindInsert

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(57, 26, 57, 85); bytes[46798,47356).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindPhaseUnwindInsert)`, or replace it by
`symbol(chBindPhaseUnwindInsert)`.
  syntax CHBindPhase ::= chBindPhaseUnwindInsert() [klabel(chBindPhaseUnwindInsert)]
```

## 91 Warning/Compiler/deprecated-klabel chBindPhasePropagate

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(58, 26, 58, 79); bytes[47356,47896).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindPhasePropagate)`, or replace it by
`symbol(chBindPhasePropagate)`.
  syntax CHBindPhase ::= chBindPhasePropagate() [klabel(chBindPhasePropagate)]
```

## 92 Warning/Compiler/deprecated-klabel chBindPhaseFinished

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(59, 26, 59, 77); bytes[47896,48430).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindPhaseFinished)`, or replace it by `symbol(chBindPhaseFinished)`.
  syntax CHBindPhase ::= chBindPhaseFinished() [klabel(chBindPhaseFinished)]
```

## 93 Warning/Compiler/deprecated-klabel chBindStatusOk

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(60, 27, 60, 68); bytes[48430,48936).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindStatusOk)`, or replace it by `symbol(chBindStatusOk)`.
  syntax CHBindStatus ::= chBindStatusOk() [klabel(chBindStatusOk)]
```

## 94 Warning/Compiler/deprecated-klabel chBindStatusBad

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(61, 27, 61, 70); bytes[48936,49448).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindStatusBad)`, or replace it by `symbol(chBindStatusBad)`.
  syntax CHBindStatus ::= chBindStatusBad() [klabel(chBindStatusBad)]
```

## 95 Warning/Compiler/deprecated-klabel chAppendPhaseCopy

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(62, 28, 62, 75); bytes[49448,49974).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chAppendPhaseCopy)`, or replace it by `symbol(chAppendPhaseCopy)`.
  syntax CHAppendPhase ::= chAppendPhaseCopy() [klabel(chAppendPhaseCopy)]
```

## 96 Warning/Compiler/deprecated-klabel chAppendPhaseTail

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(63, 28, 63, 75); bytes[49974,50500).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chAppendPhaseTail)`, or replace it by `symbol(chAppendPhaseTail)`.
  syntax CHAppendPhase ::= chAppendPhaseTail() [klabel(chAppendPhaseTail)]
```

## 97 Warning/Compiler/deprecated-klabel chAppendPhaseDone

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(64, 28, 64, 75); bytes[50500,51026).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chAppendPhaseDone)`, or replace it by `symbol(chAppendPhaseDone)`.
  syntax CHAppendPhase ::= chAppendPhaseDone() [klabel(chAppendPhaseDone)]
```

## 98 Warning/Compiler/deprecated-klabel chMatchPhaseArm

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(65, 27, 65, 70); bytes[51026,51538).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseArm)`, or replace it by `symbol(chMatchPhaseArm)`.
  syntax CHMatchPhase ::= chMatchPhaseArm() [klabel(chMatchPhaseArm)]
```

## 99 Warning/Compiler/deprecated-klabel chMatchPhaseTag

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(66, 27, 66, 70); bytes[51538,52050).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseTag)`, or replace it by `symbol(chMatchPhaseTag)`.
  syntax CHMatchPhase ::= chMatchPhaseTag() [klabel(chMatchPhaseTag)]
```

## 100 Warning/Compiler/deprecated-klabel chMatchPhaseDistinct

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(67, 27, 67, 80); bytes[52050,52592).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseDistinct)`, or replace it by
`symbol(chMatchPhaseDistinct)`.
  syntax CHMatchPhase ::= chMatchPhaseDistinct() [klabel(chMatchPhaseDistinct)]
```

## 101 Warning/Compiler/deprecated-klabel chMatchPhaseField

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(68, 27, 68, 74); bytes[52592,53116).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseField)`, or replace it by `symbol(chMatchPhaseField)`.
  syntax CHMatchPhase ::= chMatchPhaseField() [klabel(chMatchPhaseField)]
```

## 102 Warning/Compiler/deprecated-klabel chMatchPhaseBind

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(69, 27, 69, 72); bytes[53116,53634).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseBind)`, or replace it by `symbol(chMatchPhaseBind)`.
  syntax CHMatchPhase ::= chMatchPhaseBind() [klabel(chMatchPhaseBind)]
```

## 103 Warning/Compiler/deprecated-klabel chMatchPhaseReady

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(70, 27, 70, 74); bytes[53634,54158).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseReady)`, or replace it by `symbol(chMatchPhaseReady)`.
  syntax CHMatchPhase ::= chMatchPhaseReady() [klabel(chMatchPhaseReady)]
```

## 104 Warning/Compiler/deprecated-klabel chMatchPhaseNoMatchReady

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(71, 27, 71, 88); bytes[54158,54724).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseNoMatchReady)`, or replace it by
`symbol(chMatchPhaseNoMatchReady)`.
  syntax CHMatchPhase ::= chMatchPhaseNoMatchReady() [klabel(chMatchPhaseNoMatchReady)]
```

## 105 Warning/Compiler/deprecated-klabel chMatchPhaseDone

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(72, 27, 72, 72); bytes[54724,55242).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseDone)`, or replace it by `symbol(chMatchPhaseDone)`.
  syntax CHMatchPhase ::= chMatchPhaseDone() [klabel(chMatchPhaseDone)]
```

## 106 Warning/Compiler/deprecated-klabel chPlanPhaseWalk

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(73, 26, 73, 69); bytes[55242,55752).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPlanPhaseWalk)`, or replace it by `symbol(chPlanPhaseWalk)`.
  syntax CHPlanPhase ::= chPlanPhaseWalk() [klabel(chPlanPhaseWalk)]
```

## 107 Warning/Compiler/deprecated-klabel chPlanPhaseTest

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(74, 26, 74, 69); bytes[55752,56262).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPlanPhaseTest)`, or replace it by `symbol(chPlanPhaseTest)`.
  syntax CHPlanPhase ::= chPlanPhaseTest() [klabel(chPlanPhaseTest)]
```

## 108 Warning/Compiler/deprecated-klabel chPlanPhaseBind

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(75, 26, 75, 69); bytes[56262,56772).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPlanPhaseBind)`, or replace it by `symbol(chPlanPhaseBind)`.
  syntax CHPlanPhase ::= chPlanPhaseBind() [klabel(chPlanPhaseBind)]
```

## 109 Warning/Compiler/deprecated-klabel chPlanPhaseReady

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(76, 26, 76, 71); bytes[56772,57288).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPlanPhaseReady)`, or replace it by `symbol(chPlanPhaseReady)`.
  syntax CHPlanPhase ::= chPlanPhaseReady() [klabel(chPlanPhaseReady)]
```

## 110 Warning/Compiler/deprecated-klabel chPlanPhaseNoMatchReady

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(77, 26, 77, 85); bytes[57288,57846).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPlanPhaseNoMatchReady)`, or replace it by
`symbol(chPlanPhaseNoMatchReady)`.
  syntax CHPlanPhase ::= chPlanPhaseNoMatchReady() [klabel(chPlanPhaseNoMatchReady)]
```

## 111 Warning/Compiler/deprecated-klabel chPlanPhaseDone

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(78, 26, 78, 69); bytes[57846,58356).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPlanPhaseDone)`, or replace it by `symbol(chPlanPhaseDone)`.
  syntax CHPlanPhase ::= chPlanPhaseDone() [klabel(chPlanPhaseDone)]
```

## 112 Warning/Compiler/deprecated-klabel chAfterWalkTest

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(79, 26, 79, 69); bytes[58356,58866).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chAfterWalkTest)`, or replace it by `symbol(chAfterWalkTest)`.
  syntax CHAfterWalk ::= chAfterWalkTest() [klabel(chAfterWalkTest)]
```

## 113 Warning/Compiler/deprecated-klabel chAfterWalkBind

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(80, 26, 80, 69); bytes[58866,59376).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chAfterWalkBind)`, or replace it by `symbol(chAfterWalkBind)`.
  syntax CHAfterWalk ::= chAfterWalkBind() [klabel(chAfterWalkBind)]
```

## 114 Warning/Compiler/deprecated-klabel chBuildPhaseCopy

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(81, 27, 81, 72); bytes[59376,59894).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBuildPhaseCopy)`, or replace it by `symbol(chBuildPhaseCopy)`.
  syntax CHBuildPhase ::= chBuildPhaseCopy() [klabel(chBuildPhaseCopy)]
```

## 115 Warning/Compiler/deprecated-klabel chBuildPhaseDone

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(82, 27, 82, 72); bytes[59894,60412).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBuildPhaseDone)`, or replace it by `symbol(chBuildPhaseDone)`.
  syntax CHBuildPhase ::= chBuildPhaseDone() [klabel(chBuildPhaseDone)]
```

## 116 Warning/Compiler/deprecated-klabel chPatternPVar

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(83, 24, 83, 63); bytes[60412,60906).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPatternPVar)`, or replace it by `symbol(chPatternPVar)`.
  syntax CHPattern ::= chPatternPVar() [klabel(chPatternPVar)]
```

## 117 Warning/Compiler/deprecated-klabel chPatternPNil

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(84, 24, 84, 63); bytes[60906,61400).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPatternPNil)`, or replace it by `symbol(chPatternPNil)`.
  syntax CHPattern ::= chPatternPNil() [klabel(chPatternPNil)]
```

## 118 Warning/Compiler/deprecated-klabel chPatternPCons

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(85, 24, 85, 65); bytes[61400,61900).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPatternPCons)`, or replace it by `symbol(chPatternPCons)`.
  syntax CHPattern ::= chPatternPCons() [klabel(chPatternPCons)]
```

## 119 Warning/Compiler/deprecated-klabel chPatternPLeaf

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(86, 24, 86, 65); bytes[61900,62400).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPatternPLeaf)`, or replace it by `symbol(chPatternPLeaf)`.
  syntax CHPattern ::= chPatternPLeaf() [klabel(chPatternPLeaf)]
```

## 120 Warning/Compiler/deprecated-klabel chPatternPBranch

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(87, 24, 87, 69); bytes[62400,62912).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPatternPBranch)`, or replace it by `symbol(chPatternPBranch)`.
  syntax CHPattern ::= chPatternPBranch() [klabel(chPatternPBranch)]
```

## 121 Warning/Compiler/deprecated-klabel chPatternWildcardExtensionReserved

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(88, 24, 88, 105); bytes[62912,63533).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPatternWildcardExtensionReserved)`, or replace it by
`symbol(chPatternWildcardExtensionReserved)`.
  syntax CHPattern ::= chPatternWildcardExtensionReserved() [klabel(chPatternWildcardExtensionReserved)]
```

## 122 Warning/Compiler/deprecated-klabel chPatternConstructorExtensionReserved

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(89, 24, 89, 111); bytes[63533,64172).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPatternConstructorExtensionReserved)`, or replace it by
`symbol(chPatternConstructorExtensionReserved)`.
  syntax CHPattern ::= chPatternConstructorExtensionReserved() [klabel(chPatternConstructorExtensionReserved)]
```

## 123 Warning/Compiler/deprecated-klabel chIndexNone

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(90, 22, 90, 57); bytes[64172,64650).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chIndexNone)`, or replace it by `symbol(chIndexNone)`.
  syntax CHIndex ::= chIndexNone() [klabel(chIndexNone)]
```

## 124 Warning/Compiler/deprecated-klabel chIndexSome

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(91, 22, 91, 60); bytes[64650,65134).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chIndexSome)`, or replace it by `symbol(chIndexSome)`.
  syntax CHIndex ::= chIndexSome(Int) [klabel(chIndexSome)]
```

## 125 Warning/Compiler/deprecated-klabel chResumeNone

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(92, 23, 92, 60); bytes[65134,65620).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResumeNone)`, or replace it by `symbol(chResumeNone)`.
  syntax CHResume ::= chResumeNone() [klabel(chResumeNone)]
```

## 126 Warning/Compiler/deprecated-klabel chResumeSome

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(93, 23, 93, 63); bytes[65620,66112).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResumeSome)`, or replace it by `symbol(chResumeSome)`.
  syntax CHResume ::= chResumeSome(Int) [klabel(chResumeSome)]
```

## 127 Warning/Compiler/deprecated-klabel chTypeNone

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(94, 21, 94, 54); bytes[66112,66582).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chTypeNone)`, or replace it by `symbol(chTypeNone)`.
  syntax CHType ::= chTypeNone() [klabel(chTypeNone)]
```

## 128 Warning/Compiler/deprecated-klabel chTypeSome

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(95, 21, 95, 57); bytes[66582,67058).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chTypeSome)`, or replace it by `symbol(chTypeSome)`.
  syntax CHType ::= chTypeSome(Int) [klabel(chTypeSome)]
```

## 129 Warning/Compiler/deprecated-klabel chRefNone

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(96, 23, 96, 54); bytes[67058,67526).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chRefNone)`, or replace it by `symbol(chRefNone)`.
  syntax CHOptRef ::= chRefNone() [klabel(chRefNone)]
```

## 130 Warning/Compiler/deprecated-klabel chRefSome

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(97, 23, 97, 59); bytes[67526,68004).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chRefSome)`, or replace it by `symbol(chRefSome)`.
  syntax CHOptRef ::= chRefSome(CTRef) [klabel(chRefSome)]
```

## 131 Warning/Compiler/deprecated-klabel chCommon

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(98, 23, 98, 73); bytes[68004,68508).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chCommon)`, or replace it by `symbol(chCommon)`.
  syntax CHCommon ::= chCommon(CHSite, Int, CHResume) [klabel(chCommon)]
```

## 132 Warning/Compiler/deprecated-klabel chStagedNone

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(99, 23, 99, 60); bytes[68508,68994).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedNone)`, or replace it by `symbol(chStagedNone)`.
  syntax CHStaged ::= chStagedNone() [klabel(chStagedNone)]
```

## 133 Warning/Compiler/deprecated-klabel chStagedU128Value

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(100, 23, 100, 73); bytes[68994,69520).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedU128Value)`, or replace it by `symbol(chStagedU128Value)`.
  syntax CHStaged ::= chStagedU128Value(Int) [klabel(chStagedU128Value)]
```

## 134 Warning/Compiler/deprecated-klabel chStagedBoolValue

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(101, 23, 101, 74); bytes[69520,70048).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedBoolValue)`, or replace it by `symbol(chStagedBoolValue)`.
  syntax CHStaged ::= chStagedBoolValue(Bool) [klabel(chStagedBoolValue)]
```

## 135 Warning/Compiler/deprecated-klabel chStagedPendingNode

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(102, 23, 102, 80); bytes[70048,70592).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedPendingNode)`, or replace it by `symbol(chStagedPendingNode)`.
  syntax CHStaged ::= chStagedPendingNode(CHNode) [klabel(chStagedPendingNode)]
```

## 136 Warning/Compiler/deprecated-klabel chStagedPrimError

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(103, 23, 103, 73); bytes[70592,71118).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedPrimError)`, or replace it by `symbol(chStagedPrimError)`.
  syntax CHStaged ::= chStagedPrimError(Int) [klabel(chStagedPrimError)]
```

## 137 Warning/Compiler/deprecated-klabel chStagedSelector

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(104, 23, 104, 78); bytes[71118,71652).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedSelector)`, or replace it by `symbol(chStagedSelector)`.
  syntax CHStaged ::= chStagedSelector(CHSelector) [klabel(chStagedSelector)]
```

## 138 Warning/Compiler/deprecated-klabel chStagedTypeTest

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(105, 23, 105, 72); bytes[71652,72174).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedTypeTest)`, or replace it by `symbol(chStagedTypeTest)`.
  syntax CHStaged ::= chStagedTypeTest(Bool) [klabel(chStagedTypeTest)]
```

## 139 Warning/Compiler/deprecated-klabel chScalar

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(106, 23, 106, 123); bytes[72174,72783).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chScalar)`, or replace it by `symbol(chScalar)`.
  syntax CHHelper ::= chScalar(CHCommon, CHMode, CTRef, CHOptRef, CHType, CHScalarPhase, Int, CHStaged) [klabel(chScalar)]
```

## 140 Warning/Compiler/deprecated-klabel chEnvGet

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(107, 23, 107, 91); bytes[72783,73327).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chEnvGet)`, or replace it by `symbol(chEnvGet)`.
  syntax CHHelper ::= chEnvGet(CHCommon, Int, CHIndex, CHOptRef, CHTri) [klabel(chEnvGet)]
```

## 141 Warning/Compiler/deprecated-klabel chEnvPut

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(108, 23, 108, 95); bytes[73327,73879).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chEnvPut)`, or replace it by `symbol(chEnvPut)`.
  syntax CHHelper ::= chEnvPut(CHCommon, Int, CTRef, CTEnv, CHIndex, CHTri) [klabel(chEnvPut)]
```

## 142 Warning/Compiler/deprecated-klabel chFind

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(109, 23, 109, 82); bytes[73879,74401).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chFind)`, or replace it by `symbol(chFind)`.
  syntax CHHelper ::= chFind(CHCommon, Int, Int, CHIndex, CHTri) [klabel(chFind)]
```

## 143 Warning/Compiler/deprecated-klabel chBind

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(110, 23, 110, 132); bytes[74401,75024).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBind)`, or replace it by `symbol(chBind)`.
  syntax CHHelper ::= chBind(CHCommon, Int, CTSlice, CTSlice, Int, Int, CTEnv, CHIndex, CHBindPhase, CHBindStatus) [klabel(chBind)]
```

## 144 Warning/Compiler/deprecated-klabel chAppend

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(111, 23, 111, 111); bytes[75024,75609).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chAppend)`, or replace it by `symbol(chAppend)`.
  syntax CHHelper ::= chAppend(CHCommon, CTSlice, CTRef, Int, Int, CHOptRef, CHAppendPhase) [klabel(chAppend)]
```

## 145 Warning/Compiler/deprecated-klabel chValidate

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(112, 23, 112, 78); bytes[75609,76131).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chValidate)`, or replace it by `symbol(chValidate)`.
  syntax CHHelper ::= chValidate(CHCommon, CTRef, CHTri) [klabel(chValidate)]
```

## 146 Warning/Compiler/deprecated-klabel chEqual

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(113, 23, 113, 79); bytes[76131,76649).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chEqual)`, or replace it by `symbol(chEqual)`.
  syntax CHHelper ::= chEqual(CHCommon, CTRef, CTRef, CHTri) [klabel(chEqual)]
```

## 147 Warning/Compiler/deprecated-klabel chMatch

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(114, 23, 114, 141); bytes[76649,77292).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatch)`, or replace it by `symbol(chMatch)`.
  syntax CHHelper ::= chMatch(CHCommon, CTRef, Int, CTEnv, CTEnv, CHPattern, Int, Int, Int, CHOptRef, CHMatchPhase, CHTri) [klabel(chMatch)]
```

## 148 Warning/Compiler/deprecated-klabel chPlan

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(115, 23, 115, 150); bytes[77292,77951).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPlan)`, or replace it by `symbol(chPlan)`.
  syntax CHHelper ::= chPlan(CHCommon, Int, CTRef, CTEnv, CTEnv, Int, CHPlanPhase, CHAfterWalk, CTRef, CTSlice, Int, CHIndex, CHTri) [klabel(chPlan)]
```

## 149 Warning/Compiler/deprecated-klabel chBuild

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(116, 23, 116, 121); bytes[77951,78554).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBuild)`, or replace it by `symbol(chBuild)`.
  syntax CHHelper ::= chBuild(CHCommon, Int, Int, CTSlice, Int, Int, CHOptRef, CHOptRef, CHBuildPhase) [klabel(chBuild)]
```

## 150 Warning/Compiler/deprecated-klabel chResultValidated

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(117, 23, 117, 74); bytes[78554,79082).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultValidated)`, or replace it by `symbol(chResultValidated)`.
  syntax CHResult ::= chResultValidated(Bool) [klabel(chResultValidated)]
```

## 151 Warning/Compiler/deprecated-klabel chResultEnvFound

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(118, 23, 118, 73); bytes[79082,79606).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultEnvFound)`, or replace it by `symbol(chResultEnvFound)`.
  syntax CHResult ::= chResultEnvFound(CTRef) [klabel(chResultEnvFound)]
```

## 152 Warning/Compiler/deprecated-klabel chResultEnvMissing

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(119, 23, 119, 72); bytes[79606,80132).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultEnvMissing)`, or replace it by `symbol(chResultEnvMissing)`.
  syntax CHResult ::= chResultEnvMissing() [klabel(chResultEnvMissing)]
```

## 153 Warning/Compiler/deprecated-klabel chResultEnvUpdated

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(120, 23, 120, 75); bytes[80132,80664).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultEnvUpdated)`, or replace it by `symbol(chResultEnvUpdated)`.
  syntax CHResult ::= chResultEnvUpdated(Int) [klabel(chResultEnvUpdated)]
```

## 154 Warning/Compiler/deprecated-klabel chResultFindFound

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(121, 23, 121, 73); bytes[80664,81190).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultFindFound)`, or replace it by `symbol(chResultFindFound)`.
  syntax CHResult ::= chResultFindFound(Int) [klabel(chResultFindFound)]
```

## 155 Warning/Compiler/deprecated-klabel chResultFindMissing

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(122, 23, 122, 74); bytes[81190,81722).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultFindMissing)`, or replace it by `symbol(chResultFindMissing)`.
  syntax CHResult ::= chResultFindMissing() [klabel(chResultFindMissing)]
```

## 156 Warning/Compiler/deprecated-klabel chResultBindOk

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(123, 23, 123, 69); bytes[81722,82234).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultBindOk)`, or replace it by `symbol(chResultBindOk)`.
  syntax CHResult ::= chResultBindOk(CTEnv) [klabel(chResultBindOk)]
```

## 157 Warning/Compiler/deprecated-klabel chResultBindBad

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(124, 23, 124, 66); bytes[82234,82742).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultBindBad)`, or replace it by `symbol(chResultBindBad)`.
  syntax CHResult ::= chResultBindBad() [klabel(chResultBindBad)]
```

## 158 Warning/Compiler/deprecated-klabel chResultAppendDone

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(125, 23, 125, 79); bytes[82742,83282).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultAppendDone)`, or replace it by `symbol(chResultAppendDone)`.
  syntax CHResult ::= chResultAppendDone(CTSlice) [klabel(chResultAppendDone)]
```

## 159 Warning/Compiler/deprecated-klabel chResultScalarValue

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(126, 23, 126, 79); bytes[83282,83824).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultScalarValue)`, or replace it by `symbol(chResultScalarValue)`.
  syntax CHResult ::= chResultScalarValue(CTRef) [klabel(chResultScalarValue)]
```

## 160 Warning/Compiler/deprecated-klabel chResultScalarError

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(127, 23, 127, 77); bytes[83824,84362).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultScalarError)`, or replace it by `symbol(chResultScalarError)`.
  syntax CHResult ::= chResultScalarError(Int) [klabel(chResultScalarError)]
```

## 161 Warning/Compiler/deprecated-klabel chResultScalarSelector

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(128, 23, 128, 90); bytes[84362,84932).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultScalarSelector)`, or replace it by
`symbol(chResultScalarSelector)`.
  syntax CHResult ::= chResultScalarSelector(CHSelector) [klabel(chResultScalarSelector)]
```

## 162 Warning/Compiler/deprecated-klabel chResultScalarTypeTest

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(129, 23, 129, 84); bytes[84932,85490).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultScalarTypeTest)`, or replace it by
`symbol(chResultScalarTypeTest)`.
  syntax CHResult ::= chResultScalarTypeTest(Bool) [klabel(chResultScalarTypeTest)]
```

## 163 Warning/Compiler/deprecated-klabel chResultEqualDone

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(130, 23, 130, 75); bytes[85490,86020).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultEqualDone)`, or replace it by `symbol(chResultEqualDone)`.
  syntax CHResult ::= chResultEqualDone(CTRef) [klabel(chResultEqualDone)]
```

## 164 Warning/Compiler/deprecated-klabel chResultMatchMatched

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(131, 23, 131, 81); bytes[86020,86568).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultMatchMatched)`, or replace it by
`symbol(chResultMatchMatched)`.
  syntax CHResult ::= chResultMatchMatched(CTEnv) [klabel(chResultMatchMatched)]
```

## 165 Warning/Compiler/deprecated-klabel chResultMatchNoMatch

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(132, 23, 132, 76); bytes[86568,87106).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultMatchNoMatch)`, or replace it by
`symbol(chResultMatchNoMatch)`.
  syntax CHResult ::= chResultMatchNoMatch() [klabel(chResultMatchNoMatch)]
```

## 166 Warning/Compiler/deprecated-klabel chResultPlanMatched

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(133, 23, 133, 84); bytes[87106,87658).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultPlanMatched)`, or replace it by `symbol(chResultPlanMatched)`.
  syntax CHResult ::= chResultPlanMatched(Int, CTEnv) [klabel(chResultPlanMatched)]
```

## 167 Warning/Compiler/deprecated-klabel chResultPlanNoMatch

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(134, 23, 134, 74); bytes[87658,88190).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultPlanNoMatch)`, or replace it by `symbol(chResultPlanNoMatch)`.
  syntax CHResult ::= chResultPlanNoMatch() [klabel(chResultPlanNoMatch)]
```

## 168 Warning/Compiler/deprecated-klabel chResultBuildDone

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(135, 23, 135, 75); bytes[88190,88720).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultBuildDone)`, or replace it by `symbol(chResultBuildDone)`.
  syntax CHResult ::= chResultBuildDone(CTRef) [klabel(chResultBuildDone)]
```

## 169 Warning/Compiler/deprecated-klabel chNoHelper

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(136, 29, 136, 62); bytes[88720,89210).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chNoHelper)`, or replace it by `symbol(chNoHelper)`.
  syntax CHHelperOption ::= chNoHelper() [klabel(chNoHelper)]
```

## 170 Warning/Compiler/deprecated-klabel chSomeHelper

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(137, 29, 137, 74); bytes[89210,89728).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSomeHelper)`, or replace it by `symbol(chSomeHelper)`.
  syntax CHHelperOption ::= chSomeHelper(CHHelper) [klabel(chSomeHelper)]
```

## 171 Warning/Compiler/deprecated-klabel chNoResult

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(138, 29, 138, 62); bytes[89728,90218).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chNoResult)`, or replace it by `symbol(chNoResult)`.
  syntax CHResultOption ::= chNoResult() [klabel(chNoResult)]
```

## 172 Warning/Compiler/deprecated-klabel chSomeResult

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-helper-syntax.k Location(139, 29, 139, 74); bytes[90218,90736).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSomeResult)`, or replace it by `symbol(chSomeResult)`.
  syntax CHResultOption ::= chSomeResult(CHResult) [klabel(chSomeResult)]
```

## 173 Warning/Compiler/deprecated-klabel dpU128

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-owned-data-syntax.k Location(7, 21, 7, 49); bytes[90736,91188).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpU128)`, or replace it by `symbol(dpU128)`.
  syntax DPData ::= dpU128(Int) [klabel(dpU128)]
```

## 174 Warning/Compiler/deprecated-klabel dpBool

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-owned-data-syntax.k Location(8, 21, 8, 50); bytes[91188,91642).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpBool)`, or replace it by `symbol(dpBool)`.
                  | dpBool(Bool) [klabel(dpBool)]
```

## 175 Warning/Compiler/deprecated-klabel dpNil

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-owned-data-syntax.k Location(9, 21, 9, 44); bytes[91642,92082).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpNil)`, or replace it by `symbol(dpNil)`.
                  | dpNil() [klabel(dpNil)]
```

## 176 Warning/Compiler/deprecated-klabel dpCons

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-owned-data-syntax.k Location(10, 21, 10, 53); bytes[92082,92546).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpCons)`, or replace it by `symbol(dpCons)`.
                  | dpCons(CTSlice) [klabel(dpCons)]
```

## 177 Warning/Compiler/deprecated-klabel dpLeaf

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-owned-data-syntax.k Location(11, 21, 11, 53); bytes[92546,93010).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpLeaf)`, or replace it by `symbol(dpLeaf)`.
                  | dpLeaf(CTSlice) [klabel(dpLeaf)]
```

## 178 Warning/Compiler/deprecated-klabel dpBranch

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-owned-data-syntax.k Location(12, 21, 12, 57); bytes[93010,93486).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpBranch)`, or replace it by `symbol(dpBranch)`.
                  | dpBranch(CTSlice) [klabel(dpBranch)]
```

## 179 Warning/Compiler/deprecated-klabel dpConstructor

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-owned-data-syntax.k Location(13, 21, 13, 77); bytes[93486,94012).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpConstructor)`, or replace it by `symbol(dpConstructor)`.
                  | dpConstructor(Int, Int, CTSlice) [klabel(dpConstructor)]
```

## 180 Warning/Compiler/deprecated-klabel dpNoNodes

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-owned-data-syntax.k Location(14, 22, 14, 53); bytes[94012,94482).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpNoNodes)`, or replace it by `symbol(dpNoNodes)`.
  syntax DPNodes ::= dpNoNodes() [klabel(dpNoNodes)]
```

## 181 Warning/Compiler/deprecated-klabel dpNode

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-owned-data-syntax.k Location(15, 22, 15, 62); bytes[94482,94964).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpNode)`, or replace it by `symbol(dpNode)`.
                   | dpNode(DPData, DPNodes) [klabel(dpNode)]
```

## 182 Warning/Compiler/deprecated-klabel dpNoRefs

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-owned-data-syntax.k Location(16, 21, 16, 50); bytes[94964,95426).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpNoRefs)`, or replace it by `symbol(dpNoRefs)`.
  syntax DPRefs ::= dpNoRefs() [klabel(dpNoRefs)]
```

## 183 Warning/Compiler/deprecated-klabel dpRef

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-owned-data-syntax.k Location(17, 21, 17, 57); bytes[95426,95896).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpRef)`, or replace it by `symbol(dpRef)`.
                  | dpRef(CTRef, DPRefs) [klabel(dpRef)]
```

## 184 Warning/Compiler/deprecated-klabel dpEnvCell

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-owned-data-syntax.k Location(18, 24, 18, 72); bytes[95896,96404).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpEnvCell)`, or replace it by `symbol(dpEnvCell)`.
  syntax DPEnvCell ::= dpEnvCell(Int, CTRef, CTEnv) [klabel(dpEnvCell)]
```

## 185 Warning/Compiler/deprecated-klabel dpNoEnvs

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-owned-data-syntax.k Location(19, 21, 19, 50); bytes[96404,96866).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpNoEnvs)`, or replace it by `symbol(dpNoEnvs)`.
  syntax DPEnvs ::= dpNoEnvs() [klabel(dpNoEnvs)]
```

## 186 Warning/Compiler/deprecated-klabel dpEnv

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-owned-data-syntax.k Location(20, 21, 20, 61); bytes[96866,97344).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpEnv)`, or replace it by `symbol(dpEnv)`.
                  | dpEnv(DPEnvCell, DPEnvs) [klabel(dpEnv)]
```

## 187 Warning/Compiler/deprecated-klabel dpTables

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-owned-data-syntax.k Location(21, 23, 21, 83); bytes[97344,97872).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpTables)`, or replace it by `symbol(dpTables)`.
  syntax DPTables ::= dpTables(DPNodes, DPRefs, DPEnvs, DPRefs) [klabel(dpTables)]
```

## 188 Warning/Compiler/deprecated-klabel ctConst

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(7, 20, 7, 50); bytes[97872,98328).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctConst)`, or replace it by `symbol(ctConst)`.
  syntax CTRef ::= ctConst(Int) [klabel(ctConst)]
```

## 189 Warning/Compiler/deprecated-klabel ctData

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(8, 22, 8, 50); bytes[98328,98782).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctData)`, or replace it by `symbol(ctData)`.
                   | ctData(Int) [klabel(ctData)]
```

## 190 Warning/Compiler/deprecated-klabel ctEnvNone

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(9, 20, 9, 51); bytes[98782,99244).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvNone)`, or replace it by `symbol(ctEnvNone)`.
  syntax CTEnv ::= ctEnvNone() [klabel(ctEnvNone)]
```

## 191 Warning/Compiler/deprecated-klabel ctEnvSome

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(10, 22, 10, 56); bytes[99244,99720).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvSome)`, or replace it by `symbol(ctEnvSome)`.
                   | ctEnvSome(Int) [klabel(ctEnvSome)]
```

## 192 Warning/Compiler/deprecated-klabel ctFunctionNone

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(11, 25, 11, 66); bytes[99720,100226).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFunctionNone)`, or replace it by `symbol(ctFunctionNone)`.
  syntax CTFunction ::= ctFunctionNone() [klabel(ctFunctionNone)]
```

## 193 Warning/Compiler/deprecated-klabel ctFunctionSome

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(12, 27, 12, 71); bytes[100226,100742).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFunctionSome)`, or replace it by `symbol(ctFunctionSome)`.
                        | ctFunctionSome(Int) [klabel(ctFunctionSome)]
```

## 194 Warning/Compiler/deprecated-klabel ctSlice

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(13, 22, 13, 57); bytes[100742,101216).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSlice)`, or replace it by `symbol(ctSlice)`.
  syntax CTSlice ::= ctSlice(Int, Int) [klabel(ctSlice)]
```

## 195 Warning/Compiler/deprecated-klabel ctAdd

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(14, 23, 14, 46); bytes[101216,101664).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAdd)`, or replace it by `symbol(ctAdd)`.
  syntax CTBinary ::= ctAdd() [klabel(ctAdd)]
```

## 196 Warning/Compiler/deprecated-klabel ctSub

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(15, 25, 15, 48); bytes[101664,102116).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSub)`, or replace it by `symbol(ctSub)`.
                      | ctSub() [klabel(ctSub)]
```

## 197 Warning/Compiler/deprecated-klabel ctMul

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(16, 25, 16, 48); bytes[102116,102568).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMul)`, or replace it by `symbol(ctMul)`.
                      | ctMul() [klabel(ctMul)]
```

## 198 Warning/Compiler/deprecated-klabel ctEq

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(17, 25, 17, 46); bytes[102568,103014).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEq)`, or replace it by `symbol(ctEq)`.
                      | ctEq() [klabel(ctEq)]
```

## 199 Warning/Compiler/deprecated-klabel ctLt

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(18, 25, 18, 46); bytes[103014,103460).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLt)`, or replace it by `symbol(ctLt)`.
                      | ctLt() [klabel(ctLt)]
```

## 200 Warning/Compiler/deprecated-klabel ctCons

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(19, 25, 19, 50); bytes[103460,103918).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctCons)`, or replace it by `symbol(ctCons)`.
                      | ctCons() [klabel(ctCons)]
```

## 201 Warning/Compiler/deprecated-klabel ctBranch

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(20, 25, 20, 54); bytes[103918,104388).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBranch)`, or replace it by `symbol(ctBranch)`.
                      | ctBranch() [klabel(ctBranch)]
```

## 202 Warning/Compiler/deprecated-klabel ctLeaf

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(21, 22, 21, 47); bytes[104388,104840).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLeaf)`, or replace it by `symbol(ctLeaf)`.
  syntax CTUnary ::= ctLeaf() [klabel(ctLeaf)]
```

## 203 Warning/Compiler/deprecated-klabel ctNot

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(22, 24, 22, 47); bytes[104840,105290).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNot)`, or replace it by `symbol(ctNot)`.
                     | ctNot() [klabel(ctNot)]
```

## 204 Warning/Compiler/deprecated-klabel ctLetF

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(23, 22, 23, 67); bytes[105290,105782).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLetF)`, or replace it by `symbol(ctLetF)`.
  syntax CTFrame ::= ctLetF(Int, Int, CTEnv, Int) [klabel(ctLetF)]
```

## 205 Warning/Compiler/deprecated-klabel ctLeftF

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(24, 24, 24, 76); bytes[105782,106294).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLeftF)`, or replace it by `symbol(ctLeftF)`.
                     | ctLeftF(CTBinary, Int, CTEnv, Int) [klabel(ctLeftF)]
```

## 206 Warning/Compiler/deprecated-klabel ctRightF

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(25, 24, 25, 73); bytes[106294,106802).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRightF)`, or replace it by `symbol(ctRightF)`.
                     | ctRightF(CTBinary, CTRef, Int) [klabel(ctRightF)]
```

## 207 Warning/Compiler/deprecated-klabel ctUnaryF

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(26, 24, 26, 65); bytes[106802,107294).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctUnaryF)`, or replace it by `symbol(ctUnaryF)`.
                     | ctUnaryF(CTUnary, Int) [klabel(ctUnaryF)]
```

## 208 Warning/Compiler/deprecated-klabel ctIfF

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(27, 24, 27, 67); bytes[107294,107784).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctIfF)`, or replace it by `symbol(ctIfF)`.
                     | ctIfF(Int, Int, CTEnv, Int) [klabel(ctIfF)]
```

## 209 Warning/Compiler/deprecated-klabel ctMatchF

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(28, 24, 28, 72); bytes[107784,108290).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMatchF)`, or replace it by `symbol(ctMatchF)`.
                     | ctMatchF(CTSlice, CTEnv, Int) [klabel(ctMatchF)]
```

## 210 Warning/Compiler/deprecated-klabel ctArgsF

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(29, 24, 29, 84); bytes[108290,108818).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctArgsF)`, or replace it by `symbol(ctArgsF)`.
                     | ctArgsF(Int, CTSlice, CTSlice, CTEnv, Int) [klabel(ctArgsF)]
```

## 211 Warning/Compiler/deprecated-klabel ctReturnF

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(30, 24, 30, 70); bytes[108818,109322).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctReturnF)`, or replace it by `symbol(ctReturnF)`.
                     | ctReturnF(Int, CTEnv, Int) [klabel(ctReturnF)]
```

## 212 Warning/Compiler/deprecated-klabel ctScopeF

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(31, 24, 31, 63); bytes[109322,109810).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctScopeF)`, or replace it by `symbol(ctScopeF)`.
                     | ctScopeF(CTEnv, Int) [klabel(ctScopeF)]
```

## 213 Warning/Compiler/deprecated-klabel ctConstructorFieldsF

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(32, 24, 32, 131); bytes[109810,110459).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctConstructorFieldsF)`, or replace it by
`symbol(ctConstructorFieldsF)`.
                     | ctConstructorFieldsF(Int, Int, Int, Int, Bool, CTSlice, CTSlice, CTEnv, Int) [klabel(ctConstructorFieldsF)]
```

## 214 Warning/Compiler/deprecated-klabel ctNoFrames

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(33, 23, 33, 56); bytes[110459,110937).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNoFrames)`, or replace it by `symbol(ctNoFrames)`.
  syntax CTFrames ::= ctNoFrames() [klabel(ctNoFrames)]
```

## 215 Warning/Compiler/deprecated-klabel ctFrame

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(34, 25, 34, 69); bytes[110937,111435).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFrame)`, or replace it by `symbol(ctFrame)`.
                      | ctFrame(CTFrame, CTFrames) [klabel(ctFrame)]
```

## 216 Warning/Compiler/deprecated-klabel ctBindingBad

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(35, 24, 35, 61); bytes[111435,111927).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBindingBad)`, or replace it by `symbol(ctBindingBad)`.
  syntax CTBinding ::= ctBindingBad() [klabel(ctBindingBad)]
```

## 217 Warning/Compiler/deprecated-klabel ctBindingOk

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(36, 26, 36, 66); bytes[111927,112427).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBindingOk)`, or replace it by `symbol(ctBindingOk)`.
                       | ctBindingOk(CTEnv) [klabel(ctBindingOk)]
```

## 218 Warning/Compiler/deprecated-klabel ctNoMatch

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(37, 25, 37, 56); bytes[112427,112903).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNoMatch)`, or replace it by `symbol(ctNoMatch)`.
  syntax CTMatching ::= ctNoMatch() [klabel(ctNoMatch)]
```

## 219 Warning/Compiler/deprecated-klabel ctMatched

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(38, 27, 38, 63); bytes[112903,113393).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMatched)`, or replace it by `symbol(ctMatched)`.
                        | ctMatched(CTEnv) [klabel(ctMatched)]
```

## 220 Warning/Compiler/deprecated-klabel ctPrimValue

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(39, 26, 39, 66); bytes[113393,113893).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctPrimValue)`, or replace it by `symbol(ctPrimValue)`.
  syntax CTPrimitive ::= ctPrimValue(CTRef) [klabel(ctPrimValue)]
```

## 221 Warning/Compiler/deprecated-klabel ctPrimError

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(40, 28, 40, 66); bytes[113893,114393).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctPrimError)`, or replace it by `symbol(ctPrimError)`.
                         | ctPrimError(Int) [klabel(ctPrimError)]
```

## 222 Warning/Compiler/deprecated-klabel ctEval

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(41, 24, 41, 52); bytes[114393,114855).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEval)`, or replace it by `symbol(ctEval)`.
  syntax CTControl ::= ctEval(Int) [klabel(ctEval)]
```

## 223 Warning/Compiler/deprecated-klabel ctReturn

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(42, 26, 42, 60); bytes[114855,115337).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctReturn)`, or replace it by `symbol(ctReturn)`.
                       | ctReturn(CTRef) [klabel(ctReturn)]
```

## 224 Warning/Compiler/deprecated-klabel ctScheduleNext

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(43, 26, 43, 86); bytes[115337,115883).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctScheduleNext)`, or replace it by `symbol(ctScheduleNext)`.
                       | ctScheduleNext(CTFrame, Int, CTEnv) [klabel(ctScheduleNext)]
```

## 225 Warning/Compiler/deprecated-klabel ctInvoke

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(44, 26, 44, 67); bytes[115883,116379).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctInvoke)`, or replace it by `symbol(ctInvoke)`.
                       | ctInvoke(Int, CTSlice) [klabel(ctInvoke)]
```

## 226 Warning/Compiler/deprecated-klabel ctEnter

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(45, 26, 45, 72); bytes[116379,116883).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnter)`, or replace it by `symbol(ctEnter)`.
                       | ctEnter(CTFunction, CTSlice) [klabel(ctEnter)]
```

## 227 Warning/Compiler/deprecated-klabel ctBound

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(46, 26, 46, 72); bytes[116883,117387).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBound)`, or replace it by `symbol(ctBound)`.
                       | ctBound(CTBinding, Int, Int) [klabel(ctBound)]
```

## 228 Warning/Compiler/deprecated-klabel ctCases

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(47, 26, 47, 74); bytes[117387,117895).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctCases)`, or replace it by `symbol(ctCases)`.
                       | ctCases(CTRef, CTSlice, CTEnv) [klabel(ctCases)]
```

## 229 Warning/Compiler/deprecated-klabel ctCaseResult

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(48, 26, 48, 101); bytes[117895,118468).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctCaseResult)`, or replace it by `symbol(ctCaseResult)`.
                       | ctCaseResult(CTMatching, CTRef, Int, CTSlice, CTEnv) [klabel(ctCaseResult)]
```

## 230 Warning/Compiler/deprecated-klabel ctPrimResult

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(49, 26, 49, 74); bytes[118468,118986).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctPrimResult)`, or replace it by `symbol(ctPrimResult)`.
                       | ctPrimResult(CTPrimitive) [klabel(ctPrimResult)]
```

## 231 Warning/Compiler/deprecated-klabel ctError

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(50, 26, 50, 56); bytes[118986,119458).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctError)`, or replace it by `symbol(ctError)`.
                       | ctError(Int) [klabel(ctError)]
```

## 232 Warning/Compiler/deprecated-klabel ctMaterialize

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(51, 26, 51, 82); bytes[119458,119994).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMaterialize)`, or replace it by `symbol(ctMaterialize)`.
                       | ctMaterialize(Int, Int, CTSlice) [klabel(ctMaterialize)]
```

## 233 Warning/Compiler/deprecated-klabel ctFuel

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(52, 24, 52, 49); bytes[119994,120450).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFuel)`, or replace it by `symbol(ctFuel)`.
  syntax CTExhaust ::= ctFuel() [klabel(ctFuel)]
```

## 234 Warning/Compiler/deprecated-klabel ctDataNodes

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(53, 26, 53, 61); bytes[120450,120940).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDataNodes)`, or replace it by `symbol(ctDataNodes)`.
                       | ctDataNodes() [klabel(ctDataNodes)]
```

## 235 Warning/Compiler/deprecated-klabel ctDataFields

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(54, 26, 54, 63); bytes[120940,121436).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDataFields)`, or replace it by `symbol(ctDataFields)`.
                       | ctDataFields() [klabel(ctDataFields)]
```

## 236 Warning/Compiler/deprecated-klabel ctEnvironmentCells

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(55, 26, 55, 75); bytes[121436,121968).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvironmentCells)`, or replace it by `symbol(ctEnvironmentCells)`.
                       | ctEnvironmentCells() [klabel(ctEnvironmentCells)]
```

## 237 Warning/Compiler/deprecated-klabel ctHelperTasks

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(56, 26, 56, 65); bytes[121968,122470).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctHelperTasks)`, or replace it by `symbol(ctHelperTasks)`.
                       | ctHelperTasks() [klabel(ctHelperTasks)]
```

## 238 Warning/Compiler/deprecated-klabel ctHelperWork

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(57, 26, 57, 63); bytes[122470,122966).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctHelperWork)`, or replace it by `symbol(ctHelperWork)`.
                       | ctHelperWork() [klabel(ctHelperWork)]
```

## 239 Warning/Compiler/deprecated-klabel ctSerializationBytes

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(58, 26, 58, 79); bytes[122966,123510).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSerializationBytes)`, or replace it by
`symbol(ctSerializationBytes)`.
                       | ctSerializationBytes() [klabel(ctSerializationBytes)]
```

## 240 Warning/Compiler/deprecated-klabel ctRunning

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(59, 24, 59, 55); bytes[123510,123984).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRunning)`, or replace it by `symbol(ctRunning)`.
  syntax CTOutcome ::= ctRunning() [klabel(ctRunning)]
```

## 241 Warning/Compiler/deprecated-klabel ctHalted

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(60, 26, 60, 60); bytes[123984,124466).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctHalted)`, or replace it by `symbol(ctHalted)`.
                       | ctHalted(CTRef) [klabel(ctHalted)]
```

## 242 Warning/Compiler/deprecated-klabel ctRejected

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(61, 26, 61, 62); bytes[124466,124956).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRejected)`, or replace it by `symbol(ctRejected)`.
                       | ctRejected(Int) [klabel(ctRejected)]
```

## 243 Warning/Compiler/deprecated-klabel ctExhausted

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(62, 26, 62, 70); bytes[124956,125464).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctExhausted)`, or replace it by `symbol(ctExhausted)`.
                       | ctExhausted(CTExhaust) [klabel(ctExhausted)]
```

## 244 Warning/Compiler/deprecated-klabel ctAlloc

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(63, 22, 63, 62); bytes[125464,125948).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAlloc)`, or replace it by `symbol(ctAlloc)`.
  syntax CTAlloc ::= ctAlloc(Int, Int, Int) [klabel(ctAlloc)]
```

## 245 Warning/Compiler/deprecated-klabel ctActive

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(64, 23, 64, 70); bytes[125948,126450).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctActive)`, or replace it by `symbol(ctActive)`.
  syntax CTActive ::= ctActive(Int, Int, Int, Int) [klabel(ctActive)]
```

## 246 Warning/Compiler/deprecated-klabel ctRoot

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(65, 21, 65, 166); bytes[126450,127141).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRoot)`, or replace it by `symbol(ctRoot)`.
  syntax CTRoot ::= ctRoot(CTControl, Int, CTEnv, Int, CTOutcome, Int, Int, Int, Int, Int, Int, CTAlloc, CTActive, CTActive, CTAlloc, Int, CTFrames) [klabel(ctRoot)]
```

## 247 Warning/Compiler/deprecated-klabel ctNoLanes

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(66, 22, 66, 53); bytes[127141,127611).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNoLanes)`, or replace it by `symbol(ctNoLanes)`.
  syntax CTLanes ::= ctNoLanes() [klabel(ctNoLanes)]
```

## 248 Warning/Compiler/deprecated-klabel ctLane

/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-EnvGetCell-EnvGetExit-owner-positive-20261020/conditional-positive-transition-source01/source/c6-typed-root-syntax.k Location(67, 24, 67, 61); bytes[127611,128091).

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLane)`, or replace it by `symbol(ctLane)`.
                     | ctLane(Int, CTLanes) [klabel(ctLane)]
```
