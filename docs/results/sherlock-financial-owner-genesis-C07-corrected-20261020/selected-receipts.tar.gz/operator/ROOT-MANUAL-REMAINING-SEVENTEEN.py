from pathlib import Path
import json,hashlib,runpy,os
B=Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/financial-owner-genesis-C07-ordinary-QA-20261020')
plan=B/'PROPOSED-NINETEEN-OPERATIONS.json';assert hashlib.sha256(plan.read_bytes()).hexdigest()=='06fdd94b066d5d8c0101da4c1d283e1c9b10454fe8cfb029504f9b66ba442804'
j=json.loads(plan.read_text());hp=j['captureHelper'];assert hashlib.sha256(Path(hp['path']).read_bytes()).hexdigest()=='713119d9400f82d559967e4296313cec8cde7125dc91a74152500577ced00626'
h=runpy.run_path(hp['path'],run_name='Root_existing_capture_functions_only')
old=runpy.run_path(str(B/'PREVIOUS-ROOT-COMPOSITION.READONLY-REFERENCE.py'),run_name='Root_existing_list_pretty_inventory_functions_only')
A=B/'root-actual-ordinary19-01';first=json.loads((A/'ROOT-FIRST-TWO-RESULT.json').read_text());assert first['accepted']
generated=first['generated'];flat=json.loads((B/'STATIC-PREPOST-PINS.json').read_text())['files'];assert len(flat)==459
controls=[h['pin'](p)for p in B.iterdir()if p.is_file()]+[h['pin'](A/'ROOT-FIRST-TWO-RESULT.json')]
assert h['static_check'](flat+controls+generated)['all_match'];old['inventory']()
ops=j['operations'][2:];assert len(ops)==17
for o in ops:
 assert not(A/o['id']).exists()
 assert o['wallSeconds']==30 and o['keptBytesPerStream']==131072
 for p in o['outputs']:assert not Path(p).exists()
selection=dict(selectedIds=[o['id']for o in ops],proposal=h['pin'](plan),RootFullTwoSourceOpinionAndExistingAPIRead=True,actualComposition=h['pin'](__file__),priorTwoCompile=h['pin'](A/'ROOT-FIRST-TWO-RESULT.json'),preconditions='Bothnewnormal/cfgCorecompiledandfrozen; exactexistingordinarycaps/noSDK/native; existingstrictlist/pretty/inventoryparsersunchanged',noRetries=True)
h['save'](A/'ROOT-SELECTION-REMAINING-SEVENTEEN.json',selection)
with(A/'ROOT-SELECTION-REMAINING-SEVENTEEN.json').open('rb')as f:os.fsync(f.fileno())
controls+=[h['pin'](A/'ROOT-SELECTION-REMAINING-SEVENTEEN.json')]
records=[];fullnames=None;external_names={}
try:
 for o in ops:
  assert h['static_check'](flat+controls+generated)['all_match'];old['inventory']()
  phase=A/o['id'];phase.mkdir()
  h['save'](phase/'PRECHECK.json',h['static_check'](flat+controls+generated))
  raw=h['capture'](o,phase);h['save'](phase/'RESULT.json',raw)
  for name in ['COMMAND.json','RESULT.json','stdout.bin','stderr.bin']:
   with(phase/name).open('rb')as f:os.fsync(f.fileno())
  fd=os.open(phase,os.O_DIRECTORY|os.O_RDONLY);os.fsync(fd);os.close(fd)
  post=h['static_check'](flat+controls+generated);h['save'](phase/'POSTCHECK.json',post)
  assert post['all_match'];old['inventory']()
  assert json.loads((phase/'COMMAND.json').read_text())==o
  assert raw['actual_exit']==0 and raw['controller_failure']is None
  for x in raw['streams']:
   h['check'](x);assert x['full_stream_retained']and x['bytes']==x['bytes_seen']==x['bytes_retained']
  out=(phase/'stdout.bin').read_bytes();err=(phase/'stderr.bin').read_bytes()
  row=dict(id=o['id'],accepted=True,result=h['pin'](phase/'RESULT.json'),elapsedSeconds=raw['elapsed_seconds'])
  if o['outputs']:
   assert out==b''
   products=[h['pin'](p)for p in o['outputs']]
   assert all(x['bytes']>0 and not Path(x['path']).is_symlink()for x in products)
   h['save'](phase/'ACTUAL-GENERATED-PINS.json',dict(files=products))
   cl=json.loads((B/'EXPECTED-DEP-MEMBERSHIP.json').read_text())[o['expectedDepMembership']]
   allowed={str(Path(x['path']).resolve(strict=True)):x for x in cl['files']};assert len(allowed)==cl['count']==1
   deps=h['dep_inputs'](o['outputs'][1],allowed)
   assert{str(Path(x['selected_binding']).resolve(strict=True))for x in deps}==set(allowed)
   h['save'](phase/'EXACT-DEP-MEMBERSHIP.json',dict(files=deps,canonicalCount=1,exact=True))
   for ix,p in enumerate(o['outputs']):os.chmod(p,0o500 if ix==0 else 0o400)
   generated+=products;row.update(generated=products,exactDependencies=1,diagnostics='Full retained; later complete diagnostic extraction')
  elif '--list'in o['argv']:
   assert err==b''
   names=old['list_names'](out)
   if o['id']=='03-list-all-Core':
    expected=json.loads((B/'EXPECTED-TEST-MEMBERSHIP.json').read_text())
    assert names==expected['expectedWholeNames']and len(names)==expected['expectedWholeCount']==436
    fullnames=names
   else:
    assert names==o['expected']['exactNames']and len(names)==o['expected']['count']
    if 'complete-observation'in o['id']:external_names['complete-observation']=names
    elif 'generic-owner-and-refusal'in o['id']:external_names['generic-owner-and-refusal']=names
    else:assert fullnames is not None and all(n in fullnames for n in names)
   membership=dict(names=names,count=len(names),sourceExpected=h['pin'](B/'EXPECTED-TEST-MEMBERSHIP.json'))
   h['save'](phase/'FROZEN-ACTUAL-MEMBERSHIP.json',membership)
   generated+=[h['pin'](phase/'stdout.bin'),h['pin'](phase/'FROZEN-ACTUAL-MEMBERSHIP.json')]
   row['listed']=len(names)
  else:
   assert err==b''
   names=o['expected']['exactNames']
   if 'complete-observation'in o['id']:
    assert names==external_names['complete-observation'];filtered=0
   elif 'generic-owner-and-refusal'in o['id']:
    assert names==external_names['generic-owner-and-refusal'];filtered=0
   else:
    assert fullnames is not None;filtered=len(fullnames)-len(names)
   old['pretty'](out,names,filtered)
   row.update(passed=len(names),failed=0,ignored=0,measured=0,filteredOut=filtered,exactNames=names)
  h['save'](phase/'ACCEPTANCE.json',row);records.append(row)
  assert h['static_check'](flat+controls+generated)['all_match']
  print(json.dumps({k:v for k,v in row.items()if k not in ['exactNames','generated']}),flush=True)
 h['save'](A/'ROOT-ALL-NINETEEN-RESULT.json',dict(accepted=True,firstTwo=first['phases'],remainingSeventeen=records,selectedTestsPassed=sum(x.get('passed',0)for x in records),generated=generated,staticRows=459,compiledSnapshotMembers=191,newTests=14,affectedInternal=38,affectedExternal=8,scope='Normal/cfg Core and60selectednew/affectedtests only; financialadmission/genesis/boundedcapture. No20XFinexecution/native/SDK/proof/target/EARS. RootfirstTwooperatorfilepostdispatch chronology separatelydisclosed.',noPrefixRefresh=True,noRetryOrCapChanges=True))
except BaseException as e:
 h['save'](A/'FAILURE-REMAINING.json',dict(error=type(e).__name__+': '+str(e),acceptedPhases=records,remainingUnrun=True,noRetryOrCapChange=True))
 raise
