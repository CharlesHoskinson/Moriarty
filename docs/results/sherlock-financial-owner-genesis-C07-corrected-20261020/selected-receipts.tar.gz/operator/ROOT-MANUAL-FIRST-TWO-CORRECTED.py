from pathlib import Path
import json,hashlib,runpy,os,stat
B=Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/financial-owner-genesis-C07-ordinary-QA-20261020/phase11-V4-V8-source-diagnosis-and-owner-correction-01/literal-owner-correction-candidate-01/ordinary-QA-proposal-01')
plan=B/'PROPOSED-THIRTEEN-OPERATIONS.json';flatp=B/'STATIC-PREPOST-PINS.json'
assert hashlib.sha256(plan.read_bytes()).hexdigest()=='01b8c7413721b447da1cfa004df0810a40a13eddb711c041961b42bc296f9c46'
assert hashlib.sha256(flatp.read_bytes()).hexdigest()=='6656a5540c3ac3137eb7e634972926fce408695841f1641d3ad96c62a237cf00'
j=json.loads(plan.read_text());helper=j['captureHelper']
assert hashlib.sha256(Path(helper['path']).read_bytes()).hexdigest()=='713119d9400f82d559967e4296313cec8cde7125dc91a74152500577ced00626'
h=runpy.run_path(helper['path'],run_name='Root_existing_ordinary_capture_functions_only')
reference=Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/financial-owner-genesis-C07-ordinary-QA-20261020/PREVIOUS-ROOT-COMPOSITION.READONLY-REFERENCE.py')
assert hashlib.sha256(reference.read_bytes()).hexdigest()=='205117022c370688ca442d57040d0eccef2cca10b34b008e52e7bf1f5394e31e'
old=runpy.run_path(str(reference),run_name='Root_retained_ordinary_definition_functions_only')
flat=json.loads(flatp.read_text())['files'];assert len(flat)==460
assert json.loads((B/'CORE-EXACT-L-DIRECTORY-MEMBERSHIP.json').read_text())['directories']==json.loads((reference.parent/'CORE-EXACT-L-DIRECTORY-MEMBERSHIP.json').read_text())['directories']
control=[h['pin'](p)for p in B.iterdir()if p.is_file()]
h['static_check'](flat+control)
assert h['static_check'](flat+control)['all_match'];old['inventory']()
ops=j['operations'][:2];assert [o['id']for o in ops]==['01-normal','02-cfgtest']
for o in ops:
 assert o['wallSeconds']==30 and o['keptBytesPerStream']==131072
 assert o['argv'][:9]==['/usr/bin/timeout','--signal=KILL','30s','/usr/bin/prlimit','--cpu=25:25','--as=2147483648:2147483648','--fsize=67108864:67108864','--core=0:0','--']
 for p in o['outputs']:assert not Path(p).exists()
W=Path(ops[0]['cwd']);A=B/'actual-thirteen-01'
for p in [W,A]:
 assert not p.exists()and not p.is_symlink()
 assert not any(x.is_symlink()for x in p.parents)
W.mkdir();(W/'build').mkdir()
for name in ['normal','cfgtest','external','test']:(W/'tmp'/name).mkdir(parents=True)
A.mkdir(mode=0o700)
selection=dict(selectedIds=[o['id']for o in ops],RootReadFreshFullSourceOpinion=True,RootReadExistingCompositionAndExactFirstTwoArgv=True,sourceOpinions=['500f2208a2d705cd827650dbd56a113ca20f834d5b2f35bdd3f9b4b1d5612a61'],actualManualComposition=h['pin'](__file__),metadataErratum='Frozen operation normalLibraryQualification repeats old191file/14owner count; actual corrected sourceFreeze is192files including3newtests, dep117/190. No source/argv/caps change or oldresult rewrite.',proposal=h['pin'](plan),flat=h['pin'](flatp),existingHelper=helper,sourceMembers=192,scope='Fresh normal then real cfgtest Core compile only; later11 operations not selected here. Existing ordinaryclass unchanged; noSDK/native/proof.',noRetries=True)
h['save'](A/'ROOT-SELECTION-FIRST-TWO.json',selection)
with(A/'ROOT-SELECTION-FIRST-TWO.json').open('rb')as f:os.fsync(f.fileno())
generated=[];records=[]
try:
 for ix,o in enumerate(ops):
  phase=A/o['id'];phase.mkdir()
  before=h['static_check'](flat+control+generated);assert before['all_match'];old['inventory']()
  h['save'](phase/'PRECHECK.json',before)
  raw=h['capture'](o,phase);h['save'](phase/'RESULT.json',raw)
  for name in ['COMMAND.json','stdout.bin','stderr.bin','RESULT.json']:
   with(phase/name).open('rb')as f:os.fsync(f.fileno())
  fd=os.open(phase,os.O_DIRECTORY|os.O_RDONLY);os.fsync(fd);os.close(fd)
  post=h['static_check'](flat+control+generated);h['save'](phase/'POSTCHECK.json',post)
  assert post['all_match'];old['inventory']()
  assert json.loads((phase/'COMMAND.json').read_text())==o
  assert raw['actual_exit']==0 and raw['controller_failure']is None
  for x in raw['streams']:
   h['check'](x);assert x['full_stream_retained']and x['bytes']==x['bytes_seen']==x['bytes_retained']
  assert(phase/'stdout.bin').read_bytes()==b''
  products=[h['pin'](p)for p in o['outputs']]
  assert all(x['bytes']>0 and not Path(x['path']).is_symlink()for x in products)
  h['save'](phase/'ACTUAL-GENERATED-PINS.json',dict(files=products))
  cl=json.loads((B/'EXPECTED-DEP-MEMBERSHIP.json').read_text())[['normal','cfgTest'][ix]]
  allowed={str(Path(x['path']).resolve(strict=True)):x for x in cl['files']}
  assert len(allowed)==cl['count']==[117,190][ix]
  deps=h['dep_inputs'](o['outputs'][1],allowed)
  seen={str(Path(x['selected_binding']).resolve(strict=True))for x in deps}
  assert seen==set(allowed)
  h['save'](phase/'EXACT-DEP-MEMBERSHIP.json',dict(files=deps,canonicalCount=len(seen),expected=cl['count'],exact=True))
  for k,p in enumerate(o['outputs']):os.chmod(p,0o500 if ix==1 and k==0 else 0o400)
  generated+=products
  row=dict(id=o['id'],accepted=True,result=h['pin'](phase/'RESULT.json'),elapsedSeconds=raw['elapsed_seconds'],generated=products,exactDependencies=len(seen),diagnostics='Complete retained, semantic warning/error adjudication pending')
  h['save'](phase/'ACCEPTANCE.json',row);records.append(row)
  print(json.dumps(row),flush=True)
 h['save'](A/'ROOT-FIRST-TWO-RESULT.json',dict(accepted=True,phases=records,generated=generated,scope='Exact C07 plus V4/V8 corrected fresh normal+real cfgtest compile observed; later11 operations unselected/unrun; warnings unadjudicated.'))
except BaseException as e:
 h['save'](A/'FAILURE.json',dict(error=type(e).__name__+': '+str(e),acceptedPhases=records,remainingUnrun=True,noRetryOrCapChange=True))
 raise
