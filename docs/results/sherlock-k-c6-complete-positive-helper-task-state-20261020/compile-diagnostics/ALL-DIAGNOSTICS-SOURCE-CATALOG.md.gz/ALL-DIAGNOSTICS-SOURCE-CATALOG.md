## 1 deprecated-klabel csHelperCase

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperCase)`, or replace it by `symbol(csHelperCase)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-input-syntax.k)
	Location(5,27,5,86)
	5 |	  syntax CSHelperCase ::= csHelperCase(String, CHHelperOption)
[klabel(csHelperCase)]
	  .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 2 deprecated-klabel csResultCase

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csResultCase)`, or replace it by `symbol(csResultCase)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-input-syntax.k)
	Location(6,27,6,86)
	6 |	  syntax CSResultCase ::= csResultCase(String, CHResultOption)
[klabel(csResultCase)]
	  .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 3 deprecated-klabel csTaskCase

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csTaskCase)`, or replace it by `symbol(csTaskCase)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-input-syntax.k)
	Location(7,25,7,72)
	7 |	  syntax CSTaskCase ::= csTaskCase(String, CSTask) [klabel(csTaskCase)]
	  .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 4 deprecated-klabel csHelperSectionCase

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperSectionCase)`, or replace it by `symbol(csHelperSectionCase)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-input-syntax.k)
	Location(8,34,8,107)
	8 |	  syntax CSHelperSectionCase ::= csHelperSectionCase(String,
CSHelperTables) [klabel(csHelperSectionCase)]
	  .	                                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 5 deprecated-klabel csStateCase

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csStateCase)`, or replace it by `symbol(csStateCase)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-input-syntax.k)
	Location(9,26,9,92)
	9 |	  syntax CSStateCase ::= csStateCase(String, CSContext, CSOwnedState)
[klabel(csStateCase)]
	  .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 6 deprecated-klabel csNoHelperCases

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoHelperCases)`, or replace it by `symbol(csNoHelperCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-input-syntax.k)
	Location(10,28,10,71)
	10 |	  syntax CSHelperCases ::= csNoHelperCases() [klabel(csNoHelperCases)]
	   .	                           ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 7 deprecated-klabel csHelperCaseRow

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperCaseRow)`, or replace it by `symbol(csHelperCaseRow)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-input-syntax.k)
	Location(11,28,11,98)
	11 |	  syntax CSHelperCases ::= csHelperCaseRow(CSHelperCase, CSHelperCases)
[klabel(csHelperCaseRow)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 8 deprecated-klabel csNoResultCases

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoResultCases)`, or replace it by `symbol(csNoResultCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-input-syntax.k)
	Location(12,28,12,71)
	12 |	  syntax CSResultCases ::= csNoResultCases() [klabel(csNoResultCases)]
	   .	                           ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 9 deprecated-klabel csResultCaseRow

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csResultCaseRow)`, or replace it by `symbol(csResultCaseRow)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-input-syntax.k)
	Location(13,28,13,98)
	13 |	  syntax CSResultCases ::= csResultCaseRow(CSResultCase, CSResultCases)
[klabel(csResultCaseRow)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 10 deprecated-klabel csNoTaskCases

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoTaskCases)`, or replace it by `symbol(csNoTaskCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-input-syntax.k)
	Location(14,26,14,65)
	14 |	  syntax CSTaskCases ::= csNoTaskCases() [klabel(csNoTaskCases)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 11 deprecated-klabel csTaskCaseRow

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csTaskCaseRow)`, or replace it by `symbol(csTaskCaseRow)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-input-syntax.k)
	Location(15,26,15,88)
	15 |	  syntax CSTaskCases ::= csTaskCaseRow(CSTaskCase, CSTaskCases)
[klabel(csTaskCaseRow)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 12 deprecated-klabel csNoHelperSectionCases

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoHelperSectionCases)`, or replace it by
`symbol(csNoHelperSectionCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-input-syntax.k)
	Location(16,35,16,92)
	16 |	  syntax CSHelperSectionCases ::= csNoHelperSectionCases()
[klabel(csNoHelperSectionCases)]
	   .	                                 
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 13 deprecated-klabel csHelperSectionCaseRow

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperSectionCaseRow)`, or replace it by
`symbol(csHelperSectionCaseRow)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-input-syntax.k)
	Location(17,35,17,133)
	17 |	  syntax CSHelperSectionCases ::=
csHelperSectionCaseRow(CSHelperSectionCase, CSHelperSectionCases)
[klabel(csHelperSectionCaseRow)]
	   .	                                 
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 14 deprecated-klabel csNoStateCases

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoStateCases)`, or replace it by `symbol(csNoStateCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-input-syntax.k)
	Location(18,27,18,68)
	18 |	  syntax CSStateCases ::= csNoStateCases() [klabel(csNoStateCases)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 15 deprecated-klabel csStateCaseRow

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csStateCaseRow)`, or replace it by `symbol(csStateCaseRow)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-input-syntax.k)
	Location(19,27,19,93)
	19 |	  syntax CSStateCases ::= csStateCaseRow(CSStateCase, CSStateCases)
[klabel(csStateCaseRow)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 16 deprecated-klabel csCohort

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csCohort)`, or replace it by `symbol(csCohort)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-input-syntax.k)
	Location(20,23,20,153)
	20 |	  syntax CSCohort ::= csCohort(String, String, CSCaps, CSHelperCases,
CSResultCases, CSTaskCases, CSHelperSectionCases, CSStateCases)
[klabel(csCohort)]
	   .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 17 deprecated-klabel csUnvisited

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csUnvisited)`, or replace it by `symbol(csUnvisited)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(10,22,10,57)
	10 |	  syntax CSVisit ::= csUnvisited() [klabel(csUnvisited)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 18 deprecated-klabel csFields

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csFields)`, or replace it by `symbol(csFields)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(11,22,11,51)
	11 |	  syntax CSVisit ::= csFields() [klabel(csFields)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 19 deprecated-klabel csValidateTask

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csValidateTask)`, or replace it by `symbol(csValidateTask)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(12,21,12,81)
	12 |	  syntax CSTask ::= csValidateTask(CTRef, CSVisit, Int)
[klabel(csValidateTask)]
	   .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 20 deprecated-klabel csEqualTask

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csEqualTask)`, or replace it by `symbol(csEqualTask)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(13,21,13,82)
	13 |	  syntax CSTask ::= csEqualTask(CTRef, CTRef, CSVisit, Int)
[klabel(csEqualTask)]
	   .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 21 deprecated-klabel csPairTask

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csPairTask)`, or replace it by `symbol(csPairTask)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(14,21,14,69)
	14 |	  syntax CSTask ::= csPairTask(Int, Int, CTRef) [klabel(csPairTask)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 22 deprecated-klabel csNoTasks

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoTasks)`, or replace it by `symbol(csNoTasks)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(15,22,15,53)
	15 |	  syntax CSTasks ::= csNoTasks() [klabel(csNoTasks)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 23 deprecated-klabel csTask

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csTask)`, or replace it by `symbol(csTask)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(16,22,16,62)
	16 |	  syntax CSTasks ::= csTask(CSTask, CSTasks) [klabel(csTask)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 24 deprecated-klabel csHelperTables

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperTables)`, or replace it by `symbol(csHelperTables)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(17,29,17,109)
	17 |	  syntax CSHelperTables ::= csHelperTables(CHHelperOption,
CHResultOption, CSTasks) [klabel(csHelperTables)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 25 deprecated-klabel csCaps

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csCaps)`, or replace it by `symbol(csCaps)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(18,21,18,189)
	18 |	  syntax CSCaps ::= csCaps(Int, Int, Int, Int, Int, Int, Int, Int, Int,
Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int,
Int, Int, Int, Int) [klabel(csCaps)]
	   .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 26 deprecated-klabel csLimits

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csLimits)`, or replace it by `symbol(csLimits)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(19,23,19,55)
	19 |	  syntax CSLimits ::= csLimits(Int) [klabel(csLimits)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 27 deprecated-klabel csContext

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csContext)`, or replace it by `symbol(csContext)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(20,24,20,77)
	20 |	  syntax CSContext ::= csContext(CSCaps, Bool, CSLimits)
[klabel(csContext)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 28 deprecated-klabel csOwnedState

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csOwnedState)`, or replace it by `symbol(csOwnedState)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(21,27,21,96)
	21 |	  syntax CSOwnedState ::= csOwnedState(CTRoot, DPTables, CSHelperTables)
[klabel(csOwnedState)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 29 deprecated-klabel csNoStrings

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoStrings)`, or replace it by `symbol(csNoStrings)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(22,24,22,59)
	22 |	  syntax CSStrings ::= csNoStrings() [klabel(csNoStrings)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 30 deprecated-klabel csString

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csString)`, or replace it by `symbol(csString)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(23,24,23,70)
	23 |	  syntax CSStrings ::= csString(String, CSStrings) [klabel(csString)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 31 deprecated-klabel csCaseIds

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csCaseIds)`, or replace it by `symbol(csCaseIds)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(24,24,24,108)
	24 |	  syntax CSCaseIds ::= csCaseIds(CSStrings, CSStrings, CSStrings,
CSStrings, CSStrings) [klabel(csCaseIds)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 32 deprecated-klabel csHelperRecord

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperRecord)`, or replace it by `symbol(csHelperRecord)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(25,29,25,93)
	25 |	  syntax CSHelperRecord ::= csHelperRecord(CTLanes, CHHelperOption)
[klabel(csHelperRecord)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 33 deprecated-klabel csNoHelperRecords

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoHelperRecords)`, or replace it by `symbol(csNoHelperRecords)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(26,30,26,77)
	26 |	  syntax CSHelperRecords ::= csNoHelperRecords()
[klabel(csNoHelperRecords)]
	   .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 34 deprecated-klabel csHelperRecordRow

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperRecordRow)`, or replace it by `symbol(csHelperRecordRow)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(27,30,27,108)
	27 |	  syntax CSHelperRecords ::= csHelperRecordRow(CSHelperRecord,
CSHelperRecords) [klabel(csHelperRecordRow)]
	   .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 35 deprecated-klabel csResultRecord

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csResultRecord)`, or replace it by `symbol(csResultRecord)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(28,29,28,93)
	28 |	  syntax CSResultRecord ::= csResultRecord(CTLanes, CHResultOption)
[klabel(csResultRecord)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 36 deprecated-klabel csNoResultRecords

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoResultRecords)`, or replace it by `symbol(csNoResultRecords)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(29,30,29,77)
	29 |	  syntax CSResultRecords ::= csNoResultRecords()
[klabel(csNoResultRecords)]
	   .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 37 deprecated-klabel csResultRecordRow

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csResultRecordRow)`, or replace it by `symbol(csResultRecordRow)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(30,30,30,108)
	30 |	  syntax CSResultRecords ::= csResultRecordRow(CSResultRecord,
CSResultRecords) [klabel(csResultRecordRow)]
	   .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 38 deprecated-klabel csTaskRecord

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csTaskRecord)`, or replace it by `symbol(csTaskRecord)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(31,27,31,79)
	31 |	  syntax CSTaskRecord ::= csTaskRecord(CTLanes, CSTask)
[klabel(csTaskRecord)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 39 deprecated-klabel csNoTaskRecords

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoTaskRecords)`, or replace it by `symbol(csNoTaskRecords)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(32,28,32,71)
	32 |	  syntax CSTaskRecords ::= csNoTaskRecords() [klabel(csNoTaskRecords)]
	   .	                           ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 40 deprecated-klabel csTaskRecordRow

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csTaskRecordRow)`, or replace it by `symbol(csTaskRecordRow)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(33,28,33,98)
	33 |	  syntax CSTaskRecords ::= csTaskRecordRow(CSTaskRecord, CSTaskRecords)
[klabel(csTaskRecordRow)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 41 deprecated-klabel csTaskSpan

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csTaskSpan)`, or replace it by `symbol(csTaskSpan)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(34,25,34,85)
	34 |	  syntax CSTaskSpan ::= csTaskSpan(Int, Int, Int, Int, CTLanes)
[klabel(csTaskSpan)]
	   .	                       
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 42 deprecated-klabel csNoTaskSpans

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoTaskSpans)`, or replace it by `symbol(csNoTaskSpans)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(35,26,35,65)
	35 |	  syntax CSTaskSpans ::= csNoTaskSpans() [klabel(csNoTaskSpans)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 43 deprecated-klabel csTaskSpanRow

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csTaskSpanRow)`, or replace it by `symbol(csTaskSpanRow)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(36,26,36,88)
	36 |	  syntax CSTaskSpans ::= csTaskSpanRow(CSTaskSpan, CSTaskSpans)
[klabel(csTaskSpanRow)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 44 deprecated-klabel csHelperSection

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperSection)`, or replace it by `symbol(csHelperSection)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(37,30,37,114)
	37 |	  syntax CSHelperSection ::= csHelperSection(CTLanes, CSHelperTables,
CSTaskSpans, Int) [klabel(csHelperSection)]
	   .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 45 deprecated-klabel csNoHelperSections

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoHelperSections)`, or replace it by `symbol(csNoHelperSections)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(38,31,38,80)
	38 |	  syntax CSHelperSections ::= csNoHelperSections()
[klabel(csNoHelperSections)]
	   .	                             
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 46 deprecated-klabel csHelperSectionRow

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperSectionRow)`, or replace it by `symbol(csHelperSectionRow)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(39,31,39,113)
	39 |	  syntax CSHelperSections ::= csHelperSectionRow(CSHelperSection,
CSHelperSections) [klabel(csHelperSectionRow)]
	   .	                             
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 47 deprecated-klabel csChildSection

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csChildSection)`, or replace it by `symbol(csChildSection)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(40,29,40,105)
	40 |	  syntax CSChildSection ::= csChildSection(String, Int, Int, Int, Int,
CTLanes) [klabel(csChildSection)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 48 deprecated-klabel csNoChildSections

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoChildSections)`, or replace it by `symbol(csNoChildSections)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(41,30,41,77)
	41 |	  syntax CSChildSections ::= csNoChildSections()
[klabel(csNoChildSections)]
	   .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 49 deprecated-klabel csChildSectionRow

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csChildSectionRow)`, or replace it by `symbol(csChildSectionRow)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(42,30,42,108)
	42 |	  syntax CSChildSections ::= csChildSectionRow(CSChildSection,
CSChildSections) [klabel(csChildSectionRow)]
	   .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 50 deprecated-klabel csStateObservation

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csStateObservation)`, or replace it by `symbol(csStateObservation)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(43,33,43,145)
	43 |	  syntax CSStateObservation ::= csStateObservation(CTLanes, CSOwnedState,
CSContext, CTLanes, CSChildSections, Int) [klabel(csStateObservation)]
	   .	                               
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 51 deprecated-klabel csNoStateObservations

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csNoStateObservations)`, or replace it by
`symbol(csNoStateObservations)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(44,34,44,89)
	44 |	  syntax CSStateObservations ::= csNoStateObservations()
[klabel(csNoStateObservations)]
	   .	                                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 52 deprecated-klabel csStateObservationRow

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csStateObservationRow)`, or replace it by
`symbol(csStateObservationRow)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(45,34,45,128)
	45 |	  syntax CSStateObservations ::=
csStateObservationRow(CSStateObservation, CSStateObservations)
[klabel(csStateObservationRow)]
	   .	                                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 53 deprecated-klabel csObservations

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObservations)`, or replace it by `symbol(csObservations)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-helper-task-state-syntax.k)
	Location(46,29,46,183)
	46 |	  syntax CSObservations ::= csObservations(String, String, CSCaseIds,
CSHelperRecords, CSResultRecords, CSTaskRecords, CSHelperSections,
CSStateObservations) [klabel(csObservations)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 54 deprecated-klabel csTaskRoundtrip

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csTaskRoundtrip)`, or replace it by `symbol(csTaskRoundtrip)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state-laws.k)
	Location(6,19,6,78)
	6 |	  syntax Bool ::= csTaskRoundtrip(CSTask) [function,
klabel(csTaskRoundtrip)]
	  .	                 
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 55 deprecated-klabel csHelperRoundtrip

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperRoundtrip)`, or replace it by `symbol(csHelperRoundtrip)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state-laws.k)
	Location(8,19,8,90)
	8 |	  syntax Bool ::= csHelperRoundtrip(CSHelperTables) [function,
klabel(csHelperRoundtrip)]
	  .	                 
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 56 deprecated-klabel csDataRoundtrip

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csDataRoundtrip)`, or replace it by `symbol(csDataRoundtrip)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state-laws.k)
	Location(10,19,10,80)
	10 |	  syntax Bool ::= csDataRoundtrip(DPTables) [function,
klabel(csDataRoundtrip)]
	   .	                 
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 57 deprecated-klabel csStateRoundtrip

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csStateRoundtrip)`, or replace it by `symbol(csStateRoundtrip)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state-laws.k)
	Location(12,19,12,97)
	12 |	  syntax Bool ::= csStateRoundtrip(CSContext, CSOwnedState) [function,
klabel(csStateRoundtrip)]
	   .	                 
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 58 deprecated-klabel csVisitTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csVisitTag)`, or replace it by `symbol(csVisitTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(12,18,12,68)
	12 |	  syntax Int ::= csVisitTag(CSVisit) [function, klabel(csVisitTag)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 59 deprecated-klabel csVisitDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csVisitDecode)`, or replace it by `symbol(csVisitDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(13,22,13,74)
	13 |	  syntax CSVisit ::= csVisitDecode(Int) [function, klabel(csVisitDecode)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 60 deprecated-klabel csEncodeTask

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csEncodeTask)`, or replace it by `symbol(csEncodeTask)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(18,22,18,75)
	18 |	  syntax CTLanes ::= csEncodeTask(CSTask) [function,
klabel(csEncodeTask)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 61 deprecated-klabel csDecodeTask

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csDecodeTask)`, or replace it by `symbol(csDecodeTask)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(19,21,19,75)
	19 |	  syntax CSTask ::= csDecodeTask(CTLanes) [function,
klabel(csDecodeTask)]
	   .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 62 deprecated-klabel csTaskCount

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csTaskCount)`, or replace it by `symbol(csTaskCount)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(26,18,26,70)
	26 |	  syntax Int ::= csTaskCount(CSTasks) [function, klabel(csTaskCount)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 63 deprecated-klabel csEncodeTasks

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csEncodeTasks)`, or replace it by `symbol(csEncodeTasks)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(29,22,29,78)
	29 |	  syntax CTLanes ::= csEncodeTasks(CSTasks) [function,
klabel(csEncodeTasks)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 64 deprecated-klabel csReadTasks

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csReadTasks)`, or replace it by `symbol(csReadTasks)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(32,22,32,79)
	32 |	  syntax CSTasks ::= csReadTasks(Int, CTLanes) [function,
klabel(csReadTasks)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 65 deprecated-klabel csPackHelper

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csPackHelper)`, or replace it by `symbol(csPackHelper)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(35,22,35,83)
	35 |	  syntax CTLanes ::= csPackHelper(CSHelperTables) [function,
klabel(csPackHelper)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 66 deprecated-klabel csReadHelper

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csReadHelper)`, or replace it by `symbol(csReadHelper)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(37,29,37,83)
	37 |	  syntax CSHelperTables ::= csReadHelper(CTLanes) [function,
klabel(csReadHelper)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 67 deprecated-klabel csPackOwnedData

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csPackOwnedData)`, or replace it by `symbol(csPackOwnedData)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(39,22,39,83)
	39 |	  syntax CTLanes ::= csPackOwnedData(DPTables) [function,
klabel(csPackOwnedData)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 68 deprecated-klabel csDataFieldsBase

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csDataFieldsBase)`, or replace it by `symbol(csDataFieldsBase)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(41,18,41,80)
	41 |	  syntax Int ::= csDataFieldsBase(CTLanes) [function,
klabel(csDataFieldsBase)]
	   .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 69 deprecated-klabel csDataEnvBase

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csDataEnvBase)`, or replace it by `symbol(csDataEnvBase)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(43,18,43,74)
	43 |	  syntax Int ::= csDataEnvBase(CTLanes) [function, klabel(csDataEnvBase)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 70 deprecated-klabel csDataValuesBase

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csDataValuesBase)`, or replace it by `symbol(csDataValuesBase)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(45,18,45,80)
	45 |	  syntax Int ::= csDataValuesBase(CTLanes) [function,
klabel(csDataValuesBase)]
	   .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 71 deprecated-klabel csReadOwnedData

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csReadOwnedData)`, or replace it by `symbol(csReadOwnedData)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(47,23,47,83)
	47 |	  syntax DPTables ::= csReadOwnedData(CTLanes) [function,
klabel(csReadOwnedData)]
	   .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 72 deprecated-klabel csCapsLanes

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csCapsLanes)`, or replace it by `symbol(csCapsLanes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(49,22,49,73)
	49 |	  syntax CTLanes ::= csCapsLanes(CSCaps) [function, klabel(csCapsLanes)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 73 deprecated-klabel csContextCaps

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csContextCaps)`, or replace it by `symbol(csContextCaps)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(51,22,51,80)
	51 |	  syntax CTLanes ::= csContextCaps(CSContext) [function,
klabel(csContextCaps)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 74 deprecated-klabel csContextPresence

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csContextPresence)`, or replace it by `symbol(csContextPresence)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(53,18,53,84)
	53 |	  syntax Int ::= csContextPresence(CSContext) [function,
klabel(csContextPresence)]
	   .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 75 deprecated-klabel csPackState

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csPackState)`, or replace it by `symbol(csPackState)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(55,22,55,90)
	55 |	  syntax CTLanes ::= csPackState(CSContext, CSOwnedState) [function,
klabel(csPackState)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 76 deprecated-klabel csPackStateParts

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csPackStateParts)`, or replace it by `symbol(csPackStateParts)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(56,22,56,113)
	56 |	  syntax CTLanes ::= csPackStateParts(CSContext, CTLanes, CTLanes,
CTLanes) [function, klabel(csPackStateParts)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 77 deprecated-klabel csStateDataStart

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csStateDataStart)`, or replace it by `symbol(csStateDataStart)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(59,18,59,80)
	59 |	  syntax Int ::= csStateDataStart(CTLanes) [function,
klabel(csStateDataStart)]
	   .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 78 deprecated-klabel csStateHelperStart

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csStateHelperStart)`, or replace it by `symbol(csStateHelperStart)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(61,18,61,84)
	61 |	  syntax Int ::= csStateHelperStart(CTLanes) [function,
klabel(csStateHelperStart)]
	   .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 79 deprecated-klabel csReadState

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csReadState)`, or replace it by `symbol(csReadState)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(63,27,63,90)
	63 |	  syntax CSOwnedState ::= csReadState(CSContext, CTLanes) [function,
klabel(csReadState)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 80 deprecated-klabel csSpans

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csSpans)`, or replace it by `symbol(csSpans)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(65,26,65,80)
	65 |	  syntax CSTaskSpans ::= csSpans(Int, Int, CTLanes) [function,
klabel(csSpans)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 81 deprecated-klabel csChildren

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csChildren)`, or replace it by `symbol(csChildren)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(68,30,68,80)
	68 |	  syntax CSChildSections ::= csChildren(CTLanes) [function,
klabel(csChildren)]
	   .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 82 deprecated-klabel csObserveHelperRecord

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObserveHelperRecord)`, or replace it by
`symbol(csObserveHelperRecord)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(70,29,70,108)
	70 |	  syntax CSHelperRecord ::= csObserveHelperRecord(CHHelperOption)
[function, klabel(csObserveHelperRecord)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 83 deprecated-klabel csObserveHelperRecordEncoded

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObserveHelperRecordEncoded)`, or replace it by
`symbol(csObserveHelperRecordEncoded)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(71,29,71,115)
	71 |	  syntax CSHelperRecord ::= csObserveHelperRecordEncoded(CTLanes)
[function, klabel(csObserveHelperRecordEncoded)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 84 deprecated-klabel csObserveResultRecord

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObserveResultRecord)`, or replace it by
`symbol(csObserveResultRecord)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(74,29,74,108)
	74 |	  syntax CSResultRecord ::= csObserveResultRecord(CHResultOption)
[function, klabel(csObserveResultRecord)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 85 deprecated-klabel csObserveResultRecordEncoded

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObserveResultRecordEncoded)`, or replace it by
`symbol(csObserveResultRecordEncoded)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(75,29,75,115)
	75 |	  syntax CSResultRecord ::= csObserveResultRecordEncoded(CTLanes)
[function, klabel(csObserveResultRecordEncoded)]
	   .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 86 deprecated-klabel csObserveTaskRecord

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObserveTaskRecord)`, or replace it by `symbol(csObserveTaskRecord)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(78,27,78,94)
	78 |	  syntax CSTaskRecord ::= csObserveTaskRecord(CSTask) [function,
klabel(csObserveTaskRecord)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 87 deprecated-klabel csObserveTaskRecordEncoded

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObserveTaskRecordEncoded)`, or replace it by
`symbol(csObserveTaskRecordEncoded)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(79,27,79,109)
	79 |	  syntax CSTaskRecord ::= csObserveTaskRecordEncoded(CTLanes) [function,
klabel(csObserveTaskRecordEncoded)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 88 deprecated-klabel csObserveHelperSection

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObserveHelperSection)`, or replace it by
`symbol(csObserveHelperSection)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(82,30,82,111)
	82 |	  syntax CSHelperSection ::= csObserveHelperSection(CSHelperTables)
[function, klabel(csObserveHelperSection)]
	   .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 89 deprecated-klabel csObserveHelperSectionEncoded

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObserveHelperSectionEncoded)`, or replace it by
`symbol(csObserveHelperSectionEncoded)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(83,30,83,118)
	83 |	  syntax CSHelperSection ::= csObserveHelperSectionEncoded(CTLanes)
[function, klabel(csObserveHelperSectionEncoded)]
	   .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 90 deprecated-klabel csObserveState

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObserveState)`, or replace it by `symbol(csObserveState)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(86,33,86,107)
	86 |	  syntax CSStateObservation ::= csObserveState(CSContext, CSOwnedState)
[function, klabel(csObserveState)]
	   .	                               
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 91 deprecated-klabel csObserveStateEncoded

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObserveStateEncoded)`, or replace it by
`symbol(csObserveStateEncoded)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(87,33,87,116)
	87 |	  syntax CSStateObservation ::= csObserveStateEncoded(CSContext, CTLanes)
[function, klabel(csObserveStateEncoded)]
	   .	                               
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 92 deprecated-klabel csHelperIds

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperIds)`, or replace it by `symbol(csHelperIds)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(90,24,90,82)
	90 |	  syntax CSStrings ::= csHelperIds(CSHelperCases) [function,
klabel(csHelperIds)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 93 deprecated-klabel csObserveHelperCases

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObserveHelperCases)`, or replace it by
`symbol(csObserveHelperCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(93,30,93,106)
	93 |	  syntax CSHelperRecords ::= csObserveHelperCases(CSHelperCases)
[function, klabel(csObserveHelperCases)]
	   .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 94 deprecated-klabel csResultIds

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csResultIds)`, or replace it by `symbol(csResultIds)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(96,24,96,82)
	96 |	  syntax CSStrings ::= csResultIds(CSResultCases) [function,
klabel(csResultIds)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 95 deprecated-klabel csObserveResultCases

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObserveResultCases)`, or replace it by
`symbol(csObserveResultCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(99,30,99,106)
	99 |	  syntax CSResultRecords ::= csObserveResultCases(CSResultCases)
[function, klabel(csObserveResultCases)]
	   .	                            
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 96 deprecated-klabel csTaskIds

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csTaskIds)`, or replace it by `symbol(csTaskIds)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(102,24,102,76)
	102 |	  syntax CSStrings ::= csTaskIds(CSTaskCases) [function,
klabel(csTaskIds)]
	    .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 97 deprecated-klabel csObserveTaskCases

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObserveTaskCases)`, or replace it by `symbol(csObserveTaskCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(105,28,105,98)
	105 |	  syntax CSTaskRecords ::= csObserveTaskCases(CSTaskCases) [function,
klabel(csObserveTaskCases)]
	    .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 98 deprecated-klabel csHelperSectionIds

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csHelperSectionIds)`, or replace it by `symbol(csHelperSectionIds)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(108,24,108,103)
	108 |	  syntax CSStrings ::= csHelperSectionIds(CSHelperSectionCases)
[function, klabel(csHelperSectionIds)]
	    .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 99 deprecated-klabel csObserveHelperSectionCases

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObserveHelperSectionCases)`, or replace it by
`symbol(csObserveHelperSectionCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(111,31,111,128)
	111 |	  syntax CSHelperSections ::=
csObserveHelperSectionCases(CSHelperSectionCases) [function,
klabel(csObserveHelperSectionCases)]
	    .	                             
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 100 deprecated-klabel csStateIds

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csStateIds)`, or replace it by `symbol(csStateIds)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(114,24,114,79)
	114 |	  syntax CSStrings ::= csStateIds(CSStateCases) [function,
klabel(csStateIds)]
	    .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 101 deprecated-klabel csObserveStateCases

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObserveStateCases)`, or replace it by `symbol(csObserveStateCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(117,34,117,107)
	117 |	  syntax CSStateObservations ::= csObserveStateCases(CSStateCases)
[function, klabel(csObserveStateCases)]
	    .	                                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 102 deprecated-klabel csObserveAll

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(csObserveAll)`, or replace it by `symbol(csObserveAll)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-complete-positive-helper-task-state.k)
	Location(120,29,120,84)
	120 |	  syntax CSObservations ::= csObserveAll(CSCohort) [function,
klabel(csObserveAll)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 103 deprecated-klabel chSiteTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteTag)`, or replace it by `symbol(chSiteTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(11,18,11,65)
	11 |	  syntax Int ::= chSiteTag(CHSite) [function, klabel(chSiteTag)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 104 deprecated-klabel chSiteDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteDecode)`, or replace it by `symbol(chSiteDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(12,21,12,71)
	12 |	  syntax CHSite ::= chSiteDecode(Int) [function, klabel(chSiteDecode)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 105 deprecated-klabel chModeTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeTag)`, or replace it by `symbol(chModeTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(67,18,67,65)
	67 |	  syntax Int ::= chModeTag(CHMode) [function, klabel(chModeTag)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 106 deprecated-klabel chModeDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeDecode)`, or replace it by `symbol(chModeDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(68,21,68,71)
	68 |	  syntax CHMode ::= chModeDecode(Int) [function, klabel(chModeDecode)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 107 deprecated-klabel chScalarPhaseTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chScalarPhaseTag)`, or replace it by `symbol(chScalarPhaseTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(89,18,89,86)
	89 |	  syntax Int ::= chScalarPhaseTag(CHScalarPhase) [function,
klabel(chScalarPhaseTag)]
	   .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 108 deprecated-klabel chScalarPhaseDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chScalarPhaseDecode)`, or replace it by `symbol(chScalarPhaseDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(90,28,90,92)
	90 |	  syntax CHScalarPhase ::= chScalarPhaseDecode(Int) [function,
klabel(chScalarPhaseDecode)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 109 deprecated-klabel chNodeTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chNodeTag)`, or replace it by `symbol(chNodeTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(97,18,97,65)
	97 |	  syntax Int ::= chNodeTag(CHNode) [function, klabel(chNodeTag)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 110 deprecated-klabel chNodeDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chNodeDecode)`, or replace it by `symbol(chNodeDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(98,21,98,71)
	98 |	  syntax CHNode ::= chNodeDecode(Int) [function, klabel(chNodeDecode)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 111 deprecated-klabel chSelectorTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSelectorTag)`, or replace it by `symbol(chSelectorTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(105,18,105,77)
	105 |	  syntax Int ::= chSelectorTag(CHSelector) [function,
klabel(chSelectorTag)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 112 deprecated-klabel chSelectorDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSelectorDecode)`, or replace it by `symbol(chSelectorDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(106,25,106,83)
	106 |	  syntax CHSelector ::= chSelectorDecode(Int) [function,
klabel(chSelectorDecode)]
	    .	                       
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 113 deprecated-klabel chTriTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chTriTag)`, or replace it by `symbol(chTriTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(113,18,113,62)
	113 |	  syntax Int ::= chTriTag(CHTri) [function, klabel(chTriTag)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 114 deprecated-klabel chTriDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chTriDecode)`, or replace it by `symbol(chTriDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(114,20,114,68)
	114 |	  syntax CHTri ::= chTriDecode(Int) [function, klabel(chTriDecode)]
	    .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 115 deprecated-klabel chBindPhaseTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindPhaseTag)`, or replace it by `symbol(chBindPhaseTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(121,18,121,80)
	121 |	  syntax Int ::= chBindPhaseTag(CHBindPhase) [function,
klabel(chBindPhaseTag)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 116 deprecated-klabel chBindPhaseDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindPhaseDecode)`, or replace it by `symbol(chBindPhaseDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(122,26,122,86)
	122 |	  syntax CHBindPhase ::= chBindPhaseDecode(Int) [function,
klabel(chBindPhaseDecode)]
	    .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 117 deprecated-klabel chBindStatusTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindStatusTag)`, or replace it by `symbol(chBindStatusTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(135,18,135,83)
	135 |	  syntax Int ::= chBindStatusTag(CHBindStatus) [function,
klabel(chBindStatusTag)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 118 deprecated-klabel chBindStatusDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindStatusDecode)`, or replace it by `symbol(chBindStatusDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(136,27,136,89)
	136 |	  syntax CHBindStatus ::= chBindStatusDecode(Int) [function,
klabel(chBindStatusDecode)]
	    .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 119 deprecated-klabel chAppendPhaseTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chAppendPhaseTag)`, or replace it by `symbol(chAppendPhaseTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(141,18,141,86)
	141 |	  syntax Int ::= chAppendPhaseTag(CHAppendPhase) [function,
klabel(chAppendPhaseTag)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 120 deprecated-klabel chAppendPhaseDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chAppendPhaseDecode)`, or replace it by `symbol(chAppendPhaseDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(142,28,142,92)
	142 |	  syntax CHAppendPhase ::= chAppendPhaseDecode(Int) [function,
klabel(chAppendPhaseDecode)]
	    .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 121 deprecated-klabel chMatchPhaseTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseTag)`, or replace it by `symbol(chMatchPhaseTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(149,18,149,83)
	149 |	  syntax Int ::= chMatchPhaseTag(CHMatchPhase) [function,
klabel(chMatchPhaseTag)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 122 deprecated-klabel chMatchPhaseDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseDecode)`, or replace it by `symbol(chMatchPhaseDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(150,27,150,89)
	150 |	  syntax CHMatchPhase ::= chMatchPhaseDecode(Int) [function,
klabel(chMatchPhaseDecode)]
	    .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 123 deprecated-klabel chPlanPhaseTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPlanPhaseTag)`, or replace it by `symbol(chPlanPhaseTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(167,18,167,80)
	167 |	  syntax Int ::= chPlanPhaseTag(CHPlanPhase) [function,
klabel(chPlanPhaseTag)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 124 deprecated-klabel chPlanPhaseDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPlanPhaseDecode)`, or replace it by `symbol(chPlanPhaseDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(168,26,168,86)
	168 |	  syntax CHPlanPhase ::= chPlanPhaseDecode(Int) [function,
klabel(chPlanPhaseDecode)]
	    .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 125 deprecated-klabel chAfterWalkTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chAfterWalkTag)`, or replace it by `symbol(chAfterWalkTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(181,18,181,80)
	181 |	  syntax Int ::= chAfterWalkTag(CHAfterWalk) [function,
klabel(chAfterWalkTag)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 126 deprecated-klabel chAfterWalkDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chAfterWalkDecode)`, or replace it by `symbol(chAfterWalkDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(182,26,182,86)
	182 |	  syntax CHAfterWalk ::= chAfterWalkDecode(Int) [function,
klabel(chAfterWalkDecode)]
	    .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 127 deprecated-klabel chBuildPhaseTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBuildPhaseTag)`, or replace it by `symbol(chBuildPhaseTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(187,18,187,83)
	187 |	  syntax Int ::= chBuildPhaseTag(CHBuildPhase) [function,
klabel(chBuildPhaseTag)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 128 deprecated-klabel chBuildPhaseDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBuildPhaseDecode)`, or replace it by `symbol(chBuildPhaseDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(188,27,188,89)
	188 |	  syntax CHBuildPhase ::= chBuildPhaseDecode(Int) [function,
klabel(chBuildPhaseDecode)]
	    .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 129 deprecated-klabel chPatternTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPatternTag)`, or replace it by `symbol(chPatternTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(193,18,193,74)
	193 |	  syntax Int ::= chPatternTag(CHPattern) [function,
klabel(chPatternTag)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 130 deprecated-klabel chPatternDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPatternDecode)`, or replace it by `symbol(chPatternDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(194,24,194,80)
	194 |	  syntax CHPattern ::= chPatternDecode(Int) [function,
klabel(chPatternDecode)]
	    .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 131 deprecated-klabel chIndexTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chIndexTag)`, or replace it by `symbol(chIndexTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(209,18,209,68)
	209 |	  syntax Int ::= chIndexTag(CHIndex) [function, klabel(chIndexTag)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 132 deprecated-klabel chIndexIndex

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chIndexIndex)`, or replace it by `symbol(chIndexIndex)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(210,18,210,72)
	210 |	  syntax Int ::= chIndexIndex(CHIndex) [function, klabel(chIndexIndex)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 133 deprecated-klabel chIndexDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chIndexDecode)`, or replace it by `symbol(chIndexDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(211,22,211,79)
	211 |	  syntax CHIndex ::= chIndexDecode(Int, Int) [function,
klabel(chIndexDecode)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 134 deprecated-klabel chResumeTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResumeTag)`, or replace it by `symbol(chResumeTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(218,18,218,71)
	218 |	  syntax Int ::= chResumeTag(CHResume) [function, klabel(chResumeTag)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 135 deprecated-klabel chResumeIndex

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResumeIndex)`, or replace it by `symbol(chResumeIndex)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(219,18,219,75)
	219 |	  syntax Int ::= chResumeIndex(CHResume) [function,
klabel(chResumeIndex)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 136 deprecated-klabel chResumeDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResumeDecode)`, or replace it by `symbol(chResumeDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(220,23,220,82)
	220 |	  syntax CHResume ::= chResumeDecode(Int, Int) [function,
klabel(chResumeDecode)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 137 deprecated-klabel chTypeTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chTypeTag)`, or replace it by `symbol(chTypeTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(227,18,227,65)
	227 |	  syntax Int ::= chTypeTag(CHType) [function, klabel(chTypeTag)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 138 deprecated-klabel chTypeIndex

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chTypeIndex)`, or replace it by `symbol(chTypeIndex)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(228,18,228,69)
	228 |	  syntax Int ::= chTypeIndex(CHType) [function, klabel(chTypeIndex)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 139 deprecated-klabel chTypeDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chTypeDecode)`, or replace it by `symbol(chTypeDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(229,21,229,76)
	229 |	  syntax CHType ::= chTypeDecode(Int, Int) [function,
klabel(chTypeDecode)]
	    .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 140 deprecated-klabel chOptRefPresence

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chOptRefPresence)`, or replace it by `symbol(chOptRefPresence)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(236,18,236,81)
	236 |	  syntax Int ::= chOptRefPresence(CHOptRef) [function,
klabel(chOptRefPresence)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 141 deprecated-klabel chOptRefTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chOptRefTag)`, or replace it by `symbol(chOptRefTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(237,18,237,71)
	237 |	  syntax Int ::= chOptRefTag(CHOptRef) [function, klabel(chOptRefTag)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 142 deprecated-klabel chOptRefIndex

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chOptRefIndex)`, or replace it by `symbol(chOptRefIndex)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(238,18,238,75)
	238 |	  syntax Int ::= chOptRefIndex(CHOptRef) [function,
klabel(chOptRefIndex)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 143 deprecated-klabel chOptRefDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chOptRefDecode)`, or replace it by `symbol(chOptRefDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(239,23,239,87)
	239 |	  syntax CHOptRef ::= chOptRefDecode(Int, Int, Int) [function,
klabel(chOptRefDecode)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 144 deprecated-klabel chCommonLane0

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chCommonLane0)`, or replace it by `symbol(chCommonLane0)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(248,18,248,75)
	248 |	  syntax Int ::= chCommonLane0(CHCommon) [function,
klabel(chCommonLane0)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 145 unused-variable O

```text
[Warning] Compiler: Variable 'O' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(249,34,249,35)
	249 |	  rule chCommonLane0(chCommon(S, O, P)) => chSiteTag(S)
	    .	                                 ^
```

## 146 unused-variable P

```text
[Warning] Compiler: Variable 'P' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(249,37,249,38)
	249 |	  rule chCommonLane0(chCommon(S, O, P)) => chSiteTag(S)
	    .	                                    ^
```

## 147 deprecated-klabel chCommonLane1

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chCommonLane1)`, or replace it by `symbol(chCommonLane1)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(250,18,250,75)
	250 |	  syntax Int ::= chCommonLane1(CHCommon) [function,
klabel(chCommonLane1)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 148 unused-variable S

```text
[Warning] Compiler: Variable 'S' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(251,31,251,32)
	251 |	  rule chCommonLane1(chCommon(S, O, P)) => O
	    .	                              ^
```

## 149 unused-variable P

```text
[Warning] Compiler: Variable 'P' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(251,37,251,38)
	251 |	  rule chCommonLane1(chCommon(S, O, P)) => O
	    .	                                    ^
```

## 150 deprecated-klabel chCommonLane2

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chCommonLane2)`, or replace it by `symbol(chCommonLane2)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(252,18,252,75)
	252 |	  syntax Int ::= chCommonLane2(CHCommon) [function,
klabel(chCommonLane2)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 151 unused-variable S

```text
[Warning] Compiler: Variable 'S' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(253,31,253,32)
	253 |	  rule chCommonLane2(chCommon(S, O, P)) => chResumeTag(P)
	    .	                              ^
```

## 152 unused-variable O

```text
[Warning] Compiler: Variable 'O' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(253,34,253,35)
	253 |	  rule chCommonLane2(chCommon(S, O, P)) => chResumeTag(P)
	    .	                                 ^
```

## 153 deprecated-klabel chCommonLane3

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chCommonLane3)`, or replace it by `symbol(chCommonLane3)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(254,18,254,75)
	254 |	  syntax Int ::= chCommonLane3(CHCommon) [function,
klabel(chCommonLane3)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 154 unused-variable S

```text
[Warning] Compiler: Variable 'S' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(255,31,255,32)
	255 |	  rule chCommonLane3(chCommon(S, O, P)) => chResumeIndex(P)
	    .	                              ^
```

## 155 unused-variable O

```text
[Warning] Compiler: Variable 'O' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(255,34,255,35)
	255 |	  rule chCommonLane3(chCommon(S, O, P)) => chResumeIndex(P)
	    .	                                 ^
```

## 156 deprecated-klabel chStagedTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedTag)`, or replace it by `symbol(chStagedTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(257,18,257,71)
	257 |	  syntax Int ::= chStagedTag(CHStaged) [function, klabel(chStagedTag)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 157 deprecated-klabel chStagedPayload

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedPayload)`, or replace it by `symbol(chStagedPayload)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(258,18,258,79)
	258 |	  syntax Int ::= chStagedPayload(CHStaged) [function,
klabel(chStagedPayload)]
	    .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 158 deprecated-klabel chStagedDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedDecode)`, or replace it by `symbol(chStagedDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(259,23,259,82)
	259 |	  syntax CHStaged ::= chStagedDecode(Int, Int) [function,
klabel(chStagedDecode)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 159 unused-variable I

```text
[Warning] Compiler: Variable 'I' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(263,38,263,39)
	263 |	  rule chStagedTag(chStagedU128Value(I)) => 1
	    .	                                     ^
```

## 160 unused-variable B

```text
[Warning] Compiler: Variable 'B' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(266,38,266,39)
	266 |	  rule chStagedTag(chStagedBoolValue(B)) => 2
	    .	                                     ^
```

## 161 unused-variable T

```text
[Warning] Compiler: Variable 'T' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(269,40,269,41)
	269 |	  rule chStagedTag(chStagedPendingNode(T)) => 3
	    .	                                       ^
```

## 162 unused-variable C

```text
[Warning] Compiler: Variable 'C' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(272,38,272,39)
	272 |	  rule chStagedTag(chStagedPrimError(C)) => 4
	    .	                                     ^
```

## 163 unused-variable S

```text
[Warning] Compiler: Variable 'S' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(275,37,275,38)
	275 |	  rule chStagedTag(chStagedSelector(S)) => 5
	    .	                                    ^
```

## 164 unused-variable B

```text
[Warning] Compiler: Variable 'B' defined but not used. Prefix variable name
with underscore if this is intentional.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(278,37,278,38)
	278 |	  rule chStagedTag(chStagedTypeTest(B)) => 6
	    .	                                    ^
```

## 165 deprecated-klabel chEncodeHelper

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chEncodeHelper)`, or replace it by `symbol(chEncodeHelper)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(281,22,281,87)
	281 |	  syntax CTLanes ::= chEncodeHelper(CHHelperOption) [function,
klabel(chEncodeHelper)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 166 deprecated-klabel chDecodeHelper

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chDecodeHelper)`, or replace it by `symbol(chDecodeHelper)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(282,29,282,87)
	282 |	  syntax CHHelperOption ::= chDecodeHelper(CTLanes) [function,
klabel(chDecodeHelper)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 167 deprecated-klabel chEncodeResult

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chEncodeResult)`, or replace it by `symbol(chEncodeResult)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(285,22,285,87)
	285 |	  syntax CTLanes ::= chEncodeResult(CHResultOption) [function,
klabel(chEncodeResult)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 168 deprecated-klabel chDecodeResult

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chDecodeResult)`, or replace it by `symbol(chDecodeResult)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-codec.k)
	Location(286,29,286,87)
	286 |	  syntax CHResultOption ::= chDecodeResult(CTLanes) [function,
klabel(chDecodeResult)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 169 deprecated-klabel chSiteEvalLiteral

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalLiteral)`, or replace it by `symbol(chSiteEvalLiteral)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(5,21,5,68)
	5 |	  syntax CHSite ::= chSiteEvalLiteral() [klabel(chSiteEvalLiteral)]
	  .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 170 deprecated-klabel chSiteEvalVar

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalVar)`, or replace it by `symbol(chSiteEvalVar)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(6,21,6,60)
	6 |	  syntax CHSite ::= chSiteEvalVar() [klabel(chSiteEvalVar)]
	  .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 171 deprecated-klabel chSiteEvalLet

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalLet)`, or replace it by `symbol(chSiteEvalLet)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(7,21,7,60)
	7 |	  syntax CHSite ::= chSiteEvalLet() [klabel(chSiteEvalLet)]
	  .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 172 deprecated-klabel chSiteEvalBinary

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalBinary)`, or replace it by `symbol(chSiteEvalBinary)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(8,21,8,66)
	8 |	  syntax CHSite ::= chSiteEvalBinary() [klabel(chSiteEvalBinary)]
	  .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 173 deprecated-klabel chSiteEvalUnary

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalUnary)`, or replace it by `symbol(chSiteEvalUnary)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(9,21,9,64)
	9 |	  syntax CHSite ::= chSiteEvalUnary() [klabel(chSiteEvalUnary)]
	  .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 174 deprecated-klabel chSiteEvalIf

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalIf)`, or replace it by `symbol(chSiteEvalIf)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(10,21,10,58)
	10 |	  syntax CHSite ::= chSiteEvalIf() [klabel(chSiteEvalIf)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 175 deprecated-klabel chSiteEvalMatch

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalMatch)`, or replace it by `symbol(chSiteEvalMatch)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(11,21,11,64)
	11 |	  syntax CHSite ::= chSiteEvalMatch() [klabel(chSiteEvalMatch)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 176 deprecated-klabel chSiteEvalCall

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalCall)`, or replace it by `symbol(chSiteEvalCall)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(12,21,12,62)
	12 |	  syntax CHSite ::= chSiteEvalCall() [klabel(chSiteEvalCall)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 177 deprecated-klabel chSitePush

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSitePush)`, or replace it by `symbol(chSitePush)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(13,21,13,54)
	13 |	  syntax CHSite ::= chSitePush() [klabel(chSitePush)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 178 deprecated-klabel chSiteRetLet

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetLet)`, or replace it by `symbol(chSiteRetLet)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(14,21,14,58)
	14 |	  syntax CHSite ::= chSiteRetLet() [klabel(chSiteRetLet)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 179 deprecated-klabel chSiteRetLeft

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetLeft)`, or replace it by `symbol(chSiteRetLeft)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(15,21,15,60)
	15 |	  syntax CHSite ::= chSiteRetLeft() [klabel(chSiteRetLeft)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 180 deprecated-klabel chSiteRetRight

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetRight)`, or replace it by `symbol(chSiteRetRight)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(16,21,16,62)
	16 |	  syntax CHSite ::= chSiteRetRight() [klabel(chSiteRetRight)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 181 deprecated-klabel chSiteRetUnary

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetUnary)`, or replace it by `symbol(chSiteRetUnary)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(17,21,17,62)
	17 |	  syntax CHSite ::= chSiteRetUnary() [klabel(chSiteRetUnary)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 182 deprecated-klabel chSiteRetIf

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetIf)`, or replace it by `symbol(chSiteRetIf)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(18,21,18,56)
	18 |	  syntax CHSite ::= chSiteRetIf() [klabel(chSiteRetIf)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 183 deprecated-klabel chSiteRetMatch

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetMatch)`, or replace it by `symbol(chSiteRetMatch)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(19,21,19,62)
	19 |	  syntax CHSite ::= chSiteRetMatch() [klabel(chSiteRetMatch)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 184 deprecated-klabel chSiteRetArgs

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetArgs)`, or replace it by `symbol(chSiteRetArgs)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(20,21,20,60)
	20 |	  syntax CHSite ::= chSiteRetArgs() [klabel(chSiteRetArgs)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 185 deprecated-klabel chSiteRetCall

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetCall)`, or replace it by `symbol(chSiteRetCall)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(21,21,21,60)
	21 |	  syntax CHSite ::= chSiteRetCall() [klabel(chSiteRetCall)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 186 deprecated-klabel chSiteRetScope

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetScope)`, or replace it by `symbol(chSiteRetScope)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(22,21,22,62)
	22 |	  syntax CHSite ::= chSiteRetScope() [klabel(chSiteRetScope)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 187 deprecated-klabel chSiteInvoke

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteInvoke)`, or replace it by `symbol(chSiteInvoke)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(23,21,23,58)
	23 |	  syntax CHSite ::= chSiteInvoke() [klabel(chSiteInvoke)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 188 deprecated-klabel chSiteEnter

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEnter)`, or replace it by `symbol(chSiteEnter)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(24,21,24,56)
	24 |	  syntax CHSite ::= chSiteEnter() [klabel(chSiteEnter)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 189 deprecated-klabel chSiteBound

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteBound)`, or replace it by `symbol(chSiteBound)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(25,21,25,56)
	25 |	  syntax CHSite ::= chSiteBound() [klabel(chSiteBound)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 190 deprecated-klabel chSiteCases

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteCases)`, or replace it by `symbol(chSiteCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(26,21,26,56)
	26 |	  syntax CHSite ::= chSiteCases() [klabel(chSiteCases)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 191 deprecated-klabel chSiteCaseResult

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteCaseResult)`, or replace it by `symbol(chSiteCaseResult)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(27,21,27,66)
	27 |	  syntax CHSite ::= chSiteCaseResult() [klabel(chSiteCaseResult)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 192 deprecated-klabel chSitePrim

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSitePrim)`, or replace it by `symbol(chSitePrim)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(28,21,28,54)
	28 |	  syntax CHSite ::= chSitePrim() [klabel(chSitePrim)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 193 deprecated-klabel chSiteEvalConstruct

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteEvalConstruct)`, or replace it by `symbol(chSiteEvalConstruct)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(29,21,29,72)
	29 |	  syntax CHSite ::= chSiteEvalConstruct() [klabel(chSiteEvalConstruct)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 194 deprecated-klabel chSiteRetCtorFields

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteRetCtorFields)`, or replace it by `symbol(chSiteRetCtorFields)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(30,21,30,72)
	30 |	  syntax CHSite ::= chSiteRetCtorFields() [klabel(chSiteRetCtorFields)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 195 deprecated-klabel chSiteMaterialize

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSiteMaterialize)`, or replace it by `symbol(chSiteMaterialize)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(31,21,31,68)
	31 |	  syntax CHSite ::= chSiteMaterialize() [klabel(chSiteMaterialize)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 196 deprecated-klabel chModeAdd

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeAdd)`, or replace it by `symbol(chModeAdd)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(32,21,32,52)
	32 |	  syntax CHMode ::= chModeAdd() [klabel(chModeAdd)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 197 deprecated-klabel chModeSub

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeSub)`, or replace it by `symbol(chModeSub)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(33,21,33,52)
	33 |	  syntax CHMode ::= chModeSub() [klabel(chModeSub)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 198 deprecated-klabel chModeMul

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeMul)`, or replace it by `symbol(chModeMul)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(34,21,34,52)
	34 |	  syntax CHMode ::= chModeMul() [klabel(chModeMul)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 199 deprecated-klabel chModeLt

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeLt)`, or replace it by `symbol(chModeLt)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(35,21,35,50)
	35 |	  syntax CHMode ::= chModeLt() [klabel(chModeLt)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 200 deprecated-klabel chModeCons

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeCons)`, or replace it by `symbol(chModeCons)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(36,21,36,54)
	36 |	  syntax CHMode ::= chModeCons() [klabel(chModeCons)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 201 deprecated-klabel chModeBranch

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeBranch)`, or replace it by `symbol(chModeBranch)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(37,21,37,58)
	37 |	  syntax CHMode ::= chModeBranch() [klabel(chModeBranch)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 202 deprecated-klabel chModeLeaf

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeLeaf)`, or replace it by `symbol(chModeLeaf)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(38,21,38,54)
	38 |	  syntax CHMode ::= chModeLeaf() [klabel(chModeLeaf)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 203 deprecated-klabel chModeNot

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeNot)`, or replace it by `symbol(chModeNot)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(39,21,39,52)
	39 |	  syntax CHMode ::= chModeNot() [klabel(chModeNot)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 204 deprecated-klabel chModeTestBool

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeTestBool)`, or replace it by `symbol(chModeTestBool)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(40,21,40,62)
	40 |	  syntax CHMode ::= chModeTestBool() [klabel(chModeTestBool)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 205 deprecated-klabel chModeTestType

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chModeTestType)`, or replace it by `symbol(chModeTestType)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(41,21,41,62)
	41 |	  syntax CHMode ::= chModeTestType() [klabel(chModeTestType)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 206 deprecated-klabel chScalarPhaseFirst

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chScalarPhaseFirst)`, or replace it by `symbol(chScalarPhaseFirst)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(42,28,42,77)
	42 |	  syntax CHScalarPhase ::= chScalarPhaseFirst()
[klabel(chScalarPhaseFirst)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 207 deprecated-klabel chScalarPhaseSecond

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chScalarPhaseSecond)`, or replace it by `symbol(chScalarPhaseSecond)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(43,28,43,79)
	43 |	  syntax CHScalarPhase ::= chScalarPhaseSecond()
[klabel(chScalarPhaseSecond)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 208 deprecated-klabel chScalarPhaseDone

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chScalarPhaseDone)`, or replace it by `symbol(chScalarPhaseDone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(44,28,44,75)
	44 |	  syntax CHScalarPhase ::= chScalarPhaseDone()
[klabel(chScalarPhaseDone)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 209 deprecated-klabel chNodeCons

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chNodeCons)`, or replace it by `symbol(chNodeCons)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(45,21,45,54)
	45 |	  syntax CHNode ::= chNodeCons() [klabel(chNodeCons)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 210 deprecated-klabel chNodeLeaf

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chNodeLeaf)`, or replace it by `symbol(chNodeLeaf)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(46,21,46,54)
	46 |	  syntax CHNode ::= chNodeLeaf() [klabel(chNodeLeaf)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 211 deprecated-klabel chNodeBranch

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chNodeBranch)`, or replace it by `symbol(chNodeBranch)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(47,21,47,58)
	47 |	  syntax CHNode ::= chNodeBranch() [klabel(chNodeBranch)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 212 deprecated-klabel chSelectorTrue

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSelectorTrue)`, or replace it by `symbol(chSelectorTrue)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(48,25,48,66)
	48 |	  syntax CHSelector ::= chSelectorTrue() [klabel(chSelectorTrue)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 213 deprecated-klabel chSelectorFalse

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSelectorFalse)`, or replace it by `symbol(chSelectorFalse)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(49,25,49,68)
	49 |	  syntax CHSelector ::= chSelectorFalse() [klabel(chSelectorFalse)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 214 deprecated-klabel chSelectorNotBool

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSelectorNotBool)`, or replace it by `symbol(chSelectorNotBool)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(50,25,50,72)
	50 |	  syntax CHSelector ::= chSelectorNotBool() [klabel(chSelectorNotBool)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 215 deprecated-klabel chTriPending

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chTriPending)`, or replace it by `symbol(chTriPending)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(51,20,51,57)
	51 |	  syntax CHTri ::= chTriPending() [klabel(chTriPending)]
	   .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 216 deprecated-klabel chTriPositive

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chTriPositive)`, or replace it by `symbol(chTriPositive)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(52,20,52,59)
	52 |	  syntax CHTri ::= chTriPositive() [klabel(chTriPositive)]
	   .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 217 deprecated-klabel chTriNegative

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chTriNegative)`, or replace it by `symbol(chTriNegative)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(53,20,53,59)
	53 |	  syntax CHTri ::= chTriNegative() [klabel(chTriNegative)]
	   .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 218 deprecated-klabel chBindPhasePairing

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindPhasePairing)`, or replace it by `symbol(chBindPhasePairing)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(54,26,54,75)
	54 |	  syntax CHBindPhase ::= chBindPhasePairing()
[klabel(chBindPhasePairing)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 219 deprecated-klabel chBindPhaseUnwindType

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindPhaseUnwindType)`, or replace it by
`symbol(chBindPhaseUnwindType)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(55,26,55,81)
	55 |	  syntax CHBindPhase ::= chBindPhaseUnwindType()
[klabel(chBindPhaseUnwindType)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 220 deprecated-klabel chBindPhaseUnwindDup

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindPhaseUnwindDup)`, or replace it by
`symbol(chBindPhaseUnwindDup)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(56,26,56,79)
	56 |	  syntax CHBindPhase ::= chBindPhaseUnwindDup()
[klabel(chBindPhaseUnwindDup)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 221 deprecated-klabel chBindPhaseUnwindInsert

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindPhaseUnwindInsert)`, or replace it by
`symbol(chBindPhaseUnwindInsert)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(57,26,57,85)
	57 |	  syntax CHBindPhase ::= chBindPhaseUnwindInsert()
[klabel(chBindPhaseUnwindInsert)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 222 deprecated-klabel chBindPhasePropagate

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindPhasePropagate)`, or replace it by
`symbol(chBindPhasePropagate)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(58,26,58,79)
	58 |	  syntax CHBindPhase ::= chBindPhasePropagate()
[klabel(chBindPhasePropagate)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 223 deprecated-klabel chBindPhaseFinished

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindPhaseFinished)`, or replace it by `symbol(chBindPhaseFinished)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(59,26,59,77)
	59 |	  syntax CHBindPhase ::= chBindPhaseFinished()
[klabel(chBindPhaseFinished)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 224 deprecated-klabel chBindStatusOk

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindStatusOk)`, or replace it by `symbol(chBindStatusOk)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(60,27,60,68)
	60 |	  syntax CHBindStatus ::= chBindStatusOk() [klabel(chBindStatusOk)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 225 deprecated-klabel chBindStatusBad

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBindStatusBad)`, or replace it by `symbol(chBindStatusBad)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(61,27,61,70)
	61 |	  syntax CHBindStatus ::= chBindStatusBad() [klabel(chBindStatusBad)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 226 deprecated-klabel chAppendPhaseCopy

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chAppendPhaseCopy)`, or replace it by `symbol(chAppendPhaseCopy)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(62,28,62,75)
	62 |	  syntax CHAppendPhase ::= chAppendPhaseCopy()
[klabel(chAppendPhaseCopy)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 227 deprecated-klabel chAppendPhaseTail

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chAppendPhaseTail)`, or replace it by `symbol(chAppendPhaseTail)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(63,28,63,75)
	63 |	  syntax CHAppendPhase ::= chAppendPhaseTail()
[klabel(chAppendPhaseTail)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 228 deprecated-klabel chAppendPhaseDone

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chAppendPhaseDone)`, or replace it by `symbol(chAppendPhaseDone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(64,28,64,75)
	64 |	  syntax CHAppendPhase ::= chAppendPhaseDone()
[klabel(chAppendPhaseDone)]
	   .	                          
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 229 deprecated-klabel chMatchPhaseArm

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseArm)`, or replace it by `symbol(chMatchPhaseArm)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(65,27,65,70)
	65 |	  syntax CHMatchPhase ::= chMatchPhaseArm() [klabel(chMatchPhaseArm)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 230 deprecated-klabel chMatchPhaseTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseTag)`, or replace it by `symbol(chMatchPhaseTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(66,27,66,70)
	66 |	  syntax CHMatchPhase ::= chMatchPhaseTag() [klabel(chMatchPhaseTag)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 231 deprecated-klabel chMatchPhaseDistinct

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseDistinct)`, or replace it by
`symbol(chMatchPhaseDistinct)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(67,27,67,80)
	67 |	  syntax CHMatchPhase ::= chMatchPhaseDistinct()
[klabel(chMatchPhaseDistinct)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 232 deprecated-klabel chMatchPhaseField

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseField)`, or replace it by `symbol(chMatchPhaseField)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(68,27,68,74)
	68 |	  syntax CHMatchPhase ::= chMatchPhaseField() [klabel(chMatchPhaseField)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 233 deprecated-klabel chMatchPhaseBind

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseBind)`, or replace it by `symbol(chMatchPhaseBind)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(69,27,69,72)
	69 |	  syntax CHMatchPhase ::= chMatchPhaseBind() [klabel(chMatchPhaseBind)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 234 deprecated-klabel chMatchPhaseReady

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseReady)`, or replace it by `symbol(chMatchPhaseReady)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(70,27,70,74)
	70 |	  syntax CHMatchPhase ::= chMatchPhaseReady() [klabel(chMatchPhaseReady)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 235 deprecated-klabel chMatchPhaseNoMatchReady

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseNoMatchReady)`, or replace it by
`symbol(chMatchPhaseNoMatchReady)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(71,27,71,88)
	71 |	  syntax CHMatchPhase ::= chMatchPhaseNoMatchReady()
[klabel(chMatchPhaseNoMatchReady)]
	   .	                         
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 236 deprecated-klabel chMatchPhaseDone

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatchPhaseDone)`, or replace it by `symbol(chMatchPhaseDone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(72,27,72,72)
	72 |	  syntax CHMatchPhase ::= chMatchPhaseDone() [klabel(chMatchPhaseDone)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 237 deprecated-klabel chPlanPhaseWalk

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPlanPhaseWalk)`, or replace it by `symbol(chPlanPhaseWalk)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(73,26,73,69)
	73 |	  syntax CHPlanPhase ::= chPlanPhaseWalk() [klabel(chPlanPhaseWalk)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 238 deprecated-klabel chPlanPhaseTest

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPlanPhaseTest)`, or replace it by `symbol(chPlanPhaseTest)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(74,26,74,69)
	74 |	  syntax CHPlanPhase ::= chPlanPhaseTest() [klabel(chPlanPhaseTest)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 239 deprecated-klabel chPlanPhaseBind

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPlanPhaseBind)`, or replace it by `symbol(chPlanPhaseBind)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(75,26,75,69)
	75 |	  syntax CHPlanPhase ::= chPlanPhaseBind() [klabel(chPlanPhaseBind)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 240 deprecated-klabel chPlanPhaseReady

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPlanPhaseReady)`, or replace it by `symbol(chPlanPhaseReady)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(76,26,76,71)
	76 |	  syntax CHPlanPhase ::= chPlanPhaseReady() [klabel(chPlanPhaseReady)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 241 deprecated-klabel chPlanPhaseNoMatchReady

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPlanPhaseNoMatchReady)`, or replace it by
`symbol(chPlanPhaseNoMatchReady)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(77,26,77,85)
	77 |	  syntax CHPlanPhase ::= chPlanPhaseNoMatchReady()
[klabel(chPlanPhaseNoMatchReady)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 242 deprecated-klabel chPlanPhaseDone

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPlanPhaseDone)`, or replace it by `symbol(chPlanPhaseDone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(78,26,78,69)
	78 |	  syntax CHPlanPhase ::= chPlanPhaseDone() [klabel(chPlanPhaseDone)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 243 deprecated-klabel chAfterWalkTest

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chAfterWalkTest)`, or replace it by `symbol(chAfterWalkTest)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(79,26,79,69)
	79 |	  syntax CHAfterWalk ::= chAfterWalkTest() [klabel(chAfterWalkTest)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 244 deprecated-klabel chAfterWalkBind

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chAfterWalkBind)`, or replace it by `symbol(chAfterWalkBind)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(80,26,80,69)
	80 |	  syntax CHAfterWalk ::= chAfterWalkBind() [klabel(chAfterWalkBind)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 245 deprecated-klabel chBuildPhaseCopy

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBuildPhaseCopy)`, or replace it by `symbol(chBuildPhaseCopy)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(81,27,81,72)
	81 |	  syntax CHBuildPhase ::= chBuildPhaseCopy() [klabel(chBuildPhaseCopy)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 246 deprecated-klabel chBuildPhaseDone

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBuildPhaseDone)`, or replace it by `symbol(chBuildPhaseDone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(82,27,82,72)
	82 |	  syntax CHBuildPhase ::= chBuildPhaseDone() [klabel(chBuildPhaseDone)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 247 deprecated-klabel chPatternPVar

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPatternPVar)`, or replace it by `symbol(chPatternPVar)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(83,24,83,63)
	83 |	  syntax CHPattern ::= chPatternPVar() [klabel(chPatternPVar)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 248 deprecated-klabel chPatternPNil

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPatternPNil)`, or replace it by `symbol(chPatternPNil)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(84,24,84,63)
	84 |	  syntax CHPattern ::= chPatternPNil() [klabel(chPatternPNil)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 249 deprecated-klabel chPatternPCons

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPatternPCons)`, or replace it by `symbol(chPatternPCons)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(85,24,85,65)
	85 |	  syntax CHPattern ::= chPatternPCons() [klabel(chPatternPCons)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 250 deprecated-klabel chPatternPLeaf

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPatternPLeaf)`, or replace it by `symbol(chPatternPLeaf)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(86,24,86,65)
	86 |	  syntax CHPattern ::= chPatternPLeaf() [klabel(chPatternPLeaf)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 251 deprecated-klabel chPatternPBranch

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPatternPBranch)`, or replace it by `symbol(chPatternPBranch)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(87,24,87,69)
	87 |	  syntax CHPattern ::= chPatternPBranch() [klabel(chPatternPBranch)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 252 deprecated-klabel chPatternWildcardExtensionReserved

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPatternWildcardExtensionReserved)`, or replace it by
`symbol(chPatternWildcardExtensionReserved)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(88,24,88,105)
	88 |	  syntax CHPattern ::= chPatternWildcardExtensionReserved()
[klabel(chPatternWildcardExtensionReserved)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 253 deprecated-klabel chPatternConstructorExtensionReserved

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPatternConstructorExtensionReserved)`, or replace it by
`symbol(chPatternConstructorExtensionReserved)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(89,24,89,111)
	89 |	  syntax CHPattern ::= chPatternConstructorExtensionReserved()
[klabel(chPatternConstructorExtensionReserved)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 254 deprecated-klabel chIndexNone

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chIndexNone)`, or replace it by `symbol(chIndexNone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(90,22,90,57)
	90 |	  syntax CHIndex ::= chIndexNone() [klabel(chIndexNone)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 255 deprecated-klabel chIndexSome

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chIndexSome)`, or replace it by `symbol(chIndexSome)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(91,22,91,60)
	91 |	  syntax CHIndex ::= chIndexSome(Int) [klabel(chIndexSome)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 256 deprecated-klabel chResumeNone

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResumeNone)`, or replace it by `symbol(chResumeNone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(92,23,92,60)
	92 |	  syntax CHResume ::= chResumeNone() [klabel(chResumeNone)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 257 deprecated-klabel chResumeSome

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResumeSome)`, or replace it by `symbol(chResumeSome)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(93,23,93,63)
	93 |	  syntax CHResume ::= chResumeSome(Int) [klabel(chResumeSome)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 258 deprecated-klabel chTypeNone

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chTypeNone)`, or replace it by `symbol(chTypeNone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(94,21,94,54)
	94 |	  syntax CHType ::= chTypeNone() [klabel(chTypeNone)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 259 deprecated-klabel chTypeSome

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chTypeSome)`, or replace it by `symbol(chTypeSome)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(95,21,95,57)
	95 |	  syntax CHType ::= chTypeSome(Int) [klabel(chTypeSome)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 260 deprecated-klabel chRefNone

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chRefNone)`, or replace it by `symbol(chRefNone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(96,23,96,54)
	96 |	  syntax CHOptRef ::= chRefNone() [klabel(chRefNone)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 261 deprecated-klabel chRefSome

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chRefSome)`, or replace it by `symbol(chRefSome)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(97,23,97,59)
	97 |	  syntax CHOptRef ::= chRefSome(CTRef) [klabel(chRefSome)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 262 deprecated-klabel chCommon

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chCommon)`, or replace it by `symbol(chCommon)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(98,23,98,73)
	98 |	  syntax CHCommon ::= chCommon(CHSite, Int, CHResume) [klabel(chCommon)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 263 deprecated-klabel chStagedNone

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedNone)`, or replace it by `symbol(chStagedNone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(99,23,99,60)
	99 |	  syntax CHStaged ::= chStagedNone() [klabel(chStagedNone)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 264 deprecated-klabel chStagedU128Value

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedU128Value)`, or replace it by `symbol(chStagedU128Value)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(100,23,100,73)
	100 |	  syntax CHStaged ::= chStagedU128Value(Int) [klabel(chStagedU128Value)]
	    .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 265 deprecated-klabel chStagedBoolValue

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedBoolValue)`, or replace it by `symbol(chStagedBoolValue)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(101,23,101,74)
	101 |	  syntax CHStaged ::= chStagedBoolValue(Bool)
[klabel(chStagedBoolValue)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 266 deprecated-klabel chStagedPendingNode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedPendingNode)`, or replace it by `symbol(chStagedPendingNode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(102,23,102,80)
	102 |	  syntax CHStaged ::= chStagedPendingNode(CHNode)
[klabel(chStagedPendingNode)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 267 deprecated-klabel chStagedPrimError

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedPrimError)`, or replace it by `symbol(chStagedPrimError)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(103,23,103,73)
	103 |	  syntax CHStaged ::= chStagedPrimError(Int) [klabel(chStagedPrimError)]
	    .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 268 deprecated-klabel chStagedSelector

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedSelector)`, or replace it by `symbol(chStagedSelector)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(104,23,104,78)
	104 |	  syntax CHStaged ::= chStagedSelector(CHSelector)
[klabel(chStagedSelector)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 269 deprecated-klabel chStagedTypeTest

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chStagedTypeTest)`, or replace it by `symbol(chStagedTypeTest)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(105,23,105,72)
	105 |	  syntax CHStaged ::= chStagedTypeTest(Bool) [klabel(chStagedTypeTest)]
	    .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 270 deprecated-klabel chScalar

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chScalar)`, or replace it by `symbol(chScalar)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(106,23,106,123)
	106 |	  syntax CHHelper ::= chScalar(CHCommon, CHMode, CTRef, CHOptRef,
CHType, CHScalarPhase, Int, CHStaged) [klabel(chScalar)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 271 deprecated-klabel chEnvGet

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chEnvGet)`, or replace it by `symbol(chEnvGet)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(107,23,107,91)
	107 |	  syntax CHHelper ::= chEnvGet(CHCommon, Int, CHIndex, CHOptRef, CHTri)
[klabel(chEnvGet)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 272 deprecated-klabel chEnvPut

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chEnvPut)`, or replace it by `symbol(chEnvPut)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(108,23,108,95)
	108 |	  syntax CHHelper ::= chEnvPut(CHCommon, Int, CTRef, CTEnv, CHIndex,
CHTri) [klabel(chEnvPut)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 273 deprecated-klabel chFind

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chFind)`, or replace it by `symbol(chFind)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(109,23,109,82)
	109 |	  syntax CHHelper ::= chFind(CHCommon, Int, Int, CHIndex, CHTri)
[klabel(chFind)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 274 deprecated-klabel chBind

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBind)`, or replace it by `symbol(chBind)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(110,23,110,132)
	110 |	  syntax CHHelper ::= chBind(CHCommon, Int, CTSlice, CTSlice, Int, Int,
CTEnv, CHIndex, CHBindPhase, CHBindStatus) [klabel(chBind)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 275 deprecated-klabel chAppend

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chAppend)`, or replace it by `symbol(chAppend)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(111,23,111,111)
	111 |	  syntax CHHelper ::= chAppend(CHCommon, CTSlice, CTRef, Int, Int,
CHOptRef, CHAppendPhase) [klabel(chAppend)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 276 deprecated-klabel chValidate

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chValidate)`, or replace it by `symbol(chValidate)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(112,23,112,78)
	112 |	  syntax CHHelper ::= chValidate(CHCommon, CTRef, CHTri)
[klabel(chValidate)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 277 deprecated-klabel chEqual

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chEqual)`, or replace it by `symbol(chEqual)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(113,23,113,79)
	113 |	  syntax CHHelper ::= chEqual(CHCommon, CTRef, CTRef, CHTri)
[klabel(chEqual)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 278 deprecated-klabel chMatch

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chMatch)`, or replace it by `symbol(chMatch)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(114,23,114,141)
	114 |	  syntax CHHelper ::= chMatch(CHCommon, CTRef, Int, CTEnv, CTEnv,
CHPattern, Int, Int, Int, CHOptRef, CHMatchPhase, CHTri) [klabel(chMatch)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 279 deprecated-klabel chPlan

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chPlan)`, or replace it by `symbol(chPlan)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(115,23,115,150)
	115 |	  syntax CHHelper ::= chPlan(CHCommon, Int, CTRef, CTEnv, CTEnv, Int,
CHPlanPhase, CHAfterWalk, CTRef, CTSlice, Int, CHIndex, CHTri) [klabel(chPlan)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 280 deprecated-klabel chBuild

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chBuild)`, or replace it by `symbol(chBuild)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(116,23,116,121)
	116 |	  syntax CHHelper ::= chBuild(CHCommon, Int, Int, CTSlice, Int, Int,
CHOptRef, CHOptRef, CHBuildPhase) [klabel(chBuild)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 281 deprecated-klabel chResultValidated

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultValidated)`, or replace it by `symbol(chResultValidated)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(117,23,117,74)
	117 |	  syntax CHResult ::= chResultValidated(Bool)
[klabel(chResultValidated)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 282 deprecated-klabel chResultEnvFound

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultEnvFound)`, or replace it by `symbol(chResultEnvFound)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(118,23,118,73)
	118 |	  syntax CHResult ::= chResultEnvFound(CTRef) [klabel(chResultEnvFound)]
	    .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 283 deprecated-klabel chResultEnvMissing

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultEnvMissing)`, or replace it by `symbol(chResultEnvMissing)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(119,23,119,72)
	119 |	  syntax CHResult ::= chResultEnvMissing() [klabel(chResultEnvMissing)]
	    .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 284 deprecated-klabel chResultEnvUpdated

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultEnvUpdated)`, or replace it by `symbol(chResultEnvUpdated)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(120,23,120,75)
	120 |	  syntax CHResult ::= chResultEnvUpdated(Int)
[klabel(chResultEnvUpdated)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 285 deprecated-klabel chResultFindFound

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultFindFound)`, or replace it by `symbol(chResultFindFound)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(121,23,121,73)
	121 |	  syntax CHResult ::= chResultFindFound(Int) [klabel(chResultFindFound)]
	    .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 286 deprecated-klabel chResultFindMissing

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultFindMissing)`, or replace it by `symbol(chResultFindMissing)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(122,23,122,74)
	122 |	  syntax CHResult ::= chResultFindMissing()
[klabel(chResultFindMissing)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 287 deprecated-klabel chResultBindOk

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultBindOk)`, or replace it by `symbol(chResultBindOk)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(123,23,123,69)
	123 |	  syntax CHResult ::= chResultBindOk(CTEnv) [klabel(chResultBindOk)]
	    .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 288 deprecated-klabel chResultBindBad

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultBindBad)`, or replace it by `symbol(chResultBindBad)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(124,23,124,66)
	124 |	  syntax CHResult ::= chResultBindBad() [klabel(chResultBindBad)]
	    .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 289 deprecated-klabel chResultAppendDone

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultAppendDone)`, or replace it by `symbol(chResultAppendDone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(125,23,125,79)
	125 |	  syntax CHResult ::= chResultAppendDone(CTSlice)
[klabel(chResultAppendDone)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 290 deprecated-klabel chResultScalarValue

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultScalarValue)`, or replace it by `symbol(chResultScalarValue)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(126,23,126,79)
	126 |	  syntax CHResult ::= chResultScalarValue(CTRef)
[klabel(chResultScalarValue)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 291 deprecated-klabel chResultScalarError

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultScalarError)`, or replace it by `symbol(chResultScalarError)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(127,23,127,77)
	127 |	  syntax CHResult ::= chResultScalarError(Int)
[klabel(chResultScalarError)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 292 deprecated-klabel chResultScalarSelector

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultScalarSelector)`, or replace it by
`symbol(chResultScalarSelector)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(128,23,128,90)
	128 |	  syntax CHResult ::= chResultScalarSelector(CHSelector)
[klabel(chResultScalarSelector)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 293 deprecated-klabel chResultScalarTypeTest

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultScalarTypeTest)`, or replace it by
`symbol(chResultScalarTypeTest)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(129,23,129,84)
	129 |	  syntax CHResult ::= chResultScalarTypeTest(Bool)
[klabel(chResultScalarTypeTest)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 294 deprecated-klabel chResultEqualDone

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultEqualDone)`, or replace it by `symbol(chResultEqualDone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(130,23,130,75)
	130 |	  syntax CHResult ::= chResultEqualDone(CTRef)
[klabel(chResultEqualDone)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 295 deprecated-klabel chResultMatchMatched

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultMatchMatched)`, or replace it by
`symbol(chResultMatchMatched)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(131,23,131,81)
	131 |	  syntax CHResult ::= chResultMatchMatched(CTEnv)
[klabel(chResultMatchMatched)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 296 deprecated-klabel chResultMatchNoMatch

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultMatchNoMatch)`, or replace it by
`symbol(chResultMatchNoMatch)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(132,23,132,76)
	132 |	  syntax CHResult ::= chResultMatchNoMatch()
[klabel(chResultMatchNoMatch)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 297 deprecated-klabel chResultPlanMatched

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultPlanMatched)`, or replace it by `symbol(chResultPlanMatched)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(133,23,133,84)
	133 |	  syntax CHResult ::= chResultPlanMatched(Int, CTEnv)
[klabel(chResultPlanMatched)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 298 deprecated-klabel chResultPlanNoMatch

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultPlanNoMatch)`, or replace it by `symbol(chResultPlanNoMatch)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(134,23,134,74)
	134 |	  syntax CHResult ::= chResultPlanNoMatch()
[klabel(chResultPlanNoMatch)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 299 deprecated-klabel chResultBuildDone

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chResultBuildDone)`, or replace it by `symbol(chResultBuildDone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(135,23,135,75)
	135 |	  syntax CHResult ::= chResultBuildDone(CTRef)
[klabel(chResultBuildDone)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 300 deprecated-klabel chNoHelper

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chNoHelper)`, or replace it by `symbol(chNoHelper)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(136,29,136,62)
	136 |	  syntax CHHelperOption ::= chNoHelper() [klabel(chNoHelper)]
	    .	                            ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 301 deprecated-klabel chSomeHelper

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSomeHelper)`, or replace it by `symbol(chSomeHelper)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(137,29,137,74)
	137 |	  syntax CHHelperOption ::= chSomeHelper(CHHelper)
[klabel(chSomeHelper)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 302 deprecated-klabel chNoResult

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chNoResult)`, or replace it by `symbol(chNoResult)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(138,29,138,62)
	138 |	  syntax CHResultOption ::= chNoResult() [klabel(chNoResult)]
	    .	                            ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 303 deprecated-klabel chSomeResult

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(chSomeResult)`, or replace it by `symbol(chSomeResult)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-helper-syntax.k)
	Location(139,29,139,74)
	139 |	  syntax CHResultOption ::= chSomeResult(CHResult)
[klabel(chSomeResult)]
	    .	                           
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 304 deprecated-klabel dpNodesSize

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpNodesSize)`, or replace it by `symbol(dpNodesSize)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-codec.k)
	Location(7,18,7,70)
	7 |	  syntax Int ::= dpNodesSize(DPNodes) [function, klabel(dpNodesSize)]
	  .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 305 deprecated-klabel dpRefsSize

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpRefsSize)`, or replace it by `symbol(dpRefsSize)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-codec.k)
	Location(8,18,8,67)
	8 |	               | dpRefsSize(DPRefs) [function, klabel(dpRefsSize)]
	  .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 306 deprecated-klabel dpEnvsSize

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpEnvsSize)`, or replace it by `symbol(dpEnvsSize)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-codec.k)
	Location(9,18,9,67)
	9 |	               | dpEnvsSize(DPEnvs) [function, klabel(dpEnvsSize)]
	  .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 307 deprecated-klabel dpEncodeData

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpEncodeData)`, or replace it by `symbol(dpEncodeData)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-codec.k)
	Location(17,22,17,75)
	17 |	  syntax CTLanes ::= dpEncodeData(DPData) [function,
klabel(dpEncodeData)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 308 deprecated-klabel dpEncodeRef

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpEncodeRef)`, or replace it by `symbol(dpEncodeRef)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-codec.k)
	Location(26,22,26,72)
	26 |	  syntax CTLanes ::= dpEncodeRef(CTRef) [function, klabel(dpEncodeRef)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 309 deprecated-klabel dpEncodeEnv

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpEncodeEnv)`, or replace it by `symbol(dpEncodeEnv)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-codec.k)
	Location(27,21,27,75)
	27 |	                  | dpEncodeEnv(DPEnvCell) [function,
klabel(dpEncodeEnv)]
	   .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 310 deprecated-klabel dpEncodeNodes

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpEncodeNodes)`, or replace it by `symbol(dpEncodeNodes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-codec.k)
	Location(31,22,31,78)
	31 |	  syntax CTLanes ::= dpEncodeNodes(DPNodes) [function,
klabel(dpEncodeNodes)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 311 deprecated-klabel dpEncodeRefs

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpEncodeRefs)`, or replace it by `symbol(dpEncodeRefs)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-codec.k)
	Location(32,21,32,74)
	32 |	                  | dpEncodeRefs(DPRefs) [function, klabel(dpEncodeRefs)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 312 deprecated-klabel dpEncodeEnvs

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpEncodeEnvs)`, or replace it by `symbol(dpEncodeEnvs)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-codec.k)
	Location(33,21,33,74)
	33 |	                  | dpEncodeEnvs(DPEnvs) [function, klabel(dpEncodeEnvs)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 313 deprecated-klabel dpHeader

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpHeader)`, or replace it by `symbol(dpHeader)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-codec.k)
	Location(42,22,42,69)
	42 |	  syntax CTLanes ::= dpHeader(DPTables) [function, klabel(dpHeader)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 314 deprecated-klabel dpDecodeData

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpDecodeData)`, or replace it by `symbol(dpDecodeData)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-codec.k)
	Location(48,21,48,91)
	48 |	  syntax DPData ::= dpDecodeData(Int, Int, Int, Int, Int) [function,
klabel(dpDecodeData)]
	   .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 315 deprecated-klabel dpReadNodes

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpReadNodes)`, or replace it by `symbol(dpReadNodes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-codec.k)
	Location(57,22,57,79)
	57 |	  syntax DPNodes ::= dpReadNodes(Int, CTLanes) [function,
klabel(dpReadNodes)]
	   .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 316 deprecated-klabel dpReadRefs

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpReadRefs)`, or replace it by `symbol(dpReadRefs)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-codec.k)
	Location(58,21,58,76)
	58 |	  syntax DPRefs ::= dpReadRefs(Int, CTLanes) [function,
klabel(dpReadRefs)]
	   .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 317 deprecated-klabel dpReadEnvs

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpReadEnvs)`, or replace it by `symbol(dpReadEnvs)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-codec.k)
	Location(59,21,59,76)
	59 |	  syntax DPEnvs ::= dpReadEnvs(Int, CTLanes) [function,
klabel(dpReadEnvs)]
	   .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 318 deprecated-klabel dpU128

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpU128)`, or replace it by `symbol(dpU128)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-syntax.k)
	Location(7,21,7,49)
	7 |	  syntax DPData ::= dpU128(Int) [klabel(dpU128)]
	  .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 319 deprecated-klabel dpBool

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpBool)`, or replace it by `symbol(dpBool)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-syntax.k)
	Location(8,21,8,50)
	8 |	                  | dpBool(Bool) [klabel(dpBool)]
	  .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 320 deprecated-klabel dpNil

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpNil)`, or replace it by `symbol(dpNil)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-syntax.k)
	Location(9,21,9,44)
	9 |	                  | dpNil() [klabel(dpNil)]
	  .	                    ^~~~~~~~~~~~~~~~~~~~~~~
```

## 321 deprecated-klabel dpCons

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpCons)`, or replace it by `symbol(dpCons)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-syntax.k)
	Location(10,21,10,53)
	10 |	                  | dpCons(CTSlice) [klabel(dpCons)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 322 deprecated-klabel dpLeaf

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpLeaf)`, or replace it by `symbol(dpLeaf)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-syntax.k)
	Location(11,21,11,53)
	11 |	                  | dpLeaf(CTSlice) [klabel(dpLeaf)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 323 deprecated-klabel dpBranch

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpBranch)`, or replace it by `symbol(dpBranch)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-syntax.k)
	Location(12,21,12,57)
	12 |	                  | dpBranch(CTSlice) [klabel(dpBranch)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 324 deprecated-klabel dpConstructor

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpConstructor)`, or replace it by `symbol(dpConstructor)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-syntax.k)
	Location(13,21,13,77)
	13 |	                  | dpConstructor(Int, Int, CTSlice)
[klabel(dpConstructor)]
	   .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 325 deprecated-klabel dpNoNodes

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpNoNodes)`, or replace it by `symbol(dpNoNodes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-syntax.k)
	Location(14,22,14,53)
	14 |	  syntax DPNodes ::= dpNoNodes() [klabel(dpNoNodes)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 326 deprecated-klabel dpNode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpNode)`, or replace it by `symbol(dpNode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-syntax.k)
	Location(15,22,15,62)
	15 |	                   | dpNode(DPData, DPNodes) [klabel(dpNode)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 327 deprecated-klabel dpNoRefs

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpNoRefs)`, or replace it by `symbol(dpNoRefs)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-syntax.k)
	Location(16,21,16,50)
	16 |	  syntax DPRefs ::= dpNoRefs() [klabel(dpNoRefs)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 328 deprecated-klabel dpRef

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpRef)`, or replace it by `symbol(dpRef)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-syntax.k)
	Location(17,21,17,57)
	17 |	                  | dpRef(CTRef, DPRefs) [klabel(dpRef)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 329 deprecated-klabel dpEnvCell

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpEnvCell)`, or replace it by `symbol(dpEnvCell)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-syntax.k)
	Location(18,24,18,72)
	18 |	  syntax DPEnvCell ::= dpEnvCell(Int, CTRef, CTEnv) [klabel(dpEnvCell)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 330 deprecated-klabel dpNoEnvs

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpNoEnvs)`, or replace it by `symbol(dpNoEnvs)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-syntax.k)
	Location(19,21,19,50)
	19 |	  syntax DPEnvs ::= dpNoEnvs() [klabel(dpNoEnvs)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 331 deprecated-klabel dpEnv

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpEnv)`, or replace it by `symbol(dpEnv)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-syntax.k)
	Location(20,21,20,61)
	20 |	                  | dpEnv(DPEnvCell, DPEnvs) [klabel(dpEnv)]
	   .	                    ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 332 deprecated-klabel dpTables

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(dpTables)`, or replace it by `symbol(dpTables)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-owned-data-syntax.k)
	Location(21,23,21,83)
	21 |	  syntax DPTables ::= dpTables(DPNodes, DPRefs, DPEnvs, DPRefs)
[klabel(dpTables)]
	   .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 333 deprecated-klabel ctJoin

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctJoin)`, or replace it by `symbol(ctJoin)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(10,22,10,73)
	10 |	  syntax CTLanes ::= ctJoin(CTLanes, CTLanes) [function, klabel(ctJoin)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 334 deprecated-klabel ctSize

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSize)`, or replace it by `symbol(ctSize)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(13,18,13,60)
	13 |	  syntax Int ::= ctSize(CTLanes) [function, klabel(ctSize)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 335 deprecated-klabel ctTake

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctTake)`, or replace it by `symbol(ctTake)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(16,22,16,69)
	16 |	  syntax CTLanes ::= ctTake(Int, CTLanes) [function, klabel(ctTake)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 336 deprecated-klabel ctDrop

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDrop)`, or replace it by `symbol(ctDrop)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(17,22,17,69)
	17 |	  syntax CTLanes ::= ctDrop(Int, CTLanes) [function, klabel(ctDrop)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 337 deprecated-klabel ctAt

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAt)`, or replace it by `symbol(ctAt)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(18,18,18,61)
	18 |	  syntax Int ::= ctAt(Int, CTLanes) [function, klabel(ctAt)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 338 deprecated-klabel ctEnvTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvTag)`, or replace it by `symbol(ctEnvTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(25,18,25,62)
	25 |	  syntax Int ::= ctEnvTag(CTEnv) [function, klabel(ctEnvTag)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 339 deprecated-klabel ctEnvIndex

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvIndex)`, or replace it by `symbol(ctEnvIndex)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(26,18,26,66)
	26 |	  syntax Int ::= ctEnvIndex(CTEnv) [function, klabel(ctEnvIndex)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 340 deprecated-klabel ctFunctionTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFunctionTag)`, or replace it by `symbol(ctFunctionTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(27,18,27,77)
	27 |	  syntax Int ::= ctFunctionTag(CTFunction) [function,
klabel(ctFunctionTag)]
	   .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 341 deprecated-klabel ctFunctionIndex

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFunctionIndex)`, or replace it by `symbol(ctFunctionIndex)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(28,18,28,81)
	28 |	  syntax Int ::= ctFunctionIndex(CTFunction) [function,
klabel(ctFunctionIndex)]
	   .	                
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 342 deprecated-klabel ctRefTag

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRefTag)`, or replace it by `symbol(ctRefTag)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(29,18,29,62)
	29 |	  syntax Int ::= ctRefTag(CTRef) [function, klabel(ctRefTag)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 343 deprecated-klabel ctRefIndex

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRefIndex)`, or replace it by `symbol(ctRefIndex)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(30,18,30,66)
	30 |	  syntax Int ::= ctRefIndex(CTRef) [function, klabel(ctRefIndex)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 344 deprecated-klabel ctBool

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBool)`, or replace it by `symbol(ctBool)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(31,18,31,57)
	31 |	  syntax Int ::= ctBool(Bool) [function, klabel(ctBool)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 345 deprecated-klabel ctEnvDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvDecode)`, or replace it by `symbol(ctEnvDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(46,20,46,73)
	46 |	  syntax CTEnv ::= ctEnvDecode(Int, Int) [function, klabel(ctEnvDecode)]
	   .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 346 deprecated-klabel ctFunctionDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFunctionDecode)`, or replace it by `symbol(ctFunctionDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(47,25,47,88)
	47 |	  syntax CTFunction ::= ctFunctionDecode(Int, Int) [function,
klabel(ctFunctionDecode)]
	   .	                       
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 347 deprecated-klabel ctRefDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRefDecode)`, or replace it by `symbol(ctRefDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(48,20,48,73)
	48 |	  syntax CTRef ::= ctRefDecode(Int, Int) [function, klabel(ctRefDecode)]
	   .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 348 deprecated-klabel ctBoolDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBoolDecode)`, or replace it by `symbol(ctBoolDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(55,19,55,69)
	55 |	  syntax Bool ::= ctBoolDecode(Int) [function, klabel(ctBoolDecode)]
	   .	                  ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 349 deprecated-klabel ctBinary

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBinary)`, or replace it by `symbol(ctBinary)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(58,18,58,65)
	58 |	  syntax Int ::= ctBinary(CTBinary) [function, klabel(ctBinary)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 350 deprecated-klabel ctBinaryDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBinaryDecode)`, or replace it by `symbol(ctBinaryDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(59,23,59,77)
	59 |	  syntax CTBinary ::= ctBinaryDecode(Int) [function,
klabel(ctBinaryDecode)]
	   .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 351 deprecated-klabel ctUnary

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctUnary)`, or replace it by `symbol(ctUnary)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(74,18,74,62)
	74 |	  syntax Int ::= ctUnary(CTUnary) [function, klabel(ctUnary)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 352 deprecated-klabel ctUnaryDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctUnaryDecode)`, or replace it by `symbol(ctUnaryDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(75,22,75,74)
	75 |	  syntax CTUnary ::= ctUnaryDecode(Int) [function, klabel(ctUnaryDecode)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 353 deprecated-klabel ctExhaust

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctExhaust)`, or replace it by `symbol(ctExhaust)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(80,18,80,68)
	80 |	  syntax Int ::= ctExhaust(CTExhaust) [function, klabel(ctExhaust)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 354 deprecated-klabel ctExhaustDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctExhaustDecode)`, or replace it by `symbol(ctExhaustDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(81,24,81,80)
	81 |	  syntax CTExhaust ::= ctExhaustDecode(Int) [function,
klabel(ctExhaustDecode)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 355 deprecated-klabel ctSliceStart

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSliceStart)`, or replace it by `symbol(ctSliceStart)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(96,18,96,72)
	96 |	  syntax Int ::= ctSliceStart(CTSlice) [function, klabel(ctSliceStart)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 356 deprecated-klabel ctSliceLen

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSliceLen)`, or replace it by `symbol(ctSliceLen)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(97,18,97,68)
	97 |	  syntax Int ::= ctSliceLen(CTSlice) [function, klabel(ctSliceLen)]
	   .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 357 deprecated-klabel ctEncodeFrame

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEncodeFrame)`, or replace it by `symbol(ctEncodeFrame)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(100,22,100,78)
	100 |	  syntax CTLanes ::= ctEncodeFrame(CTFrame) [function,
klabel(ctEncodeFrame)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 358 deprecated-klabel ctDecodeFrame

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDecodeFrame)`, or replace it by `symbol(ctDecodeFrame)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(101,22,101,78)
	101 |	  syntax CTFrame ::= ctDecodeFrame(CTLanes) [function,
klabel(ctDecodeFrame)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 359 deprecated-klabel ctBindingLanes

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBindingLanes)`, or replace it by `symbol(ctBindingLanes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(122,22,122,82)
	122 |	  syntax CTLanes ::= ctBindingLanes(CTBinding) [function,
klabel(ctBindingLanes)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 360 deprecated-klabel ctMatchingLanes

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMatchingLanes)`, or replace it by `symbol(ctMatchingLanes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(123,22,123,85)
	123 |	  syntax CTLanes ::= ctMatchingLanes(CTMatching) [function,
klabel(ctMatchingLanes)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 361 deprecated-klabel ctPrimitiveLanes

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctPrimitiveLanes)`, or replace it by `symbol(ctPrimitiveLanes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(124,22,124,88)
	124 |	  syntax CTLanes ::= ctPrimitiveLanes(CTPrimitive) [function,
klabel(ctPrimitiveLanes)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 362 deprecated-klabel ctOutcomeLanes

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctOutcomeLanes)`, or replace it by `symbol(ctOutcomeLanes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(125,22,125,82)
	125 |	  syntax CTLanes ::= ctOutcomeLanes(CTOutcome) [function,
klabel(ctOutcomeLanes)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 363 deprecated-klabel ctBindingDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBindingDecode)`, or replace it by `symbol(ctBindingDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(136,24,136,90)
	136 |	  syntax CTBinding ::= ctBindingDecode(Int, Int, Int) [function,
klabel(ctBindingDecode)]
	    .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 364 deprecated-klabel ctMatchingDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMatchingDecode)`, or replace it by `symbol(ctMatchingDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(137,25,137,93)
	137 |	  syntax CTMatching ::= ctMatchingDecode(Int, Int, Int) [function,
klabel(ctMatchingDecode)]
	    .	                       
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 365 deprecated-klabel ctPrimitiveDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctPrimitiveDecode)`, or replace it by `symbol(ctPrimitiveDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(138,26,138,96)
	138 |	  syntax CTPrimitive ::= ctPrimitiveDecode(Int, Int, Int) [function,
klabel(ctPrimitiveDecode)]
	    .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 366 deprecated-klabel ctOutcomeDecode

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctOutcomeDecode)`, or replace it by `symbol(ctOutcomeDecode)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(139,24,139,90)
	139 |	  syntax CTOutcome ::= ctOutcomeDecode(Int, Int, Int) [function,
klabel(ctOutcomeDecode)]
	    .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 367 deprecated-klabel ctEncodeControl

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEncodeControl)`, or replace it by `symbol(ctEncodeControl)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(150,22,150,84)
	150 |	  syntax CTLanes ::= ctEncodeControl(CTControl) [function,
klabel(ctEncodeControl)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 368 deprecated-klabel ctDecodeControl

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDecodeControl)`, or replace it by `symbol(ctDecodeControl)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(151,24,151,84)
	151 |	  syntax CTControl ::= ctDecodeControl(CTLanes) [function,
klabel(ctDecodeControl)]
	    .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 369 deprecated-klabel ctFrameCount

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFrameCount)`, or replace it by `symbol(ctFrameCount)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(174,18,174,73)
	174 |	  syntax Int ::= ctFrameCount(CTFrames) [function, klabel(ctFrameCount)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 370 deprecated-klabel ctEncodeFrames

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEncodeFrames)`, or replace it by `symbol(ctEncodeFrames)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(177,22,177,81)
	177 |	  syntax CTLanes ::= ctEncodeFrames(CTFrames) [function,
klabel(ctEncodeFrames)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 371 deprecated-klabel ctDecodeFrames

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDecodeFrames)`, or replace it by `symbol(ctDecodeFrames)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(180,23,180,86)
	180 |	  syntax CTFrames ::= ctDecodeFrames(Int, CTLanes) [function,
klabel(ctDecodeFrames)]
	    .	                     
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 372 deprecated-klabel ctAlloc0

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAlloc0)`, or replace it by `symbol(ctAlloc0)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(183,18,183,64)
	183 |	  syntax Int ::= ctAlloc0(CTAlloc) [function, klabel(ctAlloc0)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 373 deprecated-klabel ctAlloc1

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAlloc1)`, or replace it by `symbol(ctAlloc1)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(185,18,185,64)
	185 |	  syntax Int ::= ctAlloc1(CTAlloc) [function, klabel(ctAlloc1)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 374 deprecated-klabel ctAlloc2

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAlloc2)`, or replace it by `symbol(ctAlloc2)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(187,18,187,64)
	187 |	  syntax Int ::= ctAlloc2(CTAlloc) [function, klabel(ctAlloc2)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 375 deprecated-klabel ctActive0

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctActive0)`, or replace it by `symbol(ctActive0)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(189,18,189,67)
	189 |	  syntax Int ::= ctActive0(CTActive) [function, klabel(ctActive0)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 376 deprecated-klabel ctActive1

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctActive1)`, or replace it by `symbol(ctActive1)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(191,18,191,67)
	191 |	  syntax Int ::= ctActive1(CTActive) [function, klabel(ctActive1)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 377 deprecated-klabel ctActive2

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctActive2)`, or replace it by `symbol(ctActive2)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(193,18,193,67)
	193 |	  syntax Int ::= ctActive2(CTActive) [function, klabel(ctActive2)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 378 deprecated-klabel ctActive3

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctActive3)`, or replace it by `symbol(ctActive3)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(195,18,195,67)
	195 |	  syntax Int ::= ctActive3(CTActive) [function, klabel(ctActive3)]
	    .	                 ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 379 deprecated-klabel ctEncodeRoot

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEncodeRoot)`, or replace it by `symbol(ctEncodeRoot)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(197,22,197,75)
	197 |	  syntax CTLanes ::= ctEncodeRoot(CTRoot) [function,
klabel(ctEncodeRoot)]
	    .	                    
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 380 deprecated-klabel ctDecodeRoot

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDecodeRoot)`, or replace it by `symbol(ctDecodeRoot)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-codec.k)
	Location(198,21,198,75)
	198 |	  syntax CTRoot ::= ctDecodeRoot(CTLanes) [function,
klabel(ctDecodeRoot)]
	    .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 381 deprecated-klabel ctConst

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctConst)`, or replace it by `symbol(ctConst)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(7,20,7,50)
	7 |	  syntax CTRef ::= ctConst(Int) [klabel(ctConst)]
	  .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 382 deprecated-klabel ctData

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctData)`, or replace it by `symbol(ctData)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(8,22,8,50)
	8 |	                   | ctData(Int) [klabel(ctData)]
	  .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 383 deprecated-klabel ctEnvNone

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvNone)`, or replace it by `symbol(ctEnvNone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(9,20,9,51)
	9 |	  syntax CTEnv ::= ctEnvNone() [klabel(ctEnvNone)]
	  .	                   ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 384 deprecated-klabel ctEnvSome

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvSome)`, or replace it by `symbol(ctEnvSome)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(10,22,10,56)
	10 |	                   | ctEnvSome(Int) [klabel(ctEnvSome)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 385 deprecated-klabel ctFunctionNone

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFunctionNone)`, or replace it by `symbol(ctFunctionNone)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(11,25,11,66)
	11 |	  syntax CTFunction ::= ctFunctionNone() [klabel(ctFunctionNone)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 386 deprecated-klabel ctFunctionSome

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFunctionSome)`, or replace it by `symbol(ctFunctionSome)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(12,27,12,71)
	12 |	                        | ctFunctionSome(Int) [klabel(ctFunctionSome)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 387 deprecated-klabel ctSlice

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSlice)`, or replace it by `symbol(ctSlice)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(13,22,13,57)
	13 |	  syntax CTSlice ::= ctSlice(Int, Int) [klabel(ctSlice)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 388 deprecated-klabel ctAdd

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAdd)`, or replace it by `symbol(ctAdd)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(14,23,14,46)
	14 |	  syntax CTBinary ::= ctAdd() [klabel(ctAdd)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~
```

## 389 deprecated-klabel ctSub

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSub)`, or replace it by `symbol(ctSub)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(15,25,15,48)
	15 |	                      | ctSub() [klabel(ctSub)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~
```

## 390 deprecated-klabel ctMul

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMul)`, or replace it by `symbol(ctMul)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(16,25,16,48)
	16 |	                      | ctMul() [klabel(ctMul)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~
```

## 391 deprecated-klabel ctEq

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEq)`, or replace it by `symbol(ctEq)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(17,25,17,46)
	17 |	                      | ctEq() [klabel(ctEq)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~
```

## 392 deprecated-klabel ctLt

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLt)`, or replace it by `symbol(ctLt)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(18,25,18,46)
	18 |	                      | ctLt() [klabel(ctLt)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~
```

## 393 deprecated-klabel ctCons

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctCons)`, or replace it by `symbol(ctCons)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(19,25,19,50)
	19 |	                      | ctCons() [klabel(ctCons)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~
```

## 394 deprecated-klabel ctBranch

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBranch)`, or replace it by `symbol(ctBranch)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(20,25,20,54)
	20 |	                      | ctBranch() [klabel(ctBranch)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 395 deprecated-klabel ctLeaf

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLeaf)`, or replace it by `symbol(ctLeaf)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(21,22,21,47)
	21 |	  syntax CTUnary ::= ctLeaf() [klabel(ctLeaf)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~
```

## 396 deprecated-klabel ctNot

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNot)`, or replace it by `symbol(ctNot)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(22,24,22,47)
	22 |	                     | ctNot() [klabel(ctNot)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~
```

## 397 deprecated-klabel ctLetF

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLetF)`, or replace it by `symbol(ctLetF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(23,22,23,67)
	23 |	  syntax CTFrame ::= ctLetF(Int, Int, CTEnv, Int) [klabel(ctLetF)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 398 deprecated-klabel ctLeftF

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLeftF)`, or replace it by `symbol(ctLeftF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(24,24,24,76)
	24 |	                     | ctLeftF(CTBinary, Int, CTEnv, Int)
[klabel(ctLeftF)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 399 deprecated-klabel ctRightF

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRightF)`, or replace it by `symbol(ctRightF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(25,24,25,73)
	25 |	                     | ctRightF(CTBinary, CTRef, Int) [klabel(ctRightF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 400 deprecated-klabel ctUnaryF

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctUnaryF)`, or replace it by `symbol(ctUnaryF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(26,24,26,65)
	26 |	                     | ctUnaryF(CTUnary, Int) [klabel(ctUnaryF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 401 deprecated-klabel ctIfF

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctIfF)`, or replace it by `symbol(ctIfF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(27,24,27,67)
	27 |	                     | ctIfF(Int, Int, CTEnv, Int) [klabel(ctIfF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 402 deprecated-klabel ctMatchF

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMatchF)`, or replace it by `symbol(ctMatchF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(28,24,28,72)
	28 |	                     | ctMatchF(CTSlice, CTEnv, Int) [klabel(ctMatchF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 403 deprecated-klabel ctArgsF

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctArgsF)`, or replace it by `symbol(ctArgsF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(29,24,29,84)
	29 |	                     | ctArgsF(Int, CTSlice, CTSlice, CTEnv, Int)
[klabel(ctArgsF)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 404 deprecated-klabel ctReturnF

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctReturnF)`, or replace it by `symbol(ctReturnF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(30,24,30,70)
	30 |	                     | ctReturnF(Int, CTEnv, Int) [klabel(ctReturnF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 405 deprecated-klabel ctScopeF

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctScopeF)`, or replace it by `symbol(ctScopeF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(31,24,31,63)
	31 |	                     | ctScopeF(CTEnv, Int) [klabel(ctScopeF)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 406 deprecated-klabel ctConstructorFieldsF

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctConstructorFieldsF)`, or replace it by
`symbol(ctConstructorFieldsF)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(32,24,32,131)
	32 |	                     | ctConstructorFieldsF(Int, Int, Int, Int, Bool,
CTSlice, CTSlice, CTEnv, Int) [klabel(ctConstructorFieldsF)]
	   .	                      
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 407 deprecated-klabel ctNoFrames

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNoFrames)`, or replace it by `symbol(ctNoFrames)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(33,23,33,56)
	33 |	  syntax CTFrames ::= ctNoFrames() [klabel(ctNoFrames)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 408 deprecated-klabel ctFrame

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFrame)`, or replace it by `symbol(ctFrame)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(34,25,34,69)
	34 |	                      | ctFrame(CTFrame, CTFrames) [klabel(ctFrame)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 409 deprecated-klabel ctBindingBad

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBindingBad)`, or replace it by `symbol(ctBindingBad)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(35,24,35,61)
	35 |	  syntax CTBinding ::= ctBindingBad() [klabel(ctBindingBad)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 410 deprecated-klabel ctBindingOk

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBindingOk)`, or replace it by `symbol(ctBindingOk)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(36,26,36,66)
	36 |	                       | ctBindingOk(CTEnv) [klabel(ctBindingOk)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 411 deprecated-klabel ctNoMatch

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNoMatch)`, or replace it by `symbol(ctNoMatch)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(37,25,37,56)
	37 |	  syntax CTMatching ::= ctNoMatch() [klabel(ctNoMatch)]
	   .	                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 412 deprecated-klabel ctMatched

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMatched)`, or replace it by `symbol(ctMatched)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(38,27,38,63)
	38 |	                        | ctMatched(CTEnv) [klabel(ctMatched)]
	   .	                          ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 413 deprecated-klabel ctPrimValue

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctPrimValue)`, or replace it by `symbol(ctPrimValue)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(39,26,39,66)
	39 |	  syntax CTPrimitive ::= ctPrimValue(CTRef) [klabel(ctPrimValue)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 414 deprecated-klabel ctPrimError

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctPrimError)`, or replace it by `symbol(ctPrimError)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(40,28,40,66)
	40 |	                         | ctPrimError(Int) [klabel(ctPrimError)]
	   .	                           ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 415 deprecated-klabel ctEval

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEval)`, or replace it by `symbol(ctEval)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(41,24,41,52)
	41 |	  syntax CTControl ::= ctEval(Int) [klabel(ctEval)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 416 deprecated-klabel ctReturn

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctReturn)`, or replace it by `symbol(ctReturn)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(42,26,42,60)
	42 |	                       | ctReturn(CTRef) [klabel(ctReturn)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 417 deprecated-klabel ctScheduleNext

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctScheduleNext)`, or replace it by `symbol(ctScheduleNext)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(43,26,43,86)
	43 |	                       | ctScheduleNext(CTFrame, Int, CTEnv)
[klabel(ctScheduleNext)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 418 deprecated-klabel ctInvoke

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctInvoke)`, or replace it by `symbol(ctInvoke)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(44,26,44,67)
	44 |	                       | ctInvoke(Int, CTSlice) [klabel(ctInvoke)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 419 deprecated-klabel ctEnter

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnter)`, or replace it by `symbol(ctEnter)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(45,26,45,72)
	45 |	                       | ctEnter(CTFunction, CTSlice) [klabel(ctEnter)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 420 deprecated-klabel ctBound

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctBound)`, or replace it by `symbol(ctBound)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(46,26,46,72)
	46 |	                       | ctBound(CTBinding, Int, Int) [klabel(ctBound)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 421 deprecated-klabel ctCases

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctCases)`, or replace it by `symbol(ctCases)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(47,26,47,74)
	47 |	                       | ctCases(CTRef, CTSlice, CTEnv) [klabel(ctCases)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 422 deprecated-klabel ctCaseResult

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctCaseResult)`, or replace it by `symbol(ctCaseResult)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(48,26,48,101)
	48 |	                       | ctCaseResult(CTMatching, CTRef, Int, CTSlice,
CTEnv) [klabel(ctCaseResult)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 423 deprecated-klabel ctPrimResult

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctPrimResult)`, or replace it by `symbol(ctPrimResult)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(49,26,49,74)
	49 |	                       | ctPrimResult(CTPrimitive) [klabel(ctPrimResult)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 424 deprecated-klabel ctError

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctError)`, or replace it by `symbol(ctError)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(50,26,50,56)
	50 |	                       | ctError(Int) [klabel(ctError)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 425 deprecated-klabel ctMaterialize

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctMaterialize)`, or replace it by `symbol(ctMaterialize)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(51,26,51,82)
	51 |	                       | ctMaterialize(Int, Int, CTSlice)
[klabel(ctMaterialize)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 426 deprecated-klabel ctFuel

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctFuel)`, or replace it by `symbol(ctFuel)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(52,24,52,49)
	52 |	  syntax CTExhaust ::= ctFuel() [klabel(ctFuel)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~
```

## 427 deprecated-klabel ctDataNodes

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDataNodes)`, or replace it by `symbol(ctDataNodes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(53,26,53,61)
	53 |	                       | ctDataNodes() [klabel(ctDataNodes)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 428 deprecated-klabel ctDataFields

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctDataFields)`, or replace it by `symbol(ctDataFields)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(54,26,54,63)
	54 |	                       | ctDataFields() [klabel(ctDataFields)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 429 deprecated-klabel ctEnvironmentCells

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctEnvironmentCells)`, or replace it by `symbol(ctEnvironmentCells)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(55,26,55,75)
	55 |	                       | ctEnvironmentCells()
[klabel(ctEnvironmentCells)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 430 deprecated-klabel ctHelperTasks

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctHelperTasks)`, or replace it by `symbol(ctHelperTasks)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(56,26,56,65)
	56 |	                       | ctHelperTasks() [klabel(ctHelperTasks)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 431 deprecated-klabel ctHelperWork

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctHelperWork)`, or replace it by `symbol(ctHelperWork)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(57,26,57,63)
	57 |	                       | ctHelperWork() [klabel(ctHelperWork)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 432 deprecated-klabel ctSerializationBytes

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctSerializationBytes)`, or replace it by
`symbol(ctSerializationBytes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(58,26,58,79)
	58 |	                       | ctSerializationBytes()
[klabel(ctSerializationBytes)]
	   .	                        
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 433 deprecated-klabel ctRunning

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRunning)`, or replace it by `symbol(ctRunning)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(59,24,59,55)
	59 |	  syntax CTOutcome ::= ctRunning() [klabel(ctRunning)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 434 deprecated-klabel ctHalted

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctHalted)`, or replace it by `symbol(ctHalted)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(60,26,60,60)
	60 |	                       | ctHalted(CTRef) [klabel(ctHalted)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 435 deprecated-klabel ctRejected

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRejected)`, or replace it by `symbol(ctRejected)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(61,26,61,62)
	61 |	                       | ctRejected(Int) [klabel(ctRejected)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 436 deprecated-klabel ctExhausted

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctExhausted)`, or replace it by `symbol(ctExhausted)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(62,26,62,70)
	62 |	                       | ctExhausted(CTExhaust) [klabel(ctExhausted)]
	   .	                         ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 437 deprecated-klabel ctAlloc

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctAlloc)`, or replace it by `symbol(ctAlloc)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(63,22,63,62)
	63 |	  syntax CTAlloc ::= ctAlloc(Int, Int, Int) [klabel(ctAlloc)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 438 deprecated-klabel ctActive

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctActive)`, or replace it by `symbol(ctActive)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(64,23,64,70)
	64 |	  syntax CTActive ::= ctActive(Int, Int, Int, Int) [klabel(ctActive)]
	   .	                      ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 439 deprecated-klabel ctRoot

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctRoot)`, or replace it by `symbol(ctRoot)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(65,21,65,166)
	65 |	  syntax CTRoot ::= ctRoot(CTControl, Int, CTEnv, Int, CTOutcome, Int,
Int, Int, Int, Int, Int, CTAlloc, CTActive, CTActive, CTAlloc, Int, CTFrames)
[klabel(ctRoot)]
	   .	                   
^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 440 deprecated-klabel ctNoLanes

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctNoLanes)`, or replace it by `symbol(ctNoLanes)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(66,22,66,53)
	66 |	  syntax CTLanes ::= ctNoLanes() [klabel(ctNoLanes)]
	   .	                     ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```

## 441 deprecated-klabel ctLane

```text
[Warning] Compiler: Attribute `klabel(_)` is deprecated. Either remove
`klabel(ctLane)`, or replace it by `symbol(ctLane)`.
	Source(/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-complete-positive-HELPER-TASK-STATE-20261020/producer-source01/source/c6-typed-root-syntax.k)
	Location(67,24,67,61)
	67 |	                     | ctLane(Int, CTLanes) [klabel(ctLane)]
	   .	                       ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
```
