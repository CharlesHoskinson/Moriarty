# Complete current DATA compile warning catalog

Every diagnostic has the same deprecated-klabel template. This is complete text/source-location classification, not semantic acceptance. Raw wrapping/carets remain exact in stderr.original and membership.

## D1: dpInverse

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-laws.k` Location(9,19,9,76).

```k
  syntax Bool ::= dpInverse(DPCaps, DPTables) [function, klabel(dpInverse)]
```

## D2: dpExtent

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-laws.k` Location(10,19,10,74).

```k
                | dpExtent(DPCaps, DPTables) [function, klabel(dpExtent)]
```

## D3: dpHeaderCounts

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-laws.k` Location(11,19,11,86).

```k
                | dpHeaderCounts(DPCaps, DPTables) [function, klabel(dpHeaderCounts)]
```

## D4: dpInactiveZeros

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-laws.k` Location(12,19,12,88).

```k
                | dpInactiveZeros(DPCaps, DPTables) [function, klabel(dpInactiveZeros)]
```

## D5: dpAllZero

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-laws.k` Location(13,19,13,67).

```k
                | dpAllZero(CTLanes) [function, klabel(dpAllZero)]
```

## D6: dpPaddingIn

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-laws.k` Location(14,19,14,89).

```k
                | dpPaddingIn(DPCaps, DPTables, CTLanes) [function, klabel(dpPaddingIn)]
```

## D7: dpU128

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(7,21,7,49).

```k
  syntax DPData ::= dpU128(Int) [klabel(dpU128)]
```

## D8: dpBool

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(8,21,8,50).

```k
                  | dpBool(Bool) [klabel(dpBool)]
```

## D9: dpNil

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(9,21,9,44).

```k
                  | dpNil() [klabel(dpNil)]
```

## D10: dpCons

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(10,21,10,53).

```k
                  | dpCons(CTSlice) [klabel(dpCons)]
```

## D11: dpLeaf

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(11,21,11,53).

```k
                  | dpLeaf(CTSlice) [klabel(dpLeaf)]
```

## D12: dpBranch

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(12,21,12,57).

```k
                  | dpBranch(CTSlice) [klabel(dpBranch)]
```

## D13: dpConstructor

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(13,21,13,77).

```k
                  | dpConstructor(Int, Int, CTSlice) [klabel(dpConstructor)]
```

## D14: dpNoNodes

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(14,22,14,53).

```k
  syntax DPNodes ::= dpNoNodes() [klabel(dpNoNodes)]
```

## D15: dpNode

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(15,22,15,62).

```k
                   | dpNode(DPData, DPNodes) [klabel(dpNode)]
```

## D16: dpNoRefs

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(16,21,16,50).

```k
  syntax DPRefs ::= dpNoRefs() [klabel(dpNoRefs)]
```

## D17: dpRef

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(17,21,17,57).

```k
                  | dpRef(CTRef, DPRefs) [klabel(dpRef)]
```

## D18: dpEnvCell

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(18,24,18,72).

```k
  syntax DPEnvCell ::= dpEnvCell(Int, CTRef, CTEnv) [klabel(dpEnvCell)]
```

## D19: dpNoEnvs

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(19,21,19,50).

```k
  syntax DPEnvs ::= dpNoEnvs() [klabel(dpNoEnvs)]
```

## D20: dpEnv

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(20,21,20,61).

```k
                  | dpEnv(DPEnvCell, DPEnvs) [klabel(dpEnv)]
```

## D21: dpTables

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(21,23,21,83).

```k
  syntax DPTables ::= dpTables(DPNodes, DPRefs, DPEnvs, DPRefs) [klabel(dpTables)]
```

## D22: dpCaps

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(23,21,23,89).

```k
  syntax DPCaps ::= dpCaps(Int, Int, Int, Int, Int, Int, Int, Int, Int) [klabel(dpCaps)]
```

## D23: dpGeometry

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(25,25,25,81).

```k
  syntax DPGeometry ::= dpGeometry(Int, Int, Int, Int, Int) [klabel(dpGeometry)]
```

## D24: dpObservation

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data-syntax.k` Location(27,28,27,106).

```k
  syntax DPObservation ::= dpObservation(DPGeometry, CTActive, CTLanes, DPTables) [klabel(dpObservation)]
```

## D25: dpNodeCap

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(11,18,11,65).

```k
  syntax Int ::= dpNodeCap(DPCaps) [function, klabel(dpNodeCap)]
```

## D26: dpFieldCap

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(12,18,12,67).

```k
               | dpFieldCap(DPCaps) [function, klabel(dpFieldCap)]
```

## D27: dpEnvCap

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(13,18,13,63).

```k
               | dpEnvCap(DPCaps) [function, klabel(dpEnvCap)]
```

## D28: dpValueCap

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(14,18,14,67).

```k
               | dpValueCap(DPCaps) [function, klabel(dpValueCap)]
```

## D29: dpFieldsBase

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(20,18,20,71).

```k
  syntax Int ::= dpFieldsBase(DPCaps) [function, klabel(dpFieldsBase)]
```

## D30: dpEnvBase

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(21,18,21,65).

```k
               | dpEnvBase(DPCaps) [function, klabel(dpEnvBase)]
```

## D31: dpValuesBase

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(22,18,22,71).

```k
               | dpValuesBase(DPCaps) [function, klabel(dpValuesBase)]
```

## D32: dpTotal

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(23,18,23,61).

```k
               | dpTotal(DPCaps) [function, klabel(dpTotal)]
```

## D33: dpGeometryOf

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(28,25,28,78).

```k
  syntax DPGeometry ::= dpGeometryOf(DPCaps) [function, klabel(dpGeometryOf)]
```

## D34: dpNodesSize

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(31,18,31,70).

```k
  syntax Int ::= dpNodesSize(DPNodes) [function, klabel(dpNodesSize)]
```

## D35: dpRefsSize

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(32,18,32,67).

```k
               | dpRefsSize(DPRefs) [function, klabel(dpRefsSize)]
```

## D36: dpEnvsSize

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(33,18,33,67).

```k
               | dpEnvsSize(DPEnvs) [function, klabel(dpEnvsSize)]
```

## D37: dpZeros

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(41,22,41,62).

```k
  syntax CTLanes ::= dpZeros(Int) [function, klabel(dpZeros)]
```

## D38: dpEncodeData

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(45,22,45,75).

```k
  syntax CTLanes ::= dpEncodeData(DPData) [function, klabel(dpEncodeData)]
```

## D39: dpEncodeRef

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(54,22,54,72).

```k
  syntax CTLanes ::= dpEncodeRef(CTRef) [function, klabel(dpEncodeRef)]
```

## D40: dpEncodeEnv

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(55,21,55,75).

```k
                  | dpEncodeEnv(DPEnvCell) [function, klabel(dpEncodeEnv)]
```

## D41: dpEncodeNodes

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(59,22,59,78).

```k
  syntax CTLanes ::= dpEncodeNodes(DPNodes) [function, klabel(dpEncodeNodes)]
```

## D42: dpEncodeRefs

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(60,21,60,74).

```k
                  | dpEncodeRefs(DPRefs) [function, klabel(dpEncodeRefs)]
```

## D43: dpEncodeEnvs

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(61,21,61,74).

```k
                  | dpEncodeEnvs(DPEnvs) [function, klabel(dpEncodeEnvs)]
```

## D44: dpHeader

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(70,22,70,69).

```k
  syntax CTLanes ::= dpHeader(DPTables) [function, klabel(dpHeader)]
```

## D45: dpPack

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(75,22,75,73).

```k
  syntax CTLanes ::= dpPack(DPCaps, DPTables) [function, klabel(dpPack)]
```

## D46: dpDecodeData

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(84,21,84,91).

```k
  syntax DPData ::= dpDecodeData(Int, Int, Int, Int, Int) [function, klabel(dpDecodeData)]
```

## D47: dpReadNodes

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(93,22,93,79).

```k
  syntax DPNodes ::= dpReadNodes(Int, CTLanes) [function, klabel(dpReadNodes)]
```

## D48: dpReadRefs

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(94,21,94,76).

```k
  syntax DPRefs ::= dpReadRefs(Int, CTLanes) [function, klabel(dpReadRefs)]
```

## D49: dpReadEnvs

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(95,21,95,76).

```k
  syntax DPEnvs ::= dpReadEnvs(Int, CTLanes) [function, klabel(dpReadEnvs)]
```

## D50: dpUnpack

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(103,23,103,77).

```k
  syntax DPTables ::= dpUnpack(DPCaps, CTLanes) [function, klabel(dpUnpack)]
```

## D51: dpObserve

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(110,28,110,85).

```k
  syntax DPObservation ::= dpObserve(DPCaps, DPTables) [function, klabel(dpObserve)]
```

## D52: dpObservePacked

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-positive-data.k` Location(111,27,111,95).

```k
                        | dpObservePacked(DPCaps, CTLanes) [function, klabel(dpObservePacked)]
```

## D53: ctJoin

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(10,22,10,73).

```k
  syntax CTLanes ::= ctJoin(CTLanes, CTLanes) [function, klabel(ctJoin)]
```

## D54: ctSize

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(13,18,13,60).

```k
  syntax Int ::= ctSize(CTLanes) [function, klabel(ctSize)]
```

## D55: ctTake

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(16,22,16,69).

```k
  syntax CTLanes ::= ctTake(Int, CTLanes) [function, klabel(ctTake)]
```

## D56: ctDrop

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(17,22,17,69).

```k
  syntax CTLanes ::= ctDrop(Int, CTLanes) [function, klabel(ctDrop)]
```

## D57: ctAt

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(18,18,18,61).

```k
  syntax Int ::= ctAt(Int, CTLanes) [function, klabel(ctAt)]
```

## D58: ctEnvTag

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(25,18,25,62).

```k
  syntax Int ::= ctEnvTag(CTEnv) [function, klabel(ctEnvTag)]
```

## D59: ctEnvIndex

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(26,18,26,66).

```k
  syntax Int ::= ctEnvIndex(CTEnv) [function, klabel(ctEnvIndex)]
```

## D60: ctFunctionTag

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(27,18,27,77).

```k
  syntax Int ::= ctFunctionTag(CTFunction) [function, klabel(ctFunctionTag)]
```

## D61: ctFunctionIndex

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(28,18,28,81).

```k
  syntax Int ::= ctFunctionIndex(CTFunction) [function, klabel(ctFunctionIndex)]
```

## D62: ctRefTag

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(29,18,29,62).

```k
  syntax Int ::= ctRefTag(CTRef) [function, klabel(ctRefTag)]
```

## D63: ctRefIndex

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(30,18,30,66).

```k
  syntax Int ::= ctRefIndex(CTRef) [function, klabel(ctRefIndex)]
```

## D64: ctBool

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(31,18,31,57).

```k
  syntax Int ::= ctBool(Bool) [function, klabel(ctBool)]
```

## D65: ctEnvDecode

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(46,20,46,73).

```k
  syntax CTEnv ::= ctEnvDecode(Int, Int) [function, klabel(ctEnvDecode)]
```

## D66: ctFunctionDecode

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(47,25,47,88).

```k
  syntax CTFunction ::= ctFunctionDecode(Int, Int) [function, klabel(ctFunctionDecode)]
```

## D67: ctRefDecode

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(48,20,48,73).

```k
  syntax CTRef ::= ctRefDecode(Int, Int) [function, klabel(ctRefDecode)]
```

## D68: ctBoolDecode

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(55,19,55,69).

```k
  syntax Bool ::= ctBoolDecode(Int) [function, klabel(ctBoolDecode)]
```

## D69: ctBinary

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(58,18,58,65).

```k
  syntax Int ::= ctBinary(CTBinary) [function, klabel(ctBinary)]
```

## D70: ctBinaryDecode

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(59,23,59,77).

```k
  syntax CTBinary ::= ctBinaryDecode(Int) [function, klabel(ctBinaryDecode)]
```

## D71: ctUnary

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(74,18,74,62).

```k
  syntax Int ::= ctUnary(CTUnary) [function, klabel(ctUnary)]
```

## D72: ctUnaryDecode

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(75,22,75,74).

```k
  syntax CTUnary ::= ctUnaryDecode(Int) [function, klabel(ctUnaryDecode)]
```

## D73: ctExhaust

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(80,18,80,68).

```k
  syntax Int ::= ctExhaust(CTExhaust) [function, klabel(ctExhaust)]
```

## D74: ctExhaustDecode

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(81,24,81,80).

```k
  syntax CTExhaust ::= ctExhaustDecode(Int) [function, klabel(ctExhaustDecode)]
```

## D75: ctSliceStart

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(96,18,96,72).

```k
  syntax Int ::= ctSliceStart(CTSlice) [function, klabel(ctSliceStart)]
```

## D76: ctSliceLen

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(97,18,97,68).

```k
  syntax Int ::= ctSliceLen(CTSlice) [function, klabel(ctSliceLen)]
```

## D77: ctEncodeFrame

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(100,22,100,78).

```k
  syntax CTLanes ::= ctEncodeFrame(CTFrame) [function, klabel(ctEncodeFrame)]
```

## D78: ctDecodeFrame

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(101,22,101,78).

```k
  syntax CTFrame ::= ctDecodeFrame(CTLanes) [function, klabel(ctDecodeFrame)]
```

## D79: ctBindingLanes

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(122,22,122,82).

```k
  syntax CTLanes ::= ctBindingLanes(CTBinding) [function, klabel(ctBindingLanes)]
```

## D80: ctMatchingLanes

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(123,22,123,85).

```k
  syntax CTLanes ::= ctMatchingLanes(CTMatching) [function, klabel(ctMatchingLanes)]
```

## D81: ctPrimitiveLanes

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(124,22,124,88).

```k
  syntax CTLanes ::= ctPrimitiveLanes(CTPrimitive) [function, klabel(ctPrimitiveLanes)]
```

## D82: ctOutcomeLanes

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(125,22,125,82).

```k
  syntax CTLanes ::= ctOutcomeLanes(CTOutcome) [function, klabel(ctOutcomeLanes)]
```

## D83: ctBindingDecode

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(136,24,136,90).

```k
  syntax CTBinding ::= ctBindingDecode(Int, Int, Int) [function, klabel(ctBindingDecode)]
```

## D84: ctMatchingDecode

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(137,25,137,93).

```k
  syntax CTMatching ::= ctMatchingDecode(Int, Int, Int) [function, klabel(ctMatchingDecode)]
```

## D85: ctPrimitiveDecode

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(138,26,138,96).

```k
  syntax CTPrimitive ::= ctPrimitiveDecode(Int, Int, Int) [function, klabel(ctPrimitiveDecode)]
```

## D86: ctOutcomeDecode

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(139,24,139,90).

```k
  syntax CTOutcome ::= ctOutcomeDecode(Int, Int, Int) [function, klabel(ctOutcomeDecode)]
```

## D87: ctEncodeControl

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(150,22,150,84).

```k
  syntax CTLanes ::= ctEncodeControl(CTControl) [function, klabel(ctEncodeControl)]
```

## D88: ctDecodeControl

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(151,24,151,84).

```k
  syntax CTControl ::= ctDecodeControl(CTLanes) [function, klabel(ctDecodeControl)]
```

## D89: ctFrameCount

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(174,18,174,73).

```k
  syntax Int ::= ctFrameCount(CTFrames) [function, klabel(ctFrameCount)]
```

## D90: ctEncodeFrames

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(177,22,177,81).

```k
  syntax CTLanes ::= ctEncodeFrames(CTFrames) [function, klabel(ctEncodeFrames)]
```

## D91: ctDecodeFrames

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(180,23,180,86).

```k
  syntax CTFrames ::= ctDecodeFrames(Int, CTLanes) [function, klabel(ctDecodeFrames)]
```

## D92: ctAlloc0

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(183,18,183,64).

```k
  syntax Int ::= ctAlloc0(CTAlloc) [function, klabel(ctAlloc0)]
```

## D93: ctAlloc1

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(185,18,185,64).

```k
  syntax Int ::= ctAlloc1(CTAlloc) [function, klabel(ctAlloc1)]
```

## D94: ctAlloc2

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(187,18,187,64).

```k
  syntax Int ::= ctAlloc2(CTAlloc) [function, klabel(ctAlloc2)]
```

## D95: ctActive0

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(189,18,189,67).

```k
  syntax Int ::= ctActive0(CTActive) [function, klabel(ctActive0)]
```

## D96: ctActive1

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(191,18,191,67).

```k
  syntax Int ::= ctActive1(CTActive) [function, klabel(ctActive1)]
```

## D97: ctActive2

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(193,18,193,67).

```k
  syntax Int ::= ctActive2(CTActive) [function, klabel(ctActive2)]
```

## D98: ctActive3

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(195,18,195,67).

```k
  syntax Int ::= ctActive3(CTActive) [function, klabel(ctActive3)]
```

## D99: ctEncodeRoot

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(197,22,197,75).

```k
  syntax CTLanes ::= ctEncodeRoot(CTRoot) [function, klabel(ctEncodeRoot)]
```

## D100: ctDecodeRoot

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(198,21,198,75).

```k
  syntax CTRoot ::= ctDecodeRoot(CTLanes) [function, klabel(ctDecodeRoot)]
```

## D101: ctObserveRoot

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(201,23,201,86).

```k
  syntax CTAnswer ::= ctObserveRoot(String, CTRoot) [function, klabel(ctObserveRoot)]
```

## D102: ctObserveEncoded

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(202,23,202,101).

```k
  syntax CTAnswer ::= ctObserveEncoded(String, CTRoot, CTLanes) [function, klabel(ctObserveEncoded)]
```

## D103: ctObserveAll

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-codec.k` Location(205,24,205,80).

```k
  syntax CTAnswers ::= ctObserveAll(CTQueries) [function, klabel(ctObserveAll)]
```

## D104: ctConst

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(7,20,7,50).

```k
  syntax CTRef ::= ctConst(Int) [klabel(ctConst)]
```

## D105: ctData

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(8,22,8,50).

```k
                   | ctData(Int) [klabel(ctData)]
```

## D106: ctEnvNone

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(9,20,9,51).

```k
  syntax CTEnv ::= ctEnvNone() [klabel(ctEnvNone)]
```

## D107: ctEnvSome

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(10,22,10,56).

```k
                   | ctEnvSome(Int) [klabel(ctEnvSome)]
```

## D108: ctFunctionNone

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(11,25,11,66).

```k
  syntax CTFunction ::= ctFunctionNone() [klabel(ctFunctionNone)]
```

## D109: ctFunctionSome

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(12,27,12,71).

```k
                        | ctFunctionSome(Int) [klabel(ctFunctionSome)]
```

## D110: ctSlice

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(13,22,13,57).

```k
  syntax CTSlice ::= ctSlice(Int, Int) [klabel(ctSlice)]
```

## D111: ctAdd

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(14,23,14,46).

```k
  syntax CTBinary ::= ctAdd() [klabel(ctAdd)]
```

## D112: ctSub

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(15,25,15,48).

```k
                      | ctSub() [klabel(ctSub)]
```

## D113: ctMul

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(16,25,16,48).

```k
                      | ctMul() [klabel(ctMul)]
```

## D114: ctEq

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(17,25,17,46).

```k
                      | ctEq() [klabel(ctEq)]
```

## D115: ctLt

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(18,25,18,46).

```k
                      | ctLt() [klabel(ctLt)]
```

## D116: ctCons

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(19,25,19,50).

```k
                      | ctCons() [klabel(ctCons)]
```

## D117: ctBranch

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(20,25,20,54).

```k
                      | ctBranch() [klabel(ctBranch)]
```

## D118: ctLeaf

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(21,22,21,47).

```k
  syntax CTUnary ::= ctLeaf() [klabel(ctLeaf)]
```

## D119: ctNot

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(22,24,22,47).

```k
                     | ctNot() [klabel(ctNot)]
```

## D120: ctLetF

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(23,22,23,67).

```k
  syntax CTFrame ::= ctLetF(Int, Int, CTEnv, Int) [klabel(ctLetF)]
```

## D121: ctLeftF

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(24,24,24,76).

```k
                     | ctLeftF(CTBinary, Int, CTEnv, Int) [klabel(ctLeftF)]
```

## D122: ctRightF

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(25,24,25,73).

```k
                     | ctRightF(CTBinary, CTRef, Int) [klabel(ctRightF)]
```

## D123: ctUnaryF

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(26,24,26,65).

```k
                     | ctUnaryF(CTUnary, Int) [klabel(ctUnaryF)]
```

## D124: ctIfF

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(27,24,27,67).

```k
                     | ctIfF(Int, Int, CTEnv, Int) [klabel(ctIfF)]
```

## D125: ctMatchF

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(28,24,28,72).

```k
                     | ctMatchF(CTSlice, CTEnv, Int) [klabel(ctMatchF)]
```

## D126: ctArgsF

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(29,24,29,84).

```k
                     | ctArgsF(Int, CTSlice, CTSlice, CTEnv, Int) [klabel(ctArgsF)]
```

## D127: ctReturnF

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(30,24,30,70).

```k
                     | ctReturnF(Int, CTEnv, Int) [klabel(ctReturnF)]
```

## D128: ctScopeF

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(31,24,31,63).

```k
                     | ctScopeF(CTEnv, Int) [klabel(ctScopeF)]
```

## D129: ctConstructorFieldsF

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(32,24,32,131).

```k
                     | ctConstructorFieldsF(Int, Int, Int, Int, Bool, CTSlice, CTSlice, CTEnv, Int) [klabel(ctConstructorFieldsF)]
```

## D130: ctNoFrames

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(33,23,33,56).

```k
  syntax CTFrames ::= ctNoFrames() [klabel(ctNoFrames)]
```

## D131: ctFrame

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(34,25,34,69).

```k
                      | ctFrame(CTFrame, CTFrames) [klabel(ctFrame)]
```

## D132: ctBindingBad

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(35,24,35,61).

```k
  syntax CTBinding ::= ctBindingBad() [klabel(ctBindingBad)]
```

## D133: ctBindingOk

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(36,26,36,66).

```k
                       | ctBindingOk(CTEnv) [klabel(ctBindingOk)]
```

## D134: ctNoMatch

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(37,25,37,56).

```k
  syntax CTMatching ::= ctNoMatch() [klabel(ctNoMatch)]
```

## D135: ctMatched

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(38,27,38,63).

```k
                        | ctMatched(CTEnv) [klabel(ctMatched)]
```

## D136: ctPrimValue

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(39,26,39,66).

```k
  syntax CTPrimitive ::= ctPrimValue(CTRef) [klabel(ctPrimValue)]
```

## D137: ctPrimError

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(40,28,40,66).

```k
                         | ctPrimError(Int) [klabel(ctPrimError)]
```

## D138: ctEval

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(41,24,41,52).

```k
  syntax CTControl ::= ctEval(Int) [klabel(ctEval)]
```

## D139: ctReturn

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(42,26,42,60).

```k
                       | ctReturn(CTRef) [klabel(ctReturn)]
```

## D140: ctScheduleNext

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(43,26,43,86).

```k
                       | ctScheduleNext(CTFrame, Int, CTEnv) [klabel(ctScheduleNext)]
```

## D141: ctInvoke

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(44,26,44,67).

```k
                       | ctInvoke(Int, CTSlice) [klabel(ctInvoke)]
```

## D142: ctEnter

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(45,26,45,72).

```k
                       | ctEnter(CTFunction, CTSlice) [klabel(ctEnter)]
```

## D143: ctBound

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(46,26,46,72).

```k
                       | ctBound(CTBinding, Int, Int) [klabel(ctBound)]
```

## D144: ctCases

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(47,26,47,74).

```k
                       | ctCases(CTRef, CTSlice, CTEnv) [klabel(ctCases)]
```

## D145: ctCaseResult

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(48,26,48,101).

```k
                       | ctCaseResult(CTMatching, CTRef, Int, CTSlice, CTEnv) [klabel(ctCaseResult)]
```

## D146: ctPrimResult

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(49,26,49,74).

```k
                       | ctPrimResult(CTPrimitive) [klabel(ctPrimResult)]
```

## D147: ctError

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(50,26,50,56).

```k
                       | ctError(Int) [klabel(ctError)]
```

## D148: ctMaterialize

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(51,26,51,82).

```k
                       | ctMaterialize(Int, Int, CTSlice) [klabel(ctMaterialize)]
```

## D149: ctFuel

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(52,24,52,49).

```k
  syntax CTExhaust ::= ctFuel() [klabel(ctFuel)]
```

## D150: ctDataNodes

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(53,26,53,61).

```k
                       | ctDataNodes() [klabel(ctDataNodes)]
```

## D151: ctDataFields

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(54,26,54,63).

```k
                       | ctDataFields() [klabel(ctDataFields)]
```

## D152: ctEnvironmentCells

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(55,26,55,75).

```k
                       | ctEnvironmentCells() [klabel(ctEnvironmentCells)]
```

## D153: ctHelperTasks

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(56,26,56,65).

```k
                       | ctHelperTasks() [klabel(ctHelperTasks)]
```

## D154: ctHelperWork

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(57,26,57,63).

```k
                       | ctHelperWork() [klabel(ctHelperWork)]
```

## D155: ctSerializationBytes

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(58,26,58,79).

```k
                       | ctSerializationBytes() [klabel(ctSerializationBytes)]
```

## D156: ctRunning

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(59,24,59,55).

```k
  syntax CTOutcome ::= ctRunning() [klabel(ctRunning)]
```

## D157: ctHalted

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(60,26,60,60).

```k
                       | ctHalted(CTRef) [klabel(ctHalted)]
```

## D158: ctRejected

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(61,26,61,62).

```k
                       | ctRejected(Int) [klabel(ctRejected)]
```

## D159: ctExhausted

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(62,26,62,70).

```k
                       | ctExhausted(CTExhaust) [klabel(ctExhausted)]
```

## D160: ctAlloc

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(63,22,63,62).

```k
  syntax CTAlloc ::= ctAlloc(Int, Int, Int) [klabel(ctAlloc)]
```

## D161: ctActive

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(64,23,64,70).

```k
  syntax CTActive ::= ctActive(Int, Int, Int, Int) [klabel(ctActive)]
```

## D162: ctRoot

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(65,21,65,166).

```k
  syntax CTRoot ::= ctRoot(CTControl, Int, CTEnv, Int, CTOutcome, Int, Int, Int, Int, Int, Int, CTAlloc, CTActive, CTActive, CTAlloc, Int, CTFrames) [klabel(ctRoot)]
```

## D163: ctNoLanes

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(66,22,66,53).

```k
  syntax CTLanes ::= ctNoLanes() [klabel(ctNoLanes)]
```

## D164: ctLane

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(67,24,67,61).

```k
                     | ctLane(Int, CTLanes) [klabel(ctLane)]
```

## D165: ctAnswer

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(68,23,68,83).

```k
  syntax CTAnswer ::= ctAnswer(String, CTRoot, CTLanes, CTRoot) [klabel(ctAnswer)]
```

## D166: ctNoQueries

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(69,24,69,59).

```k
  syntax CTQueries ::= ctNoQueries() [klabel(ctNoQueries)]
```

## D167: ctQuery

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(70,26,70,78).

```k
                       | ctQuery(String, CTRoot, CTQueries) [klabel(ctQuery)]
```

## D168: ctNoAnswers

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(71,24,71,59).

```k
  syntax CTAnswers ::= ctNoAnswers() [klabel(ctNoAnswers)]
```

## D169: ctAnswerRow

Source `/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-review-20261017/k-C6-positive-padded-DATA-20261020/source/c6-typed-root-syntax.k` Location(72,26,72,80).

```k
                       | ctAnswerRow(CTAnswer, CTAnswers) [klabel(ctAnswerRow)]
```
