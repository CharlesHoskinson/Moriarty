//! UNADOPTED, private, caller-bounded host Snapshot codec proposal.
//!
//! All recursive semantic payloads become flat rows, IDs and ordered slices.
//! Complete program syntax is included structurally, including unused code and
//! original function order. Held expressions/functions are copied structurally:
//! old Snapshot does not expose their original source-occurrence identities.
//! No pointer equality, synthetic identity flag or digest replaces source code.
//!
//! Limits count table rows, ordered ID cells and copied UTF-8 symbol bytes only.
//! They do not bound host allocation overhead, temporary traversal storage,
//! semantic reconstruction, recursive Drop/Clone/PartialEq or serialized bytes.
//! This selects no B schema, native tags/widths, field encoding, canonical wire
//! format, helper clock, capacity policy or untrusted-input admission. Refusal
//! is tooling-only and never changes a machine Outcome, fuel or error code.

#![cfg(test)]

use super::reference_types::*;
use std::sync::Arc;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct HostImageLimits {
    pub(super) rows: usize,
    pub(super) cells: usize,
    pub(super) name_bytes: usize,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub(super) struct HostImageUsage {
    pub(super) rows: usize,
    pub(super) cells: usize,
    pub(super) name_bytes: usize,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum HostLimitKind { Rows, Cells, NameBytes }

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct HostEncodingRefusal {
    pub(super) kind: HostLimitKind,
    pub(super) used: usize,
    pub(super) additional: usize,
    pub(super) limit: usize,
}

type EncodingResult<T> = Result<T, HostEncodingRefusal>;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct ExprId(usize);
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct ValueId(usize);
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct EnvironmentId(usize);
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct FrameId(usize);
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct ControlId(usize);
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct FunctionId(usize);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Slice { start: usize, len: usize }

impl Slice {
    const EMPTY: Self = Self { start: 0, len: 0 };
    fn get<T>(self, table: &[T]) -> &[T] { &table[self.start..self.start + self.len] }
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum ExprPayload {
    Literal(ValueId), Var(Name), Let(Name), Binary(BinaryOp), Unary(UnaryOp),
    If, Call(Name), Match(Slice),
}

#[derive(Clone, Debug, PartialEq, Eq)]
struct ExprRow { payload: ExprPayload, children: Slice }

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ValuePayload { UInt(u128), Bool(bool), List, TreeLeaf(u128), TreeBranch }

#[derive(Clone, Debug, PartialEq, Eq)]
struct ValueRow { payload: ValuePayload, fields: Slice }

#[derive(Clone, Debug, PartialEq, Eq)]
struct ArmRow { pattern: Pattern, body: ExprId }

#[derive(Clone, Debug, PartialEq, Eq)]
struct FunctionRow {
    name: Name, parameters: Slice, return_type: Type, body: ExprId,
}

#[derive(Clone, Debug, PartialEq, Eq)]
struct EnvironmentRow { bindings: Slice }

#[derive(Clone, Debug, PartialEq, Eq)]
struct BindingRow { name: Name, value: ValueId }

#[derive(Clone, Debug, PartialEq, Eq)]
enum FrameRow {
    Let(Name, ExprId, EnvironmentId),
    Left(BinaryOp, ExprId, EnvironmentId),
    Right(BinaryOp, ValueId),
    Unary(UnaryOp),
    If(ExprId, ExprId, EnvironmentId),
    Match(Slice, EnvironmentId),
    Args(Name, Slice, Slice, EnvironmentId),
    Return(Type, EnvironmentId),
    Scope(EnvironmentId),
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum ControlRow {
    Eval(ExprId), Return(ValueId), Push(FrameId, ControlId, EnvironmentId),
    Invoke(Name, Slice), Enter(Option<FunctionId>, Slice),
    Bound(Option<EnvironmentId>, Type, ExprId),
    Cases(ValueId, Slice, EnvironmentId),
    CaseResult(Option<EnvironmentId>, ValueId, ExprId, Slice, EnvironmentId),
    PrimitiveResult(Result<ValueId, u8>), Error(u8),
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum OutcomeRow { Pending, Done(ValueId), Rejected(u8), Exhausted }

#[derive(Clone, Debug, PartialEq, Eq)]
struct ProgramRoots { entry: ExprId, functions: Slice }

/// Only a host proposal. Row fields are private; no state importer, public
/// consumer or claimed A4 decodeCanonical/decodeStep/project API is supplied.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct MachineImageDraft {
    limits: HostImageLimits,
    usage: HostImageUsage,
    program: ProgramRoots,
    expressions: Vec<ExprRow>,
    expr_children: Vec<ExprId>,
    arms: Vec<ArmRow>,
    functions: Vec<FunctionRow>,
    parameters: Vec<Parameter>,
    values: Vec<ValueRow>,
    value_ids: Vec<ValueId>,
    environments: Vec<EnvironmentRow>,
    bindings: Vec<BindingRow>,
    frames: Vec<FrameRow>,
    frame_ids: Vec<FrameId>,
    controls: Vec<ControlRow>,
    control: Option<ControlId>,
    environment: EnvironmentId,
    outcome: OutcomeRow,
    stack_limit: usize,
    remaining_fuel: u128,
    initial_fuel: u128,
}

impl MachineImageDraft {
    pub(super) fn usage(&self) -> HostImageUsage { self.usage }
    pub(super) fn limits(&self) -> HostImageLimits { self.limits }
}

/// Partial representation of finite typed snapshots; no semantic validity or
/// budget-invariant check is added. The input is borrowed and is never stepped.
/// Each persistent table row/cell/name copy is accounted before insertion.
pub(super) fn encode_snapshot(snapshot: &Snapshot, limits: HostImageLimits)
    -> EncodingResult<MachineImageDraft>
{
    let mut encoder = Encoder { image: MachineImageDraft {
        limits, usage: HostImageUsage::default(),
        program: ProgramRoots { entry: ExprId(0), functions: Slice::EMPTY },
        expressions: vec![], expr_children: vec![], arms: vec![], functions: vec![],
        parameters: vec![], values: vec![], value_ids: vec![], environments: vec![],
        bindings: vec![], frames: vec![], frame_ids: vec![], controls: vec![],
        control: None, environment: EnvironmentId(0), outcome: OutcomeRow::Pending,
        stack_limit: snapshot.stack_limit, remaining_fuel: snapshot.remaining_fuel,
        initial_fuel: snapshot.initial_fuel,
    }};
    let entry = encoder.expression(&snapshot.program.entry)?;
    let functions = Slice { start: encoder.image.functions.len(), len: snapshot.program.functions.len() };
    for function in &snapshot.program.functions { encoder.function(function)?; }
    encoder.image.program = ProgramRoots { entry, functions };
    let environment = encoder.environment(&snapshot.environment)?;
    encoder.image.environment = environment;
    encoder.account(HostLimitKind::Cells, snapshot.frames.len())?;
    for frame in &snapshot.frames {
        let id = encoder.frame(frame)?;
        encoder.image.frame_ids.push(id);
    }
    if let Some(control) = &snapshot.control {
        let id = encoder.control(control)?;
        encoder.image.control = Some(id);
    }
    encoder.image.outcome = match &snapshot.outcome {
        Outcome::Pending => OutcomeRow::Pending,
        Outcome::Done(value) => OutcomeRow::Done(encoder.value(ValueInput::Value(value))?),
        Outcome::Rejected(code) => OutcomeRow::Rejected(*code),
        Outcome::Exhausted => OutcomeRow::Exhausted,
    };
    Ok(encoder.image)
}

struct Encoder { image: MachineImageDraft }

#[derive(Clone, Copy)]
enum ValueInput<'a> { Value(&'a Value), UInt(u128), Tree(&'a Tree) }

struct ExprTask<'a> {
    input: &'a Expr, parent_cell: Option<usize>, parent_arm: Option<usize>,
}

impl Encoder {
    fn account(&mut self, kind: HostLimitKind, additional: usize) -> EncodingResult<()> {
        let (used, limit) = match kind {
            HostLimitKind::Rows => (&mut self.image.usage.rows, self.image.limits.rows),
            HostLimitKind::Cells => (&mut self.image.usage.cells, self.image.limits.cells),
            HostLimitKind::NameBytes => (&mut self.image.usage.name_bytes, self.image.limits.name_bytes),
        };
        let Some(total) = used.checked_add(additional).filter(|total| *total <= limit) else {
            return Err(HostEncodingRefusal { kind, used: *used, additional, limit });
        };
        *used = total;
        Ok(())
    }

    fn name(&mut self, name: &str) -> EncodingResult<Name> {
        self.account(HostLimitKind::NameBytes, name.len())?;
        Ok(name.to_owned())
    }

    fn pattern(&mut self, pattern: &Pattern) -> EncodingResult<Pattern> {
        Ok(match pattern {
            Pattern::Var(name) => Pattern::Var(self.name(name)?),
            Pattern::Nil => Pattern::Nil,
            Pattern::Cons(a, b) => Pattern::Cons(self.name(a)?, self.name(b)?),
            Pattern::Leaf(name) => Pattern::Leaf(self.name(name)?),
            Pattern::Branch(a, b) => Pattern::Branch(self.name(a)?, self.name(b)?),
        })
    }

    fn expr_cells(&mut self, len: usize) -> EncodingResult<Slice> {
        self.account(HostLimitKind::Cells, len)?;
        let slice = Slice { start: self.image.expr_children.len(), len };
        self.image.expr_children.resize(slice.start + len, ExprId(0));
        Ok(slice)
    }

    fn value_cells(&mut self, len: usize) -> EncodingResult<Slice> {
        self.account(HostLimitKind::Cells, len)?;
        let slice = Slice { start: self.image.value_ids.len(), len };
        self.image.value_ids.resize(slice.start + len, ValueId(0));
        Ok(slice)
    }

    fn reserve_arms(&mut self, arms: &[Arm]) -> EncodingResult<Slice> {
        self.account(HostLimitKind::Rows, arms.len())?;
        let slice = Slice { start: self.image.arms.len(), len: arms.len() };
        for arm in arms {
            let pattern = self.pattern(&arm.pattern)?;
            self.image.arms.push(ArmRow { pattern, body: ExprId(0) });
        }
        Ok(slice)
    }

    fn arms(&mut self, arms: &[Arm]) -> EncodingResult<Slice> {
        let slice = self.reserve_arms(arms)?;
        for (position, arm) in arms.iter().enumerate() {
            let body = self.expression(&arm.body)?;
            self.image.arms[slice.start + position].body = body;
        }
        Ok(slice)
    }

    fn expression(&mut self, expression: &ExprRef) -> EncodingResult<ExprId> {
        let root = ExprId(self.image.expressions.len());
        let mut pending = vec![ExprTask { input: expression.as_ref(), parent_cell: None, parent_arm: None }];
        while let Some(task) = pending.pop() {
            self.account(HostLimitKind::Rows, 1)?;
            let id = ExprId(self.image.expressions.len());
            self.image.expressions.push(ExprRow { payload: ExprPayload::If, children: Slice::EMPTY });
            if let Some(cell) = task.parent_cell { self.image.expr_children[cell] = id; }
            if let Some(arm) = task.parent_arm { self.image.arms[arm].body = id; }
            let mut children: Vec<(&Expr, Option<usize>)> = vec![];
            let payload = match task.input {
                Expr::Literal(value) => ExprPayload::Literal(self.value(ValueInput::Value(value))?),
                Expr::Var(name) => ExprPayload::Var(self.name(name)?),
                Expr::Let(name, value, body) => {
                    children.extend([(value.as_ref(), None), (body.as_ref(), None)]);
                    ExprPayload::Let(self.name(name)?)
                }
                Expr::Binary(op, left, right) => {
                    children.extend([(left.as_ref(), None), (right.as_ref(), None)]);
                    ExprPayload::Binary(*op)
                }
                Expr::Unary(op, value) => {
                    children.push((value.as_ref(), None));
                    ExprPayload::Unary(*op)
                }
                Expr::If(condition, yes, no) => {
                    children.extend([(condition.as_ref(), None), (yes.as_ref(), None), (no.as_ref(), None)]);
                    ExprPayload::If
                }
                Expr::Call(name, args) => {
                    children.extend(args.iter().map(|arg| (arg.as_ref(), None)));
                    ExprPayload::Call(self.name(name)?)
                }
                Expr::Match(value, arms) => {
                    children.push((value.as_ref(), None));
                    let slice = self.reserve_arms(arms)?;
                    children.extend(arms.iter().enumerate().map(|(position, arm)|
                        (arm.body.as_ref(), Some(slice.start + position))));
                    ExprPayload::Match(slice)
                }
            };
            let slice = self.expr_cells(children.len())?;
            self.image.expressions[id.0] = ExprRow { payload, children: slice };
            for (position, (input, parent_arm)) in children.into_iter().enumerate().rev() {
                pending.push(ExprTask { input, parent_cell: Some(slice.start + position), parent_arm });
            }
        }
        Ok(root)
    }

    fn expressions(&mut self, expressions: &[ExprRef]) -> EncodingResult<Slice> {
        let slice = self.expr_cells(expressions.len())?;
        for (position, expression) in expressions.iter().enumerate() {
            let id = self.expression(expression)?;
            self.image.expr_children[slice.start + position] = id;
        }
        Ok(slice)
    }

    fn value(&mut self, value: ValueInput<'_>) -> EncodingResult<ValueId> {
        let root = ValueId(self.image.values.len());
        let mut pending = vec![(value, None)];
        while let Some((input, parent_cell)) = pending.pop() {
            self.account(HostLimitKind::Rows, 1)?;
            let id = ValueId(self.image.values.len());
            if let Some(cell) = parent_cell { self.image.value_ids[cell] = id; }
            let mut children = vec![];
            let payload = match input {
                ValueInput::UInt(n) => ValuePayload::UInt(n),
                ValueInput::Value(Value::UInt(n)) => ValuePayload::UInt(*n),
                ValueInput::Value(Value::Bool(value)) => ValuePayload::Bool(*value),
                ValueInput::Value(Value::List(values)) => {
                    children.extend(values.iter().copied().map(ValueInput::UInt));
                    ValuePayload::List
                }
                ValueInput::Value(Value::Tree(tree)) | ValueInput::Tree(tree) => match tree {
                    Tree::Leaf(value) => ValuePayload::TreeLeaf(*value),
                    Tree::Branch(left, right) => {
                        children.extend([ValueInput::Tree(left.as_ref()), ValueInput::Tree(right.as_ref())]);
                        ValuePayload::TreeBranch
                    }
                },
            };
            let fields = self.value_cells(children.len())?;
            self.image.values.push(ValueRow { payload, fields });
            for (position, child) in children.into_iter().enumerate().rev() {
                pending.push((child, Some(fields.start + position)));
            }
        }
        Ok(root)
    }

    fn values(&mut self, values: &[Value]) -> EncodingResult<Slice> {
        let slice = self.value_cells(values.len())?;
        for (position, value) in values.iter().enumerate() {
            let id = self.value(ValueInput::Value(value))?;
            self.image.value_ids[slice.start + position] = id;
        }
        Ok(slice)
    }

    fn function(&mut self, function: &Function) -> EncodingResult<FunctionId> {
        self.account(HostLimitKind::Rows, 1)?;
        let id = FunctionId(self.image.functions.len());
        let name = self.name(&function.name)?;
        let parameters = Slice { start: self.image.parameters.len(), len: function.parameters.len() };
        self.account(HostLimitKind::Rows, parameters.len)?;
        for parameter in &function.parameters {
            let name = self.name(&parameter.name)?;
            self.image.parameters.push(Parameter { name, ty: parameter.ty });
        }
        let body = self.expression(&function.body)?;
        self.image.functions.push(FunctionRow { name, parameters, return_type: function.return_type, body });
        Ok(id)
    }

    fn environment(&mut self, environment: &Environment) -> EncodingResult<EnvironmentId> {
        self.account(HostLimitKind::Rows, 1)?;
        let id = EnvironmentId(self.image.environments.len());
        let bindings = Slice { start: self.image.bindings.len(), len: environment.len() };
        for (name, value) in environment {
            self.account(HostLimitKind::Rows, 1)?;
            let name = self.name(name)?;
            let value = self.value(ValueInput::Value(value))?;
            self.image.bindings.push(BindingRow { name, value });
        }
        self.image.environments.push(EnvironmentRow { bindings });
        Ok(id)
    }

    fn frame(&mut self, frame: &Frame) -> EncodingResult<FrameId> {
        self.account(HostLimitKind::Rows, 1)?;
        let id = FrameId(self.image.frames.len());
        let row = match frame {
            Frame::Let(name, body, saved) => FrameRow::Let(self.name(name)?, self.expression(body)?, self.environment(saved)?),
            Frame::Left(op, right, saved) => FrameRow::Left(*op, self.expression(right)?, self.environment(saved)?),
            Frame::Right(op, value) => FrameRow::Right(*op, self.value(ValueInput::Value(value))?),
            Frame::Unary(op) => FrameRow::Unary(*op),
            Frame::If(yes, no, saved) => FrameRow::If(self.expression(yes)?, self.expression(no)?, self.environment(saved)?),
            Frame::Match(arms, saved) => FrameRow::Match(self.arms(arms)?, self.environment(saved)?),
            Frame::Args(name, values, rest, saved) => FrameRow::Args(
                self.name(name)?, self.values(values)?, self.expressions(rest)?, self.environment(saved)?),
            Frame::Return(ty, saved) => FrameRow::Return(*ty, self.environment(saved)?),
            Frame::Scope(saved) => FrameRow::Scope(self.environment(saved)?),
        };
        self.image.frames.push(row);
        Ok(id)
    }

    fn control_slot(&mut self) -> EncodingResult<ControlId> {
        self.account(HostLimitKind::Rows, 1)?;
        let id = ControlId(self.image.controls.len());
        self.image.controls.push(ControlRow::Error(0));
        Ok(id)
    }

    fn control(&mut self, control: &Control) -> EncodingResult<ControlId> {
        let root = self.control_slot()?;
        let mut id = root;
        let mut current = control;
        loop {
            if let Control::Push(frame, next, environment) = current {
                let frame = self.frame(frame)?;
                let environment = self.environment(environment)?;
                let next_id = self.control_slot()?;
                self.image.controls[id.0] = ControlRow::Push(frame, next_id, environment);
                id = next_id;
                current = next.as_ref();
                continue;
            }
            let row = match current {
                Control::Eval(body) => ControlRow::Eval(self.expression(body)?),
                Control::Return(value) => ControlRow::Return(self.value(ValueInput::Value(value))?),
                Control::Invoke(name, values) => ControlRow::Invoke(self.name(name)?, self.values(values)?),
                Control::Enter(function, values) => ControlRow::Enter(
                    function.as_ref().map(|function| self.function(function)).transpose()?, self.values(values)?),
                Control::Bound(bindings, ty, body) => ControlRow::Bound(
                    bindings.as_ref().map(|bindings| self.environment(bindings)).transpose()?, *ty, self.expression(body)?),
                Control::Cases(value, arms, saved) => ControlRow::Cases(
                    self.value(ValueInput::Value(value))?, self.arms(arms)?, self.environment(saved)?),
                Control::CaseResult(bindings, value, body, rest, saved) => ControlRow::CaseResult(
                    bindings.as_ref().map(|bindings| self.environment(bindings)).transpose()?,
                    self.value(ValueInput::Value(value))?, self.expression(body)?, self.arms(rest)?, self.environment(saved)?),
                Control::PrimitiveResult(result) => ControlRow::PrimitiveResult(match result {
                    Ok(value) => Ok(self.value(ValueInput::Value(value))?), Err(code) => Err(*code),
                }),
                Control::Error(code) => ControlRow::Error(*code),
                Control::Push(_, _, _) => unreachable!("push chain handled iteratively"),
            };
            self.image.controls[id.0] = row;
            break;
        }
        Ok(root)
    }
}

/// Decode normal finite acyclic typed row images from this proposal, including
/// encoder outputs. This is structural materialization only. No malformed-input
/// admission, canonicality, foreign-code check or A4 security policy is supplied.
pub(super) fn decode_snapshot(image: &MachineImageDraft) -> Snapshot {
    let values = decode_values(image);
    let expressions = decode_expressions(image, &values);
    let environments: Vec<Environment> = image.environments.iter().map(|environment|
        environment.bindings.get(&image.bindings).iter().map(|binding|
            (binding.name.clone(), values[binding.value.0].clone())).collect()).collect();
    let functions: Vec<Function> = image.functions.iter().map(|function| Function {
        name: function.name.clone(), parameters: function.parameters.get(&image.parameters).to_vec(),
        return_type: function.return_type, body: expressions[function.body.0].clone(),
    }).collect();
    let decoded = Decoded { image, values, expressions, environments, functions };
    let outcome = match &image.outcome {
        OutcomeRow::Pending => Outcome::Pending,
        OutcomeRow::Done(value) => Outcome::Done(decoded.value(*value)),
        OutcomeRow::Rejected(code) => Outcome::Rejected(*code),
        OutcomeRow::Exhausted => Outcome::Exhausted,
    };
    Snapshot {
        program: Arc::new(Program {
            entry: decoded.expression(image.program.entry),
            functions: image.program.functions.get(&decoded.functions).to_vec(),
        }),
        control: image.control.map(|root| decoded.control(root)),
        environment: decoded.environment(image.environment),
        frames: image.frame_ids.iter().map(|id| decoded.frame(*id)).collect(),
        stack_limit: image.stack_limit, remaining_fuel: image.remaining_fuel,
        initial_fuel: image.initial_fuel, outcome,
    }
}

fn decode_values(image: &MachineImageDraft) -> Vec<Value> {
    let mut values: Vec<Option<Value>> = vec![None; image.values.len()];
    // Iterative dependency visits support ordinary acyclic rows in either
    // parent/child index order; no cycle/adversarial admission claim is made.
    for root in 0..image.values.len() {
        let mut pending = vec![(root, false)];
        while let Some((index, visited)) = pending.pop() {
            if values[index].is_some() { continue; }
            let row = &image.values[index];
            let fields = row.fields.get(&image.value_ids);
            if !visited {
                pending.push((index, true));
                pending.extend(fields.iter().rev().map(|id| (id.0, false)));
                continue;
            }
            let field = |position: usize| values[fields[position].0].as_ref().expect("normal acyclic value dependency");
            let value = match row.payload {
                ValuePayload::UInt(value) => Value::UInt(value),
                ValuePayload::Bool(value) => Value::Bool(value),
                ValuePayload::List => Value::List((0..fields.len()).map(|position| match field(position) {
                    Value::UInt(value) => *value, _ => unreachable!("normal typed list field"),
                }).collect()),
                ValuePayload::TreeLeaf(value) => Value::Tree(Tree::Leaf(value)),
                ValuePayload::TreeBranch => match (field(0), field(1)) {
                    (Value::Tree(left), Value::Tree(right)) => Value::Tree(Tree::Branch(
                        Arc::new(left.clone()), Arc::new(right.clone()))),
                    _ => unreachable!("normal typed branch fields"),
                },
            };
            values[index] = Some(value);
        }
    }
    values.into_iter().map(|value| value.expect("normal value row materialized")).collect()
}

fn decode_expressions(image: &MachineImageDraft, values: &[Value]) -> Vec<ExprRef> {
    let mut expressions: Vec<Option<ExprRef>> = vec![None; image.expressions.len()];
    for root in 0..image.expressions.len() {
        let mut pending = vec![(root, false)];
        while let Some((index, visited)) = pending.pop() {
            if expressions[index].is_some() { continue; }
            let row = &image.expressions[index];
            let children = row.children.get(&image.expr_children);
            if !visited {
                pending.push((index, true));
                pending.extend(children.iter().rev().map(|id| (id.0, false)));
                continue;
            }
            let expression = |id: ExprId| expressions[id.0].as_ref().expect("normal acyclic expression dependency").clone();
            let child = |position: usize| expression(children[position]);
            let expr = match &row.payload {
                ExprPayload::Literal(id) => Expr::Literal(values[id.0].clone()),
                ExprPayload::Var(name) => Expr::Var(name.clone()),
                ExprPayload::Let(name) => Expr::Let(name.clone(), child(0), child(1)),
                ExprPayload::Binary(op) => Expr::Binary(*op, child(0), child(1)),
                ExprPayload::Unary(op) => Expr::Unary(*op, child(0)),
                ExprPayload::If => Expr::If(child(0), child(1), child(2)),
                ExprPayload::Call(name) => Expr::Call(name.clone(), children.iter().map(|id| expression(*id)).collect()),
                ExprPayload::Match(arms) => Expr::Match(child(0), arms.get(&image.arms).iter().map(|arm| Arm {
                    pattern: arm.pattern.clone(), body: expression(arm.body),
                }).collect()),
            };
            expressions[index] = Some(Arc::new(expr));
        }
    }
    expressions.into_iter().map(|expr| expr.expect("normal expression row materialized")).collect()
}

struct Decoded<'a> {
    image: &'a MachineImageDraft,
    values: Vec<Value>, expressions: Vec<ExprRef>, environments: Vec<Environment>, functions: Vec<Function>,
}

impl Decoded<'_> {
    fn value(&self, id: ValueId) -> Value { self.values[id.0].clone() }
    fn expression(&self, id: ExprId) -> ExprRef { self.expressions[id.0].clone() }
    fn environment(&self, id: EnvironmentId) -> Environment { self.environments[id.0].clone() }
    fn values(&self, slice: Slice) -> Vec<Value> {
        slice.get(&self.image.value_ids).iter().map(|id| self.value(*id)).collect()
    }
    fn expressions(&self, slice: Slice) -> Vec<ExprRef> {
        slice.get(&self.image.expr_children).iter().map(|id| self.expression(*id)).collect()
    }
    fn arms(&self, slice: Slice) -> Vec<Arm> {
        slice.get(&self.image.arms).iter().map(|arm| Arm {
            pattern: arm.pattern.clone(), body: self.expression(arm.body),
        }).collect()
    }
    fn frame(&self, id: FrameId) -> Frame {
        match &self.image.frames[id.0] {
            FrameRow::Let(name, body, saved) => Frame::Let(name.clone(), self.expression(*body), self.environment(*saved)),
            FrameRow::Left(op, right, saved) => Frame::Left(*op, self.expression(*right), self.environment(*saved)),
            FrameRow::Right(op, value) => Frame::Right(*op, self.value(*value)),
            FrameRow::Unary(op) => Frame::Unary(*op),
            FrameRow::If(yes, no, saved) => Frame::If(self.expression(*yes), self.expression(*no), self.environment(*saved)),
            FrameRow::Match(arms, saved) => Frame::Match(self.arms(*arms), self.environment(*saved)),
            FrameRow::Args(name, values, rest, saved) => Frame::Args(
                name.clone(), self.values(*values), self.expressions(*rest), self.environment(*saved)),
            FrameRow::Return(ty, saved) => Frame::Return(*ty, self.environment(*saved)),
            FrameRow::Scope(saved) => Frame::Scope(self.environment(*saved)),
        }
    }
    fn control(&self, root: ControlId) -> Control {
        let mut id = root;
        let mut pushes = vec![];
        let mut control = loop {
            let row = &self.image.controls[id.0];
            if let ControlRow::Push(frame, next, environment) = row {
                pushes.push((*frame, *environment));
                id = *next;
                continue;
            }
            break match row {
                ControlRow::Eval(body) => Control::Eval(self.expression(*body)),
                ControlRow::Return(value) => Control::Return(self.value(*value)),
                ControlRow::Invoke(name, values) => Control::Invoke(name.clone(), self.values(*values)),
                ControlRow::Enter(function, values) => Control::Enter(
                    function.map(|id| self.functions[id.0].clone()), self.values(*values)),
                ControlRow::Bound(bindings, ty, body) => Control::Bound(
                    bindings.map(|id| self.environment(id)), *ty, self.expression(*body)),
                ControlRow::Cases(value, arms, saved) => Control::Cases(
                    self.value(*value), self.arms(*arms), self.environment(*saved)),
                ControlRow::CaseResult(bindings, value, body, rest, saved) => Control::CaseResult(
                    bindings.map(|id| self.environment(id)), self.value(*value), self.expression(*body), self.arms(*rest), self.environment(*saved)),
                ControlRow::PrimitiveResult(result) => Control::PrimitiveResult(match result {
                    Ok(value) => Ok(self.value(*value)), Err(code) => Err(*code),
                }),
                ControlRow::Error(code) => Control::Error(*code),
                ControlRow::Push(_, _, _) => unreachable!("push chain handled iteratively"),
            };
        };
        for (frame, environment) in pushes.into_iter().rev() {
            control = Control::Push(self.frame(frame), Box::new(control), self.environment(environment));
        }
        control
    }
}

#[cfg(test)]
#[path = "machine_image_tests.rs"]
mod tests;
