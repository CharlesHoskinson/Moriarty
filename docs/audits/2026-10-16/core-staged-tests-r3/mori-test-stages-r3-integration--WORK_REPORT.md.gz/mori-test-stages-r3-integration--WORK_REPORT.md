# R3 complete-candidate mechanical integration: frozen handoff

In the R3 successor worktree, copied exact `independent-oracle-r3/` membership:
freeze SHA `ad44178b801dc51bfa6e254a2d9b48c18a4f7ea99e7b919be75730dc761cc34d`
plus24 bound files,25 total. Six manifest-named root reports and four complete
program/plan preimages now match the corresponding frozen R3 bytes exactly.
No assembly script or Moriarty parser/evaluator was run.

Archived exact21 original blocked files under `history/blocked-r2/`:20 old
regular fixture files plus original PROVENANCE.md. A new history/README.md is
outside that frozen21 and labels it blocked/unusable history. OldWT, original
root expectation-freeze.json and copiedr2 folder remain unchanged. Root freeze
relative hashes refer to archived old members, not current root fixture bytes.

Concise current PROVENANCE.md and the guide now identify the R3 frozen source
candidate, actual oracle program/plan digests, both unused declaration actions,
R7 and condition-consistency limits. Exact Opus S1-S3 guide sentences remain.
Historical C1-C6/N1-N6 and all14 draft gaps are retained with immutable record
links. R2 positive-data approvals remain invalidated historical only. No assumed
approval or stale global review-pending claim: actual dispositions belong to
Root's final `docs/audits/2026-10-16/core-staged-tests-r3/REVIEW-BINDING.json`,
which must exist before publication. Two exact pre-integration prose copies are
preserved only in this runtime handoff's history/ directory.

All8 frozen input pins and all235 public Rust source pins are unchanged.
Ownership stayed within specified data/history/prose paths. No Rust/test/code,
manifest/normative/premise source/index/privateClean/old92packet was edited.
All copied membership hashes, archive identities, before/after replacement and
prose hashes, input pins, Rust pins and actual old47 changes are in WORK_REPORT.json.
Two complete report replacements happen to retain identical old bytes; allten
specified root files were nevertheless copied from R3 and checked against it.

Source integration is authorized reversible preparation for fresh joint
Muse/Opus source/data/draft-publication reviews. Those reviews are still due;
no prior approval is applied. Build/tests/CLI/evaluator/actual-output comparisons
are **UNRUN**; comparison admission NOT_GRANTED; native authority0. No proof,
financial/native/printed-format acceptance or parent-roadmap exit follows.
No model/subagent, commit/push/merge, SDK/native/cache action or publication.
