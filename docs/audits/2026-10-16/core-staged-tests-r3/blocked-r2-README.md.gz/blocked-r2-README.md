# Core/2 staged-test source and expectation packet

This source candidate adds the moriarty-tests/2 manifest to public `mori test`.
It invokes the existing local Core/2 load/start/resume APIs and compares complete
reports, including local/unauthenticated/consumption-untracked labels. Its source
normal tests use the actual public binary path. No build, public command, test or
runtime-output comparison has been run for this candidate. Native authority is zero.

The original implementation author supplied provisional expectations. A separately
blinded author then derived six complete normal report candidates. The preserved
r1 freeze had twelve trace-value gaps; r2 fills only those twelve fields under
P-TRACE-PROJ/draft, a disclosed source-observed selection convention. Separate
reviews approve only the frozen normal expectations, under C1–C6 and N1–N6.
All fourteen trace-contract draft gaps remain open. The draft is unadopted.
Agreement on its conventions is not independent semantic correctness or proof.

Root verified the eight input hashes, four preimage hashes, exact r1/r2 value-only
delta and the six expected-file byte equalities. Those are literal-data checks,
not interpreter observations or execution admission. The new oracle subdirectory
also required a regular-file guard in the test fixture copier. Those changed test
and prose bytes require the final candidate review; older source approvals retain
their historical scope.

All original author reports, blocked and later source reviews, expectation and
premise reviews, original partial oracle data, and trace draft are captured
verbatim. CAPTURE-BINDING.json binds their original and gzip bytes. Historical
UNRUN, partial or review-pending labels describe their original records. The final
review binding records only the actual newer verdicts and their limited scope.
Scripts in the frozen data are provenance records with original local paths,
not portable public commands, and were not executed by this integration.

This packet does not admit Cargo, SDK/native work, a retry of terminal subjects,
proving, deployment or ledger operations. It establishes no printed-byte-format,
Rust/Quint/Lean/circuit correspondence, financial/native/target acceptance or
U0–U7/M1–M17/MC/SP/G exit. Source publication is proposed as a draft PR only.
