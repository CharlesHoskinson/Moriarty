# Local Core/2 staged tests

The additive `moriarty-tests/2` manifest runs existing `moriarty/2` programs
through the ordinary Rust `mori test DIRECTORY` command. It calls the actual
Core/2 `stage::load`, `stage::start` and `stage::resume` APIs. The language,
semantics and continuation formats are unchanged. `moriarty-tests/1` keeps its
existing atomic consumer and report format.

This candidate is source-only: build, public command execution, tests and
actual-output comparisons are **UNRUN**. The checked-in
[examples](../models/core-stage-tests/mori-tests.json) still name historical
expected files and preimages. The old author/R1/R2 six-report expectation sets
and their approvals are unusable for current positive-path validation: final
Opus source review found that they omitted the existing R7 liability-registry
premise. Original copies and freezes remain preserved.

The R3 sources append unused matching-duty `declare` actions after their target
actions; target deliver/charge code and incoming duty5/duty3 scenarios remain
unchanged. New whole-program/plan hashes and fresh blinded R3 reports are pending
Root integration and review. This candidate is **not publication ready**, and
no comparison or execution admission follows. See
[fixture provenance](../models/core-stage-tests/PROVENANCE.md) for the preserved
historical C1–C6/N1–N6 scopes and all fourteen open draft gaps.

A directory contains `mori-tests.json`:

```json
{
  "profile": "moriarty-tests/2",
  "cases": [{
    "name": "two-deliveries",
    "source": "two-deliveries.mori",
    "action": "deliver",
    "scenario": "two-deliveries-scenario.json",
    "logical_cap": "16",
    "expected": "two-deliveries-start.json",
    "events": [
      {"event": "approval-false.json", "expected": "two-deliveries-observed.json"},
      {"event": "approval-true.json", "expected": "two-deliveries-approved.json"},
      {"event": "receipt-true.json", "expected": "two-deliveries-complete.json"}
    ]
  }]
}
```

All keys shown are required. `logical_cap` is a canonical unsigned decimal
string or explicit `null`. Paths resolve from the manifest directory using the
existing test-command path convention.
paths are not confined to the directory; treat the manifest as trusted input.
There are 1–256 cases with unique,
nonempty names and at most 255 events per case, giving at most 256 invocations
including start. An empty event list tests the start result alone. Each case
starts independently from its scenario.

Under the existing R7 source check, liability identities at an awaiting start
and at a resume boundary must match an exact identity registered from a
`Liability` statement across the program's actions. The examples' unused
`declare` actions provide those matching identities without being executed by
the selected deliver/charge trajectories. Declaration presence alone implies
neither liability creation nor discharge. This is the source premise identified
in the final Opus finding; no runtime pass is claimed.

The start report is compared to `expected`; each ordered event resumes the
actual pending continuation and compares its report to that event's expected
file. Expected values never provide runtime state or continuations. A false
guard retains the actual pending continuation. A rejected resume also retains
its actual input for a later explicitly listed event. After a complete result,
or a rejected start, a further event is a command error because no actual
pending continuation exists.
A rejection before resume admission (event read/decode) reports attempted 0 and committed 0, as public `simulate` does; the retained continuation's committed work is unchanged.

Each expected file contains the **entire** report envelope printed by public
`mori simulate` for that invocation. Waiting reports include status, advanced,
segment (including explicit null), continuation, attempted/committed logical
work and residual liabilities. Complete reports include the full segment,
work and residuals. Rejected reports include the complete error and work.
Every actual report retains these literal qualifications:

```json
{"qualification":"local-reference-stage","authentication":"none","consumption":"untracked"}
```

Segments include action, pending frames, semantics, pre/post snapshots, ordered
steps with serialized statements and expression IDs, and ordered effects.
Continuations include program/plan hashes, site, ordered captures, logical cap
and committed work, and the whole boundary. Supply those fields explicitly;
there are no wildcards, omitted-field defaults, generated expectations or
selected-field comparisons. Object key order and JSON whitespace do not affect
equality. Array order, absent versus present fields, explicit nulls, values and
all additional fields do affect equality. Unknown manifest fields are errors;
additional expected-report fields cause a comparison mismatch.

Manifest, source, scenario and expected files retain the existing 1 MiB reader
ceiling and strict JSON parser. Event files use the existing strict Core/2
64 KiB event decoder. The harness passes actual typed continuations in memory;
it does not read or write continuation files or record their consumption.
Existing language limits and logical-cost semantics still apply. Logical work
is distinct from circuit cost, DUST, service fees and recovery reserves.

The aggregate retains `status` and ordered `cases`. Each case reports `name`,
`passed`, and ordered `stages`; each stage reports zero-based `index`, `passed`
and complete `actual`.
`passed` is a comparison verdict over local-reference-stage reports; the qualification labels are carried by each `actual`.
An expectation mismatch fails that case, retains its
actual report, and continues with actual state through later events and cases.
Any mismatch returns nonzero. A manifest/input error or impossible event
sequence also returns nonzero. Individual case export keeps the existing 1 MiB
export bound; an unexportable case publishes no partial JSON aggregate.

This is local, unauthenticated execution with consumption untracked. Test
agreement does not establish native proofs, settlement, authenticated events,
once-only consumption, circuit correspondence or complete conditional recovery.
U3, M10, the partial/conditional requirements, helper/circuit/native work and
every retained roadmap exit remain open. Security and hostile-test judgments
remain assigned to Opus; this document supplies none.
