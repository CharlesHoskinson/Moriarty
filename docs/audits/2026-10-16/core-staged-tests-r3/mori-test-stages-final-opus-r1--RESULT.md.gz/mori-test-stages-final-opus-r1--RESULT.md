# Verdict: **BLOCKED**

## The defect

Both test scenarios contain an external `duty` liability. The unchanged `/2` start admission rejects that liability, so both cases fail at their first step. The checked-in expectations and every published account of these cases were built on a premise that the actual consumer contradicts.

The rejection path, from the supplied unchanged source:

1. `stage::start` in `crates/mori-core/src/stage/admit.rs` calls `decode::canonical_boundary(sp, index, &inputs, &pre)` before any segment runs. It does this whenever the action has an await site (`if !plan.sites.is_empty()`), and both actions have one.
2. `canonical_boundary` step (c) in `crates/mori-core/src/stage/decode.rs` requires every boundary liability to appear in `registry(p)` with the same identity. `registry(p)` is built only from `Statement::Liability` statements across all actions:
   ```rust
   if registry.get(l.name.as_str()) != Some(&(&l.asset, l.debtor.as_str(), l.creditor.as_str())) {
       return Err(Error::new("liability", format!("Existing liability identity differs for {:?}.", l.name)));
   }
   ```
3. Neither `two-deliveries.mori` nor `quoted-fee.mori` contains a `liability` statement, so both registries are empty. Yet `two-deliveries-scenario.json` has `duty` (alice→bob, 5) and `quoted-fee-scenario.json` has `duty` (payer→treasury, 3). The legacy `scenario_snapshot` accepts undeclared incoming duties; R7 does not.

What the actual consumer therefore does, derived from source and not observed:

- **Both starts are rejected.** Each returns `{"status":"rejected","error":{"code":"mori::core::liability","message":"Existing liability identity differs for \"duty\".","offset":null,"step":null},"attempted":"0","committed":"0"}` plus the three labels. The same check inside `emit_checked` would also refuse any continuation carrying `duty`.
- **The two-deliveries case then stops the whole command.** After the rejected start, `pending` is `None`, so its first event raises the command error "a staged test event requires an actual pending continuation". The command exits nonzero with no JSON on stdout. This is consistent with `stage_test.rs` and the guide.
- **Both new public tests would fail.** `full_reports_match_…` and `expected_report_transcription_mismatches_…` both assert an exit code and parse stdout as JSON.

What this invalidates:

- All six expected reports in both the author-supplied copies and the `independent-oracle-r2` copies.
- The "duty5/duty3 survive every segment" accounting in `PROVENANCE.md`, `DERIVATION.md`, the r1 accounting record and the README packet.
- The basis of the two frozen-data approvals.

Why earlier reviews did not catch it:

- Opus source r1 did not read `decode.rs`.
- The Opus trace review and r2 data review recorded `canonical_boundary` as unsupplied (GAP-13).
- N1 lists other source premises but not R7.
- Root's literal correspondence compares two static expectation sets that share the same omitted premise, so their exact agreement could not detect it.

This finding comes from reading source, the same evidence class as the pinned-serde clarification. Execution remains UNRUN.

## What correcting it requires

This is Root's decision. Any correction changes the eight hashed inputs. That invalidates `expectation-freeze.json`, both preimage sets if the source changes, the r1 and r2 freezes, the gap map and the literal correspondence record. Two routes would satisfy R7:

- **(a) Remove the `duty` rows from both scenarios.** Program and plan hashes stay the same, but residuals become `[]`, and the "transfer is not discharge" contrast is lost.
- **(b) Declare `duty` through a source `liability` statement** with a matching identity, for example in a separate action that never runs. This changes the program, the expression arena, the plan and both hashes.

Either route needs a fresh blinded oracle derivation that is given `decode.rs`/R7 as a disclosed premise, new data reviews and a new final review.

Do not "fix" the fixtures by rewriting the expected files to the rejected outputs. That would discard the positive staged trajectories this candidate exists to test. It would also amount to deriving expectations from consumer behaviour rather than independently. Keep the existing records preserved as historical captures.

## Other judgments, so the next round can be narrower

These are conditional. None of them lifts the block.

- **`test.rs`, `stage_test.rs`, the dispatch and the continuation chain.** These bytes are unchanged from the prior review, and no new security defect is found. Expected values never reach `start`/`resume`, labels appear in every actual report, and rejected or false resumes keep only the actual continuation. Findings S1–S6 stay as previously disposed, with the S1–S3 sentences present in the guide.
- **Test-helper guard.** `DirEntry::file_type()` does not follow symlinks, so the guard skips both directories and symlinks. That is acceptable and conservative. The test still runs the real `CARGO_BIN_EXE_mori`.
- **Privacy and disclosure.** The captures include the host username and paths, the `/root/...` owner label, cargo registry paths, provider request and response IDs, and token and cost figures. I judge these acceptable for deliberate public disclosure: I saw no credentials, keys, environment values or Clean/Fenrir content.
- **CI and publication trigger.** The only active workflow, `site.yml`, filters on `site/**` and its own path for both `push` and `pull_request`, and deploys only from `main`. This candidate touches neither filtered path. A draft PR from `feat/mori-test-stages-20261016` should therefore trigger no configured workflow. A suitable bounded read-only tripwire after any future push: confirm that no workflow runs exist for the branch or PR.

## Unchanged

- No build, test, CLI run, comparison, SDK or native action is admitted; execution is UNRUN, comparison admission is NOT_GRANTED and native authority stays 0.
- C1–C6 and N1–N6 still apply, all 14 draft gaps stay open, and GAP-13 now has a contradicting observation rather than a resolution.
- Muse R1 BLOCKED and the R2 serde clarification are preserved as historical records.
- No U0–U7, M1–M17, MC/SP/G, partial/conditional or parent exit is affected or closed.
- I am `claude-opus-5-5`, the same model as earlier Opus reviewers. My non-authorship rests on a separate context. I recomputed no hashes.
