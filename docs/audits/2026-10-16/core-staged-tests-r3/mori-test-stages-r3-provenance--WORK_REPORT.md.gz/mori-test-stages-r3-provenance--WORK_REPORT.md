# R3 current provenance: frozen prose-only handoff

Updated only `models/core-stage-tests/PROVENANCE.md` and
`docs/CORE-STAGED-TESTS.md` in the R3 successor worktree. Exact before/after
hashes and integrity checks are in adjacent `WORK_REPORT.json`.

Both documents now make the final Opus R7 BLOCKED finding explicit: historical
author/R1/R2 six-report expectations and their approvals cannot validate the
intended positive paths, because the original sources omitted the program-wide
Liability identity registry premise. Historical copies/freezes are retained,
not rewritten. The R3 source declarations and unchanged incoming duty5/3 are
identified; declaration presence implies no execution, liability creation or
discharge in the target trajectories. No new rule or security judgment is added.

New whole-program/plan hashes and fresh blinded R3 reports remain pending Root
integration/review. Current root expectations/preimages are historical/stale;
this candidate is not publication ready. Exact Opus S1-S3 guide sentences,
C1-C6/N1-N6 under historical scope, and all14 open draft gaps remain intact.

All8 frozen R3 input hashes match the source-repair handoff. Only the2 owned
prose files changed among47 copied source members; the other45 are unchanged.
No Rust/test/input/expected/preimage/freeze/copiedr2/normative/premise/private/
old92packet/index bytes were written. No commit/push/merge or model/subagent.

Build/tests/CLI/evaluator/actual-output comparisons are **UNRUN**. Comparison
admission NOT_GRANTED; native authority0; no publication or milestone/parent
exit acceptance. Checks here were literal source-text/JSON/SHA and diff only.
