# Verdict: **APPROVE_SOURCE_FROZEN_DATA_AND_DRAFT_PUBLICATION_ONLY**

This approves three things only:

- the exact R3 source;
- the frozen R3 normal expectation data (freeze `ad44178b…`);
- publication as a **draft** GitHub PR from `feat/mori-test-stages-r3-20261016`.

It does not approve a merge, marking the PR ready for review, any build, Cargo, CLI, test or comparison run, comparison admission, a runtime result, a printed-format result, native, financial or target acceptance, or any parent exit. Conditions K1–K4 below are part of this verdict.

**Who I am.** I am `claude-opus-5-5`, the same model as the earlier Opus reviewers and the trace-contract author. My non-authorship rests on a separate context. I authored or edited none of these files.

**What I did not check.** I used no tools and recomputed no SHA-256 values. Digest equality and capture binding rest on Root's mechanical record. Where I checked byte lengths by hand, I say so.

## 1. The R2 defect is fixed as a source premise

The blocking R2 finding was that both scenarios carried a `duty` liability that neither program registered, so R7 rejected both starts. That finding no longer applies, judged as a source premise only. Nothing was observed at runtime.

- **The registry now contains `duty`.** `decode::registry` (`decode.rs:52-77`) scans every action's `Statement::Liability`. The appended `declare` actions register:
  - TwoDeliveries: `duty` → (UNIT identity, `alice`, `bob`);
  - QuotedFee: `duty` → (UNIT identity, `payer`, `treasury`).
- **The scenarios match.** Each scenario's `duty` row has exactly that asset, debtor and creditor. The amount is not part of the identity check (`decode.rs:206`), so the incoming amounts 5 and 3 versus the declaration's literal 0 do not matter.
- **The start check passes.** `admit.rs:253-255` calls `canonical_boundary` before any segment runs. Every other condition holds as well: exact typed state, sorted declared-asset balances, the Transfer/Fee accounts present, a single liability row with nothing to sort against, and trace cells of 63 (deliver) and 49 (charge).
- **The legacy normalizer passes too.** `scenario_snapshot`'s registered-name check (`runtime.rs:652-659`) now applies to `duty`, and the row matches.
- **Emission passes.** `emit_checked` (`admit.rs:51-68`) re-runs R7 on each waiting boundary. The duty row is unchanged at every boundary, so it passes.

## 2. I traced all six invocations against the actual consumer source

R2's reviewers did not have `admit.rs`, `decode.rs` or `runtime.rs`. I traced each call through `start`/`resume` (R0–R7), then `run_segment`, `finish` and `emit_checked`, and compared the result with the frozen files:

| Invocation | Path through admission | Meter | Outcome | Matches frozen file |
|---|---|---|---|---|
| deliver start, cap 16 | preflight 16 ≤ 16; R7 passes; Transfer 2 + Next 2 + entry 1 | 5 of limit 5 | Waiting at site 1, captures `[]`, committed 5 | yes |
| approval false | R0 `Some("deliver")`; R6 needs 10 ≤ 16; guard `ok` is false, so NotAdvanced; dispatch 2 matches `require_static` | 2 | Waiting, advanced false, segment null, input continuation unchanged | yes |
| approval true | Await Step (Bool true, snapshot pre, no effects); Transfer 3; entry 1; captures `[ok: true]` | 5 | Waiting at site 2, committed 10 | yes |
| receipt true | R6 needs 16 ≤ 16; Await 2; Next 2; Emit 2 (reads the updated phase, 2); exit 0; total equals plan total | 6 | Complete, committed 16 | yes |
| charge start, cap null | Let: 1 + 3 nodes = 4; entry 1; captures `[amount 4, payable 5]` | 5 | Waiting, cap null | yes |
| quote true | no ceiling; Await, Fee 5, Next, Emit, each 2 | 8 | Complete, committed 13 | yes |

Every report checks out on:

- `Step.value` attachment, using only the categories reviewed under P-TRACE-PROJ;
- frames and envelope fields, including the waiting `committed` equalling `continuation.logical.committed`;
- the three qualification labels on every report;
- residuals, which list the positive duties 5 and 3;
- the source's own semantics: balances sum to 31 at every boundary, Fee and Transfer stay distinct, and no duty is created, accrued or discharged.

**Program and plan preimages.** I re-derived these by hand from `parser.rs`, `plan.rs`, `cost.rs` and `validate.rs`:

- **Expression arenas.** Each has eight nodes, and the `declare` literal 0 sits at node 7.
- **Liability statement shape.** The `declare` statement serializes as `{amount:7, asset, creditor, debtor, kind, name}`.
- **Plans.** Each `declare` plan entry is `{statement_count 1, sites [], segment_cost ["2"], committed_before ["0"], plan_total "2"}`. This satisfies both `cost_invariants` and `plan_invariants`.
- **Byte lengths (hand arithmetic).**
  - The two appended source lines add 67 and 72 bytes, matching 430 → 497 and 411 → 483.
  - The TwoDeliveries program preimage grows by exactly the new action plus the new literal: 1105 + 141 + 55 = 1301.
  - Its plan grows by exactly the `declare` entry: 503 + 115 = 618.

  This is consistent with a pure append. It is not a hash recomputation.

**Noninterference.** The `declare` action is never selected. Node 7 is unreachable from `deliver` and `charge`, and the trace-cell count includes only the selected action's Liability statements. So the only expected change from R2 is the `program_hash` and `plan_hash` fields. The frozen data agrees:

- the four reports that carry hashes keep their byte sizes (11599, 2417, 11444, 7948);
- the two complete reports, which carry no hashes, are byte-identical to R2 (`076cf…`, `f92e…`).

**Premises I could not see.** The lexer source was not supplied. That `declare` and `liability` lex as words rests on existing usage in `liability_reads.rs`. That an at-limit meter charge is allowed rests on the `cost.rs` unit tests.

## 3. Findings (not blocking for a draft)

- **F1. A stale provenance comment in a published test file.** The header of `stage_test_public.rs` still says the reports are "author-supplied provisional … frozen before the command implementation." For the current root bytes this is false: they are blinded R3 oracle copies, frozen after the implementation existed.
  - Independence for R3 rests on blinding the author, not on ordering. `PROVENANCE.md` states this correctly.
  - The comment understates authorship independence but overstates timing.
  - Fixing it needs one new comment line, which means a new candidate (see K3).
- **F2. The root `expectation-freeze.json` binds archived bytes.** It sits next to the current fixtures but describes the old ones. Three documents disclose this, and an exact copy exists in `history/blocked-r2/`. Move or relabel it in a later candidate.
- **F3. This is a security observation, not a new risk.** The registry is source-wide, so a declaration in an action that never runs is enough to admit externally supplied duties. That is documented Core behavior (`mori-core/README.md:59-63`). R7 checks the identity of a duty, not its amount or authenticity. The fixtures use this behavior and the guide says so. If `declare` were ever run, it would add 0 and leave a present-zero row, which is harmless.
- **F4. Correlated-premise risk.** R1, R2 and R3 have the same oracle owner and model. The trace in section 2 is my independent check against the actual consumer source, but it is still source-derived, not execution.
- **F5. One unverified risk.** `history/blocked-r2/` contains `.mori` files and a `mori-tests.json` whose old sources would fail R7 if anything ran them. Nothing I can see discovers them: the fixture copier is non-recursive, and the only workflow, `site.yml`, does not build Rust. A recursive harness elsewhere in the repository is not ruled out. A read-only grep is enough to settle it.
- **F6. A published script with absolute paths.** `assemble_*.py` uses absolute paths and writes into its own directory. Before it fails partway, it would rewrite the frozen members in place, regenerating the same bytes. It is labeled as provenance that must not be run. Keep that label.

## 4. Publication: privacy and CI

**Privacy and disclosure.** The raw captures expose:

- host usernames and paths, and the `/root/...` owner label;
- runtime directory names and cargo registry paths;
- model names;
- provider request and response IDs;
- token counts and cost figures;
- 235 hashes of public source files.

I judge these acceptable for deliberate public disclosure. I saw no credentials, keys, environment values, parameters or SRS, private witnesses, Clean or Fenrir payloads, or personal contact data.

**CI trigger.** The candidate touches no `site/**`, `.github/**` or CI configuration path. `site.yml` filters both `push` and `pull_request` on those paths and deploys only from `main`, so a draft PR should start no configured workflow. After the push, Root should run one bounded read-only check: confirm there are zero workflow runs for the branch and the PR. If any run appears, stop and report it; do not cancel and retry.

## 5. Conditions

- **K1. Capture names.** Name the four new final-review captures distinctly, for example `…-r3-final-…`. Do not overwrite or reuse the existing `mori-test-stages-final-{muse,opus}-r1--RESULT.*` captures, which review the R2 candidate.
- **K2. REVIEW-BINDING.** It must classify the existing `final-*-r1` captures as R2-candidate dispositions (membership `10b4ba4a…`), including the R2 Muse APPROVE. It must bind this verdict only to the R3 source and data hashes listed. It must state that the R2 positive-data approvals remain invalidated.
- **K3. Before ready-for-review or merge.** Fix F1. Then a fresh source review of the changed bytes is needed. No approval here carries forward.
- **K4. Unchanged limits.**
  - Everything is still UNRUN, comparison admission is NOT_GRANTED and native authority is 0.
  - P-TRACE-PROJ/draft remains an unadopted attachment and presence premise only.
  - The admission and source-shape conditions are source-derived consistency, not semantic proofs.
  - C1–C6 and the historical N1–N6 keep their stated scope.
  - All 14 draft gaps stay open. GAP-13 keeps its historical R7 contradiction and is not closed.
  - JSON value equality is the only intended predicate; printed member order and whitespace are unobserved (GAP-04).
  - No U0–U7, M1–M17, MC/SP/G, partial/conditional or parent exit is affected.
