# Source candidate: public Core/2 staged tests

Implementation is prepared in the assigned worktree; no commit, push or merge.
All builds, program execution and tests are **UNRUN**. The exact candidate files,
SHA-256 digests, inspected sources, proposed check graph and dependencies are in
`WORK_REPORT.json`.

`test.rs` now dispatches only the additive `moriarty-tests/2` manifest to the
owned `stage_test.rs`. The existing `/1` evaluation loop and aggregate writer
are unchanged. The new path calls actual Core/2 load/start/resume, carries only
actual continuations, and compares each entire staged report against a supplied
expected file. Later actual results remain visible after expectation mismatches;
any mismatch exits nonzero. Actual reports preserve local-reference-stage,
authentication none, consumption untracked labels. No backend/SDK/sign/proof/
native routine was added to the runtime path.

Two source specimens and full reports are under `models/core-stage-tests`:
two-await delivery (transfer7 then3, unchanged duty5, costs5/5/6, false
observation2) and captured quoted fee (amount4/payable5, fee5, duty3,
costs5/8). Original author fixture freeze and canonical preimages are preserved.
These are **author-supplied provisional expectations**, independent of evaluator
output, not independent by author ownership. Root assigned a separate author
to derive expectations from eight exact inputs. No comparisons may execute
before Root checks that separate freeze and admits ordinary execution.

The new normal public integration tests specify complete report/byte equality
and eight expected-only transcription mismatches. Existing `/1` normal stdout
byte test is proposed as a scoped regression; existing tests were not edited.
`docs/CORE-STAGED-TESTS.md` documents format, consumer, bounds, retries and scope.

Performed operations were read-only startup/status/source inspection, local
fixture JSON assembly/hashing, owned writes, Rust formatting and tracked patch
whitespace inspection. There is no compile/typecheck/runtime pass claim. Build
and focused test admission, complete independent expectations, fresh Muse audit
and Opus-owned security work remain due. No security judgment is supplied.
Native authority remains zero. U0-U7, M1-M17, MC/SP/G, partial/conditional,
helper, circuit and native requirements retain every open exit.
