# Core trace report contract (DRAFT)

> Status: SOURCE_OBSERVATION_DRAFT_UNADOPTED. Not canonical. Execution: UNRUN. Native authority: 0. Fresh non-author review is required before adoption. This draft supersedes nothing. Prior source, oracle and evidence data are preserved unchanged.

## 1. Purpose and evidence classes

This draft records how the original `main9a7` reference interpreter projects each executed `Statement` into a serialized `Step`. The purpose is to let a separate normal-oracle author derive full reports under a named encoding premise, while deriving semantic, accounting and work values independently.

Every rule carries exactly one class:

- **[N] Existing normative or documentary semantics**: `docs/CORE-CONTINUATIONS.md` and `crates/mori-core/README.md`. MPLR SHALL statements describe required future behavior, not implemented capability.
- **[S] Source-observed projection convention**: read from the original `crates/mori-core/src/ir.rs`, `crates/mori-core/src/runtime.rs` and `crates/mori/src/commands/simulate.rs`. An [S] rule records what the evaluator emits. It is not an independent semantic oracle and claims no semantic correctness.
- **[D] Draft requirement**: proposed under existing requirements only. Unadopted.
- **[GAP]**: unresolved. See section 10.

Citations name declarations and match arms. The supplied excerpt did not include line numbers (GAP-01).

## 2. Serialized shapes [S]

| Type | Encoding | Source |
|---|---|---|
| `UInt` | Canonical unsigned decimal JSON string. | `ir.rs` `impl Serialize for UInt` |
| `Value` | Adjacently tagged, for example `{"type":"UInt","value":"10"}` or `{"type":"Bool","value":true}`. | `ir.rs` `enum Value`, serde `tag = type`, `content = value` |
| `Statement` | Internally tagged by `kind` (the variant name), with the declared fields. `ExprId` is a JSON integer. `Await.binders` is an array of `{name, ty}`, where `ty` is `UInt` or `Bool`. | `ir.rs` `enum Statement` (Serialize only) and `struct InputDecl` |
| `Effect` | Internally tagged by `kind`: `State{name,before,after}`, `Transfer{asset,from,to,amount}`, `Fee{asset,from,to,amount}`, `Liability{name,asset,debtor,creditor,before,after}` or `Emit{name,value}`. `asset` is the full `AssetId{network,issuer,reference,scale}`, with `scale` as a JSON number. | `ir.rs` `enum Effect` and `struct AssetId` |
| `Snapshot` | `{state, balances, liabilities}`. `state` is a map keyed by state name. | `ir.rs` `struct Snapshot` |
| `Step` | `{index, statement, value, snapshot, effects}`. `index` is a JSON integer. `value` is always present, and `null` would encode `None`. | `ir.rs` `struct Step` (no skip attribute) |
| `Execution` | `{semantics, action, pre, post, steps, effects}` | `ir.rs` `struct Execution` |
| `Error` | `{code, message, offset, step}`. `code` is `mori::core::<code>`. `offset` and `step` may be `null`. | `ir.rs` `struct Error` and `Error::new` |

Member order and whitespace in printed output depend on the serde_json map configuration and on `core_io::print`. Neither was supplied (GAP-04). The oracle comparison premise is therefore JSON value equality, not byte equality.

## 3. Statement to Step projection [S]

The `/1` path (`simulate_with_meter`) and the `/2` path (`run_segment`) both call `execute_statement` (`runtime.rs`). A Step is pushed only when the statement returns `Ok`. Every `Ok` arm returns `Some(..)`. **No source-emitted Step therefore has `value: null`** [S]; the `None` domain of `Option<Value>` is unused.

| Statement | `Step.value` | `Step.effects` | Snapshot change | Env change | Refusal (no Step; `error.step` = ordinal) | [N] anchor |
|---|---|---|---|---|---|---|
| `Let{name,value}` | The evaluated value. | `[]` | None. | `name` bound to the value. | Expression errors. | README: `let` captures a value. |
| `Requires{predicate}` | `Bool true` | `[]` | None. | None. | A non-true result raises `mori::core::requires`. | README: checked where written. |
| `Ensures{predicate}` | `Bool true` | `[]` | None. | None. | A non-true result raises `mori::core::ensures`. | Same as Requires. |
| `Next{state,value}` | The new value (`after`). | `[State{name,before,after}]` | `state[name]` becomes `after`. | `state` becomes `after`. | Expression errors. | README: immediate update, and the right-hand side reads before the update. |
| `Emit{name,value}` | The evaluated value. | `[Emit{name,value}]` | None. | None. | Expression errors. | README: explicit event. |
| `Transfer{asset,from,to,amount}` | `UInt amount` | `[Transfer{asset:AssetId,from,to,amount}]` | Debit `from` and credit `to` when `from` differs from `to`. A self-transfer leaves balances unchanged. | None. | `balance` (insufficient or missing) and `overflow`. | README: exact-asset debit and credit. A self-transfer keeps its gross effect and requires sufficient funds. |
| `Fee{asset,from,to,amount}` | `UInt amount` | `[Fee{asset,from,to,amount}]` | Same as Transfer. | None. | Same as Transfer. | README: same balance semantics, separate effect. |
| `Liability{name,asset,debtor,creditor,amount}` | `UInt amount`, which is the **increment**, not the resulting total. | `[Liability{..,before,after}]` with `after = before + amount`. `before` is 0 for a new row. | Row is created (then re-sorted by name) or increased. A zero amount creates a present-zero row. | None. | `liability` (identity differs) and `overflow`. | README: create or add, with a fixed identity. |
| `Discharge{name,amount}` | `UInt amount`, which is the **decrement**. | `[Liability{..,before,after}]`, taking identity fields from the existing row, with `after = before - amount`. | Row is decreased and retained at zero. | None. | `liability` (unknown residual, or discharge exceeds residual). | README: checked subtraction, and zero rows remain. |
| `Await{label,binders,guard}` | `Bool true` only. Published only on an accepted resume. | `[]` | None. `snapshot` equals the segment `pre`. | Captures and event binders are added before the guard is evaluated. | See section 5. | Continuations doc: resume evaluates the guard. |

`Step.snapshot` is the complete snapshot after the statement (`current.clone()`), including untouched rows. `Step.effects` holds only that statement's effects, which are zero or one. Expressions, including liability reads, evaluate against the snapshot as it stood before the enclosing statement mutated it.

## 4. Indices, ordering and Execution [S]

- `Step.index` is the original source ordinal within the selected action. It is never segment-relative.
  - `simulate_with_meter` uses `enumerate`.
  - `run_segment` uses `enumerate().skip(begin)`, and uses the Await ordinal for the resume Step.
  - [N] Rust API: an Execution carries original source statement indices.
- `/1` steps are contiguous from 0. A `/2` segment is contiguous from its begin ordinal up to, but not including, the next Await, or to the end of the action.
- `error.step` is the failing ordinal, including Await entry-charge failures and guard failures. One exception: in `run_segment`, a missing stage site (`stage_site`) or a missing capture name (`name`) produces an error with no step [S].
- `Execution.effects` is the concatenation of every `Step.effects`, in step order.
- `Execution.pre` is the normalized scenario (`/1`) or the supplied boundary (`/2`). `Execution.post` is the snapshot at exit.
- Canonical ordering (`scenario_snapshot` and the `execute_statement` Liability arm):
  - `state` is ordered by name (BTreeMap).
  - Balances are ordered by `(asset, account)`, with `AssetId` ordered by `network, issuer, reference, scale`.
  - Liabilities are ordered by `name`. They are sorted at normalization and again when a row is created.
- `Execution.semantics`: `/1` emits `moriarty-core/1` (the `SEMANTICS` constant). `/2` segments emit `program.semantics`, which the stage loader assigns (GAP-03).

## 5. Await entry and resume [S], with [N] anchors

| Event | Steps published | Snapshot and effects | Work | Outcome |
|---|---|---|---|---|
| Start or remainder reaches the Await at ordinal k. | Ordinals before k only. **No Await Step.** | `post` is the boundary at k. | Entry charge of 1. A refusal sets `error.step` to k. | `exit_site` is the site number. Captures follow `site.captures` order. |
| Start reaches no Await. | All ordinals. | As in `/1`. | Charged per statement. | Complete. |
| Resume with guard true. | The Await Step at k comes first (`value` Bool true, `snapshot` equal to the boundary, `effects` `[]`), followed by k+1 onward. | As in section 3. | Dispatch plus uncached guard nodes, then the remainder. | Waiting at the next Await, or complete. |
| Resume with guard not true. | None. No Execution. | Boundary unchanged. No effects. | Dispatch plus guard nodes, attempted but not committed. | `SegmentRun::NotAdvanced`. |
| Resume with a guard evaluation error. | None. | Unchanged. | Attempted. | Rejected, with `error.step` set to k. |
| Resume with guard true, then a later statement fails. | None published. | Unchanged. | Attempted. | Rejected. No segment and no replacement continuation. |

[N] anchors from `docs/CORE-CONTINUATIONS.md`:

- Reaching an await ends the segment before its guard is evaluated, and charges its entry.
- Resuming charges dispatch and evaluates the guard.
- A false guard returns `status:"waiting"`, `advanced:false`, `segment:null` and the unchanged continuation, with no new prefix.
- A true guard runs only the remainder.
- A rejected suffix returns its error and attempted work, with no segment and no replacement continuation.

The presence of an Await Step on resume, and its absence at entry, is [S] only. Its source is the `run_segment` comment stating that the guard and its Step belong to resume.

Resumes that are false or fail do not commit. A false or failing resume discards its local env, snapshot and steps. The input continuation and the prior prefix remain usable. Consumption is untracked.

## 6. Report envelopes [S]

From `crates/mori/src/commands/simulate.rs`:

- `/1` accepted: `{status:"accepted", qualification:"local-reference-execution", execution}`. With `--logical-cap`, the report adds `profile` and `logical{cap,used}`.
- `/1` rejected: `{status:"rejected", error}`. A metered rejection adds `profile` and `logical`.
- `/2` waiting: `{status:"waiting", advanced, segment, continuation, attempted, committed, residual}`, where `committed` equals `continuation.logical.committed`.
- `/2` complete: `{status:"complete", segment, attempted, committed, residual}`.
- `/2` rejected: `{status:"rejected", error, attempted, committed}`. Refusals before any segment evaluation use `no_work`, which reports 0 and 0.
- Every staged report adds `STAGE_LABELS`. [N] The labels are `qualification:"local-reference-stage"`, `authentication:"none"` and `consumption:"untracked"`.

The stage module defines the internal shapes of `segment`, `continuation`, `attempted`, `committed` and `residual`, and the value of `advanced` on start. That module was not supplied (GAP-02).

## 7. Profiles and local scope

- [S] `/1` `validate` refuses Await with `mori::core::profile` (Await requires moriarty-core/2).
- [S] The `v1` wire has no Await variant, and every Statement, Step and Execution decode routes through `v1`. A `/2` trace that contains an Await Step is therefore serialize-only, and the existing `replay` and `compare_execution` cannot decode it (GAP-11).
- [N] `/1` keeps its atomic semantics, its JSON and its logical-cost profile `/1`. `/2` uses `moriarty-reference-logical-cost/2`.
- [S] In `/2`, each segment's env is the boundary state plus either the inputs (start) or the captures and event binders (resume). `Next` updates the env.
- [N] Inputs and evaluated lets are captured by value. Earlier accepted binders are captured for later awaits. State and liabilities are read from the current boundary.

## 8. Preserved accounting, work, effects and qualifications [N]

This draft leaves all of the following unchanged:

- Amounts are integral atomic units with exact asset identity. There is no mint, no burn and no implicit account creation.
- Effect lists are complete.
- `residual` lists every positive liability in the post boundary. Completion reports no settlement.
- Logical units count statement dispatch and distinct expression-node visits, with a fresh cache per statement. They are not circuit cost, DUST, service fees or proof measurements.
- Attempted work on false or rejected invocations is reported separately.
- The stored `logical.cap` is an unauthenticated advisory ceiling and lies outside both digests.
- Reports are local, unauthenticated and consumption-untracked.
- Native-call execution does not support `/2`.
- Rust and Quint correspondence is unestablished.
- No U0–U7, M1–M17 or MC/SP/G exit is closed.

This draft adds no wire field, financial policy, resource counter, fee rule, qualification or runtime behavior.

## 9. Draft clause [D] (unadopted)

Proposed under MPLR-012 and MPLR-017, with existing obligations MOR-003/004/006/008/009/011/012 as applicable. The specific MOR mapping is unresolved (GAP-12).

> DRAFT-TRACE-01: When the local reference interpreter publishes a Step for an accepted statement, the interpreter shall encode `index`, `value`, `snapshot` and `effects` as specified by the adopted projection tables in sections 3 to 5 of this document.

This draft introduces no new EARS family, gate or approval system.

## 10. Oracle premise, limits and gaps

Named premise **P-TRACE-PROJ/draft**. A separate oracle may use sections 2 to 5 as a disclosed encoding premise for two questions: which value, snapshot and effects attach to which Step, and whether an Await Step exists.

The oracle must derive the following independently, from [N] text and scenario data:

- expression values and guard truth;
- balances, liability before/after values and residuals;
- effect contents;
- refusal points;
- attempted and committed work.

Limits: agreement on [S] projection fields shows conformance to an evaluator-observed convention, not semantic correctness. This document is not a proof, an evaluator verification, a cross-layer correspondence, a native acceptance or an approval to execute.

Gaps:

- GAP-01: line numbers.
- GAP-02: stage report internals.
- GAP-03: the `/2` semantics string.
- GAP-04: key order and format.
- GAP-05: parser ExprId allocation.
- GAP-06: stage admission premises.
- GAP-07: stage-specific error codes.
- GAP-08: the `/2` trace bound.
- GAP-09: no [N] source for Step.value.
- GAP-10: no [N] source for Await Step presence.
- GAP-11: no `/2` decode or replay.
- GAP-12: MOR clause mapping.
- GAP-13: boundary canonical-order provenance.
- GAP-14: cap refusal during a false resume.

The separate author freezes unresolved fields as GAPs and preserves them before using any later reviewed contract.
