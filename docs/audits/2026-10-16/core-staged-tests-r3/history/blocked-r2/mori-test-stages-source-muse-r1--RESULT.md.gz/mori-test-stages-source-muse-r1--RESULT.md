## Verdict: BLOCKED — source-only

The top finding is that `logical_cap` is documented and commented as a mandatory manifest key, but the source does not explicitly enforce its presence.

This is not approval of any result, comparison, admission, publication, roadmap exit, or execution. All security, theorem, hostile-input, privacy, and resource-policy judgments are expressly reserved to Opus; I make none here. Compilation and runtime behavior remain **UNVERIFIED** because no build or test execution was admitted or performed.

### Blocking finding

1. **Mandatory `logical_cap` presence is not established by the code.**  
   In [stage_test.rs](/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-reference-20261015/opus-sprint-loop-20261015/mori-test-stages-source-muse-r1/crates/mori/src/commands/stage_test.rs), `Case.logical_cap` is an `Option<mori_core::UInt>` using `Option::deserialize`. That pattern is also used elsewhere to represent an explicitly nullable value, so the source alone does not prove that an omitted key is rejected rather than becoming `None`. This conflicts with the field comment and with [CORE-STAGED-TESTS.md](/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-reference-20261015/opus-sprint-loop-20261015/mori-test-stages-source-muse-r1/docs/CORE-STAGED-TESTS.md), which states that all shown keys are required and distinguishes a decimal string from explicit `null`.

   **Necessary fix:** enforce key presence explicitly before or during manifest decoding, independent of Serde’s `Option` missing-field behavior, and add an ordinary missing-`logical_cap` manifest test. Alternatively, if omission is intended to mean `null`, correct the struct comment and documentation; the current documents do not say that.

### Source findings that are otherwise sound

- The `/2` dispatch in [test.rs](/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-reference-20261015/opus-sprint-loop-20261015/mori-test-stages-source-muse-r1/crates/mori/src/commands/test.rs) is additive: non-`/2` manifests continue through the retained legacy `/1` structure and comparison logic.
- Expected start and event reports are read before the corresponding case executes, and comparisons use whole `serde_json::Value` equality rather than selected fields or expected continuation state.
- Actual continuation chaining is correct on its face: waiting outcomes supply the next continuation, false observations retain the returned waiting continuation, rejected resumes retain the previous actual continuation, and completion or rejected start leaves no continuation for a later event.
- The staged report envelope mirrors the supplied `simulate` implementation for waiting, complete, and rejected outcomes, including attempted/committed work, residuals, segment data, and the three stage labels.
- Case-name uniqueness, nonempty case lists, the 256-case bound, and the bound of 255 events plus start are present in source. I express no judgment about whether those bounds are the correct resource policy.
- The public-consumer test uses the real `mori test` binary path and constructs its expected aggregate from the fixture manifest and expected-report files rather than calling evaluator internals directly.

### Completeness and honesty limitations

- The separate oracle remains partial: six reports, accounting, work schedules, and AST/plan preimages were frozen, but twelve `Step.value` fields remain unresolved gaps. Full-report comparisons are therefore **INELIGIBLE**, and the candidate’s filled `Step.value` entries remain author-supplied expectations, not independent oracle values.
- The provenance documents are honest about this limitation, the author-supplied status, and the **UNRUN** state. They correctly do not claim an independent-author freeze.
- Rejected-resume retry, events after completion, events after rejected start, and invalid-manifest execution paths are implemented in source but are not covered by the two proposed public tests. The author report already discloses that these executions are unobserved.
- I cannot verify from source text alone that every API use compiles, that hashes in the supplied fixtures equal the runtime digests, or that Serde’s generated handling of the nullable-cap field matches the documented contract. Those items must remain **UNVERIFIED**, not inferred as passing.

Once the mandatory-`logical_cap` issue is fixed explicitly, this candidate could be reconsidered for **APPROVE_SOURCE_ONLY**; that would still not approve execution, fixture comparison, admission, or publication.
