# Public staged-test r2 provenance integration

Copied the exact public r2 `INDEPENDENT-FREEZE.json` and all21 bound members into
`models/core-stage-tests/independent-oracle-r2/`. Copied22-file membership,
every SHA256 and source/destination byte equality are in `WORK_REPORT.json`.
Freeze SHA256:
`428d9eab4cf6bab885f9eb866d4a54ad14cf592ce8adf0b6818c64ab4e431918`.
Captured data and historical review-pending strings remain unchanged. The copied
assembly script was not run.

Updated `PROVENANCE.md` and inserted only the exact Opus-authored S1/S2/S3
sentences in `CORE-STAGED-TESTS.md`. Provenance separates original author
expectations from separately authored reviewed frozen normal data, literal-data
agreement from runtime evidence, and source-derived representation premises
from independent numeric content. C1-C6/N1-N6, all14 draft gaps, zero author
self-assessment review authority and immutable historical statuses remain.

Root extended ownership for one minimal test-helper change: before `fs::copy`,
`stage_test_public.rs` now skips entries for which `file_type().unwrap().is_file()`
is false. This accommodates the required r2 subdirectory while preserving the
original flat fixture leaf copies and real-binary invocation. No recursive copy
or new selection infrastructure was added. In-memory removal of that exact guard
restores the original test hash. Runtime behavior remains UNRUN.

**Earlier source approvals do not cover these changed test bytes.** They remain
historical exact-candidate receipts. Root owns fresh final full-candidate source
and publication reviews covering the updated test, docs/provenance and oracle
copies. The exact new test hash is recorded below and in the JSON report.

Of the original25 candidate files, only the two owned prose files and the
Root-authorized test-helper guard changed; the other22 hashes are unchanged.
Runtime Rust, manifest, inputs, original author freeze/preimages/expected files
remain untouched. No private Clean/Fenrir content/path was copied. No commit,
push, merge or index mutation occurred.

Product/build/tests/CLI/actual-output comparisons remain **UNRUN**; comparison
admission is **NOT_GRANTED**, native authority0, no execution authority added.
No CLI pass, printed-byte-format acceptance, evaluator/native/financial result,
proof or U0-U7/M1-M17/MC/SP/G/partial-and-conditional exit is claimed.

New stage_test_public.rs SHA256:
2d045094c0e67e6941f6a6b3f5b6a101a910e4d97fa4fcce80dc9daba2feeaff
