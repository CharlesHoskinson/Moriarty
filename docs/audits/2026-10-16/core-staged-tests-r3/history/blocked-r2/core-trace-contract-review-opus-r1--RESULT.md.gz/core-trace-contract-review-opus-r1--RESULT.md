# Verdict: **APPROVE_DISCLOSED_PROJECTION_PREMISE_ONLY**

A separate normal oracle may use sections 2–5 as the disclosed source-observed premise **P-TRACE-PROJ/draft** for one purpose: filling the 12 Step.value attachment slots below. It must still derive every expression and guard value, effect, state value, liability value, refusal and unit of logical work independently. None of the 12 slots disagrees with the original source.

This verdict does not adopt the draft, establish evaluator correctness, close any GAP, or approve execution, native work, proof, publication or roadmap acceptance. It is conditional on C1–C6 below.

Two binding notes:

- I could not recompute the SHA256 values without tools. The verdict applies to the text exactly as supplied.
- The draft's author is recorded as `claude-opus-5-5 high`, the same model as me. My non-authorship rests only on a separate context; I did not author or edit the draft in this session.

## Slot enumeration and source check

The draft never names "12 slots". I used the enumeration below. If the separate author's enumeration differs, this approval does not cover any slot outside it.

| # | Slot | Draft claim | Source | Result |
|---|---|---|---|---|
| 1 | Let | value of the evaluated expression | `runtime.rs:716-720` | match |
| 2 | Requires | `Bool true` (Step only if true) | `runtime.rs:721-734` (the `v != Bool(true)` check, then `Some(v)`) | match |
| 3 | Ensures | `Bool true` | same arm | match |
| 4 | Next | `after`, the right-hand side evaluated before the update | `runtime.rs:735-746` | match |
| 5 | Emit | value of the evaluated expression | `runtime.rs:747-754` | match |
| 6 | Transfer | `UInt amount`, gross, including self-transfers and zero | `runtime.rs:755-786`, `move_funds` `668-700` | match |
| 7 | Fee | `UInt amount` | same arm | match |
| 8 | Liability | the **increment**, not `after` | `runtime.rs:787-836` (`Ok(Some(Value::UInt(amount)))` at 835) | match |
| 9 | Discharge | the **decrement**, not `after` | `runtime.rs:837-860` (859) | match |
| 10 | Await, accepted resume | Step at `k`, value `Bool true`, snapshot `pre`, effects `[]` | `runtime.rs:955-975` (964 check, 967-973 push) | match |
| 11 | Await at entry | no Step; `error.step = k` on an entry-charge refusal | `runtime.rs:980-995` | match |
| 12 | Await, non-true or erroring resume | no Step and no Execution | `runtime.rs:963-966`, `admit.rs:103-122` | match |

Every `Ok` arm returns `Some`, and `Step.value: Option<Value>` has no skip attribute (`ir.rs:254-260`). The no-`null` claim therefore holds for every Step the source emits.

I also checked the remaining rows of sections 2–5: serialized shapes, index rules, ordering, snapshot timing and per-step effects. None disagrees with source. This verdict still covers only the 12 value slots above.

## Circularity analysis

The premise supplies only a **selection function**: which quantity, already derived independently, goes into `Step.value`, and whether a Step exists. It supplies no numeric content. What agreement then shows depends on the slot:

- **Content slots (1, 4–9):** agreement is a real cross-check of the oracle's independently derived expression value against the evaluator's, conditioned on the premise.
- **Constant slots (2, 3, 10):** agreement checks presence only. That is equivalent to the predicate or guard truth the oracle derived independently.
- **Absence slots (11, 12):** agreement checks entry and non-advance behavior.

The selection itself has no [N] source (GAP-09, GAP-10). Agreement therefore shows conformance to the evaluator's convention, not that the convention is semantically correct.

## Conditions

- **C1 (scope).** The approval covers only slots 1–12 above. It does not cover index, snapshot, effect, envelope, error-code or work fields.
- **C2 (call sites).** The premise was observed only for unmetered `/1` (`simulate` → `simulate_with_meter`, `runtime.rs:865-867`) and for `/2` `run_segment` reached from `admit.rs:257`/`351`.
  - The metered `/1` path (`simulate.rs:107`, `simulate_metered`) is not in the supplied source. Only [N] text (`README.md:98-99`, "runs the same interpreter") anchors it.
  - The oracle must record this as an additional disclosed assumption for metered `/1` traces.
  - The `--trace` path through `mori_backend::replay::generate` is out of scope.
- **C3 (refusal columns are not premise).** The refusal columns in section 3 are incomplete. The Requires, Ensures, Transfer, Fee, Liability, Discharge and Await rows omit expression-evaluation errors (`overflow`, `underflow`, `type`, `name`) in the predicate, amount or guard. The oracle must derive refusal points independently and must not treat these columns as exhaustive.
- **C4 (author self-assessment has no review weight).** The inventory field `oracle_premises_and_limits.assessment` is written in a security-owner voice ("As security owner, I assess…") by the draft's own author.
  - Preserve it unchanged.
  - Annotate it in a separate review record as an author self-assessment with no review authority.
  - Do not cite it as approval. This verdict is the non-author judgment, and it is narrower than that field.
- **C5 (no evaluator-sourced content).** Content for slots 1 and 4–9 must come from the oracle's own derivation from [N] text and scenario data. It must not be copied from evaluator outputs or evaluator effects.
- **C6 (traps to freeze in the oracle's notes):**
  - Liability and Discharge values are the delta, not the resulting total. Using `after` or the residual is a mismatch.
  - Self-transfers and zero-amount Transfers still publish `amount`. A zero-amount Liability still publishes `"0"` and creates a present-zero row.
  - The Await-true Step carries `snapshot = pre` (the boundary) and `Bool true`, not the event values.
  - `Execution.effects` omits the resume Await Step's effects (`runtime.rs:955-975` never extends `all_effects`). The concatenation rule in section 4 holds only because those effects are always `[]`.

## Gap observations (input to separate review; nothing closed)

The newly supplied stage source narrows several gaps. These are observations only. Each GAP stays open in the draft until separate review and explicit derivation.

| Gap | What the source now shows |
|---|---|
| GAP-03 | `/2` semantics is forced to `"moriarty-core/2"` (`stage/mod.rs:24`, `profile.rs:26-31`, `validate.rs:48`, `mod.rs:73-74`). |
| GAP-06 | Bool guard typing (`validate.rs:198`) and non-shadowing binders (`validate.rs:187-197`) are enforced by `validate_v2`. |
| GAP-14 | The cap is checked at R6 preflight, before any guard runs (`cost.rs:184-217`, `admit.rs:347`). The meter limit is the planned segment cost, which is at least `dispatch_cost`. A cap refusal during a false resume therefore appears unreachable: refusal comes first, with attempted 0 and the input's committed value. |
| GAP-02 | The `StageOutcome`, `StageSegment`, `PendingFrame` and `Continuation` shapes are visible (`stage/mod.rs:90-177`). The decode module and `canonical_boundary` (GAP-13) are still not supplied. |
| GAP-08 | Narrowed only partly: start runs `scenario_snapshot`; resume does not. |

## Remains unapproved

- adopting the draft, including DRAFT-TRACE-01 (whose "adopted projection tables" wording refers to tables that remain unadopted)
- any evaluator or semantic-correctness claim
- full oracle freeze
- envelope agreement
- execution, native work, proof, publication and roadmap acceptance

All source, oracle, gap and evidence records are preserved unchanged.
