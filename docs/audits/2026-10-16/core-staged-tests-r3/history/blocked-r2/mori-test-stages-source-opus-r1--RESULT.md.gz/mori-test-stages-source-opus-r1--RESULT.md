# Opus security-owner review: `mori test` with `moriarty-tests/2` (source-only)

## Verdict: **APPROVE_SOURCE_ONLY**

**Scope.** This is a source-only security judgment on the exact candidate bytes in the report above (`test.rs` a984a404…, `stage_test.rs` c4f5b2bd…, `stage_test_public.rs` f230bf8b…, `CORE-STAGED-TESTS.md` 7625771e…, and the fixture set).

**What it does not approve.** It does not approve:
- execution, any build or test run, or public CLI admission
- result acceptance, comparison eligibility or publication
- any U/M/MC/SP/G or partial/conditional exit

**What I did and did not run.** I used no tools and ran nothing. All proposed commands remain UNRUN and unadmitted, and native authority stays 0. Nothing here asks for a cap or reset, a campaign, permissions, a shim or an alternate surface.

**Limits of what I read.** I did not read `runtime.rs`, `decode.rs` or `mori_core::json`. Claims that depend on them are marked UNVERIFIED.

The nonsecurity Muse reconsideration (APPROVE_SOURCE_ONLY) stays separate and does not substitute for this review. I also do not substitute for it.

---

## Security properties confirmed from source

### 1. Expected values are never trusted as inputs

- Every expected file is read into a plain `serde_json::Value` before the program loads (`crates/mori/src/commands/stage_test.rs:94-99`).
- Those values are used only in `actual == expected_start` (`:109`) and `actual == expected` (`:134`).
- The pending continuation is derived only from actual API outcomes:
  - `continuation(&started)` at `:107`
  - `continuation(&resumed)` at `:131`
  - the retained actual `previous` at `:130`
- Event bytes come from event files through the existing strict decoder (`:117-123`). The scenario comes from the scenario file (`:103`, `:141-153`). The cap comes from the manifest (`:104`). No path lets expected data reach `start`, `resume`, captures, hashes or counters.
- The mismatch test checks this correctly. It builds `expected_report` from the **unmodified** fixtures before corrupting one expected file (`crates/mori/tests/stage_test_public.rs:136-139`). It then requires the printed actuals to equal the original values while the corrupted stage has `passed:false`. The corrupted fields include an expected continuation boundary (`:110`) and expected captures (`:115`). If this ran and passed, it would show that wrong expectations neither leak into `actual` nor alter later stages. The test is UNRUN.

### 2. The actual local API is consumed end to end

- The path is `stage::load` → `stage::start` → `stage::resume`, using the same `StagedProgram` (`stage_test.rs:101-126`).
- `resume` still applies R0–R7 to the in-memory continuation (`crates/mori-core/src/stage/admit.rs:279-349`).
- The public test runs the real binary, `CARGO_BIN_EXE_mori` (`stage_test_public.rs:40-46`).
- Passing `Some(&case.action)` as R0 cannot diverge from the default `None`, because the continuation's action is always `case.action` (`admit.rs:183-188`, `:291`).

### 3. Reports are complete

- `report()` (`stage_test.rs:175-206`) emits every field of `StageOutcome::Waiting`, `StageOutcome::Complete` and `StageRejection` (`crates/mori-core/src/stage/mod.rs:155-177`).
- It uses the same key selection as `print_stage_result` (`crates/mori/src/commands/simulate.rs`, Waiting/Complete/Rejected arms).
- Comparison is whole-`Value` equality. Extra, missing or explicit-null fields all mismatch. Object key order does not matter.

### 4. Unsigned and consumption-untracked labels are preserved

- `stage::STAGE_LABELS` is inserted verbatim into **every** stage report, including rejections and load failures (`stage_test.rs:202-204`).
- Because comparison is over whole values, any expected file that lacks or alters a label fails.
- Retry after rejection (`:130`) and reuse of the unchanged false-observation continuation are consistent with "consumption untracked" (`admit.rs:3-7`).
- No once-only claim is made, and the docs disclaim one (`docs/CORE-STAGED-TESTS.md:87+`).

### 5. Financial, work, effect and residual distinctions are kept

- Per-invocation `attempted` is reported separately from cumulative `committed`. The false observation reports attempted 2 and committed 5.
- `Fee` and `Transfer` are distinct effect kinds.
- A transfer is not a discharge: duty 5 and duty 3 persist in every residual.
- `residual` is reported separately from balances.
- `CORE-STAGED-TESTS.md:76-77` separates logical work from circuit cost, DUST, service fees and reserves.
- `PROVENANCE.md` states that scalar `total` and `phase` are not custody, and that no claim is made about rounding dust.

### 6. Failures are fail-closed

These all return a nonzero exit with no partial JSON:
- input or IO errors
- impossible event sequences (`:113-115`)
- unexportable cases (shared `aggregate_report`, unchanged)

Any mismatch also exits nonzero (`:84-88`).

### 7. Legacy `/1` behaviour is unchanged

- Parsing to `Value` and then `from_value::<Manifest>` (`test.rs:41-45`) does the same work as the former `read_json::<Manifest>`, with the same error mapping.
- Non-object manifests and other profiles stay on the legacy path.

### 8. The test temp directory is handled safely

- `fs::create_dir` on a fresh path refuses to reuse an existing directory or a pre-planted symlink (`stage_test_public.rs:18-23`).
- The test only copies fixtures into it and then removes it.

---

## Non-blocking findings (no change required for source-only approval)

**S1. Qualification at the case and aggregate level.**
- The top-level `"status":"passed"` and the per-case `"passed":true` (`stage_test.rs:138`) carry no labels. Labels appear only inside each `actual`.
- This matches existing practice: `simulate` labels only top-level reports, and the shared aggregate is unchanged.
- Risk: a consumer extracting only verdicts could lose the qualification.
- Optional fix: add one sentence near `CORE-STAGED-TESTS.md:79`: "`passed` is a comparison verdict over local-reference-stage reports; the qualification labels are carried by each `actual`."
- An optional code alternative is to insert `STAGE_LABELS` into the case object at `:138`. That would require updating the `expected()` builder at `stage_test_public.rs:65` and getting a fresh review.

**S2. Event-read or decode rejection reports `committed:"0"`.**
- `.map_err(no_work)` at `stage_test.rs:123` reports `committed:"0"` even though the in-memory pending continuation has committed 5 or 10.
- This mirrors `simulate --resume` exactly, so the envelope stays faithful.
- However, it differs from the core convention that R0–R7 rejections echo the input's `committed` (`admit.rs:276-289`).
- No state is corrupted: the actual `previous` is retained.
- Recommended doc sentence at `CORE-STAGED-TESTS.md:55`: "A rejection before resume admission (event read/decode) reports attempted 0 and committed 0, as public `simulate` does; the retained continuation's committed work is unchanged."
- Do not change the code to diverge from `simulate` without a separate decision.

**S3. Paths are not confined to the test directory.**
- `dir.join(path)` accepts absolute paths and `..` (`stage_test.rs:94,98,100,103,118`).
- This is the existing `/1` convention. Expected files are never echoed. Decode and serde errors may echo fragments of event or scenario files, sanitised by `display::text` or export escaping.
- This is pre-existing and not a new class of issue.
- Optional doc clarification at `CORE-STAGED-TESTS.md:37`: "paths are not confined to the directory; treat the manifest as trusted input."

**S4. Resource amplification (for the hostile-test lane; nothing executes here).**
- All case `Value`s are retained until `aggregate_report` runs (`stage_test.rs:67-82`).
- Up to 255 expected `Value`s of up to 1 MiB each are held per case (`:95-99`).
- Memory before export can therefore grow by roughly 256 stages × 256 cases compared with legacy before the existing 1 MiB per-case export bound rejects anything.
- It is local and needs a hostile manifest, so it is not gating.
- A possible future mitigation within existing bounds, with no new cap: export or check each case immediately after `run_case` so the run fails fast.
- Route this to hostile-test design only.

**S5. stderr can say "passed" on a failing run.**
- `shell.status("Tested", "N passed; …")` is printed before the aggregate export (`stage_test.rs:76-82`). An export failure therefore follows a "passed" line on stderr. The exit status is still nonzero.
- This ordering is pre-existing in `/1`. Note only.

**S6. Naming in fixtures.**
- The issuer `"independent-staged-test-oracle"` and the freeze format `moriarty-independent-staged-tests-freeze/1` read as independent ownership.
- `PROVENANCE.md` corrects this adequately.
- **Do not rename the issuer.** It is part of the oracle's eight hashed inputs, and renaming would invalidate the partial freeze.

---

## Oracle and evidence notes (not result evidence)

- The partial oracle's canonical-preimage digests match the author's continuation hashes for both programs and both plans:
  - `a965688c…` and `a043c977…` (quoted-fee)
  - `6a5a08d0…` and `ef14320e…` (two-deliveries)
- The oracle's `two-deliveries-observed` draft is byte-identical to the author's file (`29a105e0…`).
- Deterministic convergence on a small sorted-key file with no segment is plausible. Root's independence attestation still governs.
- Neither point establishes agreement with the runtime.
- GAP-TRACE-1 still leaves 12 `Step.value` fields unresolved. Full-report comparisons stay **INELIGIBLE**, and the author's expected files stay **AUTHOR-SUPPLIED**.

## UNVERIFIED dependencies (outside the files I read)

- `mori_core::json::parse` number representation equals `to_value` output for ExprId/site/scale/index.
- `json::export` escaping behaves as asserted.
- `decode::event` is strict.
- `Error` serialization is complete.
- The byte-equality assertion at `stage_test_public.rs:96-98` assumes serde_json's default sorted `Map`, i.e. that no `preserve_order` feature is unified into the build. This is a nonsecurity concern for Muse and Root.

## Abstentions and remaining gaps

- No hostile tests were authored or executed.
- Rejected-resume retry and error-path behaviour remain unobserved.
- These remain open for the hostile lane:
  - S4 resource behaviour
  - malformed manifests and events
  - `null` versus absent `logical_cap` at runtime
  - aliasing between event and expected paths
- No theorem, financial-validity, privacy, native, proof or target judgment is made.
- Any doc edits Root adopts from S1–S3 create a new candidate hash. That needs a fresh freeze and review before any separate execution admission.
