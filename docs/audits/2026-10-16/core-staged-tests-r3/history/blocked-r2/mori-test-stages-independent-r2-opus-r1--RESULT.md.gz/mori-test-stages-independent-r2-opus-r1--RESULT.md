# Verdict: **APPROVE_FROZEN_NORMAL_EXPECTATIONS_ONLY**

This approves the six report candidates in freeze `428d9eab…4918` only as frozen normal expectation data. The approval rests on the disclosed premises listed below and on conditions N1–N6.

It does not approve:
- execution, a build, a comparison, comparison admission, integration or publication;
- a runtime result, evaluator correctness or proof;
- native or financial acceptance, or any roadmap exit.

All 14 draft gaps remain open. The author's self-assessment carries no review weight.

I am `claude-opus-5-5 high`, the same model recorded as the trace-contract draft author and the Opus r1 reviewer. My non-authorship of this oracle rests on a separate context. I authored or edited none of these files.

I had no tools. I recomputed no SHA256 values, and I saw neither the r1 `.partial.json` files nor the r1 freeze. Byte binding and "exactly 12 replacements, all other r1 values preserved" therefore rest on Root's mechanical record, not on my check.

## 1. AST and plan preimages

I checked these against the supplied `parser.rs`, `ir.rs`, `plan.rs` and `cost.rs`.

### TwoDeliveries

| Item | Expected (my derivation) | Oracle | Result |
|---|---|---|---|
| Expression nodes 0–6 | `Lit 7`, `Lit 1`, `Name ok`, `Lit 3`, `Name seen`, `Lit 2`, `Name phase` (one push per occurrence, no interning) | same | match |
| Statement expression IDs | Transfer 0, Next 1, Await 2, Transfer 3, Await 4, Next 5, Emit 6 | same | match |
| Language and semantics | `moriarty/2` and `moriarty-core/2` (`parser.rs:37-38`) | same | match |
| Site 1 | ordinal 2, captures `[]` (cloned before the binders are pushed, `plan.rs:85-93`) | same | match |
| Site 2 | ordinal 4, captures `[ok/Event/2]` | same | match |
| Segment costs | 2+2+1=5; Await 2 + Transfer 2 + entry 1 = 5; 2+2+2 = 6 (no entry, `cost.rs:106`) | `[5,5,6]` | match |
| Committed before and total | `[0,5,10]`, total 16 | same | match |

### QuotedFee

| Item | Expected (my derivation) | Oracle | Result |
|---|---|---|---|
| Expression nodes 0–6 | `Name amount`, `Lit 1`, `Add(0,1)` (children before parent, `parser.rs:311-312`), `Name agreed`, then `Name payable` three times | same | match |
| State order | `total` then `marker`, in declaration order | same | match |
| Site 1 captures | `[amount/Input/0, payable/Let/0]` | same | match |
| Segment costs | Let: 1 + 3 nodes = 4, plus entry 1 = 5; resume: 2+2+2+2 = 8 | `[5,8]` | match |
| Committed before and total | `[0,5]`, total 13 | same | match |

Key sets, sorted order, string-encoded UInts, integer ordinals and `scale`, and unit-variant enums (`"Bool"`, `"Event"`) all agree with the type declarations.

Each plan's `program_hash` equals the hash its continuation reports. The plan hashes also agree across `canonical-digests.json` and the freeze. That cross-file agreement is all I verified about the hashes.

## 2. The six reports

### TwoDeliveries

| Report | State, balances and duties | Ordered effects | Step values (category) | Work (attempted / committed) | Frames and continuation |
|---|---|---|---|---|---|
| Start, cap 16 (preflight 16 ≤ 16) | Pre: alice 20, bob 0, observer 11, treasury 0, phase 0, duty 5. Post: alice 13, bob 7, phase 1. | Transfer 7 alice→bob; State phase 0→1. No step at the Await at 2. | 7 (6), 1 (4) | 5 / 5 | Frames idle → {site 1, []}. Cap "16", committed "5". |
| Approval false | Boundary unchanged | none (`segment:null`, `advanced:false`) | none | 2 / 5 | Continuation identical to start's. |
| Approval true (preflight 10 ≤ 16) | Pre is the boundary. Post: alice 10, bob 10, phase 1. | Transfer 3 only. Await effects are empty and not concatenated. | Await `true`, snapshot = pre (10); 3 (6) | 5 / 10 | Frames {1, []} → {2, [ok:true]}. Cap "16", committed "10". |
| Receipt true (preflight 16 ≤ 16) | Post: phase 2, balances unchanged | State phase 1→2; Emit `done` 2. The emit reads the immediately updated phase. | Await `true`, snapshot = pre (10); 2 (4); 2 (5) | 6 / 16 | Frames {2, [ok]} → idle. Status complete, no continuation. |

### QuotedFee

| Report | State, balances and duties | Ordered effects | Step values (category) | Work (attempted / committed) | Frames and continuation |
|---|---|---|---|---|---|
| Start, no cap | Pre = post: observer 11, payer 20, treasury 0, marker 9, total 0, duty 3 | none | 5 = 4+1 (1) | 5 / 5 | Frames idle → {1, [amount 4, payable 5]}. Cap `null`. |
| Quote true (effective cap `None`) | Post: payer 15, treasury 5, total 5, marker 9 | Fee 5 payer→treasury; State total 0→5; Emit `fee` 5 | Await `true`, snapshot = pre (10); 5 (7); 5 (4); 5 (5) | 8 / 13 | Frames {1, captures} → idle. Status complete. |

### Financial accounting

- **TwoDeliveries:** alice's cumulative gross debit is 7, 10, 10, and bob's net receipts match. Fees are 0.
- **QuotedFee:** the payer's gross debit is 5, all of it a fee. The treasury's net receipt is 5.
- **Both:** the balance sum is 31 at every boundary. There is no mint, burn or reserve effect, and no liability creation, accrual or discharge. `residual` lists the positive duty in each case: 5 for TwoDeliveries and 3 for QuotedFee.
- **Untouched rows:** observer, treasury (in TwoDeliveries) and `marker` are preserved in every snapshot.
- **Docs anchor:** this work model reproduces the docs' delivery example of 5/6, with a false resume at 2.

### Replacement map

- All 12 pointers resolve to every Step that exists across the five segment-bearing reports.
- Each pointer's new value equals the value in its report.
- The categories used are exactly {1, 4, 5, 6, 7, 10}.
- No placeholder remains, and no Requires, Ensures, Liability or Discharge slot exists.
- The script assigns only these pointers and imports no Moriarty code.

## 3. Conditions (record with the freeze)

- **N1. Unsupplied source premises.** These fields rest on source-derived premises whose specimens were not supplied to me: `intent.rs` canonical encoding, `simulate.rs` envelopes, the `admit.rs` and stage runtime flow, and the runtime comment at line 981. I checked them only for consistency with the [N] text and the types. They are neither independent nor verified by me.
  - `advanced:true` on start;
  - resume `frame_pre` equalling the input frame;
  - `Execution.semantics = "moriarty-core/2"`, taken from `program.semantics`. GAP-03 remains open, and draft §4 is outside the scope of the Opus review's C1;
  - the waiting envelope's `committed` field;
  - the presence and absence of Await Steps.
- **N2. Hashes not recomputed here.** Preimage-to-digest equality and the hashes of the 21 bound files rely solely on Root's mechanical verification. The r1-to-r2 delta also rests only on that record.
- **N3. Cost-schedule provenance.** The work numbers use the static schedule in `cost.rs`, which is source-derived. They agree with the [N] work text, but they are not an observation of the evaluator's meter.
- **N4. Comparison scope.** A future comparison predicate means JSON value equality only. It does not cover byte order or formatting (GAP-04).
- **N5. Untested traps.** The C6 traps are not exercised by these cases. They remain untested limits.
- **N6. Self-assessment.** The author self-assessment keeps zero review weight, and C1–C6 remain binding.

Unchanged: execution UNRUN, comparisons UNRUN, admission NOT_GRANTED, native authority 0. All 14 gaps stay open.
