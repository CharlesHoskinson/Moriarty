"""Assemble hand-derived literal oracle data. Not a Moriarty evaluator/parser.

No candidate output, author expectations, preimages or implementation is read.
Only SHA256 and canonical JSON encoding operate on the literal AST/plan below.
"""
import copy
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).parent
WT = Path('/home/charl/Moriarty/.worktrees/mori-test-stages-20261016')

def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()

def sha(x):
    return hashlib.sha256(x).hexdigest()

def write(name, x):
    (OUT / name).write_text(json.dumps(x, indent=2, sort_keys=True) + '\n')

def u(x): return {'type': 'UInt', 'value': str(x)}
def b(x): return {'type': 'Bool', 'value': x}
def nv(name, value): return {'name': name, 'value': value}
ASSET = {'network': 'local', 'issuer': 'independent-staged-test-oracle', 'reference': 'UNIT', 'scale': 0}
LABELS = {'qualification':'local-reference-stage','authentication':'none','consumption':'untracked'}

two_statements = [
    {'kind':'Transfer','asset':'UNIT','from':'alice','to':'bob','amount':0},
    {'kind':'Next','state':'phase','value':1},
    {'kind':'Await','label':'approval','binders':[{'name':'ok','ty':'Bool'}],'guard':2},
    {'kind':'Transfer','asset':'UNIT','from':'alice','to':'bob','amount':3},
    {'kind':'Await','label':'receipt','binders':[{'name':'seen','ty':'Bool'}],'guard':4},
    {'kind':'Next','state':'phase','value':5},
    {'kind':'Emit','name':'done','value':6},
]
quote_statements = [
    {'kind':'Let','name':'payable','value':2},
    {'kind':'Await','label':'quote','binders':[{'name':'agreed','ty':'Bool'}],'guard':3},
    {'kind':'Fee','asset':'UNIT','from':'payer','to':'treasury','amount':4},
    {'kind':'Next','state':'total','value':5},
    {'kind':'Emit','name':'fee','value':6},
]
two_program = {
 'language':'moriarty/2','semantics':'moriarty-core/2','name':'TwoDeliveries',
 'states':[{'name':'phase','ty':'UInt','initial':u(0)}],
 'assets':[{'name':'UNIT','identity':ASSET}],
 'expressions':[
   {'kind':'Literal','value':u(7)}, {'kind':'Literal','value':u(1)},
   {'kind':'Name','name':'ok'}, {'kind':'Literal','value':u(3)},
   {'kind':'Name','name':'seen'}, {'kind':'Literal','value':u(2)},
   {'kind':'Name','name':'phase'}],
 'actions':[{'name':'deliver','inputs':[],'statements':two_statements}],
}
quote_program = {
 'language':'moriarty/2','semantics':'moriarty-core/2','name':'QuotedFee',
 'states':[{'name':'total','ty':'UInt','initial':u(0)}, {'name':'marker','ty':'UInt','initial':u(9)}],
 'assets':[{'name':'UNIT','identity':ASSET}],
 'expressions':[
   {'kind':'Name','name':'amount'}, {'kind':'Literal','value':u(1)},
   {'kind':'Binary','op':'Add','lhs':0,'rhs':1}, {'kind':'Name','name':'agreed'},
   {'kind':'Name','name':'payable'}, {'kind':'Name','name':'payable'},
   {'kind':'Name','name':'payable'}],
 'actions':[{'name':'charge','inputs':[{'name':'amount','ty':'UInt'}],'statements':quote_statements}],
}
two_plan = {'format':'moriarty-stage-plan/1','program_hash':sha(canonical(two_program)), 'actions':[
 {'action':'deliver','statement_count':7,'sites':[
   {'site':1,'ordinal':2,'label':'approval','binders':[{'name':'ok','ty':'Bool'}],'captures':[]},
   {'site':2,'ordinal':4,'label':'receipt','binders':[{'name':'seen','ty':'Bool'}],
    'captures':[{'name':'ok','ty':'Bool','origin':'Event','ordinal':2}]}],
  'segment_cost':['5','5','6'],'committed_before':['0','5','10'],'plan_total':'16'}]}
quote_plan = {'format':'moriarty-stage-plan/1','program_hash':sha(canonical(quote_program)), 'actions':[
 {'action':'charge','statement_count':5,'sites':[
   {'site':1,'ordinal':1,'label':'quote','binders':[{'name':'agreed','ty':'Bool'}],
    'captures':[{'name':'amount','ty':'UInt','origin':'Input','ordinal':0},
                {'name':'payable','ty':'UInt','origin':'Let','ordinal':0}]}],
  'segment_cost':['5','8'],'committed_before':['0','5'],'plan_total':'13'}]}

def duty(debtor, creditor, amount):
    return {'name':'duty','asset':ASSET,'debtor':debtor,'creditor':creditor,'amount':str(amount)}
def snapshot(state, rows, liability):
    return {'state':state,'balances':[{'account':a,'asset':ASSET,'amount':str(n)} for a,n in rows], 'liabilities':[liability]}
DUTY_TWO = duty('alice','bob',5)
DUTY_QUOTE = duty('payer','treasury',3)
T0 = snapshot({'phase':u(0)}, [('alice',20),('bob',0),('observer',11),('treasury',0)], DUTY_TWO)
T7 = snapshot({'phase':u(0)}, [('alice',13),('bob',7),('observer',11),('treasury',0)], DUTY_TWO)
T1 = snapshot({'phase':u(1)}, [('alice',13),('bob',7),('observer',11),('treasury',0)], DUTY_TWO)
T2 = snapshot({'phase':u(1)}, [('alice',10),('bob',10),('observer',11),('treasury',0)], DUTY_TWO)
T3 = snapshot({'phase':u(2)}, [('alice',10),('bob',10),('observer',11),('treasury',0)], DUTY_TWO)
Q0 = snapshot({'marker':u(9),'total':u(0)}, [('observer',11),('payer',20),('treasury',0)], DUTY_QUOTE)
QF = snapshot({'marker':u(9),'total':u(0)}, [('observer',11),('payer',15),('treasury',5)], DUTY_QUOTE)
Q1 = snapshot({'marker':u(9),'total':u(5)}, [('observer',11),('payer',15),('treasury',5)], DUTY_QUOTE)
FT7 = {'kind':'Transfer','asset':ASSET,'from':'alice','to':'bob','amount':'7'}
FT3 = {'kind':'Transfer','asset':ASSET,'from':'alice','to':'bob','amount':'3'}
FS1 = {'kind':'State','name':'phase','before':u(0),'after':u(1)}
FS2 = {'kind':'State','name':'phase','before':u(1),'after':u(2)}
FED = {'kind':'Emit','name':'done','value':u(2)}
FF5 = {'kind':'Fee','asset':ASSET,'from':'payer','to':'treasury','amount':'5'}
FST = {'kind':'State','name':'total','before':u(0),'after':u(5)}
FEF = {'kind':'Emit','name':'fee','value':u(5)}
IDLE = {'site':0,'captures':[]}
P1 = {'site':1,'captures':[]}
P2 = {'site':2,'captures':[nv('ok',b(True))]}
PQ = {'site':1,'captures':[nv('amount',u(4)),nv('payable',u(5))]}

TRACE_GAP = {'$gap':'GAP-TRACE-1: exact Statement to Step.value Option<Value> serialization mapping lacks an inspected standalone normative contract; no evaluator loop logic or outputs were read.'}
def step(index, statement, boundary, effects):
    return {'index':index,'statement':statement,'value':TRACE_GAP,'snapshot':boundary,'effects':effects}
def segment(action, pre, post, frame_pre, frame_post, effects, steps):
    return {'action':action,'frame_pre':frame_pre,'frame_post':frame_post,
            'execution':{'semantics':'moriarty-core/2','action':action,'pre':pre,'post':post,'effects':effects,'steps':steps}}
def continuation(program, plan, action, frame, boundary, committed, cap):
    return {'format':'moriarty-continuation/1','program_hash':sha(canonical(program)),
      'plan_hash':sha(canonical(plan)), 'action':action, **frame,
      'boundary':boundary,'logical':{'profile':'moriarty-reference-logical-cost/2','cap':cap,'committed':str(committed)}}
def waiting(seg, c, attempted, residual, advanced=True):
    return {**LABELS,'status':'waiting','advanced':advanced,'segment':seg,
      'continuation':c,'attempted':str(attempted),'committed':c['logical']['committed'],'residual':[residual]}
def complete(seg, attempted, committed, residual):
    return {**LABELS,'status':'complete','segment':seg,'attempted':str(attempted),'committed':str(committed),'residual':[residual]}

digests = {}
for stem, program, plan in [('two-deliveries',two_program,two_plan),('quoted-fee',quote_program,quote_plan)]:
    for kind, obj in [('program',program),('plan',plan)]:
        name = f'{stem}-{kind}-preimage.json'
        (OUT/name).write_bytes(canonical(obj))
        digests[name] = sha(canonical(obj))

for variant, tc, qc in [('manifest-input-caps','16',None)]:
    c1 = continuation(two_program,two_plan,'deliver',P1,T1,5,tc)
    c2 = continuation(two_program,two_plan,'deliver',P2,T2,10,tc)
    cq = continuation(quote_program,quote_plan,'charge',PQ,Q0,5,qc)
    reports = {
      'two-deliveries-start':waiting(segment('deliver',T0,T1,IDLE,P1,[FT7,FS1], [step(0,two_statements[0],T7,[FT7]),step(1,two_statements[1],T1,[FS1])]),c1,5,DUTY_TWO),
      'two-deliveries-observed':waiting(None,c1,2,DUTY_TWO,False),
      'two-deliveries-approved':waiting(segment('deliver',T1,T2,P1,P2,[FT3], [step(2,two_statements[2],T1,[]),step(3,two_statements[3],T2,[FT3])]),c2,5,DUTY_TWO),
      'two-deliveries-complete':complete(segment('deliver',T2,T3,P2,IDLE,[FS2,FED], [step(4,two_statements[4],T2,[]),step(5,two_statements[5],T3,[FS2]),step(6,two_statements[6],T3,[FED])]),6,16,DUTY_TWO),
      'quoted-fee-start':waiting(segment('charge',Q0,Q0,IDLE,PQ,[], [step(0,quote_statements[0],Q0,[])]),cq,5,DUTY_QUOTE),
      'quoted-fee-complete':complete(segment('charge',Q0,Q1,PQ,IDLE,[FF5,FST,FEF], [step(1,quote_statements[1],Q0,[]),step(2,quote_statements[2],QF,[FF5]),step(3,quote_statements[3],Q1,[FST]),step(4,quote_statements[4],Q1,[FEF])]),8,13,DUTY_QUOTE),
    }
    for name, report in reports.items(): write(f'{name}-{variant}.partial.json',report)

write('normal-accounting-and-work.json',{
 'format':'moriarty-independent-normal-data/1','scope':'normal expected data only; not financial validity, security, theorem or target evidence',
 'two-deliveries':{
   'boundaries':{'initial':T0,'after-transfer-7':T7,'first-await':T1,'second-await':T2,'complete':T3},
   'ordered-effects-by-segment':[[FT7,FS1],[FT3],[FS2,FED]],
   'statement-source-indices-by-segment-with-evaluated-expression':[ [0,1], [2,3], [4,5,6] ],
   'entry-await-source-indices':[2,4],
   'logical-statement-costs':{'0':'2','1':'2','2-resume':'2','2-entry':'1','3':'2','4-resume':'2','4-entry':'1','5':'2','6':'2'},
   'segment-costs':['5','5','6'],'committed-after-success':['5','10','16'],
   'approval-false':{'attempted':'2','committed':'5','segment':None,'advanced':False,'continuation-unchanged':True},
   'cumulative-gross-debit-alice':['7','10','10'],'cumulative-fees':['0','0','0'],'cumulative-net-receipts-bob':['7','10','10'],
   'liability':{'opening':'5','created':'0','accrued':'0','discharged':'0','closing':'5','present':True},
   'balance-sum-each-boundary':'31','mint':'0','burn':'0','reserve-dust':'0','rounding-dust':'0'},
 'quoted-fee':{
   'boundaries':{'initial':Q0,'first-await':Q0,'after-fee':QF,'complete':Q1},
   'captured-input':nv('amount',u(4)),'captured-let':nv('payable',u(5)),
   'ordered-effects-by-segment':[[],[FF5,FST,FEF]],
   'statement-source-indices-by-segment-with-evaluated-expression':[[0],[1,2,3,4]],'entry-await-source-indices':[1],
   'logical-statement-costs':{'0':'4','1-entry':'1','1-resume':'2','2':'2','3':'2','4':'2'},
   'segment-costs':['5','8'],'committed-after-success':['5','13'],
   'cumulative-gross-debit-payer':['0','5'],'cumulative-fees':['0','5'],'cumulative-net-receipts-treasury':['0','5'],
   'liability':{'opening':'3','created':'0','accrued':'0','discharged':'0','closing':'3','present':True},
   'balance-sum-each-boundary':'31','mint':'0','burn':'0','reserve-dust':'0','rounding-dust':'0'},
 'unmeasured':['circuit cost','DUST','service fees','proof cost','recovery reservation','wall-clock','allocation'],
 'execution':'UNRUN','comparison':'UNRUN','gaps':['GAP-TRACE-1']})

raw_inputs = ['two-deliveries.mori','two-deliveries-scenario.json','approval-false.json','approval-true.json','receipt-true.json','quoted-fee.mori','quoted-fee-scenario.json','quote-true.json']
source_paths = ['docs/CORE-CONTINUATIONS.md','docs/NATIVE-CORE.md','crates/mori-core/README.md','crates/mori-core/src/ir.rs','crates/mori-core/src/parser.rs','crates/mori-core/src/intent.rs','crates/mori-core/src/stage/mod.rs','crates/mori-core/src/stage/plan.rs','crates/mori-core/src/stage/cost.rs','crates/mori-core/src/stage/digest.rs','crates/mori/src/commands/simulate.rs']
write('input-sha256.json',{p:sha((WT/'models/core-stage-tests'/p).read_bytes()) for p in raw_inputs})
write('source-premise-sha256.json',{p:sha((WT/p).read_bytes()) for p in source_paths})
write('canonical-digests.json',digests)
