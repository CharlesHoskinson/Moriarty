# R3 test-header provenance correction

Changed only the first four module-doc comment lines in
`crates/mori/tests/stage_test_public.rs`, based on final Opus F1/K3.
The header now identifies current reports/preimages as blinded independent R3
oracle copies frozen after implementation existed, with independence from
blinding rather than preimplementation timing. All runtime comparisons UNRUN.

Before SHA256: `2d045094c0e67e6941f6a6b3f5b6a101a910e4d97fa4fcce80dc9daba2feeaff`
After SHA256: `d4abfcfd1af848aa0d00bbf40c4ca00ea463a2032da0ca8431c0da873264fca1`

Nonheader bytes are identical (SHA256 `1149302d4411b4496000e95d127cf7960003cc86fea0677ecf86f27ca571b299`).
The exact diff and source-finding receipt hash are in WORK_REPORT.json.

Falsifiable predicate: only the first four //! comment lines differ; every
remaining byte is unchanged. Test logic, fixtures, audit captures, other source,
metadata and index were not edited. No formatter/build/test/product command,
external model/subagent, private source read, commit or push was used.

No prior approval carries forward. Root owns the freeze and fresh exact-candidate
reviews. All product checks **UNRUN**, native authority0, all parent exits open.

```diff
--- before/crates/mori/tests/stage_test_public.rs
+++ after/crates/mori/tests/stage_test_public.rs
@@ -1,7 +1,7 @@
-//! Ordinary public staged-test consumers. Author-supplied provisional reports
-//! and canonical preimages were frozen before the command implementation.
-//! They are independent of evaluator output, not independent author ownership.
-//! No evaluator/compiler/backend import; these checks remain UNRUN until admitted.
+//! Ordinary public staged-test consumers against blinded independent R3 oracle copies.
+//! Current reports and canonical preimages were frozen after implementation existed.
+//! Oracle independence rests on blinding, not preimplementation timing.
+//! No evaluator/compiler/backend import; all runtime comparisons remain UNRUN.
 use serde_json::{Value, json};
 use std::{
     fs,
```
