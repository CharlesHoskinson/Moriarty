# Verdict: **APPROVE_CURRENT_SOURCE_AND_DRAFT_UPDATE_ONLY**

This verdict covers the exact 162-path candidate on base `504acdbe48cd08aee26caa8740329612b14bc682` and publication of that candidate as an update to the existing **draft** PR75. Conditions G1–G6 below and the inherited K1–K4 limits are part of the verdict.

This verdict does not approve:
- marking the PR ready for review, or merging it;
- any build, Cargo, CLI, test or comparison run, or comparison admission;
- any runtime or printed-format result;
- native, financial or target acceptance, or any parent or milestone exit.

**Reviewer.** I am `claude-opus-5-5` at high effort. The R1, R2 and R3 Opus reviewers and the trace-contract author were the same model. Finding F1, which this candidate corrects, is my own prior wording, and the new header closely reproduces it. So I am partly reviewing text I suggested. My non-authorship rests only on a separate context. The author work report does not name its model.

**Method.** I used no tools, ran nothing and recomputed no SHA-256 values. Digest and membership equality rest on Root's mechanical record. I checked byte counts and arithmetic by hand where noted.

## 1. The change is exactly what is claimed

- **Diff.** Only `crates/mori/tests/stage_test_public.rs:1-4` changed. All four lines are `//!` module comments. The diff in the author work report matches the frozen file.
- **Byte count.** I counted the old header lines at 79, 75, 80 and 84 bytes (318 total) and the new lines at 88, 86, 73 and 80 bytes (327 total). The difference is 9, which gives 5669 + 9 = 5678. This agrees with the reported before and after sizes. It is consistent with a header-only edit but does not prove the tail is unchanged; the tail hash `1149302d…` rests on Root.
- **Code.** No test logic, import, attribute or path changed. The new header compiles as an inner doc comment with no code block or lint-relevant content. `rustfmt` does not wrap comments by default. The longest new line is 87 columns.
- **Accuracy of the new header:**
  - The six root reports are byte copies of the R3 freeze `ad44178b…`. The header's "blinded independent R3 oracle copies" is correct.
  - "Frozen after implementation existed" is correct.
  - "Independence rests on blinding, not preimplementation timing" is correct. `PROVENANCE.md` and the R3 `DERIVATION.md` record what the author was blinded to and what source it did read.
  - "No evaluator/compiler/backend import" is correct: the file imports only `serde_json` and `std`.
  - "All runtime comparisons remain UNRUN" is correct.
  - The header claims no semantic independence. F1 is resolved in source.

## 2. Membership and inherited bytes

I counted the published paths by hand:

| Group | Paths |
|---|---|
| CAPTURE-BINDING `source_files` | 94 |
| Bound captures | 58 |
| `CAPTURE-BINDING.json` and `README.md` | 2 |
| R3 final-review captures | 4 |
| `REVIEW-BINDING.json` | 1 |
| **Original published total** | **159** |
| New `header-correction-r1/` members | 3 |
| **Candidate total** | **162** |

This matches the declared 159 original paths, 158 unchanged paths and 3 new members.

I re-checked the unchanged R3 data against the supplied consumer source:

- **R7 registry.** Each `declare` action registers `duty` with the exact UNIT identity and debtor/creditor pair carried by its scenario.
- **Ordering.** State keys, balance order and liability order are canonical.
- **Trace bound.** Trace cells are 63 for deliver and 49 for charge.
- **Costs.** Segment costs are 5/5/6 (total 16) and 5/8 (total 13). Each `declare` costs 2. The start cap check is 16 ≤ 16. The false approval passes preflight at 10 ≤ 16 and attempts 2.
- **Expression arenas.** The parser's append order gives eight nodes per program, with the literal 0 at node 7.
- **Hashes.** Every continuation carries the program and plan hashes named in the plan preimages and `canonical-digests.json`.
- **Mutation pointers.** All eight pointers in the expected-report mutation test still resolve against the R3 bytes.

I found no new defect in `test.rs`, `stage_test.rs` or the data.

## 3. Findings (none blocking a draft)

- **G-F1. The guide's binding link is now stale.** `docs/CORE-STAGED-TESTS.md` and `models/core-stage-tests/PROVENANCE.md` link to `REVIEW-BINDING.json`, which binds `stage_test_public.rs` at `2d045094…`, not the current `d4abfcfd…`. The new README qualifies this, but a reader who follows the guide's link cannot find that README. Docs may not be edited in this round. Before ready-for-review, a later candidate must point the guide and provenance at the current binding, or at an index of both bindings, and needs fresh review.
- **G-F2. Wording.** The header-correction README says "findingF1" with no space. This is cosmetic only.
- **G-F3. Correlated premise.** "Blinded" is the oracle author's own attestation. R1, R2 and R3 share the same owner and model, and the R3 author read original stage source and, later, R2 review text. This is disclosed in `DERIVATION.md` and is no change from F4.
- **Still open from the prior review:**
  - F2: the root `expectation-freeze.json` binds archived bytes.
  - F3: the source-wide registry lets an unexecuted declaration admit an incoming duty. This is documented Core behaviour.
  - F5: a read-only grep showing that no recursive harness discovers `history/blocked-r2/`.
  - F6: the copied assembly scripts must keep their label as unportable provenance that must not be run.

## 4. Privacy and disclosure

**New members.** The three new members expose:
- the host username and worktree/runtime paths;
- the receipt path and SHA-256 of the prior final Opus review;
- tool and skill names.

They contain no request IDs or cost figures.

**Review captures to be appended.** The four captures will expose model names, provider request and response IDs, token counts and cost figures.

**Judgment.** I judge all of this acceptable for deliberate public disclosure, consistent with the material already published at `504acdbe`. I saw no credentials, keys, environment values, parameters or SRS, private witnesses, Clean or Fenrir content, or personal contact data. This review text contains none either.

## 5. CI and publication

- **Workflow.** `site.yml` is the only active workflow. Its `push` trigger is limited to `main`. Its `pull_request` trigger is limited to `site/**` and its own path. `workflow_dispatch` is manual only.
- **Candidate paths.** The candidate adds or changes no `site/**`, `.github/**` or CI configuration path.
- **Diff size.** The PR diff stays at about 170 files, below GitHub's documented 300-file limit for path-filter evaluation.
- **Expected result.** No configured workflow should run. This is a judgment from configuration, not an observation; the tripwire in G5 is the control.

## 6. Conditions

- **G1. Append only; no rewrite.** Publish as a new fast-forward commit on top of `504acdbe`. Do not force-push or rewrite that commit. The existing `CAPTURE-BINDING.json`, `REVIEW-BINDING.json` and all prior captures must stay byte-identical.
- **G2. Capture names.** Name the four new captures distinctly, for example `header-correction-r1/mori-test-stages-header-final-{muse,opus}-r1--RESULT.{md,json}.gz`. Do not reuse or overwrite any `final-*-r1` or `r3-final-*-r1` name. Capture verbatim with no redaction. Gzip deterministically (for example `gzip -n`) so the header carries no host filename or mtime. Record the original and gzip SHA-256 values and byte counts for each capture.
- **G3. Separate binding.** Write a separate binding, for example `header-correction-r1/REVIEW-BINDING.json`, and never overwrite the existing `REVIEW-BINDING.json`. It must:
  - bind all 162 frozen paths and their hashes, plus the 4 new captures;
  - record base `504acdbe` and the exact candidate membership hash;
  - classify the existing `REVIEW-BINDING.json` and the `r3-final-*` captures as dispositions of the `504acdbe` bytes only (test hash `2d045094…`);
  - classify the `final-*-r1` captures as R2-only;
  - state that R2 positive-data approvals are `INVALIDATED_HISTORICAL_ONLY` and that no prior approval carries forward;
  - record both current dispositions with model, effort and terminal state;
  - record execution `UNRUN`, comparison admission `NOT_GRANTED`, native authority `0` and publication scope `DRAFT_ONLY`.
- **G4. Exact diff before push.** The diff from `504acdbe` to the new head must contain exactly the 3 new members, the 5 finalization files (4 captures and 1 binding) and 1 modified file, `stage_test_public.rs`. Any other path voids this approval.
- **G5. Bounded post-push check, read-only.** Confirm that:
  - PR75 is still a draft;
  - its head SHA equals the new commit;
  - the status rollup is empty;
  - there are zero Actions runs for the branch, the PR and the head SHA.

  If any run appears, stop and report it. Do not cancel or retry. This admits no new CI or build activity.
- **G6. Before ready-for-review or merge.**
  - Resolve G-F1 and F5.
  - Obtain fresh reviews of any further changed bytes.
  - Obtain a separate decision on execution admission.

  This verdict satisfies F1 and the Opus source-review part of K3 for these exact bytes only.

**K4 is unchanged:**
- Everything remains UNRUN, comparison admission is NOT_GRANTED and native authority is 0.
- P-TRACE-PROJ/draft remains unadopted.
- Source-admission consistency is not a semantic proof.
- C1–C6 and the historical N1–N6 keep their scope.
- All fourteen draft gaps stay open, and GAP-13 keeps its historical R7 contradiction.
- JSON value equality is the only intended predicate; printed member order and whitespace remain unobserved.
- No U0–U7, M1–M17, MC/SP/G, partial/conditional or parent exit changes.
