### Command Classification: **ORDINARY HOST / NON-NATIVE (Both Stages RED and GREEN)**

Scope: **Command classification only.** This assessment carries zero correctness, security-property, or adoption vote, makes no Candidate B (`sherlock-helper-microstep/1`) claim, does not assume Stage GREEN test results, and leaves untrusted consumers excluded under H1.

---

### 1. Command & Execution Boundary
* **Working Directory:** [`/home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015)
* **Exact Argv (Identical for RED and GREEN):**
  ```text
  ["timeout", "90s", "python3", "-I", "-B", "models/sherlock/reference/check-reference.py", "--rustc", "/home/charl/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin/rustc", "--timeout-seconds", "30"]
  ```
* **Host-Only Properties:**
  * `python3 -I -B` runs in isolated mode (ignoring `PYTHONPATH` and user site directories) and suppresses `.pyc` bytecode writes.
  * [`check-reference.py`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/models/sherlock/reference/check-reference.py) uses only the Python standard library, verifies pre- and post-execution SHA-256 digests of all 3 `FROZEN` files and 9 `SOURCE_PATHS`, checks that [`normal_oracles.rs`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/crates/mori-core/src/sherlock/normal_oracles.rs) is an exact transcription of the frozen JSON literals, compiles [`mod.rs`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/crates/mori-core/src/sherlock/mod.rs) directly with the pinned host `rustc` (`--edition=2024 --test`) into an ephemeral `tempfile.TemporaryDirectory`, and runs the test binary single-threaded (`--test-threads=1 --nocapture`).
  * No Cargo, `build.rs`, proc-macros, external crates, network I/O, or persistent filesystem writes outside temporary storage are invoked.
  * **Zero Native Authority:** Neither stage touches any SDK relation, circuit, model, degree, $k$, VM, transcript, keygen, prove, native verify, ledger, deploy, private key, PK, SRS, or cache path.

---

### 2. Two-Stage Closure & Pinned SHA-256 Conditions

The classification as **Ordinary Host / Non-Native** holds iff the following exact byte-level conditions are satisfied:

1. **Frozen Oracles & Specification (Both Stages):**
   * `models/sherlock/oracles/normal-programs.json`: `ef87f94f7e5d22a75b1c2e5e61af016b08175beee9a3599e3e69ddf92945d32f`
   * `models/sherlock/oracles/normal-prefixes.json`: `dca67b553d7483fdf7d9148e7f4bf1a6022b42b8843635f33f23c58a2415d56d`
   * `models/sherlock/k/main.k`: `b3746ff51dd7999b046ccb23237595605420adcfeebc0c04c0ad0f1396b11d41`
2. **Fixed Source Closure Across Both Stages (7 Files):**
   * [`check-reference.py`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/models/sherlock/reference/check-reference.py): `01f370da84e9681cf18cccd4128979631471b59ebee70426a9eacb620000961f`
   * [`mod.rs`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/crates/mori-core/src/sherlock/mod.rs): `d550b50b0c73f49c7c8267d718c31cc1753c064124ddcf64b347f515c5a229bd`
   * [`normal_oracles.rs`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/crates/mori-core/src/sherlock/normal_oracles.rs): `3421828bada394a5f1aa7b9ccc2fa52182db88adf7f2bfd58bf1d871e9d6bbe5`
   * [`reference_display.rs`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/crates/mori-core/src/sherlock/reference_display.rs): `3f3456bfeaa6ce043986de29673ba038d94cfa405de2d715fd774ad8aa1872e4`
   * [`reference_oracles_tests.rs`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/crates/mori-core/src/sherlock/reference_oracles_tests.rs): `7d254ecd7ffbadda8214e82d47dd2d2c21aea261677f223813541a386d22faba`
   * [`reference_tests.rs`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/crates/mori-core/src/sherlock/reference_tests.rs): `0138a704d0d68c9c78bb9ae752011736a387bb9bc24072e44ff73854536901c1`
   * [`resource_tests.rs`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/crates/mori-core/src/sherlock/resource_tests.rs): `e785241f3ebfe3269de8e2c316270f4308476d956c996a95e014965b872b1457` (5 security-owned tests alongside the 8 existing normal tests and 92 literal prefixes; all inputs are tiny, finite host ASTs).
3. **Stage-Specific Pinned Files (2 Files):**
   * **Stage RED:**
     * [`reference_types.rs`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/crates/mori-core/src/sherlock/reference_types.rs): `44802a96c9a903160bd20043007a98c315d47213f6978db2f00469da34bbc7f9` (provides real method signatures [`Outcome::is_resource_limit`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/crates/mori-core/src/sherlock/reference_types.rs#L140) $\to$ `false` and [`Snapshot::checked_charged_steps`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/crates/mori-core/src/sherlock/reference_types.rs#L159) $\to$ `Some(0)`, ensuring compilation succeeds with exit code `0` and RED fails via runtime assertion failures in `resource_tests` rather than missing-method compile errors).
     * [`reference.rs`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/crates/mori-core/src/sherlock/reference.rs): `3f8ccbf3d594b29873fcf79684d98639a7d90155f34cd06ab06ec82a01048b00`
   * **Stage GREEN:**
     * [`reference_types.rs`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/crates/mori-core/src/sherlock/reference_types.rs): `4b4bb364a0c8182e117a9c36efb5d91cb7e405f653a6d3870f54dc03eefa317f`
     * [`reference.rs`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/crates/mori-core/src/sherlock/reference.rs): `e1bb1098d6e19ca3bca30a09bb90b11366fa9f70726aba9165d54f14056b181b`

---

### 3. Blockers & Invalidating Conditions
* **Blocker Status:** **None** for classifying and running the exact two-stage command as an ordinary host / non-native check under the pinned hashes above.
* **Invalidating Conditions:**
  1. Any deviation in argv, working directory, `--rustc` binary path, or timeout bounds (`90s` outer / `30s` inner).
  2. Any pre- or post-execution SHA-256 mismatch against the pinned RED or GREEN file digests listed above, or introduction of any additional module/import.
  3. Stage RED failing at `rustc` compilation (`exit_code != 0` on compile) instead of compiling cleanly (`exit_code == 0`) and failing via non-zero test assertion exit code.
  4. Any attempt to treat Stage GREEN execution as a security/correctness adoption vote, a Candidate B claim, or authorization to expose [`Machine`](file:///home/charl/Moriarty/.worktrees/sherlock-resource-diagnostics-20261015/crates/mori-core/src/sherlock/reference.rs#L9) to untrusted consumers.

