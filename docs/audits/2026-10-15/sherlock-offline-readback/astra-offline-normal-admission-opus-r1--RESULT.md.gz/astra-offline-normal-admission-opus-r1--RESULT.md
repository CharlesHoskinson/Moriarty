# Security classification: Sherlock Astra offline normal tests, proposal r1

**Classification: BLOCKED as proposed, on one import-closure gap. The command class itself is eligible as an ordinary path.** This is a source and classification finding only. It does not admit the run, does not claim a runtime pass, and grants no native authority (it stays at zero). It requests no change to any cap. Once the single prerequisite below is met, I find no other security blocker under the unchanged limits.

## Findings

1. **Subject behaviour matches the claim.** `test_offline.py` and `offline.py` import only stdlib modules (`hashlib`, `json`, `pathlib`, `unittest`, `argparse`, `copy`, `typing`, `__future__`) plus local `offline`.
   - They only read files, using `read_bytes` and `read_text`.
   - There are no subprocess, socket, environment, tempfile or write calls.
   - `main()` is never invoked.
   - The ZKIR, hex and commitment strings are parsed as JSON string values and never interpreted.
   - Every path the tests resolve sits under `REPO = HERE.parents[2]`, which is the worktree root. Each such path is listed in INPUT-MEMBERSHIP.
   - I counted 16 test functions (11 + 5), which matches `expected_test_functions`.
   - Memory and recursion use are trivial: JSON of about 75 KB, shallow recursion.

2. **Import-path analysis.** With `-I`, which implies `-E -s -P`, the working directory is not prepended to `sys.path`. `-S` suppresses `site`, `.pth` files, `sitecustomize` and dist-packages.
   - `unittest discover -s models/sherlock/stagenet` with no `-t` sets `top_level_dir` to the absolute start directory and runs `sys.path.insert(0, …)`.
   - That insertion is how `import offline` resolves.
   - It also means that every entry in that directory is importable ahead of the stdlib, for any module not yet cached in `sys.modules`. That includes `json`, `hashlib`, `copy`, `pathlib` and `typing` at test-import time.

3. **Blocker: directory membership is not pinned, only file contents are.** INPUT-MEMBERSHIP fixes the bytes of named files. It does not establish that `models/sherlock/stagenet` and its `fixtures/` subdirectory contain only those files. Any of the following would execute code that the hashes do not cover:
   - a stdlib-shadowing `json.py`, `hashlib.py` or `copy.py`, or a package directory with those names;
   - an extension module such as `offline*.so`, which `FileFinder` prefers over `.py`;
   - a `__pycache__/offline.cpython-314.pyc` or `test_offline.cpython-314.pyc` whose recorded mtime and size match the source, or an unchecked-hash pyc. `-B` only stops bytecode writes; existing pyc files are still read;
   - a `fixtures/__init__.py`, which would make discover recurse into `fixtures` and import it;
   - a `stagenet/__init__.py`, which changes how discover treats the start directory;
   - a symlinked `stagenet` or a symlinked path component, which would move `HERE` and `REPO` because the code calls `Path.resolve()`.

   None of these are suggested by the supplied material. But the proposal's pre-run and post-run checks would not detect them.

4. **Sandbox view is consistent with the stated R4 pattern.**
   - The root is the empty bwrap tmpfs. `--dir /tmp` lives on that root, so it becomes read-only after `--remount-ro /`.
   - Only `/usr`, `/etc` and the worktree are bound, all read-only, with the WSL masks retained.
   - `/dev` and `/proc` are private. `--unshare-net` and `--unshare-pid` are set, and the `--new-session` flag guards against TIOCSTI.
   - DBUS and XDG are unset inside the sandbox; they are needed only by the outer `systemd-run --user`.
   - The tool chain (`systemd-run`, `timeout`, `bwrap`, `bash`, `python3`) resolves through the same `/usr` and `/etc` view inside and outside, so the pinned tool hashes are meaningful.
   - No toolchain, Nix, cache or scratch mount is needed or present.

5. **Shell and limits are correct.**
   - In non-POSIX mode, bash `ulimit -f 16384` is 16384 × 1 KiB = 16 MiB, setting both soft and hard limits. This matches `fsize_bytes`.
   - The script has no `set -e`. A failing `ulimit` could only mean a lower inherited hard limit already exists, so the run fails toward tighter limits.
   - `BASH_ENV` is absent from the fixed 7-variable environment, so bash runs no rc file.
   - The cgroup values match the JSON exactly: `MemoryMax=4G`, `MemorySwapMax=0`, `TasksMax=256`. Timeouts are 90 s outer and 30 s inner, each with a 5 s kill-after.

6. **Termination path.**
   - The outer `timeout` signals its own process group.
   - The sandboxed tree is in a new session, so cleanup relies on `--die-with-parent`, the pid-namespace init, and the scope cgroup.
   - That combination is adequate.
   - `/usr/bin/timeout` is uutils (Rust coreutils), not GNU. Record its exit status literally, for example 124 or 137, and do not infer GNU semantics.

7. **Changes from Foreman's prospective argv.** The proposed argv adds `-I -S` and uses an absolute interpreter path. This is stricter than Foreman's version and functionally compatible with discover, per finding 2. Any result applies to the proposed argv, not to Foreman's.

## Minimal prerequisite (the only blocker)

Immediately before launch, and again immediately after exit, record a recursive no-follow (`lstat`) manifest and require exact equality with this entry set:

- Every path component from the worktree root to `models/sherlock/stagenet` is a real directory, not a symlink.
- `models/sherlock/stagenet` contains exactly:
  - `offline.py`
  - `test_offline.py`
  - `fixtures/`
- `fixtures/` contains exactly the five listed `.json` files.
- All files are regular files.
- There is no `__init__.py`, no `__pycache__`, no `.pyc`, no `.so`, and no other entry.
- The four `crates/…` and `deliverables/…` inputs are regular files, not symlinks.

Combine this with the existing content hashes. If there is any extra entry or mismatch before launch, do not run; it is not a retry candidate. A mismatch after exit means the result is not accepted. This check is a guard on the existing input surface, not a change to the mount view or to any limit.

## Non-blocking residuals (recorded, not promoted)

- **Host writes are not blocked.** A read-only bind controls only the sandbox's view, and pre/post hashes do not detect a change that is made and then reverted. Ensure no other agent or process writes to this worktree during the run window.
- **Cgroup enforcement is inherited.** The ceilings only bind if the user manager has the memory and pids controllers delegated. I accept this as the owner-known unchanged condition and do not re-establish it.
- **Writable private `/dev` tmpfs.** This includes `/dev/shm`. Its pages are charged to the scope's memory limit and each file is capped by the 16 MiB fsize limit. The subject does not use it.
- **Full read-only `/etc` and worktree.** Host configuration is readable inside the sandbox, but there is no network, and output goes only to root's capture files.
- **The subject holds the capture fds.** It could rewrite its own stdout or stderr. The source review rules this out for this code, but the capture files are therefore not tamper-evident against the subject.
- **stdout buffering.** Python's stdout to a regular file is block-buffered, so output may be lost if the process is killed. unittest `-v` reports go to stderr, which is line-buffered, so they survive.
- **Muse finding 8 still stands.** It noted that the pure-scope and external-configuration branches are untested and that `.get` is called on effect entries that might not be objects. Hostile and malformed-input cases are not covered by this normal run. A 16-test pass would establish nothing about them, nor about native, target, financial or stagenet properties.
- **The R4 preflight is unaffected.** It remains refused. I have not reused it and see no exception that would apply here.

## Scope

Reviewed:

- PROPOSAL, ARGV, ENV, INPUT-MEMBERSHIP and ROOT-NORMAL-FIXTURE-REVIEW;
- the full bodies of `offline.py`, `test_offline.py`, the five fixtures, the payment artifact, target and source, and the historical readback;
- `ir.rs`;
- the supplied excerpts of `lib.rs` (lines 1–300) and `prepare.rs` (lines 1–64);
- the Muse review.

I recomputed no digests, ran no tools, and executed nothing. Admission, execution and result acceptance remain separate decisions for the root to make.
