Implemented an offline input inventory and complete JSON readback comparator.
The source is in `models/sherlock/stagenet/offline.py`.
The candidate has not run. Root owns integration and check admission.

`prepare` consumes an externally supplied backend Artifact/3, Target, Scenario,
action, application scope, and hash-pinned expected Readback.
It retains complete documents, ordered ABI fields, effect frames, liability frames,
and original evidence labels. It inventories optional source bytes and public target configuration.
It does not fill missing target fields from the artifact.
The requested destination is Midnight stagenet. A supplied local target stays local.

`compare` reads expected bytes under the caller's frozen SHA-256.
It compares every object member and every ordered array entry.
The diagnostic identifies the first JSON pointer, raw differing values, and available full step context.
Missing members differ from null values. Present-zero duties differ from absent duties.
Additional fields are compared without projection. No field exclusion or numeric coercion occurs.

The existing `mori-ledger::prepare::Readback` describes prospective local preparation.
Its preservation scope remains `unchanged-supplied-ledger-not-an-applied-successor`.
JSON equality does not change this scope or establish an applied successor.
The helper supplies no acceptance record or execution status.

The two new pure output fixtures represent ordinary values seven and eight.
Their expected first difference is a separate literal fixture.
These literals do not import an evaluator or comparator.
Native fields contain conspicuous fixture-only strings. They are not native encodings.
The pure application has no financial effects. Network fees remain unknown.
Non-author review of all new expectations remains pending.

The integration tests read an existing compiled payment artifact and historical prepared readback as data.
The payment Scenario is a literal copy of that readback's supplied predecessor, plus amount seventy.
These files test preservation of real consumer shapes. They are not independent semantic oracles.
The test expectations retain transfer, fee, liability, state, and emit order.
They retain the present-zero duty and all original evidence labels.

Observed verification: Python AST parsing and JSON parsing exited zero.
No candidate module was imported or executed. The sixteen normal tests remain UNRUN.
The attached JSON report records exact prospective argv and side effects.
No SDK, Cargo, Lake, K, Quint, model, native, network, or private Fenrir operation ran.
No transaction was submitted. No commit, push, or merge occurred.

Integration points:

- `crates/mori-backend/src/lib.rs`: Artifact/3, Target, CircuitArtifact and ordered frames.
- `crates/mori-backend/src/proving.rs`: source/action/Scenario/Target proving inputs remain separate from this inventory.
- `crates/mori-core/src/ir.rs`: existing Scenario, Execution, Snapshot and Effect JSON shapes.
- `crates/mori-ledger/src/prepare.rs`: complete Readback and prospective preservation scope.
- `crates/mori-ledger/src/relation/mod.rs`: distinct native-call artifact and statement.
- `crates/mori-ledger/src/proving.rs`: private typed native preparation cannot be reconstructed by this helper.

Remaining gaps:

- No Sherlock source or Clean-to-Midnight lowering is supplied.
- No handwritten-step artifact layout is assumed or adopted.
- Backend Artifact/3 is not a ledger native-call artifact. A justified common-subset adapter remains missing.
- JSON container checks do not replace Rust artifact validation or native field decoding.
- Complete opaque native-byte expectations require independent preparation or a reviewed projection. This helper cannot derive them.
- Target endpoints, actual network identity, compatibility, Anchor, proof identities, submission and readback position need external evidence.
- Financial data is retained, but gross debit, fees, net receipts and residual-duty acceptance need their actual accounting adapter.
- No Candidate B, general recursion, correspondence, proof, stagenet or roadmap acceptance follows.
- Fresh Muse nonsecurity review and Opus-owned security review remain pending.

The files remain uncommitted in branch `feat/sherlock-astra-export-20261015`.
The base is `1fb794d1598e19fe34b9735f90996fc316b743fa`.
