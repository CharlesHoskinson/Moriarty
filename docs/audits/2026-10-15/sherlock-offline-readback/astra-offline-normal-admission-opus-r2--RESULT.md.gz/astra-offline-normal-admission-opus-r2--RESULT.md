# Opus R2 disposition: Sherlock Astra offline normal tests

**Verdict: APPROVE.** The exact R2 source (`offline.py` `9a21a2ac…`) and the R2 proposal are eligible for Root formal ordinary admission, provided the immediate prerequisites below are met.

- This is a source and classification finding only. It does not admit the run and does not claim a runtime pass.
- Native authority stays at zero. No cap changes.
- I recomputed no digests and executed nothing. Admission, execution and result acceptance remain Root decisions.

## Findings

1. **The R2 diff applies exactly my findings 12 and 13(b), and nothing else.**
   - The byte arithmetic reconciles: +30 −50 −5 +22 = −3, so 14851 becomes 14848. This matches INPUT-MEMBERSHIP. The hunk offsets (+1, then −1) are consistent.
   - External configuration content no longer reaches any output. Only the path, SHA-256 and size are retained.
   - `"acceptance": "none"` is explicit in both the `prepare` and `compare` results.
   - The diff adds no import, I/O, write path or environment read.
   - Two low-severity items remain, and neither touches this run because the tests never pass `--external-configuration`:
     - The configuration is still parsed, so a duplicate-key error would echo one key name to stderr.
     - Finding 13(a) is unaddressed: absolute `resolve()` paths still appear in output.

2. **The test impact is nil by inspection.** No test asserts full-dict equality of `prepare` or `compare` results, and none asserts that a key is absent. The added field therefore cannot alter any of the 16 assertions. As Muse finding 8 notes, the two corrected lines have no test coverage. A pass must not be cited as exercising them.

3. **The sole R1 blocker is closed as a static observation.** R2-IMPORT-CLOSURE matches the prerequisite:
   - The worktree root, `models`, `models/sherlock` and `stagenet` are all real directories (mode 040755).
   - `stagenet` contains exactly `offline.py`, `test_offline.py` and `fixtures/`.
   - `fixtures/` contains exactly the five regular JSON files.
   - Every file is mode 0100644 with nlink 1.
   - The four historical inputs are regular files.

   Independent corroboration:
   - `stagenet` has nlink 3 and `fixtures` has nlink 2. This excludes any `__pycache__` or package subdirectory.
   - The `stagenet` directory mtime (…429.6 s) is earlier than the `offline.py` mtime (…011.6 s), with the same inode and ctime equal to mtime. This is consistent with an in-place rewrite and with no directory entry created since.

   Components above the worktree root are not lstat-pinned. The host check and bwrap's bind both resolve that path the same way at the same moment, and the root inode and device are recorded, so equality would still detect a substitution. This is not blocking.

4. **The closure scope is correct.** With `-I` (which implies `-P`), neither the cwd nor the worktree root is on `sys.path`. Only `stagenet` is inserted, by discover. Unpinned top-level worktree entries are therefore not importable.

5. **The launch envelope is acceptable and slightly stronger than R1.**
   - Explicit inherited-fd closure matters because bwrap does not close inherited fds. A leaked directory fd would bypass the read-only view.
   - `systemd-run --scope` execs in the same process.
   - ARGV and ENV differ from R1 only in the unit name. The caps (90 s outer, 30 s inner, 4 GiB, swap 0, 256 tasks, 16 MiB file size) are unchanged.
   - R4 is not reused, and its refusal stands.

6. **This is not a terminal retry.** That holds on Root's record that the R1 unit was never created, no subject started and no cap was consumed. If any R1 launch occurred in any form, R1 is terminal and this disposition does not apply. R2 is itself one-shot.

7. **The proposal text is stale.** It says "R2 reviews pending." Do not rewrite PROPOSAL.json. Record the review dispositions in the separate admission record, which should reference PROPOSAL.json by hash.

## Remaining requirements

All of these apply at admission or launch. None requires a source change.

- **a. Admission record.** Root's formal record must bind:
  - the PROPOSAL.json hash and the five listed file hashes;
  - `offline.py` `9a21a2ac…`;
  - Muse R2 APPROVE and this disposition.

  The historical FOREMAN_REPORT (R1 `abff7771…`) may be published only alongside the Root CORRECTION record.

- **b. Pre-launch check, immediately before exec.**
  - Recompute the no-follow closure and all 17 hashes.
  - Require exact equality with the whole R2-IMPORT-CLOSURE record, including parent inode, mode, size, mtime and ctime. Atime is correctly excluded.
  - On any mismatch, do not launch. No subject starts, and continuing requires a new reviewed proposal, not an automatic re-attempt.

- **c. Exec conditions.**
  - The argv and envp passed to execve must be byte-identical to the decoded ARGV.json and ENV.json, and nothing else.
  - The cwd is `/tmp` and fd 0 is `/dev/null`.
  - fd 1 and fd 2 must be fresh regular files **outside the worktree**. Captures inside it would perturb the parent metadata and violate the no-other-writer condition.
  - All other fds are closed.

- **d. No-other-writer attestation.** Record an attestation, with timestamps, covering the worktree and the four historical paths from the pre-check to the post-check.

- **e. Post-exit check.** Repeat (b) exactly. Any mismatch means the result is not accepted.

- **f. Result disposition (for later, not admission).**
  - Record the exit status literally. `/usr/bin/timeout` is uutils, so do not infer GNU semantics.
  - Treat the run as a normal pass only if all of these hold:
    - the exit status is 0;
    - stderr shows exactly `Ran 16 tests` and `OK`, with no skips, expected failures or errors;
    - check (e) holds.
  - Exit 0 alone is insufficient. Any other outcome is terminal for R2, with no retry.

## Limitations

- **Unpinned but read-only.** The stdlib, libpython, lib-dynload, `/etc` and the `pyvenv.cfg` lookup paths under `/usr` are unpinned beyond the five tool binaries. This is an existing residual and is not promoted.
- **R1 residuals stand unchanged.** These are: host writes outside the sandbox view, inherited cgroup delegation, the writable private `/dev` tmpfs, capture fds being tamperable by the subject, and stdout buffering on kill.
- **What a pass establishes.** Only that these 16 normal assertions held over these pinned bytes under this argv. It says nothing about:
  - hostile or malformed input, or the R2 corrected lines;
  - native, target, financial or Midnight stagenet properties;
  - Candidate B, or any B/U/M/MC/SP/G exit.
- **Publishing.** Capture files may contain absolute host paths and, on failure, large JSON diffs. Review them before publishing.
