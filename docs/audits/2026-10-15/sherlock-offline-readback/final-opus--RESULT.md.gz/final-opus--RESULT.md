# Opus security disposition: Sherlock offline helper, final result and publication review

**Verdict: APPROVE.** This approval covers commit, publication and regular merge of the exact frozen package, as an ordinary offline JSON helper. It rests on the mechanical conditions under "Conditions" below.

- This is not target acceptance, native acceptance or financial acceptance, and it admits no new run.
- Native authority stays at 0, and no cap changes.
- U0–U7, M1–M17, MC/SP/G/ZR/MNR/OSR, ACTUS, DeFi and composition exits all stay open.
- The R4 refusal stands, and no guard was regenerated or invoked.
- I used no tools, recomputed no digests and executed nothing. Each hash comparison below compares hash strings within the packet only.

## Result against the R2 admission

1. **The pass criteria in my R2 admission (f) are met as recorded.** These were exit status 0, exactly 16 OK records with `Ran 16 tests` and `OK`, no skip, expected failure or error, and post-closure equality.
   - The stderr capture shows 16 named `ok` lines, `Ran 16 tests in 0.007s`, and `OK`.
   - stdout is empty, with hash `e3b0…`.
   - The stderr hash `fb31…` matches `RESULT.stderr_sha256` and the binding.
   - The test IDs listed under `actual_test_ids` and `expected_test_ids` are identical.

2. **The binding chain reconciles across the whole packet.**
   - **Proposal and admission.** The R2 `PROPOSAL` hash `7918…` matches `EXECUTION-ADMISSION.proposal_sha256`. Its members match the hashes in the binding: ARGV `0ecf…`, ENV `4230…`, INPUT-MEMBERSHIP `2ab6…`, R2-IMPORT-CLOSURE `7a62…` and fixture review `6bab…`.
   - **Reviews.** The Muse R2 hash `43a6…` and the Opus R2 hash `b176…` match the admission record.
   - **Source.** `offline-after` is `9a21…`, which equals the candidate source. `offline-before` is `abff…`, which equals the Foreman R1 hash. The FOREMAN report is therefore published alongside the CORRECTION record, as I required in R2 condition (a).
   - **Argv and environment.** The admission argv and environment are element-for-element identical to the decoded R2 ARGV and ENV. They differ from R1 only in the unit name.
   - **Membership.** The seven source and fixture hashes in CAPTURE-BINDING equal the frozen membership. All 34 capture entries match the membership's capture hashes.

3. **Exec conditions (c) and (d) are met as recorded.**
   - The cwd is `/tmp`, fd 0 is `/dev/null`, and the other fds are closed.
   - fd 1 and fd 2 are regular files under `.moriarty-dev/runtime/…`, which is outside the bound worktree.
   - The no-other-writer attestation covers 00:12:58.68 to 00:13:30.40. Host write-and-revert remains a disclosed residual.

4. **The closure observations are equal.** BEFORE, R2-IMPORT-CLOSURE and `post_closure` are identical in every parent and entry field, so condition (e) holds as recorded.

5. **Evidence weight.** The exit status is a Root attestation that cites transcript chunk `841f84`. That transcript is not in the packet. This is acceptable for an ordinary result, but it is attestation, not captured evidence. The 31.7 s between start and post-check is Root's observation latency, not test duration. Exit 0 rules out an inner timeout under uutils semantics.

## Claim review (documentation and binding)

6. **Every new prose claim is accurate and correctly limited.**
   - The docs say "first difference" follows sorted-key traversal, not execution order.
   - Ordered arrays, missing-versus-present and extension fields are described correctly.
   - The docs state that a traceback is possible outside the handled `OSError`/`ValueError` path.
   - They state the CLI example, the pure branch, the R2 non-echo and acceptance lines, and hostile cases are UNRUN or uncovered.
   - They do not claim a Moriarty command, compiler, native exporter, financial acceptance or stagenet result.
   - All six relative links resolve correctly from their file locations.

7. **The historical-versus-fresh distinction is stated correctly.** The audit README says the result is historical for the bound bytes and not a rerun after the fast-forward. The test reads only the 7 bound files and the 4 historical inputs, and both sets are pinned by hash in INPUT-MEMBERSHIP. Equality of all 17 hashes after the merge therefore carries the claim to the published bytes. The parent directory metadata changed, and that change does not affect the claim.

8. **R1 and R2 history is preserved without rewriting.** The R1 BLOCKED import-closure disposition, R1 UNRUN reports, the Root correction, the R2 reviews and the actual result are all separate, immutable captures.

## Privacy and publication review

9. **No private Fenrir or Clean source, pins, paths or credentials appear in the shown captures.** "Fenrir" and "Clean" appear only as names of gaps or blocked paths, with no paths or pins.
   - The ENV capture holds only fixed launcher values. `DBUS_SESSION_BUS_ADDRESS` and `XDG_RUNTIME_DIR` are standard socket and runtime paths, not secrets.
   - No tokens or keys are present.
   - The external-configuration echo risk (my R1 finding 12) is fixed in the published source.

10. **The remaining host metadata is eligible under the existing policy, and disclosure is Root's choice.** It is non-secret operational metadata of low value:
    - absolute `/home/charl/…` paths and the user name;
    - UID and GID 1000;
    - inode and device numbers;
    - PID 2238327;
    - nanosecond timestamps;
    - the WSL kernel version;
    - tool hashes;
    - model token and cost usage;
    - Muse request and response IDs, which are support identifiers and not credentials.

11. **The `astra-pair-opus-r1` capture also reviews a separate step candidate that is not in this package.** That candidate covers `sherlock_step`, K, Quint and the SDK. The capture exposes no exploitable defect in any deployed or qualified system, and no private material. Publishing it is acceptable as design commentary. Its step-candidate APPROVE must not be read as publication, admission or acceptance of that candidate.

## Conditions (mechanical, Root-owned; no source or doc change)

- **Gzip structure.** I saw only decompressed payloads. Each `.gz` must be a single gzip member whose decompressed bytes hash to the source hash recorded in the binding. There must be no trailing bytes and no FEXTRA or FCOMMENT. FNAME, if present, may only be the benign basename.
- **Staged blobs.** The staged blobs must equal the frozen membership byte for byte. Nothing outside the 51 listed paths may be staged. The only later additions allowed are the four review captures and REVIEW-BINDING.
- **Divergence.** Any mismatch voids this approval for the affected bytes.

## Non-blocking residuals (recorded, not promoted)

- **Stale labels in `post_closure`.** It still says `NO_SUBJECT_EXECUTED` and `candidate_execution: UNRUN`. This is a reused closure template captured after the run, so the README's remark about labels describing capture-time state does not fit this record exactly. The error runs toward under-claiming, and the top-level `PASSED_…` status is unambiguous. Note this in REVIEW-BINDING; do not rewrite the capture.
- **`base_commit` in CAPTURE-BINDING.** `9a7c04…` is the publication base. It is not the worktree HEAD at run time. The result rests on the input hashes, not on the commit.
- **"16 normal assertions".** The precise unit is 16 test methods; there are more `assert` calls than that. This is wording, not an overclaim. ROADMAP's present-tense "pass" would read better as "passed (captured)".
- **Low-severity source items from my R1 and R2 reviews remain:**
  - absolute `resolve()` paths in the tool output (13a);
  - full echo of target, artifact and scenario content by `prepare`. Users should not place credentials in the target;
  - one key name echoed to stderr on a duplicate-key error in external configuration;
  - hostile or deep JSON can raise an uncaught `RecursionError`, `AttributeError` or `TypeError`, which fails closed with a traceback.

  Any of these should be addressed before the tool's output is published from real stagenet inputs.
- **Earlier residuals are unchanged.** These are: the stdlib, `/etc` and `/usr` were unpinned beyond the five tools; cgroup delegation was inherited; the private `/dev` tmpfs was writable; the subject could tamper with its own capture fds; and the hostile matrix is unwritten.
- **ROADMAP formatting.** The diff adds a double blank line, which is cosmetic.

**Scope of this approval:** the exact package above, published as an ordinary offline helper with a historical normal result. It grants no execution admission, target or native acceptance, financial acceptance, semantic proof, or parent-exit closure.
