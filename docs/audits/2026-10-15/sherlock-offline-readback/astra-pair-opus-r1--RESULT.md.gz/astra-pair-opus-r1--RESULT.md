# Opus security review: Astra step and export candidates (source-only)

**Verdict: APPROVE, source-only, security scope only.** Both candidates are approved as source. This is not result acceptance. Nothing was executed, and no B/U/M/MC/SP/G exit or target qualification follows.

## Scope

I reviewed the pasted bodies of:
- `sherlock_step/mod.rs` and `normal_tests.rs`
- the step-slice README, fixture JSON and `.ui` files
- `main.k`, `reference_types.rs`, `kProfileMachine.qnt`, and the excerpts from `Builder::public`, `lib.rs` and `prepare.rs`
- `offline.py`, `test_offline.py`, all five stagenet fixtures, and the historical artifact, target, `.mori` file and readback consumed by those tests

I did not verify file hashes or the K digest, and I ran no tools. Muse keeps independent nonsecurity scope.

## Step candidate findings

1. **The relation is complete for the stated slice.** I derived every constraint by hand. In both rules, all 11 after-fields and all 11 before-fields are fully determined by the header and the opposite state. The K side conditions are all enforced:
   - **Rule 102 needs F>0.** It follows from `before.remaining = after.remaining + 1`, with both values ranged to 128 bits.
   - **`uiValid(V)`** is enforced by the 128-bit range for UInt and the 1-bit range for Bool.
   - **Empty stack** is enforced by frame_count = depth = 0 on both sides.
   - **`<out>` Pending** is constrained before each step.
   - **Rule 80 has no fuel predicate**, which matches K and Quint `advance`.
   - **No field wrap.** Sums are below 2^129, far under the BLS12-381 scalar modulus. A wrap attempt with `before.remaining = 2^128` fails the range check.

   I found no missing constraint within the stated slice.

2. **The K line anchors match the pasted `main.k`.** Startup is at line 74, publication at 80, error at 82, exhaustion at 84, literal evaluation at 102–104 and invalid literal at 105. I did not verify these against the K digest.

3. **Cross-relation replay is closed inside the circuit.** `rule`, `scalar_kind`, `layout` and `profile` are public inputs equated to emitted constants. A proof under one relation therefore cannot be presented with another rule or kind label. Verifiers must still pin the exact IR/key for each of the four (kind, rule) relations; that is a consumer obligation.

4. **Public exposure is total, as documented.** All 30 fields go through PublicInput, range check, and `Impact(guard=1)`, which reuses the existing builder pattern. `Output` repeats already-public after-state values, which is harmless.

   `layout=1` and `profile=1` are integer conventions. They are not bound to `K_SOURCE_SHA256`, and there is no program or source digest. Within this domain, the header fully determines the one-literal program, so this is not a soundness gap here. Binding the digest is required before any wider domain (future work, not blocking).

5. **Steps are not chained.** Each transition is a separate statement. Linking EvalLiteral's after-state to PublishReturn's before-state is an equality the verifier must check across 11 public fields. Nothing aggregates them. Consumers must not treat two individual proofs as a trace proof.

6. **The adapter is not a validity check.** `encode_public_inputs` only serializes and checks representability. Its doc comment says so. A successful encode must never be treated as transition success; this is correctly stated, and the reminder is for consumers.

7. **Test limitation.** All five normal tests check topology: that expected equalities are present and fixture rows encode correctly. None checks that the encoded rows actually satisfy the emitted constraints, and none is a hostile test.

   The hostile matrix below is owned by Opus and is unwritten and unrun. My analysis predicts every case is rejected:
   - charge skip
   - substituted return value
   - Bool payload of 2
   - fuel wrap
   - mutated stack_limit or initial_fuel
   - publish from a Done state
   - mislabelled rule or kind
   - remaining greater than initial

   Executing them needs either SDK check (blocked) or a separately admitted host constraint evaluator.

8. **Compile and SDK-acceptance assumptions are unverified. Each fails closed.**
   - `version: Default::default()` must equal the pinned v3.0 version. It should be replaced by the exact expression the existing builder uses.
   - The `%sherlock.<dotted>` identifiers have not been tested against ZKIR serialization or parsing.
   - The code assumes `Fr: From<u128>`, the ConstrainBits `bits` type, and `PartialEq`/`Debug` on `IrSource`, `Instruction`, `Operand` and `IrType`, which the tests need.

   Test access to the private `literal_payload` field and `STATE_FIELDS` from the child module is legal.

9. **The execution blocker is unchanged.** Cached `mori_core` rlibs show no Sherlock API. I select no shim and propose no broad Cargo command. The old backend-metadata SDK-macro terminal is preserved.

## Export candidate findings

10. **Code scope matches the claims.** The only imports are `argparse`, `copy`, `hashlib`, `json`, `pathlib`, `typing` and `unittest`. There is no subprocess, socket, ctypes, dynamic import, environment read or write path.
    - JSON parsing rejects duplicate keys and NaN/Infinity.
    - Comparison is exact by type, so `bool` ≠ `int` and there is no numeric coercion.
    - Arrays are compared in order. Missing and null members are reported distinctly.

11. **The 16 tests match the fixtures, traced by hand:**
    - The settle selection and its order (transfer, fee, liability, state, emit).
    - The target equals the artifact's target, so there are no missing fields.
    - An empty target yields all seven missing fields.
    - The pure-case path `/execution/effects/0/value/value` is correct under sorted-key traversal.
    - The historical preserved-frame scope, ledger_apply label and present-zero duty all match.

12. **Exposure risk (required correction before any non-fixture use).** `prepare` echoes the full `external_configuration` file to stdout. A real stagenet configuration could hold endpoint credentials.
    - Minimal fix: record only `files.external_configuration` (path, SHA-256, size) and drop the echoed content.
    - This does not block the current tests, which never pass that argument.

13. **Low severity:**
    - `path.resolve()` writes absolute paths such as `/home/charl/...` into the output. Prefer repo-relative paths.
    - A `compare` exit code of 0 could be misread as acceptance. Add an explicit `"acceptance": "none"` field.
    - Hostile JSON can raise uncaught `RecursionError`, `AttributeError` or `TypeError`. These produce a traceback and fail closed.

14. **Nonsecurity, for Muse.** The "first difference" follows sorted key order, not execution order. In the pure case it reports effects before pre-state.

## Test-command classification

The command `python3 -B -m unittest discover -s models/sherlock/stagenet -p test_offline.py -v` invokes **no** blocked SDK, model, native, Cargo, Lake, K, Quint, network or key path.

- **Behaviour.** It runs as one stdlib-only process and only reads files: the five stagenet fixtures, the three `task4-native` files (the `.mori` source is hashed, never parsed) and the historical `readback.json`. It writes only stdout and stderr; `-B` prevents bytecode caches.
- **Size.** It reads under 200 KiB in total and starts no threads, so it is far inside the 90s / 30s / 4GiB / swap0 / 256-task / 16MiB ceiling.
- **Classification.** It is eligible ordinary stdlib/file-only work for Root to separately bound, classify and admit. This review grants no authority.
- **Suggested conditions for Root:**
  - Confirm the start directory and the current directory contain no stdlib-shadowing `.py` files.
  - Pin the hashes of the files read.
  - Add `-I` (`python3 -I -B -m unittest ...`). Discover still inserts the start directory itself, and `-I` drops PYTHONPATH and the user site.

## Blockers and minimal corrections

- **No security blocker** for either candidate's source approval.
- **Required before the export tool is used beyond fixtures:** finding 12.
- **Required before SDK admission of the step:** findings 4 (digest binding before scope widens) and 8 (version and identifier verification).
- **Required before any security result claim:** the finding 7 hostile tests and a constraint-satisfaction check.

## Limitations

This review covers source and analysis only. It produces no execution result, no test result, no SDK constraint result, no theorem, and no Clean or Lean correspondence. Every listed gap stays open: full B, recursion, digest binding, the native/ledger adapter, and target observation. Fresh Muse nonsecurity review remains pending.
