**APPROVE SCOPED SOURCE/RESULTS/PUBLICATION — no concrete blockers found.**

This review is based on the supplied candidate sources and captured records. I ran no tools and make no new security judgment; security remains exclusively within the designated Opus scope.

### Source coherence

- [image_reference.rs](/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-reference-20261015/source-origin-integration-final-muse/crates/mori-core/src/sherlock/image_reference.rs) maintains the central invariant: `frames` and `frame_origins` remain equal in length and aligned top-first. Push inserts both together only on success; frame consumption removes both together; Let-to-Scope and Left-to-Right replacements preserve the existing owner.
- A generated `Eval` adopts its actual expression ID. Non-Eval intermediate controls retain the causal occurrence: calls through Invoke/Enter/Bound/Push, match evaluation through Cases/CaseResult/Scope, and primitive evaluation through PrimitiveResult.
- Push failure leaves the frame vector, frame-origin vector, and environment unchanged and proceeds to error publication under the originating construct.
- Return handling restores the top frame’s scheduling occurrence. Consuming Scope, Match, Args, Right, Unary, Return, and If branches remove or replace frames consistently. If and return-type failures retain their frames while moving the current origin to the interacting frame owner before error publication, which is coherent with the stated frame-restoration model.
- Match arm selection, saved-environment restoration, argument accumulation, lexical scope restoration, and named-call return propagation preserve both the frozen A state and the aligned causal owners.
- [helper_call_adapter.rs](/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-reference-20261015/source-origin-integration-final-muse/crates/mori-core/src/sherlock/helper_call_adapter.rs) `CallContext::from_image_machine` obtains the image, snapshot, current occurrence, and saved frame owners from the same `ImageMachine`. It does not accept a caller-selected occurrence or infer one from names or values. The retained frame owners remain available throughout helper stepping.
- The public surface remains unchanged: the image machine, helper adapter, and source-origin tests are private `cfg(test)` components and introduce no public runtime export.

### New-test expectations

I independently checked the three new source-first cases against the written programs and K-A boundaries:

- The two distinct same-name call sites retain separate entry paths at cursors 3 and 11, with call, body, restored-call, second-call, and publication states following cursors 8, 9, 16, 17, and 19.
- The recursive occurrence is the same function-body path at cursors 28 and 52, while the distinct invocation cursors and saved caller owners remain distinguishable; base-case return and the three caller restorations follow cursors 67 through 70.
- The subtraction-underflow case retains the binary owner and pending Let frame through PrimitiveResult and free error publication at cursors 7 through 9.

### Results and publication

The captured checker record reports exact oracle transcription, successful compilation, **82 passing checks**, eight frozen programs, and all **216 literal fuel prefixes**, with empty stderr and unchanged membership. The source membership covers the stated 26 Rust modules and checker.

The README, correctness-loop entry, binding record, and roadmap wording remain properly scoped: they claim only private host source-origin metadata and normal comparisons, while expressly leaving image/digest binding, full B adoption, circuit/native correspondence, and roadmap acceptance open.

END_SOURCE_ORIGIN_INTEGRATION_FINAL_MUSE_REVIEW
