**Verdict: APPROVE the merged `lib.rs` as a correct, reviewable union for a merge commit.** No code changes are required. Two record-wording corrections are listed below. This review authorizes no execution and leaves the metadata-walk and capsule gates where they were.

**Union check**
- Against the old draft, the merged file only inserts the parent's two lines (`#[path = "sherlock/source_adapter.rs"]` and `pub mod sherlock_source;`).
- Against the parent, it only inserts the draft block (2 comment lines plus 5 × `#[cfg(test)]`/`#[path]`/`mod` triples).
- Nothing else differs. The re-exports, the `stage`/`replay`/`runtime`/`source_sponsor` items and their order are identical to both sides.

**Attribute attachment**
- Each `#[cfg(test)] #[path]` pair attaches only to the next `mod …;` item, and each item ends with `;`.
- The parent's `#[path]` follows `mod sherlock_draft_image_tests;`, so it attaches only to `pub mod sherlock_source`. That module is not test-gated, which matches the parent.
- This was the one real risk in this merge (a `cfg(test)` silently gating the public adapter). It does not occur.

**Path resolution**
- All six `#[path]` values resolve relative to `src/` and point at `src/sherlock/*.rs`. These match the parent and the old draft.
- Sherlock's `mod.rs` declares none of `draft_*` or `source_adapter`, so no file is included twice. The comment about staying "outside Sherlock's standalone Std graph" still holds for both blocks.

**Visibility**
- The draft modules stay private and `cfg(test)`-only.
- `sherlock_source` stays `pub` at the crate root, unchanged from the parent.
- No names collide (`sherlock_source` vs `sherlock_draft*`).
- A non-test `sherlock_source` cannot depend on `cfg(test)` draft modules, and the parent never referenced them. Draft references to `sherlock_source` are absent per the membership record.
- Item order is semantically irrelevant here.

**Required (record accuracy, not code)**
1. **"ALL 18 private cfg-test path aliases" is wrong as worded.** `lib.rs` contains **5** aliases (15 attribute/item lines, or 17–18 with the comments and blank line). Restate it as a count of 5 aliases, or as an explicit line count. Otherwise a later reviewer cannot reconcile the number.
2. **Scope `compiled_harness_modules_changed: false` precisely.**
   - It is true for the draft harness modules.
   - However, the `mori-core` test compilation unit now also builds `sherlock_source`, including any `#[cfg(test)]` items inside `source_adapter.rs`.
   - The membership record should state that the crate test build gained the parent adapter files. This matters for the future exact-subject freeze, even if the 11 draft tests are later selected by filter.

**Optional**
- Add a blank line between the draft block and `#[path = "sherlock/source_adapter.rs"]` so the draft comment does not visually appear to cover the adapter.
- Alternatively, place the parent's two lines directly after `pub mod sherlock;`, which reproduces the parent layout. That makes the merge diff against the parent a pure insertion.

**Not verified by me (no tools)**
- The SHA-256 values of all three files and the JSON.
- That the merge commit's parents are exactly `c20468f2` and `bf15f59c…`.
- The contents of `source_adapter.rs`, including whether it declares child `mod`s that would resolve under `src/sherlock/`. This one was already established by the parent merge.
- Any compile or test outcome. All 11 tests remain unrun, and the `9ff626b2…` subject stays invalidated and must not be run.

END_FRONTEND_PARENT71_SOURCE_REVIEW
