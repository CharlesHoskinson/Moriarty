**Verdict: APPROVE — source-integration only.** The merged `lib.rs` is a clean additive union and is suitable to commit as a reviewable merge commit on the draft branch. This is not approval to merge PR 72, run tests, or execute any subject.

**Concrete findings**

- Every draft declaration from old `lib.rs` is retained verbatim: the explanatory comment and all `#[cfg(test)] #[path = "sherlock/draft_*.rs"] mod sherlock_draft*;` blocks keep their private visibility, test gating, paths, names, and order. No draft capability is widened to non-test or public scope.
- The parent capability is retained verbatim and correctly attached: `#[path = "sherlock/source_adapter.rs"] pub mod sherlock_source;` is unconditional and public, exactly as in parent. Its `#[path]` attribute attaches only to `sherlock_source`; the preceding `#[cfg(test)]` blocks are each closed by their own `mod ...;`, so no test gating leaks onto it, and none of its visibility leaks onto the draft modules.
- There is no name collision or namespace wiring change: `sherlock_source` is a distinct crate-root module, separate from `pub mod sherlock;` and from the private `sherlock_draft*` modules. The shown `sherlock/mod.rs` does not declare `source_adapter`, so the parent module stays outside Sherlock's standalone module graph and is not newly referenced by the draft harness.
- All shared declarations and the trailing `pub use` block are identical across old, parent, and merged files. The only delta from the draft is the two-line parent insertion; the only delta from parent is the retained draft test block. This matches the membership comparison: sole pre-existing input change is `lib.rs` `7d02055c…` → `2f7ea832…`, compiled harness modules unchanged.

**Required before relying on this beyond committing the merge**

- None for the union itself. No attribute, visibility, or wiring correction is needed.

**Optional**

- None. Reordering for stylistic grouping would only churn the exact merged SHA and should be avoided.

**Preserved boundaries**

All 11 tests remain UNRUN with no target or native claim. Candidate `9ff626b2…` is invalidated by this `lib.rs` change and must not be run; no failed-subject rerun or counter reset is implied. A new exact subject may be frozen only after the pending owner gate approach, and this review does not waive the failed metadata walk or new capsule eligibility. Native0 and the full Moriarty roadmap remain open. Security review remains reserved to Opus; this is a functional/API source-integration review only.

END_FRONTEND_PARENT71_SOURCE_REVIEW
