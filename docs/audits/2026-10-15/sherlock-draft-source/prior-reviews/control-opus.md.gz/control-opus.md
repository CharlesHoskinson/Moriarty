# R4 frontend control/closure review: fresh, non-author, owner-scope

## Verdict

**APPROVE, conditional ordinary classification only.**

- I found **no design blocker and no source blocker** in the R4 control.
- **Execution is not authorized.** A separate formal root admission is still required, with a single shot and no retry.
- My approval covers only the exact argv, the view, and the staged closure below. It holds only if every immediate fact in §5 passes in the same pre-shot sequence.
- Four findings are new from this review (§3 F1–F4). None of them requires an argv change. Each becomes a required fact or a recorded residual.

## 1. Literal argv against the design

**Item by item:** I compared every element from `"--ro-bind","/usr","/usr"` through `"--remount-ro","/"` in PROPOSED-ARGV.json against design §2. They match exactly:

- the order;
- both mask pairs;
- the four `--symlink` frozen literals (`usr/bin`, `usr/sbin`, `usr/lib`, `usr/lib64`, equal to LITERAL-CONTROL-BINDING);
- the 7 bind sources;
- the staged source mounted at the original deps target;
- `--dir /tmp`;
- the scratch path, which is identical in both bind operands and in `TMPDIR`;
- `--dev`, `--proc`, and the final `--remount-ro /`.

**Unit name:** `sherlock-draft-frontend-eleven-r4-20261015`.

**Unchanged in shape:**
- resources and timeout;
- `--unshare-net/pid`, `--new-session`, `--die-with-parent`;
- `--unsetenv` ×2 and `--chdir`;
- the bash `ulimit` wrapper;
- `python3 -I -B`;
- the checker path and every checker argument.

**Mount semantics are sound:**
- bwrap always uses a tmpfs root, so only the explicitly bound trees exist.
- `--remount-ro /` is non-recursive, so scratch stays writable.
- No bind target is nested inside another bind target.
- The masks come after `/usr`, so they cover the three WSL submounts carried by the recursive `/usr` bind.
- Bind mounts are nosuid and bwrap sets NO_NEW_PRIVS, so the setuid binaries in `/usr` and group 27 (sudo) are inert.

**What I could not verify (no tools):**
- the sha256 values `25dacc4f…`, `4230f6…` and `d4e3d13e…`;
- byte-identity of the non-view elements against R3 `0e6905…`, whose bytes were not supplied.

Root must confirm these by hash.

## 2. Facts judged against the gates (as of capture `…778.86–784.54`)

| Gate | Fact | Judgment |
|---|---|---|
| **V1** | All 7 bind sources are S_IFDIR with `realpath == path`. | PASS for the sources. **Missing:** the mask targets' lstat, and an observation of the host `readlink` values (the frozen literals are not observations). |
| **V2** | Scratch is a 0700 directory, uid 1000, with 0 entries. | PASS at capture time. Must be re-checked immediately before the shot. |
| **V3** | The only mountpoints under bound roots are the 2 WSL dirs and the modules dir, all three covered by masks. `/nix/store` is not a mountpoint. | PASS. |
| **V4** | `path_listener_rows: []`. | PASS as recorded. The filter definition is not recorded; see §5. |
| **V5** | One invocation, 5.67 s. All 7 roots have root-complete markers, `socket_count` 0, and the masks were pruned. | PASS. |
| **§4 EACCES** | 5 directories, all uid 0: `/etc/ssl/private`, `/etc/credstore`, `/etc/credstore.encrypted`, `/usr/local/lib/ollama/cuda_v13`, and `/etc/polkit-1/rules.d` (gid 987). Groups are `27 100 986 1000 1001`, so 987 is not among them. Effective `X_OK` is false. Walker uid/gid are 1000×4 and CapEff/Prm/Inh/Amb are all 0. | **UNREACHABLE-DAC, not STOP.** Stronger than the owner rule requires: inside bwrap's user namespace, uid 0 and gid 987 are unmapped, so even residual namespace capabilities could not override DAC on these inodes. |
| **V6** | 91 members. I compared all 91 against R3 DEPENDENCY-MEMBERSHIP (minus rustc) by hash prefix: each matched, and the set is exactly 42×(rlib+rmeta), 5 R1′ `.so`, plus the `serde_derive` and `thiserror_impl` `.so`. Every member has `cmp_equal`. Staged inodes (5463661–5463751) all differ from source inodes on the same device, so they are copies, not hardlinks. The directory is 0555, uid 1000. No `libmidnight*` names. | PASS on the supplied facts. **Missing:** per-member lstat and listing equality (§5). Full-hash equality is root's binding job. |

## 3. New findings from this review

These are not R4 regressions. All of them also existed under R3.

**F1. Inherited descriptors bypass the path-socket model.**
- bwrap passes through every fd that is not CLOEXEC.
- If the launcher passes an AF_UNIX socket, a directory fd, or a tty, the subject reaches it regardless of the view.
- This is a launcher property and needs no argv change.
- It becomes required fact 7.

**F2. The IPC namespace is not unshared.**
- The argv has no `--unshare-ipc`.
- POSIX shm is isolated, because `/dev/shm` sits on bwrap's private `/dev`.
- Host SysV shm/msg/sem objects and POSIX message queues are shared with the host. That is the same class of host-object reachability the allow-list removes for sockets.
- **Ruling:** a start-time gate, required fact 8. The remedy on STOP is `--unshare-ipc` in a re-frozen argv with a new review, not an edit in place.

**F3. binfmt_misc on WSL.**
- A handler registered with the `F` flag (typically WSLInterop → `/init`) executes an interpreter outside the view when the subject runs MZ bytes it wrote to scratch. Scratch is not noexec.
- Reaching Windows from there requires the interop unix socket under `/run/WSL`, which is absent from the view (and `WSL_INTEROP` is not in the environment), or hv_sock.
- **Ruling:** WSLInterop folds into the retained vsock/hv_sock residual. Any other `F` handler whose interpreter lies outside the view means STOP (required fact 9).

**F4. SOURCE-MEMBERSHIP omits the parent adapter.**
- The 55 members contain no `src/sherlock/source_adapter.rs`.
- The current `lib.rs` (`2f7ea832…`) declares that file, and the checker's `snapshot()` hashes every `src/sherlock/**/*.rs`.
- Both parent71 reviews say `mod.rs` does not reach the adapter, so it is not compiled by this harness. The gap is in the binding record, not a security exposure.
- It still must be reconciled before admission (required fact 10). This was also the parent71 Opus required item #2.

**Record corrections, not blockers:**
- **"Scratch is the only writable path" is inaccurate.** bwrap's `--dev` tmpfs (`/dev`, `/dev/shm`, `/dev/pts`) is outside the non-recursive `--remount-ro /`. It is private to the sandbox, ephemeral, charged to the memory cgroup, and unchanged from R3.
- **The same-uid TOCTOU locus is wider than recorded.** It is every directory in the view that uid 1000 or its groups can write, not only the uid-1000-owned trees. It also includes host mounts that propagate into the bound trees after start.

## 4. Muse premises C4–C7

- **C4 is retained.**
  - Python `tempfile` honours `TMPDIR` under `-I`, because `-I` ignores only `PYTHON*` variables.
  - rustc uses `env::temp_dir` and gcc/collect2 use `TMPDIR`.
  - `/tmp` is empty and read-only. The R3 parity holds.
- **C5 (view completeness) is a liveness premise only.**
  - On static analysis the loader, interpreter, stdlib, libcrypto, `/etc/alternatives/cc`, gcc/collect2/ld/crt, the gcc-ld/rust-lld path in the toolchain, and `/proc/self/exe` sysroot discovery all resolve inside the view.
  - Anything missing fails closed and consumes the shot. It cannot widen authority.
- **C6 is a liveness premise only.**
  - The 5 R1′ macros' host build deps (syn, quote, proc_macro2, unicode_ident, synstructure) are already staged.
  - `serde_derive` and `thiserror_impl` are outside the lexer graph and named by no crate, so they are never located. The absence of their own deps is irrelevant.
  - A missing crate means E0463, which fails closed. Non-members are not in the view, so nothing can be substituted for them.
  - The sysroot candidates stay under G-R1b.
- **C7 is confirmed from checker `b90929…`.**
  - `subprocess.run` is called only for the rustc and test-binary phases. There is no `git` and no use of `HOME`.
  - The worktree `.git` gitlink target is not in the view, so git would fail anyway.
  - `-I` includes `-P`, so the checker's own directory is not on `sys.path`.

## 5. Immediate facts required before any separately admitted shot

Run these in the same pre-shot sequence; any failure means STOP. The capture above is predicate and feasibility evidence, not the start gate.

1. **V1, completed:**
   - lstat `/usr/lib/wsl` and `/usr/lib/modules/6.18.33.2-microsoft-standard-WSL2`: each must be S_IFDIR and not a symlink;
   - observe host `readlink` for `/bin`, `/sbin`, `/lib`, `/lib64`, byte-equal to the frozen literals;
   - repeat the 7-source lstat/realpath check.
2. **Repeat V3, V4 and V5 in one invocation within the 90 s bound, with these rules:**
   - Same rules as before.
   - Mountinfo sha recorded.
   - Record the V4 filter definition: `/proc/net/unix` paths at or under the bind **source** paths, with a path-boundary match, excluding paths under the masks.
   - EACCES classified by §4.
   - Any new uid-1000 EACCES, or any socket, means STOP.
3. **V2:** scratch is fresh, 0700, uid 1000, empty.
4. **V6:**
   - The staged name set equals exactly the 91 members.
   - Per member: S_IFREG, not a symlink, uid 1000, mode 0444, `nlink == 1`.
   - The directory is 0555.
   - Full sha256 pre-hashes equal STAGING-PRE and R3 membership.
   - G-R1b sysroot prefix check.
   - Post-hashes on the staged files.
5. **V7/S6 in full:**
   - tool hashes, including `systemd-run`, `timeout`, `bwrap` (record its mode and whether it is setuid), `bash` and `python3`;
   - rustc, the compiler libraries, R2 `bin/**`, `cc`/`ld`/crt;
   - delegated cgroup controllers;
   - unit-not-found;
   - the fixed environment with no ambient `LD_*`, `RUST*` or `CARGO*`.
6. **Credentials:** the launcher's Uid, Gid, Groups and Cap* tuple equals the walker's tuple. The argv contains no `--uid`, `--gid` or `--cap-add`. This is what lets the owner EACCES rule apply on both sides.
7. **F1, inherited fds:**
   - The launcher passes exactly fds 0, 1 and 2 without CLOEXEC.
   - fd 0 is `/dev/null`; fds 1 and 2 are pipes or regular files under root's capture.
   - None of them is a socket, a tty or a directory.
8. **F2, host IPC:**
   - Record `/proc/sysvipc/{shm,msg,sem}` and the host `/dev/mqueue` listing.
   - STOP if any object grants access to uid 1000, to groups {27, 100, 986, 1000, 1001}, or to other.
9. **F3, binfmt_misc:** record every handler's status, flags and interpreter. Apply the F3 ruling.
10. **F4, source membership:**
    - Record the checker's exact snapshot set (the same rglob rule).
    - It must equal SOURCE-MEMBERSHIP plus the adapter file(s), with their hashes.
    - Confirm that bound `mod.rs` and the bound files do not reach them.
    - If `source_adapter.rs` is absent from disk, record that the merged Core crate is incomplete. That is a nonsecurity issue outside this harness.
11. **Argv, environment and design hashes:**
    - `25dacc4f…`, `4230f6…` and `d4e3d13e…` are confirmed.
    - The executed argv is exactly the JSON elements, with no shell re-splitting.

## 6. Retained limits (owner-accepted, unchanged unless noted)

**Residuals:**
- the stdout/report exfiltration channel, now limited to the view's readable content;
- `.pth` and `sitecustomize` files under `/usr`;
- vsock/hv_sock, now including WSLInterop (F3);
- unobserved loader behaviour;
- O3;
- start-time-only TOCTOU, with the wider locus from §3.

**Provenance:** correspondence between cache, source and encoded metadata is UNPROVEN, and the full encoded metadata was not decoded.

**Coverage:** a pass supports the 11-case predicate only. Core `lib.rs`, Cargo integration and the 86 old tests are untested.

**Caps and status:** the 90 s / 30 s, 4G / swap 0 / tasks 256 / 16 MiB caps are unchanged. Native authority is 0. The R3 candidate and its sources and captures are immutable and UNRUN. There is no failed-subject retry. The refused preflight code stays refused and is not regenerated. Backend stage 2 is TERMINAL. The Lean consumer is out of scope.

**Optional (each needs a re-freeze and a new review if adopted):** `--unshare-ipc`, which would turn F2 from a gate into a property.

```
END_R4_FRONTEND_EXACT_CONTROL_REVIEW_OPUS
verdict: APPROVE (conditional ordinary classification); no design/source blocker
argv: view block literally equal to design §2; hashes/R3 byte-identity root-verified only
facts: V3/V4/V5 PASS at capture; 5 EACCES = UNREACHABLE-DAC (uid0/gid987 unmapped in userns);
       V6 91 = exact R3 set by prefix, distinct-inode copies
new: F1 inherited fds; F2 host IPC ns (gate); F3 binfmt F-flag (WSLInterop -> hv_sock residual);
     F4 SOURCE-MEMBERSHIP lacks source_adapter.rs (reconcile)
corrections: /dev tmpfs writable (private); TOCTOU locus = uid1000/group-writable dirs + propagation
C4 retained; C5/C6 fail-closed liveness only; C7 confirmed from checker source
required: §5 items 1–11 in one pre-shot sequence; any failure = STOP, new classification
execution_authorized: NO; native 0; caps unchanged; R3 UNRUN immutable; no retry
END
```
