# Security owner vote (challenge): RATIFIED, conditionally

This is my written ratification of the exact-join target rule and of this metadata-only credential-identity criterion, as proposed in `PROPOSED-OWNER-RATIFICATION.json`. It has the clarifications listed below. It is one substantive Opus owner vote. Root must still record a second agreeing Opus vote before the decision is final. Root remains responsible for every fresh immediate fact and for formal admission.

## Rulings

1. **Target rule.** Acceptance requires exactly one exact-join match: same userns, same pidns, and last NSpid equal to the self PID. Namespace-only matching does not count. The bwrap pid-1 reaper is expected to share the userns and pidns, so the namespace-only count is informational. Zero exact matches is STOP, even if the reader exits 0. More than one exact match is also STOP. No heuristic may be used to pick a target.

2. **Stability rule.** I ratify comparing PID and starttime, not the full stat string. Starttime is field 22, parsed from the tokens after the last `)`. Full stat text includes volatile fields (state, utime, vsize, and others), so requiring string equality would cause spurious STOPs and add no binding strength. While the namespace is live, PID plus starttime identifies the process instance. The following must also hold:
   - userns and pidns are equal before and after, and equal the self-record;
   - NSpid has at least 2 elements, `NSpid[0] == host_pid`, and `NSpid[-1] == self pid`.

3. **Clock bracket.** Starttime must satisfy floor(launch) ≤ starttime ≤ floor(readiness), in CLOCK_BOOTTIME ticks using the recorded SC_CLK_TCK. The floor-on-both-ends conversion matches the kernel's `nsec_to_clock_t`.

4. **Completion.** The reader and the subject chain must both exit 0. Timeout is not accepted. Any traceback, nonempty stderr, missing observation file, missing output or read error is STOP. This is stricter than the challenge review's "or timeout as frozen" wording. The stricter rule governs.

5. **Identity.** The init-read maps are authoritative, because the kernel composes them through the whole nested-userns chain. The self-map `1000 0 1` is informational; it is consistent with bwrap's nested userns. The target must satisfy all of these, read from the init userns:
   - Uid and Gid are 1000 ×4;
   - Groups are exactly `27 100 986 1000 1001`;
   - CapInh, CapPrm, CapEff and CapAmb are 0;
   - NNP is 1;
   - setgroups is `deny`.

   The self-side pattern must be 1000 plus four entries of 65534. CapBnd is informational.

6. **Environment.** `INVOCATION_ID` is informational: its value is neither compared nor emitted. An absent `_` is benign. The original forbidden keys remain STOP.

## Clarifications that are part of this ratification

These are not new code. They are criterion wording that root must satisfy.

- **"Initial" reader pidns.** On this WSL2 host, the host pidns is `pid:[4026532221]`, not the kernel's canonical initial pidns. "Reader pidns initial" therefore means: equal to the value the launcher recorded before the exec chain, and equal to the immediate host fact. It does not mean a literal canonical inode. The reader's userns must be `user:[4026531837]`.
- **Explicit exclusions.** The subject's self userns must not be `4026531837`, and the subject's pidns must not equal the reader's pidns. The map rule already implies both, but they are stated so they are checked directly.
- **Unbound reader input.** `HOST-READER.py` loads `PROPOSED-ENVIRONMENT.json` from the parent directory at runtime and passes it to the `systemctl` subprocess. Root must:
  - hash-bind that exact file as an immediate fact;
  - confirm it is the frozen 7-variable environment;
  - confirm it contains no loader or `SYSTEMD_*` injection keys.

  If the file is unbound or differs, the result is STOP. I am treating this as a condition, not a block, because the exact join verifies the target's identity independently of which cgroup the query returns. The "T ∈ this unit's `cgroup.procs`" check does depend on it.
- **Observation file.** `HOST-READER-OBSERVATION.json` uses non-exclusive `write_text`. Root must verify it is absent immediately before launch, and must verify that exactly one reader pass ran.
- **Scratch directory.** Scratch must be empty before the run and empty after it.

## Not waived

Nothing in this ratification waives, alters or satisfies any of the following:

- The failed R2 result. It stays spent and immutable, with its map criterion failed, and is not retried.
- Any prior refusal, including the old preflight refusal. There is no patch.
- Fresh V5. It must record the walker's `ns/user` and re-derive all five EACCES facts. Any EACCES under differing credentials is STOP.
- P1–P5 and V1–V7.
- The eleven Rust tests and the Lean subjects. They remain UNRUN, unadmitted and unconsumed.
- Compilation and native authority. Native authority stays 0.
- The inheritance inference. That the eleven-test processes inherit these credentials through the identical prefix remains an inference, and this observation does not prove it.

The frozen limits are unchanged:
- subject 90 s outer, 20 s hold;
- reader 20 s;
- MemoryMax 4G, MemorySwapMax 0, TasksMax 256;
- file ulimit 16 MiB.

There is one run with no retry and no change to caps or limits.

## Residual risk accepted

- PTRACE_MODE_READ on `ns/*` assumes the target has the same kuid and is dumpable. If that fails, the read errors and the result is STOP.
- The race between the 20 s hold and the reader can waste the run, but it cannot produce a false accept.

```
OWNER_VOTE: RATIFIED (challenge owner; one of two required Opus votes)
scope: credential-identity metadata only; native 0; compiler/eleven/Lean unadmitted
target: exactly-one exact join; ns-only informational; zero/multiple = STOP
stability: PID+starttime(f22) before==after; ns before==after==self; NSpid[0]==host_pid, [-1]==selfpid, len>=2; boottime floor bracket
completion: reader+subject exit 0 only; any stderr/traceback/missing output = STOP
added_conditions: PROPOSED-ENVIRONMENT.json hash-bound; reader pidns == launcher record == pid:[4026532221]; observation absent pre-run; scratch empty pre+post
not_waived: R2 failure, prior refusals, fresh V5+5 EACCES, eleven-test gates, no retry
END
```
