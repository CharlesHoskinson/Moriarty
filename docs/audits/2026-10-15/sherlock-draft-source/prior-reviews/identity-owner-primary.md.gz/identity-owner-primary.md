# Security owner vote: RATIFIED (conditional, metadata only)

This is my written ratification, as designated Opus security owner, of the **exact-join target rule** and of **this criterion** as stated in `PROPOSED-OWNER-RATIFICATION.json`, plus the clarifications below. The clarifications are criterion text, not code or patch requests. Root remains responsible for all fresh immediate facts and for formal admission. This vote authorizes nothing beyond one metadata observation.

## Ruling on the target rule

- **Exact join is authoritative.** The target T is the single record whose userns, pidns and last NSpid all match the self-record, and there must be exactly one.
- **Namespace-only count is informational.** It is expected to be 2, because bwrap's pid-1 reaper shares the namespaces. It must still contain T.
- **No other selection is allowed.** No heuristic or fallback may pick a target.

This binds the credentialed process itself, so it is stricter than the namespace-only wording it replaces.

## Ruling on stability

- **PID plus starttime is the security property.** PID and stat field 22 starttime, equal before and after, are authoritative.
- **Full-stat equality is not required.** The volatile fields add no binding strength. Any difference may be recorded as informational.
- **Why this is enough.** A live (pidns inode, pid, starttime) triple names one thread group. The starttime bracket excludes any process created after readiness, which covers both PID reuse and namespace-inode reuse.

## Clarifications ratified as part of the criterion

Each item must hold; otherwise STOP.

1. **Starttime parsing.** Starttime is taken from the text after the last `)` in `/proc/<pid>/stat`. The bracket is inclusive: `floor(launch_ticks) ≤ starttime ≤ floor(readiness_ticks)`.
   - The launch reading is taken before root spawns `systemd-run`.
   - Both readings use the same `SC_CLK_TCK`.
   - The root clock records and the reader must be in the same time namespace. bwrap does not unshare it, and the launcher record must show this.
2. **Reader pidns.** Here, "initial pidns" means the recorded WSL distro pidns `pid:[4026532221]`, not the kernel's 4026531836.
   - The reader's own NSpid must be a single element equal to its own PID. This shows the procfs pidns is the reader's pidns, so `host_pid` and NSpid[0] are interpreted in the same namespace.
   - The reader's userns must be `user:[4026531837]`.
3. **Subject namespaces are distinct from the reader's.**
   - The self-reported `user_namespace` is not `user:[4026531837]`.
   - The self-reported `pid_namespace` is not `pid:[4026532221]`.
   - T's NSpid has at least 2 elements.
4. **Unbound reader input.** `HOST-READER.py` loads `r/PROPOSED-ENVIRONMENT.json` for its `systemctl` subprocess. That file is not covered by `SOURCE-BINDING.json`, and it is not the hashed `READER-ENVIRONMENT.json`.
   - Root must record its sha256 immediately before launch.
   - Root must confirm it is the frozen fixed 7-variable set claimed in the proposal.
   - An unverified or different file is STOP.

   On security impact: a wrong `ControlGroup` can only produce STOP, because the namespace join is unique system-wide. It is still an unbound input and must be bound.
5. **Completion.** I keep the challenge review's requirements:
   - the observation file exists;
   - scratch is empty after the run;
   - the reader's exit 0 is never sufficient alone. An empty `cgroup.procs` with exit 0 is STOP.

   Subject exit 0 only, with no timeout acceptance, is stricter than the challenge allowed. I adopt it.
6. **Credentials, as read from the init userns for T only.**
   - `uid_map` and `gid_map` are each exactly one row `1000 1000 1`.
   - `Uid` and `Gid` are 1000 ×4.
   - `Groups`, as a set, is exactly `27 100 986 1000 1001`.
   - `CapInh`, `CapPrm`, `CapEff` and `CapAmb` are 0.
   - `NoNewPrivs` is 1.
   - `setgroups` is `deny`.

   Informational only: the self-maps `1000 0 1`, CapBnd, the reaper's and other non-T records, and `INVOCATION_ID` (value not compared or emitted). An absent `_` is benign.
7. **Any other failure is STOP.** This covers any traceback, nonempty stderr, read error, more than one exact match, preexisting output, or reader completion after the subject has exited. There is one pass and no retry.

## What this vote does not do

- It does not waive the R2 result. R2 stays spent, immutable and criterion-failed, with no retry.
- It does not lift any prior refusal, including the preflight refusal. There is no patch.
- It does not replace the fresh V5 (walker `ns/user` plus the 5 EACCES re-derivation), P1–P5, V1–V7, or the eleven-test and Lean gates. The eleven Rust tests and the Lean subjects stay UNRUN and unadmitted.
- It does not change the frozen limits: 90 s subject, 20 s hold, 20 s reader, 4G, swap 0, 256 tasks, 16 MiB file ulimit.
- Native authority stays 0, and compiler and native permission are not granted.
- A pass admits only the credential-identity fact for this observation subject. Inheritance by the eleven-test processes remains an inference.

```
OWNER_VOTE: RATIFIED (security owner, Opus 5.5)
scope: metadata-only credential identity; exact-join target rule + this criterion
binding: PID+starttime stable, inclusive boot-tick bracket; full-stat informational
added_immediate_facts: PROPOSED-ENVIRONMENT.json sha256 bound; reader NSpid single==self; reader pidns 4026532221 / userns 4026531837; subject ns distinct; scratch empty after
root_responsible: all fresh facts, hashes, absences, formal admission
not_waived: R2 failed, prior refusals, fresh V5, P/V gates, eleven/Lean UNRUN; native 0; no retry
END
```
