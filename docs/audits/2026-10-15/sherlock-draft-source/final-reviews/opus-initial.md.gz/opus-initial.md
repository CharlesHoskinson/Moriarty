# Opus 5.5 security-owner review of the PR72 draft-source package: **BLOCKED for publication**

This is a fresh non-author review of the exact source, results and publication package. It was done by reading only; I ran no tools. I did not inherit Muse's verdict.

There is no security or correctness blocker in the source or the result. One real blocker remains in the reporting. Once it is corrected, the source and result are approvable within the limitations below.

## Findings

**1. BLOCKER: the final-review placeholders are incomplete, and the README claims they are complete.**
- `REVIEW-BINDING.json` still has status `PENDING_FINAL_EXACT_SOURCE_RESULT_REVIEWS` and contains only the requested roster.
- `CAPTURE-BINDING.json` still has status `…_FINAL_RESULT_REVIEWS_PENDING`.
- The audit README nevertheless says the review binding "records the final independent result reviews and their limitations." That sentence is false for the frozen bytes.
- No acceptance can be inferred from either placeholder.

Minimal correction, applied in this order:
1. Give `CAPTURE-BINDING` a status that does not depend on reviews, for example `ACTUAL_ELEVEN_HOST_CHECKS_CAPTURED`. Review state should live only in `REVIEW-BINDING`, which avoids a circular hash dependency.
2. Recompute the `CAPTURE-BINDING` sha256.
3. Finalize `REVIEW-BINDING` with:
   - the recomputed sha;
   - each reviewer's model, effort, scope and actual verdict (Muse BLOCKED, Opus BLOCKED, plus any later dispositions);
   - the receipt path and the content and stored sha256 of each receipt;
   - retained dissent and limitations.
4. Reword the README sentence to state the recorded outcomes. It must not imply approval.

Root should record a byte diff confirming that only these reporting files changed. If any source byte changes, the capture is invalid.

**2. Disclosure policy, as determined by the security owner.**

*Private repository contents*
- This covers Fenrir code, README, pins, private paths, theorem and integration records.
- These are **never published**. Public records carry scope and a shareable digest only.
- **None are present.** The Fenrir mentions are scope-only.

*Secret credential material*
- This covers tokens, keys, credential files and secret environment values.
- These are **never published**.
- **None are present.** In this package, "host credential" means process uid/gid/capability/namespace metadata, not secrets. `INVOCATION_ID` appears as a key only; its value is not captured.

*Host-only metadata for a run of public source*
- This covers:
  - the `/home/charl/...` paths and username;
  - uid 1000 and groups 27/100/986/1000/1001;
  - capability, NNP and namespace inodes;
  - host PIDs, start ticks and boottime;
  - the WSL kernel string;
  - tool and sysroot hashes;
  - mountinfo and EACCES path lists;
  - the session environment values;
  - the published residuals in the prior control review.
- This is **non-secret operational evidence**. Much of it carries the claims: the argv, the bindings and the credential criterion depend on it.
- It **may be published at the maintainer's deliberate choice**, and it is **not a security blocker**. The threat model is code inside a sandbox on the maintainer's own workstation, and this metadata gives an outside party no meaningful capability. The git identity is already public.
- The most incidental identifying item is the `/usr/local/lib/ollama/cuda_v13` EACCES entry.
- If the maintainer prefers to minimize, do **not** edit captured bytes. That breaks the digests. Instead, publish a redacted projection and bind the raw bytes privately by sha256.
- Muse's Finding 1 (privacy blocker) is retained as dissent. The rule it cites, "bind private evidence privately," governs private evidence such as Fenrir artifacts, not host metadata for public source. Publication is irreversible, so the maintainer must record this disposition before publishing.

**3. Result: supported.**
- Compilation: exit 0 in 1.053986589 s, with empty stdout and stderr.
- Test phase: exit 0 in 0.004563391 s, with exactly 11 named passes and summary `(11,0,0,0,86)`.
- The checker stdout sha `fefd54…` equals the root `stdout_sha256` and the capture `content_sha256`.
- Checker inputs before and after are identical. The 59 root bindings and 91 staged hashes are unchanged.
- Outer stderr is empty, scratch is empty with mode 0700 and uid 1000, and the unit is gone.
- The control-review facts F1–F4 are satisfied by the captures:
  - F1: fds 0/1/2 are `/dev/null` (char device) and two regular files.
  - F2: SysV IPC tables and mqueue are empty.
  - F3: no handler has the `F` flag (WSLInterop is `P`; python3.14 has no flags).
  - F4: 58 checker snapshot entries plus Cargo.toml give 59.
- `bwrap` is mode 0755 and not setuid.
- The walker and launcher credential tuples are equal.
- The frozen `UNRUN/PENDING` labels inside the checker JSON are superseded only by the admission and capture records, as the README explains.

**4. Host-credential observation: consistent with the two ratifications.**
- The exact join yields one target, host PID 2204273. The namespace-only count is 2, with the reaper 2204272 excluded.
- PID and starttime 8004513 are stable and fall within the bracket 8004510 to 8004628.
- The init-read maps are `1000 1000 1`. Groups are unchanged. Capabilities are 0, NNP is 1, setgroups is `deny`.
- The self-map `1000 0 1` is informational.
- The failed predecessor criterion, its self-read and its post record are preserved.
- Credential inheritance by the eleven-test processes is still an inference, not an observation.

**5. Source: no new public exposure.**
- All draft and H1 modules are `#[cfg(test)]` private modules. `pub` items inside them are not exported.
- `program_image` and `image_reference` are `pub(crate)` and test-only.
- `sherlock_source` is the existing parent71 export.
- The envelope is unregistered.
- The typing rules match the A runtime for:
  - first-match calls;
  - cross-sort `Eq`;
  - distinct `Cons`/`Branch` binders;
  - match child path `index+1`.
- `UInt` overflow fails closed.

**6. Non-blocking reporting gap.**
- `ROADMAP`, `SHERLOCK-REFERENCE-STATUS` and the correctness loop say "real lexer" without stating that the lexer is a cached rlib whose source correspondence is unproven. The audit README does state this.
- Recommended fix: add "(cached rlib; source correspondence unproven)". This touches documentation only.

**7. Non-blocking source notes.** Defer these to the next source revision; changing them now would invalidate the capture.
- The H1 warning says "This machine" on the parser, checker and bridge, none of which is a machine.
- The recursive-descent parser and the checker have no depth or size bound. The H1 exclusion of untrusted input covers this for now, but a bound must exist before any registration.
- The parser accepts split tokens such as `= =` and `= >`.

## Exposure report
- **Private code, pins or paths:** none.
- **Secrets or credential values:** none.
- **Host metadata:** present. It is publishable or minimizable as set out in Finding 2.
- **Missing raw failure receipt:** none.
- **Missing cap receipt:** none for the claimed scope. The caps are configured in the argv. No usage measurement is claimed, and none is recorded.
- **Unsafe new public exposure:** none.
- **Unsupported claim:** the README review-binding sentence (Finding 1).

## Limitations
- Approval after the correction covers only the 11 ordinary host tests, on commit `1fb794d…`.
- Correspondence between the lexer and proc-macro caches and their sources is unproven.
- The `lib.rs` wiring was not compiled. The harness used `mod.rs` plus the draft path modules, and the `mori-lexer` Cargo dependency was not exercised.
- The 86 older tests compiled but were filtered out and were not rerun.
- Core library, Cargo, backend, CLI, SDK, K, Quint, Lean, circuit, native and target were not run.
- The 24 and 7 integer oracles are trivial values.
- Retained residuals:
  - TOCTOU checks are start-time only, over the wider writable locus;
  - the private `/dev` tmpfs is writable;
  - vsock, hv_sock and WSLInterop remain reachable in principle;
  - loader behaviour, `.pth` files and the stdout channel are unobserved.
- The H1 untrusted-input restriction stays in force.
- Native authority remains 0.
- No B/U/M/MC/SP/G parent exit closes.
- This review grants no execution or other authority.
