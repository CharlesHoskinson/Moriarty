**Role & Scope Notice:** Answering as **Gemini 4 Argon (High)** through AGY, acting as temporary user-designated security owner in place of Opus 5.5. This is a scoped security and requirements analysis of the supplied packet only, not an architecture adoption, acceptance, or decision vote.

---

### Executive Quantitative Answer

`docs/MORIARTY-BACKEND-REQUIREMENTS.md` defines **16 primary requirements (`ZR01`–`ZR16`)** refined by **8 mandatory Mina-derived acceptance clauses (`MNR01`–`MNR08`)** within the same backend contract (**not** 24 independent milestones).

1. **Current Actual Closure: `0 / 16` ZR rows (and `0 / 8` MNR refinements).**
   Sherlock Candidate B is currently `SPECIFIED-ONLY / UNEXECUTED`. Existing Candidate A K frontend checks, Quint finite-arena samples, and the narrow pure first-order Lean foundation merged in the private Fenrir fork establish no Candidate B helper schedule, bounded `MachineImage` codecs, Clean circuit constraints, soundness proofs, or native Midnight execution.
2. **Projected Closure by Interpreter Alone: `0 / 16` full ZR rows.**
   Every `ZR` row requires native cryptographic proof verification, authenticated ledger state/fee enforcement, or multi-party/governance controls before financial acceptance. An interpreter or step circuit alone cannot close any complete row.
3. **Projected Implementation Ownership by "Full Sherlock" (avoiding false percentages):**
   Defining **Full Sherlock** as the complete proposed stack—reference semantics + Candidate B bounded helper microsteps (`sherlock-helper-microstep/1`), `MachineImage`/`StepInv` representation codecs, Clean bounded-step circuit components and correspondence theorems (`UIREQ-026`), `ConstraintPlan`/`WitnessPlan`/native Midnight exporter (`UIREQ-023`/`031`), source compiler lowering, and the Core/2 financial await/prefix/phase adapter (`UIREQ-014`–`020`) targeting the user-demonstrated **Midnight ledger-9 custom-decider recursion** route (where `VerifyProof`, ledger-10, and foreign proof ports are **not** prerequisites)—the 16 requirements partition as follows:
   * **Sherlock-Primary Implementation:** **4 of 16** (`ZR02`, `ZR06`, `ZR11`, `ZR12`)
   * **Joint Sherlock + Native / Ledger / Application Integration:** **5 of 16** (`ZR03`, `ZR04`, `ZR07`, `ZR09`, `ZR13`)
   * **External / Platform / Ledger / Application-Primary:** **7 of 16** (`ZR01`, `ZR05`, `ZR08`, `ZR10`, `ZR14`, `ZR15`, `ZR16`)

---

### Classification of `ZR01`–`ZR16`

#### 1. Sherlock-Primary Implementation (4 IDs: `ZR02`, `ZR06`, `ZR11`, `ZR12`)
Full Sherlock supplies the core technical engine for these rows, though final acceptance still requires named target/ledger verification:
* **`ZR02` (General program relations):** Sherlock’s indexed `ProgramImage`, `MachineImage`, and Clean step circuit (`UIREQ-001`, `023`, `027`, `032`) express developer-defined bounded relations without a maintainer circuit allowlist. *Why interpreter alone is insufficient:* Composing same- or cross-relation step proofs and rejecting unauthorized relations requires native Midnight recursive verifier/decider integration.
* **`ZR06` (Adversarial-witness soundness):** Full Sherlock (`UIREQ-006`–`010`, `026`, `029`–`031`, `034`) and Opus `A3/A4/B002` dispositions (`StepInv`, `decodeCanonical`/`decodeStep`, checked `UInt128` carry/borrow/wide-product constraints, deterministic witness DAGs) are designed to prove arbitrary-accepted-witness soundness from Clean constraints to reference semantics. *Why interpreter alone is insufficient:* Soundness must also hold across the final Midnight/ZKIR exporter lowering and target custom gates (`PR17` `WShape` discharge).
* **`ZR11` (Compiler/effect correspondence):** Full Sherlock’s compiler lowering and Core/2 typed-await adapter (`UIREQ-017`–`022`, `026`) preserve source evaluation order, exact arithmetic, committed effect prefixes, residual duties, and local failure transitions. *Why interpreter alone is insufficient:* Pure K/Lean omits finance; guaranteed/fallible ledger phase mapping and actual fee-debit enforcement require ledger binding.
* **`ZR12` (Public boundedness):** Sherlock enforces explicit `Bounds`, `stepCap`, physical arena/frame limits, helper-visit metering, and `CapacityNotAdmitted` admission (`UIREQ-012`, `013`, `028`, `029`). *Why interpreter alone is insufficient:* In-circuit step bounds do not bound native proof-byte parsing, accumulator growth, or ledger verifier memory limits.

#### 2. Joint Integration (5 IDs: `ZR03`, `ZR04`, `ZR07`, `ZR09`, `ZR13`)
Sherlock provides half of the required machinery; native recursion, ledger context, or outer application circuits provide the co-equal half:
* **`ZR03` (Complete statement binding):** Sherlock defines `ProgramImage`, `StepInput`/`StepOutput`, `decodeCanonical` checkpoints, and effect/duty records (`UIREQ-014`, `017`, `023`), but binding authoritative ledger context (network, clock, domain, signed intents) and cross-representation hashes requires ledger and outer-circuit enforcement.
* **`ZR04` (Genesis and well-foundedness):** Sherlock constrains canonical genesis decoding (`A4`) and ordered prefix slices (`UIREQ-016`, `032`), but source function recursion (`UIREQ-005`) is not proof recursion; authenticating funded genesis and inductive DAG well-foundedness requires the application compliance wrapper and ledger authentication.
* **`ZR07` (Mandatory verification/control):** Sherlock constrains internal branch/match dispatch (`MatchPlan`) and error outcomes, but preventing zeroed verification guards or bypassed parent proofs requires native recursive verifier guard constraints and outer application predicate dominance.
* **`ZR09` (Bounded multi-parent joins):** Multi-parent composition is outside Sherlock’s first pure fragment (`traceability.md`). Even with full Sherlock’s duty/resource records and slice adapters (`UIREQ-013`–`016`), verifying $\ge 2$ parent proofs and preventing shared-ancestry double-counting require a dedicated multi-parent application join circuit and native recursive fan-in.
* **`ZR13` (Honest cost and feasibility reporting):** Sherlock emits `ResourceManifest`, helper/work planes, and `ConstraintPlan` counts (`UIREQ-013`, `024`, `025`, `031`), but circuit rows/degree, prover/verifier latency, peak memory, accumulator sizes, and DUST fee coverage must be measured on the integrated Midnight backend and ledger.

#### 3. External / Platform / Ledger / Application-Primary (7 IDs: `ZR01`, `ZR05`, `ZR08`, `ZR10`, `ZR14`, `ZR15`, `ZR16`)
Sherlock is a consumer or metadata producer here; primary security ownership lies outside the interpreter stack:
* **`ZR01` (Versioned interface):** Sherlock pins profile and plan digests (`UIREQ-002`, `025`), but fail-closed version checking across ZKIR, transcript, VK, SRS, accumulator, and ledger verifier belongs to the platform release/verifier interface.
* **`ZR05` (Verifier identity):** Preventing VK substitution or `Collapsed`-state hazards requires native VK/accumulator-key binding and application policy, which an inner step circuit cannot self-enforce.
* **`ZR08` (Complete deferred verification):** Discharging KZG/pairing accumulators and custom-decider checks before settlement is owned by the native Midnight verifier and ledger acceptance path.
* **`ZR10` (State and ledger consumption):** Proofs are reusable evidence; binding predecessor identities to current ledger state, nonces, and unique UTXO/resource consumption is strictly a ledger/contract settlement property.
* **`ZR14` (Private continuation interface):** Sherlock’s `MachineImage` checkpoints (`UIREQ-014`) are structural snapshots, not confidential handoff protocols. Binding private commitments, Alice/Bob witness isolation, and leakage bounds require native privacy tooling and application/kernel handoff protocols.
* **`ZR15` (Semantic migration):** Sherlock versions its own language profile (`UIREQ-002`), whereas preserving consumed identities, debt, and authorization across contract/VK upgrades requires ledger migration interfaces and governance policy.
* **`ZR16` (Independent reproducibility and assurance):** Sherlock labels source/model/native evidence classes (`UIREQ-025`), but distinguishing outer-verified from ledger-finalized proofs and enabling third-party verification of retained MC03/MC06 artifacts belong to native CLI/verifier tooling and ledger configuration.

---

### Disposition of the 8 Binding Refinements (`MNR01`–`MNR08`)

None of `MNR01`–`MNR08` are automatically satisfied by Sherlock; each inherits the split of the `ZR` rows it refines:
* **Substantial Sherlock + Native Joint Scope (`3 / 8`):**
  * **`MNR03` (Heterogeneous compatibility/key auth, refines `ZR01/02/05/09/12/13/15`):** Sherlock unifies statement schemas and `Bounds` across programs; the native layer must bind key digests, domain sizes, and owner authorization.
  * **`MNR04` (Verified values vs. auxiliary output, refines `ZR03/07/10/11/16`):** Sherlock’s `ConstraintPlan` vs. `WitnessPlan` split (`UIREQ-031`/`035`) and Core/2 effect commitments separate constrained values from auxiliary witnesses, which must then be tied to verified parent proofs and ledger preconditions.
  * **`MNR08` (Component assurance coverage, refines `ZR01/06/14/16`):** Directly governs the end-to-end qualification dossier linking K → Quint → Lean → Clean (`UIREQ-026`) → ZKIR gates and final verifier code.
* **Platform / Native / Tooling-Primary Scope (`5 / 8`):**
  * **`MNR01` (Transcript/challenge spec, `ZR01/03/06`):** Owned by native/in-circuit verifier transcript and limb rules (to which Sherlock’s `UIREQ-030` arithmetic limbs must conform).
  * **`MNR02` (Deferred obligations/masks, `ZR04/07/08/09/16`):** Owned by native accumulator/decider discharge and parent-mask constraints.
  * **`MNR05` (Production proof-mode separation, `ZR01/07/16`):** Enforced by native proving/verifier configuration (preventing dummy/test proofs), complemented by `UIREQ-025` evidence labels.
  * **`MNR06` (Parameter/cache provenance, `ZR01/05/08/15/16`):** Owned by native SRS/key cache digest and batch-parameter checks.
  * **`MNR07` (Batching and join soundness, `ZR08/09/12/13`):** Owned by native batch challenge generation and multi-parent join soundness arguments.

