### Scope & Security Author Posture

- **Role:** Designated temporary security owner (Gemini 4 Argon High via AGY, replacing Opus until available again). This output is a **SECURITY AUTHOR proposal only**—it is not an independent audit, adoption, schema freeze, or decision vote. No tools, file edits, commands, browsing, or subagent delegations were executed.
- **Authority & Boundaries:** Native authority remains **zero** (`0`). All U0–U7, M1–M17, MC/SP/G, ZR/MNR/OSR, ACTUS, DeFi, and composition gates and counters are unchanged and remain open.
- **Schedule Separation:** `sherlock-k-a/1` (Candidate A K reference), `sherlock-quint-a/1` (Candidate A Quint reference), and `sherlock-helper-microstep/1` (Candidate B) remain strictly separate. Nothing here adopts or freezes Candidate B or transfers properties across profiles without a proved differential predicate (`OSR-1014-02`).
- **Untrusted Consumer Exclusion:** Existing Opus `dc0d7a44` source approval excludes untrusted consumers. This patch **does not** make `mori_core::sherlock` safe for untrusted inputs. H1 full host bounding (wall-clock time, heap allocation, $O(n)$ list/environment cloning, and native call-stack recursion bounds over deep `Expr`/`Tree` values) remains **open** and blocks CLI, LSP, MCP, `/1` or `/2` source adapters, and any network-reachable consumer.
- **Trace Invariance:** Executable `Machine` transitions, charges, rule line numbers, and existing normal oracles (`N01`–`N06`) are completely unchanged.

---

### Security Analysis & Design Judgments

1. **Opus H2 — Host-Diagnostic Resource Classifier (`Outcome::is_resource_limit`):**
   - Frozen **A1** (`UISEC-004` overflow arm) specifies for `sherlock-k-a/1` that `resourceLimit(o)` holds iff `o` is `Outcome::Exhausted` or `Outcome::Rejected(4)` (frame-cap overflow at `D >=Int L`, K rule 140 $\to$ 82).
   - All other `Outcome` variants—`Pending`, `Done(_)`, and every other `Rejected(code)` (reachable semantic/typing/binding/matching/arithmetic rejections `3, 5..=11`, unreachable literal validation `2`, and all other `u8` values)—must classify as `false` and never be conflated with resource exhaustion; conversely, no consumer may read `Exhausted` or `Rejected(4)` as a semantic, typing, or financial rejection.
   - Added `pub const fn is_resource_limit(&self) -> bool` on `Outcome` in `reference_types.rs`. This is strictly a host-diagnostic predicate on the `sherlock-k-a/1` typed common domain with zero native constraint acceptance authority.

2. **Opus H1 — Explicit Unmetered Host Rustdoc Warning (`reference.rs` rustdoc only):**
   - Added rustdoc warnings to `Machine`, `Machine::step`, and `Machine::run` without modifying any executable code in `reference.rs`.
   - Documents the exact H1 host DoS and process-abort surfaces: unbounded `fuel: u128` and `stack_limit: usize`; twice-per-step deep `Snapshot` cloning (`BTreeMap` environments and `Vec` lists) discarded by `run()`; per-frame `Environment` clones; $O(n)$ `BinaryOp::Cons` insertion; and native stack overflow aborts from recursive `Drop`, `Clone`, `PartialEq`, and `to_k` over deep caller-supplied `Arc<Expr>` or runtime-built `Arc<Tree>` values.

3. **Muse Q2 — Counter Diagnostic Invariant (`Snapshot::charged_steps` & `checked_charged_steps`):**
   - **Rejection of silent clamping (`saturating_sub`):** Silently clamping `initial_fuel.saturating_sub(remaining_fuel)` to `0` when `remaining_fuel > initial_fuel` is rejected. It maps an invalid, non-machine-reachable counter state (`remaining_fuel > initial_fuel`) to `0` charged steps, making corrupted or forged hand-built `Snapshot` structs indistinguishable from a valid uncharged genesis snapshot.
   - **Justification for explicit invariant documentation + additive `checked_charged_steps`:**
     - `Machine::new` initializes `remaining_fuel = initial_fuel = fuel`, and `Machine::step` decrements `remaining_fuel` by `1` only when `remaining_fuel > 0`. Therefore, `remaining_fuel <= initial_fuel` is an inductive invariant across all `Machine`-produced snapshots.
     - Retaining `pub fn charged_steps(&self) -> u128` unchanged preserves exact type and behavioral compatibility for existing callers on `Machine` observations while documenting `remaining_fuel <= initial_fuel` as an explicit precondition.
     - Adding `pub const fn checked_charged_steps(&self) -> Option<u128>` (`self.initial_fuel.checked_sub(self.remaining_fuel)`) gives diagnostic callers and tests a total, non-panicking, non-wrapping, non-clamping check that surfaces invalid hand-built counter states as `None`.

---

### Concrete Patch Proposal

#### 1. `crates/mori-core/src/sherlock/reference_types.rs`

```diff
--- a/crates/mori-core/src/sherlock/reference_types.rs
+++ b/crates/mori-core/src/sherlock/reference_types.rs
@@ -134,8 +134,27 @@
     Exhausted,
 }
 
+impl Outcome {
+    /// Host-diagnostic classifier for the frozen `sherlock-k-a/1` A1 resource-limit partition.
+    ///
+    /// Returns `true` iff `self` is [`Outcome::Exhausted`] (zero-fuel termination) or
+    /// [`Outcome::Rejected(4)`] (K-A frame-cap overflow at `D >=Int L`). All other outcomes—
+    /// including [`Outcome::Pending`], [`Outcome::Done`], and all other [`Outcome::Rejected`]
+    /// codes (such as semantic, typing, binding, pattern, or arithmetic errors `3, 5..=11` and
+    /// unreachable literal code `2`)—return `false`.
+    ///
+    /// Scope: host diagnostic only on the `sherlock-k-a/1` typed common domain. This predicate
+    /// carries zero native or cryptographic authority, does not transfer across Quint
+    /// (`sherlock-quint-a/1`) or Candidate B (`sherlock-helper-microstep/1`), and does not make
+    /// the unmetered host evaluator safe for untrusted inputs. No consumer may interpret a
+    /// resource-limit outcome as a semantic, typing, or financial rejection.
+    pub const fn is_resource_limit(&self) -> bool {
+        matches!(self, Self::Exhausted | Self::Rejected(4))
+    }
+}
+
 /// Complete post-startup K boundary state on the typed host common domain.
 /// Frames are stored top first. `None` control represents K's `.K`.
 /// Snapshots are observations; no arbitrary-state import is exposed.
+///
+/// Machine invariant: every `Snapshot` produced by [`super::reference::Machine`] satisfies
+/// `remaining_fuel <= initial_fuel`.
 #[derive(Clone, Debug, PartialEq, Eq)]
 pub struct Snapshot {
     pub program: Arc<Program>,
@@ -152,8 +171,19 @@
     pub fn depth(&self) -> usize {
         self.frames.len()
     }
+
+    /// Returns `initial_fuel - remaining_fuel` for machine-valid observations.
+    ///
+    /// # Preconditions
+    /// Requires the machine invariant `self.remaining_fuel <= self.initial_fuel`.
+    /// For hand-constructed snapshots where this invariant is not guaranteed, use
+    /// [`Snapshot::checked_charged_steps`] so invalid counters are reported as `None`
+    /// rather than silently clamped, wrapped, or panicked.
     pub fn charged_steps(&self) -> u128 {
         self.initial_fuel - self.remaining_fuel
     }
+
+    /// Checked host-diagnostic step counter returning `None` if `remaining_fuel > initial_fuel`.
+    pub const fn checked_charged_steps(&self) -> Option<u128> {
+        self.initial_fuel.checked_sub(self.remaining_fuel)
+    }
 }
```

#### 2. `crates/mori-core/src/sherlock/reference.rs` (Rustdoc Only)

```diff
--- a/crates/mori-core/src/sherlock/reference.rs
+++ b/crates/mori-core/src/sherlock/reference.rs
@@ -1,6 +1,11 @@
 use super::reference_types::*;
 use std::sync::Arc;
 
+/// Host reference evaluator for the frozen `sherlock-k-a/1` profile on the typed common domain.
+///
+/// # Security Warning (H1 — Unmetered Host Evaluator)
+/// This machine is a host diagnostic reference with zero native authority and no host time,
+/// heap, or native stack admission bounds. Do not expose it to untrusted inputs.
 pub struct Machine {
     pub(super) state: Snapshot,
 }
@@ -23,6 +28,10 @@
         self.state.clone()
     }
 
+    /// Executes at most one `sherlock-k-a/1` transition or free terminal publication.
+    ///
+    /// Clones the full [`Snapshot`] twice (`before` and `after`), including environments and
+    /// lists. Unmetered on host resources; not safe for untrusted input (H1).
     pub fn step(&mut self) -> Option<StepRecord> {
         if self.state.outcome != Outcome::Pending {
             return None;
@@ -264,6 +273,21 @@
         }
     }
 
+    /// Runs the machine until a terminal [`Outcome`] (`Done`, `Rejected`, or `Exhausted`) is
+    /// published.
+    ///
+    /// # Security Warning (H1 — DoS and Native Stack Overflow Risks)
+    /// This method is an **unmetered** host reference evaluator and **must not** be connected to
+    /// the CLI, LSP, MCP, the `/1` or `/2` source compiler adapter, or any untrusted/network-reachable
+    /// input path until host time, memory, and nesting bounds are enforced:
+    /// - `fuel: u128` and `stack_limit: usize` have no host ceiling.
+    /// - Every step clones the full [`Snapshot`] twice (`before`/`after`) and `run()` discards
+    ///   both copies; every pushed [`Frame`] clones its [`Environment`]; `BinaryOp::Cons` is $O(n)$.
+    /// - Derived `Drop`, `Clone`, and `PartialEq` impls (as well as diagnostic K rendering)
+    ///   recurse over `Arc<Expr>` and `Arc<Tree>`. Deep caller-supplied ASTs or runtime-built
+    ///   `Branch`/`Leaf` trees can overflow the native call stack and abort the process.
     pub fn run(&mut self) -> Snapshot {
         while self.step().is_some() {}
         self.snapshot()
```

#### 3. `crates/mori-core/src/sherlock/resource_tests.rs` (New File)

```rust
use super::reference::Machine;
use super::reference_types::*;
use std::sync::Arc;

fn program(functions: Vec<Function>, entry: Expr) -> Arc<Program> {
    Arc::new(Program {
        functions,
        entry: Arc::new(entry),
    })
}

fn collect_trace(prog: Arc<Program>, fuel: u128, stack_limit: usize) -> (Vec<(usize, u8)>, Snapshot) {
    let mut machine = Machine::new(prog, fuel, stack_limit);
    let mut steps = Vec::new();
    while let Some(record) = machine.step() {
        assert!(record.before.remaining_fuel <= record.before.initial_fuel);
        assert!(record.after.remaining_fuel <= record.after.initial_fuel);
        assert_eq!(
            record.after.checked_charged_steps(),
            Some(record.after.charged_steps())
        );
        steps.push((record.rule_start_line, record.charge));
    }
    let final_snap = machine.snapshot();
    assert_eq!(
        final_snap.checked_charged_steps(),
        Some(final_snap.charged_steps())
    );
    (steps, final_snap)
}

#[test]
fn outcome_is_resource_limit_matches_frozen_a1_partition() {
    assert!(Outcome::Exhausted.is_resource_limit());
    assert!(Outcome::Rejected(4).is_resource_limit());

    assert!(!Outcome::Pending.is_resource_limit());
    assert!(!Outcome::Done(Value::UInt(0)).is_resource_limit());
    assert!(!Outcome::Done(Value::Bool(true)).is_resource_limit());
    assert!(!Outcome::Done(Value::List(vec![1, 2])).is_resource_limit());
    assert!(!Outcome::Done(Value::Tree(Tree::Leaf(9))).is_resource_limit());

    for code in 0..=u8::MAX {
        assert_eq!(
            Outcome::Rejected(code).is_resource_limit(),
            code == 4,
            "unexpected A1 classification for Rejected({code})"
        );
    }
}

#[test]
fn frame_cap_boundary_off_by_one_and_error4_publication() {
    // Let("0", Unary(Not, Bool(true)), Var("0")) requires depth 1 for Let and depth 2 for Unary.
    let nested = program(
        vec![],
        Expr::Let(
            "0".into(),
            Arc::new(Expr::Unary(
                UnaryOp::Not,
                Arc::new(Expr::Literal(Value::Bool(true))),
            )),
            Arc::new(Expr::Var("0".into())),
        ),
    );

    // stack_limit = 0: first Push fails at depth 0 == 0 via rule 140 -> 82.
    let (steps_0, snap_0) = collect_trace(nested.clone(), 10, 0);
    assert_eq!(steps_0, vec![(114, 1), (140, 1), (82, 0)]);
    assert_eq!(snap_0.outcome, Outcome::Rejected(4));
    assert!(snap_0.outcome.is_resource_limit());
    assert_eq!(snap_0.depth(), 0);
    assert_eq!(snap_0.charged_steps(), 2);

    // stack_limit = 1: first Push succeeds (depth 1), second Push fails at depth 1 == 1.
    let (steps_1, snap_1) = collect_trace(nested.clone(), 10, 1);
    assert_eq!(
        steps_1,
        vec![(114, 1), (135, 1), (120, 1), (140, 1), (82, 0)]
    );
    assert_eq!(snap_1.outcome, Outcome::Rejected(4));
    assert!(snap_1.outcome.is_resource_limit());
    assert_eq!(snap_1.depth(), 1);
    assert_eq!(snap_1.charged_steps(), 4);

    // stack_limit = 2: both Pushes succeed (reaching depth 2) and run finishes with Done(Bool(false)).
    let (steps_2, snap_2) = collect_trace(nested, 10, 2);
    assert_eq!(
        steps_2,
        vec![
            (114, 1),
            (135, 1),
            (120, 1),
            (135, 1),
            (102, 1),
            (157, 1),
            (223, 1),
            (145, 1),
            (108, 1),
            (195, 1),
            (80, 0),
        ]
    );
    assert_eq!(snap_2.outcome, Outcome::Done(Value::Bool(false)));
    assert!(!snap_2.outcome.is_resource_limit());
    assert_eq!(snap_2.depth(), 0);
    assert_eq!(snap_2.charged_steps(), 10);
}

#[test]
fn exhaustion_and_zero_fuel_publication_precedence() {
    let lit = program(vec![], Expr::Literal(Value::UInt(7)));

    // Non-terminal Eval at 0 fuel publishes Exhausted (rule 84, charge 0).
    let (steps_ex, snap_ex) = collect_trace(lit.clone(), 0, 8);
    assert_eq!(steps_ex, vec![(84, 0)]);
    assert_eq!(snap_ex.outcome, Outcome::Exhausted);
    assert!(snap_ex.outcome.is_resource_limit());
    assert_eq!(snap_ex.charged_steps(), 0);

    // Terminal Return with empty stack at 0 remaining fuel publishes Done (rule 80 precedes 84).
    let (steps_done, snap_done) = collect_trace(lit, 1, 8);
    assert_eq!(steps_done, vec![(102, 1), (80, 0)]);
    assert_eq!(snap_done.outcome, Outcome::Done(Value::UInt(7)));
    assert!(!snap_done.outcome.is_resource_limit());
    assert_eq!(snap_done.charged_steps(), 1);

    // Error(3) at 0 remaining fuel publishes Rejected(3) (rule 82 precedes 84).
    let unbound = program(vec![], Expr::Var("0".into()));
    let (steps_err3, snap_err3) = collect_trace(unbound, 1, 8);
    assert_eq!(steps_err3, vec![(111, 1), (82, 0)]);
    assert_eq!(snap_err3.outcome, Outcome::Rejected(3));
    assert!(!snap_err3.outcome.is_resource_limit());
    assert_eq!(snap_err3.charged_steps(), 1);

    // Error(4) at 0 remaining fuel publishes Rejected(4), which is still a resource limit.
    let push_fail = program(
        vec![],
        Expr::Unary(UnaryOp::Not, Arc::new(Expr::Literal(Value::Bool(true)))),
    );
    let (steps_err4, snap_err4) = collect_trace(push_fail, 2, 0);
    assert_eq!(steps_err4, vec![(120, 1), (140, 1), (82, 0)]);
    assert_eq!(snap_err4.outcome, Outcome::Rejected(4));
    assert!(snap_err4.outcome.is_resource_limit());
    assert_eq!(snap_err4.charged_steps(), 2);
}

#[test]
fn all_non_resource_k_a_rejections_classified_false() {
    // Error 3: unbound variable (111 -> 82).
    let (s3, r3) = collect_trace(program(vec![], Expr::Var("0".into())), 10, 8);
    assert_eq!(s3, vec![(111, 1), (82, 0)]);
    assert_eq!(r3.outcome, Outcome::Rejected(3));
    assert!(!r3.outcome.is_resource_limit());

    // Error 5: non-boolean If condition retains frame (123 -> 135 -> 102 -> 169 -> 82).
    let (s5, r5) = collect_trace(
        program(
            vec![],
            Expr::If(
                Arc::new(Expr::Literal(Value::UInt(1))),
                Arc::new(Expr::Literal(Value::UInt(2))),
                Arc::new(Expr::Literal(Value::UInt(3))),
            ),
        ),
        10,
        8,
    );
    assert_eq!(s5, vec![(123, 1), (135, 1), (102, 1), (169, 1), (82, 0)]);
    assert_eq!(r5.outcome, Outcome::Rejected(5));
    assert_eq!(r5.depth(), 1);
    assert!(!r5.outcome.is_resource_limit());

    // Error 6: return type mismatch retains Return frame (129->200->204->208->135->102->190->82).
    let fn_bad_ret = Function {
        name: "0".into(),
        parameters: vec![],
        return_type: Type::UInt,
        body: Arc::new(Expr::Literal(Value::Bool(true))),
    };
    let (s6, r6) = collect_trace(
        program(vec![fn_bad_ret], Expr::Call("0".into(), vec![])),
        10,
        8,
    );
    assert_eq!(
        s6,
        vec![
            (129, 1),
            (200, 1),
            (204, 1),
            (208, 1),
            (135, 1),
            (102, 1),
            (190, 1),
            (82, 0)
        ]
    );
    assert_eq!(r6.outcome, Outcome::Rejected(6));
    assert_eq!(r6.depth(), 1);
    assert!(!r6.outcome.is_resource_limit());

    // Error 7: missing function (129 -> 200 -> 202 -> 82).
    let (s7, r7) = collect_trace(program(vec![], Expr::Call("0".into(), vec![])), 10, 8);
    assert_eq!(s7, vec![(129, 1), (200, 1), (202, 1), (82, 0)]);
    assert_eq!(r7.outcome, Outcome::Rejected(7));
    assert!(!r7.outcome.is_resource_limit());

    // Error 8: binding failure on duplicate parameter names (131->135->102->177->102->181->200->204->206->82).
    let fn_dup_param = Function {
        name: "0".into(),
        parameters: vec![
            Parameter {
                name: "1".into(),
                ty: Type::UInt,
            },
            Parameter {
                name: "1".into(),
                ty: Type::UInt,
            },
        ],
        return_type: Type::UInt,
        body: Arc::new(Expr::Literal(Value::UInt(0))),
    };
    let (s8, r8) = collect_trace(
        program(
            vec![fn_dup_param],
            Expr::Call(
                "0".into(),
                vec![
                    Arc::new(Expr::Literal(Value::UInt(1))),
                    Arc::new(Expr::Literal(Value::UInt(2))),
                ],
            ),
        ),
        12,
        8,
    );
    assert_eq!(
        s8,
        vec![
            (131, 1),
            (135, 1),
            (102, 1),
            (177, 1),
            (102, 1),
            (181, 1),
            (200, 1),
            (204, 1),
            (206, 1),
            (82, 0)
        ]
    );
    assert_eq!(r8.outcome, Outcome::Rejected(8));
    assert!(!r8.outcome.is_resource_limit());

    // Error 9: match exhaustion after equal-name Cons binder miss (126->135->102->173->214->217->212->82).
    let (s9, r9) = collect_trace(
        program(
            vec![],
            Expr::Match(
                Arc::new(Expr::Literal(Value::List(vec![1]))),
                vec![Arm {
                    pattern: Pattern::Cons("0".into(), "0".into()),
                    body: Arc::new(Expr::Literal(Value::UInt(1))),
                }],
            ),
        ),
        10,
        8,
    );
    assert_eq!(
        s9,
        vec![
            (126, 1),
            (135, 1),
            (102, 1),
            (173, 1),
            (214, 1),
            (217, 1),
            (212, 1),
            (82, 0)
        ]
    );
    assert_eq!(r9.outcome, Outcome::Rejected(9));
    assert!(!r9.outcome.is_resource_limit());

    // Error 10: checked arithmetic underflow (117->135->102->149->102->153->225->82).
    let (s10, r10) = collect_trace(
        program(
            vec![],
            Expr::Binary(
                BinaryOp::Sub,
                Arc::new(Expr::Literal(Value::UInt(0))),
                Arc::new(Expr::Literal(Value::UInt(1))),
            ),
        ),
        10,
        8,
    );
    assert_eq!(
        s10,
        vec![
            (117, 1),
            (135, 1),
            (102, 1),
            (149, 1),
            (102, 1),
            (153, 1),
            (225, 1),
            (82, 0)
        ]
    );
    assert_eq!(r10.outcome, Outcome::Rejected(10));
    assert!(!r10.outcome.is_resource_limit());

    // Error 11: unary operator sort mismatch (120->135->102->157->225->82).
    let (s11, r11) = collect_trace(
        program(
            vec![],
            Expr::Unary(UnaryOp::Not, Arc::new(Expr::Literal(Value::UInt(1)))),
        ),
        10,
        8,
    );
    assert_eq!(
        s11,
        vec![(120, 1), (135, 1), (102, 1), (157, 1), (225, 1), (82, 0)]
    );
    assert_eq!(r11.outcome, Outcome::Rejected(11));
    assert!(!r11.outcome.is_resource_limit());
}

#[test]
fn snapshot_counter_invariant_and_checked_charged_steps() {
    let prog = program(vec![], Expr::Literal(Value::UInt(1)));
    let mut machine = Machine::new(prog.clone(), 3, 4);
    assert_eq!(machine.snapshot().checked_charged_steps(), Some(0));
    let _ = machine.run();
    assert_eq!(machine.snapshot().checked_charged_steps(), Some(1));

    // Hand-built invalid snapshot with remaining_fuel > initial_fuel must return None, never Some(0).
    let invalid = Snapshot {
        program: prog,
        control: None,
        environment: Environment::new(),
        frames: vec![],
        stack_limit: 4,
        remaining_fuel: 6,
        initial_fuel: 5,
        outcome: Outcome::Pending,
    };
    assert_eq!(invalid.checked_charged_steps(), None);
}
```

---

### Literal Test Matrix & Enforced Invariants

| Case | Input / Setup (`fuel`, `stack_limit`) | Exact Rule Line Trace `(line, charge)` | Final `Outcome` | `is_resource_limit()` | `depth()` / `checked_charged_steps()` |
|---|---|---|---|---|---|
| Exhaustive `Outcome` domain | `Exhausted`, `Rejected(4)` vs `Pending`, `Done(_)`, `Rejected(c != 4)` for `c in 0..=255` | N/A (direct predicate) | All variants | `true` iff `Exhausted \| Rejected(4)` | N/A |
| Frame cap hit (`L=0`) | `Let("0", Not(true), Var("0"))` (`10, 0`) | `(114,1), (140,1), (82,0)` | `Rejected(4)` | `true` | `0` / `Some(2)` |
| Frame cap off-by-one (`L=1`) | `Let("0", Not(true), Var("0"))` (`10, 1`) | `(114,1), (135,1), (120,1), (140,1), (82,0)` | `Rejected(4)` | `true` | `1` / `Some(4)` |
| Frame cap pass (`L=2`) | `Let("0", Not(true), Var("0"))` (`10, 2`) | `114,135,120,135,102,157,223,145,108,195` (`1` ea), `(80,0)` | `Done(Bool(false))` | `false` | `0` / `Some(10)` |
| Zero-fuel exhaustion | `Literal(UInt(7))` (`0, 8`) | `(84,0)` | `Exhausted` | `true` | `0` / `Some(0)` |
| Return precedes exhaustion | `Literal(UInt(7))` (`1, 8`) | `(102,1), (80,0)` | `Done(UInt(7))` | `false` | `0` / `Some(1)` |
| `Error(3)` precedes exhaustion | `Var("0")` (`1, 8`) | `(111,1), (82,0)` | `Rejected(3)` | `false` | `0` / `Some(1)` |
| `Error(4)` precedes exhaustion | `Unary(Not, Bool(true))` (`2, 0`) | `(120,1), (140,1), (82,0)` | `Rejected(4)` | `true` | `0` / `Some(2)` |
| Semantic/type/arith rejections | Unbound(`3`), If(`5`), Ret(`6`), UndefFn(`7`), DupBind(`8`), MatchMiss(`9`), SubUnderflow(`10`), UnarySort(`11`) | Exact traces through `111, 169, 190, 202, 206, 212, 225` $\to$ `(82,0)` | `Rejected(3 \| 5..=11)` | `false` | Retained frames on `5,6`; `Some(charged)` |
| Invalid hand-built counter | `Snapshot { initial_fuel: 5, remaining_fuel: 6, .. }` | N/A (observation check) | `Pending` | `false` | `0` / `None` (no silent clamp) |

---

### Integration Sequence for Root-Observed RED Before Code

Root **must not** execute the new tests prior to formal closure classification. Once classified, root executes the following sequence to capture observed **RED** before applying the functional implementation:

1. **Pre-State Pin:** Verify worktree matches baseline `dc0d7a44…` and existing `reference_oracles_tests.rs` / `N01`–`N06` hashes are untouched.
2. **Stage Test & Minimal RED Stub (for runtime assertion RED, exit 101):**
   - Place `crates/mori-core/src/sherlock/resource_tests.rs` and declare `#[cfg(test)] mod resource_tests;` in `crates/mori-core/src/sherlock/mod.rs`.
   - *(Alternative A — Compile RED)*: Run against unpatched `reference_types.rs` to observe `rustc` compile failure (`E0599`: no method `is_resource_limit` / `checked_charged_steps`).
   - *(Alternative B — Runtime Assertion RED matching baseline `f218a8d8` convention)*: Add stub bodies `pub const fn is_resource_limit(&self) -> bool { false }` and `pub const fn checked_charged_steps(&self) -> Option<u128> { Some(0) }` in `reference_types.rs`. Compile test binary (`exit 0`) and run it to observe deterministic test failure (`exit 101`) on both `Outcome::Exhausted.is_resource_limit()` (H2) and `invalid.checked_charged_steps() == None` (Q2). Record the RED receipt.
3. **Apply Patch (GREEN):**
   - Apply the exact `reference_types.rs` and `reference.rs` (rustdoc-only) diffs above.
   - Re-run the compiled test target and `python3 -I -B models/sherlock/reference/check-reference.py` under the classified runner.
   - Verify all 5 new tests in `resource_tests.rs` plus the existing normal/oracle tests pass (`exit 0`), and verify `git diff` on `reference.rs` contains comment-only (`///`) additions.

