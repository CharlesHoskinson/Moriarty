### Security Classification: **ORDINARY HOST / NON-NATIVE (NO BLOCKERS)**

As user-authorized security owner (Gemini 4 Argon High via AGY), I have independently inspected the supplied 8-file source closure and proposed command. For command-safety purposes only, the closure and command are classified as **ordinary host / non-native** with **zero native/SDK authority** and **no blockers**.

---

### 1. Independent Source Closure Audit

1. **Harness (`models/sherlock/reference/check-reference.py`, SHA-256 `c9564c67...3affcd`)**:
   - **Stdlib-only**: Imports only `argparse`, `hashlib`, `json`, `pathlib.Path`, `shlex`, `subprocess`, `sys`, and `tempfile`.
   - **Input & Digest Pinning**: Verifies exact SHA-256 matches against `FROZEN` (`normal-programs.json`, `normal-prefixes.json`, `main.k`) before execution, records digests of all 8 `SOURCE_PATHS` plus `rustc`, and re-verifies all `FROZEN` and `SOURCE_PATHS` digests post-run to confirm zero repo mutation. `main.k` is read strictly as bytes for `hashlib.sha256`; no K toolchain is invoked.
   - **Mechanical Transcription Guard**: `serialize_oracles` validates printable ASCII strings (`32..=126`) and non-negative `int` literals from the frozen JSON files and requires `crates/mori-core/src/sherlock/normal_oracles.rs` to match the serialized bytes exactly (`constants.read_bytes() == generated.encode("utf-8")`). No evaluator computes expected outcomes and no files are written in the repo.
   - **Subprocess & Temp Isolation**: Compiles `crates/mori-core/src/sherlock/mod.rs` directly via the explicit absolute `--rustc` path into `tempfile.TemporaryDirectory(prefix="sherlock-reference-")` and executes the resulting binary with `--test-threads=1 --nocapture`. Both subprocess calls are bounded by `--timeout-seconds 30` (`1..=60` enforced).

2. **Transitive Rust Compilation Graph (`crates/mori-core/src/sherlock/mod.rs` as crate root)**:
   - Compiling `mod.rs` (`13e36b84...801c4f`) directly with `rustc --edition=2024 --test` isolates compilation to the `sherlock` submodule closure and does **not** pull in `crates/mori-core/src/lib.rs`, `Cargo.toml`, build scripts, proc-macros, or external crates.
   - **Transitive files**:
     - `mod.rs`: Declares `reference`, `reference_display`, `reference_types`, and `#[cfg(test)]` modules `reference_tests` and `reference_oracles_tests`.
     - `reference_types.rs` (`83d2ced3...412792`): Pure `std` data structures (`BTreeMap`, `Arc`) and static metadata constants.
     - `reference.rs` (`3f8ccbf3...048b00`): Pure in-memory state machine (`Machine::new`, `step`, `run`). Every non-terminal transition decrements `remaining_fuel`, strictly bounding execution steps.
     - `reference_display.rs` (`3f3456bf...72e4`): Pure in-memory string formatting (`KDisplay`).
     - `normal_oracles.rs` (`3421828b...bbe5`): Static literal table (`CASES`) for `N01`–`N06` (92 prefixes, max `initial_fuel = 27` / prefix `28`), included via `include!("normal_oracles.rs")`.
     - `reference_oracles_tests.rs` (`7d254ecd...2faba`) & `reference_tests.rs` (`0138a704...01c1`): 8 finite `#[test]` functions (6 normal oracle cases across 92 fuel prefixes, 1 membership check, 1 unit literal test) exercising only in-memory `Machine` transitions and assertions.
   - **Absence of Dangerous Constructs**: Across all 7 Rust files, there are zero `unsafe` blocks, FFI (`extern`), filesystem/network/env I/O calls, process spawns, or references to any proving/SDK/circuit/SRS/key/transcript/ledger components.

---

### 2. Command & Authority Verification

- **Exact Command**:
  `timeout 90s python3 -I -B models/sherlock/reference/check-reference.py --rustc /home/charl/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin/rustc --timeout-seconds 30`
- **Flags**: `timeout 90s` caps overall runtime; `python3 -I -B` isolates Python from environment/path injection and suppresses `.pyc` writes; `--timeout-seconds 30` bounds both compile and test runs.
- **Native / SDK Touch**: **ZERO**. No relation, circuit, model, degree, `k`, VM, transcript, keygen, prove, native verify, ledger, deploy, private key, PK, SRS, or cache reads/actions occur.

---

### 3. Conditions & Scope Limits

1. **Exact Closure Digest Condition**: This classification applies **only** while the 8 files in `SOURCE_PATHS` and 3 files in `FROZEN` match the exact SHA-256 digests supplied in this prompt:
   - `check-reference.py`: `c9564c679ced88b94813104b84de225cb8968f70a93189e376de4b13e13affcd`
   - `mod.rs`: `13e36b840946549feed97706cac3ee0e465cc3889f4fabcd964b98e847801c4f`
   - `normal_oracles.rs`: `3421828bada394a5f1aa7b9ccc2fa52182db88adf7f2bfd58bf1d871e9d6bbe5`
   - `reference.rs`: `3f8ccbf3d594b29873fcf79684d98639a7d90155f34cd06ab06ec82a01048b00`
   - `reference_display.rs`: `3f3456bfeaa6ce043986de29673ba038d94cfa405de2d715fd774ad8aa1872e4`
   - `reference_oracles_tests.rs`: `7d254ecd7ffbadda8214e82d47dd2d2c21aea261677f223813541a386d22faba`
   - `reference_tests.rs`: `0138a704d0d68c9c78bb9ae752011736a387bb9bc24072e44ff73854536901c1`
   - `reference_types.rs`: `83d2ced3598c758977fe0940d06f712ea7a62f0cc77d9d5f273e30ac7d412792`
2. **Exact Invocation Condition**: Must be executed from the repository root with the exact argv tokens specified and the pinned host `rustc` binary (`/home/charl/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin/rustc`).
3. **No Implied Approval**: Any byte change in the closure requires new source inspection. This classification covers command execution safety of this exact closure only, not whole-crate `mori-core`, future consumers, semantic correctness, security properties, or result adoption.

