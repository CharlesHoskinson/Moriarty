**Top finding:** The oracle test wiring is correctly integrated, but the temporary Argon routing is still contradicted by unqualified Opus-routing instructions in the developer guidance.

## Verdicts

| Scope | Verdict |
|---|---|
| Scoped source integration | **APPROVE** |
| SPEC compliance | **REQUEST_CHANGES** |
| QUALITY | **APPROVE**, with minor findings |

## Source integration — APPROVE

- [mod.rs](/home/charl/Moriarty/.worktrees/core-continuations-20261015/crates/mori-core/src/sherlock/mod.rs:18) declares `reference_oracles_tests` in the crate test graph, and [reference_oracles_tests.rs](/home/charl/Moriarty/.worktrees/core-continuations-20261015/crates/mori-core/src/sherlock/reference_oracles_tests.rs:45) now uses `include!("normal_oracles.rs")`. I found no remaining `SHERLOCK_ORACLES_RS`/`env!` inclusion and no external duplicate test wrapper.
- [check-reference.py](/home/charl/Moriarty/.worktrees/core-continuations-20261015/models/sherlock/reference/check-reference.py:184) regenerates the transcription from the frozen JSON, byte-compares it with committed [normal_oracles.rs](/home/charl/Moriarty/.worktrees/core-continuations-20261015/crates/mori-core/src/sherlock/normal_oracles.rs:1), then compiles the actual [mod.rs](/home/charl/Moriarty/.worktrees/core-continuations-20261015/crates/mori-core/src/sherlock/mod.rs:1) with `rustc --test`. The production `reference.rs`, `reference_types.rs`, `reference_tests.rs`, `reference_display.rs`, frozen JSON, and K source are unchanged from baseline `ba12e473`.
- Source counts match the retained result: seven oracle tests plus one existing reference test. [HOST-COMPARISON-RESULT.json](/home/charl/Moriarty/.worktrees/core-continuations-20261015/docs/audits/2026-10-15/sherlock-reference-wiring/HOST-COMPARISON-RESULT.json:10) records eight passed tests and 92 prefixes. All 31 membership hashes in the supplied membership file match the candidate tree.
- This was a read-only review, so I did not rerun those tests. Whole-crate Cargo and native execution remain unexecuted, as disclosed in [SHERLOCK-REFERENCE-STATUS.md](/home/charl/Moriarty/.worktrees/core-continuations-20261015/docs/SHERLOCK-REFERENCE-STATUS.md:52). The stated `u128::MAX` fuel and `usize::MAX` stack bounds at lines 24–27 match the field types in `reference_types.rs`.

## SPEC compliance — REQUEST_CHANGES

The temporary routing is correctly stated at the top of [AGENTS.md](/home/charl/Moriarty/.worktrees/core-continuations-20261015/AGENTS.md:3), in the assignment record, and in the Argon receipts. However, operative guidance still instructs routing to Opus without a temporary-supersession qualifier:

- [execution-focus.md](/home/charl/Moriarty/.worktrees/core-continuations-20261015/plugins/moriarty-dev/skills/develop/references/execution-focus.md:60), under “Opus-owned execution boundary,” says to route all security work to Opus 5.5.
- The same file at line 21 and [SKILL.md](/home/charl/Moriarty/.worktrees/core-continuations-20261015/plugins/moriarty-dev/skills/develop/SKILL.md:37) retain similar unqualified instructions, despite the temporary override added earlier in both files.

Required change: qualify those sections as superseded for new work until Opus availability is observed, while preserving them as historical/frozen-record routing. Until then, an agent reading the operative section in isolation can misroute work contrary to the user’s temporary assignment.

The model-routing receipts themselves are consistent: the authenticated model list contains `gemini-4-argon-high`, the three receipt digests match the retained decompressed HTML and text extracts, and the records explicitly disclose that AGY exposed no separate returned model ID. That establishes requested-model and transport-selection evidence only, not returned-model proof or product approval. The readiness canary’s ineffective plan-mode combination is also disclosed rather than hidden.

## QUALITY — APPROVE with minor findings

- The header in [reference_oracles_tests.rs](/home/charl/Moriarty/.worktrees/core-continuations-20261015/crates/mori-core/src/sherlock/reference_oracles_tests.rs:2) still says `check-reference.py` “only transcribes JSON,” although it now also byte-verifies the committed constants and compiles/runs the actual module graph. Update that sentence.
- The Argon author proposal is correctly retained as separate, unapplied, and unexecuted in [the wiring README](/home/charl/Moriarty/.worktrees/core-continuations-20261015/docs/audits/2026-10-15/sherlock-reference-wiring/README.md:33). I express no security conclusion on it; H1/H2/Q2, B1–B8, adoption, freeze, resource choices, and all security judgments remain for the separate Gemini 4 Argon auditor.

No adoption, freeze, new-resource, or native-authority vote is made here. Native authority remains zero.
