### Security Owner Classification (`Gemini4Argonhigh`)

Both commands are classified from the full inline source, import, and `include!` closure provided in the prompt, with zero tool calls, workspace reads, or delegation.

---

### 1. CWD1 (`sherlock-trace-compare-20261015` — RED Compare Scaffold)

* **Decision**: `APPROVE_ORDINARY_HOST_COMMAND`
* **CWD**: `/home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015`
* **Exact Argv**:
  `timeout 90s python3 -I -B models/sherlock/reference/check-reference.py --rustc /home/charl/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin/rustc --timeout-seconds 30`
* **Full Source / Import / Include Closure**:
  * **Driver**: [check-reference.py](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/models/sherlock/reference/check-reference.py) (`053861c757100bb56129061a2d21887da6e3fe9efb5e4a14b198228825ccb0ad`) importing Python stdlib only (`argparse`, `hashlib`, `json`, `pathlib.Path`, `shlex`, `subprocess`, `sys`, `tempfile`).
  * **Compiler**: `/home/charl/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin/rustc` (`f3834d26669b03f6855fa54bd2381443123e860167bc0c7a8dd137e5cf6e5e4f`).
  * **Pinned Read-Only Data (`FROZEN`)**:
    * `models/sherlock/oracles/normal-programs.json` (`ef87f94f7e5d22a75b1c2e5e61af016b08175beee9a3599e3e69ddf92945d32f`)
    * `models/sherlock/oracles/normal-prefixes.json` (`dca67b553d7483fdf7d9148e7f4bf1a6022b42b8843635f33f23c58a2415d56d`)
    * `models/sherlock/k/main.k` (`b3746ff51dd7999b046ccb23237595605420adcfeebc0c04c0ad0f1396b11d41` — digest-checked only; never executed).
  * **Rust Crate Root & Module / `include!` Closure** (`std` only; no Cargo, no external crates, no proc-macros, no `build.rs`, no `unsafe`):
    * [mod.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/mod.rs) (`4864a168ab06baa9456a193badb5ab5ef4c8a75ffc5256451e036c446fcf5b1d`)
    * [compare.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs) (`73cc610362c1ac3b63fe2c284ccbaa1ee30145e664eaded962f2b3155a6c9431`) — [`first_difference`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs#L99-L104) RED stub returning `None`.
    * [compare_tests.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare_tests.rs) (`21b05b053a773797dad2bbc2cc772a744392476533fe74011d307d68e162a61f`) — 15 finite unit tests on 2-step literal `N01` traces (`fuel <= 2`, `stack_limit <= 9`).
    * [reference.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/reference.rs) (`e1bb1098d6e19ca3bca30a09bb90b11366fa9f70726aba9165d54f14056b181b`) — [`Machine`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/reference.rs#L8-L10).
    * [reference_types.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/reference_types.rs) (`4b4bb364a0c8182e117a9c36efb5d91cb7e405f653a6d3870f54dc03eefa317f`)
    * [reference_display.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/reference_display.rs) (`3f3456bfeaa6ce043986de29673ba038d94cfa405de2d715fd774ad8aa1872e4`)
    * [reference_tests.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/reference_tests.rs) (`0138a704d0d68c9c78bb9ae752011736a387bb9bc24072e44ff73854536901c1`) — 1 test.
    * [resource_tests.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/resource_tests.rs) (`e785241f3ebfe3269de8e2c316270f4308476d956c996a95e014965b872b1457`) — 5 tests.
    * [reference_oracles_tests.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/reference_oracles_tests.rs) (`575a86fa7d2d673605721c956af400f2b44c6434fe331d30e5c15d97ea4f9cd1`) + `include!("normal_oracles.rs")` ([normal_oracles.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/normal_oracles.rs), `3421828bada394a5f1aa7b9ccc2fa52182db88adf7f2bfd58bf1d871e9d6bbe5`) — 7 tests across 6 normal programs / 92 prefixes.
* **Actual Side Effects**:
  * Read-only verification of pinned SHA-256 digests and in-memory JSON-to-Rust transcription check before and after execution.
  * `-I -B` isolates Python from environment/user-site injection and suppresses `.pyc` writes.
  * Creates an ephemeral `tempfile.TemporaryDirectory(prefix="sherlock-reference-")`, compiles `reference_check` into it, runs the 28 unit tests single-threaded (`--test-threads=1 --nocapture`), emits JSON log lines to stdout, and unlinks the temporary directory on exit.
  * Expected exit is non-zero (RED) because 13 inequality tests in `compare_tests.rs` fail against the `None` stub. Zero repository mutation.

---

### 2. CWD2 (`core-continuations-20261015` `HEAD` `c07f0f32` — Current 13-Test Suite)

* **Decision**: `APPROVE_ORDINARY_HOST_COMMAND`
* **CWD**: `/home/charl/Moriarty/.worktrees/core-continuations-20261015`
* **Exact Argv**:
  `timeout 90s python3 -I -B models/sherlock/reference/check-reference.py --rustc /home/charl/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin/rustc --timeout-seconds 30`
* **Full Source / Import / Include Closure**:
  * **Driver**: [check-reference.py](file:///home/charl/Moriarty/.worktrees/core-continuations-20261015/models/sherlock/reference/check-reference.py) (`01f370da84e9681cf18cccd4128979631471b59ebee70426a9eacb620000961f`).
  * **Crate Root**: [mod.rs](file:///home/charl/Moriarty/.worktrees/core-continuations-20261015/crates/mori-core/src/sherlock/mod.rs) (`d550b50b0c73f49c7c8267d718c31cc1753c064124ddcf64b347f515c5a229bd`).
  * **Remaining Closure**: Exact same `rustc` binary (`f3834d26...`), 3 `FROZEN` files (`ef87f94f...`, `dca67b55...`, `b3746ff5...`), and 7 Rust files (`reference.rs`, `reference_types.rs`, `reference_display.rs`, `reference_tests.rs`, `resource_tests.rs`, `reference_oracles_tests.rs`, `normal_oracles.rs`) with identical SHA-256 digests as CWD1, omitting only `compare.rs` and `compare_tests.rs`.
* **Actual Side Effects**:
  * Identical read-only hash/transcription checks, ephemeral `tempfile.TemporaryDirectory` compilation, single-threaded execution of the 13 existing tests (`reference_tests`, `reference_oracles_tests`, `resource_tests`) on small finite inputs (`fuel <= 28`, `stack_limit <= 8`), stdout JSON emission, and temporary directory cleanup. Zero workspace mutation; zero network or IPC access.

---

### 3. Common Limits & Quarantine Conditions

* **RED-Only Scope for `compare.rs`**: Approval for CWD1 covers **only** `compare.rs` SHA-256 `73cc610362c1ac3b63fe2c284ccbaa1ee30145e664eaded962f2b3155a6c9431`. No GREEN run is classified or authorized until the replacement `compare.rs` implementation source is inspected and its SHA-256 is pinned.
* **Runtime & Resource Bounds**: Bounded by outer `timeout 90s`, per-step `--timeout-seconds 30` (compile and test), `--test-threads=1`, and small finite static test inputs.
* **H1 Quarantine & Zero Native Authority**: Native authority remains `0`. [`Machine`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/reference.rs#L8-L10) and [`first_difference`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs#L99-L104) remain unmetered host diagnostics under H1 quarantine and must not be wired to untrusted inputs, CLI/LSP/MCP endpoints, or `/1` and `/2` compiler pipelines.
* **Non-Authorization**: This classification is strictly an ordinary host-command approval. It is not source/merge approval, a Candidate B decision, a K/Lean/Quint execution, or a cryptographic/ledger/proof action.

END_HOST_CLASSIFICATION

