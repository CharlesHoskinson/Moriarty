### Security Owner GREEN Host Command Classification (`Gemini 4 Argon (High)`)

Classified strictly from the inline GREEN source of [compare.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs) and the pinned full-source closure from the prior RED classification, with zero tool calls, workspace reads, commands, network access, mutations, or delegation.

---

### 1. Decision & Command Binding

* **Decision**: `APPROVE_ORDINARY_HOST_COMMAND`
* **CWD**: `/home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015`
* **Exact Argv**:
  `timeout 90s python3 -I -B models/sherlock/reference/check-reference.py --rustc /home/charl/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin/rustc --timeout-seconds 30`

---

### 2. Unchanged Closure Basis & Single-File GREEN Delta

* **Unchanged Driver, Compiler, & Frozen Data**:
  * **Driver**: [check-reference.py](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/models/sherlock/reference/check-reference.py) (`053861c757100bb56129061a2d21887da6e3fe9efb5e4a14b198228825ccb0ad`) — Python stdlib only (`argparse`, `hashlib`, `json`, `pathlib.Path`, `shlex`, `subprocess`, `sys`, `tempfile`).
  * **Compiler**: `/home/charl/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin/rustc` (`f3834d26669b03f6855fa54bd2381443123e860167bc0c7a8dd137e5cf6e5e4f`).
  * **Pinned Read-Only Data (`FROZEN`)**:
    * [normal-programs.json](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/models/sherlock/oracles/normal-programs.json) (`ef87f94f7e5d22a75b1c2e5e61af016b08175beee9a3599e3e69ddf92945d32f`)
    * [normal-prefixes.json](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/models/sherlock/oracles/normal-prefixes.json) (`dca67b553d7483fdf7d9148e7f4bf1a6022b42b8843635f33f23c58a2415d56d`)
    * [main.k](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/models/sherlock/k/main.k) (`b3746ff51dd7999b046ccb23237595605420adcfeebc0c04c0ad0f1396b11d41` — digest-checked only; never executed).
* **Unchanged Rust Module / `include!` Closure (9 of 10 Rust files identical to RED)**:
  * [mod.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/mod.rs) (`4864a168ab06baa9456a193badb5ab5ef4c8a75ffc5256451e036c446fcf5b1d`)
  * [compare_tests.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare_tests.rs) (`21b05b053a773797dad2bbc2cc772a744392476533fe74011d307d68e162a61f`) — Unchanged since RED. Actual compiled suite is 29 total tests across the crate (16 in [compare_tests.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare_tests.rs) + 13 existing tests; RED run observed `compile=0`, `test=101` with 15 passed and 14 expected inequality failures).
  * [reference.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/reference.rs) (`e1bb1098d6e19ca3bca30a09bb90b11366fa9f70726aba9165d54f14056b181b`)
  * [reference_types.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/reference_types.rs) (`4b4bb364a0c8182e117a9c36efb5d91cb7e405f653a6d3870f54dc03eefa317f`)
  * [reference_display.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/reference_display.rs) (`3f3456bfeaa6ce043986de29673ba038d94cfa405de2d715fd774ad8aa1872e4`)
  * [reference_tests.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/reference_tests.rs) (`0138a704d0d68c9c78bb9ae752011736a387bb9bc24072e44ff73854536901c1`)
  * [resource_tests.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/resource_tests.rs) (`e785241f3ebfe3269de8e2c316270f4308476d956c996a95e014965b872b1457`)
  * [reference_oracles_tests.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/reference_oracles_tests.rs) (`575a86fa7d2d673605721c956af400f2b44c6434fe331d30e5c15d97ea4f9cd1`)
  * [normal_oracles.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/normal_oracles.rs) (`3421828bada394a5f1aa7b9ccc2fa52182db88adf7f2bfd58bf1d871e9d6bbe5`)
* **Single Modified File (GREEN Target)**:
  * [compare.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs) (`775f0c3825a8dff5fd700a539e0e24e4421674f0fab4d54d757da0b24615a216`, replacing RED `73cc610362c1ac3b63fe2c284ccbaa1ee30145e664eaded962f2b3155a6c9431`).

---

### 3. Exact Scope, Imports, & Behavior of GREEN [compare.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs)

* **Imports**: Only `use super::reference_types::{Snapshot, StepRecord};` plus Rust `core`/`std` prelude traits/types (`Clone`, `Copy`, `Debug`, `PartialEq`, `Eq`, `Option`, `usize`). Zero external crates, proc-macros, `unsafe` blocks, syscalls, I/O, formatting/display parsing, or heap allocations.
* **Data Types** (unchanged signatures and derives): [`TraceIdentity`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs#L24-L27), [`TraceView`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs#L31-L35), [`IdentityField`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs#L38-L41), [`SnapshotField`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs#L47-L56), [`RecordField`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs#L61-L66), and [`TraceDifference`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs#L72-L85).
* **Executable Logic**:
  * [`first_difference`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs#L94-L138): Pure, lazy, deterministic borrowed inspection returning on the earliest mismatch in order:
    1. `left.identity.profile != right.identity.profile` $\rightarrow$ `Identity(IdentityField::Profile)`
    2. `left.identity.source_sha256 != right.identity.source_sha256` $\rightarrow$ `Identity(IdentityField::SourceSha256)`
    3. [`snapshot_difference`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs#L140-L159) on `initial` $\rightarrow$ `Initial(field)`
    4. `left.records.iter().zip(right.records).enumerate()` in ascending index order: `rule_start_line`, `charge`, `before` snapshot, `after` snapshot $\rightarrow$ `Record { index, field }`
    5. `left.records.len() != right.records.len()` $\rightarrow$ `Length { common_records, left_records, right_records }`
    6. `None` if all compared fields and record lengths match.
  * [`snapshot_difference`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs#L140-L159): Pure helper comparing [`Snapshot`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/reference_types.rs#L156-L165) fields by value in exact [`SnapshotField`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs#L47-L56) order (`program.as_ref()`, `control`, `environment`, `frames`, `stack_limit`, `remaining_fuel`, `initial_fuel`, `outcome`).

---

### 4. Actual Side Effects & Resource Bounds

* **Side Effects**:
  * Read-only SHA-256 verification of the 3 `FROZEN` files and in-memory JSON-to-Rust transcription check before and after test execution.
  * Python `-I -B` isolates from user-site/environment injection and disables `.pyc` bytecode writes.
  * Ephemeral `tempfile.TemporaryDirectory(prefix="sherlock-reference-")` holds the compiled `reference_check` test binary, runs the 29 unit tests single-threaded (`--test-threads=1 --nocapture`), prints JSON status to stdout, and unlinks the temporary directory upon exit.
  * Expected exit code is `0` (all 29 tests passing). Zero workspace or repository mutations; zero network, IPC, or background processes.
* **Termination & Resource Limits**:
  * Every call to [`first_difference`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs#L94-L138) in [compare_tests.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare_tests.rs) traverses at most 2 `StepRecord` elements over small finite `N01` ASTs/states (`fuel <= 2`, `stack_limit <= 9`), terminating in microseconds.
  * Bounded by outer `timeout 90s` and per-phase `--timeout-seconds 30` (compile and test).

---

### 5. Quarantine & Non-Authorization Limits

* **Exact Hash Pin**: This GREEN classification is strictly bound to [compare.rs](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs) SHA-256 `775f0c3825a8dff5fd700a539e0e24e4421674f0fab4d54d757da0b24615a216` and the 10 unchanged closure digests above.
* **H1 Quarantine**: Structural `PartialEq` over recursive AST/value/continuation structures in [`snapshot_difference`](file:///home/charl/Moriarty/.worktrees/sherlock-trace-compare-20261015/crates/mori-core/src/sherlock/compare.rs#L140-L159) inherits Profile A's unmetered host traversal and remains strictly quarantined under H1. It must not be wired to untrusted source pipelines, external inputs, CLI/LSP/MCP surfaces, or `/1` and `/2` compilation paths.
* **Zero Native Authority**: Native authority remains `0`. This classification authorizes only the ordinary host command above; it is not a source integration or merge approval, code audit sign-off, Candidate B decision, K/Lean/Quint/Clean execution, or proof/cryptographic authority.

END_GREEN_CLASSIFICATION

