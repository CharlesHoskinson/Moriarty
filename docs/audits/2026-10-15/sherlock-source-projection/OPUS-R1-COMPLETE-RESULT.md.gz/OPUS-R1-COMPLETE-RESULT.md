# R1′ verification: verdict

**R1′: RESOLVED.** **Security: APPROVE (unchanged).** The prior erratum stands as written.

## Argv comparison

I compared `first-link-failure-limits-argv.capture.json` with `limits-argv.capture.json` element by element. The only differences are:
- the unit name: `…-nix-masked-20261015` vs `…-stripped-20261015`
- the scratch bind, `TMPDIR` and dependency-manifest paths: `…-nix-masked-local-check/` vs `…-stripped-local-check/`

Everything else is byte-identical:
- `MemoryMax=4G`, `MemorySwapMax=0`, `TasksMax=256`
- `timeout --signal=TERM --kill-after=5s 90s`
- every bwrap flag
- `ulimit -f 16384` (16 MiB)
- checker path, interpreter flags, `--repo`, `--rustc` and `--dependency-directory`

## Binding

The first argv is tied to the failed run by its unit name and its `nix-masked-local-check` paths. This is the wrapper path I flagged in R1′. It is the same name/path linkage, held in a retained root record, that I accepted for the new run. A 16 MiB RLIMIT_FSIZE is also consistent with the observed SIGXFSZ in lld.

## README

"Unchanged … resource limits" and "records the same settings for the retained failed attempt" are now supported for both runs. No rewording is needed.

## Membership

`CAPTURE-MEMBERSHIP.json` lists both argv files and the README. The listed hashes match the SHAs stated in this packet: 6495cf67…, 21d4940b… and 04ceba99…. `first-link-failure-checker` still matches b1ccba27…. I did not recompute any SHA-256 myself, since tools were excluded. Readers should recompute them.

## Unchanged

- Native authority is 0.
- No U, M, MC, SP, G or B-T parent closes.
- S1 and O1–O7 stand.
- No remaining gap for R1 or R1′.
- The proposed filing and label/hash updates are publication bookkeeping only.

END_PUBLIC_PROJECTION_R1_COMPLETE_OPUS
