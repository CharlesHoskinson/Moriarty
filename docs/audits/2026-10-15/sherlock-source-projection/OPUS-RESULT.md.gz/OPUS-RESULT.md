# Moriarty source projection publication: independent security and claim review

## Verdict

**Security: APPROVE.** I found no blocking security defect in the inspected bytes. Artifact independence, signed/unsigned selection, the budget arithmetic and the no-clobber publication order all hold as described.

**Captured-result and publication claims: APPROVE WITH ONE REQUIRED DOCUMENTATION CORRECTION (R1).** Two README statements are not supported by any retained receipt. No code change is required.

The parent tasks U0–U7, M1–M17, MC/SP/G and B-T01–14 remain OPEN. Native authority stays 0. I am not requesting any admission or permission gate for public developer compile/deploy.

## Inspected coverage

**Full files read:**
- `crates/mori-backend/src/source_projection.rs` (e346ca73)
- `crates/mori-core/src/lib.rs`
- `sherlock/source_adapter.rs`
- `source_adapter_tests.rs`
- both `.mori` fixtures
- `crates/mori/src/commands/compile.rs`
- `SHERLOCK-REFERENCE-STATUS.md`
- the audit README, `CAPTURE-MEMBERSHIP.json` and the three captures
- `check-source-projection.py`

**Diff hunks only:** backend `lib.rs`, `SHERLOCK-IMPLEMENTATION-PLAN.md`, `tasks.md`.

**Not inspected (outside the packet):**
- `ir.rs`: `MAX_EXPRESSIONS`, `MAX_STATEMENTS`, `UInt` Serialize, identifier limits
- `parser.rs`: whether `parse` can emit shared ExprIds
- `runtime.rs`: `validate` depth/acyclicity, `expr_type`
- `intent.rs`: `hash_bytes`
- backend `compile`/`compile_signed`/`Target`/`Artifact`
- `proof_io::publish_new`, `core_io::read_source`
- `AGENTS.md`
- the failure capture's checker stdout

For the uninspected items I rely on the prior Opus F2 judgments as stated. I make no new judgment about them.

**Hash checks.** I could not recompute any SHA-256. I checked internal consistency only:
- Packet FILE headers match the capture source hashes for `lib.rs`, `source_adapter.rs`, the tests, both fixtures and the checker.
- Packet FILE headers match the membership entries for the README and all three captures.
- root-result `stdout_sha256` equals `source_capture_sha256`, which equals the core-check file hash (3bb00a11).
- Empty-stderr hash is correct.
- `source_hashes_before` equals `after`, and `changed_inputs` is `[]`.
- `source_rs_count` 47 matches the 47 `.rs` entries (10 root, 29 sherlock, 8 stage).
- The packet membership hash 468c0ae1 is unverified by me.

**Arithmetic checks:**
- 9216 × 66 = 608256.
- The backend test comment holds: cost = L² + 3L + 1, giving 361,801 for L=600 (fits) and 812,701 for L=900 (withheld).
- Weighted and threshold occurrence IDs and paths are consistent with tree-shaped parse order and `Let(name, value=0, body=1)`.

## Security assessment (Opus-owned)

Confirmed sound:

1. **Artifact independence.** `compile_reported` compiles first and propagates only compiler errors (`crates/mori-backend/src/source_projection.rs:33-37`). Preparation returns no `Result`, and `bound_paths` only rewrites projection metadata (`:52-73`). Artifact bytes cannot depend on the projection.
2. **Mode selection.** Signed/unsigned selection is keyed solely on `target.signed_policy.is_some()`, so a signed Target never reaches `crate::compile`. I independently concur with the prior judgment.
3. **Bounded work.** Both entry points validate before preparing. `charge` runs before any occurrence, path or AST allocation and before recursing into children (`source_adapter.rs` ~:164-170, ~:210, ~:255). This bounds occurrences at 9216 per report even if depth or acyclicity validation were weaker than assumed. The backend fold uses checked add/sub throughout (`source_projection.rs:57-59`).
4. **Publication order.** Both JSON strings are fully serialized before `create_dir`, which refuses an existing directory (`compile.rs:43-53`). Then come the projection, the circuits, and `artifact.json` last (`:54-55`). A partial failure leaves no completion marker. `json!` over these types is infallible, per the prior F2 judgment; I am not reapplying the rejected CLI fix.
5. **Disclosure in the envelope.** It carries only the source hash, program hash, format/ABI/relation strings and source-derived report fields. No Target, policy or key material appears.
6. **Transient memory bound.** Core path materialization is bounded at about 9216 × (MAX_STATEMENTS + 65) usize. Assuming MAX_STATEMENTS = 1024 (inferred from 9216 − 8192) and depth 64, that is about 80 MiB. The README correctly says the wrapper does not reduce this.

Non-blocking security observation:

- **S1 (low, conditional): string amplification.** Each occurrence clones its Core node (`~:258`), and each `Name` clones its string again into `Expr::Var` (`~:268`). The budgets bound counts, not string bytes.
  - **Condition:** a Program with shared ExprIds (a DAG) fans out to a Name with a long identifier. A fan-out like the existing 14-level test, ending in one long input name, yields up to about 2 × 9216 copies of that name in memory and output.
  - **Reachability:** library and JSON-deserialized callers of `compile_reported`. The CLI is affected only if `parse` can emit shared IDs.
  - **Safe case:** if Core bounds identifier bytes, or parsing is strictly tree-shaped, the CLI output stays linear plus the 608256-unit path term.
  - **Impact:** availability of the compiling process only (self-DoS, or a service that recompiles third-party sources). No integrity or authority impact. The README already disclaims any JSON-byte cap, so no claim is false.
  - **Follow-up:** verify the identifier bound in `ir.rs`/`validate` before any shared-service or bounded-output claim. This is not required for this child.

## Captured-result and publication claim findings

**R1 (REQUIRED, documentation only).** Two README statements are not evidenced by retained bytes.

- The README says the first attempt "hit SIGXFSZ while linking." The retained `first-link-failure.capture.json` records only the `compile-original-test-harness` exit code 1, an empty outer stderr, and a stdout hash (b1ccba27…). The checker JSON containing rustc's stderr is not retained, and the failing checker version and source hashes are absent. So neither the SIGXFSZ attribution nor "without changing the source" is verifiable from published bytes.
- The README cites "16 MiB per-file limit, 4 GiB memory, zero swap, 256 tasks." The only recorded limits are `caller-owned 4GiB`, `caller-owned 90` and the 30 s phase timeout. The 16 MiB, zero-swap and 256-task limits appear in no capture.

Fix with either of these:
- Add the failing run's checker stdout and the outer wrapper's limit receipt to `CAPTURE-MEMBERSHIP.json`.
- Reword both as root-reported and not in the retained receipts.

**Optional:**

| ID | Item |
|---|---|
| O1 | README says "608256 path elements plus occurrence charges." This reads as 608256 + occurrences. Suggested wording: "608256 units: one per path element plus one per occurrence." |
| O2 | README could state that Core's shared occurrence budget is consumed by partial work of actions that later fail (unsupported operator or exhaustion). An earlier unsupported action can therefore starve later actions, unlike the backend path budget, which charges nothing for withheld actions. This is correct for a work bound and metadata-only. |
| O3 | README could note that `source-projection.json` carries input/let/emit identifiers, literals and full expression structure that `artifact.json`/ZKIR may not. Publishing the output directory publishes them. |
| O4 | The plan's earlier "temporary Gemini 4 Argon … supersedes" routing line (outside the hunk, visible as hunk context) is stale beside the restored-Opus text. It is self-expiring by its own "until Opus availability is observed" clause. Also fix "Muse Wonder1.0" spacing. |
| O5 | `tasks.md` B-T02 row: "six tests over two handwritten AST specimens" could become "six tests, two of which check the specimens' handwritten ASTs." |
| O6 | Captures publish absolute local paths and a username. This is low-severity disclosure and acceptable if consistent with prior captures. |
| O7 | When backend/CLI execution is authorized, add a `run()`-level test for the `source-projection.json` leaf: raced, no-clobber, and output file set. This is a test only, not a CLI behavior change. |

**Verified accurate:**
- The occurrence and path budget semantics, including greedy order, no charge for withheld actions, and that direct Core callers still materialize quadratic paths.
- The envelope binds the source and compiled program, not the Target, mode or manifest.
- The report does not embed the generated function.
- Statements that the backend/CLI build, SDK tests and publication tests are UNRUN.
- Values 45/false are unobserved, and the result is a direct rustc run, not a Cargo build.
- The pre-execution "UNRUN" header is retained and acknowledged.
- No parent closure is claimed.

One precision note: the harness wraps the test file with its own imports against the public rlib. Core was built without `--test`, so the in-crate `#[cfg(test)] #[path = "source_adapter_tests.rs"] mod tests` wiring was never compiled. "Not a Cargo build" covers this; no change is needed.

## Retained gaps (not findings)

- **Backend/CLI build and execution:** `compile_reported` type correctness, `compile_signed` and the signed-mode projection are all unexercised.
- **Backend tests:** both are unrun. The 900-let test assumes `validate` and ledger9 accept 900 unused lets.
- **Publication:** `run()` publication is unrun. The SDK and publication consumers that enumerate the output file set have not been checked for the new leaf.
- **Provenance:** cached transitive, lexer and proc-macro provenance is UNPROVEN. Only selected externs and listed macros are hashed.
- **Semantics:** source-to-machine values and prefixes are unobserved. Correspondence between Core UInt overflow/underflow semantics and Sherlock checked u128 is unestablished.
- **Upstream checks:** S1's identifier and DAG preconditions, `hash_bytes`/`read_source` byte exactness, and `publish_new` were not re-inspected here.
- **Downstream:** recursive and general grammar, effects, bounded B representation, K/Quint/Lean correspondence, constraints/export/native proof, and stagenet proof/deploy/call/readback.

## Pending reviews

The README's final line, and `result_reviews: "PENDING"` in both `root-result` and `first-link-failure`, record this publication's own pending public-only reviews. They are publication bookkeeping, not code behavior. They do not affect the verdict above.

END_PUBLIC_PROJECTION_REVIEW
