# R1 correction review: verdict

**Security: APPROVE (unchanged).** The code, tests and oracles are unchanged. The bound I accepted still holds under the narrowed wording in the erratum below.

**R1: RESOLVED, except one residual clause (R1′).** The SIGXFSZ attribution and the new run's limits are now evidenced. Cross-run *limit* constancy is not.

## What the new bytes establish

**SIGXFSZ.** `first-link-failure-checker.capture.json` (b1ccba27…) matches the stdout hash recorded in `first-link-failure.capture.json`, so it is bound to that receipt.
- `compile-actual-core-library` returned 0. Phase 2 failed in rust-lld at `ftruncate` / `FileOutputBuffer::create`, with `ld terminated with signal 25 [File size limit exceeded]`. Signal 25 is SIGXFSZ on x86_64 Linux.
- There is no run phase, and status is `failed`. "Compiled Core … hit SIGXFSZ while linking … tests did not run" is now supported.

**Source constancy, failed side.** `source_hashes_before` equals `after`, and `changed_inputs` is `[]`.
- There are 47 `.rs` entries: 10 root, 29 sherlock, 8 stage, the same set shape as the successful capture.
- The failed run's harness command carries no strip flag, which fits the stated encoding change.

**Cross-run comparison.** Both captures are now published, so this is checkable by readers. `core-check.capture.json` is not in this packet, so I did not re-compare the hashes key by key here.
- The comparison keys are adapter d7fba670, tests 22feec2f, lib 94422a1b, fixtures caba5067 and 073474d1, plus ir, parser and runtime.
- The difference should appear only in the checker, manifest or harness hashes.

**New-run limits.** `limits-argv.capture.json` records:
- `MemoryMax=4G` (4 GiB)
- `MemorySwapMax=0`
- `TasksMax=256`
- `timeout 90s`
- `ulimit -f 16384`, which is 1 KiB blocks in bash, so 16 MiB. It is inherited by python, rustc, cc and lld.

These match the README. The argv is linked to the successful run by unit name and the `stripped-local-check` scratch and manifest paths, not by a hash inside core-check. "Records the settings used" is an accurate description of a retained root record.

## R1′ (required, documentation only): first-run limits are unevidenced

The README says "within the **unchanged** 16 MiB per-file limit, 4 GiB memory, zero swap, 256 tasks" and "without changing … **resource limits**". For the first attempt, the retained bytes show only the following:
- 4 GiB and 90 s appear in the failed checker's `limits`, as caller-reported strings.
- SIGXFSZ proves that *some* RLIMIT_FSIZE applied, but not that it was 16 MiB.
- Zero swap and 256 tasks are unrecorded.

The first run also used a different wrapper path (`nix-masked-local-check`).

**Missing bytes:** the first attempt's outer argv. Fix with either of these:
- Add that argv to `CAPTURE-MEMBERSHIP.json`.
- Reword, for example: "The first attempt's retained checker records 4 GiB and 90 s; its file-size, swap and task settings are root-reported, not retained."

## Erratum to the prior review (security item 3)

**Prior text:** "`charge` runs before any occurrence, path or AST allocation and before recursing into children."

**Corrected text:**
- Each occurrence is charged before its `SourceOccurrence`, the record's `body_path` clone, the `source_expression` clone and its AST node are allocated.
- A child's path is *not* covered. The caller clones and extends it before the callee's `charge`. This happens in the `child` closure in `map_expression`, and in the let loop's `value_path` in `prepare_validated_action`.
- If that charge fails, the vector is dropped as the error propagates.
- Exhaustion ends the current action and leaves `remaining = 0`. Every later action then fails at its first charge, which precedes any clone. An emit-only action passes an unallocated `Vec::new()`.
- Unsupported-operator sites return after their charge and before any child allocation.

**Disposition:**
- At most one uncharged path vector exists per report, or per direct preparation. Its length is no greater than a charged path's, and it is transient.
- The 9216-occurrence bound is exact. The transient-memory estimate changes by at most one path.
- The acceptance of the bound by me and by prior Opus reviews stands. Only the description is narrowed.
- The source comment on `charge` ("BEFORE any occurrence/path/AST allocation") has the same imprecision. It is non-blocking, and I am not requesting any change to frozen source.

## Unchanged

- Native authority is 0.
- No U, M, MC, SP, G or B-T parent closes.
- S1 and O1–O7 stand as previously stated. O1 now appears in the README text.
- `result_reviews: PENDING` remains publication bookkeeping.

END_PUBLIC_PROJECTION_R1_OPUS
