# Independent Security Source & Proposal Integration Audit (`0da00ed25a04a6120e7a8383cd3f628da09937ac` over `609ed892f8a0561dc5a7b6b53a03fea2a4a9a2b5`)

- **SOURCE_INTEGRATION:** `APPROVE` (unadopted candidate data/metadata integration and exact K source membership only)
- **SPEC:** `APPROVE` (as an explicitly unadopted, non-frozen candidate proposal record; `0` source conflicts against `models/sherlock/k/main.k`, preserving all open Phase 0 / `S-B-*` gates)
- **QUALITY:** `APPROVE` (exact 42-rule coverage, hash/provenance integrity, and honest AGY `returned_model_id: null` disclosure)
- **Scope & Authority:** Source-packet audit only. No tools, filesystem, commands, network, or delegation used. Native authority `0`; no policy adoption vote, no Phase 0 freeze, no runtime/model/circuit/stagenet attestation.

---

## 1. File, Hash, and Provenance Verification

All 12 changed/added file bindings in the packet are consistent across `openspec/changes/sherlock-universal-interpreter-design/SHA256SUMS` (`5b7fbccaec25c92bf1b38c76df3547e2898068f362b281f37620a35cfddb4fbc`), `publication-binding.json` (`372d003f8414561d55391f94bb7fba827e234a7e84b96b662d72c3523e531d98`), and `docs/audits/2026-10-15/sherlock-phase0-legacy-rows/SOURCE-MEMBERSHIP.json` (`09789620fd14a88bc1d6dcc32b2973635770761b5c2110e1f9757c9ab6447b09`):
- `models/sherlock/reference/security-legacy-rows-candidate.json` (`d9d9b0a7e36457275a7900a9d54b83751efbd424b104df5d1470f3a15e3292e0`) is value-identical to the raw author report (`1272bcaa332736e254a37ea0edd660dd73f99c94b851b9b7c56b487504bd970b`), with root applying JSON pretty-printing only.
- `models/sherlock/reference/rules.json` (`71b4e4e67173cf7da6fbff8cd7dfbb36533250278565469b67bfd0b77468ad2a`) preserves all 113 original `k_rules` entries unchanged (`normative_k_rules_canonical_json_sha256`: `ba366b8d948a9845c22d5acf434c0ec4af17671fbdfe65f8ff94497443bf0ed4` from `models/sherlock/k/main.k` `b3746ff51dd7999b046ccb23237595605420adcfeebc0c04c0ad0f1396b11d41`), adding only `proposed_b.legacy_completion.security_legacy_rows_candidate_ref` (`adopted: false`, `status: "CANDIDATE_PROPOSAL_ONLY_NOT_ADOPTED_OR_FROZEN"`) and a literal en-dash escape normalization in `S-B-REPRESENTATION.scope`.
- `models/sherlock/reference/README.md` (`829a93e8903bad22a249070f2bdffbb13a6797d9c0ae768d01f66d9778bb95f0`), `docs/audits/2026-10-15/sherlock-phase0-legacy-rows/README.md` (`f154169105f959ef0ebe2ae7606eaf99c43feb774f0956d5496d54a03d1c524a`), and `openspec/changes/sherlock-universal-interpreter-design/tasks.md` (`60ee83b6de77152913e592c24ace7741db4da19499f8365da5f9de978ec267fa`) accurately link the candidate as unadopted and unexecuted, with `AUTHOR.json` (`f49ca46070c6c514da9da4318f3b59e835457724b0bfc6e2289b0c090a050b3e`) disclosing `requested_model: "gemini-4-argon-high"` and `returned_model_id: null`.
- Historical Opus files (`openspec/changes/sherlock-universal-interpreter-design/security-candidate-b.md` `128635e0d8d56b7e3985aeb85fc101dcbf5d25a531c1811e261e20806e7402df`, `security-requirements.md` `dcd1527312768355eae494b28df02234d509a63acfee8ea62708fea186f91b89`, `security-author-provenance.json` `d16125f537e6a1bf1e3bfd7f5af8a6e175b115cd0aa0c43d98892bdfd258e6c6`, and `models/sherlock/reference/security-phase0.md`) are untouched.

---

## 2. Independent Audit of All 42 K Rules (5 Administrative + 37 Machine)

### A. 5 Administrative Rules (`administrative_5_rows_separate_cost_0`, all charge `0`)
1. `k.admin.startup.valid` (lines 74–77): `uiRun(P,E,F,L) => uiEval(E)` when `F >= 0 && L >= 0`; sets `code=>P`, `fuel=>F`, `initialFuel=>F`, `stackLimit=>L`, with `stack=uiNoFrames()`, `depth=0`, `env` unchanged. Exact match.
2. `k.admin.startup.invalid` (lines 78–79): `uiRun(_,_,F,L) => uiError(1)` when `F < 0 || L < 0`; raw error `1`, no cells initialized/mutated. Exact match.
3. `k.admin.publish.value` (lines 80–81): `uiRet(V) => .K` with `<stack> uiNoFrames() </stack>` (`D == 0`) and `<out> uiPending() => uiDone(V) </out>`. Exact match.
4. `k.admin.publish.error` (lines 82–83): `uiError(C) => .K` with `<out> uiPending() => uiRejected(C) </out>` regardless of `<stack> S` or `<fuel> F`. Exact match.
5. `k.admin.publish.exhausted` (lines 84–86): `C:UIControl => .K` with `<fuel> 0 </fuel>`, `<out> uiPending() => uiExhausted() </out>` when `notBool uiTerminal(C, S)`; preserves `S`, `D`, `Rho`. Exact match.

### B. 37 Charged Machine Rules (`exact37rows`, all require `F > 0` and charge `1`: `F => F - 1`)
Verified in exact `main.k` source order (lines 102–226):
- **1 Push-Accept Rule (`frame_delta: +1`):**
  - `k.machine.push.accept` (135–139): requires `D < L`; transitions `uiPush(Fr,C,Rho) => C`, `<env> _ => Rho </env>`, `<stack> S => uiFrame(Fr,S) </stack>`, `<depth> D => D + 1 </depth>`.
- **3 In-Place Top-Frame Replacement Return Rules (`frame_delta: 0`, replace top frame, do NOT pop):**
  - `k.machine.return.let` (145–148): `uiFrame(uiLetF(X,B,Rho),S) => uiFrame(uiScopeF(Rho),S)`, `<env> _ => Rho[X <- V] </env>`, `D` unchanged.
  - `k.machine.return.left` (149–152): `uiFrame(uiLeftF(Op,B,Rho),S) => uiFrame(uiRightF(Op,V),S)`, `<env> _ => Rho </env>`, `D` unchanged.
  - `k.machine.return.arguments.next` (177–180): `uiFrame(uiArgsF(N,Vs,uiExpr(A,Rest),Rho),S) => uiFrame(uiArgsF(N,uiAppend(Vs,V),Rest,Rho),S)`, `<env> _ => Rho </env>`, `D` unchanged.
- **2 Peek-on-Error Return Rules (`frame_delta: 0`, retain top frame and current `<env>`):**
  - `k.machine.return.if.invalid` (169–172): on `!uiHasType(V, uiBoolT())`, emits `uiError(5)`; `<stack> uiFrame(uiIfF(_,_,_),_) </stack>` is NOT popped, `D` is unchanged, and saved `Rho` is NOT restored.
  - `k.machine.return.call.invalid` (190–193): on `!uiHasType(V, T)`, emits `uiError(6)`; `<stack> uiFrame(uiReturnF(T,_),_) </stack>` is NOT popped, `D` is unchanged, and caller `Rho` is NOT restored.
- **8 Popping Return Rules (`frame_delta: -1`, `<depth> D => D - 1 </depth>`):**
  - `k.machine.return.right` (153–156, pops `uiRightF(Op,A)`, `env` unchanged, stages `uiPrimResult(uiBinaryResult(Op,A,V))`), `k.machine.return.unary` (157–160, pops `uiUnaryF(Op)`, `env` unchanged, stages `uiPrimResult(uiUnaryResult(Op,V))`), `k.machine.return.if.true` (161–164, pops `uiIfF(A,_,Rho)`, restores `Rho`), `k.machine.return.if.false` (165–168, pops `uiIfF(_,B,Rho)`, restores `Rho`), `k.machine.return.match` (173–176, pops `uiMatchF(Cs,Rho)`, restores `Rho`, transitions to `uiCases(V,Cs,Rho)`), `k.machine.return.arguments.final` (181–184, pops `uiArgsF(N,Vs,uiNoExprs(),Rho)`, restores `Rho`, transitions to `uiInvoke(N,uiAppend(Vs,V))`), `k.machine.return.call.valid` (185–189, pops `uiReturnF(T,Rho)` when `uiHasType(V,T)`, restores `Rho`), `k.machine.return.scope` (195–198, pops `uiScopeF(Rho)`, restores `Rho`).
- **8 Push-Staging Rules (`frame_delta: 0`, stage `uiPush(...)` in `<k>` without mutating `<stack>`, `<depth>`, or `<env>`):**
  - `k.machine.eval.let` (114–116), `k.machine.eval.binary` (117–119), `k.machine.eval.unary` (120–122, passes `Rho` in `uiPush` without capturing `Rho` inside `uiUnaryF(Op)`), `k.machine.eval.if` (123–125), `k.machine.eval.match` (126–128), `k.machine.eval.call.arguments` (131–133), `k.machine.bound.valid` (208–210, captures `Old` in `uiReturnF(T,Old)` and defers `New` to `push.accept`), `k.machine.cases.hit` (220–222, stages `uiScopeF(Rho)` and defers `Bs` to `push.accept`).
- **15 Non-Frame Evaluation / Dispatch / Error Rules (`frame_delta: 0`, `<stack>` and `<depth>` unchanged):**
  - `k.machine.eval.literal.valid` (102–104), `k.machine.eval.literal.invalid` (105–107, `uiError(2)`), `k.machine.eval.variable.present` (108–110, reads `X |-> V` in `Rho`), `k.machine.eval.variable.absent` (111–113, `uiError(3)`), `k.machine.eval.call.empty` (129–130), `k.machine.push.refuse` (140–143, `D >= L` => `uiError(4)`, discards candidate frame and target `Rho`, preserves `S`, `D`, and current `env`), `k.machine.invoke.find` (200–201, reads `<code> P`), `k.machine.enter.missing` (202–203, `uiError(7)`), `k.machine.enter.bind` (204–205), `k.machine.bound.invalid` (206–207, `uiError(8)`), `k.machine.cases.empty` (212–213, `uiError(9)`, after `uiMatchF` was already popped in `return.match`), `k.machine.cases.try` (214–216), `k.machine.cases.miss` (217–219), `k.machine.primitive.value` (223–224), `k.machine.primitive.error` (225–226, propagates `uiPrimError(C) => uiError(C)` including `C = 10, 11`, after `uiRightF`/`uiUnaryF` was already popped in `return.right`/`return.unary`).

### C. Fuel vs. Error Precedence
The candidate accurately states K's exact precedence (matching `security-candidate-b.md` A1/A2):
- At `F == 0`, any nonterminal control (`!uiTerminal(C, S)`), including states poised to trigger errors `2..9` or `uiPrimResult(uiPrimError(C))`, cannot fire a machine rule and instead fires `k.admin.publish.exhausted` (cost `0`) -> `uiExhausted()`.
- At `F == 1`, an error-producing machine rule decrements `F => 0` and produces `uiError(C)`. Because `uiTerminal(uiError(C), S)` holds for all `S`, `k.admin.publish.error` fires (cost `0`) -> `uiRejected(C)`.

---

## 3. Source Facts vs. Proposed B Mapping & Consequential Admission Narrowing

1. **Pure K Source Facts:** `<stack>` is top-first `uiFrame(Fr, S)`; `<depth> D` and `<stackLimit> L` are unbounded K integers admitted for any `F >= 0 && L >= 0`; overflow compares `D` against `L` (`D >= L` -> `uiError(4)`).
2. **Proposed B Physical Mapping (Unadopted Proposal):** Bijects `D` to `len(active_frames)` in a bottom-first array `frames[0..D-1]` (`frames[0]` bottom/oldest, `frames[D-1]` top `Fr`), pushing at `frames[D]`, replacing in-place at `frames[D-1]` for `return.let`/`return.left`/`return.arguments.next`, peeking in-place at `frames[D-1]` on `return.if.invalid`/`return.call.invalid`, and popping `frames[D-1]` on the 8 popping returns, while comparing `D` exclusively against `runConfig.stackLimit (L)`.
3. **Consequential Admission Narrowing (`0 <= L <= physicalBounds.frames`):** Requiring `L <= physicalBounds.frames` at admission (`CapacityNotAdmitted` otherwise) so `0 <= D <= L` prevents hitting `physicalBounds.frames` before `D >= L` (`uiError(4)`) is a **consequential representability restriction**, NOT a K source fact. It requires future substantive decision votes before Phase 0 freeze.

---

## 4. Dissent, Limits, and Necessary Fixes Before Freeze

- **Source Conflicts / Dissent:** `0` conflicts with `main.k` or `security-candidate-b.md`.
- **Necessary Fixes / Open Obligations Before Any Phase 0 Freeze (none required for this unadopted catalog integration commit):**
  1. Reconcile `proposed_B_physical_mapping` pop/replace operations with `security-candidate-b.md` A3/A4 `StepInv` (explicitly zeroing released frame slot `frames[D-1]` on `pop_delta_minus_1` and unused trailing fields on `replace_in_place_delta_0`).
  2. Resolve and vote on `L <= physicalBounds.frames` admission narrowing and all remaining `S-B-*` rows (`S-B-FAILURE-ROWS` helper failure charges, `S-B-CAP-PRECEDENCE`, `S-B-RESOURCE-POLICY`, `S-B-REPRESENTATION`, `S-B-SECURITY-ACCEPTANCE`), `H1`, `B1–B8`, codec/StepInv proofs, Clean/K/Quint/handwritten/native equivalence, Midnight stagenet qualification, and full `U/M/MC/SP/G/ZR/MNR/OSR` exits.

END_LEGACY_REVIEW

