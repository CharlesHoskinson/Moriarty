# Classification: actual comparison closure for `check-reference.py`

**Verdict: fits ordinary host checks, with the conditions below. No blocker.** This covers command safety and the execution boundary only. It does not judge correctness, implementation acceptance or design.

## What I inspected

- **Python driver** (`9a3800ba…`):
  - It uses only the standard library and checks the hashes of the three frozen inputs before reading them.
  - `main.k` is only hashed, never executed.
  - The JSON files go through `json.loads` and then a fixed-shape transcription into Rust.
  - Strings must be printable ASCII. Only `"` and `\` get escaped, and both escapes are valid in Rust.
  - Integers must have exact type `int` and be nonnegative.
  - Field names, structure and layout are fixed by the script. JSON content can only become literal values, never Rust syntax. No evaluator computes expected values.
  - Commands run from argv lists with `shell=False`. There are only two: the given `rustc` binary and the built test executable.
  - Each command has a 1–60 s timeout. After the test, the script rechecks the hashes of all ten source and frozen files.
- **Wrapper:** it names only `mod.rs` and `reference_oracles_tests.rs` via `#[path]`. Because the `#[path]` target is a `mod.rs` file, it also pulls in `reference.rs`, `reference_types.rs`, `reference_display.rs` and (under `--test`) `reference_tests.rs`. I inspected all four.
- **Rust sources:**
  - They use only `std::sync::Arc`, `BTreeMap`, `String`/`format!`, iterators and asserts.
  - No `std::fs`, `std::process`, `std::net`, `unsafe` or FFI.
  - The only external input is the compile-time `include!(env!("SHERLOCK_ORACLES_RS"))` of the generated literal file. At runtime, nothing reads the environment or the filesystem.
  - Failures end in panics: asserts, `unreachable!`, `expect`, and u128 underflow in a debug build. These stop the test process; they are not memory-unsafe.
- **Toolchain:** the `rustc` path is the toolchain binary itself, not the rustup proxy. So it does no toolchain sync or download. There is no Cargo, no build scripts, no proc macros and no external crates. The one subprocess `rustc` starts itself is the normal system linker (`cc` found via PATH), which is ordinary host compilation.

## Conditions for this classification

1. **On-disk bytes must match the inspected hashes.** All seven `SOURCE_PATHS` must match the SHA256 values above. The script only *logs* these hashes in the `inputs` event; it does not enforce them before compiling. Check with `sha256sum` before the run, or at least compare the logged `inputs` record afterward. Any mismatch puts the run outside this classification, and the changed bytes need fresh inspection.
2. **Rust toolchain:** the logged `rustc` hash is recorded as provenance. Changing the toolchain path is a new command.
3. **Python environment:** run from the repo root under the outer `timeout 90s`.
   - Because the command uses `-B` but not `-I`, `models/sherlock/reference/` comes first on `sys.path`.
   - That directory must not contain `.py` files that shadow standard-library modules (`json.py`, `hashlib.py`, …).
   - `PYTHONPATH` and `PYTHONHOME` must be unset or harmless.
   - `python3 -I -B` would remove this dependence and would not change the script's behavior. I recommend it, but it is not required for an ordinary check of your own repo.
4. **Exact flags:** `--timeout-seconds 30`, so compile plus test is at most about 60 s, inside the 90 s outer bound. GNU `timeout` signals its process group by default, which also covers a stray linker.
5. **Scope of the run:** the six frozen normal programs (N01–N06), all 92 literal ordinary-fuel prefixes, and the one existing stub-era unit test (`reference_tests.rs`). That is all.

## Not blockers, but should be reported accurately

- **Leftover temp files:** if the outer timeout's SIGTERM kills Python, `TemporaryDirectory` is not cleaned up. The generated `.rs` files and the test executable may remain under `$TMPDIR/sherlock-reference-*`. They are harmless and can be deleted.
- **Postcheck can be skipped:** it runs only after a successful compile. If compilation fails, the script returns before rechecking hashes. Treat a compile failure as having no frozen-candidate claim.
- **No memory cap:** only time is bounded. For these small normal programs that is fine.
- **Size of JSON values:** very large fuel or `stack_limit` values would only lengthen run time, which the timeout bounds. Out-of-range literals fail at compile time. Because the JSON hashes are frozen, the content is fixed. I have not seen the JSON content itself, but the transcription rules keep the run safe whatever it contains.
- **Possible exit codes:**
  - 0: pass.
  - 101: test failure.
  - 124: timeout.
  - 2: input or hash error.
  - Any nonzero code from `rustc` means a compile failure.
  
  Report whichever occurs verbatim, including the `inputs`, `generated`, `executable` and `comparison` records.

## Outside this classification

- SDK, native, model and proving actions of every kind, as you excluded.
- Any change to the seven sources, the frozen inputs or the command line.
- Any use of a result as a correctness, refinement or acceptance claim. The script itself labels the result "finite normal reference comparison only".

No change to authority, campaign or counters.
