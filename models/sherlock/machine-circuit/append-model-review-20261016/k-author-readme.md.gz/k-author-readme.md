# ValueSlots EXT/COPY: standalone K source counterpart

Status: **UNADOPTED MODEL SOURCE; ALL UNRUN; native authority 0**. This is a small reference projection of the A177/A181 ValueSlots relation, not a machine interpreter, accepted machine step, circuit component, proof or language restriction. P3 r1 and its reviews are the expectation basis. Root's later r2 notification is retained as unreviewed; it does not adopt a new relation here.

`value-slots.k` contains syntax, pure functions and one actual `<k>` rewrite. It requires only the same framework `domains.md` used by pinned public `models/sherlock/k/main.k`; it neither imports nor changes that main module. `normal-checks.k` imports the new pure-function module and contains nine normal Boolean check terms. Each `examples/*.vs` is a literal request; its `.expected` file is a literal final K-cell term. Nothing has been parsed, compiled or executed.

## Projection and requirements

| Shared abstract field | K term / scope |
|---|---|
| ValueRef `{space,index}` | `vsRef(S,I)`, space 0 Constant or 1 Data, exact integer index; copied identity only, never semantic Eq |
| Slice `{start,length}` | `vsSlice(S,M)`; only empty form is `(0,0)` |
| fixed ValueSlots array | `VSRefs`, an explicit finite constructor list of exactly capacity rows; padding row `vsRef(0,0)` |
| activeLength | second `vsState` field; all earlier rows active, all later rows zero |
| holders pair | fourth/fifth `vsState` fields; acting holder index is 0 or 1; arbitrary overlap and identical slices allowed |
| capacity | first `vsState` field, symbolic supplied nonnegative Int; no production default |
| referenced Constant/Data active bounds | `vsBounds(K,D)` request parameter, immutable abstract domain assumptions, not new L4 StateBlock columns |
| tooling result | `vsAppended(branch,state)` or `vsCapacity(needed,limit,firstOverflowIndex)`; no MachineOutcome constructor |

The model carries logical nonnegative integers, not L4 byte lanes. Space tags match L4 exactly; indices are checked against their selected active bound. Physical widths, byte bridges, actual Constant/Data contents and their typing remain outside this projection. Every reference denotes an abstract token with an externally supplied meaning; equal tokens are not used to decide semantic value equality.

| Rule family / branch | Preconditions | Local post relation |
|---|---|---|
| common valid input | K,D,C >= 0; 0 <= A <= C; table length C; every active row is a valid ref; inactive rows `(0,0)`; both slices canonical-empty or nonempty bounded within A; actor 0/1; new ref valid | no normalization or coercion of malformed input; domain is explicit |
| EXT | m > 0 and s+m = A; A+1 <= C | write new ref at A; acting slice `(s,m+1)`; active A+1 |
| COPY | not EXT; A+m+1 <= C | copy original rows s..s+m-1 to A..A+m-1 in order; write new ref at A+m; acting slice `(A,m+1)`; active A+m+1 |
| Capacity | valid input, selected branch needs more than C | tooling `vsCapacity(A+delta,C,C)`, no post-image and no MachineOutcome |
| untouched holder | either successful branch | exact slice retained and same materialized references; no row below pre-active length is a write target |
| outside domain | input violates explicit preconditions | no request transition specified; not a semantic error, acceptance flag or malformed-input test contract |

Capacity includes physical ValueSlots storage only. It neither implements nor waives full39 P6 frame/control capacity, semantic stack/fuel behavior or other arena checks. Since all candidate writes begin at A <= C in increasing order, the first overflowing slot for an over-capacity branch is C. This located refusal is the normal storage boundary requested by the owner, not a security test or a source rejection.

`vsAttempt` derives the branch through `vsSelect`; requests do not supply a selector. The helper `vsPlan` is an internal pure function under that call precondition, not an alternate accepted input interface. Partial indexing/update functions are used only with the valid-input and capacity preconditions. This packet adds no untrusted consumer or host execution path.

## Source relation and independent oracle

Public Rust `reference.rs:243–254` appends the returned value to the completed vector before choosing nonempty-rest A177 or empty-rest A181. Public K `main.k:177–184` consumes `uiAppend`, whose independent structural recursion is at 285–287. The full39 map retains complete ordered argument meaning, saved environment, frame/control differences and charged fuel. This projection deliberately models only the common ValueSlots relation. It does not model POP, Eval/Invoke, environments, fuel, ProgramBlock or all eight Snapshot cells; it cannot establish a full A177/A181 step.

The physical implementation uses `vsAt`, `vsSet` and `vsCopyRows`, with copy reads taken from the frozen original table. The independent `vsSourceAppend` oracle recurses over a materialized sequence and does not call the physical selector, delta, row-write or commit helpers. Observation uses independent prefix/drop functions. Normal checks compare the actual pure relation result to literal expected whole tables/holders/lengths, then compare its acting projection to source append, its untouched projection to the pre-image and every pre-active row to the pre-image. Equality in these checks compares exact reference structures, never values reached through the references.

## Literal normal expectations

The nine expectations were frozen before implementation in `expected.json` and `TESTS-FIRST-FREEZE.json`. Their K representations are mechanical serializations of that literal JSON; no evaluator, selector, row-update helper or Quint implementation produced them. Specimen K=D=4 and V in {1,7,8,9} are model examples only, not production bounds/admission values.

EX4 uses `ra=C2`, `rx=D2`, `rg=D3`, `rc=C3`. Four initial active rows are concrete retained filler references `[C0,D0,C1,D1]`. The outer holder first copies ra to row4. The inner holder copies rx to row5 while the saved outer slice `(4,1)` retains `[ra]`. The outer then copies its frozen `[ra]` and appends rg at rows6–7, giving `(6,2)`, while the inner still observes `[rx]`. Its later tail extension adds rc at row8, giving `(6,3)`. The fixture assumes the omitted execution of g adds no further ValueSlots, as Muse explicitly required; the general selector always uses the actual current A.

A V=7 third step needs8 and refuses at row7; a V=8 final step needs9 and refuses at row8. The V=9 final step exactly fills capacity. An additional empty-origin case confirms `(0,0)` chooses COPY even at A=0. The two shared-holder cases start with both slices `(4,1)`: holder0 extends; holder1 retains `[ra]`, then copies `[ra,rx]` after the tail moves. Holder0 continues to observe `[ra,rg]`.

Future falsifiable predicate: the saved outer slice materializes exactly the frozen old references after the inner append, and the next outer COPY materializes those references followed by the new reference. All earlier rows and the co-holder projection agree exactly. These are proposed checks, not observed results or proofs.

## Dependencies, tool evidence and retained gates

`INPUTS.json` pins exact public Rust/K, full39 map/adoption, all seven frozen L4 files and complete r1 author/challenge/normal receipts. L4 design ValueRef/ValueSlots/slice/append clauses and crosswalk columns/widths are the scoped normative dependencies. This is targeted source inspection, not a new audit of every unrelated rule or all L4 mechanisms. Existing K constructors, [function] rules, arithmetic guards, `==K`, KItem injection and configuration syntax are the syntax basis; every new non-framework helper is defined locally.

K tool availability and exact framework `domains.md` identity are **UNKNOWN**. No engine detection, help, K/Java process, parser or setup was attempted. Thus no exact future command is asserted. Minimum evidence before proposing execution is a pinned trusted K toolchain and builtins closure with documented module/syntax-module invocation, plus a separately reviewed finite command/resource scope. No setup loop is requested or authorized here.

Fresh normal and designated Opus source reviews remain required. The P3 relation remains unadopted in this packet; full39 adoption alone did not select physical mechanisms. No native/resource/counter/tier grant is inferred. FullStepInv, G4, P2–P6, F4, widths, semantic equality, source/target correspondence, B, general ADTs, all financial/ledger/native/target and U0–U7/M1–M17/MC/SP/G gates remain open. C4 forbids dependent circuit edits until admitted A102 compilation; failure requires registration revert, not an unreviewed hotpatch.

Requested/acting author routing: GPT-6 Astra high. The local agent has no separate provider-return identity attestation; no external model or subagent was invoked. Quint's independent unfrozen implementation and expected-output producer were not read. All outputs are confined to this new runtime folder; checkout, main.k, wrappers and previous freezes remain unchanged.
