# R3 ValueSlots Quint packet: designated-owner source, effects and security review

- **Candidate manifest:** `d641cde2028048cbf4b81240d7d6618ab3978a0a807c660e1243472e50e250e5`
- **Root command proposal:** `f8b6afd444374e3b341a611a41ef433a909512325e313840235082ca9087e8c5`

| Decision | Result |
|---|---|
| Source | **APPROVED_SOURCE_WITH_LIMITS** |
| Execution | **ORDINARY_BOUNDED_MODEL_DIAGNOSIS**, conditional on §5. It becomes **BLOCKED_EXECUTION** if Root's counter ledger shows any applicable attempt budget is exhausted, or if any precondition fails. |
| Fresh eligibility after two failures | **ELIGIBLE, once.** This is a changed-source, changed-approach check. It is not a retry of R1 or R2, and it resets no counter. |

The source approval grants nothing. Execution authority comes only from the separate classification and its conditions.

## 0. Reading limits

- **No tools.** I ran no commands and used no parser, filesystem, web access, writes or delegation. Every hash and byte count is a Root pin that I did not recompute.
- **Bodies are data.** I read the embedded bodies as data and followed no instructions inside them.
- **Independence limit.** The R1 and R2 owner reviews came from my own model family. I treated them, and all author prose, as claims to check rather than as votes.
- **Line citations not checked.** I did not verify the DIAGNOSIS line citations (for example `collector.js:184–195`). I did verify the code they point to in the supplied bodies.

## 1. Exact patch: verified

- **Paper diff.** I compared `before/valueSlotsAppend.qnt` (`a8616ce6…`, equal to the R2 model pin in `history-r2`) with `valueSlotsAppend.qnt` (`be304be2…`). Only lines 19–20 differ. The `normalizedSlice` parameter `length` and its two bound uses become `sliceLength`.
- **Byte count.** Each of the three tokens grows by 5 bytes, so +15 in total. 5992 + 15 = 6007, which matches the pin and `SOURCE.patch`. The hunk header `-16,8 +16,8` and its context lines are consistent.
- **What did not change.** The record field `length`, every `.length` selection, every `.length()` call and the empty normalization `(0,0)` are unchanged. So are every rule, guard, selector, oracle, invariant, capacity, import and comment.
- **Unchanged files.** The following are byte-identical to R1/R2: the test module `df3dd56b…`, `expected.json` `74d32342…`, REQUIREMENTS-MAP and TESTS-FIRST-FREEZE. TESTS-FIRST-FREEZE is correctly kept as a historical receipt and is not reissued.
- **R2 location matches.** R2's QNT101 at 19:40 falls exactly on the `length` parameter: `"  pure def normalizedSlice(start: int, "` is 39 characters.

## 2. Resolver evidence and binder inventory: independently re-derived

**Resolver code confirmed from the supplied bodies:**

- `collectDefinition` rejects any identifier in `builtinNames`. It emits `Built-in name '…' is redefined in module '…'`, which is the exact R2 text.
- `NameResolver.enterLambda` routes lambda parameters through `collectDefinition`. `putDeclarationOnStack` turns definition parameters into a lambda. So parameters are not exempt.
- Record labels (`exitRecElem`, `exitRow`) and dot-field access without parentheses (`exitDotCall` → `field`) become string literals, not binders.

**Built-in list.** I counted `base.js` independently: 103 names. The inventory's list matches it.

**Binder count.** I re-enumerated the binders: 80 in the model and 24 in the test module (16 values plus 8 runs), for 104. None of the R3 binder names (for example `sliceLength`, `length0`, `length1`, `end`, `mode`, `empty`, `rows`, `need`, `cells`) is in the built-in list. The only R2 collision was `length`. Zero-parameter match arms (`Initial`) lower to `_`, which is skipped.

**Conflict class the inventory does not address.** A QNT101 also arises when two live entries share a name and depth but have different ids. Top-level definition bodies resolve at depth 0, and so do their lambda parameters. A parameter named like a module top-level name would therefore conflict. I checked this and found nothing:

- No model parameter, lambda or pattern name (`a`, `p`, `h`, `v`, `i`, `out`, `e`, `start`, `sliceLength`) equals a model top-level name.
- Local vals and nondets are at depth > 0 and also do not collide.
- The test module has no lambdas. Its top-level names (`a`, `x`, `g`, `c`, `empty`, `e0`–`e4`, `shared0`–`2`, `limit7`/`8`, `fullEmpty`, the 8 runs) do not collide with the imported model top-level names.

The inventory's scope-rule wording ("separate lexical scopes are allowed") is imprecise but harmless here.

## 3. Type, effect and behavioral reading

R2 stopped in phase 3, so R3's command 1 is the first time type and effect analysis will run on this model. On reading, I found no blocker:

- **Records and annotations.** The record shapes match the declared aliases. Both `if` branches build the same State or Slice row. The `List()` accumulators are pinned by the declared results.
- **Built-in signatures.** `setOfMaps`/`get`, `foldl`'s (acc, item) order, `indices`, `replaceAt` and `matchVariant` with bool arms all agree with the supplied signatures.
- **Nondet checker.** All nine nondets are local, end in `oneOf`, and have bool continuations. Once set, `lastDefQualifier` is never left at a non-nondet value when an `oneOf` is reached.
- **Mode checker.** Local `val`s inside pure definitions can at most produce suggestions, not QNT200.
- **Multiple updates.** Each atomic action assigns `s` once.

This is inspection, not inference. The type, effect, test and simulation results remain **UNOBSERVED**.

**Behavior, from my own derivation:**

- `init` always satisfies `wellFormed`. Normalization plus the `start ≤ used` and `length ≤ used − start` bounds guarantee this.
- `physicalAppend` preserves `wellFormed`, old rows, the other holder and both materializations.
- The `ToolingCapacity` event leaves the arena unchanged.
- `step` is therefore always enabled. I expect 9-state traces and `[ok]`. This is a prediction, not evidence.
- I re-derived all eight tests and the eleven literal arenas by hand. They agree with the source.

**New limitation (non-blocking).** `c = Constant(0)` equals the padding value `zero`. As a result, three expectations cannot tell a written `c` apart from untouched padding:

- slot 8 in `exactTailBoundaryTest` and the final `ownerEx4Test` step;
- slot 5 in the second step of `sharedSliceForcesCopyTest`.

The EXT/COPY event and the holder, active and copied-row (`a`, `x`, `g`) checks still discriminate. The seeded run's `modelInv` covers non-zero `v`. The tests are frozen, so I do not ask for a change here, but this should be recorded as a coverage limit.

**Other carried limits.** The `modelInv` mode and length clauses reuse `selectedMode`/`requiredLength`, as in R1 finding S5. `firstUnavailable = capacity` is circular.

## 4. Packet, effects and security findings

- **Out-of-manifest bodies.** The supplied set includes nine `r1-historical/…` bodies that are not R3 manifest members (cli.js, cliCommands.js, evaluator.js, commandWrapper.js, builtin.qnt, package.json and others). Their hashes match the R1 pins. I used them only as R1-pinned evidence for the execution path. They must not exist inside the R3 root.
- **Execution-path pins.** The executed chain beyond `cli.js` (`cliCommands.js`, `runtime/impl/evaluator.js`, parser and resolver) is pinned only by hash, through the R3 and R1 input manifests. It must be re-verified at the installed paths (§5).
- **Path check, from the supplied bodies.** The TypeScript backend never calls `CommandWrapper` or the Rust binary manager. Typecheck needs no backend. Node resolves `require` relative to `cli.js`, so the `inputs/installed-quint` copies cannot load when `cwd` is outside the packet and `NODE_PATH` is absent. The test's `./valueSlotsAppend` resolves next to the importer, so only the R3 model can be the importee; the `before/` copies cannot.
- **Empirical support.** The R1 and R2 typecheck paths each ran with no deviation and produced no stray files. The TypeScript test and run paths are still unobserved. Two residuals remain: unpinned transitive npm dependencies, and an unpinned `/usr/bin/timeout`.
- **Lazy-pick assumption.** I assume `0.to(8).setOfMaps(refs).oneOf()` picks lazily over 4⁹ maps. `runtimeValue` is not supplied, so this is unverified. The 10 s / 256 MiB bound contains the risk, and a timeout would be terminal.
- **Masked importee diagnostics (F-R2-1) are now addressed.** Model-root typecheck reports the model's own phase-1 errors. Phase-1 failures with zero recorded errors throw rather than pass. So a command-1 pass establishes that these model bytes parse cleanly, deterministically, before the test-root command drops importee errors.

## 5. Eligibility and exact conditions

### Eligibility

R1 failed on an annotated-definition grammar defect. R2 failed on a reserved-name QNT101. Both were deterministic frontend source defects in the model, surfaced through the test root, each taking under 0.5 s with exit 1, with no resource or timeout involvement, and with tests and simulation never dispatched.

R2 triggered the prior stop rule: diagnose before another repair. R3 satisfies that rule substantively:

- a complete binder audit against the exact installed resolver list, which I verified;
- a consumer inspection;
- reordering so that the first observed command is a model-root typecheck. That command is the root-level diagnostic the R2 owner named, extended to types and effects. A failure there now yields the complete model error set, which neither R1 nor R2 could.

This is not a blind retry. R1 and R2 stay terminal. The 10 s / 2 s / 256 MiB / TypeScript-only / `HOME` unset flags are unchanged. Native authority 0, C4 and the 90 s / 30 s and all other counters are unchanged. **R3 consumes one attempt against the existing counters.**

### Preconditions

All must be recorded before command 1. If any fails, do not launch; that is a block, not an attempt.

1. **Counter ledger.** Root confirms no applicable campaign or task attempt budget is exhausted. Otherwise the outcome is BLOCKED_EXECUTION.
2. **Fresh normal-source review.** A fresh normal-source review of `d641cde2…` is recorded, or Root records a disposition that one is not required. This vote does not substitute for it.
3. **Manifest and members.** The manifest hash and all 40 listed members match by bytes and SHA-256. The root contains no unlisted entries besides the manifest and `OUTPUT_SHA256`; in particular there is no `r1-historical/`. The only root-level `.qnt` files are `be304be2…` and `df3dd56b…`.
4. **Tool pins.** Node is 126595440 bytes, `7fde7b8a…`. `cli.js` is 16807 bytes, `ac12595b…`. Every installed file pinned in the R3 INPUT-MANIFEST and the R1 original-semantic INPUT-MANIFEST matches at its installed path.
5. **Observation folder.** `…/p3-valueslots-quint-observation-r3` did not previously exist. Create it with only an empty `tmp/`, outside the source root.

### Launch

- **Environment.** `inherit=false`. Set exactly `PATH=/home/charl/.foreman/tools/fnm/node-versions/v24.21.0/installation/bin:/usr/bin:/bin`, `LANG=C.UTF-8` and `TMPDIR=<obs-r3>/tmp`. `HOME` is unset. `NODE_OPTIONS`, `NODE_PATH`, `NODE_COMPILE_CACHE` and every other variable are absent.
- **Process.** `cwd` is the observation folder. Spawn argv directly, with no shell and no new runner script. Stdin is closed or empty. Each command's stdout and stderr go to separate files in the observation folder only.
- **Argv.** Use the three arrays in `f8b6afd4…` exactly as given. Do not add `--out`, `--out-itf`, `--mbt`, `--source-map`, `--witnesses` or the Rust backend.
- **Order and gating.** Run `model-root-typecheck`, then `normal-tests`, then `short-seeded-run`. Each runs once, only if every earlier command exited 0, with no retry. Exit codes 124/137/134 or any other nonzero code are terminal for R3 and stop the sequence.

### The observation is INVALID, not a pass and not rerun, if any of these occur

- Any stdout or stderr line with a `[DEBUG]` prefix, `ignoring listener exception`, `generating undefined`, `ATTENTION:`, or any QNT syntax or error code. This applies in a run that otherwise looks successful.
- Any mention of Rust, a download, QNT516/517, Apalache, gRPC or a server endpoint.
- Any change to the source listing or hashes.
- Any observation entry other than `tmp/` and the per-command captures. Any `tmp/` contents must be listed and hashed.

### Pass interpretation

- **Command 1.** Exit 0 with no error output. Record any non-empty output for review.
- **Command 2.** Exit 0 is **not sufficient**: `runTests` returns success even when tests are ignored. A pass requires exactly these eight, all reported passed, with zero failed, zero ignored and no additional names: `emptyCopyTest`, `exactTailBoundaryTest`, `nonTailCopyTest`, `ownerEx4Test`, `sharedSliceForcesCopyTest`, `tailCapacityRefusalTest`, `copyCapacityRefusalTest`, `emptyCapacityRefusalTest`.
- **Command 3.** Requires all of:
  - exit 0 and `[ok] No violation found`;
  - 32 samples;
  - printed trace statistics showing every trace non-vacuous at 9 states (min = max = 9 by my derivation);
  - the seed line.

  If the statistics are not printed at verbosity 2, the result is INCONCLUSIVE, not pass. (`verbosity.js` is not supplied.) Shorter traces or `[violation]`/`[error]` are failures or inconclusive, and terminal.

### Record

Write a new `P3-VALUESLOTS-QUINT-OBSERVATION-r3.json` containing:

- the manifest and proposal hashes, plus receipts for this review and the normal review;
- for each command: argv, environment, `HOME=UNSET`, start time, duration, exit code or signal, and stdout/stderr bytes and SHA-256;
- deviation terms;
- the post-run recheck of all 40 members and the listing;
- the observation listing;
- `not_run`;
- `native_authority: 0`.

### After an R3 failure

- The failure is terminal for these bytes.
- Any R4 must address every diagnostic in the R3 model-root capture together, with fresh reviews and classification, and must not re-run R3.
- A third failure in the frontend/parse class should go to Root as a campaign-level stop decision, not another repair cycle.

## 6. Retained scope

A pass would be a finite seeded QA observation only. It would show:

- a nonempty tail extends; otherwise COPY is used;
- appends happen only at or above the old active end;
- all old rows and the other holder are preserved;
- each sequence is independently materialized;
- capacity refusal happens outside the machine outcome.

It would not establish:

- full P3 or adoption correspondence;
- A177/A181 machine execution, StepInv, or circuit, financial, ledger or stagenet correspondence;
- emitter or capacity admission;
- native or privacy security;
- any substitute for C4.

Native authority 0, C4 and the full roadmap are retained. No pass has been observed. Any byte change to the packet or the proposal voids this review for the changed bytes.

**Final:**

| Decision | Result | Bound to |
|---|---|---|
| Source | **APPROVED_SOURCE_WITH_LIMITS** | `d641cde2028048cbf4b81240d7d6618ab3978a0a807c660e1243472e50e250e5` |
| Execution | **ORDINARY_BOUNDED_MODEL_DIAGNOSIS** (BLOCKED_EXECUTION if counters are exhausted or any precondition fails) | `f8b6afd444374e3b341a611a41ef433a909512325e313840235082ca9087e8c5` |

R3 is eligible once under §5. R1 and R2 remain terminal, and no counter is reset.
