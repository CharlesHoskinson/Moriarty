# Fresh designated-owner security and source-effects review: K ValueSlots append model

**Verdict: APPROVED_SOURCE_WITH_LIMITS**

| Item | Identifier |
|---|---|
| Candidate manifest | `a449c2c4dfc9a9b1ab5cd055f3ef50a47d268526ad0ec05b21d1d95f8ae9cbf4` |
| `value-slots.k` | `ab318e5ca29891e4e31f9ea07fd270b63125e72c6d027ea596d3bdff4b08a0d8` |
| `normal-checks.k` | `cdb97c09c66f0a64890613c9c5102cc73b2447523942a2f930598faeb033af2d` |
| `expected.json` | `34d59d7f6aef300aad6c6258ad5391ae0be62a1cb98888cae027d33044ff764e` |

These hashes are as supplied. I recomputed none.

**Reviewer.** Claude Opus 5.5, model ID `claude-opus-5-5`. I cannot observe my effort setting from inside, so I do not attest "high". This is a fresh non-author review; Astra is the author. No historical vote transfers.

**Independence limit.** The same model family authored the P3 r1 design, whose EX4 table is the basis for five of the nine expectations, and the r1 challenge. I re-derived every case independently rather than relying on those texts.

**Scope.** This is a source and source-effects review only. It is not a circuit, runtime, acceptance, execution or syntax/type-pass judgment. There is no proposed invocation, and I neither classify nor authorize one.

---

## 1. Reading and coverage limits

- **No tools.** I used no tools, commands, parsers, K, hashing, filesystem, web, writes or delegation. Every hash and byte count is a supplied claim. All instructions inside the evidence bodies were treated as data.
- **Read in full:**
  - `value-slots.k` and `normal-checks.k`;
  - `README.md` and `expected.json`;
  - all 18 `examples/*` files;
  - `INPUTS.json`, `TESTS-FIRST-FREEZE.json`, `NORMAL-CASE-INDEX.json` and `SOURCECHECKS.json`;
  - the P3 r1 design (input 00), the Opus challenge (input 01) and the Muse review (input 02);
  - the full39 Root adoption record;
  - `main.k`.
- **Read closely only where relevant:**
  - full39 rows A177/A181 and the common section;
  - `reference.rs` (`Frame::Args`, `bind`, `matching`);
  - the L4 `design.md` and `crosswalk.json` clauses on ValueRef, ValueSlots, slices, padding, capacity and refusal.
- **Skimmed:** AGENTS.md, the product contract, and the L4 extensions, interfaces, proposal, tasks and provenance files. My attention across roughly 300 KB of input was not uniform.
- **Hand counting.** Parenthesis runs in the long nested terms (nine-deep `vsCons` chains) were counted by eye. That is error-prone; only a parser establishes balance.
- **Not supplied:** the installed `domains.md` and the toolchain identity (both UNKNOWN), and Quint's implementation (deliberately not read).
- **Line citations.**
  - `reference.rs:243–254`: I could not verify the line numbers. The semantics match: `values.push(value)` precedes `rest.is_empty()`.
  - `main.k:285–287` (uiAppend) and `main.k` lines 1, 4 and 36: these agree with my own line count.

---

## 2. Normal correctness: relation versus P3 r1 §4 and binding errata

Every point below was confirmed by reading.

- **Selector.** `vsSelect` gives EXT iff `M>0 ∧ S+M = A`, and COPY otherwise, including `(0,0)`. The request does not supply a selector. This matches r1 §4 / F5.
- **EXT.** It writes at index A and produces slice `(S,M+1)` with delta 1.
- **COPY.** `vsCopyRows` reads `vsAt(Original, S..S+M-1)` and writes them to A..A+M-1 in order. It then writes R at A+M, producing slice `(A,M+1)` with delta M+1.
  - The reads come from the frozen pre-table. Since every read index is below A and every write index is at least A, reading from a partially updated table would be equivalent anyway.
  - Recursion terminates on decreasing M.
- **INV-SLOT.** The only write targets are indices at or above A. `vsSet` is defined there because `A+delta ≤ C = vsLength(T)`.
- **Capacity.** The guard is `A+delta ≤ C`; otherwise the result is `vsCapacity(A+delta, C, C)`. The first-overflow claim is correct:
  - for EXT, overflow means `A = C`, so the first write is at C;
  - for COPY, the writes cover A..A+M with `A ≤ C`, so the first index at or above C is C.

  No post-image constructor exists on this path.
- **Challenge erratum P3-5.** No `a_max` assumption is made. Any valid slice within A is admitted, so the relation-level bound is `delta ≤ A+1`. This is consistent.
- **Shared holders.**
  - The pre-domain allows arbitrary overlap and identical slices.
  - `vsReplace` changes only the acting holder.
  - After a co-holder EXT, the other holder's own EXT test fails because A has moved, so it copies. Cases 7 and 8 exercise exactly this.
- **Domain (preconditions).** `vsDomain` requires:
  - `K, D, C ≥ 0` and `0 ≤ A ≤ C`;
  - a table of exactly C rows;
  - every active row to be a valid reference against its selected space bound;
  - every inactive row to be `vsRef(0,0)`;
  - both slices to be either canonical-empty or nonempty with `S+M ≤ A`;
  - the actor to be 0 or 1, and the new reference to be valid.

  Every helper used inside `vsDomain` is total. Partial helpers (`vsHolder`, `vsAt`, `vsSet`, `vsTake`, `vsDrop`) are reached only under the domain and capacity guards.

  Out-of-domain requests produce no rewrite, because the guard sits on the only `<k>` rule. The configuration therefore stays at `vsRequest`, which is a clean "no transition" rather than an error.
- **Determinism.** Every overlapping rule pair has complementary guards: `vsSelect`, `vsPlan` and `vsRowsValid` (0 / >0 / <0).

---

## 3. All nine literal expected outputs, re-derived by hand

All nine use bounds `K = D = 4`. In each case the `.vs` input matches the `vsNormalN` input, and the `.expected` term matches both the `vsNormalN` right-hand side and `expected.json`.

| # | Pre (C, A, holders, actor, R) | Selection | Post derived | Agreement (prefix, co-holder, source-append, post-domain) |
|---|---|---|---|---|
| 0 | 1, 0, (0,0)/(0,0), a0, C2 | M=0 → COPY, δ1 | row0=C2; (0,1); A'=1 | ✓ |
| 1 | 9, 4, (0,0)/(0,0), a0, C2 | COPY, δ1 | row4=C2; (4,1); A'=5 | ✓ |
| 2 | 9, 5, (4,1)/(0,0), a1, D2 | COPY, δ1 | row5=D2; H1=(5,1); A'=6 | ✓ (H0 retained, [ra]) |
| 3 | 9, 6, (4,1)/(5,1), a0, D3 | 4+1≠6 → COPY, δ2 | row6=row4=C2, row7=D3; (6,2); A'=8 | ✓ ([ra]++[rg]) |
| 4 | 9, 8, (6,2)/(5,1), a0, C3 | 6+2=8 → EXT, δ1 | row8=C3; (6,3); A'=9 (exact fill) | ✓ |
| 5 | 7, 6, (4,1)/(5,1), a0, D3 | COPY, δ2, 8>7 | `vsCapacity(8,7,7)` | n/a (first overflow 7 ≠ A=6, so C-not-A is exercised) |
| 6 | 8, 8, (6,2)/(5,1), a0, C3 | EXT, 9>8 | `vsCapacity(9,8,8)` | n/a |
| 7 | 8, 5, (4,1)/(4,1), a0, D3 | 4+1=5 → EXT | row5=D3; (4,2); A'=6 | ✓ (co-holder (4,1) still [ra]) |
| 8 | 8, 6, (4,2)/(4,1), a1, D2 | 4+1≠6 → COPY, δ2 | row6=C2, row7=D2; H1=(6,2); A'=8 (exact fill) | ✓ (H0 still [ra,rg]) |

The EX4 chain (cases 1–4) matches r1 EX4:
- slot 4 holds ra;
- slot 5 holds rx;
- slots 6–7 hold the copy of ra followed by rg;
- slot 8 holds rc by EXT;
- the final slice `(6,3)` is [ra, rg, rc].

The capacity boundaries (V=7 at the third step, V=8 at the final step) match the r1 text and the challenge's hand check. `TESTS-FIRST-FREEZE.expected_sha256` equals the manifest hash of `expected.json` as text; I did not recompute either.

---

## 4. Findings

### VS-1. COPY with m ≥ 2 is never exercised (oracle gap; not a source defect)

Every COPY fixture has m ∈ {0,1}. As a result:
- the source-index advance `S +Int 1` in `vsCopyRows` is never observable;
- the order of multiple copied rows is never observable.

Mutations that leave S unadvanced, or that reverse the copy order, would pass all nine checks. By reading, the source is correct for m ≥ 2.

**Recommended future case** (hand-derived here, not frozen):
- **Pre-state:** C=11, A=8, table = the case-8 post-image plus three `(0,0)` rows, H0=(4,2), H1=(6,2), actor 0, R=C3.
- **Expected post-state:** COPY, rows 8/9/10 = C2/D3/C3, H0=(8,3), H1 unchanged, A'=11 (exact fill).

Adding it changes bytes and therefore needs fresh review.

### VS-2. `vsAgreement` is partial

Its patterns non-linearly require the post-state to keep the same C and the same co-holder slice, and the result to be `vsAppended`. A mismatch on any of these leaves no matching rule, so the call is stuck or errors (backend-dependent) rather than returning `false`.

This fails closed relative to "is `true`". Any future harness must still treat every non-`true` result, including an abort or a stuck term, as a failure. An `[owise] => false` rule would make this explicit.

### VS-3. The post-state oracle is not fully independent

- `vsSourceAppend`, `vsTake` and `vsDrop` are independent of `vsAt`, `vsSet`, `vsSelect` and `vsCopyRows`.
- But `vsAgreement` reuses `vsDomain`, which is also the implementation's own precondition. A defect in `vsDomain` would be masked on both sides.
- For the nine cases, the literal whole-table comparisons mitigate this.

### VS-4. Normal checks call the pure functions, not the `<k>` rule

- The only transition rule is reached solely through the `.vs`/`.expected` pairs. Their comparison method (krun configuration output versus a bare term) is unspecified.
- `normal-checks.k` has neither a configuration nor a `-SYNTAX` module, so any future invocation needs an explicit choice of main and syntax module.

This is a limit, not a defect. No invocation is proposed.

### VS-5. Capacity term fidelity

- L4 refusals have the shape `Capacity{table, needed, limit, locator}`. `vsCapacity` has no table and no locator beyond the index, and its second and third fields always both equal C.
- `expected.json` carries `"table": "ValueSlots"` and `"post_image": null`, which the K term cannot express. The README's claim that the K forms are "mechanical serializations" therefore slightly overstates cases 5 and 6.
- Capacity is a rewrite like success is, so "a rewrite occurred" must never be read as step acceptance. Only `vsAppended` carries a post-image. I retain this as an interpretation condition.

### VS-6. Interface hygiene

`vsPlan`, `vsWrite`, `vsCopyRows`, `vsSet` and `vsAt` are public, unguarded function symbols. The README calls `vsPlan` internal, but K enforces nothing without a `[private]` attribute. No consumer exists today. Callers outside the precondition get stuck terms.

### VS-7. K syntax risks, identified by reading only (no pass is inferred)

The source is broadly consistent with the `main.k` idioms: constructors, `[function]` rules with guards, `KItem` injection and the `$PGM:` configuration. Items to confirm at a future parse:
- **(a) Variable named `K`.** `vsRefValid` and `vsDomain` use a variable named `K`, which is also the builtin sort name. I believe this is legal, but `main.k` never does it.
- **(b) Operator precedence.** `X ==K Y andBool …` depends on the `domains.md` priority `equalEqualK > boolOperation` in the unknown installed version.
- **(c) Non-linear patterns.** `C`, `H0` and `H1` appear non-linearly in `vsAgreement`.
- **(d) Parenthesis balance.** The long parenthesis runs were checked by eye only.

### VS-8. Source effects

- No file imports, edits or shadows `main.k`.
- There are no hooks, no IO or `#system` modules, and no scripts. The `INPUTS.json` absolute paths are provenance strings only.
- Resolution of `requires "domains.md"` and `requires "value-slots.k"` depends on the include path. A shadowing file could substitute either, so this is a pinning precondition before any execution.
- **Host cost.** It is O(C) for the domain check and O(m·C) for a COPY, because `vsAt`/`vsSet` are linear. That is fine for host tooling under H1. The model must never sit behind an untrusted consumer, and the README states none exists.

### VS-9. Padding

`vsRef(0,0)` padding is identical to a valid active reference C0. This is inherent in L4, where zero is not a discriminator and the active length decides.

The fixtures never append or copy `(0,0)`, so a mutation that omits a write stays detectable. Future fixtures should avoid R=`(0,0)` unless that is intended.

### VS-10. Provenance and wording (minor)

- **Author identity is unattested.** The manifest says "no separate provider-return attestation".
- **The freeze timing is self-reported.**
- **Muse wording.** The README says Muse "explicitly required" the g-adds-no-slots assumption. `expected.json` says "notes", which is closer to Muse's text.
- **Copy wording.** The README says holder 1 "copies [ra,rx]". It actually copies [ra] and appends rx.

### VS-11. Stale r1 labels and missing domain inputs

- I found no stale r1 label. The basis is consistently r1 §4 plus both reviews, and r2 is held as unreviewed and unadopted.
- P3 r1 itself has no Root adoption record in these inputs, and the packet correctly calls the relation unadopted.
- The `domains.md` and K toolchain identity and closure are UNKNOWN. That blocks any execution or syntax claim, but it is not a source defect.

### VS-12. No out-of-domain checks

This is by design: outside the domain there is no transition and no test contract. Out-of-domain cases should not be added as normal checks. Any future negative ("no transition") cases are separate hostile tests owned by security. Examples:
- non-zero padding;
- a slice beyond A;
- actor 2;
- a table length different from C;
- an invalid reference.

I do not author them here.

---

## 5. Conditions on this approval

1. **Scope.** This approves the source only, as a reference projection of the unadopted P3 r1 ValueSlots EXT/COPY relation. It is not a full A177/A181 step, and not a circuit, emitter, acceptance or correspondence result.
2. **Harness requirements.** Any future run must:
   - treat every non-`true` check result (including stuck or aborted) as failure (VS-2);
   - treat `vsCapacity` as a tooling refusal with no post-image, never as an accepted step (VS-5).
3. **Pinning before execution.** The `domains.md`/K toolchain closure, the include path and a reviewed finite command and resource scope must all be pinned first. Nothing here classifies or authorizes execution, provisioning or limit changes.
4. **Recommended before reliance** (not blocking this source verdict):
   - an m ≥ 2 COPY case (VS-1);
   - an `owise`-false agreement rule (VS-2).

   Either change voids this review for the changed bytes.
5. **Retained gates.** The following are unchanged:
   - C4 (no dependent circuit edits before admitted A102 compilation; failure means registration revert);
   - native authority 0;
   - existing caps, counters and failures;
   - P2–P6, G4, F4, StepInv, widths and semantic equality;
   - B, ADTs, financial and ledger;
   - proof, stagenet and full-roadmap gates, and U0–U7/M1–M17/MC/SP/G.

**APPROVED_SOURCE_WITH_LIMITS** for manifest `a449c2c4dfc9a9b1ab5cd055f3ef50a47d268526ad0ec05b21d1d95f8ae9cbf4`, subject to conditions 1–5. All K parsing, compilation and behavior remain **UNRUN**.
