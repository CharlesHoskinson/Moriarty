## Verdict: APPROVED_NORMAL_SOURCE_WITH_LIMITS

Candidate manifest: `a449c2c4dfc9a9b1ab5cd055f3ef50a47d268526ad0ec05b21d1d95f8ae9cbf4`

This is a fresh Muse NORMAL-conformance source review. Astra is the candidate author, and the prior owner report was treated only as evidence, not as my vote. I used no tools, K, commands, parsers, filesystem access, web access, writes, delegation, or execution. All hashes are as supplied and were not recomputed. The K toolchain, `domains.md` identity, and closure remain UNKNOWN, and all K parsing, compilation, and tests remain UNRUN. No security or execution classification is made.

### Normal conformance verified by reading

- **EXT/COPY:** `vsSelect` gives EXT exactly when `M > 0` and `S + M = A`, including COPY for the canonical empty slice `(0,0)`. EXT writes the new reference at `A` and produces `(S, M+1)`. COPY reads the acting slice from the frozen pre-table, writes those rows in order at `A..A+M-1`, writes the new reference at `A+M`, and produces `(A, M+1)`.
- **Pre-domain and padding:** `vsDomain` requires nonnegative bounds and capacity, `0 <= A <= C`, a table of exactly `C` rows, valid active references against the selected Constant/Data bound, `vsRef(0,0)` in every inactive row, canonical-empty or `A`-bounded slices, actor `0` or `1`, and a valid appended reference. Invalid-domain requests have no specified transition under the sole `<k>` rule.
- **Old prefix and shared holders:** All writes begin at or after pre-active index `A`, so no earlier row is a write target. `vsReplace` changes only the acting holder. Arbitrary overlapping and identical holder slices are admitted; after one holder extends, the other holder's EXT test fails against the advanced `A`, so it copies.
- **Capacity:** Success requires `A + delta <= C`. Otherwise the result is `vsCapacity(A + delta, C, C)` with no post-image. Because writes proceed upward from `A <= C`, the first overflowing ValueSlots index is `C` for both branches.
- **Independent oracle:** `vsSourceAppend` recurses structurally over the sequence materialized through prefix/drop helpers and does not call `vsAt`, `vsSet`, `vsSelect`, `vsCopyRows`, or `vsWrite`. The normal checks also compare complete literal post-tables, holders, and active lengths.
- **Source binding:** The candidate models only the common ValueSlots append relation from the supplied Rust `Frame::Args` behavior and K `uiAppend` pattern. It does not model a complete A177/A181 step, frames, environments, fuel, Eval/Invoke, or a Snapshot. The later conditional P3 r2 source adoption in PR 97 does not change this frozen r1 basis, and this review makes no correspondence claim.

### Nine normal fixtures

All nine supplied `.vs`, `.expected`, `normal-checks.k`, and `expected.json` cases agree by hand derivation: cases 0–4 and 7–8 produce the stated EXT/COPY post-images; case 5 gives `vsCapacity(8, 7, 7)`; case 6 gives `vsCapacity(9, 8, 8)`. The EX4 sequence preserves `(4,1) = [ra]` and `(5,1) = [rx]`, then forms `(6,3) = [ra, rg, rc]`. The shared-holder cases preserve holder 0's `[ra]` and later `[ra, rg]` projections. For capacity cases, no agreement or post-image check applies.

### Owner VS1–VS12 findings and conditions preserved

- **VS1:** Retained as an oracle gap, not a source defect: no fixture exercises COPY with `m >= 2`, so multi-row order and source-index advancement are verified by reading only.
- **VS2:** Retained: `vsAgreement` is partial. A pattern mismatch may produce a stuck or otherwise non-`true` term rather than `false`; any future checker must treat every non-`true` result as failure.
- **VS3:** Retained: the oracle is not fully independent because `vsAgreement` reuses `vsDomain` for post-domain validation. The literal whole-state comparisons mitigate this for the nine cases.
- **VS4:** Retained: normal checks call `vsAttempt`, not the `<k>` transition, and no invocation or comparison method is specified.
- **VS5:** Retained: `vsCapacity` is a tooling refusal with no post-image and must never be read as an accepted step. Its term does not literally encode `expected.json`'s `"table": "ValueSlots"` or `"post_image": null`.
- **VS6:** Retained: `vsPlan`, `vsWrite`, `vsCopyRows`, `vsSet`, and `vsAt` are public helpers whose stated preconditions are not enforced by K visibility.
- **VS7:** Retained as unresolved syntax risk only: the variable named `K`, `==K`/`andBool` precedence in the unknown `domains.md`, non-linear `vsAgreement` patterns, and parenthesis balance cannot be settled without parsing, which remains UNRUN.
- **VS8:** Retained as a source-binding limit: `domains.md` and relative `requires` resolution must be pinned before any later reliance; no execution proposal is made here.
- **VS9:** Retained: `vsRef(0,0)` padding is indistinguishable from an active Constant 0 reference except through active length.
- **VS10:** Retained as minor provenance and wording limits, including unattested author identity, self-reported freeze timing, and the README wording points identified by the owner.
- **VS11:** Retained: the basis is consistently P3 r1; r2 remains outside this frozen review basis. The missing `domains.md` and toolchain identity block execution claims, not this source reading.
- **VS12:** Retained: there are intentionally no out-of-domain normal checks, and no such cases should be treated as part of this NORMAL contract.

C4, native authority 0, all existing caps and counters, the full roadmap, proof obligations, target gates, and the other retained P2–P6/G4/F4/StepInv/width/semantic-equality/B/ADT/financial/ledger/U0–U7/M1–M17/MC/SP/G limits remain unchanged.

**APPROVED_NORMAL_SOURCE_WITH_LIMITS** for candidate `a449c2c4dfc9a9b1ab5cd055f3ef50a47d268526ad0ec05b21d1d95f8ae9cbf4`.
