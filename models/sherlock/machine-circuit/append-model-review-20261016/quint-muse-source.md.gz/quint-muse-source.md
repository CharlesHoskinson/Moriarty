## APPROVED_NORMAL_SOURCE_WITH_LIMITS

Candidate manifest SHA-256: `d641cde2028048cbf4b81240d7d6618ab3978a0a807c660e1243472e50e250e5`

Exact fresh Root command proposal SHA-256: `f8b6afd444374e3b341a611a41ef433a909512325e313840235082ca9087e8c5`

This is a fresh normal conformance, syntax, and expectation review of the supplied R3 bodies only. It transfers no historical vote, makes no security or execution classification, grants no execution, and observes no pass. All hashes are treated as supplied pins because this review used no tools or recomputation.

### Exact patch

The complete supplied patch changes only `valueSlotsAppend.qnt` lines 19–20:

- parameter `length: int` becomes `sliceLength: int`;
- the zero test uses `sliceLength`;
- the nonzero record value uses `length: sliceLength`.

The Slice record field remains named `length`, and empty normalization remains `(start: 0, length: 0)`. Reversing those three token occurrences restores the R2 model. No EXT/COPY rule, capacity rule, arena row, holder update, invariant, initializer, import, test, or expected state changes.

### Binder and resolver verification

The supplied inventory enumerates 104 binding occurrences across both modules and compares them with the 103 exact names in the pinned `names/base.js`. The sole R2 collision is the former `normalizedSlice` parameter `length`, because `length` is an exact built-in name. `sliceLength` is not in that list.

The pinned consumer code supports that diagnosis:

- `names/collector.js` calls `recordConflict` when a collected identifier is in `builtinNames`; that path emits the observed QNT101 message.
- `names/resolver.js` collects lambda and function parameters through the same collector and removes them at scope exit, so a local parameter is not exempt.
- Repeated `a`, `h`, `i`, `p`, `out`, `rows`, and `e` bindings occur in separate lexical scopes and are not the global built-in collision.
- Record labels and `.length` selections are not binding declarations; `ToIrListener.js` lowers record labels to string literals. The field name `length` and list operation `.length()` therefore correctly remain unchanged.
- Names such as `length0`, `length1`, `start`, `end`, `mode`, `empty`, and `nextSlice` are not exact built-in names.

I found no second exact-name collision in the supplied model or test bodies. This remains a manual source inventory, not parser execution.

### Model semantics

The model preserves the specified predicate on reading:

- `selectedMode` returns `EXT` only for a nonempty slice whose `start + length` equals the old `active`; every other case, including an empty slice, returns `COPY`.
- `physicalAppend` derives every destination row from the preimage, preserves all old active rows, writes copied elements and the appended value only at or above the old `active`, retains zero padding after the new end, and replaces only the acting holder.
- `materialize` independently reconstructs the sequence with `range` and `foldl`; `physicalAppend` does not consume that oracle sequence or a supplied postimage.
- `appendTo` computes `requiredLength` before constructing the post-state. On refusal it leaves the arena exactly unchanged and records `ToolingCapacity` as a State event diagnostic, without producing an applied arena outcome or a `MachineOutcome`.

The two `: bool` action annotations from R2 remain present, and the unparameterized `init` and `step` declarations retain the other Quint declaration form supported by the supplied grammar and examples.

### Tests and literal expectations

The test module and `expected.json` are byte-identical to their supplied R1/R2 copies. All eight tests remain present:

`emptyCopyTest`, `exactTailBoundaryTest`, `nonTailCopyTest`, `ownerEx4Test`, `sharedSliceForcesCopyTest`, `tailCapacityRefusalTest`, `copyCapacityRefusalTest`, and `emptyCapacityRefusalTest`.

The eleven literal arenas—`e0`–`e4`, `shared0`–`shared2`, `limit8`, `limit7`, and `fullEmpty`—remain internally consistent on hand inspection for capacity, active length, holder coordinates, active values, and zero padding. In particular:

- empty append uses COPY and writes at the old active position;
- the exact tail boundary uses EXT;
- a non-tail append copies the old sequence before the new value;
- the shared-slice trace first extends holder 0 and then forces holder 1 to copy its preserved old sequence;
- all three capacity cases retain the exact preimage arena and produce the stated required and limit values.

These literal tests retain the normative ground truth for the EXT/COPY boundary. By contrast, `modelInv` reuses `selectedMode` and `requiredLength`, so its mode and length clauses are consistency checks rather than fully independent selector or length oracles.

### Diagnosis and proposed command order

The R1 and R2 terminal failures remain failures for their own bytes. R1's import cascade and R2's single QNT101 diagnostic do not establish an R3 result.

The changed future order is source-supported. In `quintParserFrontend.js`, phase 2 parses an imported file but does not concatenate that importee's phase-1 errors into the returned error list, so relying only on the importing test root can lose direct model parse diagnostics. The proposal therefore typechecks `valueSlotsAppend.qnt` as Root first, then runs the eight TypeScript tests, then the seeded model run with 32 samples and 8 steps. Each command remains once-only, gated on every preceding exit 0, with the stated 10-second timeout plus 2-second kill grace, 256 MiB Node old-space setting, TypeScript backend only, and `HOME` unset. Any failure stops the sequence. No old counter reset, new contract, native-authority increase, or cap change is proposed.

### Retained limits

R3 is entirely UNRUN: no parse, typecheck, effect check, test, or simulation result has been observed, and the rename is only a source-grounded repair hypothesis. Later parser, type, effect, or runtime defects may still appear.

This is finite QA over two holders, four abstract references, and capacities 7, 8, and 9. It is not full P3 correspondence, A177/A181 or StepInv evidence, a complete machine, circuit or financial acceptance, stagenet correspondence, emitter acceptance, or production capacity admission. `firstUnavailable = capacity` remains a model diagnostic, not an adopted auxiliary ABI. Native authority remains 0, C4 remains retained, and the full roadmap remains open.
