The standalone K counterpart is frozen as unadopted source. It contains the exact derived EXT/COPY relation, a fixed padded table with two holders, tooling-only Capacity and one request rewrite. Nine literal normal expectations were frozen first. The independent source append oracle uses separate structural recursion; no physical update helper generated the expectations.

All K parsing, compilation, checks and execution are UNRUN. Only text/data/hash observations were made. K tool availability and the exact framework domains.md closure remain UNKNOWN. No future exact command is invented.

The README maps the shared projection, valid domain, branches, preserved cells, EX4/co-holder cases and remaining evidence. All source dependencies and original review receipts are pinned. No Quint implementation or expected-output producer was read.

Requested and acting routing is GPT-6 Astra high; no separate returned-model attestation exists. Fresh Opus/Muse source reviews remain required. P3 is unadopted here; native authority is zero, C4 and all full39/language/financial/target gates remain open. Only the new runtime packet was written.
