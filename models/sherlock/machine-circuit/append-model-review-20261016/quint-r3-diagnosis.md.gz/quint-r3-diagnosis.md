# R3: whole-source binding inspection after two terminal failures

R1 and R2 remain terminal failures, not retry permissions. R1 failed during the
annotated-action parse path; R2 included the two required `: bool` annotations
and reported one QNT101 diagnostic: built-in `length` redefined at model line 19.
R2 exited 1 after 0.46129529300378636 seconds, with empty stdout and 389-byte stderr.
Neither revision dispatched tests or simulation. Exact captures and Root reports
are preserved under inputs/terminal-r1 and inputs/terminal-r2. No new run occurred.

The approach for R3 is broader than replacing only the reported token: inspect
all source binding sites in both modules against the entire installed resolver
list, then inspect the actual type/effect consumers before choosing the minimal
source change. No parser or language helper was executed to make that inventory.

## Resolver evidence and full binder inventory

- `names/base.js` exports 103 exact `builtinNames`, including `length`.
- `names/collector.js:184–195` checks every collected identifier against that list
  and calls `recordConflict` for a built-in. `recordConflict` at lines 273–283
  emits QNT101 with the exact message observed in R2.
- `names/resolver.js:76–101` collects nested definitions and lambda parameters
  through the same collector, then removes them on lexical scope exit.
  Function parameters are represented as lambda parameters. A local name is
  therefore not exempt from the reserved-built-in rule.
- The collector permits shadowing at different lexical depths. Repeated `a`,
  `h`, `i`, `p`, `out`, `rows` and `e` in separate source scopes are not the
  global built-in collision that caused R2.
- `ToIrListener.js:684–716` lowers record labels to string literals, not binding
  declarations. Thus the Slice field label `length` and all `.length` field
  selections remain unchanged. The list operator `.length()` also remains the
  intended built-in call.

`BINDER-INVENTORY.json` lists all 104 explicit binding occurrences: types,
constructors, state variable, top-level definitions/tests, function parameters,
local vals, lambda parameters, match payload patterns and nondet bindings. It
includes module/file, line, category, old/new spelling and exact built-in-list
membership for each occurrence. The 103-name source list is retained in full.
A separate textual declaration-starter listing agrees with the manually
enumerated declarations. Parameters, lambda and match scopes were inspected
manually; this is not a substitute Quint parser.

The only collision is `normalizedSlice`'s parameter `length`. Its new spelling
`sliceLength` has no collision. The inventory also checked names such as
`length0`, `length1`, `start`, `end`, `mode`, `empty` and `nextSlice`; exact-name
membership, not substring matching, controls the installed collector.
Record labels/member names are explicitly excluded from the binder inventory.
There are no source destructuring or anonymous-hole binders. Consumer-generated
constructor/pattern implementation names are not additional source declarations.

## Type/effect consumer inspection

`quintAnalyzer.js` invokes type application resolution, type inference, effect
inference, multiple-update checking, nondet checking and mode checking. This
packet ran none of those stages. The following is source comparison only:

| Consumer contract | Candidate inspection |
| --- | --- |
| `types/constraintGenerator.js` constrains typed parameters and definition annotations against bodies. | All parameterized functions/actions now have explicit results; the two action results remain bool. The sole rename leaves all annotations unchanged. |
| Built-in type signatures: range returns List[int]; foldl takes (acc,item); append preserves List element type; indices returns Set[int]. | The three folds use (out,i), append ValueRefs and return List[ValueRef]. `indices().forall` receives integer indices. |
| setOfMaps yields Set[key -> value]; oneOf selects its element; get consumes key type. | Cells are an int -> ValueRef map from bounded integer keys; subsequent get uses integer i. |
| assign, then and expect have boolean result types. | Both concrete actions assign the sole state variable s once; test traces chain those same actions and read s in expectations. |
| `effects/modeChecker.js` separates pure, read-only and updating definitions; stricter possible modes can be suggestions. | Pure helpers depend only on parameters/constants. Invariants read s. Actions update s. Local val definitions inside pure helpers introduce no state access. |
| `effects/builtinSignatures.js` allows read/temporal propagation through folds and quantifiers; then composes identical update sets; expect adds reads. | Fold/quantifier lambdas perform no updates. All test actions update the same single variable, and expectations only inspect state. |
| `NondetChecker.js` requires local nondet, outermost oneOf/generate and a boolean continuation. | All nine nondet declarations are local, each RHS ends in oneOf, and their enclosing initialization/step continuation is an action with boolean result. |
| `MultipleUpdatesChecker.js` rejects repeated updates in a combined effect. | Each atomic action has one s assignment. The conditional is on the assigned record value, not a pair of separate update assignments. |

Records and sum variants use the actual declared Slice/Arena/State/Event fields;
both conditional branches construct the same State shape. Empty fold accumulators
are constrained by append and declared result/record types. Pattern payloads
match their declared Event alternatives. These observations identify no additional
obvious source blocker, but do not establish that actual inference will succeed.
There is no type/effect execution result to promote.

## Exact change and preserved semantics

Only model lines 19–20 change: the parameter and its two bound uses become
`sliceLength`. The record field name stays `length`; empty normalization stays
`(0,0)`. No EXT/COPY rule, mode, capacity, row, holder, diagnostic, invariant,
initializer, import, test or expected result changes. SOURCE.patch contains the
complete delta against R2. Reversing these three token changes reproduces R2.

All eight normal tests and eleven complete literal arenas are byte-identical to
R1/R2. The original tests-first receipt remains historical evidence of its actual
ordering. It is not reissued as a new preimplementation freeze.

## Future evidence predicate and retained scope

The next separately reviewed/classified check should consume the model file as
the ROOT input first, rather than relying only on its import from the test file.
This would expose model parse diagnostics directly and avoid the inspected
importee parse-error-loss path. Only after an admitted model-root check succeeds
could separately classified test-module and behavioral checks provide further
evidence. This is a predicate/order recommendation, not argv, a runner, a grant,
or an inference that another launch is allowed.

Both terminal packets, original 10-second timeout/256 MiB Node old-space records,
all broader caps/counters and C4/native authority zero remain unchanged. Fresh
applicable audits and exact owner classification are required for changed bytes.
The model has not been parsed, typechecked, tested or simulated in R3.

Root reports current P3 conditional SOURCE adoption in the PR97 preparation.
This packet does not extend or re-review that adoption, and makes no model
correspondence claim. Earlier packet statements about unadopted P3 remain
historical statements at their freezes. All unimplemented emitter, complete
machine, binding/canonical, resource, B/general-ADT, financial, proof, ledger,
stagenet and roadmap obligations retain their existing scope. No security
judgment or new physical-design decision is supplied.
