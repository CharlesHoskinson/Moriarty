## Verdict: APPROVED_SCOPED_NORMAL_RESULT

This approval is limited to the finite Quint QA result described below. It is not a security or execution classification, and it grants no native, complete-P3, A177/A181, StepInv, financial, circuit, stage-net, or roadmap acceptance. Actual SDK authority remains 0, and the old C4 counters are preserved.

### Binding

- Full consolidated capture SHA-256, supplied and not recomputed by me: `1432da5bd8421bb0ab8e1a7bf102400e6e09ad89ddebf1c1a90fa390ef69f578`
- Full source-manifest SHA-256, supplied and not recomputed by me: `d641cde2028048cbf4b81240d7d6618ab3978a0a807c660e1243472e50e250e5`

The source manifest reports 40 members rechecked post-run with the listing unchanged. The observation listing contains the six expected stdout/stderr captures plus `tmp/`. Each of the three commands ran exactly once; commands 1 and 2 were carried forward without rerun, and command 3 was the never-started remainder of the same attempt under the designated owner adjudication. The 267.822441-second gap between commands 2 and 3 is disclosed; no overall gap limit applied, no retry occurred, and no counter or cap was reset.

### Exact passed predicate

1. **Model-root typecheck — passed.**  
   The model file was the typecheck root. Exit code was 0, and both stdout and stderr were 0 bytes with the empty-stream SHA-256. This directly avoids relying only on diagnostics propagated through the importing test module.

2. **Eight named normal tests — passed.**  
   The test command exited 0 with empty stderr. Its literal 400-byte stdout lists exactly these tests, each as `ok <name> passed 1 test(s)`, followed by `8 passing (18ms)`:
   `emptyCopyTest`, `exactTailBoundaryTest`, `nonTailCopyTest`, `ownerEx4Test`, `sharedSliceForcesCopyTest`, `tailCapacityRefusalTest`, `copyCapacityRefusalTest`, and `emptyCapacityRefusalTest`.  
   There are no failed, ignored, or additional names. This matters because the inspected consumer can return success when failures are absent even if tests were ignored; the literal membership and summary close that loophole for this capture. The original monitor's empty extracted list was caused by expecting Unicode checkmarks while the CLI printed ASCII `ok`; it is a false stop, not a test failure, and the original record remains preserved and unchanged.

3. **Finite seeded simulation — passed within the stated configuration.**  
   With TypeScript backend, seed 1, configured `--max-samples 32`, and `--max-steps 8`, the run exited 0 with empty stderr and printed:
   - `[ok] No violation found (66ms at 485 traces/second).`
   - `Trace length statistics: max=9, min=9, average=9.00`
   - `Use --seed=0x1 --backend=typescript to reproduce.`

   Thus every counted trace reached nine states: the initial state plus eight steps. The printed example trace also shows repeated `ToolingCapacity` self-loops after capacity saturation, so the nine-state result is non-vacuous but not evidence of eight distinct productive appends in every trace.

### Sample-count assessment

The number 32 is **not a literally printed sample count**. It is a strong inference, not a direct observation:

- The CLI passes configured `maxSamples` to the TypeScript evaluator as the number of runs.
- With status `ok`, no failure, and zero invariant errors, the inspected simulation loop terminates by reaching the configured run bound.
- Independently, `round(1000 × samples / 66) = 485` gives the unique integer sample count 32 for the printed 66 ms elapsed value.

That combination makes the 32-sample statement well supported, but it must remain labeled **INFERENCE**, not literal printed evidence. The absence of an instrumented or directly printed count is a scope limit, not a missing criterion under the disclosed inference basis.

### Normal-test and oracle assessment

The literal tests were authored independently of candidate output and cover:

- empty-slice COPY;
- exact-tail EXT;
- non-tail COPY;
- the four-step EX4 sequence;
- a shared slice where the first holder extends and the second is subsequently forced to copy without disturbing the first holder's materialized sequence;
- EXT, COPY, and empty-holder capacity refusals, with the preimage arena retained exactly and `ToolingCapacity` carrying required/limit values 9/8, 8/7, and 10/9 respectively.

`physicalAppend` computes destination rows from the preimage and does not consume the materialized oracle sequence or a supplied postimage. That gives the sequence-content checks meaningful independence. However, two carried limits remain:

- **Circular selector/length clauses:** `appendInv` reuses `selectedMode` and `requiredLength`, the same helpers used by the implementation path. The invariant therefore does not independently prove the selector or required-length formulas. The literal tests partly compensate because they independently pin EXT/COPY events, active lengths, holder slices, and refusal requirements for the named cases.
- **Circular `firstUnavailable` clause:** the implementation sets it to capacity and the invariant checks that same relation. The three literal refusal tests independently pin the expected values, so coverage exists for those cases, but the invariant alone is not an independent definition.
- **Zero-padding overlap:** `c = Constant(0)` equals the padding value `zero`. Consequently, the written-`c` positions in the exact-tail/EX4 final step and in the second shared-slice step cannot by themselves distinguish an actual write from untouched padding. Mode, active length, holder progression, event, and non-zero copied values still discriminate the transitions, and other tests write non-zero values, but those particular `c` writes have reduced discriminating power.

### Finite-coverage limits

This is finite seeded QA only. Coverage is bounded to two holders, the four `Constant`/`Data` identities with ids 0–1 used in the model, capacities 7/8/9, the eleven literal arenas, seed 1, the inferred 32 samples, and eight steps per trace. It does not exhaust the initializer domain, prove reachability or production-domain properties, establish arbitrary-holder or arbitrary-capacity behavior, or substitute for any broader machine, proof, ledger, circuit, or financial acceptance gate.

### Missing criteria

None within the scoped finite-QA predicate. The only evidence qualification is that the 32-sample count is inferred from the pinned CLI/evaluator control flow and corroborating rate arithmetic rather than printed literally.
