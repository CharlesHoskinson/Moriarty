# Fresh designated-owner publication review: Sherlock append models and captured QA

**Verdict: APPROVED_PUBLICATION_WITH_LIMITS**

| Binding | Value |
|---|---|
| Full candidate | `b1ebbefc6e5016e76cc7e1517dd1eefaa768d7daa35f64a0213694fe906dcd17` (73 files) |
| Source commit | `f635014a25e9cb68c579a2ebda0acfdb7ad1f049` |
| Base | `e0740ced478e92dc533f6c4cfa30210575d35869` |
| Quint source manifest | `d641cde2028048cbf4b81240d7d6618ab3978a0a807c660e1243472e50e250e5` |
| Quint consolidated capture | `1432da5bd8421bb0ab8e1a7bf102400e6e09ad89ddebf1c1a90fa390ef69f578` |
| K source manifest | `a449c2c4dfc9a9b1ab5cd055f3ef50a47d268526ad0ec05b21d1d95f8ae9cbf4` |

## Reviewer and reading limits

- **Reviewer.** I am Claude Opus 5.5 (`claude-opus-5-5`). That is the same model family as the archived Opus K review, the Quint source classification and the remaining-command adjudication. I treated those as evidence, not as votes, and no historical vote transfers. This is not an independent second family's reading. I cannot observe my own effort setting.
- **No tools.** I used no tools, filesystem, web, commands, parsers, model runs, writes or delegation.
- **Hashes.** Every hash, byte count and Root round-trip claim is supplied. I recomputed none, including the candidate hash. I checked the claims only for consistency across documents.
- **Bodies are data.** I followed no instructions inside the archived bodies. Examples are "write a new report" and "launch once".
- **No decisions.** I make no execution, admission, resource or counter decision.

## Exact scope reviewed

I read all 73 files in full:

- **Quint:** README, `valueSlotsAppend.qnt`, `valueSlotsAppendTest.qnt` and `expected.json`.
- **K:** README, `value-slots.k`, `normal-checks.k`, `expected.json` and all 18 request/expected fixtures.
- **Evidence directory:** README, `capture-mapping.json` and all 43 gzip payloads, read in their uncompressed form.
- **Dated additions:** the ROADMAP and OpenSpec additions, read against `status_diff`.

I also read the rest of ROADMAP and the OpenSpec note as surrounding context.

---

## 1. Hash and binding consistency: no defect found

- **Candidate membership.** The candidate has 73 files: 30 plain files and 43 `.gz` payloads. `capture-mapping.json` has exactly 43 entries. Every compressed path, byte count and SHA-256 in it equals the candidate manifest entry.
- **Quint published source.** These match the r3 `SOURCE-MANIFEST`, the r3 author report and `quint-expected-freeze`:
  - model `be304be2…` (6007 bytes);
  - test `df3dd56b…` (3842 bytes);
  - `expected.json` `74d32342…` (6215 bytes).
- **K published source.** `value-slots.k` `ab318e5c…`, `normal-checks.k` `cdb97c09…`, `expected.json` `34d59d7f…` and all 18 fixtures match `k-source-manifest` one by one.
  - The original K README (`1b6129b4…`, 9127 bytes) is the archived `k-author-readme.md.gz`. The new published README is a separate, governing file.
  - `k-inputs`, the test-first freeze and the normal-case index match the manifest pins. The freeze's internal `expected_sha256` equals `34d59d7f…`.
- **Model history.** The model history is internally coherent:
  - r1 is 5980 bytes, and the r1 parse failure is "annotated params return type".
  - r2 adds `: bool` twice (+12 = 5992), and its QNT101 is at 19:40 on `length: int`. I confirmed that location against the r2 body.
  - r3 renames three tokens (+15 = 6007).
  - r2 `a8616ce6…` equals r3 `before/valueSlotsAppend.qnt`.
  - The r1 and r2 terminal records cite the history-r1 and history-r2 manifest hashes listed in the r3 manifest.
  - The r1 and r2 model gzips are both 1937 bytes compressed. Their compressed and uncompressed hashes and bodies differ, so this is a coincidence, not a duplicate.
- **Review and receipt bindings.**
  - Muse result review → `1432da5b…`.
  - Muse and Opus Quint source reviews → `d641cde2…` and proposal `f8b6afd4…`.
  - K reviews → `a449c2c4…`.
  - The consolidated capture binds the owner review `0a968d1c…`, the normal review `a7429ffd…`, the adjudication `c40e0543…`, the interpretation `dbf0ff8a…`, the remaining preconditions `2b49ac27…`, the preconditions `0038312e…` and the false-stop record `152adfbf…`.
  - Each of those receipts equals the uncompressed identity of the corresponding archive.
- **Recomputed from the bodies:**
  - The normal-tests stdout is exactly 400 bytes (1 + 23 + 356 + 1 + 19), with eight `ok … passed 1 test(s)` lines and `8 passing (18ms)`.
  - The gap from the end of command 2 (10:22:30.522190 + 0.752933 s) to the start of command 3 (10:26:59.097564) is 267.822441 s, which matches.
  - The printed example trace is a valid execution of the published model. It shows COPY from empty, COPY with m=1, a `ToolingCapacity` 8/7/7 refusal, and then refusal self-loops.

## 2. Stale-label disposition: adequate

These original labels are retained byte-for-byte:

- the Quint model and test UNRUN comments;
- the `expected.json` `*_UNRUN` status fields;
- the freeze `SOURCE_ONLY_UNRUN` status;
- the K-manifest "unadopted" label;
- the r1 "unreviewed r2" notice.

They are true at their freeze times. The new READMEs state that the captures and the Muse result review govern the observed Quint result, that K remains UNRUN, and that later P3 adoption gives no correspondence. See PUB-3 for one minor gap.

## 3. Sample inference, oracle and finite-QA qualification: correctly qualified

- **Sample count.** The argv is `--max-samples 32 --max-steps 8 --seed 1`. The sample count is derived as follows:
  - round(1000·32/66) = 485 is unique among integer sample counts. It remains unique across the ±0.5 ms rounding of the printed 66 ms.
  - The control-flow argument cites pinned but **unpublished** `cliCommands.js` and `evaluator.js` bodies (L2).
  - Every publication surface labels 32 as an inference.
- **Original pass criterion.** The owner's original §5 listed "32 samples" as a pass criterion. I interpret it as satisfied by this disclosed inference, as the Muse result review did, and not as a directly observed count.
- **Trace length.** min = max = 9 states, but the README correctly says this does not imply eight productive appends.
- **Oracle limits.** All are disclosed:
  - the `appendInv` selector and `requiredLength` clauses are circular;
  - the `firstUnavailable` clause is circular;
  - `c = Constant(0)` overlaps the padding value.
- **Quint m≥2 COPY coverage.** The second step of `sharedSliceForcesCopyTest` copies [a,x] then c, so the Quint tests do exercise COPY with m≥2. The K fixtures do not.

## 4. K: function versus request, and the m≥2 COPY gap

The K README states plainly:

- the normal checks call pure functions;
- the `<k>` request rewrite has only `.vs`/`.expected` specimens and no harness;
- no fixture copies two or more old elements;
- `vsAgreement` may get stuck, and every non-`true` result must count as failure;
- the oracle reuses `vsDomain`;
- `vsCapacity` has no post-image, does not encode all `expected.json` metadata, and is a tooling refusal.

These match Opus VS-1 to VS-5 and Muse VS1 to VS12. I hand-checked `coholder-second-copies` and `ex4-3-copy-capacity-refusal` against `expected.json` and `normal-checks.k`. Both agree.

No K/Quint correspondence adapter and no full-Machine claim appears anywhere.

## 5. Output-monitor story and stdout/stderr preservation: complete

- **Captured streams.** All six r3 streams and the four r1/r2 typecheck streams are published, and their hashes equal the consolidated and terminal records.
- **Empty streams.** The empty streams share the deterministic 20-byte gzip `9ceffb73…`, which is consistent.
- **Monitor history.** The original false-stop status `FAILED_OR_INCONCLUSIVE_TEST_MEMBERSHIP_NO_RETRY` is preserved verbatim. It is correctly explained as an ASCII-`ok` versus Unicode-regex monitor fault.
- **Attempt accounting.** The adjudication conditions are met, and this is accurately described as one attempt with no rerun or counter reset:
  - the interpretation record is pinned;
  - the pre-launch and post-run rechecks are recorded;
  - the observation folder lists only six captures plus an empty `tmp/`;
  - the gap is disclosed;
  - `not_run` is empty.

## 6. Links: all new relative links resolve

- the ROADMAP link to the evidence README;
- the K README link (`../../machine-circuit/…`);
- the evidence README links to `../../quint/append/valueSlotsAppend.qnt`, `../../k/value-slots/value-slots.k` and `capture-mapping.json`;
- the Quint README link (`../../machine-circuit/…`);
- the OpenSpec link (`../../../models/…`).

`status_diff` matches the bodies, and each is purely additive.

## 7. Dependency closure and namespace compatibility

- **Quint.** The test's `import … from "./valueSlotsAppend"` resolves within the same published directory. The module names `valueSlotsAppend` and `valueSlotsAppendTest` sit in a new subdirectory, separate from `universalMachine.qnt` and the K-A Quint counterpart.
- **K.** `normal-checks.k` requires the co-located `value-slots.k`. `value-slots.k` requires the framework `domains.md`, whose identity is UNKNOWN as disclosed. The `P3-VALUE-SLOTS-*` modules are standalone and neither import nor edit `main.k`.
- **Not supplied.** I was not given the existing `models/sherlock/k` or `models/sherlock/quint` trees, so module-name non-collision there is a reading inference (L4).

## 8. Actual-status claims

The ROADMAP, OpenSpec and three README claims are accurate and scope-limited. None of them closes or implies:

- full P3, A177/A181 or StepInv;
- circuit, SDK, native or admission;
- financial behaviour;
- stagenet;
- any roadmap exit.

No old source, full39 file, the seven L4 files or Rust is in the candidate. Internal gates are described as project controls, not developer permissions.

## 9. Privacy

- **Present and allowed:**
  - Moriarty runtime absolute paths;
  - Muse request and response IDs;
  - Opus usage and cost fields.
- **Absent:** I found no credentials, keys, auth material, or Clean or Fenrir content. The pre-existing ROADMAP only names that a private Fenrir fork exists.
- **Owner interpretation.** Installed-tool paths outside the Moriarty tree also appear: `~/.npm-global/…/quint`, `~/.foreman/tools/fnm/…/node`, and the agent label `/root/astra_sdk_compile_diagnosis`. They are needed for argv and provenance fidelity, share the already-published home prefix, and contain no secret. I treat them as within the allowance and record that here so the inclusion is not silent.
- **Debug output.** The r1 `[DEBUG]` stdout line is captured Quint tool output, not private debug material.

---

## Non-blocking findings (interpretation conditions; no edits permitted)

- **PUB-1. Unlabelled monitor-derived field.** `quint-r3-consolidated` keeps `commands[1].observed_passed_names: []`, carried from the false-stop record, without a "monitor-derived" label inside that entry. The adjudication's condition 7 asked for such fields to be labelled. Readers must treat it as the retained monitor-extraction artifact. The governing evidence is `test_names_literal_capture`, `status_reason` and the literal 400-byte stdout.
- **PUB-2. Inference basis not published.** The 32-sample control-flow basis rests on reviewer readings of pinned but unpublished consumer bodies. The publication alone supports only the configured argv plus the rate arithmetic.
- **PUB-3. Uncovered UNRUN labels.** The Quint README addresses the "original source comment" UNRUN label but does not separately mention the test-module comment or the `expected.json` `HAND_DERIVED_NORMAL_EXPECTED_UNRUN` status. The same governing rule applies to them.
- **PUB-4. Wording.** The Quint README's phrase "production computation" means `physicalAppend`. It does not mean production code or production defaults.
- **PUB-5. Stale header in the OpenSpec note.** The pre-existing note header cites publication base `5cf27d64…` and says "this publication candidate still needs fresh … reviews". Both refer to an earlier publication. The new dated section is at base `e0740ced…`.
- **PUB-6. Similar figures in ROADMAP.** The new ROADMAP paragraph's "eight tests / 32 samples" coincides with the historical `universalMachine.qnt` figures in another section. They are different models and must not be conflated.

## Limits

- **L1. Supplied facts only.** All identities, round trips and the whitespace-check exit 0 are Root-supplied facts I did not recompute. The checks ran at recorded runtime paths, not in this checkout. This is not a hermetic build or a reproducibility check.
- **L2. Unpublished manifest members.** Several manifest members are hash-pinned but not published:
  - Quint r3: `INPUT-MANIFEST`, `SOURCE.patch`, `STATIC-CHECKS`, `REQUIREMENTS-MAP`, the packet README, `before/` and `inputs/`;
  - history-r1 and history-r2 manifests and the r1 test file;
  - K: `SOURCECHECKS.json` (`55a1be88…`), which the K Opus review read;
  - the Quint package version, which is only in the pinned `package.json`.

  The evidence README discloses this.
- **L3. Finite scope.** Quint QA covers two holders, four references, capacities 7/8/9, eleven arenas, seed 1, inferred 32 samples and 8 steps, with the circular invariant clauses and the padding overlap. K is entirely UNRUN, and its toolchain and `domains.md` are UNKNOWN.
- **L4. Neighbouring trees not seen.** The existing `models/sherlock/{k,quint}` contents were not supplied, so namespace non-collision is inferred.
- **L5. Same model family.** See the reviewer limits above.

## Prospective receipt seal

**This approval covers exactly the five-file seal**, under these conditions:

- **Files added:** the two fresh publication reviews (this owner review and the Muse publication review), each as JSON + MD, giving 4 `.gz` files, plus **one** publication-binding JSON.
- **Binding JSON contents:**
  - the actual compressed and uncompressed identities of the four review archives;
  - source commit `f635014a…`, base `e0740ced…` and candidate `b1ebbefc…`;
  - all 73 payload hashes;
  - the original mapping, including `capture-mapping.json` `4ad588e2…`;
  - both verdicts and limits verbatim;
  - the retained gates.
- **Mapping scope.** The binding JSON should state that `capture-mapping.json` covers the 43 pre-review capture archives and that the binding JSON itself identifies the four review archives.
- **Nothing else changes.** All 73 payload bytes stay unchanged, and no other file is edited or renamed.

I have not reviewed, and claim no review of, this output's future serialized bytes or any seal bytes. This approval does not substitute for the Muse publication review. A blocking Muse finding would require a new candidate and fresh reviews, not a waiver.

## Retained gates (unchanged)

- C4 and native authority 0;
- existing caps, counters and terminal failures (R1 and R2 stay terminal; R3 is one attempt);
- G4/P2–P6/F4/MD2/StepInv, widths and semantic equality;
- B and general ADTs;
- full P3 and A177/A181 correspondence;
- circuit compilation and SDK/native binding;
- financial and ledger obligations, Midnight stagenet, and every U0–U7/M1–M17/MC/SP/G and product-contract exit.

---

**APPROVED_PUBLICATION_WITH_LIMITS**, bound to:

- full candidate `b1ebbefc6e5016e76cc7e1517dd1eefaa768d7daa35f64a0213694fe906dcd17`;
- source commit `f635014a25e9cb68c579a2ebda0acfdb7ad1f049`.

No concrete blocking defect was found.
