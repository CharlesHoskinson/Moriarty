# Publication review: Sherlock full39 typed-A semantic map (source publication only)

**Verdict: APPROVED_SOURCE_PUBLICATION_WITH_CONDITIONS**

- Candidate manifest: `6c4ae5d3f18f8b4a026e27894960f198d7539f042f629eef4b2baf71c58aa618`
- Source commit: `20e27bc8fe187220039bb1ca0f041c8e65d7fabd`, parent and base `5cf27d64fe91a3faef3ed1b4283284c50f660b24`
- Preparation manifest inside the candidate: `0439e0c6…89d5`
- Adopted map: `6823badb…122c2` (54,334 B)

All of these are pinned as supplied. I did not recompute any of them.

**Identity and role.** I am Claude Opus 5.5 (`claude-opus-5-5`). This is the designated-owner security and publication-scope vote only. It is not a Muse vote. A fresh, successful, non-author Muse publication vote is still required.

**Independence limit.** The same model family authored the original twelve rows and gave the full39 source vote. That vote is published here as evidence. This publication review is a fresh reading, but it is not independent of that family.

**What this vote does not cover.** It approves no language, compiler, circuit, runtime, resource, native, ledger or stagenet result. Native authority is 0. All 16 machine tests and all 29 host-codec tests remain UNRUN. Old caps, counters and failures are unchanged.

## Coverage and reading limits (mandatory)

- **No tools were used.** I ran no commands, accessed no filesystem, web or SDK, ran no parser, recomputed no hashes and made no writes. Every SHA-256, byte count, git blob, mode, gzip property and the `git diff --cached --check` exit 0 is a Root or author claim as transported.
- **Read as supplied text.** I read all 15 changed bodies and all 10 unchanged dependencies:
  - three normative sources (`reference.rs`, `reference_types.rs`, `main.k`);
  - seven L4 files;
  - the full 616,420 B R5 JSON and the full 161,989 B R5 Markdown;
  - the map;
  - both READMEs, the status note, the ROADMAP insertion and the full ROADMAP before-image;
  - the Root adoption record, the inventory clarification and the binding;
  - all five gzip captures, through their supplied decompressed bodies.
- **JSON transport.** JSON bodies arrived whitespace-reencoded, so I cannot attest to their exact original bytes.
- **Attention on R5 was not uniform.** For this publication review I checked scope and status strings, locators, counts, cross-references and sensitive content. I did not re-audit R5 semantics; that was the source vote's job.
- **ROADMAP comparison was visual, not a byte diff.** The only difference I found is the inserted `## Sherlock source status — 2026-10-16` section, between "Compiler provenance observation" and "Sherlock design work". I found no other changed text.
- **Gzip properties not independently checked.** I accept Root's lossless, one-member, mtime=0, no-filename, no-trailing-data checks. I did not inspect compressed bytes. The decompressed Opus and Muse `.md` bodies visually match the `text` fields of their `.json` captures.
- **Bodies not supplied, so counts rest on Root pins.** These were not supplied:
  - `crates/mori-backend/src/lib.rs`;
  - `crates/mori-core/src/sherlock/mod.rs` and `layout_a/mod.rs`;
  - all nine test-source files.

  The counts "16 registered UNRUN" and "29 authored UNRUN", and the claim that `layout_a` is registered privately under `#[cfg(test)]`, therefore rest on the `test_attributes` pins in the binding. The registration of the four backend test modules is visible in the supplied `sherlock_machine/mod.rs`.

## Concrete checks performed

1. **Inventory consistency.** The binding's `selected_files` lists 24 paths: 14 changed plus 10 unchanged. It omits itself, which matches "binding_self_hash intentionally absent". With the binding, the changed set is 15, which matches `initial_files`. The listed roles agree with the README and the status note.

2. **Count consistency across files.**
   - R5 coverage: 42 K rows, 39 Rust events (36 charged and 3 free), 71 helper starts, and 14 inline groups. I counted 14 by enumerating H-push through H-kind.
   - The map's `written` array has 39 entries, which match R5's Rust line list.
   - Backend tests: 4 + 2 + 5 + 5 = 16. This matches the ROADMAP, the status note and the four `#[cfg(test)]` modules in `mod.rs`.
   - Host codec tests: 8 + 8 + 5 + 4 + 4 = 29. This matches the layout_a README and the status note.

3. **No overclaim.**
   - The ROADMAP insertion says the map "does not complete P1 or establish emitter, compiler, circuit, native or stagenet acceptance". It also says existing milestones are unchanged.
   - The status note checks off no task and states that no invocation occurred.
   - The machine-circuit README calls this "semantic source adoption only" and says "No emitter acceptance follows."
   - The Root record's `scope` excludes publication-hygiene approval.

   I found no executed-result claim anywhere in the 15 files.

4. **Conditions reproduced verbatim.** I compared the owner and normal condition blocks and the Root open-obligation list in the machine-circuit README against the Root record's three fields. They match, including the normal block's trailing blank lines.

   F1–F7, the MD2 UNSELECTED status, the symbolic status of `resultRef`, `resultRoot` and `newDone`, the C4 compile gate and the byte-edit void rule are all present. The old twelve rows are stated to be governed by the full39 common lines.

5. **Excluded bodies stay excluded.** These four bodies are named as identity-only and not published, and no published file contains them:
   - `SEMANTIC-CROSSWALK.json`
   - `SOURCE.patch`
   - `author_proposal.py`
   - `freeze_source_data.py`

   The map's `basis` still mentions the companion crosswalk as a historical path. The source-review README explicitly disclaims it.

6. **No executable or sensitive payload.**
   - Every published file is Markdown, JSON or gzip of JSON or Markdown. No scripts, prompts or debug logs are included.
   - No private Fenrir, Clean or SDK source, credentials, keys or witnesses are included.
   - The decompressed sizes (≤ 16,865 B) rule out a decompression-bomb concern.

7. **Relative links resolve.** I checked these against the pinned public paths:
   - `../../../crates/…`, `../k/main.k` and `../../../openspec/…` from `models/sherlock/machine-circuit/`;
   - `../../../models/…` and `../../../crates/…` from `openspec/changes/sherlock-machine-circuit-layout/`;
   - the root-relative ROADMAP links to `models/sherlock/literal-step/MAPPING.md`, `models/sherlock/machine-circuit/README.md` and `IMPLEMENTATION-STATUS-2026-10-16.md`.

8. **Historical labels are explained, not rewritten.**
   - The map's `UNADOPTED` status and the R5 `SOURCE_OBSERVATION_CANDIDATE_UNREVIEWED` status are preserved.
   - The 32/33 discrepancy and the self-reference concern remain in the raw Opus text.
   - The inventory clarification and the source-review README resolve that discrepancy as 32 members plus a separately bound manifest, with no self-hash. They do not alter the review text.

9. **C4 gate respected.** No `crates/` source or circuit body appears among the changed files. The status note says "no circuit source is edited here."

## Findings

**P-1 (low; hygiene; accepted with disclosure): absolute local paths.**
- **Where:** `/home/charl/Moriarty/.moriarty-dev/runtime/…` and `/home/charl/Moriarty/.worktrees/…` locators appear in:
  - the map (`basis_pins`);
  - R5 JSON and Markdown;
  - the Root adoption record;
  - both review captures, by reference;
  - the new `publication-binding.json`.
- **Risk:** these expose a local username and directory layout. They are not credentials.
- **Why accepted:**
  - In the map, R5 and the Root record they are part of reviewed or adopted bytes. Editing them would void those votes.
  - In the new binding they serve as provenance locators.
  - Both READMEs label them historical locators and point to the binding for public paths.
- **Condition:** future public prose should prefer repo-relative locators. This candidate needs no edit.

**P-2 (low; hygiene; accepted): service metadata in the review captures.**
- **Where:** `muse-full39-source.json.gz` contains a provider `request_id` and `response_id`. `opus-full39-source.json.gz` and the Root record contain token counts and `costUSD`.
- **Assessment:** these are call identifiers and accounting data, not secrets or bearer tokens. Their exact retention is what makes the capture lossless.
- **Status:** acceptable. The same will apply to the future publication captures.

**P-3 (low; scope clarity; non-blocking): stale in-file statements in R5.**
- **Where:** R5 is published as `pinned_r5_semantic_dependency`, but its own JSON and Markdown still say:
  - "the other 27 P1 rows are UNWRITTEN";
  - the P1 r2 proposal is "UNADOPTED";
  - fresh Opus and Muse reviews of r5 plus P1 r2 are "required before use".
- **Assessment:** both statements are now historical. The full39 map writes all 39 rows. Root's adoption covers the map checked against R5. It does not adopt R5 itself as a separately reviewed artifact.
- **Current coverage:** the machine-circuit README neither upgrades R5 nor explains this. The status note's phrase "R5 42 K machine-row reconciliation" is accurate.
- **Remedy (no candidate edit):** the future `publication-review-binding.json` should state two things:
  - R5's UNWRITTEN and unadopted lines predate full39 and are superseded only as to the map's 39 rows;
  - R5 retains its own UNREVIEWED status label and is published as a pinned dependency, not as an adopted artifact.

**P-4 (low; temporal; non-blocking): statements that become stale at seal.**
- **Where:** after the seal, these texts in the 15 frozen files will be stale:
  - `publication-binding.json` has `"publication_review":"PENDING"` and `status` `PUBLICATION_CANDIDATE_REQUIRES_FRESH_FULL_REVIEWS`;
  - the source-review README says the candidate "still needs fresh full owner and Muse review";
  - the status note says the candidate still needs fresh publication reviews.
- **Remedy:** no edit is permitted or needed. The seal binding must state that it supersedes those pending statements solely for publication hygiene of these exact 15 bodies plus the four captures. The frozen bodies stay unchanged.

**P-5 (informational): Root-only test counts.**
- **Where:** the ROADMAP and status-note counts of 16 and 29 depend on test-attribute pins for files whose bodies I did not see.
- **Assessment:** the counts are internally consistent and every one is labeled UNRUN, so a miscount could not imply a pass.
- **Status:** retained as a reading limit.

**No blocker found.** I found nothing that publishes a secret, executable content, excluded bodies or an unreviewed source change. I also found nothing that overstates scope, drops or paraphrases an F1–F7 condition, alters existing milestone status, or loosens resource or native limits. The PR #95 and A102 statements match the base `mod.rs` and `MAPPING.md`, which themselves say the registration is an uncompiled candidate needing fresh review. The ROADMAP does not claim otherwise.

## Conditions of this approval

1. **Muse vote required.** A fresh, successful, non-author Muse publication vote must cover this exact candidate, `6c4ae5d3…a618` at `20e27bc8…`. If Muse blocks, or any of the 15 bytes change, this approval lapses for the changed bytes.
2. **No edits to the 15 files.** P-1 through P-4 are dispositioned by disclosure, or by text in the future seal binding only.
3. **No inferred approvals.** This vote does not approve R5, the four auxiliary bodies, any test source, the A102 registration or any physical mechanism (P1/P3 gaps, P2–P6, G4, F4, MD2, StepInv, byte bridge, dispatch, statement binding). Every obligation listed in the Root record and the README stays open.
4. **No new authority.** Publication through ordinary maintainer review grants no runtime, resource, tier, operator or native authority. It adds no public developer permission gate. Native authority remains 0.

## Future seal: approved — YES, with limits

I approve the derivation only. I do not approve the future bytes.

1. **Exactly five new paths** under `models/sherlock/machine-circuit/source-review-20261016/`:
   - `opus-publication.json.gz` and `muse-publication.json.gz`. Each holds the exact raw `RESULT.json` bytes of a fresh successful publication review on this candidate.
   - `opus-publication.md.gz` and `muse-publication.md.gz`. Each holds that JSON's `text` field encoded as UTF-8, with no normalization or newline insertion.
   - All four are lossless gzip with one member, mtime=0 and no filename header.
   - `publication-review-binding.json`.
2. **Binding contents.** The binding must list:
   - the initial 15 paths with their hashes and sizes;
   - the four receipt identities: compressed and uncompressed hash and size, requested and returned model, and verdict string;
   - the source commit, the base commit and this candidate SHA;
   - the source-only limits: UNRUN, native 0, no milestone change, and all open obligations;
   - the P-3 and P-4 dispositions.

   It must omit its own hash. An external final manifest must bind all 20 paths.
3. **No changes to the 15 initial files.** The seal must not alter or add any other path.
4. **Binding must not overstate the votes.** It may record two successful publication-hygiene votes on these 15 bodies. It must not present them as semantic re-adoption, R5 adoption, auxiliary-body approval or any executable result.
5. **No seal without both votes.** If either receipt is missing, unsuccessful or not for this exact candidate, the seal is not authorized.

## Retained (not affected by this vote)

All of the following remain open:
- U0–U7, M1–M17, MC, SP and G exits;
- financial, proof, B and general-ADT work;
- statement binding, StepInv, canonicality (F4), the byte bridge, dispatch and resource admission;
- the Midnight target, ledger and stagenet requirements.

The C4 rule is unchanged: no dependent circuit change before an admitted A102 compile, and a compile failure means reverting the registration, not an unreviewed hotpatch. The 90 s and 30 s caps, the counters and the recorded failures are immutable. All 16 Rust machine tests, all 29 host-codec tests and the Midnight stagenet run are UNRUN.

**APPROVED_SOURCE_PUBLICATION_WITH_CONDITIONS**: candidate `6c4ae5d3f18f8b4a026e27894960f198d7539f042f629eef4b2baf71c58aa618`, source commit `20e27bc8fe187220039bb1ca0f041c8e65d7fabd`. Future five-path seal: **yes**, within the limits above.