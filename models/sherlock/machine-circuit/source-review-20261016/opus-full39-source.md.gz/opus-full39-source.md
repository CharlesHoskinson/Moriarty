# FULL39 P1 Source Review: Designated-Owner Security and Scope Vote

## Role and identity

I am Claude Opus 5.5 (`claude-opus-5-5`), acting as the designated owner for security and scope. I am not Muse. The nonsecurity semantic findings below are offered as evidence, but they are not a Muse vote and must not be counted as one. A separate Muse review and a Root adoption are both still required.

**Independence limitation.** The original 12 rows were authored by "Opus 5.5 high". My judgment on those rows, as part of FULL39, is therefore not independent of their authorship. The prior independent security vote on them is Argon's scoped vote (`482851e7…`).

**Bound subject.** Manifest `a742817c…159b` and proposal `A-REFERENCE-OUTPUTS-EVAL.json` `6823badb…122c2`, as carried in the supplied manifest. No tool, command, hash, parser or execution was used.

## Reading limits

- **No hashes recomputed.** Every SHA256 and byte count in the manifest, INPUT-MANIFEST, CHANGES and STATIC-CHECKS is an author claim to me. The manifest's own hash `a742…` is self-referential and unverifiable here.
- **File count discrepancy.** The `complete33files` array contains 32 entries, not 33:
  - 14 top-level, before and script files;
  - 7 L4 files;
  - 3 authority files;
  - 2 basis files;
  - 6 checkout files.
  
  If the manifest itself is the 33rd item, it is not body-verifiable. Otherwise one body is missing. Root should resolve this before adoption.
- **Bodies read in context.** I read the full 616420-byte R5 JSON, the 161989-byte R5 Markdown and the 546756-byte crosswalk as supplied text. My attention over roughly 1.3 MB is not uniform. I compared all 42 R5 rule objects and 14 inline-operation groups against reference.rs and main.k for semantics, not byte-for-byte.
  - I hand-recounted the line numbers for reference.rs lines 14, 37–39 and 41, and for main.k line 74. I did not recount all 207 quotations.
  - I recounted the 71 helper rule starts and confirmed they are the union of the inline-op `k_sources`.
  - I recounted the 207 citations by structure: 42 `k_source` + 81 rule `rust_sources` + 84 inline-op citations. This matches STATIC-CHECKS. Byte equality of each quotation remains the author's claim.
- **Static checks are not runtime passes.** STATIC-CHECKS and `freeze_source_data.py` are JSON, regex and hash bookkeeping. They establish nothing about executed correspondence: no `Machine.step`, K, Quint or circuit run exists.
- **Citations outside the static count.** The two no-event citations (N-outcome lines 38–39, N-control line 41) are not in the scripted 207. I checked them by hand.
- **Provenance not supplied as bodies.** These are known only through R5 quotations:
  - the owner `RESULT.md` (`986b…`);
  - the L3/L4 Opus and Muse result files;
  - the original Opus author-before bytes (`a668…`);
  - the scoped Argon and Muse results.

**Is full raw R5 now reviewed?** Yes, within the limits above, for semantic reading. Every body needed for the current 39 Rust events, 42 K rule objects, 71 pure helpers, 207 quotations, and the 8-cell, Program, environment, frames, control, fuel and outcome view was present, apart from the 32/33 discrepancy.

What this reading establishes is object, helper and quotation coverage. It does not establish executed correspondence.

## Coverage reconciliation

**Events.** The 39 Rust `(line, charge)` literals in reference.rs equal the 39 rows in `written`:
- 36 charged events;
- 3 free events: lines 80, 82 and 84.

**K rules.** The 42 K machine rules are the 39 events plus three non-events:
- A074: constructor; no StepRecord.
- A078: negative startup; outside the unsigned typed domain.
- A105: invalid literal; unrepresentable as a typed `Value`.

The crosswalk keeps all three as excluded rows. None is fabricated as an event.

**Helpers.** All 14 inline groups cover the 71 K helper starts plus the Rust map and Vec operations. Structural equality is correctly located inside `binary_result`'s derived equality, not as a new helper or event.

**Snapshot cells.** Each of the 27 SNAPSHOT8 lines lists all eight cells in R5 field order. Each matches the corresponding R5 `post` value, apart from the `Pending`/`pre.outcome` normalization, which is sound because the charged guard requires Pending.

## Preservation of the original 12 and the common block

**Row arrays.** By visual comparison of `before/` and the proposal, all 12 arrays are textually unchanged. This includes A102's `controlLength'=1` and A131's MD7 text. The following are also unchanged:
- `eval`, `schedule` and `basis_pins`;
- the original `revision_metadata` keys;
- the inherited `common` and `legend` strings, in order.

**Finding F1 (scope wording).** The prefix line restricts "the following inherited charged common G/W/envelope conditions" to the 36 charged events. The inherited `common` has five lines, and the scope sentence names only three classes. The two OBL lines — `OBL.G4@id`, and `OBL.P4.fuel@id; OBL.P5…; OBL.P6@id` — are not named.

`OBL.P4.fuel` must not apply to A080, A082 or A084, which have no fuel write. The free rows do enumerate their own G4, P4.publication and P5 obligations, so the intent is recoverable.

Condition: the adoption record must state that all five inherited common lines are charged-only. A080, A082 and A084 carry only their row-local OBL lists. Any byte edit to fix the wording requires fresh review.

**Finding F2 (old 12 effectively augmented).** Six new common lines apply to all 39 rows, including the old 12: ALL39, NO EVENT, PRECEDENCE, FUEL, ENVELOPE and PRESERVATION. The claim "does not change any inherited12 rule object" is true of the arrays. The effective constraint set on the old 12 has nonetheless grown.

I checked each addition against the old rows and found them consistent:
- old schedule rows are `P3.empty`;
- complete replacement with zeroed inactive lanes matches the legend;
- ENVELOPE matches Argon's `rule_start_line` 102 ↔ wire `rule_tag` 3 clarification.

Root must record that the old 12 are now governed by this full-39 adoption, not by the scoped record (`d8dd…`) alone.

## Per-row semantic findings (added 27)

These are offered as nonsecurity evidence for Muse to evaluate independently.

### Free publications and precedence

**A080, A082, A084.**
- Precedence matches reference.rs lines 45–60: Return with no frames, then Error, then zero fuel, then the charged transition.
- A084 uses the outermost control: Push-wrapped Return or Error is nonterminal. This matches K84 `notBool uiTerminal(C,S)`.
- A084 zeroes every control row `CRi` for `i<n`.
- All three preserve fuel, frames, environment and arenas.
- Wire tags 0, 1 and 2 match the crosswalk `rule_line_tags`.

**Finding F3.** A080's `outcomeValue'=A:CR0.valueRef` may be a Constant-space reference. P5 allows this mid-segment, but a terminal post-image is plausibly a trace boundary, where L4 requires Data space. The proposal makes no boundary claim. Projection remains F4/P5-open, and A080's post-image must not be described as canonical.

### Frame and environment rows

**A145.** Replace-in-place with `Scope(saved)`; `Root.environment` = saved extended with name → value; one EnvCell with `parent = savedEnv`. The original Scope root cannot see the new binding. This matches lines 204–208 and K145, and the single-cell rule is L4's adopted insertion meaning, not a new choice.

**A149.** `Right` keeps `op` and the value reference and has no environment. Control becomes `Eval(expr0)`, which is the `right` operand. This matches lines 210–213.

**A161 and A165.** These read `expr0` and `expr1` respectively, matching the `If` layout `then = expr0`, `else = expr1`. Both POP and restore the environment.

**A169 and A190.** No POP and no environment restore. This is correct; both are frequently mis-specified.

**A173.** `Cases(value, FS0.armSlice, FS0.savedEnv)`, with both the root and the control aliasing `savedEnv` (line 241).

**A185 and A195.** POP and restore; control stays `Return` and Pending persists even at depth 0.

**Finding F4.** A185 and A195 write `CR0'={tag=Return,valueRef=A:CR0.valueRef}` explicitly. This must be read as a post-relation only, not as choosing the "rewrite" alternative. MD2's ControlRow choice stays UNSELECTED. The two alternatives yield the same post-image under zero-padding.

### Primitives

**A153.**
- Operand order: left = `FS0.valueRef`, right = `CR0.valueRef`.
- Add, Sub and Mul are mathematical with range check 0 ≤ r < 2^128, so subtraction underflow gives Err(10). This matches `checked_sub`.
- Lt returns Bool.
- Eq is total over all `Value` pairs and is structural, not pointer or index equality.
- Cons is UInt × List; Branch is Tree × Tree; every other combination is Err(11).
- Environment is preserved and the frame is POPped (lines 215–220, 308–330; K254–272).

**A157.** Leaf of UInt and Not of Bool succeed; every other combination is Err(11). Leaf reuses the input reference, consistent with owner P3.

**A223 and A225.** These expose Ok and Err. A225 keeps all 256 error codes and performs no Rejected publication.

### Arguments and calls

**A177.** Source order is respected: append, restore the environment, then take the next expression. `nextId = ExprChildren[s.start].expression` is a direct occurrence link, satisfying owner P1. The MD7 tail is applied. The frame is replaced at the same depth.

**A181.** Empty rest → POP, `Invoke(name, newDone)`.

**Finding F5.** `newDone` is defined as the old completed references, in order, followed by `CR0.valueRef`. That is a P1-style reference rule consistent with owner P3 (no unfolding). Two things stay P3-open and the proposal correctly does not choose them:
- copying the slice versus extending it in place when the old slice ends at the active length;
- the O(n²) copying bound.

**A200.** First exact-name row `j`. The `Some(row0)` and `None` cases are distinct. For machine-produced states, `j` coincides with L4's "least structurally equal row", because any earlier equal row would share the name.

**A202 and A206.** These yield Error(7) and Error(8). `bindingsPresent=0` is distinct from a present but empty root.

**A204.**
- Length is checked first; then pairs are visited in reverse; within each pair the type test comes before the duplicate check.
- Zero parameters give `Some(empty)`.
- On failure, Bound still carries the return type and body.
- K's tail-first `uiBind` yields the same result on the common domain, and no internal trace equality is claimed. I checked this against lines 341–355 and K290–298.

**A208.** The pending `Return` frame saves the current Rho; the Push carries the bindings; no capacity check is made here. This matches lines 110–112.

### Matching

**A212.** Empty arm slice → Error(9).

**A214.**
- The first arm is removed before matching.
- The MD7 tail is applied.
- The value, body, remaining arms and saved map are kept on both match outcomes.
- The five H-matching success cases and the equal-binder miss match lines 357–380 and K300–312.
- Child references are reused with zero copies.

**A217.** A miss yields Cases even when the suffix is empty, so Error(9) arrives only at the next A212.

**A220.** The pending Scope saves the CaseResult environment, not Rho; the Push carries the bindings.

**Finding F6 (gap, not error).** A214 states no output-reference rule for the `bindings` root on a successful match.

- **Nil.** Owner P3 expects zero EnvCells, so the root must denote the saved map without new cells. Whether it must alias `CR0.environment` is unstated.
- **Var, Leaf, Cons, Branch.** Each result root chains onto the saved root; this is also unstated.
- **Insertion order.** The "head/left first" order is a logical source order only.

This must be recorded as a P1/P3 gap. It must not be resolved in this vote.

**Finding F7.** The common PRESERVATION line says "no unspecified new active arena rows … authorized". It must be read as neither authorizing nor forbidding failure scratch. P3 must specify A204's failed-bind partial work, and P2/P3 the A153 Eq worklist scratch.

Reading the line as a mandated "zero rows on failure" constraint would silently select a mechanism, so the adoption record must exclude that reading. A214 has no partial-insert path in the source, since every miss returns before inserting, so F7 does not apply to A214's miss.

**No semantic error found.** I found no missing branch, wrong field mapping, precedence error, charge error, POP or restore error, or invented helper failure or partial-append effect in the 27 added rows, within the typed Rust/L4 common domain.

## Security and scope judgment

**Authority.** The proposal grants nothing:
- native authority is 0;
- all execution is UNRUN;
- it makes no resource, ABI, statement-binding, StepInv, F4, B, general-ADT, financial or stagenet claim.

The UNSELECTED status of P2–P6, G4 and F4 is preserved on every row. `resultRef`, `resultRoot` and `newDone` are declared symbolic relations, not expected data or acceptance flags. Capacity is stated never to become `false`, Err(10), Err(11), error4 or any other outcome. This is the core soundness separation, and it holds in every row with appends.

**Fuel.** Fuel is the exact 16-byte little-endian u128. The FUEL line keeps Argon's A102 clarification at its original scope and selects no borrow circuit.

**No determinism claim.** The proposal adopts no deterministic emitter or full-39 circuit claim. SEMANTIC-NOTES correctly states that a unique physical after-image is blocked by P3 for A145, A153, A157, A177, A181, A204 and A214.

**Authorship override.** "GPT-6 Astra high, user override" is acceptable for an ordinary source proposal. It does not substitute for any vote.

**Prior caps preserved.** The old 90-second, 30-second caps, counters and Lean failures, and native 0, are unaffected.

**Embedded material.** The supplied bodies contain no nested instructions I acted on. The Argon RESULT text is treated as evidence of its original scope only.

**Residual risk.** Adopting this map as P1 source text makes it the reference that a future emitter will be checked against. Each condition above is therefore a binding interpretation for that future check. In particular, F6 and F7 must not be "resolved" by emitter behavior without fresh owner review.

## Verdict

**ADOPT_FULL39_P1_SOURCE_WITH_CONDITIONS**

This is the designated-owner security and scope vote only. Conditions:

1. **Separate votes.** A fresh Muse nonsecurity vote on these exact bytes and a Root adoption record are both required. This vote and any old-12 vote do not substitute for either.
2. **File inventory.** Resolve the 32-versus-33 discrepancy and pin the manifest hash `a742…` in Root's record.
3. **F1.** Record that all five inherited common lines are charged-only. `OBL.P4.fuel` never applies to A080, A082 or A084.
4. **F2.** Record that the old 12 are now governed by this full-39 adoption, including the six appended common lines.
5. **F3.** A080's post-image is not asserted canonical; boundary projection remains F4/P5-open.
6. **F4.** For A185 and A195, MD2 stays UNSELECTED; the explicit CR0′ is a post-relation only.
7. **F5 and F6.** For A177, A181 and A214, copy-versus-extend, the bindings-root reference rule, and append order remain P1/P3 gaps. They are not resolved here.
8. **F7.** The PRESERVATION line neither authorizes nor forbids failure scratch. P3 must specify partial-work behavior for A204 and A153.
9. **No emitter acceptance.** No emitter may treat these rows as acceptance criteria until P2–P6, G4 and F4 are owner-specified and reviewed.
10. **Byte edits.** Any byte change to this proposal, including wording fixes for F1, F6 or F7, voids this vote for the changed bytes.

This adoption grants no runtime, resource, native, circuit, proof, ledger, stagenet or roadmap permission. Native authority remains 0.