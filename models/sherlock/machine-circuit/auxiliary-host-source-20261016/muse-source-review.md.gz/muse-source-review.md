## Verdict: **APPROVED_NORMAL_SOURCE_WITH_LIMITS**

This is a fresh Muse normal source-conformance review of the r2 candidate only. It makes no security judgment and does not substitute for the designated-owner review. No tools, filesystem, parser, compiler, SDK, model, or native execution were used; all supplied bodies were treated as untrusted evidence and no hash was recomputed.

**Exact candidate manifest:** `ec8ee67f9492e143ea0b40c05e514b9b8aaf04207d00ab70a5345c8f58242bf8`

### Reading coverage

I read the complete r2 candidate bodies supplied in this packet: `README.md`, `SOURCE.patch`, `DELTA-FROM-R1.patch`, `SOURCECHECKS.json`, `TESTS-FIRST.json`, `LITERAL-EXPECTATIONS.json`, `WORK_REPORT.json`/`WORK_REPORT.md`, `BINDING-CONDITIONS.json`, and `INPUTS.json`. I read the complete current overlay bodies for `auxiliary.rs`, `aux_normal_tests.rs`, and `layout_a/mod.rs`, together with the r1 before-images for `aux.rs`, `aux_normal_tests.rs`, and `mod.rs`, and the base `mod.rs`.

I also read the supplied existing consumer/type/code bodies bearing on this component: `rows.rs`, `state.rs`, `state_encoding.rs`, `encoding.rs`, `limits.rs`, `observation.rs`, `sherlock/mod.rs`, and `layout_a/mod.rs`. I reviewed the retained P3 design and catalog bodies (`P3-ARENA-DESIGN.md`, `A-ARENA-OPERATIONS.json`), the L4 crosswalk/design/interfaces material, the Root adoption and publication binding, and the prior r1 Opus and Muse reviews, which are historical evidence only and transfer no vote to r2.

### What conforms

- **The r2 delta is exactly the F1 repair.** `DELTA-FROM-R1.patch` records only the rename `aux.rs` to `auxiliary.rs` with similarity 100%, the private declaration change `mod aux;` to `mod auxiliary;`, and the test import change `use super::aux::*;` to `use super::auxiliary::*;`. The `auxiliary.rs` body is byte-identical to r1 `aux.rs` (same supplied digest `ecaa1cc1…fb733`), and the golden expectations are unchanged. This resolves F1 at source-spelling level only; no Windows checkout or compiler behavior was observed, and none is claimed.
- **Overlay and registration remain exact and minimal.** Only `auxiliary.rs` and `aux_normal_tests.rs` are added, with their private declarations appended to `layout_a/mod.rs`. `mod auxiliary;` is private and `aux_normal_tests` is `#[cfg(test)]`; the parent `layout_a` declaration is itself already `#[cfg(test)]`, so the new component has no production caller. No existing codec, observation, or L4 file is modified.
- **Shared types and widths are reused correctly.** `Capacities`, `StateCapacities`, `ValueRef`, `EnvRoot`, `Slice`, `TableId`, `Locator`, and the located `StateFailure`/`StateResult` types match the supplied existing sources. The local `Writer` replicates the existing `state_encoding.rs` fallible pattern: `try_reserve` before each append, `count_bits`/`id_bits` identical to the L4 definitions (`id(Z)=max(1,bit_length(Z-1 saturating))`, count/start with at least one bit, little-endian `ceil(bits/8)` bytes, over-width values to `HostUnrepresentable`). Widths, errors, and failure classes are not newly invented; duplicating the private writer leaves existing codec visibility unchanged.
- **All four record orders and fixed shapes match P3 §3.** EnvGetScan uses `max(1,E)` rows, FindScan uses `F` rows with retained `seen` beyond active functions, BindPreflight uses `P` rows plus a checked `P(P-1)/2` flat strict-upper-triangle `Vec<bool>` with no `pass_P` or diagnostic column, and EqScratch uses exactly `Q_eq` (required `>=1`) rows each with exactly `W_eq = 1+D+K` ordered `(L,R)` pairs, two fixed `fL` entries and two fixed `fR` entries, and no header or result column. The `D` agreement check, the even-factor-first triangle arithmetic, and all length checks occur before emission. Column order, `VR = Bool + id(max(K,D))`, `ER = Bool + id(E)`, `NODE = enum + id(T) + id(Q) + u8[16] + Bool + start/count(max(DF,KF))`, one-byte booleans, and enum tags `0/1/2` all match the adopted column lists.
- **Shape encoding only.** `AuxBlock::ordered_bytes(&Capacities, &StateCapacities, &AuxDimensions)` copies supplied flags and columns (`res_found`, `ok`, `hd`, `seen`, `term`, and the rest) without deriving enables, proof truth, step selection, E/F/B/Q equations, disabled-record zeros, capacity adequacy, or any acceptance bit. `AUX_PROFILE` is a non-serialized source identifier only. This is precisely the bounded component claimed; there is **no complete `packStepWitnessA` consumer**, and arithmetic/fuel-borrow witness placement (R2-2/condition 4) remains owner-reserved.

### Expected packing derivations, hand-checked

For the ordinary fixture (`E=1,F=2,P=3,D=1,K=1,Q_eq=1,W_eq=3`, `N/T/Q/X=4`, `V=4`, `DF=KF=2`, all scalar lanes one byte):

| Record | Derivation | Bytes |
|---|---|---:|
| EnvGetScan | header `1 + VR(2) = 3`; row `1+ER(2)+1+VR(2)+ER(2)+1+1 = 10`; `3 + 1×10` | 13 |
| FindScan | header `1 + 1 = 2`; row `5`; `2 + 2×5` | 12 |
| BindPreflight | header `8`; row `9`; `8 + 3×9 + 3` matrix | 38 |
| EqScratch | row `1 + 1 + 3×4 + NODE(22) + NODE(22) + 1 + 4 + 4 + 1`; `1×68` | 68 |
| **Total** | `13 + 12 + 38 + 68` | **131** |

The wide-name case (`N=257`, name lane two bytes) widens exactly the six NameId lanes (one Env row, two Find rows, three Bind rows), giving `131 + 6 = 137`. The zero-minimum case gives `13 + 2 + 8 + 60 = 83`, including one Env row at `E=0` and one Eq row at `W_eq=1`. All six literal vectors agree with these derivations by reading, as they did for r1.

### Interface and test limits

The six tests remain independent whole-literal expectations frozen before the implementation per `TESTS-FIRST.json`; for r2 the test body differs from the historical freeze only in the import spelling, and no new test-first ordering claim is made. Coverage gaps are real and remain limits, not blockers for this shape-only scope: not every enum variant (notably Absent, Mismatch, Bool, and Constructor), every multi-byte lane, long scans, multiple Eq rows, or `P >= 4` triangles are exercised; no malformed, hostile, security, or refusal tests were authored; disabled-record all-zero constraints, active-index guards, typed-node consistency, canonicality, StepInv/chaining, and Constant typing/D-NAMES remain unenforced obligations. **All Rust syntax, type checking, compilation, parsing, and all six tests are UNRUN** — nothing here is compilation, platform, or execution evidence. The retained unrun compilation risks from r1 (for example unused `AUX_PROFILE` and enum variants raising `dead_code` warnings) are unchanged by the rename.

### Retained bindings and limits

The P3 binding errata R2-1, R2-3, R2-4, R2-5, R2-6 and conditions 1–8 govern as adopted, and the Muse R2-4 dissent is preserved verbatim: R2-4 must not be read as selecting an exact-need reporting format or a circuit ordering mechanism; `Q_eq+1` is a labelled lower bound only. The r2 documentation limits are sustainable without further byte changes: F2 (the flat `eq_name` producer order is a documented convention, and for `P <= 3` row-major and column-major coincide, so the fixture cannot distinguish them), F3 (`ZERO_MINIMUM` is width/shape-only and outside the valid L4 capacity domain, with no minima check added), F4 (component shape errors are not P3 Capacity refusals, the R2-4 classifier, needed metadata, or a native refusal ABI, and the L4-only `WrongProfile` obligation is retained with no such consumer added), F5 (dimensions above `usize::MAX` may yield `WrongRepresentation` rather than `HostUnrepresentable`, with no new representability check), F6 (the width/writer code remains a private copy requiring future synchronization, and the pre-existing `encoding.rs` byte-granularity observation remains out of scope), and F7/H1 (capacities are caller-trusted and unbound to `PreparedA`, the StateBlock codec dimensions, or the statement, and the only callers are the private `cfg(test)` tests, with no complete `packStepWitnessA` consumer). No new unselected encoding, profile, resource, or refusal mechanism was found — and none is approved by this review. Native authority remains 0; C4, all existing caps, counters, and terminal failures, the full39 map, the seven L4 bodies, and the full roadmap remain unchanged and open.

**APPROVED_NORMAL_SOURCE_WITH_LIMITS** for candidate `ec8ee67f9492e143ea0b40c05e514b9b8aaf04207d00ab70a5345c8f58242bf8`.
