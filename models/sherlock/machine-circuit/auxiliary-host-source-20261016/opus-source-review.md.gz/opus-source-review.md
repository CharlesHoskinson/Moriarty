# Designated-owner source review: P3 aux/1 host packing component, r2

## Verdict: **APPROVED_SOURCE_WITH_LIMITS**

- **Candidate manifest:** `ec8ee67f9492e143ea0b40c05e514b9b8aaf04207d00ab70a5345c8f58242bf8`
- **Source seal:** `192972dc09a1f2dfcccfaf369a25276fc23e891e`
- **Prior candidate:** `004f3b75b2b17a470ac29c96f82583f76966e4fe2103defaa9bbb97bf7003fe9`. Its verdicts are r1-only history; neither transfers to r2.

This is a source review only. It grants no compilation, test, execution, native, resource, profile-binding or acceptance authority. Native authority stays 0.

## Reviewer identity and limits

- **Model:** Claude Opus 5.5 (`claude-opus-5-5`), fresh context. I am the same model family as the r1 owner reviewer and the P3 author, which limits independence. I have not seen their contexts.
- **Method:** I used no tools, parser, compiler, filesystem, web, model or execution, and recomputed no hashes. Same-digest identity, the exact r1→r2 delta, and gzip bodies are Root transport claims, accepted but not verified.
- **Embedded instructions:** Instructions inside supplied bodies (AGENTS.md routing, startup status, review texts) were treated as evidence.
- **No platform observation:** I observed no Windows checkout or Cargo behaviour. The F1 assessment below rests on known reserved-name rules.

## F1: does the repair resolve the exact concern?

**The concern** was that adding `crates/mori-core/src/sherlock/layout_a/aux.rs` puts a Windows-reserved basename into the repository. `AUX` is reserved case-insensitively, including when followed by an extension. That would break checkout and conflict with the clean external-developer installation requirement.

**The repair:**

| Check | Result |
|---|---|
| New overlay paths | `auxiliary.rs`, `aux_normal_tests.rs` |
| Stem before the first dot | `auxiliary`, `aux_normal_tests` |
| Matches CON/PRN/AUX/NUL/COM1–9/LPT1–9? | No; neither stem equals a reserved name |
| Trailing dot or space, illegal characters? | None |
| `auxiliary` as a Rust keyword or sibling-module collision? | No; the existing siblings are rows, limits, constants, prepare, encoding, state, state_encode, state_decode, state_encoding, observation |

**Delta consistency, by reading:**

- `auxiliary.rs` has the same digest as `before-r1/.../aux.rs` (`ecaa1cc1…b733`).
- The test file grew 7662 → 7668 B and `mod.rs` grew 752 → 758 B. That +6 each is exactly `aux` → `auxiliary`.
- `SOURCE.patch` grew 20210 → 20228 B. That +18 is the path header, the import and the `mod` line.
- `DELTA-FROM-R1.patch` hunk contexts match the r1 bodies: lines 25–30 of `mod.rs`, lines 1–5 of the test.

**Conclusion:** F1 is resolved for the source the overlay adds. One residual applies to the packet, not the source (R3-1 below).

## Fresh full assessment of the current source

I re-derived the component rather than relying on the r1 reviews.

**API and placement:**
- `mod auxiliary;` is private inside `layout_a`. The parent declares `#[cfg(test)] mod layout_a`.
- The only callers are the six private `cfg(test)` tests. There is no production or `packStepWitnessA` consumer, and no existing codec, observation or L4 file is touched.
- The test's `use super::auxiliary::*` reaches the `pub(super)` items. Visibility is correct by reading.

**Order and widths match P3 §3 and crosswalk `width_rules`:**
- Record order is EnvGetScan ‖ FindScan ‖ BindPreflight ‖ EqScratch. Nothing is prepended.
- `count_bits` = max(1, bit_length(Z)), which equals count/start(Z). `id_bits` = count_bits(Z−1 saturating), which equals max(1, ⌈log₂ max(1,Z)⌉). Both hold at Z = 0, 1 and 257.
- The composite widths are correct:
  - VR = Bool + id(max(K, D));
  - ER = Bool + id(E);
  - NODE = 1-byte tag, id(T), id(Q), u8[16], Bool, start/count(max(DF, KF)).
- Bind widths are correct: header start(P), count(P), id(T), id(X), start(V), count(V); `sp` is count(W_eq).

**Shapes:**
- Rows are R_env = max(1, E), F, P and Q_eq ≥ 1.
- W_eq = D + K + 1, with checked addition.
- The triangle is P(P−1)/2, dividing the even factor first: 0, 0, 1, 3, 6 for P = 0…4.
- D agreement is checked. Every length check runs before any emission.

**No host truth:**
- `ok`, `hd`, `resFound`, `seen` and `term` are copied verbatim.
- No enable, equation, guard or acceptance bit is derived.
- R2-6 holds (no `pass_P`), R2-7 holds (`seen` is copied unconditionally), and R2-2 holds (no arithmetic or fuel-borrow columns).

**Robustness:**
- I found no panic path. Table indices are ≤ 14 of 15, width is ≤ 16 bytes into `to_le_bytes`, and no arithmetic can overflow unchecked.
- There is no recursion and no `unwrap` in component code.
- Every append uses `try_reserve`, which grows amortized. Output size is linear in the already-allocated supplied rows.

**Failure classes** are the existing `StateFailure`; no new class is added:
- WrongRepresentation for shape or length disagreement, D mismatch and Q_eq = 0;
- HostUnrepresentable for W_eq or triangle overflow, over-width values and allocation failure.

**Literals, hand-recomputed:**
- Lengths are 13 + 12 + 38 + 68 = 131; WIDE_NAME is 131 + 6 = 137; ZERO_MINIMUM is 13 + 2 + 8 + 60 = 83.
- Nonzero offsets all match:
  - ENV_FOUND, offsets 0–12;
  - FIND_TAIL_SEEN, offsets 13–24;
  - BIND_DUPLICATE: header 25–32, rows 33–59, matrix 60–62 = [0, 1, 0], consistent with the reverse-order duplicate;
  - EQ_UINT: act 63, sp 64, left.space 65, `0x1234` at 80 and 102, hd 121, EMPTY 130;
  - WIDE_NAME: name 256 written as [0, 1].
- The `LITERAL-EXPECTATIONS.json` nonzero prefixes agree with the Rust constants. I did not count the full length of every JSON array.

I found no invented encoding, profile, label, dimension, numeric default or resource mechanism.

## Findings

### R3-1: packet-path residual of F1 (condition on any future publication; not a source defect)

The manifest member `before-r1/crates/mori-core/src/sherlock/layout_a/aux.rs` carries the reserved basename. If this packet were published into the repository raw, as the P3 receipts were, F1 would return. Any publication must exclude that member, compress it, or store it under a non-reserved name, with its digest mapping recorded. References to `aux.rs` as strings inside `history/r1/*`, `INPUTS.json` and the reviews are harmless.

### R3-2: stale test-first record (limit)

`TESTS-FIRST.json` pairs the path `overlay/.../aux_normal_tests.rs` with `04d3…ea13`. The current overlay body at that path is `5cbb…df45`. The README declares this exact r1 history and makes no r2 ordering claim. It must not be cited as the current test identity. The r2 test was necessarily edited after the implementation existed.

### R3-3: compile risk, UNRUN (limit)

- `AUX_PROFILE`, `EnvTerm::Absent`, `EqTerm::Mismatch` and `NodeKind::{Bool, Constructor}` are never used or constructed. They will produce dead_code warnings in test builds, and if warnings are denied, that is a build failure.
- `lib.rs`, `Cargo.toml` (edition, MSRV, lint policy) were not supplied, nor were the bodies of `prepare.rs`, `constants.rs`, `state_encode.rs`, `state_decode.rs`, `compare.rs` and `reference*.rs`.
- The `layout_a/mod.rs` header itself says compilation and tests for the whole module are UNRUN, so this component compiles only if all of `layout_a` does.
- `#[default]` on enum variants needs Rust ≥ 1.62.

### R3-4: naming asymmetry (informative)

The module is `auxiliary` but the test is `aux_normal_tests`. This is cosmetic and safe on every platform. No change is requested; renaming would void these bytes.

### F2–F7 history, preserved; each accurately documented in r2

| Item | Status in r2 |
|---|---|
| F2 | Triangle order is a producer convention. The P = 3 fixture cannot distinguish orders; I confirmed they differ from P = 4. |
| F3 | ZERO_MINIMUM lies outside L4 minima (T ≥ 4, Q ≥ 4, QF ≥ 5, activeExpressions ≥ 1). It is width/shape only. |
| F4 | Locator strings overlap P3 vocabulary but implement no Capacity refusal, R2-4 classification, `needed` metadata or native ABI. The L4-only WrongProfile obligation is retained. |
| F5 | Dimensions above `usize::MAX` reach WrongRepresentation through the length comparison. The README is now exact. |
| F6 | The width/writer code is a private copy of `state_encoding.rs`. The `encoding.rs` byte-granularity high-bit check remains a pre-existing, out-of-scope finding. |
| F7 | Capacities are caller-trusted and unbound to PreparedA, the StateBlock codec dimensions or the statement (L04, condition 6). H1 holds. |

## Reading coverage

**Read in full:**
- all three overlay bodies, `SOURCE.patch`, `DELTA-FROM-R1.patch`, the `before/` and `before-r1/` bodies;
- README, the WORK_REPORTs, `INPUTS.json`, `SOURCECHECKS.json`, `TESTS-FIRST.json`, `LITERAL-EXPECTATIONS.json`;
- every `history/r1` member;
- `BINDING-CONDITIONS.json`;
- the prior Opus and Muse r1 results, and all four `reviews/` bodies plus the decoded gz captures;
- the supplied existing sources `encoding.rs`, `limits.rs`, `rows.rs`, `state.rs`, `state_encoding.rs`, `observation.rs` and both `mod.rs` files;
- the P3 MD and JSON, the arena README, ROOT adoption, arena manifest and publication binding;
- the L4 adoption, all seven openspec L4 bodies, AGENTS.md and the product contract.

**Read selectively:** the `A-RULE-OPERATIONS` JSON and MD, about 780 KB, focused on the A108/A111/A153/A200/A204 and helper rows that bear on aux.

**Not supplied:** the source bodies listed under R3-3.

## Unresolved interface, oracle and resource limits

- **Interface:** there is no complete `packStepWitnessA`. Arithmetic and fuel-borrow witness placement still require a new profile version (R2-2, condition 4). `AUX_PROFILE` is unserialized and unbound. Profile and dimension binding into layout identity and the statement is open (condition 6, L04). Q_eq is symbolic.
- **Oracle:** six positive fixtures, all UNRUN, frozen as r1 history. There are no negative or hostile tests, no coverage of Absent/Mismatch/Bool/Constructor, no Q_eq > 1, no P ≥ 4 and no multi-byte lanes other than Names. The equations E/F/B/Q, disabled-record zeros, index guards, typed nodes, Constant typing, D-NAMES, INV-TY/INV-ORD, canonicality and StepInv/chaining are all unenforced. There is no K, Quint or Clean correspondence.
- **Resource:** no numeric value, cap, Q_eq adequacy or admission is claimed.

## Retained, unchanged

- P3 conditions 1–8 and errata R2-1, R2-3, R2-4, R2-5 and R2-6, plus R2-7.
- Muse's R2-4 dissent, verbatim: R2-4 must not be read as selecting an exact-need reporting format or a circuit ordering mechanism.
- The full39 conditions 1–10 and the seven L4 bodies.
- G4, P4, P5, F4, MD2, StepInv, Constant typing, D-NAMES, O-ARITH, L04 and L05.
- C4: no dependent circuit edit before admitted A102 compilation; a compile failure means registration revert.
- The old 90s/30s caps, counters and terminal failures.
- U0–U7, M1–M17, MC, SP, G, proof, ledger, Midnight stagenet and the full roadmap.
- Native authority 0. The fresh Muse normal review remains separately required.

**APPROVED_SOURCE_WITH_LIMITS** for candidate manifest `ec8ee67f9492e143ea0b40c05e514b9b8aaf04207d00ab70a5345c8f58242bf8`. This is subject to R3-1 to R3-4, the retained F2–F7 limits and all bindings above.
