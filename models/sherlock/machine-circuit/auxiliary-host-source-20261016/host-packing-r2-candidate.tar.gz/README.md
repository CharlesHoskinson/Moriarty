# P3 aux/1 host packing source candidate r2

This packet contains a three-file overlay against source seal
`192972dc09a1f2dfcccfaf369a25276fc23e891e`. The original source-seal checkout remains read only. The r2 patch is
constructed from r1 frozen beforeimages; this revision does not rebase it. Root identifies PR97 merge `e0740ced478e92dc533f6c4cfa30210575d35869`;
r1 observed the source-seal worktree HEAD, not the merge object's tree.
`INPUTS.json` pins the actual read source. This new implementation needs fresh
Opus owner and Muse normal reviews. No compilation, parser, formatter or test
execution occurred.

The callable source predicate is
`AuxBlock::ordered_bytes(&Capacities, &StateCapacities, &AuxDimensions)`.
It receives four supplied records, checks their fixed shape and scalar widths,
and returns their ordered bytes. It does not receive a Program, Snapshot,
StepRecord, rule selector or enable, and does not compute a semantic result.
Existing supplied witness columns such as `ok`, `hd`, `resFound`, `seen` and
`term` are copied as columns; none becomes a host acceptance flag.

## Source graph and actual consumer limit

The overlay adds `auxiliary.rs` and `aux_normal_tests.rs` and appends only their private
module declarations to `layout_a/mod.rs`. The existing parent declaration in
`sherlock/mod.rs` is `#[cfg(test)] mod layout_a`. The six normal tests are the
only newly authored callers. This gives an internal typed packing component
and source registration, not a production witness consumer. Existing
`observed_state_bytes_a` canonically encodes a Snapshot; it must not be reused
as a supplied-aux validator and is untouched.

There is no complete `packStepWitnessA` consumer. Owner R2-2/condition 4 retains
arithmetic and fuel-borrow witness placement as a required profile revision;
this task cannot fill that choice. No profile prefix, dimension prefix, native
ABI, label binding, Program/pre/post packing or step relation is invented.
`AUX_PROFILE` is a source identifier only. The component returns only AuxBlock
column bytes. Native statement binding remains open.

## Exact requirements projection

| Source requirement | Implementation |
|---|---|
| P3 §3.0 record order | EnvGetScan, FindScan, BindPreflight, EqScratch |
| Fixed dimensions | E/F/P/D/K read from existing caller capacities; Q_eq explicitly supplied and >=1; D agreement checked; W_eq=1+D+K checked arithmetic |
| Env rows | Exactly max(1,E), including E=0 |
| Find rows | Exactly F; every supplied row emitted, including retained `seen` beyond activeFunctions (R2-7) |
| Bind rows/matrix | Exactly P rows and P(P-1)/2 supplied booleans, flat strict upper triangle in documented row-major order; no pass_P column (R2-6) |
| Eq rows/stack | Exactly Q_eq rows, each exactly W_eq ordered (L,R) pairs; two fixed fL entries then two fixed fR entries; no header/result column |
| L4 scalar rules | id(Z)=max(1,bit_length(Z-1 saturating)), count/start(Z)=max(1,bit_length(Z)); ceil(bits/8) LE bytes; unused high bits checked |
| Bool and enum | Bool emits exactly 0/1; typed three-variant enums have tags 0/1/2, each emitted in one byte |
| VR / ER | Existing ValueRef / EnvRoot; bool then id(max(K,D)) / id(E) |
| NODE | kind,id(T),id(Q),16 supplied UInt bytes,bool,start(max(DF,KF)),count(max(DF,KF)) |
| Allocation | Existing state_encoding-style `try_reserve` before each append; no eager dimension-sized allocation or numeric cap/default |
| Located failures | WrongRepresentation for length/dimension disagreement (including a representable supplied vector length versus a dimension > usize::MAX); HostUnrepresentable for checked u128 arithmetic overflow, over-width supplied scalars or byte-allocation failure; no MachineOutcome conversion |

Ordered Rust fields and serialization calls map as follows:

- Env header: res_found, res_value. Rows: act, cur, name_id, value, parent,
  matches, term. Found=1, Absent=2.
- Find header: out_present, out_id. Rows: act, name_id, matches, seen, first.
- Bind header: parameters_start, k, return_type, body, values_start,
  values_len, len_ok, ok. Rows: reached, name_id, parameter_type, argument,
  argument_type, type_ok, duplicate, pass. Then eq_name[(0,1),(0,2),...].
- Eq rows: act, sp, stack pairs left/right, left NODE, right NODE, hd,
  fields_left[0..2), fields_right[0..2), term. Mismatch=1, Empty=2.

The NODE host type uses `usize` for id(T), as for other IDs; the explicit L4
width remains capacity-derived. It does not derive kind/type/constructor
consistency. Vec<bool>'s host storage has no wire significance: each matrix
entry emits one Bool byte. Defaults exist only for zero rows and enums, never
for capacities, Q_eq, a full AuxBlock, or resource admission.

Shape errors here are component packing errors, not implementation of the
owner's machine-step refusal ordering. The code does not compute Capacity,
Q_eq adequacy, needed counts or the R2-4 lower bound. In particular it does not
run L4 Step decoding and cannot claim the composite R2-4 refusal classifier.

## Test-first literal expectations (all UNRUN)

`TESTS-FIRST.json` and `tests-first/aux_normal_tests.rs` preserve the exact r1
historical freeze, which records that aux.rs did not yet exist. The r2 overlay
test differs from that historical file only by `super::aux` -> `super::auxiliary`.
The expected literals and all six test bodies are unchanged; no new test-first
ordering claim is made for r2. `LITERAL-EXPECTATIONS.json` contains complete byte vectors,
transcribed from listed columns before implementation, not produced by any
encoder, evaluator or model. The Rust tests contain the same complete literal
vectors rather than computing expected output through packing helpers.

The ordinary fixed example uses E=1,F=2,P=3,D=1,K=1,Q_eq=1,W_eq=3,
N/T/Q/X=4,V=4,DF=KF=2. These are example inputs only. Its record lengths are
13,12,38,68 bytes, for 131 bytes total:

1. Env FOUND at cell 0, name 3, Constant reference 0; all other records zero.
2. Find first match in row 0 with row 1 inactive and `seen=true` retained.
3. Bind names [1,2,1], reverse-order duplicate failure, supplied row results,
   triangle (0,1)=0,(0,2)=1,(1,2)=0; no semantic decision computed by the test.
4. Eq single UInt leaf 0x1234 across Data/Constant references, full three-pair
   stack, two 22-byte NODE records and EMPTY terminal. UInt bytes are supplied
   verbatim, including all fourteen trailing zero bytes.
5. N=257, name=256, preserves the full fixed record order while all six NameId
   lanes widen to two bytes; complete expected length 137.
6. All base capacities zero, Q_eq=1: one Env row, no Find/Bind rows or matrix,
   one Eq row with W_eq=1; 83 zero bytes. ZERO_MINIMUM is a width/shape-only
   fixture OUTSIDE the valid L4 program-capacity domain: T=Q=QF=X=0 violates
   T>=4, Q>=4, QF>=5 and activeExpressions>=1. The component does not check
   those minima. This is neither a valid-program fixture nor evidence that
   the capacities satisfy L4.

These six examples are not comprehensive column/domain coverage: they do not
exercise every enum variant, every multi-byte lane, long scans or multiple Eq
rows. No malformed, hostile, security or refusal test was authored. All source
and expected bytes require fresh review and later separately authorized checks.

## Retained owner bindings and open work

`BINDING-CONDITIONS.json` preserves the complete Root adoption and publication
binding. `reviews/` preserves all four decoded full source/publication reviews;
`inputs/` retains exact original public gzip captures. Historical author-time
PROPOSED labels remain unchanged. This packet does not extend their approvals
to these Rust bytes.

All conditions 1–8 and errata remain: arithmetic integer/range domains (R2-1),
incomplete whole witness profile (R2-2), INV-ORD-PRE as an unenforced StepInv
precondition (R2-3), qualified refusal ordering/lower-bound reading (R2-4),
typed A214 domain implications (R2-5), pass_P notation only (R2-6), and Find
inactive-tail seen (R2-7). The exact preserved Muse dissent is:

> I preserve one dissent from any broader reading of the Opus vote: R2-4 must not be read as selecting an exact-need reporting format or a circuit ordering mechanism. It is accepted only as the bounded refusal-classification reading above.

The supplied records still owe E/F/B/Q equations, disabled-record all-zero
constraints, active index guards, unused NODE-column zeros, Constant typing,
D-NAMES, INV-TY/INV-ORD, canonicality and StepInv/chaining. Nothing here enforces
those relations. G4/P4/P5/F4/MD2/O-ARITH/L04/L05, full39/B/financial work,
proof/ledger/Midnight stagenet and all U/M/MC/SP/G exits remain open.

C4 still forbids dependent circuit changes before admitted A102 compilation;
compile failure requires registration revert, not a hotpatch. No circuit file
is in this overlay. Native authority remains 0. The historical 90s/30s caps,
terminal failures/counters, old compile subjects and SDK payload barriers are
unchanged. No source execution or new execution grant is implied by this packet.

## r2 owner-directed correction and retained F2–F7 limits

F1 changes only the filename/module name `aux` to `auxiliary`, plus the one
normal-test import. The auxiliary.rs body is byte-identical to r1 aux.rs.
The owner's reason is the Windows-reserved AUX basename, including extensions;
no Windows checkout or compiler behavior was observed here.
`DELTA-FROM-R1.patch` records this exact source delta. r1, its BLOCKED_SOURCE
Opus vote and its APPROVED_NORMAL_SOURCE_WITH_LIMITS Muse vote are immutable;
both apply only to r1 and neither approves r2. Fresh complete votes are required.

- **F2:** eq_name is a flat Vec<bool>; producer order is a documented convention,
  not checked. For P<=3, row-major and column-major strict-upper-triangle order
  coincide. The unchanged P=3 fixture cannot distinguish those producer orders.
- **F3:** ZERO_MINIMUM is outside the valid L4 capacity domain, as stated above.
  None of these supplied packing fixtures is bound to a prepared canonical
  Program; source validity and minimum capacities are not established.
- **F4:** the existing error/locator strings overlap P3 vocabulary but do not
  implement P3 EqScratch.rows/stack Capacity refusals, R2-4 ordering, needed
  metadata, or a native refusal ABI. The owner retains the requirement that
  an L4-only consumer report WrongProfile for the extension. This component
  adds no profile-dispatch consumer and changes no existing failure class.
- **F5:** dimensions above usize::MAX are not unconditionally classified as
  HostUnrepresentable. For example F above usize::MAX reaches the length
  comparison and produces WrongRepresentation; checked u128 arithmetic can
  fail earlier for other dimensions. No new representability check is added.
- **F6:** the width/writer code is a private copy of state_encoding.rs and must
  be kept in sync with future width changes. The owner's separate observation
  that pre-existing encoding.rs checks high bits only at byte granularity is
  retained as an out-of-scope finding; this revision does not repair that code.
- **F7:** capacities are caller-trusted inputs, not bound to PreparedA, the
  StateBlock codec dimensions or the statement. Their L04/condition-6 binding
  remains open. H1 remains: private normal-test callers only and no complete
  packStepWitnessA consumer.

The full owner review is retained in prior-candidate-reviews/opus-RESULT.json
and its exact text companion, including unrun compilation risks and coverage
gaps. No fixture, allocation strategy, failure class, numeric default or
packing behavior is changed to resolve these limits. All six tests remain
uncompiled and UNRUN. PR98's separately merged model work does not alter this
overlay or its original source-seal basis.
