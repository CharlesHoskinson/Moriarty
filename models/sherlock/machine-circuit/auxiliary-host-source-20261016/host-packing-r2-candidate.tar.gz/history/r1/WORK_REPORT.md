# Frozen aux/1 host source candidate

Implemented a pure typed supplied-AuxBlock packing component in a three-file
overlay against observed source seal `192972dc09a1f2dfcccfaf369a25276fc23e891e`.
The source checkout was not edited. The exact patch is `SOURCE.patch`.

- `aux.rs`: four record families, fixed shape checks, explicit symbolic Q_eq,
  L4 byte widths/order, fallible incremental byte writes and existing located
  error types. No step evaluation or derived host acceptance flag.
- `aux_normal_tests.rs`: six ordinary complete literal byte expectations,
  frozen before implementation. All six tests are UNRUN.
- `mod.rs`: only private aux and normal-test module declarations appended.
  The existing parent gates layout_a with cfg(test).

Source inspection covered the existing state byte consumer and shared
Capacities/StateCapacities/ValueRef/EnvRoot/Slice/failure APIs. Existing observed
Snapshot serialization is unchanged. The only new callers are normal tests;
this is not a production or complete step-witness path. Arithmetic and
fuel-borrow placement remain an owner-reviewed profile prerequisite for a
complete packStepWitnessA consumer. No new profile or native binding is selected.

`TESTS-FIRST.json` records the pre-implementation test bytes and complete
independent expected byte data. `SOURCECHECKS.json` records only literal, hash
and text observations: exact registration append, six declarations, literal
text agreement, unchanged test-first bytes and all 35 copied source inputs
unchanged. This is not Rust syntax/typechecking or execution evidence.

The only source invocation was the explicitly permitted startup status command
with `python3 -B`, exit 0, captured in `STARTUP-STATUS.json`. No new Rust source,
encoder, test, SDK, K/Quint/Lean/native tool, parser or formatter was executed.
No model/network operation occurred. All authored source is uncompiled.

`INPUTS.json`, `inputs/`, `reviews/` and `BINDING-CONDITIONS.json` preserve the
adopted P3 bytes, all seven pinned L4 files, full39 rule facts, four complete
source/publication reviews, exact Root/publication bindings and Muse's R2-4
dissent. Prior approvals apply to those inputs, not to this new implementation.

Fresh full Opus owner and Muse normal audits are required. Six normal fixtures
do not provide complete enum/width/trace coverage; no hostile/refusal/security
tests were authored. Q_eq adequacy, semantic equations, disabled-record zeros,
active guards, INV-TY/INV-ORD, canonicality, StepInv, G4/P4/P5/F4/MD2/O-ARITH,
L04/L05, full39/B/financial and target acceptance remain separate obligations.

Native authority remains 0. C4, compile-failure registration revert, old
90s/30s caps, counters and terminal failures remain unchanged. No circuit edit,
execution admission, numeric resource choice, source publication or commit was
performed. Requested routing was GPT-6 Astra high; author is the assigned
/root/astra_sdk_compile_diagnosis agent. No separate provider canonical identity
receipt is available for this agent turn.
