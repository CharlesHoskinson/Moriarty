# Publication review: Sherlock CandidateA P3 arena source publication

## Verdict: **APPROVED_PUBLICATION_WITH_LIMITS**

This is the designated-owner security and publication-interpretation review. It does not reopen any adopted design choice. It grants no execution, resource, numeric, operator, configuration, binding, circuit, proof, ledger or stagenet admission. Native authority remains 0.

## Reviewer identity and limits

- **Model.** I am Claude Opus 5.5 (`claude-opus-5-5`), in a fresh context.
- **Independence limit.** The P3 author and the source-review owner are the same model family. I have not seen either of their contexts.
- **No tools.** I used no tools, filesystem, web, parser, model or runtime. I recomputed no hashes.
- **Transport claims accepted, not verified.** These are Root's claims:
  - byte identity of the 12 files;
  - gzip round-trips and decoded bodies;
  - the staged whitespace check (exit 0);
  - base and source commits;
  - that full39, the seven L4 files and the Rust sources are untouched.
- **What I did compare.** My consistency checks are reading comparisons of the supplied text only.
- **Embedded instructions.** Instructions inside the payloads were treated as evidence and not acted on.

## Exact subject

- **Base:** `bd62ed7041ebdd92e08986f628c8b7b889b7ce1a`
- **Source commit:** `8194011357795e77f37cfc6686ab28f88bbbc08a` (PR #97, draft)
- **Candidate manifest:** `a6c322afd9ca23dd0a236c56ac82948c043db9e32a507f7f6a52cc8b17ff4e2b`

Paths below are relative to `models/sherlock/machine-circuit/arena-policy-source-20261016/` unless shown in full.

| Path | Bytes | SHA-256 |
|---|---|---|
| `ROADMAP.md` | 28118 | `c4eab6d60845674769b6321db8d88abd6435f4e6b4938c396949c3885b7cacd7` |
| `A-ARENA-OPERATIONS.json` | 27137 | `3f33a0dc7fe831022b109ae0d60f2eb8cc9167e94bbc3d27c95a61ebdddbb214` |
| `P3-ARENA-DESIGN.md` | 65930 | `b2d6fda4b07804406f8f6d1c4ed9aa4d86031ccffb4bbb6e0be2c7cdab8891eb` |
| `README.md` | 2363 | `4201e00b7ea5c467917b4aa9a097de09cfdd927b52d294c67324571f24a5a310` |
| `ROOT-COMPLETE-P3-SOURCE-ADOPTION.json` | 5733 | `782a2db684298d9acc77850a40d9f79ec40934774a2c338f51134f3e04aefd3d` |
| `SOURCE-MANIFEST.json` | 2590 | `e7c34e524a6f6aa002307124a9f2f0ad6f856c9522135cd74b8f65a1e9f7984f` |
| `muse-source-review.json.gz` | 5267 | `c9b4abdd46b9192f2b12808fa9718c4641fa2273a167d11d5e02258ae29c7a40` |
| `muse-source-review.md.gz` | 5059 | `d3b2aeff6015e62e42ef8d3c11d416b232352b7e24ced81e7d7f2d3894fdc185` |
| `opus-source-review.json.gz` | 9341 | `fbaf1e5e46e9256b679bc2c007a3d0affbc8ae1e1931b184c34bbce886e9a44f` |
| `opus-source-review.md.gz` | 9074 | `51917a50a3152949755e6908cfd429222eafad7e0275c67d5e5abb77dd49be57` |
| `owner-author-result.json.gz` | 24205 | `3670e1eddf054c517797ef4bd620070dbbb4c0add4a7df402acd2ed929b450ed` |
| `openspec/changes/sherlock-machine-circuit-layout/IMPLEMENTATION-STATUS-2026-10-16.md` | 6206 | `c3df8d754e099bc7195c8f51a12809ed82fe57eb245c299ffc06749037ad4073` |

## What checks out

**Completeness.** All the pieces are present:
- the exact design, its JSON catalog and the original manifest;
- the Root record;
- the author capture;
- both source-review captures (JSON and MD);
- the README;
- the two dated status additions.

**Hash and size agreement.** The Root subject entries match the payload rows:
- MD `b2d6…91eb`, 65930;
- JSON `3f33…b214`, 27137;
- manifest `e7c3…984f`, 2590.

The Opus and Muse votes name the same three hashes.

**Chronology.** The manifest was created at 09:47:20 and the Root record at 10:03:09.

**Root record fidelity.**
- `owner_binding_conditions_verbatim` reads identically to Opus §9, conditions 1–8.
- `muse_refusal_qualification_verbatim` reads identically to Muse's R2-4 bullet.
- `binding_rule` binds R2-1, R2-3, R2-4, R2-5 and R2-6, conditions 1–8, and the complete Muse review, and says "Preserve dissent".

**README errata mapping.** The README phrases map correctly onto the binding errata:

| README phrase | Erratum |
|---|---|
| arithmetic ranges | R2-1 |
| pre-state ordering | R2-3 |
| refusal precedence / lower-bound reporting | R2-4 |
| typed A214 guards | R2-5 |
| BindPreflight boundary notation | R2-6 |

The README also states that `Q_eq+1` is only a labelled lower bound, and that `aux/1` is not a complete step-witness profile (R2-2, condition 4).

**Original manifest versus publication.** The README states the distinction explicitly. The original manifest "records the source packet, not this publication directory", and runtime paths are historical. The manifest's `OWNER-RESULT.json` is carried as `owner-author-result.json.gz`.

**Scope.**
- No executable, model, L4, full39 or Rust path is among the 12 files.
- Both status diffs are additions only.
- Every file keeps C4, native authority 0, existing caps and counters, the open G4/P4/P5/F4/MD2/StepInv/D-NAMES/O-ARITH/L04/L05 items, and every U/M/MC/SP/G and stagenet exit open.

**New links.** All three new relative links resolve to candidate paths by path arithmetic:
- README → three siblings;
- ROADMAP → README;
- status note `../../../` → README.

**Sensitive content.** I found no keys, auth material, debug output or Fenrir/Clean tool paths in the 10 new files.

## Findings (none blocking)

**PUB-1: integrity mapping for the compressed captures (limit; fix in the binding).**
- No payload file maps each `.gz` to its uncompressed original identity. Those identities are:
  - `OWNER-RESULT.json` `9664…c99c`, 70969 bytes;
  - Opus `RESULT.json` `8b80…cf05`, 21222 bytes;
  - Muse `RESULT.json` `bf92…745b`, 11423 bytes.
- The two `.md.gz` captures have no published original hash anywhere.
- By reading, each MD body appears to be the corresponding JSON `text` field plus one final LF. I have not verified this byte for byte.
- The README's statement that the captures "preserve exact original bytes" therefore depends on Root's claim.
- The publication-binding JSON should record, for each capture: compressed and uncompressed bytes and SHA-256, the Root-listed original, and the MD derivation. All of these should be marked as Root-verified transport facts.

**PUB-2: frozen authoring-time labels (limit).**
- These labels are stale relative to the adoption:
  - `PROPOSED_UNADOPTED_SOURCE_DESIGN` in the JSON and MD;
  - the final line `…UNADOPTED_UNRUN` in the MD;
  - `FROZEN_…_NOT_ADOPTED_UNRUN` in the manifest.
- They cannot change without voiding the votes.
- The README governs them by calling the design "unchanged" and pointing to the Root record, but it does not say outright that these are frozen authoring-time labels. That is acceptable as published.

**PUB-3: status-note layering (limit).**
- The new section is appended after older text dated at base `5cf27d64…`. That older text says:
  - A177/A181, the A214 root rule, A204 failure scratch and A153 equality scratch "remain P1/P3 gaps/matters";
  - "This publication candidate still needs fresh full owner and Muse publication reviews."
- The new section does not say that it resolves those items at source-design level only.
- There is no false closure claim. Readers should treat the earlier paragraphs as the base-`5cf27d64` snapshot.
- Any wording correction needs a future reviewed dated note, not a post-review edit.

**PUB-4: dissent breadth (limit).**
- Muse's dissent excludes reading R2-4 as selecting either an exact-need format or a circuit ordering mechanism.
- The README states only the first.
- The full capture and Root's "Preserve dissent" preserve the second. The binding JSON should restate both verbatim.

**PUB-5: conditions not named in the summaries (informative).**
- The README and ROADMAP do not name two conditions:
  - condition 5: no emitter acceptance until every §8 item is specified and reviewed;
  - condition 6: profile and dimensions must be bound into layout identity and the statement before native use.
- Both are governed through the Root `binding_rule`.

**PUB-6: provenance content (informative, within scope).** The publication includes:
- absolute runtime paths (`/home/charl/Moriarty/.moriarty-dev/runtime/...`);
- token and cost usage;
- Muse provider `request_id`/`response_id`.

These are historical Moriarty runtime provenance, not credentials, and are permitted by the stated scope. The ROADMAP's existing "private Fenrir fork" wording is base text and was not introduced here.

**PUB-7: discoverability (informative).**
- The README does not list `SOURCE-MANIFEST.json` or the five `.gz` files by name.
- The status note's existing link to `source-review-20261016/publication-binding.json` is base content and cannot be checked from the supplied material.

**PUB-8: no grounds to reopen the design (informative).**
- I found no concrete evidence to reopen any adopted choice.
- The JSON `EnvGetScan.constraints` omits E-8, but its header column definitions encode E-8. This is a representation difference, not a contradiction.
- Pre-existing ROADMAP text outside the new paragraph was not re-reviewed.

## Five-file receipt seal: **covered, under these conditions**

The narrowly defined seal adds exactly two review captures (JSON and MD each, as 4 `.gz` files) and one publication-binding JSON. It is covered by this approval only if all of the following hold:

1. **No edits.** None of the 12 payload files is modified, renamed or removed, and the README and status files are not edited to link the new files.
2. **Required binding contents.** The binding JSON records:
   - source commit `8194011…`, base `bd62ed70…` and candidate manifest `a6c322…`;
   - all 12 paths, bytes and SHA-256 values exactly as above;
   - the actual compressed and uncompressed hashes and bytes of the 4 new review captures, as produced;
   - both verdicts verbatim, with these limits and the Muse review's limits;
   - scope, untouched full39/L4/Rust, C4, native authority 0, all retained gates and PUB-1 mapping metadata.
3. **Both reviews must approve.** If the parallel Muse publication review returns BLOCKED_PUBLICATION, this seal is not covered.
4. **No cyclic claims.** The binding must not claim that either reviewer saw the binding, the review captures or any post-review hash. It must not add new private paths, credentials or reinterpretations of findings.
5. **Any other change voids it.** A byte change to any of the 12 files, or any file beyond these five, voids this approval and requires fresh review.

**APPROVED_PUBLICATION_WITH_LIMITS** for candidate `a6c322afd9ca23dd0a236c56ac82948c043db9e32a507f7f6a52cc8b17ff4e2b` at source commit `8194011357795e77f37cfc6686ab28f88bbbc08a`. This is subject to PUB-1 to PUB-8, the source conditions 1–8, errata R2-1/3/4/5/6, and the preserved Muse dissent.