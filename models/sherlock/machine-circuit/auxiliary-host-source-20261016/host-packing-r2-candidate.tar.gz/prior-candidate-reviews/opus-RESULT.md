# Designated-owner source review: P3 aux/1 host packing component

## Verdict: **BLOCKED_SOURCE**

There is one concrete blocker, F1 below. I found no invented encoding, profile, resource or security mechanism. Byte order, widths and shape checks conform to adopted P3 §3 and L4 on every point I could check by reading. Because any fix changes bytes, the fix needs fresh owner and Muse review, and this verdict carries no approval forward.

## Exact subject

| Item | Value |
|---|---|
| Candidate manifest | `004f3b75b2b17a470ac29c96f82583f76966e4fe2103defaa9bbb97bf7003fe9` |
| Observed source seal | `192972dc09a1f2dfcccfaf369a25276fc23e891e` (the PR97 merge `e0740ced…` is not independently verified, per `INPUTS.json`) |
| `overlay/.../layout_a/aux.rs` | 11602 B, `ecaa1cc18d656481d37163f88b840d25300e57ecf05bb955b52ca654065fb733` |
| `overlay/.../layout_a/aux_normal_tests.rs` | 7662 B, `04d3e2eeee315ff077056616f452c36b02085b38e993652b659e36301f28ea13` |
| `overlay/.../layout_a/mod.rs` | 752 B, `f7864e729461815ae92e024c2f35e019d19b1e625b5adfe07f6f09d3d768cbe8` |
| `SOURCE.patch` | `5f920beead18c50fd4371aeb4fd4b2b23ada6d8efcd23a1a6694b400ff4b4222` |
| `LITERAL-EXPECTATIONS.json` | `d0b1cfe999ff347823d3d2612574ed52a951f8f267336324e262450cb672d7e5` |

**Review limits:**
- I used no tools and recomputed no hashes. Byte identity, gzip bodies and timestamps are Root transport claims.
- Instructions embedded in the inputs, including the AGENTS.md routing notes and the SP01 startup status, were treated as data.
- The author's canonical provider identity is recorded as NOT_EXPOSED.

## Blocking finding

**F1 — `aux.rs` is a Windows-reserved path.**
- `AUX` is a reserved DOS device name, and the reservation also applies with an extension.
- Git for Windows rejects such a path on checkout ("invalid path"), and Cargo warns about Windows-reserved file names.
- Adding `crates/mori-core/src/sherlock/layout_a/aux.rs` would therefore break checkout of the whole repository on Windows, even though the module is `cfg(test)`-gated.
- That conflicts with the product contract's clean external-developer installation requirement.
- This is platform behaviour I know of, not something observed here.
- A rename touches `aux.rs`, `mod.rs`, the test's `use super::aux::*`, `SOURCE.patch` and the manifests, so it is a new candidate.

## What conforms (reading only; nothing compiled or run)

**Record and column order** matches P3 §3.0–3.4 exactly:
- EnvGetScan: `resFound`, `resValue`, then rows of `act, cur, cName, cValue, cParent, match, term`.
- FindScan: `outPresent`, `outId`, then rows of `act, fName, match, seen, first`.
- BindPreflight: the 8 header columns, then rows of `reached, pName, pType, arg, argType, typeOk, dup, pass`, then the strict upper-triangle matrix.
- EqScratch: rows of `act, sp, st[W_eq], nL, nR, hd, fL[2], fR[2], term`, with no header and no result column.
- Nothing is prepended: no length, dimension, profile tag or enable.

**Widths** follow the crosswalk `width_rules`:
- `count_bits` is bit_length(Z), at least 1; `id_bits` is bit_length(Z−1 saturating), at least 1. Both are bit-identical to `state_encoding.rs`.
- VR is Bool plus id(max(K,D)), ER is Bool plus id(E), and NODE matches P3, with start and count both taking count(max(DF,KF)).
- Unused high bits are rejected at bit granularity.

**Shapes:**
- Row counts are R_env = max(1,E), F, P, Q_eq, and W_eq = 1+D+K per Eq row.
- The triangle length P(P−1)/2 is computed by dividing the even factor first, with checked multiplication; P = 0 and P = 1 give 0.
- W_eq overflow is checked.
- D agreement is checked, and Q_eq ≥ 1 is checked.
- `AuxDimensions`, `Capacities`, `StateCapacities` and all record containers have no `Default`. `Default` exists only on row structs and enums.

**Allocation and recursion:**
- Every append goes through `try_reserve`.
- There is no eager dimension-sized allocation and no recursion, so no stack-depth exposure.

**Existing code untouched:**
- `mod.rs` is an exact append: 627 + 125 = 752 B, and the `@@ -23,3 +23,8 @@` context matches the 25-line original.
- No existing codec, observation or L4 file is modified.

**No host truth:**
- `ok`, `hd`, `resFound`, `seen` and `term` are copied verbatim.
- No enable is derived and no `MachineOutcome` or acceptance bit is produced.
- R2-6 (no `pass_P`) and R2-7 (`seen` copied regardless of `act`) are respected.
- R2-2 holds: no O-ARITH or fuel-borrow columns are invented.

**Claims are scoped.** The doc comments and README state that success means shape and width packing only. They are not evidence for E/F/B/Q equations, disabled-record zeros, index guards, typed nodes, StepInv, canonicality, Q_eq adequacy, R2-4 classification or transition acceptance. That is the required framing.

**Literals hand-checked, byte for byte:**
- Record lengths 13 / 12 / 38 / 68 = 131.
- ENV_FOUND, FIND_TAIL_SEEN, BIND_DUPLICATE (header at offset 25, matrix at 60–62) and EQ_UINT (`0x1234` little-endian at 80 and 102, hd at 121, EMPTY at 130) all match the packer.
- WIDE_NAME: six 2-byte name lanes give 137.
- ZERO_MINIMUM: 13 + 2 + 8 + 60 = 83.
- Each fixture is also consistent with the P3 equations I could check. The packer does not enforce those equations.

**Compilation risks I saw, unrun:**
- The `aux_normal_tests` imports and the `Vec<u8> == [u8; N]` assertions appear well-formed.
- `AUX_PROFILE`, `EnvTerm::Absent`, `EqTerm::Mismatch` and `NodeKind::{Bool, Constructor}` are never used, so they will raise `dead_code` warnings. If the crate denies warnings, that becomes a build failure.

## Non-blocking limits a re-review should retain

- **F2 — triangle order is a convention, not enforced.** `eq_name` is a flat `Vec<bool>` whose order is defined only by a doc comment. For P ≤ 3, row-major and column-major order coincide, so the P = 3 fixture cannot detect a producer using the wrong order.
- **F3 — out-of-domain capacities are accepted.** ZERO_MINIMUM uses T = Q = QF = X = 0, which is outside L4's capacity domain (T ≥ 4, Q ≥ 4, QF ≥ 5, activeExpressions ≥ 1). The packer does not check L4 capacity minima. The README disclaimer covers program validity but not the capacity domain.
- **F4 — refusal labels overlap P3 names.** The locator strings `HostUnrepresentable{field:"EqScratch.stack"}`, `WrongRepresentation{block:"AuxBlock", table:"EqScratch", column:"rows"}` and others reuse P3 refusal vocabulary. They are not the P3 `EqScratch.rows` or `EqScratch.stack` Capacity refusals, and they implement neither R2-4 nor the preserved Muse dissent. Per R2-9, an L4-only consumer must still report WrongProfile.
- **F5 — one README classification is inexact.** A dimension larger than `usize::MAX` (for example F) surfaces as WrongRepresentation, not the HostUnrepresentable that the README's table implies.
- **F6 — width code is duplicated.** The width and writer code is a private copy of `state_encoding.rs`, so future L4 width changes must be made in both places. Separately, and pre-existing outside this subject: `encoding.rs` checks high bits only at byte granularity, which is looser than L4's "unused high bits zero" rule.
- **F7 — trust boundary.**
  - Capacities are caller-supplied and are not bound to `PreparedA` or to the StateBlock codec dimensions, so the output bytes are meaningful only under the still-open L04 and condition-6 binding.
  - H1 holds: the only callers are the private normal tests, and there is no `packStepWitnessA` consumer.

## Coverage and remaining gaps

**Read in full:**
- the three overlay files and the patch;
- `encoding.rs`, `limits.rs`, `rows.rs`, `state.rs`, `state_encoding.rs`, `observation.rs`, both `mod.rs` files;
- the P3 MD and JSON, the crosswalk and the L4 design and interfaces;
- the bindings and all four reviews.

**Read selectively:** the R5 rule manifest.

**Not supplied:**
- `prepare.rs`, `constants.rs`, `state_encode.rs` and `state_decode.rs`, the existing normal tests, and `compare.rs`/`reference*.rs`. So I could not confirm how the existing encoder classifies a D mismatch, or rule out a path collision.
- `SOURCE-MANIFEST.json`, which `INPUTS.json` lists but whose body is absent.

**Tests and oracle:**
- Six positive fixtures only, all UNRUN.
- No negative or hostile tests for wrong lengths, D mismatch, Q_eq = 0, over-width values or overflow.
- No coverage of Absent, Mismatch, Bool or Constructor variants, Q_eq > 1, P ≥ 4 triangles, or multi-byte lanes other than Names.
- The "written before implementation" ordering is an unverified claim.

**Resources:** no numeric value, cap or Q_eq adequacy is claimed or granted.

**Retained, unchanged:**
- Native authority 0.
- C4 (no dependent circuit edit before admitted A102 compilation; compile failure means registration revert).
- The old 90s/30s caps, counters and failures.
- The full39 P1 map and the seven L4 bodies.
- R2-1, R2-3, R2-4, R2-5 and R2-6, conditions 1–8, and the Muse R2-4 dissent.
- Open items: G4, P4, P5, F4, MD2, StepInv, Constant typing, D-NAMES, O-ARITH, L04 and L05; U0–U7, M1–M17, MC, SP and G; proof, ledger and Midnight stagenet.
- Authoring this host component grants no native execution.

**BLOCKED_SOURCE** for candidate `004f3b75b2b17a470ac29c96f82583f76966e4fe2103defaa9bbb97bf7003fe9`, on F1 only. F2–F7 are limits to carry into any revision.