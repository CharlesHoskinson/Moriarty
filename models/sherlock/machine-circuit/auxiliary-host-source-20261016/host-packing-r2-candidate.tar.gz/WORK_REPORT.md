# P3 aux host packing r2 — source-only correction

This new packet applies the Root-directed F1 repair from the full Opus review
of r1 manifest `004f3b75b2b17a470ac29c96f82583f76966e4fe2103defaa9bbb97bf7003fe9`.
It retains the original source seal `192972dc09a1f2dfcccfaf369a25276fc23e891e`;
there is no rebase onto the separately merged PR98 models.

The exact code delta is limited to:

- Rename overlay `layout_a/aux.rs` to `auxiliary.rs`, with identical body bytes.
- Change the private declaration to `mod auxiliary;`.
- Change the normal-test import to `use super::auxiliary::*;`.

`SOURCE.patch` is the complete minimal overlay patch against the original seal.
`DELTA-FROM-R1.patch` records the exact rename and two spelling changes.
No fixture, failure class, allocation strategy, numeric input or packing
operation changed. No existing checkout was edited.

The owner's Windows AUX-name finding is the reason for the repair; this task
made no platform observation. Source comparisons establish the exact rename,
not successful Windows checkout or Rust compilation.

README and this report retain the full owner limits:

- F2: a flat eq_name vector relies on the documented producer convention;
  P=3 cannot distinguish row-major from column-major upper-triangle order.
- F3: ZERO_MINIMUM is a width/shape-only example OUTSIDE valid L4 program
  capacities (T=Q=QF=X=0). It establishes neither valid capacity domain nor
  program validity. No L4 minima check was added.
- F4: component error strings overlap P3 names but implement no P3 Capacity
  refusal, R2-4 classifier, needed metadata or native refusal ABI. The owner's
  L4-only consumer WrongProfile obligation remains; no such consumer is added.
- F5: dimensions above usize::MAX are not always HostUnrepresentable: for
  example an F length mismatch is WrongRepresentation. Existing checked-u128
  arithmetic/width/allocation behavior remains unchanged.
- F6: width code remains duplicated from state_encoding.rs and requires future
  synchronization. The owner's pre-existing encoding.rs byte-granularity
  observation remains outside this repair.
- F7: capacities remain caller-trusted and unbound to PreparedA, StateBlock
  codec dimensions or the statement. The complete packStepWitnessA consumer
  remains absent, with arithmetic/fuel-borrow placement still profile work.

All six normal tests remain uncompiled and UNRUN. No new test was authored.
Their literal vectors are unchanged. The test-first files and receipt remain
exact r1 history; the current test differs only in its import spelling.
`SOURCECHECKS.json` records byte/text/hash comparisons only and verifies that
all 60 files of r1 remain unchanged. No Rust parser, import, compiler,
formatter, test, SDK, model or native command was invoked in this revision.
The startup status capture under history/r1 is historical, not a new result.

Both old votes are preserved verbatim under prior-candidate-reviews: Opus
BLOCKED_SOURCE on F1 and Muse APPROVED_NORMAL_SOURCE_WITH_LIMITS for r1. Neither
approves r2. Fresh complete Opus and Muse source reviews are required.
All original P3 conditions, errata, Muse R2-4 dissent, L4/full39 bytes,
canonicality/StepInv/profile/target gates, C4, compile-failure registration
revert, and old 90s/30s caps/counters/failures remain unchanged. Native authority
is 0. This packet makes no security or execution-readiness judgment.

Requested author routing is GPT-6 Astra high; actual author is the assigned
/root/astra_sdk_compile_diagnosis agent. No separate provider canonical-identity
receipt is exposed for this turn.
