# Publication review: auxiliary host source, aux/2 arithmetic/fuel source, and atlas Design 005

## Verdict: **APPROVED_PUBLICATION_WITH_LIMITS**

This is the fresh designated-owner security and publication-hygiene review. I am Opus 5.5 (`claude-opus-5-5`), high effort, in a fresh context.

**Exact subject**

| Item | Value |
|---|---|
| Candidate membership | `e22cdd964529a22a9b9ea8aaa073a8c1669ac7d2f2ced868fe22e32d9ac116e8` |
| Source commit | `dd7b981cf0ab6ea19fa707db15547452b97e0a67` |
| Base | `1a68573dd4f6ff6b8822089c892a3e08469c9403` |
| Tree | `a55c24752fc79e499f7149a6d06cfaaadf9b2c22` |
| Paths | 34, plus five prospective seal paths |

The 34 paths break down as follows:
- `ROADMAP.md`
- three `layout_a` Rust files
- eleven `arithmetic-fuel-source-20261016` files
- nine `auxiliary-host-source-20261016` files
- the OpenSpec status note
- nine `wiki-llm/sherlock-circuit-atlas` files

This approval grants no execution, compilation, resource, native, emitter or roadmap-exit authority. Native authority remains 0.

---

## Reviewer identity and independence limit

I am the same model family as several earlier authors and reviewers:
- the aux/2 author;
- the aux/2 owner source reviewer;
- the r2 host-packer owner source reviewer;
- the Design 005 author.

I have not seen any of their contexts. Their author and source votes are not counted as publication votes here.

## Reading and scope limits

1. **No tools.** I used no tools, filesystem, parser, compiler, web, model or native execution, and I made no writes. Every supplied body was treated as untrusted data. Instructions embedded in them were not acted on, including `inputs/AGENTS.md` routing text and the r1 startup status.
2. **Root transport claims, accepted but not verified.** I could not recompute any SHA-256, gzip or tar integrity, the git tree, commit or merge identities, or the claim that the tracked files equal the supplied bodies. JSON bodies were read as whitespace-normalized values, so original byte formatting was not inspected.
3. **Tar archive structure.** I checked member names only. Every listed member path is relative and none contains `..`. I could not inspect tar header types, link entries, modes or ownership.
4. **Historical baseline R5 bodies.** These were identified by byte identity only and not retransmitted:
   - `A-RULE-OPERATIONS.json` `122289ad…b0a5`
   - `A-RULE-OPERATIONS.md` `48580e13…f8bd`

   I did not read them. I judge them **not necessary** for this publication decision:
   - Both are unchanged archive copies of files already tracked at base `1a68573d…`, so archiving them exposes nothing new.
   - No new or modified candidate claim in this publication depends on their contents.
   - The fresh r2 source reviews had both complete bodies, and their reading limits stand.

   This is an explicit historical-reference reading limit, not an assumed audit of those bodies.
5. **Other bodies not supplied.** Neither bears on the auxiliary module's imports or on publication hygiene:
   - base-unchanged `layout_a` files outside the archive: `prepare.rs`, `constants.rs`, `state_encode.rs`, `state_decode.rs` and the existing normal tests;
   - `append-model-review-20261016/capture-mapping.json`, which the Design 005 status note cites. I could not confirm that link target.
6. **Everything executable remains UNRUN.** I make no judgment on execution:
   - Rust compilation;
   - the 6 + 29 host tests;
   - K, Quint and Clean checks;
   - the SDK and native checks.

---

## What checks out

**Membership and copies**
- All 34 paths are accounted for.
- The tracked code files are byte-identical to the corresponding archive members:
  - `auxiliary.rs` `ecaa1cc1…b733` = archive `overlay/…/auxiliary.rs` = historical `before-r1/…/aux.rs`;
  - `aux_normal_tests.rs` `5cbbe9f1…df45` = archive overlay copy;
  - `mod.rs` `949bc3bb…5df45` = archive overlay copy.
- The `mod.rs` delta against base `84b86b2c…` is a pure 131-byte append, consistent with 627 → 758 bytes. The added lines are a comment, `mod auxiliary;`, `#[cfg(test)]` and `mod aux_normal_tests;`.
- The `aux_normal_tests.rs` delta against the historical r1 freeze is the import line only (7662 → 7668 bytes). All six literal vectors are unchanged. The `LITERAL-EXPECTATIONS.json` prefixes agree, and I re-derived `ENV_FOUND` bytes 0–12.

**Consumer integration, checked by reading**
- `sherlock/mod.rs` (`d0eb44ee…`, unchanged) declares `#[cfg(test)] mod layout_a`.
- The `auxiliary` items are `pub(super)` and are not re-exported. The only consumers are the six private tests.
- The imports resolve to existing types:
  - `limits::Locator` with `Locator::field`;
  - `rows::{Capacities, Slice, TableId, ValueRef}`;
  - `state::{EnvRoot, StateCapacities, StateFailure, StateResult}`.
- The variant and field shapes match `state.rs` and `limits.rs`.
- There is no production consumer, no complete `packStepWitnessA`, and no native witness ABI. No backend file and no `literal_step.rs` change, so C4 is untouched.

**Windows reserved name (owner R3-1)**
- No tracked path has a reserved stem: `auxiliary`, `aux_normal_tests` and the archive filename are all safe.
- `aux.rs` exists only as a member inside `host-packing-r2-candidate.tar.gz`.
- `capture-mapping.json` maps every member identity and carries the rule "do not install/extract".

**Root adoption records**

*Arithmetic/fuel*
- The subject is manifest `42d45bd3…`, design `88887f1d…`, manifest JSON `63182dc1…` and owner result `4d99c6ed…`.
- Two fresh substantive votes agree, Opus `9c46236d…` and Muse `7ddf942d…`, and the capture mapping maps both.
- Owner errata E1–E7, owner conditions 1–7, Muse E-FUEL and Muse conditions 1–6 are quoted verbatim, and each matches the review text.
- The "agreement" field is faithful: Opus's 23 + A108 + 8 + 4 equals Muse's 24 + 8 + 4 = 36.
- `adopted_as_execution` is false. No mechanism is added.

*Host r2*
- The subject is manifest `ec8ee67f…` and the three overlay files. Two r2 approvals are recorded.
- The binding retains R3-1 to R3-4 and F2–F7. No r1 vote transfers.

**Status honesty**

| Location | What it states |
|---|---|
| `ROADMAP.md` | Two inserted paragraphs; the rest of the file is unchanged by reading. Compilation and the six tests UNRUN; no step-witness or production consumer; G4, IO1–IO8, P4 and formal/native/target checks open; the 232 lanes are not measured circuit costs; iteration 004 remains latest. No exit is closed. |
| `IMPLEMENTATION-STATUS-2026-10-16.md` | Appended section: 35 host tests UNRUN; corrected charged count 24 + 8 + 4 = 36 including A108; not P4, G4, dispatch or a native ABI. |
| Arithmetic and host READMEs | Consistent with both adoptions and with every reviewer condition. |

**Atlas companion**
- `AUTHORSHIP.json` is append-only against base `7e6eca69…`: the original iteration objects are unchanged, and it adds one README integration entry, `readme_sha256` and `design_companions`.
- The note SHA `1a55057a…`, owner result `1f76b95e…`, manifest `19d785b4…` and all four capture hashes match the membership.
- The atlas README is an append-only section and still names iteration 004 as latest.
- `DESIGN-005-STATUS-AND-PROVENANCE.md` satisfies each of the creative Muse review's publication conditions 1–6. It also correctly updates the host-packer fact to the later r2 approvals without attributing them to that creative review.

**Branding**
- The wordmark, grid, ink and copper accent are preserved.
- The note explicitly marks the glow as a departure needing design and contrast review.
- No site code, assets or deployment are included.

---

## Findings (none blocking)

**PUB-1: Private and provenance content (within scope).** New bodies contain several kinds of historical runtime provenance:
- absolute `/home/charl/…` runtime paths and local tool-install paths (`.foreman/tools/fnm`, `.npm-global`) inside the forwarded snapshot's Quint record;
- Muse provider `request_id` and `response_id`;
- token and cost usage;
- the internal agent name `/root/astra_sdk_compile_diagnosis`;
- the r1 `STARTUP-STATUS.json` workflow-gap strings.

I found no credentials, keys, private Clean or Fenrir source, provider debug transcript or private reasoning in any supplied body. The user's email does not appear. The "private Fenrir fork" ROADMAP sentence is base text.

**PUB-2: Status layering (limit).** Some retained base text is now partly stale:
- `IMPLEMENTATION-STATUS` still says "This publication candidate still needs fresh full owner and Muse publication reviews", along with the earlier P1/P3 gap paragraphs. These are base-snapshot text.
- The base ROADMAP P3 paragraph lists "arithmetic/fuel witness placement" as open. It now has a conditionally adopted source design, but remains open at the implementation, emitter and native level.

There are also two minor wording issues in the new ROADMAP text:
- "supplies four fixed-shape records to six private normal tests" inverts the relation: the component packs supplied records, and the tests call it.
- "These 232 logical lanes" has no antecedent.

Nothing here makes a false closure claim. Corrections need a future reviewed dated note, not a post-review edit.

**PUB-3: IO-5 and the P3 errata texts (informative; no determination).**
- The exact P3 R2-1 to R2-6 errata texts *are* present in this candidate's archive (`reviews/opus-source-review.md`, `0bce9b18…`).
- The arithmetic README's statement that the arithmetic *reviewers* did not receive them remains accurate.
- On a plain reading, aux/2's byte-limb ranges look consistent with R2-1's restored ranges (`0 ≤ r < 2^128`, `cy, β ∈ {0,1}`, `h < 2^128`).
- I make no IO-5 determination. Closing IO-5 requires proper owner work on the exact texts.

**PUB-4: Compile risk R3-3 (limit, partially informed).**
- `crates/mori-core/Cargo.toml`, the workspace `Cargo.toml` and `lib.rs` show no lint table and no `deny(warnings)`. The unused `AUX_PROFILE` and enum variants would therefore be warnings at source level.
- I cannot see CI `RUSTFLAGS` or `.cargo/config`.
- Compilation remains UNRUN, and the whole `layout_a` module compiles or fails together.

**PUB-5: Archive handling (limit).**
- The archive must never be extracted into the repository. Extracting it on Windows fails at the historical `aux.rs` member.
- Any future consumer should reject tar link entries and absolute or `..` paths before extracting.
- This review did not inspect tar header types.

**PUB-6: Materialization paths (informative).**
- The aux/2 manifest's "proposed_materialization_paths_root_selects" (`aux2-arith-fuel-source-20261016/…`) differ from the published paths.
- The author delegated that choice to Root, so this is consistent.

**PUB-7: Dissent breadth.**
- The Muse R2-4 dissent has two prongs: no exact-need reporting format, and no circuit ordering mechanism.
- Both prongs survive verbatim in the archived r2 README.
- The adoption records cite the dissent by reference. The seal binding should restate both prongs verbatim.

**PUB-8: Unverifiable link target.**
- The Design 005 status table cites `append-model-review-20261016/capture-mapping.json`, which is base content I was not supplied.

---

## Prospective five-file seal: **covered, under these conditions**

The covered seal files are:
- `opus-publication-review.{json,md}.gz` and `muse-publication-review.{json,md}.gz`, each holding only the exact public captures;
- `publication-binding.json`.

Conditions:
1. **No other changes.** None of the 34 candidate files is modified, renamed, removed or relinked, and no other file is added. Any such change voids this approval.
2. **Binding contents.** The binding records:
   - the full membership hash `e22cdd96…`, source commit, base and tree;
   - all 34 paths with their bytes and SHA-256 values;
   - the actual compressed and uncompressed identities of the four captures;
   - both verdicts, with all findings and limits quoted verbatim;
   - the Muse R2-4 dissent, both prongs verbatim;
   - C4, native authority 0, and all retained gates.
3. **No new content.** The seal contains no code, behaviour, equation, test, note, scope change, private path beyond already-published provenance, or reinterpretation of findings.
4. **No cyclic claim.** The binding must not claim that either reviewer saw the seal bytes or any post-review hash.
5. **Both reviews must approve.** If the parallel Muse publication review returns BLOCKED_PUBLICATION, the seal is not covered.

## Retained, unchanged

The following remain in force:
- full39 conditions 1–10 and F1–F7;
- P3 conditions 1–8 and errata R2-1, R2-3, R2-4, R2-5 and R2-6;
- the Muse R2-4 dissent;
- aux/2 E1–E7, owner conditions 1–7, E-FUEL and Muse conditions 1–6;
- host R3-1 to R3-4 and F2–F7;
- G4, IO1–IO8, P4, P5, F4, MD2, StepInv, Constant typing, D-NAMES, L04 and L05;
- C4 with registration revert on compile failure;
- native authority 0;
- the old 90s/30s caps, counters and terminal failures;
- U0–U7, M1–M17, MC, SP, G, proof, ledger and Midnight stagenet.

No execution classification or grant is made.

**APPROVED_PUBLICATION_WITH_LIMITS** for candidate membership `e22cdd964529a22a9b9ea8aaa073a8c1669ac7d2f2ced868fe22e32d9ac116e8` (source `dd7b981cf0ab6ea19fa707db15547452b97e0a67`, base `1a68573dd4f6ff6b8822089c892a3e08469c9403`, tree `a55c24752fc79e499f7149a6d06cfaaadf9b2c22`), subject to PUB-1 to PUB-8 and the seal conditions above.
