## Fresh Muse normal semantic/interface/mathematical vote

**ADOPT_COMPLETE_ARITHMETIC_FUEL_SOURCE_WITH_CONDITIONS**

Candidate manifest: `42d45bd3bea826469408a774984318d1ae473b82636ae5f32c0bf4ca8b23c6a2`

This is one fresh, non-author Muse normal vote on the stated arithmetic/fuel source scope only. Author `claude-opus-5-5/high` is not a vote, and no historical vote transfers. Adoption, execution, emitter acceptance and native use still require the second fresh substantive vote, the required designated-owner vote where applicable, and a Root adoption record. Native authority remains 0.

### Reading, identity and coverage limits

- I used only the supplied, untrusted bodies; no tools, parsers, files, web, commands, hash recalculation, SDK/native execution or models were used.
- The design MD `88887f1d…b13c3`, manifest JSON `63182dc1…5df4f` and OWNER-RESULT `4d99c6ed…767f` were read as the complete candidate. Their byte counts and hashes are as supplied, not recomputed.
- I checked the candidate against the supplied P3/aux-1, full39 semantic map, Rust/K A153 and fuel precedence statements, and literal-step interface account. The Rust/K statements checked here are byte/derived-behavior readings, not executed correspondence evidence.
- `super::*` ISA definitions, the pinned native field/characteristic, G4 implementations, L04 binding and the exact R2-1 erratum text were not supplied or established. K/Quint/Clean formal correspondence and all new native execution remain UNRUN.
- C4 remains controlling: no dependent circuit source edit until admitted A102 compilation; compile failure requires registration revert. The old 90s/30s counters/caps/failures and the full roadmap remain unchanged.

## Independent mathematical checks

### Add/Sub/Lt

For bytes `a_i,b_i`, ADD telescopes over integers once each local equation is lifted from the field:

`a+b = r + 2^128·c_16`, with `r∈[0,2^128)`. Hence Ok iff `c_16=0`; `c_16=1` is exactly Err10.

SUB similarly gives `a-b = r - 2^128·bo_16`. Sub Ok iff `bo_16=0`, while Lt is `Bool(bo_16)`, with `SUB.r` still fully constrained even though it is never stored.

Representative hand checks pass:

- `255+1`: byte 0 gives `255+1=0+256·1`; byte 1 gives `0+0+1=1`, so result 256.
- `max+1`: every carry is 1, constrained remainder 0, `c_16=1`, therefore Err10 and the bERR10 commit has `activeData'=D0`, i.e. overflow with no state append.
- High-byte Lt, `2^120` versus `255`: borrows propagate through bytes 0–14, byte 15 gives `1-0-1=0`, so `bo_16=0` and Lt is false. Reversed operands produce only final `bo_16=1` and the remainder `[FF,00×14,FF]`, so Lt is true.

Selectors are an IFF partition on unchanged bytes:

- `bERR11=en_ar-uu`
- `bERR10=ovf`
- `bLT=enLT`
- `bOK=uu-enLT-ovf`
- Their sum is `en_ar`, and exactly one is 1 when `en_ar=1`.

Thus non-UInt Add/Sub/Mul/Lt gives Err11 with all limb blocks zeroed; two UInts with arithmetic overflow give Err10. Eq remains in aux/1 EqScratch and Cons/Branch remain outside ArithScratch, so T-3/T-4 separation is sound.

### Mul: convolution, high/low split and max case

For `S_k=Σ_{i+j=k} a_i b_j`, `m_k≤16`, and each product at most 65025, `S_k≤1,040,400`. The recurrence induction gives honest carries at most 4079: starting from `c_0=0`, if `c_k≤4079`, then `c_{k+1}≤⌊(1,040,400+4079)/256⌋=4079`. Thus the admitted unsigned-12 range `[0,4095]` is complete.

For `max×max`:

- `k=0`: `65025=1+256·254`, so `p_0=01`, `c_1=254`.
- For `1≤k≤15`, `p_k=00`; at `k=15`, `T=1,044,224=256·4079`, so `c_16=4079`.
- `k=16`: `T=975,375+4,079=979,454=254+256·3825`, so first high byte is `FE`.
- Bytes 17–31 are `FF`; hence `r=[01,00×15]`, `h=[FE,FF×15]`, and `hSum=254+15·255=4079`.
- This matches `(2^128-1)^2=1+2^128(2^128-2)`.

Therefore checked Mul is Ok iff all high bytes are zero; `hSum` is a nonnegative integer sum at most 4080, and `hZero=enMUL·[hSum=0]` cannot alias a nonzero high word under the field bound. `c_32:=0` prevents hiding the high part in a final carry.

### Fuel: charged decrement and source precedence

FD-1/FD-2 correctly implement `bw_0=en_chg`, `bw_{i+1}=bw_i·z_i`, and `post_i+bw_i=pre_i+256·bw_{i+1}`.

Hand checks:

- `f=[01,00×15]`: `bw_1..16=0`, so `1→0`.
- `65536→65535`: bytes are `[00,00,01,00×13]` to `[FF,FF,00×14]`, with `bw_1=bw_2=1` and the chain stopping at byte 2.
- After `f=1→0`, a Return at depth 0 selects free A080/Done, while nonterminal Eval selects free A084/Exhausted; both preserve fuel.
- A082/Error is free both at `f=5` and at `f=0`; publication precedes exhaustion and FD-2 preserves fuel.
- Semantic-failure A153 Err10/Err11 remains charged when reached with `f>0`; no decrement occurs on A080/A082/A084, and FD-3 plus `en_chg⇒f≠0` prevent wrap.

### Field bound: local versus global

The `p>2^20` condition is **local per limb relation**. For MUL, with admitted carries up to 4095,

`E=S_k+c_k-p_k-256c_{k+1}∈[-1,048,575,1,044,495]⊂(-2^20,2^20)`.

If `p>2^20`, field equality `E=0` implies integer equality for that limb. Only after all limb equalities have been lifted to integers does the ordinary integer telescoping prove the global identity `a·b=r+2^128h`. The proof does **not** pack a 128-bit or 256-bit value into one field element and does not require `p>2^128` or `p>2^257`.

The same local argument applies to ADD/SUB/FD-2 with bounds within `[-511,511]`-type ranges and to MUL-HS within `[-4080,4095]`.

### Column inventory and oracle discipline

Every added supplied column is inventoried and bound:

- ArithScratch: `opL/opR`, fetched `nL/nR`, `selAdd/selSub/selMul/selLt`, `uu`, `ovf`, `ltOut`, ADD `r/c`, SUB `r/bo`, MUL `r/h/c/hSum/hZero`.
- FuelProbe: `z[0..16)`, `zp[1..17)`.
- FuelDec: `bw[1..17)`.
- The aux/1 prefix—EnvGetScan, FindScan, BindPreflight and EqScratch—is expressly unchanged and remains first in packing order.

Selectors, branch flags and `ovf/ltOut` are derived from pre-state/fetched-node facts, not supplied truth bits. Disabled ADD/SUB/MUL blocks and, when `en_ar=0`, operand/header records are zeroed. Products `a_i b_j`, sums `S_k`, derived enables and TestEq inverses are not extra supplied columns; making them deterministic internal instruction outputs is explicitly a G4-ISA requirement, not evidence that the native ISA already has that semantics. `LessThan{bits:128}` is not used.

NODE `uintBytes` are logical node lanes, and unsigned-12 serialization/reconstitution remains G4-BYTE. No native byte-carrier, field, fetch, append or ISA behavior is claimed from names alone.

## One concrete non-mechanism erratum

The fuel inventory enumeration is arithmetically incomplete on the candidate bytes: A108 is a charged rule but is omitted from §9/manifest `charged_no_failure`, and the printed subtotals say `23+8+5` while the listed with-failure-branch group has four rules.

**Binding reading E-FUEL:** the normative selector is the `en_chg` formula, not the illustrative rule list. Read the charged partition as A108 included and corrected counts:

- charged without a special failure-branch group: 24, including A108;
- charged failure rules: 8;
- charged rules with failure branches: 4 — A153, A157, A204, A214;
- total charged: 36; free: A080, A082, A084.

This requires no new mechanism because A108 already follows from `en_chg`.

## Conditions of this vote

1. Root must bind this vote to the exact candidate manifest `42d45bd3bea826469408a774984318d1ae473b82636ae5f32c0bf4ca8b23c6a2`; any byte change voids this vote for changed bytes.
2. E-FUEL above governs §9 and the manifest fuel-rule enumeration on unchanged bytes.
3. Before any native/emitter use, the pinned field must be shown to satisfy G4-FIELD `p>2^20`; if it does not, this byte-limb profile is inapplicable and any nibble alternative requires fresh reviewed bytes.
4. G4-ISA-1..4, G4-FETCH, G4-BYTE and G4-APPEND remain unproved requirements, not native evidence or operator certification.
5. IO-1–IO-8 remain open in their stated scopes: P5 dispatch/pre-post binding, P4 spine/POP/W1 wiring, A102/FuelDec equivalence after the C4 gate, Cons/Branch and A157 sort-read witnesses, exact R2-1 reconciliation, L04 profile/layout/statement binding, emitter acceptance and all UNRUN K/Quint/Clean checks.
6. The adopted P3 conditions 1–8, errata R2-1/3/4/5/6, the preserved Muse R2-4 dissent, full39 conditions/F-readings, costs and capacities remain open and binding. This vote decides only the complete source proposal for A153 Add/Sub/Mul/Lt witnesses and the 39-rule fuel probe/decrement/preservation relations; it does not adopt complete P4, the spine, global dispatch, a native witness ABI or G4 operators.

With those conditions and E-FUEL, I find no blocking mathematical, selector, disabled-witness, overflow-separation or fuel-precedence defect in the stated source scope.

**ADOPT_COMPLETE_ARITHMETIC_FUEL_SOURCE_WITH_CONDITIONS**
