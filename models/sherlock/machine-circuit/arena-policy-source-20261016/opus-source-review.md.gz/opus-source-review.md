# Designated-Owner Security and Physical-Design Audit: P3 r2 Complete Source Candidate

**Verdict: ADOPT_COMPLETE_P3_SOURCE_WITH_CONDITIONS**

**Bound subject:**
- Candidate manifest `e7c34e524a6f6aa002307124a9f2f0ad6f856c9522135cd74b8f65a1e9f7984f`
- `P3-ARENA-DESIGN.md` `b2d6fda4b07804406f8f6d1c4ed9aa4d86031ccffb4bbb6e0be2c7cdab8891eb` (65,930 B)
- `A-ARENA-OPERATIONS.json` `3f33a0dc7fe831022b109ae0d60f2eb8cc9167e94bbc3d27c95a61ebdddbb214` (27,137 B)
- `OWNER-RESULT.json` `9664340856defce977d7d557b6d6bc6ebe5b53b39bfa057db8f45c3a8a54c99c`

All hashes are as supplied. I recomputed none.

**Role.** I am Claude Opus 5.5 (`claude-opus-5-5`), acting as the fresh designated owner for security and physical design.
- **Independence limit.** The author is the same model family in a different context. The author's text is not a vote.
- **No vote transfer.** The r1 challenge (`19d2…6a3e`) and the Muse r1 vote (`d566…d911`) do not transfer to these bytes.
- **Still required.** A fresh Muse normal vote and a Root adoption record. This vote substitutes for neither.

---

## 1. Coverage and reading limits

**Bodies read in full, as supplied text:**
- the complete 65,930 B MD, including §0–§10 and the fenced manifest;
- the parsed JSON object, which I treated as identical to the fenced block per Root's byte-identity statement;
- r1 `e418…`, the r1 challenge and the Muse r1 review;
- the full39 P1 r3 rows, the Root full39 adoption and both full39 receipts;
- all seven L4 bodies;
- `reference.rs`, `reference_types.rs` and `main.k`.

**Read selectively.** In R5 JSON/MD I read the rules bearing on P3: A145, A153, A157, A177, A181, A204, A214, the scans, and the H-* helpers. I did not re-audit them byte-for-byte. My attention over roughly 1.5 MB is not uniform.

**What I did and did not do:**
- I used no tools, parsers, evaluators or execution.
- The K/Quint/Clean matrix in §7 is a list of unperformed obligations. I treat it only as that.
- Every example check below is my own arithmetic; I relied on no author summary.
- Embedded instructions in the supplied bodies were treated as evidence, not acted on.

---

## 2. X1/X2 source choices: the `sherlock-k-a-aux/1` profile

**Placement.** A separate extension profile is the right choice.
- It extends `StepOperandsA` with `suppliedAux`, which L4's `packStepWitnessA` signature already anticipates.
- It leaves all seven L4 files, `table_capacities` and ObservedRecordA untouched.
- Materialization and the trace comparator are unaffected, because AuxBlock is not an observation.

**Labels.** "Private step witness; dimensions are layout constants; no public column; no privacy claim" is an acceptable owner proposal. Statement binding of ProgramBlock, pre and post stays L04-open. So does binding of the profile identity and its dimensions into layout identity (condition 6).

**Packing.** EnvGetScan ‖ FindScan ‖ BindPreflight ‖ EqScratch, with header, rows and then the matrix, in fixed shape regardless of rule. A disabled record is all-zero.
- `packStepWitnessA` only orders and shape-checks. No truth bit, acceptance bit or diagnostic column survives; r1's first-failure index and reason are removed.
- I audited every column below. Each one is derived from (program, pre, dims) or forced to zero. **I found no free column, no first-failure inspection flag and no host truth result.**

**Enables.** `en_env`, `en_find`, `en_bind` and `en_eq` are derived from `cg` and the CR0 tag, which are pre-derived. They are pairwise exclusive because they require distinct CR0 tags.
- `cg` excludes A080/A082/A084, so the aux records are disabled on free publications and at zero fuel. That is correct.
- Reading `Expressions[X]` at padded `X=0` when `CR0.tag≠Eval` is harmless, because `activeExpressions≥1`.

**Dimensions.** `R_env=max(1,E)`, `R_find=F` and `R_bind=P` are derived. `W_eq=1+D+K` is derived. `Q_eq≥1` is a new symbolic dimension that L05 must select. No number is chosen. This is acceptable.

---

## 3. Record-by-record audit

### EnvGetScan (A108/A111)

**Activity and reads.**
- `act` is a forced prefix (E-1, E-6).
- `rd_t` gates the cell read, with guard `index<E0`. Non-`rd` rows are zero.
- E-3 enforces a strictly decreasing cursor.

**Termination.** E-5 classifies ABSENT on the *same row* as the last mismatch when the parent is absent, or at row 0 when the root is absent.
- Indices are `<E0` and strictly decreasing, so the terminal row is `≤E0−1≤max(1,E)−1`.
- When E0=0, L4 option validity forces the root to `{0,0}`, so row 0 is ABSENT.
- E-7 forbids a non-terminal last row.
- Exactly one terminal row exists, so the sums in E-8 are exact.

**Semantics.** FOUND is the newest cell on the chain with that NameId. That equals L4's newest-first decode, which equals `environment.get` (`reference.rs` 142–145; K108–113), under D-NAMES. P3-1 is fixed.

### FindScan (A200)

**Constraints.** F-1 to F-5 give a two-sided fold:
- `outPresent=1` exactly when some active row matches, and then `outId` is the least matching index;
- `outPresent=0` exactly when no active row matches, and then `outId=0` (the empty sum).

**Edge cases.** `Some(row0)` gives (1,0) and is distinct from None. F=0 gives no rows and `outPresent=0`.

**Padding.** Rows at or beyond `activeFunctions` are deterministic but not all-zero, because `seen` carries forward. They are constrained, so this is acceptable (informative note R2-7).

P3-2 is fixed.

### BindPreflight (A204)

**Correspondence with `bind()`:**
- Length is checked first (B-2).
- `reached` gating runs in reverse order (B-3).
- The type test comes before the duplicate test, because `eqName[i][j]` requires `typeOk_i` (B-5, B-6).

**Why `reached_i ⇒ reached_j` for i<j<k.** `reached_i` requires `pass_{i+1}`, which requires `typeOk_{i+1}`, which requires `reached_{i+1}`. By induction, every `pName_j` that `eqName` consults has been read. Unreached rows are zero, so no inactive pair is read.

**Duplicate range.** When pair i is reached, `dup_i` over j>i equals `contains_key` over the successfully bound later names.

**Outcomes.**
- `ok = lenOk ∧ (k=0 ∨ pass_0)`, so `Some(empty)` gives `bindingsPresent=1`, `{0,0}`.
- Failure gives zero EnvCells and `bindingsPresent=0`, and Bound still carries the return type and body. Zero StateBlock scratch is retained.

**Commit.** For `j=0..k−1`, the cell carries `p=k−1−j`, with the chain parent `{1,E0+j−1}` and root `{1,E0+k−1}`. The newest cell is parameter 0, and the names are distinct, so map meaning does not depend on order. Commit reads only from rows that `ok` proves were reached.

P3-10 is fixed. One formal gap remains: `pass_P` (R2-6).

### EqScratch (A153 Eq)

**Forced trace.**
- Q-1: `act_0=en_eq`, `sp_0=1`, and the initial pair is (left `FS0.valueRef`, right `CR0.valueRef`).
- Q-7: the transition is forced on every active non-terminal row; otherwise the next row is all-zero. Q-8 forbids a non-terminal last row.
- So `act` is a gapless prefix with exactly one terminal row, the last active one, and `sp≥1` on every active row.

**Each active row.**
- Q-2: the top pair is fixed and slots `≥sp` are zero.
- Q-3: HEADEQ compares kind, typeId, ctorId, uintBytes and boolValue, but not fieldStart, fieldLength, space or index. It is derived and works across both spaces.
- Q-4: E2 enforces `nR.fieldLength = nL.fieldLength ≤ 2`, and `c_t` is derived from it.
- Q-5: each field read is guarded by its own node.
- Q-6: `term` depends only on `hd` and `spNext`.
- Q-7: for c=2, field 0 ends on top, so the order is head/left first.

**Soundness and completeness.**
- MISMATCH occurs only at a same-path pair reached through head-equal ancestors, so the values are unequal.
- EMPTY requires every corresponding pair to have been popped head-equal, which gives `Value ==`.
  - Lists compare head-before-tail, which is equivalent to Vec length plus elements.
  - Trees compare shape and leaves.
- There is no reflexive shortcut and no memoization. No path leads from a budget to false, Err10, Err11, error4 or Exhausted.

**Stack bound.** I re-derived it.
- After expanding a node at depth d, the stack holds at most d pending siblings plus 2 children, so `sp≤1+depth(top)`.
- Depth in edges is at most `D0+K0−1`, assuming pre-state reference ordering (see R2-3).
- So `sp≤D+K<W_eq`, and Q-9 cannot be hit in the domain.

**Refusal order.** EqScratch.rows comes before `D0+1≤D`.

P3-3 is fixed.

---

## 4. Catalog, masks, references and errata

**Partition.** I verified the 39-row partition: 32 rules have empty appends and 7 allocate. Every Δ entry matches full39 and owner P3:
- A145 appends one EnvCell.
- A153 appends {0, 1 Data, 1 Data + 2 DataFields}.
- A157 appends {0, 1 Data, 1 Data + 1 DataField}.
- A177/A181 append 1 slot (EXT) or m+1 slots (COPY).
- A204 appends 0 or k cells.
- A214 appends 0, 1 or 2 cells.

No rule appends to more than one family.

**Masks.** The FS/CR masks implement the full39 relations; P4 wiring stays open. Fuel decrements on the 36 charged rules only.

**Rule-specific checks, each against full39:**
- **A080.** `CR0.valueRef` is aliased and not canonical (F3).
- **A140.** CR0 becomes Error 4, rows `≥1` are zeroed and n′=1.
- **A135.** Branches on `depth<stackLimit` (semantic) versus S (Capacity).
- **A145.** The parent is `savedEnv`, Scope keeps the saved root, and Root becomes `{1,E0}`.
- **A149.** Right carries no savedEnv.
- **A161/A165.** Read `expr0`/`expr1` respectively.
- **A169/A190.** No POP and no restore.
- **A173, A208, A220.** Root and saved aliases match full39.
- **A177/A181 EXT/COPY.** All write targets are at or above V0, so every co-holder is safe.
- **A214.** Parents chain from ρ, the CaseResult tuple is retained on both outcomes, and the MD7 tails are applied.

**Muse errata.** All are fixed:
- A120: the pending Unary `savedEnv` is zero and the Push environment is Rho.
- A185/A195: post-relation only; MD2 stays UNSELECTED.
- Nil alias: a deterministic selection, not a uniqueness claim.

**P3 repairs.** P3-4 to P3-11 are fixed as stated:
- P6.C/P6.S are in preflight.
- `ΔV≤V0+1`, the `a_max` invariant is unselected and not assumed, and the static admission claim is withdrawn.
- INV-TY-D and INV-TY-K are preconditions.
- D-NAMES is gating.
- u8[16] is written explicitly; EX1 includes A108; EX3 has its own tables.

**Arithmetic carrier.** The candidate keeps exact mathematical UInt128 relations and introduces no carrier. The ranges are incomplete (R2-1).

---

## 5. Bounds, capacity and refusal

**Generic per-step bounds.** `ΔD≤1`, `ΔDF≤2`, `ΔE≤max(2,k_max)` and `ΔV≤V0+1` are correct for arbitrary representation-domain images.
- `k_max` is a ProgramBlock fact, because `functionId<activeFunctions`.
- The V bound follows because COPY has `m≤V0` by slice validity.

**Envelope.** `V_end+1≤(V_start+1)·2^{T_c}` follows from `V′+1≤2(V0+1)`. It is a sound upper bound only. Admission is withdrawn.

**EqScratch need.** The bound `≤ufd(L)≤2^{D0+K0}−1` is acknowledged as not excludable by fuel, live DAG size or occupancy. Q_eq adequacy is correctly left unclaimed.

**Refusal behaviour.**
- Semantic failure branches need zero rows and are accepted at full occupancy.
- Capacity is never a semantic outcome.
- ControlRows/FrameSlots refusals on zero-arena rules are retained.

**Two refusal-reporting gaps.** Locator precedence against WrongRepresentation, and the `needed` field, are both unspecified (R2-4).

---

## 6. Hand checks of the nine examples

**EX1.**
- A114 gives a two-row spine.
- A135 installs Let.
- A102 gives `Return{C,0}`.
- A145 appends `Cell0={x,{C,0},{0,0}}` and env becomes `{1,0}`.
- A120 gives Push with Unary (savedEnv 0) and env `{1,0}`.
- A135 at depth 2.
- A108 finds `{C,0}` on row 0.
- A157 appends `Data0={2,3,2,…,fs=0,fl=1}` and `DF0={C,0}`, then POPs.

Correct. Implicit requirements: step 6 also needs `S≥2` and `stackLimit≥2`.

**EX2.** I re-traced all five rows; the stacks match the table. Row 4 is EMPTY.
- With Q_eq=5, row 4 is the last row and terminal, so the step is accepted.
- With Q_eq=4, row 3 is active and non-terminal, so Q-8 refuses.
- The precedence cases are correct.
- `Data[3]=Bool true`.

**EX3.** UInt against Nil mismatches at row 0. For `[1]` against `[1,2]`: (d1,d4) then (d0,d0) are pushed, 1=1, then Nil against Cons mismatches at row 2. Correct.

**EX4.** COPY writes v; COPY writes v+1 (g); COPY writes v+2 and v+3 because `v+1≠v+2`; EXT writes v+4 because `v+4=V0`. The final slice is `(v+2,3)`. The w-shift claim holds. Correct.

**EX5.** Correct:
- DUP at row 0 via `eqName[0][2]`.
- TYPE at row 1, with row 0 unreached.
- Success cells 10 = b and 11 = a; root `{1,11}`.
- Zero-k gives `ok`; length mismatch gives all rows zero.

**EX6.** Correct:
- Nil gives `{1,1}`, or present `{0,0}` with an empty ρ.
- Cons cells 2 and 3 decode as `t↦[6]`, `h↦5`, `z`, and ρ still decodes `h↦r9`.
- `Capacity{EnvCells,4,3,index 3}`.
- `Cons(h,h)` misses.

The scrutinee d4 is implicit.

**EX7.** ABSENT on row 2, the last row; E0=0 gives ABSENT on row 0. Correct.

**EX8.** (1,1), (1,0) and (0,0). Correct.

**EX9.** All five cases are correct. The Capacity tuples omit locators.

---

## 7. Findings

### R2-1 — ARITH ranges dropped from r1 (binding erratum; soundness-relevant)

r1 stated `c∈{0,1}` and `β∈{0,1}`. r2 states only:
- `a+b=r+2^128·cy`;
- `a−b=r−2^128·β`;
- `a·b=r+2^128·h` with `h<2^128`.

No repair disposition records the change. As written, the Lt result and the Ok/Err10 selector are free.
- **Example.** Take a=5, b=3. With unbounded r and integer β, `(β=1, r=2+2^128)` satisfies the Sub relation, so Lt would return true.
- **Even with β∈{0,1}.** For a≥b, both β values fit unless r is bounded.

**Binding reading.** This is the only reading consistent with `uiChecked`, `checked_*` and u8[16]:
- a, b, r and h are integers;
- `0≤r<2^128`;
- `cy,β∈{0,1}`;
- `0≤h<2^128`.

No carrier is selected.

### R2-2 — Arithmetic witnesses have no column (completeness scope)

r, cy, β and h on the Lt, Sub and Err10 branches are not in any `aux/1` record. The profile says every column is constrained or absent and fixes a four-record shape. So A153's non-Eq relation is not lowerable on these bytes, and nor is the charged u128 fuel borrow (P4).

O-ARITH is explicitly out of scope, so this is consistent. It means, however, that "complete P3" is complete as an arena, append, scratch and refusal relation, not as a complete step-witness profile. Witness placement for O-ARITH or P4 requires a profile revision and a fresh review.

### R2-3 — Pre-state reference ordering is an unlisted precondition (binding erratum)

The following depend on DataFields, ConstantFields and EnvCells references pointing strictly earlier in the *pre-state*:
- EqScratch termination;
- the W_eq bound and the claim that EqScratch.stack is unreachable;
- the `ufd` bound.

Only E3 enforces this, and only along the env chain. §2.4 lists INV-ORD only for appended rows. **Binding:** add INV-ORD-PRE, an L4 acyclicity dependency on StepInv and chaining, alongside INV-TY-D and INV-TY-K. It is a precondition and is not enforced.

### R2-4 — Refusal classification (binding erratum)

Q-8 failure is "no accepting assignment", the same in-circuit signal as a guard or E2/E3 failure. Under F5's incremental first-overflow refusal at row Q_eq−1, a later out-of-domain read would be masked.

**Binding:**
- Host classification first decodes the ProgramBlock and pre via L4 (Step mode). That decode is polynomial in image size, and any WrongRepresentation it finds precedes all others.
- In-domain images cannot fail E1–E3: E2 follows from constructor typing, and E3 from parent order. The EqScratch.rows locator is therefore deterministic.
- The L4 `Capacity.needed` field for EqScratch.rows is `Q_eq+1`, reported as a lower bound.

### R2-5 — A214 drops `kind=2` for Cons/Leaf/Branch but keeps it for Nil (binding erratum)

r1 tested kind on all five patterns. **Binding reading:** under INV-TY-D/K, `typeId∈{2,3}` implies `kind=2`, so the guards are equivalent in domain. No claim is made outside the domain, and the change is a reading, not a mechanism change.

### R2-6 — BindPreflight B-3 references `pass_{i+1}` at i=P−1 (binding erratum)

**Binding:** `pass_P := 0`. It is never consulted, because `i<k` short-circuits.

### R2-7 to R2-10 — Informative

- **R2-7.** FindScan tail rows carry `seen` and are not all-zero. They are constrained, so this is acceptable.
- **R2-8.** JSON A157 omits result and Err fields, and A161/A165/A169/A185/A190 omit selectors. full39's G/W lines govern them, and "no free selector" (§2.3) is conditional on P5.
- **R2-9.** EqScratch-row and Capacity table names lie outside L4's `table_capacities`, so an L4-only consumer must report WrongProfile. The fixed-shape AuxBlock carries a Q_eq×W_eq stack and a P(P−1)/2 matrix on every step. That is an L05 cost; no claim is made.
- **R2-10.** Example notation: EX1 has implicit S/stackLimit requirements, Capacity tuples lack locators, and EX6's scrutinee is implicit. Non-blocking.

---

## 8. Mechanisms still unselected or outsourced

None of these is blocking, because each is explicit and consistent. Each still gates emitter acceptance:
- O-ARITH limb, range and witness placement, and the fuel-borrow witness (R2-1, R2-2);
- P4 wiring, P5 global exactly-one dispatch and preservation, and G4 primitives;
- StepInv and chaining for INV-TY-D and INV-ORD-PRE; Constant typing and ProgramBlock canonicality (F4);
- D-NAMES enforcement;
- MD2;
- L04 labels and statement or profile binding;
- the L05 Q_eq value and segment admission.

I found no other P3 mechanism that the candidate claims complete but omits.

---

## 9. Binding conditions

1. **Votes.** A fresh Muse normal vote on these exact hashes and a Root adoption record are required. The author's text is not a vote, and no r1 vote transfers.
2. **Scope.** Adopted on these bytes: the complete P3 source design.
   - Policy A;
   - the append primitives and the 39-row Δ, mask and reference catalog as relations;
   - EXT/COPY, the A214 root rule, and the A204 commit and failure images;
   - all four `sherlock-k-a-aux/1` schemas, their packing, enables and labels as proposed;
   - Q_eq as a symbolic dimension;
   - the refusal names and order;
   - the generic bounds.
   
   P4 masks are informative wiring targets only.
3. **Binding errata, with no byte edits:** R2-1, R2-3, R2-4, R2-5 and R2-6. Any byte change voids this vote for the changed bytes.
4. **R2-2.** `aux/1` is not a complete step-witness profile. O-ARITH and fuel-borrow witnesses require a new profile version and fresh review.
5. **No emitter acceptance** until every item in §8 is owner-specified and reviewed. The full39 conditions 1–10 stay binding.
6. **Profile and dimensions.** The profile identity and its dimensions must be bound into layout identity and the statement (L04) before any native use.
7. **Unperformed obligations.** The K/Quint/Clean obligations remain unperformed. No execution is demanded or authorized.
8. **No grant.** No runtime, resource, numeric, operator, configuration, binding or circuit admission is granted.
   - Native authority stays 0.
   - The old 90s/30s caps, counters and failures are unchanged.
   - C4 is unchanged: no dependent circuit edit happens before admitted A102 compilation, and a compile failure means registration revert.
   - The full39 P1 map and the seven L4 bodies are unchanged.
   - CandidateA's four Value kinds remain distinct from B, general ADTs and financial behaviour.
   - U0–U7, M1–M17, MC, SP, G, proof, ledger and Midnight stagenet remain open.

**ADOPT_COMPLETE_P3_SOURCE_WITH_CONDITIONS** — manifest `e7c34e52…984f`, MD `b2d6fda4…91eb`, JSON `3f33a0dc…b214`, subject to conditions 1–8.
