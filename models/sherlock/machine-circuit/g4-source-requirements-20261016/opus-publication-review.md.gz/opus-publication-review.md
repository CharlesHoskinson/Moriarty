# G4 source-requirements publication review (Opus security owner)

This is a fresh full publication review of candidate manifest **f1ff2291a47a933f0596acfb2e5068af82737fdc4cd8d2c88b15cb84751bb86a**. The candidate is source commit `624e6d5e1c96ee6eff836d656c5d592650b78713` on parent `70220c8d569ded7f828350e803daffe4453c1536`, tree `15028d04cc6fac1c479f77e8d7d36d89a12a1d7c`, 26 files. I reviewed it as Opus 5.5 (`claude-opus-5-5`), the restored designated security owner, in a read-only, tool-free context.

**Disposition: APPROVED_PUBLICATION_WITH_LIMITS**, subject to the reading limits, binding errata and seal conditions below.

- This approval covers publication hygiene, privacy, provenance, claim accuracy and metadata only.
- It is not a new security analysis.
- It does not satisfy any G4, FETCH/BYTE/APPEND, IO, P4/P5, StepInv, native, proof or stagenet gate.
- It does not replace the separate fresh Muse independent conformance vote.

## Reading scope and limits

- **What I read.** I read every transported body as text:
  - the 26 candidate files;
  - the 9 gzip-decoded review bodies;
  - the two `CONTEXT::` files (the product contract and Root static r2).
- **What I did not do.** I recomputed no SHA-256 values, byte counts, gzip headers, character-span offsets or Git objects. Every identity here is as supplied and as checked by Root.
- **JSON formatting.** JSON bodies arrived whitespace-normalized, so I did not see their original byte layout.
- **Text pool references.** I did not independently verify the `EXACT_STRING_REF`/`EXACT_TEXT_REF` span arithmetic. I spot-checked content only. The B1–B13, field-split and R2-4 quotations in `BINDING-READINGS.md` read as verbatim against the full capture texts.
- **Excluded bodies.** I saw only the metadata (path, size, hash, category, reason) of the 88 excluded original bodies, never their content. I did not re-audit them, and nothing here claims the 93-file SDK packet is published.
- **Hash spot-checks.** I spot-checked about ten excluded-body hashes across the closure, `SOURCE-MANIFEST`, `INPUT-MANIFEST` and `SOURCE-BODY-SELECTION`. All agreed. The category counts also agree:
  - 4 + 5 + 6 + 2 + 68 + 8 = 93;
  - 82 snapshot pairs = 68 + 8 + 6;
  - 26 Git-blob matches = 8 Moriarty + 18 ledger;
  - 90 outer-manifest members + 3 unlisted = 93.
- **Independence.** I am the same model family as the Opus source-owner reviewer. This review is therefore not cross-family independent of the B1–B13 owner readings.
- **Effort.** High effort was requested. Neither the Opus nor the Muse capture in this packet reports effort in its returned usage. Muse's `effort: "high"` is a top-level request-side field. No effort level is claimed as response-reported.

## Provenance, source class and owner hierarchy

The candidate preserves the hierarchy correctly:

1. **Original draft.** The original Muse fallback draft (`PROPOSAL.md`, `PROVENANCE.json`, proposal manifest `f78afdd4…`) is retained byte-identical. It is labelled an unadmitted draft: the provider completed, but the adapter rejected it for the missing closure SHA. It is not a vote, and it is not retroactively approved.
2. **Opus source review.** It is the designated-owner vote with B1–B13. It discloses the shared-family limitation.
3. **First Muse review.** It is the fresh, non-author conformance vote.
4. **Muse owner-reading disposition.** It agrees with B1–B13 and explicitly retracts the "redundant defense" and weaker L-5 determinism wording.
5. **Root adoption.**
   - It is limited to requirements plus a conditional source argument.
   - It has `adopted_as_execution:false` and `native_authority:0`.
   - It quotes the normative limit sentence verbatim.
   - It subordinates the draft to the owner readings.

The current derived texts (README, `BINDING-READINGS`, the ROADMAP paragraph and the IMPLEMENTATION-STATUS section) state this ordering accurately:

- The "redundant defense" phrase is identified as false at source level and historical.
- B2's bound-cache correction governs.
- FIELD-SRC is kept separate from unproved FIELD-PRIME and unobserved FIELD-REAL.
- The in-circuit/off-circuit, width (B4/B5), Assert (B6), fetched-byte (B11), disabled-temporary (B12) and preprocessing-bypass (B13) readings are retained.

None of the current texts claims a primitive certificate, G4 runtime acceptance, emitter acceptance, a hostile test, or any SDK/compiler/model/native/proof/stagenet result. The ROADMAP and OpenSpec additions only record the conditional source argument and keep every parent exit open.

## Privacy and hygiene

- **No sensitive material.** There are no credentials, keys, tokens, prompts, provider debug logs, private source bodies, third-party implementation payloads, Moriarty implementation bodies or Git binary listings. The user's email does not appear.
- **Accepted metadata, disclosed rather than blocking:**
  - Absolute local paths reveal the local account name (`/home/charl/…`) and the runtime and worktree layout.
  - Cargo registry and git-checkout paths are included.
  - Provider request/response IDs are included (Muse/meta).
  - Opus token usage and list `costUSD` are included.
  - Prompt and launch-stdout SHA-256 values are included (hashes only).
- **Third-party material.** The only verbatim upstream fragments are short identifiers, line citations, gate equations and one `#![doc = include_str!(...)]` line. No third-party file body or license-bearing payload is redistributed, so I see no notice obligation arising from these bytes. This is a reading, not legal advice.
- **Public status of upstream sources.** I cannot independently confirm that ledger revision `04c9c5d9…` and the registry crates are public. That rests on the original `INPUT-MANIFEST` "public source" statement.
- **Filename case.** `PUBLICATION-BINDING.json` and the prospective `publication-review-binding.json` differ beyond case. There is no case-fold collision on case-insensitive checkouts.
- **Whitespace overlay.** The EOF overlay removes one blank line from derived `BINDING-READINGS.md` (8787 to 8786 bytes). It is non-semantic. The body now ends in a single LF, and no original proposal, review, adoption or source byte changed.

## Binding publication errata

These are recorded readings, not byte changes. None weakens a limit, and the full captures govern in every case.

- **P-E1 (README overstatement).** The README says "The complete owner §7 is also quoted there." `BINDING-READINGS.md` actually quotes §7 only through "…C bindings remain unknown."
  - It omits §7's closing paragraph: "Any byte change voids this review for the changed bytes. The second fresh review (the Muse conformance audit) and a Root adoption record are still required, and no historical vote transfers."
  - It also omits the vote line.
  - Read the README sentence as "owner §7's preserved-binding list and limits paragraph". The complete §7 is in `reviews/opus-source/RESULT.text.gz`.
- **P-E2 (preparation-time wording).** Some statements were true at preparation time and become historical once merged:
  - `PUBLICATION-BINDING.json` status `PREPARED_FOR_FRESH_PUBLICATION_REVIEW; NOT_PUBLISHED`;
  - the README sentences "This folder prepares publication…" and "The publication worktree is untouched by this runtime-only preparation".
  - Publication status is recorded only by the prospective `publication-review-binding.json`.
- **P-E2 (unpublished external manifest).** The external runtime manifest referenced as binding `PUBLICATION-BINDING.json` (`astra-g4-source-requirements-publication-prep-r1/SOURCE-MANIFEST.json`) is not published. Public readers cannot verify that link from the repository alone.
- **P-E3 (adoption wording).** The adoption `retained_requirements` entry "G4-FIELD-PRIME and G4-FIELD-REAL unobserved" must be read under B1: PRIME is unproved [RA] and REAL is unobserved [UK]. The frozen adoption bytes are unchanged.
- **P-E4 (superseded width restriction).** The first Muse review's condition 4 restricts G4-ISA-4 to w ≤ 12 and w = 128. That is superseded by owner B4 (0 ≤ w ≤ 254), which the later Muse disposition agrees with. The used widths 1, 8, 12 and 128 fall inside both, so there is no conflict.
- **P-E5 (IMPLEMENTATION-STATUS history).** Some earlier sections of the dated IMPLEMENTATION-STATUS note keep historical framing:
  - "at publication base `5cf27d64…`";
  - "This publication candidate still needs fresh full owner and Muse publication reviews."
  - Both refer to those earlier candidates, not to this G4 publication. I cannot tell from the transport whether those lines changed in this diff. The new G4 section is accurate.

## Retained, unchanged

The following stay exactly as they were:

- **G4 obligations:** G4-FETCH, G4-BYTE and G4-APPEND; IO-1–IO-8; complete P4/P5/StepInv/chaining.
- **Prior conditions:** E1–E7 and E-FUEL; full39 conditions 1–10 and F1–F7; P3 conditions 1–8 and R2 errata; L4/L04/L05.
- **Muse R2-4 dissent:** both prongs, verbatim as in the adoption record and `BINDING-READINGS`.
- **C4:** no dependent circuit edit before an admitted A102 compile, and registration revert on compile failure.
- **Limits:** the old 90s/30s caps, counters and terminal failures; no retry, campaign or resource grant; native authority 0.
- **Roadmap:** the full U0–U7, M1–M17, MC/SP/G, financial, product-scope and Midnight-stagenet exits.

## Seal conditions

This approval covers only these five prospective seal files:

1. `opus-publication-review.json.gz`
2. `opus-publication-review.md.gz`
3. `muse-publication-review.json.gz`
4. `muse-publication-review.md.gz`
5. `publication-review-binding.json`

Each `.json.gz` and `.md.gz` must be:

- a single-member gzip;
- with mtime 0 and an empty filename;
- containing the literal current full publication-review JSON, or the review text plus one final LF for the `.md.gz`.

`publication-review-binding.json` must include:

- **Identities:**
  - all 26 candidate identities;
  - all 9 existing gzip identities (compressed and uncompressed bytes and SHA, and the `/text` pointer rule);
  - the 4 new capture identities (original JSON/MD and gzip bytes and SHA, single-member, mtime 0).
- **Review content:**
  - both exact votes, with candidate SHA `f1ff2291…`;
  - every condition, reading limit, dissent and erratum (P-E1–P-E5);
  - both R2-4 prongs, verbatim.
- **Required statements:**
  - no CI pass is claimed if the check rollup is empty or absent;
  - no source, claim, execution or source-class change;
  - the adoption limit sentence, verbatim;
  - native authority 0.

Before publishing, Root must re-verify that all 26 candidate files are byte-unchanged and that exactly these five files were added. The binding must not claim that any reviewer saw the seal files or any post-review hash. No other future file is approved.

If the separate Muse vote blocks or materially dissents, this approval alone does not authorize publication.

**Final vote: APPROVED_PUBLICATION_WITH_LIMITS** — candidate **f1ff2291a47a933f0596acfb2e5068af82737fdc4cd8d2c88b15cb84751bb86a**, under the reading limits, binding errata P-E1–P-E5 and seal conditions above. No primitive certificate, G4 runtime, emitter, native or stagenet acceptance is implied.
