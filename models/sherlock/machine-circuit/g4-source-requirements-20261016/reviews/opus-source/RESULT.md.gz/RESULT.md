# Fresh designated-owner security review: frozen G4 source-predicate proposal

**Review target:** manifest `f78afdd4eb2695fb152eacb70bd20892d546aefdac2038feb9dee22f88b96fda`. It binds PROPOSAL.md `b6405a13e0541c71d2a4d62dcf65b9b8013db7a7a2910d3046107844145bb4af` and PROVENANCE.json `8669ca8f181110beee2a8188312af9c1e072e36d81c139f081f447252b367010`, against Root source closure `a9d389ac4f946e19bf0034912248f1e165d59c4f462084ffef7dd966f3196d51` (93 files). Opus 5.5 (`claude-opus-5-5`) reviewed it in a fresh context as the designated security owner. I did not write this proposal. I am the same model family as the author of the aux/2 design it relies on, so this is not a cross-family check of aux/2. I used no tools, shell, writes, execution or acquisition. I recomputed no hashes, so every identity above is as supplied. I read all 93 supplied bodies as text. I did not check them byte for byte.

**Provenance, retained unchanged.** The proposal is still a Muse Wonder 1.0 fallback draft. Its provider run completed, but the adapter rejected it because the body omits the closure SHA. It is not an admitted vote, and this review does not relabel it as approved. A separate fresh Muse conformance audit and a Root record are still required. Native authority stays 0.

**Disposition in brief.** The proposal's field chain, delegate chains and gate equations are correct, with one exception about TestEq Booleanity (B2). Its bound derivations are also correct. Nothing in it is unsound as a requirements statement. It does have:
- one materially false claim, the "redundant ConstrainToBoolean defense" (B2);
- one missing source mechanism that every G4 predicate depends on, the NativeGadget bound cache (B3);
- an imprecise ConstrainBits domain (B4) and an unstated LessThan field bound and width mapping (B5);
- understated Assert semantics (B6);
- several citation errors (B7–B8).

All of these are fixed by binding readings, with no new mechanism. Vote at the end.

---

## 1. Field chain (§1 of the proposal)

**Agreed [SF]:**
- `curve.rs` sets `outer::Scalar = midnight_curves::Fq` (:55) and `pub struct Fr(pub outer::Scalar)` (:158).
- The embedded scalar `midnight_curves::Fr` (:67) is the distinct Jubjub scalar.
- `F = outer::Scalar` appears at `ir_instructions/mod.rs:16` and `ir_types.rs:30`.
- The stdlib sets `F = midnight_curves::Fq` (:126) and `NG` (:129).
- The modulus limbs (`fq.rs:43`), `MODULUS_REPR` (:64), `NUM_BITS = 255` (:366) and the `PrimeField::MODULUS` string (:502) are as cited.
- The `Bls12` engine sets `type Fr = Fq` (`bls12_381/mod.rs`), so the proof system's scalar field is the same type.

Note the naming hazard: midnight_curves names the BLS12-381 scalar field `Fq` and the Jubjub scalar field `Fr`. That is the reverse of the usual convention. The proposal handles it correctly.

**[MD] derivation, checked by hand:**
- The four limbs, the 32-byte repr and the hex string encode the same integer.
- The top limb is `0x73ed…`, so bit 254 is set and bit 255 is clear, which is consistent with `NUM_BITS = 255`.
- The literal exceeds 2^254. So, for the literal: p > 2^20, p ≥ 2^129, and p > 2^w for every w ≤ 254.

**Dissent: the single G4-FIELD predicate must be split (binding reading B1).** The arithmetic the circuit and the prover actually perform does not use the Rust literal:
- `Fq` add, sub, mul, neg and invert call `blst_fr_add/sub/mul/cneg/eucl_inverse`.
- `from_bytes_le` validity uses `blst_scalar_fr_check`.
- All of these are C or assembly, which was not collected. Their modulus constant is not in the closure.
- ff-0.13.1 documents `PrimeField::MODULUS` as "written as a string for debugging purposes … should treat this string as opaque". It is the weakest evidence of the three encodings.
- The circuits, proofs and stdlib manifests carry a `cfg(ci_build)` target dependency that switches `midnight-curves` to `portable`. So the blst build configuration depends on an unobserved compiler cfg.

The predicate is therefore read as three parts:
- **G4-FIELD-SRC [SF+MD], adoptable as a requirement statement.** The three Rust-side encodings agree, and the literal meets every bound above.
- **G4-FIELD-PRIME [RA].** Primality is not derived here. TestEq soundness and Assert soundness depend on it, because they need a zero-divisor-free ring with inverses.
- **G4-FIELD-REAL [UK].** This covers the executed blst arithmetic, its modulus, the feature and cfg resolution, the binary identity, and the prover and verifier.

---

## 2. Instruction matrix: agreement and dissent against the bodies

| Instruction | Finding |
|---|---|
| **Add** | **Agree, with a precision erratum (B7).** The chain is `ir_vm` → `add_incircuit` → `std_lib.add` (a default trait method that calls `linear_combination`) → `NativeChip::linear_combination` (`native_chip.rs:858`) → `assign_linear_combination_aux`. The constraint is `−res + Σcᵢaᵢ + k = 0`. The *inputs* are copy-constrained into the row, and the output *is* the assigned result cell. Terms whose coefficient is 0, or whose cell is the cached fixed-0 cell, are filtered out. A single unit term with constant 0 returns the input cell itself, and an empty set returns a fixed cell. Both are sound aliases. `arithmetic.rs:67` is the declaration of `linear_combination`, not `add`. |
| **Mul** | **Agree.** The chain is `NativeChip::mul` (:919) → `add_and_mul` → `add_and_double_mul` with `(m1,m2) = (1,0)`, giving `res = x·y`. If either operand is the cached fixed-1 cell, the other operand is returned. That is a sound alias. |
| **ConstrainEq** | **Agree.** `std_lib.assert_equal` → `NativeGadget::assert_equal` → `Region::constrain_equal`. NativeGadget also *propagates bound metadata* between x and y (B3). Equality enablement is **[SF]**: `NativeChip::configure` calls `enable_equality` on all five value columns, `fixed_values_col` and both instance columns. Only the permutation argument is **[UK]** (B9). |
| **ConstrainToBoolean** | **Agree only conditionally (B2/B3).** If no bound ≤ 2 is cached for the cell, `NativeChip::convert` (:1098) emits `b² − b = 0` and a copy. If one is cached, it emits **no** constraint (`convert_unsafe`). |
| **ConstrainBits{w}** | **Agree for the cited widths. The domain is restated (B4).** 1-bit limbs are placed in `value_cols[1..=4]`, which by `ZkStdLib::configure` are exactly the Pow2Range lookup columns. `load_table` is collected and is called last in `MidnightCircuit::synthesize` [SF]. The lookup argument itself is [UK]. |
| **TestEq** | **Agree on the equations. Dissent on the "redundant defense" claim (B2).** `native_chip.rs:1240` enforces `(x−y)·aux = 1−res` and `res·(x−y) = 0`, the latter through `add_and_double_mul` plus `assert_zero`. These give `res = [x=y]` and make `res` Boolean, given G4-FIELD-PRIME. |
| **CondSelect** | **Agree.** `ir_vm.rs:835` converts the selector to `AssignedBit` (or elides the conversion through the cache when it is already bounded). `NativeChip::select` (:1480) then computes `y + c·x − c·y`. The predicate covers Native operands only. |
| **LessThan{128}** | **Agree on the mechanism. The bound is made explicit (B5).** |
| **Assert** | **Agree, with semantics sharpened (B6).** |

---

## 3. Source mechanisms the proposal omits (binding readings)

**B2: the ConstrainToBoolean after TestEq or LessThan is a no-op.**
1. `ir_vm` TestEq calls `std.convert(&bit)` to turn the AssignedBit into an AssignedNative.
2. The NativeGadget conversion that inherits from AssignedBit calls `update_bound(&x, 2)` on the *same cell*.
3. A later `ConstrainToBoolean` reaches `NativeGadget::convert` (AssignedNative to AssignedBit). That function sees a cached bound ≤ 2 and calls `convert_unsafe`, so no gate is emitted.

The same thing happens to:
- LessThan outputs (`lower_than` assigns `b` through `NativeChip::assign`, which enforces `b² = b`; the ir_vm conversion then caches the bound);
- `literal_step`'s `test_zero`;
- `enabled_fetch`'s `TestEq`-then-`constrain`;
- aux/2 §11's lowering of `[x=y]`.

The proposal's statement "aux/2's added ConstrainToBoolean on the result is redundant defense, retained" is **false at source level**. The instruction may stay in emitted code, but no reviewer, negative check or certificate may count it. Booleanity of TestEq rests solely on the two-equation construction plus G4-FIELD-PRIME.

**B3: NativeGadget's `constrained_cells` cache makes constraint emission depend on history.**
- The cache is keyed by cell identity.
- `convert` (to a bit or byte) and `assert_lower_than_fixed` skip emitting constraints when a sufficient bound is already recorded.
- `assert_equal` propagates bounds in both directions.

By reading, every recorded bound is backed by an enforcing gate, a lookup, or a copy constraint on an equal cell. That invariant is [SF]-supported, conditional on the permutation and lookup backend [UK]. `assigned_to_le_bits` (ConstrainBits) neither reads nor writes the cache.

Every G4-ISA predicate is therefore read as "the output cell satisfies property P", never as "this instruction emits gate G". Any constraint count, the N1–N16 negative checks, and the IO-3 fuel-chain equivalence must model the cache.

**B4: the exact domain of ConstrainBits (replaces "for bits approaching NUM_BITS").**
- For **0 ≤ w ≤ 254**, Σ2ⁱbᵢ < 2^w ≤ 2^254 < p, so the canonical representative lies in [0, 2^w) [MD].
- For **w = 255**, `enforce_canonical` is set and the range is vacuous: every field element fits. Only the decomposition becomes unique.
- For **w > 255**, the `assert!` in `assigned_to_le_bits` panics on the host.
- Off-circuit, any w ≥ 255 is rejected.

G4-ISA-4 is adopted for w ≤ 254 only. The aux/2 widths 1, 8 and 12, and the Moriarty width 128, are all inside that range.

**B5: LessThan's in-circuit width and field bound.**
- `ir_vm.rs:959` passes `n = max(bits + bits%2, 4)`. For odd `bits` or `bits < 4`, the **in-circuit** operand range (2^n) is looser than both the IR's documented domain and the off-circuit check. That is an in-circuit/off-circuit mismatch a malicious prover can exploit. For `bits = 128`, n = 128 exactly.
- In `NativeGadget::lower_than`:
  - b is Boolean by assignment;
  - x and y are each placed in [0, 2^128) by `bounded_of_element`, through `assert_less_than_pow2`;
  - z = 2by − b + x − 2bx − y is range-checked below 2^128.
- A wrong b makes z a negative integer, which wraps to at least p − 2^128. So b = [x<y] is sound and complete **iff p ≥ 2^129** [MD]. The literal satisfies this.

The stdlib's `lower_than` doc says "n > (NUM_BITS−1)/2" (that is, n > 127) "will result in a compile-time error". The `comparison.rs` module doc advises bounds of at most 2^(NUM_BITS/2−1). The collected code only asserts n ≤ NUM_BITS−2 = 253, and contains no compile-time check. My derivation supports n = 128 for this body. The upstream inconsistency stays **[RA]** for the E5 consumers (fetch and A102). It is not an aux/2 premise.

**B6: Assert is "non-zero", not "equals 1".** In-circuit, Assert goes `assert_non_zero` → `assign_with_shifted_inverse(·,0)` (y·r = 1) → copy. Off-circuit it requires exactly 1. Every Assert consumer must pass a *constrained* Boolean. `enabled_fetch` does: `select(enable, in_prefix, 1)` combines two constrained Booleans.

**B13: preprocessing is provably bypassable.**
- `IrSource::prove_unchecked` (`ir.rs`) accepts a caller-supplied `Preprocessed` value.
- The `mem_insert` and `pi_push` mismatch checks are host `Value` errors, not constraints.
- In-circuit, `PublicInput` and `PrivateInput` ignore the guard and assign Native cells with no constraint.

This confirms the proposal's off-circuit/in-circuit separation. Only constraints emitted during synthesis count as evidence.

---

## 4. Bounds and wrap avoidance (§3 of the proposal)

**Re-derived and agreed:**
- ADD, SUB and FD-2 have E within [−511, 511].
- MUL-k has S_k ≤ 65025·min(k+1, 31−k) ≤ 1,040,400. With 12-bit admitted carries, E lies in [−1,048,575, 1,044,495].
- The exact need is p ≥ 2^20. The stated binding condition, p > 2^20, is slightly stronger and remains E4.
- Honest carries reach at most 4079, and the inductive bound is 4080.
- hSum ≤ 4080.
- c₃₂ = 0 carries real weight in the proof.
- Lifting needs only |E| < p, not primality.

**Errata:**
- **B10.** A free (supplied) selector, carry, product, column sum Sₖ, or inverse is a **soundness** failure, not only a failure of determinism (L-5). It permits forged branches, for example a selector picking Sub on an Add step, and aliased disabled witnesses.
- **B11: the byte premise on fetched carriers.**
  - The generic `TableShape` has only `UInt`, constrained by `ConstrainBits{128}`, and `Bool`. It never states an 8-bit premise.
  - An 8-bit aᵢ or bᵢ must come from per-lane L4 width ranges on the row cells, and robustly also on the selected output. `literal_step` does both: `image_ranges`, and then `b.ranges(&expression.lanes, &selected)`.
  - Inheriting the range through the CondSelect fold is valid only when the selectors are Boolean and at most one is set.
  - G4-FETCH must state the re-range requirement explicitly.
- **B12: preconditions on the `gated_eq` lowering.**
  - When enabled, it yields L ≡ R (mod p). L and R must be built only from ISA-1 Add and Mul, with the ranges that bound |L−R|.
  - When disabled, it holds trivially. However, any *unconditional* constraint on temporaries that feed L or R must be satisfiable by disabled witnesses. Examples are `literal_step`'s ungated `bits(carry, 9)`, LessThan's operand ranges, and Assert.

The proposal's side remark about `checked_mul` silently assumes operands of at most 128 bits. It is not binding on G4.

---

## 5. Fetch and A102 wiring (§4 of the proposal)

**Agreed, by reading `enabled_fetch.rs` and `literal_step.rs`:**
- The enabled constructor is as described.
- `root[5]` is `activeExpressions` and `root[14]` is `activeConstants`. This matches the header order built by `literal_schema`.
- The Constant node is compared, never fetched.
- The bytewise fuel chain matches FD-1 and FD-2 algebraically. Gating and the bound cache (B3) remain IO-3 work.
- The source shows an emitter-level composition only. It is not an SDK fetch primitive, G4-FETCH, G4-BYTE or G4-APPEND.

The call-site line `literal_step.rs:293` cannot be verified from the unnumbered body. It is consistent with `emit_literal_step` at :253 (B8).

**B8 citation errata:**
- `circuit_field.rs:331` is the *test-module* alias. The instantiation is `impl_circuit_field_le!(midnight_curves::Fq, 32)`.
- `arithmetic.rs:67` is `linear_combination`, as noted in B7.

**B9 refinement:** `cpu_utils` produces witnesses only and is not a soundness premise.

---

## 6. Source requirement versus satisfied runtime property

| Item | Adopted as | Satisfied at runtime? |
|---|---|---|
| G4-FIELD-SRC (B1) | [SF]+[MD] requirement statement | **No.** No execution evidence. |
| G4-FIELD-PRIME | [RA] | No |
| G4-FIELD-REAL | [UK] | No |
| G4-ISA-1 (Native Add/Mul, B7) | Conditional source argument | No |
| G4-ISA-2 (TestEq, B2) | Conditional source argument. Booleanity depends on PRIME only. | No |
| G4-ISA-3 (Native CondSelect) | Conditional source argument | No |
| G4-ISA-4 (w ≤ 254, B3/B4) | Conditional source argument. Lookup and permutation are [UK]. | No |
| LessThan{128} (B5) | Informational only, under the E5 scope. p ≥ 2^129, plus the doc inconsistency as [RA]. | No |
| G4-FETCH / BYTE / APPEND | **Open, not addressed.** B11 is added to FETCH. | No |

Every acceptance record must repeat the proposal's §6 sentence verbatim:

> this acceptance rests on source inspection and paper derivation only; it includes no execution evidence and confers no G4 runtime certification, no emitter acceptance, and no native authority.

---

## 7. Preserved bindings

The following remain unchanged and binding:
- E1–E7 and E-FUEL;
- IO-1–IO-8;
- P3 conditions 1–8;
- errata R2-1 and R2-3–R2-6, with the Muse R2-4 dissent preserved verbatim in both prongs;
- full39 conditions 1–10 and F1–F7;
- L4;
- C4: no dependent circuit source edit before an admitted A102 compile, and a compile failure means registration revert;
- the old 90s/30s caps, counters and terminal failures;
- the full MoriartyV1 U0–U7 / M1–M17 roadmap.

There is no retry, no new campaign, no resource grant, no command, and native authority stays 0. This review makes no claim about emitters, native code, the SDK, tools, builds, registry authenticity, caller validity, proofs or targets. The complete transitive build, proof backend, table loading at runtime, features and C bindings remain unknown.

Any byte change voids this review for the changed bytes. The second fresh review (the Muse conformance audit) and a Root adoption record are still required, and no historical vote transfers.

**ADOPTABLE_G4_SOURCE_REQUIREMENTS_WITH_LIMITS** — manifest `f78afdd4eb2695fb152eacb70bd20892d546aefdac2038feb9dee22f88b96fda` (PROPOSAL `b6405a13…5bb4af`, closure `a9d389ac4f946e19bf0034912248f1e165d59c4f462084ffef7dd966f3196d51`). Adopted as reviewed requirements and conditional source argument only, not as an actual primitive certificate, subject to binding readings B1–B13 and §§6–7.
