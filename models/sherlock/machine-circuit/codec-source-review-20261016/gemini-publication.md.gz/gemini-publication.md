`APPROVED_SOURCE_PUBLICATION_WITH_CONDITIONS`

### 1. Reviewer Identity and Input Read Limits
- **Reviewer Identity**: Gemini 4 Argon (High) via AGY (`gemini-4-argon-high`), acting as temporary designated security owner under the user's explicit October 16 outage fallback (`raw/assignments/moriarty-opus-outage-fallback-2026-10-16.md`) following Opus `429 usage_limit_reached`. As recorded in the candidate's qualification metadata, `init.model` reflects observed model selection only (`separate_canonical_model_id: "NOT_REPORTED"`), not a separate cryptographic or canonical identity attestation.
- **Context & Read Completeness**: All three message parts (`PUB_PART_1_a3194546e50b4c5b849cd3aaeb860489`, `PUB_PART_2_d2fadd0f79844288a1276308802f47d9`, `PUB_PART_3_1ceb38ce00e54dc3b9b90f11ea7960bd`) were received and retained in full without truncation. I manually read all **38 selected file views**, the complete decoded UTF-8 text of all **4 gzip source-review receipts**, the **2 before-images** of the only modified pre-existing paths, and the `complete_publication_context` contract (manifest `bfba0a16b4948d7b2feb450071086b614d7b73588b2184834882b5c9baa2cb2e`, base commit `3febc9919a0a6e0756e1bfc6b9cc882d4349863b`, source commit `fb7fe8684a35fc7d31d8c771617be92968687517`).
- **Execution & Tooling Limits**: Pure static manual source reading only. Zero tools, shell commands, file reads/writes, web fetches, or subagent delegations were invoked. Requested `/plan` mode is a prompt constraint and not a mechanical no-tools guarantee. Compilation, formatting, all 25 unit tests (`8 + 8 + 5 + 4`), SDK builds, model checks, and native provers remain **UNRUN**. Native authority is `0`.

---

### 2. Exact 38-File Freeze and Scope Verification
- **Exact File Count (38, Not 31)**: The publication manifest selects exactly **38 files** (`git_mode: "100644"`), comprising **36 new additions** (`before_sha256: "ABSENT"`) and **only 2 modified pre-existing files**:
  1. **16 Current-A Host Codec Files (`crates/mori-core/src/sherlock/`)**: 15 new files under `layout_a/` (`README.md`, `constants.rs`, `encoding.rs`, `limits.rs`, `mod.rs`, `normal_tests.rs`, `prepare.rs`, `rows.rs`, `state.rs`, `state_decode.rs`, `state_decode_normal_tests.rs`, `state_encode.rs`, `state_encode_normal_tests.rs`, `state_encoding.rs`, `state_encoding_normal_tests.rs`) plus 1 modified parent file `crates/mori-core/src/sherlock/mod.rs` (`f52701a1...` -> `d0eb44ee...`), matching integration manifest `adad64b8cd6df628c36ae4cd312b4417eb4c054f632bab511096e89a432b43ee`.
  2. **7 Unchanged L4 Specification Files (`openspec/changes/sherlock-machine-circuit-layout/`)**: `OWNER-REPAIR-PROVENANCE.md`, `crosswalk.json`, `design.md`, `extensions-and-obligations.md`, `interfaces.md`, `proposal.md`, and `tasks.md`, matching `L4-ROOT-HOST-SOURCE-ADOPTION.json` (`91d8bd43ac4ce41f0d9a89127e9f39865a53b153216f6424fb10e7a3ad91af88`) bit-for-bit.
  3. **13 Review, Expectation, and Freeze Artifacts (`models/sherlock/machine-circuit/codec-source-review-20261016/`)**: 4 independent expectation JSON packets, `BYTE-EXPECTATION-PROVENANCE.md`, 4 gzipped source-review receipts (`gemini-source.{md,json}.gz`, `muse-source.{md,json}.gz`), `L4-ROOT-HOST-SOURCE-ADOPTION.json`, `PARTIAL-REVIEW-QUALIFICATION.json`, `README.md`, and `SOURCE-FREEZE.json`.
  4. **2 Routing & Repository Instruction Files**: New assignment record `raw/assignments/moriarty-opus-outage-fallback-2026-10-16.md` and modified `AGENTS.md` (`16eedf4d...` -> `f1f8697d...`).
- **Before-Image Diff Verification**:
  - `crates/mori-core/src/sherlock/mod.rs` preserves all prior lines verbatim and appends only the private `#[cfg(test)] mod layout_a;` registration and its two-line H1/UNRUN comment.
  - `AGENTS.md` preserves all prior sections and historical routing records verbatim, prepending only `## Temporary security fallback - October 16` referencing `moriarty-opus-outage-fallback-2026-10-16.md` with zero native authority.
  - No SDK build wrapper, Cargo dependency/lockfile, CI workflow, backend registration, website asset, circuit-atlas iteration, or public runtime API is added.

---

### 3. Qualifications, Correlations, and Provenance Audit
- **Disqualification of Stale/Partial Gemini Review**: `PARTIAL-REVIEW-QUALIFICATION.json` and `README.md` explicitly classify the earlier single-message Gemini run as `PARTIAL_SOURCE_REVIEW_NOT_FULL_REQUIRED_VOTE` due to normative context truncation at `OWNER-REPAIR-PROVENANCE.md`. It is not counted as a required vote.
- **Valid Two-Vote Source Coverage**: `gemini-source.{md,json}.gz` (r3 two-message review with verified context markers) and `muse-source.{md,json}.gz` (r2 review) both inspect the complete 16-file source and 7-file L4 specification and return `APPROVED_SOURCE_WITH_LIMITS`. Each `.md.gz` decodes to the exact UTF-8 `text` field of its companion `.json.gz` without newline or Unicode normalization.
- **Correlation & Expectation Provenance**:
  - `BYTE-EXPECTATION-PROVENANCE.md` accurately qualifies the inherited r1 note in `independent-state-byte-expectations.json` ("No actual StateBlock byte serializer exists at this freeze") as historical r1 task context, and discloses that while the first 3 byte tests preceded `state_encoding.rs`, the 4th hand-derived 210-byte vector (`push_saved_current_and_installed_frame`) was added after serializer source existed.
  - Both source reviews and `README.md` honestly disclose that `prepare`, `state_encode`, `state_decode`, and `state_encoding` were developed as one candidate (so `roundtrip` calls in encoder tests are not independent execution evidence) and that all 25 tests are **UNRUN**.
- **Scope Containment**: `L4-ROOT-HOST-SOURCE-ADOPTION.json` restricts adoption to `ADOPTED_WITH_LIMITS_AS_CURRENT_A_HOST_CODEC_SOURCE_INTERFACE_ONLY` (H1 internal host tooling trusting `prepare_a` output). All open obligations—`StateBlock` byte parsing, `projectA`, `ObservedRecordA`/trace materialization, hostile/refusal test modules, F3 unfolded capacity admission, F4 canonical-representative enforcement (`UNSELECTED`), P1–P6 write masks, `StepInv`, G.4 circuit components (`emitStepA`, `packStepWitnessA`), cryptographic statement/step binding, Candidate B helpers/counters, general 55-variant ADTs, financial state/phases/liabilities, and Halo2/Preview/Fenrir/stagenet proofs—remain explicitly open.

---

### 4. Manual Source-Reading Hygiene Audit
By manual line-by-line inspection of all 38 public file views, all 4 decoded gzip receipts, and both before-images (no automated scanner was written or run):
- **Secrets & Credentials**: Zero API keys, tokens, cookies, passwords, private keys, seed phrases, wallet identities, or private witness material appear in any file.
- **Private Clean / Fenrir Exposure**: Zero private Clean source or private Fenrir source, configuration, or internal endpoints appear anywhere; Clean and Fenrir are referenced solely as high-level roadmap/target constraint names in `AGENTS.md` and `extensions-and-obligations.md`.
- **Metadata Hygiene**: Local workspace paths (`/home/charl/Moriarty/...`) and provider request/response IDs in JSON receipts contain no sensitive environment variables, credentials, or private chain-of-thought.

---

### 5. Conditions Required for Source Publication
This `APPROVED_SOURCE_PUBLICATION_WITH_CONDITIONS` verdict authorizes source publication to GitHub and routine branch merge **only** under all of the following conditions:
1. **Immutable 38-File Freeze**: All 38 currently selected files must remain byte-for-byte identical to manifest `bfba0a16b4948d7b2feb450071086b614d7b73588b2184834882b5c9baa2cb2e` with `git_mode` `100644`.
2. **Exact 5-File Publication Seal Only**: Only the 5 declared seal files under `models/sherlock/machine-circuit/codec-source-review-20261016/` (`gemini-publication.md.gz`, `gemini-publication.json.gz`, `muse-publication.md.gz`, `muse-publication.json.gz`, and `publication-binding.json`) may be added:
   - Both fresh Gemini and Muse publication reviews must approve source publication.
   - Each `.md.gz` must contain the exact UTF-8 `text` of its canonical `RESULT.json` without LF or Unicode normalization, and each `.json.gz` must preserve the exact adapter receipt bytes (including actual model selection, canonical-identity limitation, effort, and terminal fields without synthesis).
   - All 4 `.gz` files must be single-member deterministic gzip streams (`mtime=0`, `flags=0`, valid CRC32/ISIZE, no trailing bytes).
   - `publication-binding.json` must record the exact full paths, SHA256 digests, byte counts, and modes of the 38 frozen files plus the 4 publication receipt files (42 entries total, no self-hash).
3. **Root Pre-Push Verification & Zero Execution**: Root must verify all 43 committed paths, hashes, modes, base/parent commit pins, and worktree cleanliness before push/merge, with zero native or test execution (`native_authority = 0`) and no claim that source publication constitutes test execution or roadmap acceptance.

PUB_PART_3_1ceb38ce00e54dc3b9b90f11ea7960bd
