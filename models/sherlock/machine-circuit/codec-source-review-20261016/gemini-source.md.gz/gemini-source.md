`APPROVED_SOURCE_WITH_LIMITS`

### Reviewer Identity and Context Completeness
- **Reviewer**: Gemini 4 Argon (High) via AGY, acting as temporary security owner under explicit user fallback following Opus `429 usage_limit_reached`.
- **Context & Candidate Scope**: Complete two-message source-only review of unchanged 16-file candidate `adad64b8cd6df628c36ae4cd312b4417eb4c054f632bab511096e89a432b43ee` (`SOURCE-GRAPH.json` `c0dd736a...`, `INTEGRATION.patch` `24a39b01...`). All 16 normative L4 specification, reference-type, and independent expectation inputs from Message 1 and all 16 candidate source files from Message 2 were received complete and retained in full without truncation.
- **Read & Execution Limitations**: Pure static source inspection only. No tools, shell, compiler, Rust/Cargo, Python, Lean, K, Quint, Midnight SDK, or native prover were invoked. All compilation and all 25 normal unit tests (`8 + 8 + 5 + 4`) are **UNRUN**. Zero execution, resource, or native admission is granted.

---

### Full Coverage Audit Against L4 Specifications and Expectations

1. **Program Preparation (`prepare.rs`, `constants.rs`, `limits.rs`, `rows.rs`, `encoding.rs`)**:
   - **Preorder & Source Paths (F1(b), G2)**: Explicit LIFO task stack assigns `ExprId`s in exact preorder (`entry` at `0` with `owner_tag = 0, function_index = 0, path = (0,0)`, followed by function bodies in source table order with `owner_tag = 1, function_index = i, path = (0,0)`). Non-`Match` children use zero-based source child positions; `Match` uses `0` for the scrutinee and `k + 1` for zero-based arm `k`. Every syntax occurrence receives a distinct `ExprId` (`child ExprId > parent ExprId`) without redirecting immutable links to earlier structurally equal nodes or following `Call` targets.
   - **Name Membership & Sorting (F1(a))**: `Names` collects only distinct strings occurring in syntax (`Function`, `Parameter`, `Var`, `Let`, `Call`, and `Pattern` binders), deduplicated and sorted in strict UTF-8 byte order while retaining duplicate parameters/binders/functions in source order.
   - **Constants & Field-Slot Timing (F1(c), G1)**: `constants::append` uses an explicit postorder stack without interning (`List` -> `UInt`/`Cons`/`Nil`; `Tree` -> `Leaf(UInt)`/`Branch(left, right)`). Contiguous `ConstantFields` slices are appended at parent completion after all children (`Task::Finish`), and fieldless nodes use `Slice::ZERO` (`(0,0)`), matching `field-slot-order-counterexample.json` and `deep-source-paths.json`.
   - **Builtin Declarations & `program_bytes()`**: Fixed A declarations (`Types = 4`, `Constructors = 4`, `ConstructorFieldTypes = 5` with `[0, 2, 0, 3, 3]`) and all 16 `ProgramHeader` columns plus 15 zero-padded tables expand in exact L4 column order using overflow-safe `count_bytes(Z)` (`max(1, 128 - Z.leading_zeros())` bits) and `id_bytes(Z)` (`count_bytes(Z.saturating_sub(1))`), with `ValueRef` index width `id(max(K, D))` and `OccurrencePaths` width `count(max(XC, A + 1))`.

2. **Canonical State Encoder (`state_encode.rs`, `state.rs`)**:
   - **Observation & Program Checks**: Enforces `caps.data == prepared.capacities.data` (`WrongRepresentation`), structural `programs_equal` via bounded non-recursive work stacks (`ProgramMismatch`, never `Arc::ptr_eq` or digest), O1 (`remaining_fuel <= initial_fuel`), O2 (`frames.len() <= stack_limit`), O3 (`Pending <=> control.is_some()`), and `stack_limit <= SL` (`Capacity`).
   - **Canonical Visit & Allocation Order**: Visits roots in exact L4 order: (1) `ControlRows` spine (`0..controlLength - 1`), visiting `Push.pendingFrame` in `Frame` source order, then `Push.environment`, before advancing to `next`, and terminal `Control` fields in source order; (2) `Root.environment`; (3) `FrameSlots` top-first (`0..depth - 1`); (4) `Outcome::Done` value.
   - **Values, Environments, and Least-Equal References**: Runtime values unfold in non-interned left-to-right postorder into `Data` (`space = true`) with parent-time `DataFields` blocks (G1) and incremental capacity reservation before expansion (F5). Each `Environment` root independently appends bindings in ascending UTF-8 name order with `parent` chaining. Held `ExprRef`, `Function`, `remainingExprSlice`, and `armSlice` select the least structurally equal prepared `ExprId`, `Function` row, or `Call`/`Match` suffix start (`OutsideProgramClosure` if absent). All 9 `Frame`, 10 `Control`, 4 `Outcome` variants, 8 `Snapshot` fields, `Option` presence bits (`function_present`, `bindings_present`, `EnvRoot.present`), 16-byte LE fuels, and all 256 `u8` error codes are preserved and zero-padded to declared capacities.

3. **Typed State Decoder in `Canonical` and `Step` Modes (`state_decode.rs`)**:
   - Validates `PROFILE`, structural `full_program`, full `ProgramBlock` equality (including inactive rows), `D` agreement, fixed vector lengths, zero padding above active counts, O1–O3, inactive outcome columns, `Push` spine structure, and unused variant columns across all active `Data`, `FrameSlots`, and `ControlRows` (including inline `pending_frame`).
   - Enforces strict acyclicity (`child.index < row` in same space, constants never referencing `Data`), constructor field types, and Opus F2 suffix membership for nonempty `remainingExprSlice` and `armSlice` in **both** `Canonical` and `Step` modes.
   - In `Canonical` mode, requires `Data` space for all state references and verifies that `encode_observed_a` on the decoded `Snapshot` reproduces the entire `StateBlock` identically.

4. **State Byte Expansion (`state_encoding.rs`) & Independent Test Alignment**:
   - `observed_state_bytes_a` encodes via `encode_observed_a` and expands `Root`, `Data`, `DataFields`, `EnvCells`, `ValueSlots`, `FrameSlots`, and `ControlRows` in exact L4 column and table order (`Root = 45B`, `DataNode = 22B`, `EnvCell = 5B`, `FrameRow = 17B`, `ControlRow = 36B` at 1-byte widths).
   - The 25 normal tests (`normal_tests.rs`, `state_encode_normal_tests.rs`, `state_decode_normal_tests.rs`, `state_encoding_normal_tests.rs`) match the hand-derived expectations in `machine-layout-independent-normal-r1` and `layout-a-state-bytes-independent-r1`/`r2`.

---

### Current-Source Defects vs. Explicit Future Obligations
- **Current-Source Blockers**: **None** within the scoped H1 `#[cfg(test)]` internal preparation, typed state codec, and `StateBlock` byte-expansion module.
- **Explicit Limits & Unresolved Future Obligations (Not Satisfied Here)**:
  - **H1 Trust Boundary**: `PreparedA` is trusted internal output of `prepare_a`; no public/untrusted byte parser, wire importer, or network consumer exists. Standard Rust `Arc`/`Box`/`BTreeMap` operations outside explicit traversal helpers retain host stack/allocation limits.
  - **Unselected / Unimplemented Roadmap Gates**: StateBlock byte parsing, boundary projection (`projectA`), `ObservedRecordA` / full trace materialization (`materializeRecordA`, `materializeTraceA`), hostile/refusal test modules, F3 unfolded capacity admission envelopes, F4 canonical-representative enforcement (bound table vs. verifier recomputation, still `UNSELECTED`), P1–P6 write masks/operation manifests, `StepInv` circuit row checks, G.4 circuit components (`emitStepA`, `packStepWitnessA`), statement/program/step-chaining cryptographic binding, Candidate B helper schedule/counters, general nominal ADTs (55-variant target), financial state/phases/liabilities, and native Halo2/Preview/stagenet proof evidence remain open under their existing owners and gates.

SOURCE_END_54e672cbb07d46c6adcd1beadac4badc
