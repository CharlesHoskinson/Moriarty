## Verdict: APPROVED_SOURCE_WITH_LIMITS

No current normal-scope blocker was found in the enclosed source. This approval is for ordinary source correctness, mappings, byte layout, and consistency with the supplied independent literal expectations only. It does not establish compilation, test execution, runtime behaviour, canonicality theorems, circuit or proof correctness, deployment, or roadmap acceptance.

### Coverage

I read all sixteen candidate files in full:

- `README.md`
- `constants.rs`
- `encoding.rs`
- `limits.rs`
- `mod.rs`
- `normal_tests.rs`
- `prepare.rs`
- `rows.rs`
- `state.rs`
- `state_decode.rs`
- `state_decode_normal_tests.rs`
- `state_encode.rs`
- `state_encode_normal_tests.rs`
- `state_encoding.rs`
- `state_encoding_normal_tests.rs`
- `crates/mori-core/src/sherlock/mod.rs`

I also read the supplied L4 `design.md`, `interfaces.md`, `crosswalk.json`, `extensions-and-obligations.md`, and owner-repair provenance in full; the actual `reference_types.rs`; the independent preparation/field-slot/deep-path expectations; the r1 and r2 byte-expectation packets; the byte-provenance qualification; the source graph; and the integration patch. No tools, commands, file edits, web access, delegation, compilation, or tests were used, as instructed. All 25 tests, compilation, formatting, Cargo, SDK, Lean, K, Quint, and native checks remain UNRUN and unauthorised.

### Preparation

`prepare_a` retains the complete `Arc<Program>`, prepares the entry and every function body in source order, and assigns distinct preorder occurrences even to shared `Arc` expressions. Immutable occurrence children, arms, function bodies, and the entry retain their own prepared positions; they are not redirected to earlier equal occurrences.

Names are deduplicated only in the sorted Names table, using exact UTF-8 byte order, while duplicate functions, parameters, binders, and syntax occurrences remain in source positions. Root paths are `(0,0)`, Entry `functionIndex` is zero, non-Match child positions are zero-based, and Match arms use `k+1` after scrutinee position zero.

Constants and Data use left-to-right postorder without interning. In both `constants::append` and the state encoder's value construction, a parent's contiguous field-reference block is appended when that parent node is appended, after its children have produced their own field blocks. Fieldless nodes retain `(0,0)`. Four Types, four Constructors, and five ConstructorFieldTypes are always emitted.

Explicit stacks and reservations precede traversal expansion. Capacity and host-representability refusals are kept distinct from semantic outcomes. No `Default` capacities are introduced.

### Canonical encoder and typed decoder

`encode_observed_a` explicitly maps all nine Frame forms, ten Control forms, four Outcome forms, and all eight Snapshot fields. Its canonical traversal visits the control spine first, each pending Push frame before that Push's environment, then the terminal control row, the current environment, installed frames top-first, and finally the Done value. Each environment occurrence independently appends values followed by its sorted binding cells, so current, saved, pending, and installed-frame environments are not accidentally shared.

Held expressions and functions are selected by least structurally equal prepared position. Remaining-expression and arm slices select the least-start equal suffix and encode empty slices as `(0,0)`. Function row zero remains distinguishable as a present function through `function_present`; successful empty bindings remain distinct from absent bindings through `bindings_present`; absent `EnvRoot` values remain distinct from successful values; `primitive_is_ok` separates Ok values from every `u8` error payload; and exact fuel, Rejected error bytes, and stack limit are retained separately.

The decoder checks profile, complete structural Program equality, the supplied complete ProgramBlock, fixed vector lengths, active rows, zero padding, constructor fields, references, environments, source suffixes in both Canonical and Step modes, spine shape, D agreement, and the O1–O3 observation distinctions. Canonical mode calls the real encoder and compares the complete resulting `StateBlock`; Step mode performs the specified checks without that final canonical equality. There is no success stub, callback substitution, pointer-identity acceptance, or decoder call inside the encoder.

### State byte expansion

`state_encoding::observed_state_bytes_a` first calls the real `encode_observed_a` and then privately expands the resulting padded `StateBlock`. The raw-block helper itself is not exposed.

The Root, Data, DataFields, EnvCells, ValueSlots, FrameSlots, and ControlRows use the listed L4 column order, recursively expand inline pending frames, include inactive fixed-capacity rows, and remain row-major. Id, count, start, and slice widths derive from their own capacities. ValueRef uses `max(K,D)`, EnvRoot uses E, stack limit uses SL independently of frame capacity S, UInt128 and both fuel fields occupy exactly sixteen little-endian bytes, and Bool/enum/`u8` lanes occupy one byte at these lane widths.

By static byte accounting against the independently supplied vectors, the four complete examples reconcile to **81, 67, 82, and 210 bytes** respectively at their own dimensions, including the two-byte count representation for stack limit 256 and the distinct saved/current/installed environments in the 210-byte example. These are hand-reconciled source expectations, not executed test results.

### Defects, correlations, and limits

**Current blockers:** none found within this normal source-review scope.

**Correlation limits:** preparation, encoder, decoder, and byte-expansion sources form one internally consistent candidate and were partly developed against one another. Decoder round-trip evidence in the encoder tests therefore is not independent execution evidence. The decoder tests use hand-authored images, and the four byte tests use independently hand-derived literal vectors. The first three byte-test sources preceded the serializer; the fourth was supplied after serializer source existed. The provenance correction properly qualifies the inherited r1 statement about serializer absence: it described the original r1 context and does not prove absence at the later r2 freeze.

**Future obligations, not current source blockers:** StateBlock byte parsing, reviewed boundary projection, complete record/trace materialization and comparison, hostile/refusal tests, F4's physical representative mechanism, P1–P6, StepInv, G4, B/general-ADT support, and all financial, native, Midnight, and stagenet obligations remain open.

The H1 boundary is limited to trusted internal `PreparedA` values produced by preparation. No promise is made for arbitrary mutated prepared objects, untrusted network input, or a public byte importer. Host `Clone`/`Drop` behaviour and allocation limits for deeply nested host values remain outside this approval.

Security judgments reserved to the temporary Gemini owner were not made here.