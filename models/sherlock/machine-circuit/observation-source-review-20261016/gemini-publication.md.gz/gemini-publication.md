### Verdict: `APPROVED_SOURCE_PUBLICATION_WITH_CONDITIONS`

- **Base Commit**: `cd2c086fcda55c2f5e434242b5d5a69cc4aa3f80`
- **Source Commit**: `8539013ce2ab7d0be0a954ca22916ed93c8dca2d`
- **Candidate Manifest SHA256**: `319a6e952761a1a17ce4b098d186b07438735b6eac540f68e6342e60df80c491`
- **Complete 18-Source Manifest SHA256**: `3e6a3773429db8dad043be098b6a5968036a388e7979579452e2639201a994fd`
- **Reviewer Identity & Role**: Gemini 4 Argon (High) via AGY — Designated Temporary Security Owner during verified Opus 429 outage (Muse Wonder 1.0 High is independent normal auditor).
- **Execution & Authority Scope**: Source-only publication review. Zero tools, commands, workspace accesses, writes, compilers, or tests were invoked. Manual reading hygiene only; no automated scanner is claimed. `native_authority = 0`; all historical SDK/Lean caps and terminal records remain unchanged. Compilation and all 29 normal unit tests are `UNRUN`. The user authorizes routine reviewed GitHub publication/merge; this model review does not itself grant execution authority, runtime classification, Root admission, user grants, or circuit/proof/ledger/stagenet acceptance.

---

### 1. Path, Hash, and Diff Provenance (11 Candidate Paths & 18-File Source Graph)

All 11 publication candidate paths on base `cd2c086fcda55c2f5e434242b5d5a69cc4aa3f80` (at source commit `8539013ce2ab7d0be0a954ca22916ed93c8dca2d`) and all 18 current source files supplied across Messages 1–3 were retained and cross-checked against `SOURCE-FREEZE.json` (`666a1d4c6e2a27e555d6fb01e94a388547e3f369593dd2252c120e83e43aa724`, `7997` bytes, mode `100644`):

1. **Unchanged 14 Source Files**: `constants.rs` (`90327d34...`, `3390` B), `encoding.rs` (`b9e136e7...`, `4317` B), `limits.rs` (`cb13fa79...`, `2619` B), `normal_tests.rs` (`74924527...`, `10079` B), `prepare.rs` (`14630c8f...`, `12555` B), `rows.rs` (`92aaa3d4...`, `3893` B), `state.rs` (`624505f4...`, `5861` B), `state_decode.rs` (`c88cae69...`, `30021` B), `state_decode_normal_tests.rs` (`5fec70c4...`, `11034` B), `state_encode.rs` (`a29533a8...`, `18674` B), `state_encode_normal_tests.rs` (`fd1f37be...`, `8890` B), `state_encoding.rs` (`556e4fe6...`, `7160` B), `state_encoding_normal_tests.rs` (`0b0bd640...`, `6012` B), and `crates/mori-core/src/sherlock/mod.rs` (`d0eb44ee...`, `1647` B) match `SOURCE-FREEZE.json` in exact path, SHA256, and byte count.
2. **Four Source Changes**:
   - `crates/mori-core/src/sherlock/layout_a/README.md`: `94a727b62d6eb9bc2aa6c898c016b8000379faeae86425e161acc6b497f08660` $\to$ `5b7b03e9bda03ef2d9763e9d6dea46c692092ccd0246064a66fb7ce72ad00d90` (`11379` B, `100644`). Updates the unrun normal test count from 25 to 29, documents `observation::project_a`, `ObservedRecordA`, `materialize_record_a`, `materialize_trace_a`, and `compare_a`, and preserves all H1/F3/F4/P1–P6/G4/roadmap disclaimers.
   - `crates/mori-core/src/sherlock/layout_a/mod.rs`: `0a16c2eca6ba781755ed77b086a5014933405453cff3aa574c7bc7659eaf52bb` $\to$ `84b86b2ca89626b429f078226fc2caec158a48c597a41a39f8d340132f7dbea7` (`627` B, `100644`). Adds private `mod observation;` and `#[cfg(test)] mod observation_normal_tests;`.
   - `crates/mori-core/src/sherlock/layout_a/observation.rs`: `ABSENT` $\to$ `959e8121783c6b72c84f527ea271a0326975de182797aec905ffddf8840ff3fe` (`8028` B, `100644`). Implements `ObservationProgramA`, `RecordEnvelopeA::rule_tag` (exact 39 `(rule_start_line, charge)` tuples matching `crosswalk.json::rule_line_tags`, keeping host source lines distinct from `0..39` wire enum tags), `project_a` (Step decode then canonical encode), `materialize_record_a` (Step decode on both sides plus O4 checks), `materialize_trace_a` (incremental `try_reserve(1)`, empty slice preserved as a present zero-step trace, unauthenticated `TraceIdentity` metadata), and `compare_a` (`compare::first_difference`).
   - `crates/mori-core/src/sherlock/layout_a/observation_normal_tests.rs`: `ABSENT` $\to$ `c13aae58e278cd1e1c37d6f0313c6b9c5a54cfad37ef9b2dc016ce212f3e10bb` (`7841` B, `100644`). Adds 4 `UNRUN` normal tests matching independent literal expectations.
3. **Seven Review & Freeze Additions under `models/sherlock/machine-circuit/observation-source-review-20261016/`**:
   - `README.md` (`2d16008a5069ae2a7914ea53163fbb60868fdc855d7a6a253d661a953345ed5a`, `2310` B, `100644`)
   - `SOURCE-FREEZE.json` (`666a1d4c6e2a27e555d6fb01e94a388547e3f369593dd2252c120e83e43aa724`, `7997` B, `100644`)
   - `independent-observation-expectations.json` (`eaa130f576671ded8af488ebdb4a2d0e2eca4540e2873e6cbb1df17bff0a8c9b`, `7267` B, `100644`)
   - `gemini-source.json.gz` (`19dc623dc06ec1fa89d210ab3e41d9b906e081db61fd5c490d39bf884505a92b`, `5598` B, `100644`)
   - `gemini-source.md.gz` (`e3aec9fc87ae124c93ac7ec0eaee12ac598429e1435a7682cfc4c971ffa564bc`, `5091` B, `100644`)
   - `muse-source.json.gz` (`480edbe380462f03716a60438b2ab2561c8618af42b397b8d88d1dd8bee1a7f3`, `2895` B, `100644`)
   - `muse-source.md.gz` (`ee934ac3e79857ab8453e96978ccbf8a214c4959f2c38315ff605377ce9b1e4f`, `2649` B, `100644`)

---

### 2. Gzip Receipt Provenance, Expectations, Boundary, and Hygiene Checks

- **Gzip Decoded Receipts vs. Hashes**:
  - `gemini-source.json.gz` decodes to `69f20c20d03a4d259f502a224ba03b0f69df41238cfb217a77b807cf2b373a46` (`18376` B) and `gemini-source.md.gz` decodes to `303c35fb7d896ffda6cbdaa913ed2ecb4d1ea4d843c0ee4e52f2e7075c31022f` (`17281` B). The `.md.gz` payload is the exact UTF-8 `.text` of `RESULT.json` without normalization, recording `APPROVED_SOURCE_WITH_LIMITS` on manifest `3e6a3773429db8dad043be098b6a5968036a388e7979579452e2639201a994fd` with `selected_model_from_init = "gemini-4-argon-high"` and `separate_canonical_model_id = "NOT_REPORTED"`.
  - `muse-source.json.gz` decodes to `b5c37f2d3b585ec82b895023bdbcb1dba4d057ad7d69f9ced1461e0be54a26ea` (`6184` B) and `muse-source.md.gz` decodes to `d304ece00d6686fca6dc4de07935ae13c62e5aa002cef7c4f6db9351bae30cf3` (`5695` B). The `.md.gz` payload is the exact UTF-8 `.text` of `RESULT.json` without normalization, recording `APPROVED_SOURCE_WITH_LIMITS` on `3e6a3773429db8dad043be098b6a5968036a388e7979579452e2639201a994fd` by `muse-wonder-1.0` (`terminal: "completed"`).
- **Production Consumer Boundary (`#[cfg(test)]`)**: `crates/mori-core/src/sherlock/mod.rs` gates `mod layout_a;` under `#[cfg(test)]`. Within `layout_a/mod.rs`, `observation` is private (`pub(super)` items only) and `observation_normal_tests` is gated under `#[cfg(test)]`. No production, runtime, network, or native consumer is exposed.
- **Independent Expectation & Old Receipt Scope**: `independent-observation-expectations.json` is hand-derived (`INDEPENDENT_HAND_DERIVED_SOURCE_EXPECTATIONS_ALL_ACTUAL_UNRUN`), free of evaluator or candidate execution. The normative L4 adoption record (`layout_manifest_sha256: 91d8bd43ac4ce41f0d9a89127e9f39865a53b153216f6424fb10e7a3ad91af88`) and sibling `codec-source-review-20261016/` receipts remain unchanged and strictly scoped to their prior artifacts.
- **Manual Reading Hygiene**: Manual inspection of all 11 candidate files and 14 unchanged source files found no credentials, private keys, tokens, private witness data, unredacted environments, private Clean/Fenrir content, or chain-of-thought material.

---

### 3. Conditions for Future Seal (Strictly Bounded 16-File Final Tree)

This publication approval covers **only** the exact 11 candidate files above plus the following single post-review sealing step in `models/sherlock/machine-circuit/observation-source-review-20261016/`:

1. **Four Publication Receipt Gzips**: Append `gemini-publication.md.gz`, `gemini-publication.json.gz`, `muse-publication.md.gz`, and `muse-publication.json.gz` in `models/sherlock/machine-circuit/observation-source-review-20261016/`. Each `.md.gz` must compress the exact canonical `RESULT.json` `.text` UTF-8 bytes without LF or Unicode normalization; each `.json.gz` must compress the original exact adapter JSON bytes. Each gzip file must contain a single gzip member with `mtime = 0`, valid CRC32 and ISIZE, and no trailing data.
2. **Publication Binding Manifest**: Append `models/sherlock/machine-circuit/observation-source-review-20261016/publication-binding.json` listing the exact initial 11 candidate files plus the 4 publication receipt `.gz` files (15 entries total) with their exact paths, SHA256 hashes, byte counts, and git modes (`100644`), with no self-hash.
3. **No Other Changes**: No other source, documentation, or repository file changes may occur after this review. Root will verify the exact seal and complete 16-file final tree before publication.

OBSERVATION_PUBLICATION_END_f1aba0655389f095828bcfce40231e85
