# Final exact publication review: G2 row-fetch source, concepts 000–002, review and provenance archives

Reviewer: Claude Opus 5.5 (`claude-opus-5-5`), high effort. I read only the supplied packet and executed nothing. I did not recompute any SHA256 or gzip digest; every digest equality below compares hashes recorded in the packet. Native authority is 0. All earlier caps, counters and terminal failures are unchanged.

## Disposition

**Commit, push, PR and regular merge of the exact 26 paths: APPROVED WITH CONDITIONS.** The conditions are the predicates in the predicates section below.

**Receipt-only seal: APPROVED CONDITIONALLY** for the contract shape described in the seal section. This does not approve any seal bytes, because I have not seen them.

**Real blockers: none found.** Five provenance disclosure gaps exist, listed as P1–P5 below. None needs a byte change in the 26 if this receipt is part of the seal, because it discloses them in the repository.

**What this approves.** Only publication: placing these bytes on GitHub as an unregistered, UNRUN source snapshot with historical concept notes and evidence archives.

**What this does not approve:**
- source acceptance beyond the existing scoped G2 verdicts;
- SDK, native, model, proof or target acceptance;
- registration of the module;
- adoption of the L layout;
- the enabled-fetch requirements;
- any website or design adoption.

## Package integrity

**Inventory.** The packet lists exactly 26 paths:
- 6 source and data files;
- 8 files under `source-review/` (7 gzip archives and a README);
- `wiki-llm/README.md`;
- 11 atlas files: `AUTHORSHIP.json`, three notes, the atlas README and 6 provenance gzip files.

**G2 source identity.** The six source and data digests match all of these:
- the R2 manifest `outputs`;
- the Opus R2 and Muse R2 reviewed bytes, under freeze `ccc0eaa0…`;
- the iteration-002 source snapshot;
- the AUTHORSHIP 002 pins.

The source is therefore the previously reviewed G2 bytes. I re-read it rather than relying on the old verdicts, and found no new defect.

**Context unchanged.** The publication base is `51db2f85`; the review base was `1fb794d1`. Six context files have identical digests at both:
- `AGENTS.md`
- `Cargo.toml`
- `Cargo.lock`
- `mori-backend/Cargo.toml`
- `mori-backend/src/lib.rs`
- `mori-core/src/ir.rs`

**Not compiled.** The `lib.rs` module list (`authorization`, `replay`, `schnorr`, `signed_relation`, `stage`, `source_projection`, `liabilities`, `parameters`, `proving`) does not declare `sherlock_machine`. Cargo therefore never compiles these files. The `include_str!` in `normal_tests.rs` and all six tests stay inert. `wiki-llm` is excluded from the workspace.

**Two open typecheck items from Opus R2 are now answerable from source:**
- `mori_core::UInt` is re-exported, because `mori-core/src/lib.rs` contains `pub use ir::*` and `ir.rs` declares `pub struct UInt`.
- The workspace edition is 2024, which supports array `into_iter`.

Both are source observations, not compilation results.

**Hand counts in note 002, re-derived from source.**
- 22 named outputs: 8 inputs and 14 temporaries.
- Temporary order: temp.0 and temp.1 are comparators; temp.2 to temp.7 alternate selector and sum; temp.8 to temp.13 are the two lanes.
- 57 instructions in total:
  - public frame: 24 (8 × 3);
  - fragment: 32, made up of ranges 8, guards 6, decoder 10 and lanes 8;
  - `Output`: 1.

All are correct.

**Link targets.** The relative links resolve correctly:
- `../../` from the atlas folder reaches the repository root;
- `../../../../` from `source-review/README.md` reaches the repository root;
- the `include_str!` path `../../../../models/…` from `src/sherlock_machine/` is correct.

## Historical versus current status

**Freeze-time statements are covered.** Notes 001 and 002 say "not on `main`" and "not in the repository". Those statements become false after merge. Both READMEs now say that note statements describe freeze time. That disclosure is adequate for the notes, and the notes stay verbatim.

**Note bytes are unchanged.**
- Notes 000 and 001 have the same digests as the files embedded in their retained replies.
- I read note 002 against the embedded escaped content in the 002 reply and it is identical. I did not hash it.
- Root's README edit is limited to provenance: the 002 reply link and the freeze-time paragraph. This matches the declared integration scope, and the original Opus README is retained inside the 002 reply.

**Archived text is history, not current code.** The r1 G0/G1 source inside the 000 and 001 snapshots, including the unprefixed r1 identifiers and the `sherlock_step` text, is archived text. No module path, registration or acceptance is claimed for it. The atlas index status for 000 ("not on `main`") stays true for the module path after merge.

**Current status claims are truthful:**
- G2 is unregistered, its six tests are UNRUN, and it has no SDK execution.
- G.4 gaps remain open, and the transcript adapter is absent.
- Muse found G2 acceptable within its normal scope.
- Opus returned ADOPTABLE_WITH_LIMITS on security source reading only.
- Neither verdict closes a roadmap gate.

"Repaired in G2" should be read as repaired by source reading. The README's opening UNRUN sentence scopes it correctly.

**Minor staleness (not blocking).** The AUTHORSHIP 002 `review_scope` reads "concept note fresh normal review/publication pending". AUTHORSHIP is a provenance record, not a note, so the freeze-time clarification does not obviously cover it.
- This receipt records that the field describes the pre-publication freeze.
- These final reviews are the only review of concept note 002 beyond its source grounding.

## Provenance and identity findings

**P1: two copies of the r2 Opus reply differ by one byte.** The R2-OPUS receipt text (`ff138834…`) and the iteration-002 reply archive (`ffc78423…`, which AUTHORSHIP records as `original_reply_sha256`) differ by exactly one trailing LF. The archive copy has it.

Muse R2 shows the same pattern: the `.md` copy (`0dfad340…`) adds a trailing LF to the json `text` (`99bf5919…`).
- The packet does not establish which bytes are provider-exact.
- I also cannot tell whether the 000 and 001 "original reply" archives are raw provider output or JSON payloads Root extracted from it. They decode to structured `{files, next_iteration_brief}` objects, while 002 is fenced raw text.
- Content is otherwise identical.

Treat the "original" reply hashes as Root-recorded captures, not provider-signed bytes.

**P2: R1 identities rest on Root labels.** The R1 `RESULT.json` receipts (`b1d046f4…`, `6ebbb2f6…`), which hold the R1 model usage, are listed in the R2 manifest but not published. The `R1-MUSE` and `R1-OPUS` names are Root labels.

For R2, raw usage is published: Muse `muse-wonder-1.0` with its request and response IDs, and Opus with a returned `canonicalModel` of `claude-opus-5-5`. For the 000 and 001 notes, identity is Root-recorded only. For 002, the published R2-OPUS usage record covers the same call.

**P3: some referenced bytes are unpublished.** R2 `SOURCE.patch` (`9e3e1d9a…`) and `STATIC-CHECKS.json` (`d440bc46…`) are cited but not published.
- The r1→r2 diff can be reconstructed from the 001 snapshot (r1 bytes) and the G2 bytes.
- The static checks cannot be verified by a reader.
- Iteration 000's missing source base is disclosed as null. The concept checkout base is correctly labelled as not a source base.

**P4: the R1 archives contain more than G.** They also hold the L layout verdicts (Muse ADOPTABLE_WITH_LIMITS, Opus CHANGES_REQUIRED) and the V concept verdicts. The source-review README describes the multiple scopes inside R2-OPUS but not inside the R1 archives.
- This receipt records that publishing those archives does not adopt L.
- The L bytes are not part of this publication.
- Muse's suggestion that its L verdict "can serve as" a vote is history, not a current vote.

**P5: local paths are exposed.** `R2-SOURCE-MANIFEST` contains absolute local paths under `/home/charl/…`, which reveal a username and directory layout. The README discloses that receipt paths describe their captured context. This is an accepted, disclosed exposure, not a secret.

## Private content

By reading, I found none of the following:
- private Fenrir or Clean source;
- witness data;
- credentials;
- CLI debug output;
- thinking content.

R2-OPUS contains only a `thinkingTokens` count and cost metadata. Mentions of "Clean" refer to public interface inventories, and "private" draft modules are `cfg(test)` host modules.

**Unobserved: gzip headers.** The packet gives decoded contents only, so I could not check gzip header fields (FNAME, FCOMMENT, FEXTRA, MTIME) or trailing members. Any of these could carry a local filename or path. This is covered by prepush predicate 4.

## Automation boundary

**`site.yml` (4200e65f…)**
- It triggers on push to `main` or on PR, but only for `site/**` and `.github/workflows/site.yml`.
- None of the 26 paths, nor the proposed seal paths, match.
- Its deploy job runs only on `main` non-PR events whose paths match.
- It runs no cargo, SDK or native step.

**Stale API `rust` workflow (`.github/workflows/rust.yml`)**
- GitHub reads workflow definitions from the event's commit. A PR uses the merge ref of head and base.
- Because the file is absent at the base and in the candidate, no definition exists to run.
- That changes if `main` gains `rust.yml` before the PR merge ref is computed. A merge ref then inherits it.
- Such a run would not compile `sherlock_machine`, because it is unregistered. It could still run existing workspace tests, including `proving`. That would be native execution outside this authorization, so predicate 1 guards against it.

**Not observed:**
- GitHub Apps;
- rulesets and required checks;
- GitHub-managed dynamic workflows that have no file in `.github/`, such as code-scanning default setup, Dependabot or Copilot agents;
- local git hooks;
- future automation.

I make no claim about future absence.

## Predicates

### Prepush (local, before any outward action)

1. **Base unchanged.** `origin/main` equals `51db2f85`. If it has moved, `51db2f85..origin/main` must touch none of:
   - the 26 paths or their directories;
   - `crates/mori-backend/src/lib.rs` and `crates/mori-core/src/lib.rs`;
   - `ir.rs`, both `Cargo.toml` files and `Cargo.lock`;
   - `AGENTS.md`;
   - anything under `.github/`.

   Otherwise, re-review against the new base.
2. **Exact diff.** The commit's tree diff against its base has exactly the 26 paths. Requirements:
   - no deletions, renames, mode changes, symlinks, submodules or LFS pointers;
   - all modes 100644;
   - every blob's SHA256 equals the manifest value.

   If `wiki-llm/README.md` already exists on the base, its diff must be only the atlas navigation row. Treat any other pre-existing path with changes as unreviewed.
3. **Archive contents.** Each `.gz` file decompresses to exactly its declared decoded SHA256, as a single member with no trailing data.
4. **Gzip headers.** No gzip header contains FNAME, FCOMMENT or FEXTRA content that reveals anything beyond the P5 disclosure. Record each MTIME.
5. **Workflows.** The commit's `.github/workflows/` contains only `site.yml` (`4200e65f…`). `lib.rs` still has `068307ea…`, with no `sherlock_machine` or `sherlock_step` declaration.
6. **Hooks.** No local commit or push hook runs cargo, SDK, model or native commands. If one would, disable it for this push or report it before pushing.
7. **Commit message and PR body.** They restate scope: unregistered, six tests UNRUN, no SDK/native/target result, no L adoption. They contain no email or local secrets.

### PR and regular merge

8. **Head SHA.** The PR head SHA equals the reviewed commit, or the reviewed commit plus the seal commit described in the seal section.
9. **Base.** The PR base is `main`, and predicate 1 still holds at merge time.
10. **Check runs.**
    - Expected: no workflow runs from repository files for this PR.
    - Any run that does appear (from an App, a dynamic workflow or anything else) is recorded with its name, ID and conclusion. It is not cited as acceptance.
    - If a required check exists that only a Rust workflow could satisfy, do not merge by adding a workflow or bypassing protection. That is a separate decision.
11. **Merge method.** Use a merge commit (regular merge). Do not squash or rebase. Merge only without conflicts.

### Postpush and postmerge

12. **Remote branch.** The remote branch tip equals the local SHA. The GitHub tree listing for the 26 paths, or the 31 sealed paths, matches the recorded hashes.
13. **Main after merge.**
    - The merge commit on `main` has the reviewed head as its second parent.
    - The paths at `main` are byte-identical to the reviewed bytes.
    - `lib.rs` is unchanged.
    - `.github/workflows/` is unchanged.
14. **Runs after merge.** Record every run observed on the `main` push. None is expected from `site.yml` because no path matches. Record "observed none" only if that was actually checked, with a timestamp. Nothing here supports a claim about future automation.
15. **Next steps stay separately gated.** Any later registration, test, SDK load or check, comparison against the fixture, or byte change needs its own admission or a fresh applicable review. Published status does not turn UNRUN into a result.

## Seal contract

**The proposed seal is valid as a receipt-only extension:**
- 4 deterministic gzip receipts (md and json for each of the two final reviews);
- 1 Root binding that maps the digest entries for the current 26 plus the 4 receipts (30 entries);
- the binding excludes itself;
- a separate runtime manifest outside the repository hashes all 31 files.

This avoids self-hashing. Git's tree also binds all 31 blobs.

**Conditions:**

- **S1: both reviews clear.** Both final reviews return a disposition that requires no changes to the 26. If either requires byte changes, nothing is sealed or pushed, and the changed bytes get a fresh review.
- **S2: deterministic receipts.**
  - Each receipt is deterministic gzip: MTIME 0, no FNAME or FCOMMENT, a fixed level, a single member.
  - Its decoded bytes are exactly the returned text, or the returned JSON receipt, with no edits.
  - Any LF normalization is either avoided or stated in the binding, so P1 does not recur.
  - The JSON receipts carry requested and returned model identity, effort and usage counts only. They contain no thinking text, debug output or email.
- **S3: binding content.** The binding contains, for each of the 30 entries:
  - the path;
  - the stored SHA256 and byte count;
  - for gzip files, the decoded SHA256.

  It also identifies the publication base and the review freeze. It contains no new status, verdict or CI-outcome claims, and nothing about future bytes or runs it did not observe.
- **S4: placement.** The 5 new files sit under `models/sherlock/machine-circuit/source-review/`, or another path outside `site/`, `.github/` and `crates/`. No README or index is edited to link them. Such an edit would add a 32nd changed path and need fresh review. Discoverability through file naming alone is acceptable.
- **S5: one exact tree.** The seal goes into the same PR, as a commit on top of the reviewed commit, before merge. The merged tree equals the base plus exactly 31 paths. A separate follow-up PR is also acceptable if it adds only those 5 paths and applies predicates 1–15 to them.
- **S6: what this review covers.** This review does not observe the seal bytes, the other final review or the runtime manifest. The binding must not cite this review as having seen them.

## Limits

These are not observed:
- my recomputation of any digest;
- gzip headers;
- current `origin/main`;
- branch protection or rulesets;
- Apps and dynamic workflows;
- local hooks;
- the other final review;
- the seal bytes.

Source, SDK, native, model, proof and target acceptance remain separate and open. The G.4 gaps and the missing transcript adapter persist. Any substantive source change requires a fresh applicable review.