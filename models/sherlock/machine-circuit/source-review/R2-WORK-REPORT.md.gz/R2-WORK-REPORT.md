# Row-fetch iteration r2: identifier repair and constructor assertions

Status: REPAIRED SOURCE FROZEN; UNREGISTERED; ALL EXECUTABLE VALIDATION UNRUN.

This source revision implements G-D1 from the completed exact-candidate Opus
and Muse r1 reviews. Both original reviews and the r1 packet remain immutable
history; neither review is reused as approval of these changed bytes. Root must
obtain fresh applicable review. Astra high remains the explicitly requested
implementation identity. Security design and the two rejection-test requirements
remain attributable to Opus's G-D1(b,c), not to this implementation author.

## Root cause confirmed at the actual consumer, by source reading

crates/mori-backend/src/lib.rs serializes IrSource with serde_json::to_value,
changes only the version header to 3.0, serializes the JSON and calls IrSource::load.
It contains no variable-name normalization in that path. The pinned SDK ir.rs
Operand serializer emits Identifier.0 verbatim; its operand deserializer rejects
variable strings without a leading percent sign. Therefore the r1 generated
names were inconsistent with this stated consumer contract. This is a confirmed
source-contract mismatch, not an observed SDK run or a new execution failure.

## Exact implementation

- Standalone public-input names now use `%row_fetch.input.{position}`.
- Fresh fragment names now use `%{scope}.temp.{serial}`.
- Caller Variable operands without `%` return UnprefixedVariable before emission.
- Collision detection reserves the final `%{scope}.temp.` prefix, including the
  prefix required by the downstream operand representation.
- The composer must reserve distinct nonoverlapping final prefixes across
  fragments and enclosing definitions. Equal or nested prefixes are disallowed
  by that documented contract. No global namespace registry was introduced.

The emitted fetch instruction body after Builder initialization is byte-identical
to r1. The standalone wrapper body is byte-identical apart from its identifier
prefix. pack_witness is unchanged. Capacity comparisons, selectors, summation,
CondSelect chains, scalar widths, input/output order and preserved aliases are
not changed. These are textual change facts, not security or semantic proof
claims. The independent normal fixture remains byte-identical at SHA256
1c0319aa6c447599eadbfb2020a60d66effc01001282470429d610e3d5867ee7.

## Authored tests; none executed

The four normal construction tests remain, with strengthened assertions:
- exact generated `%` input/temporary names;
- every TestEq compares the index to its exact row immediate;
- both Add operands chain selectors from zero and the final sum equals one;
- every CondSelect bit uses its row selector, a uses the supplied cell, b uses
  the preceding accumulator (zero first), and each output uses the final chain;
- the exceeds-capacity comparator is constrained equal to zero.

A separate identifier_rejection_tests.rs contains exactly the two rejection
prescriptions from Opus G-D1: unprefixed caller-variable rejection and final
reserved-namespace collision rejection. Each covers count, index and a row cell.
No new negative construction-policy suite or independently designed security
cases were added. These six Rust tests are source only and are UNRUN. No SDK
load/check/evaluation or circuit-acceptance assertion was replaced by a host test.

## G.4 remains open before machine reuse

No enable/guard was added; prefix and one-hot constraints remain unconditional.
No Bits(w)/byte/enum width or multi-byte ID reconstitution was added. No canonical
padding constraints, composition-wide namespace allocator, or machine public/
private/constant/statement-binding policy was added. These remain the six G.4
component/interface gaps (namespace contract documented; global enforcement
still external). pack_witness still only orders scalars and supplies no actual
SDK preimage/transcript adapter. The module is not declared machine-ready.

The full A layout proposal L is unchanged and remains under its separate reviews.
No layout/schema adoption, shared lib registration, CLI/config change, old
sherlock_step edit, native grant, resource change, counter reset or retry occurs.
All old failures, gates and limits remain in force.

## Actual verification and frozen deliverables

The required develop status was read. Ordinary text/metadata checks verified
prefix literals and the new validation location, the unchanged relation-emission
body and witness packer, exact fixture identity, six authored test functions,
whitespace/newlines, absence of execution calls in the Rust source, and unchanged
L candidate/r1 report pins. These checks are not a parser, compiler, test runner,
SDK validator, model execution or proof. No Rust/Cargo/rustc/rustfmt/Lean/Lake/K/
Quint/SDK/model/degree/k/native/proof/key/payload/ledger action was run. No other
agent/model was invoked. No commit or push was performed.

SOURCE-MANIFEST.json pins the exact base, dependencies, both audits, six current
source/data files and their complete frozen source/ copies. before/ contains
exact pre-edit G bytes. SOURCE.patch is the exact r1-to-r2 change, including the
new rejection-test file. STATIC-CHECKS.json records only the checks actually
performed. The row and temporary dataflow is otherwise the previous iteration;
new visual concept iteration002 may describe the corrected serialized names and
new source assertions while keeping Actual: UNRUN.

The next falsifiable executable checks remain: Rust typechecking against pinned
dependencies, all six source tests, actual SDK serialized load/check/evaluation,
and whole-output comparison against the unchanged independent normal data.
Every such execution still requires its own authorization/admission. This packet
contains no command dispatch, runner or execution grant.
