# Independent exact-candidate review: G (row-fetch source) and L (A layout proposal)

**Scope.** I reviewed by reading only. I read the frozen G and L bytes under freeze `ff8dc257…`, the supplied public A sources (`reference_types.rs`, `reference.rs`, `reference_display.rs`, `compare.rs`), the private drafts, Candidate B `interfaces.md`/`requirements.md`/`spec.md`, and the pinned SDK `ir.rs`/`ir_types.rs`. Nothing was compiled, loaded, evaluated or proved.

Some inputs were not supplied, so findings that depend on them are marked as future checks:
- `lib.rs` (backend)
- `mori-core/src/ir.rs`
- zkir-v3 `lib.rs`
- `mori-backend/Cargo.toml`

The concept notes were not supplied in content and are not a security subject here. Native authority stays 0. No theorem, cost, k, degree or binding claim is made or implied. All prior caps, counters, terminal records and U/M/MC/SP/G exits are unchanged.

---

## G — source/security construction disposition

**Disposition: CHANGES_REQUIRED (narrow).**
- **Relation logic:** I predict no soundness defect in the stated scalar relation (source reading only).
- **Integration defect:** one predicted defect will make the pinned SDK's JSON load reject every emitted wrapper and every composed fragment.
- **Not adoptable yet:** as frozen, G is not adoptable as an SDK-loadable building block. Its construction approach is acceptable.

### G.1 Relation as constructed (source-read)

Given shape (N≥1, C≥1, unique nonempty names), `emit_fetch_block` emits the following:

1. `ConstrainBits(128)` on `active_rows` and `index`, and a per-kind constraint on all N·C cells.
2. `LessThan(N, active_rows, 128)` then `ConstrainToBoolean`, then `ConstrainEq(…, 0)`. This gives `active_rows ≤ N`.
3. `LessThan(index, active_rows, 128)` then Boolean, then `Assert`. This gives `index < active_rows`.
   - Both LessThan operands are range-constrained before use. This satisfies the SDK's "UB if exceeds bits" precondition.
   - The immediate N fits in 64 bits.
4. Selectors are `TestEq(index, r)` for r < N, each constrained Boolean, and their field sum is constrained to 1.
   - Since N < field modulus, the sum cannot wrap.
   - Exactly one selector is 1, which is redundant with step 3 but sound.
5. For each column there is a `CondSelect(sel_r, cell[r][c], acc)` chain starting at 0. The final value gets the column's kind constraint.
6. Temporary count is N·(C+2)+2, which matches the overflow check. The fresh names `{scope}.temp.{k}` are unique within the block.
7. The wrapper does the following:
   - Emits `PublicInput(Native, guard None)`, the range constraint and `Impact(1,[v])` for all 2+N·C inputs.
   - Appends the fragment.
   - Emits `Output` with C selected values followed by exact aliases of all inputs.
   - Declares `IrSource.outputs = Native × (C+2+N·C)`, which matches the `Output` arity.

`pack_witness` checks dimensions and kinds only. It takes no expected value. The fixture is reached only by `include_str!` in a shape test, and that path resolves to the repo root.

Statement semantics: the selected outputs are a pure function of the public inputs, and the active-prefix/index precondition makes a fetch from an empty prefix unsatisfiable. The relation stated in MAPPING.md matches the source.

### G.2 Predicted source defect at the real boundary (blocking for SDK consumption)

**G-D1: variable identifiers lack the `%` prefix required by the pinned SDK.**

The cause is in pinned `ir.rs` itself:
- `Operand`'s serde `Deserialize` rejects any variable string that does not start with `%` ("Variables must start with '%' in v3").
- `Serialize` writes `id.0` verbatim.
- `Identifier` output fields deserialize without the check, but the error is raised for every operand use.

MAPPING.md states that the backend boundary is serialize → version 3.0 → `IrSource::load`, and `load` uses `serde_json`. The emitted names fail this path:
- `row_fetch.input.{n}` and `{scope}.temp.{k}` (mod.rs `emit_public_fetch`, fetch.rs `Builder::fresh`) will both be rejected at the first `ConstrainBits { val: "row_fetch.input.0" }`.
- The test-3 caller names (`caller.count` and the others) would fail the same way once composed.

This prediction holds unless the unsupplied backend `lib.rs` rewrites identifiers during serialization. That is a one-line check for whoever holds `lib.rs`.

**Genuine repair:**
- **(a) Prefix generated names.** Generate `%row_fetch.input.{n}` and `%{scope}.temp.{k}`, and define the reserved namespace as `%{scope}.temp.`.
- **(b) Reject unprefixed caller operands.** In `emit_fetch_block`, reject caller `Operand::Variable` names lacking `%` with a new `ConstructionError` variant, alongside the existing collision check.
- **(c) Update tests.** Update test 3's operands. Add tests for the collision and unprefixed-name rejection paths.

None of this changes the relation.

### G.3 Future typecheck items (not predicted bugs; unverifiable without the unsupplied files)

- `mori_core::Type` must be `Copy`. The `column.kind`/`col.kind` moves out of `&Column` in fetch.rs and mod.rs depend on it.
- `Type` must have exactly `{UInt, Bool}` and `Value` exactly `{UInt(UInt), Bool}`, and neither may be `#[non_exhaustive]`. Otherwise `constrain` and `pack_witness` fail to compile.
- `Value::ty()` must exist.
- `Fr: From<u128>` must be implemented.
- The crate path `midnight_transient_crypto` must exist; the SDK itself uses `transient_crypto`.
- `midnight_zkir_v3::{ir, ir_types}` must be public, and the root re-exports must exist.
- `serde_json` must be available to mori-backend tests.
- After admission, SDK checks must confirm:
  - `Immediate` is accepted as a `CondSelect`/`LessThan`/`TestEq`/`Add` operand.
  - 128-bit `LessThan` is supported in-circuit.
  - The `Output`-versus-public-input semantics hold when `do_communications_commitment=false`.
  - `pack_witness` order matches the actual `ProofPreimage` transcript-output consumption. Currently the packer only orders values; it does not build a preimage.

### G.4 Required before machine reuse (interface gaps, not bugs in the stated contract)

1. **No enable/guard.**
   - **Problem:** the `Assert(index<active_rows)` and `sum==1` constraints are unconditional. In a universal step circuit, a fetch needed only by some control/frame variants is still emitted for every variant. Inactive branches carry zero indices and possibly `active_rows=0`, which makes the whole circuit unsatisfiable.
   - **Repair:** add a Boolean `enable` operand. Assert `CondSelect(enable, in_prefix, 1)`, and constrain the sum against `enable` (or CondSelect it), with a defined disabled output (e.g. 0).
2. **Lane kinds.**
   - **Problem:** L stores every bounded field as 8-bit byte lanes, plus Bool and enum lanes. G's kinds (reused `mori_core::Type`) give only a 128-bit or Boolean check, which is strictly weaker than the required 8-bit/w-bit check.
   - **Repair:** add an explicit `Bits(w)` column kind, or a documented rule that adapters perform the w-bit checks.
3. **Multi-byte ids.**
   - **Problem:** L's ids need byte→index reconstitution. This must range-check every byte and enforce `< 2^width`, so the index is unique.
   - **Note:** the reconstitution is not part of G and must be its own component.
4. **Padding.**
   - **Problem:** inactive rows are only type-checked, not zero-checked. A4/L canonicality ("inactive rows zero") therefore needs a separate component. G's "no canonical padding convention" must not be read as satisfying it.
5. **Namespace nesting.**
   - **Problem:** a scope such as `a.temp.1` lives inside scope `a`'s reserved namespace.
   - **Repair:** the composer must forbid scopes that are prefixes or extensions of each other, or G must document this.
6. **Binding.**
   - **Problem:** the wrapper's all-public `PublicInput`+`Impact` convention is a demonstration only. No public/private/commitment choice for machine state may be inherited from it (L04).

### G.5 Test coverage gaps (tests UNRUN)

Test 2 checks each `CondSelect.a` operand and the final chain output. It does not check:
- each `CondSelect.bit` operand against the selector for its row;
- the `b` accumulator chaining;
- the `TestEq` immediates;
- `ConstrainEq(exceeds, 0)`;
- `sum==1`.

A swapped-selector bug would pass. There are no negative construction tests (`RowCount`, `ColumnCount`, `CellType`, `EmptyScope`, collision, overflow). The expected-data test checks fixture provenance only; that is correctly labeled, so nothing is claimed beyond it.

---

## L — substantive consequential design vote

**Vote: CHANGES_REQUIRED.**

What I am not reopening:
- **L01 (arena layout):** acceptable.
- **L02 (top-first frames, recursive control spine, persistent env roots, byte baseline, tags and column order):** acceptable in substance.
- **B handling:** correct. B is kept as explicit normative gaps, not zeroed A cells.

What blocks: the canonical encoding (L03) has a real ambiguity, the claimed StepRecord coverage is missing an encoding, and the decode/invariant domain needed for every L04 canonicality and security obligation is unstated. Each fix is a bounded text repair to the frozen files and creates no new semantics.

### L.1 Coverage confirmed (source-read against `reference_types.rs`)

**Counts.** The crosswalk covers 55 variants:
- Tree 2, Value 4, Type 4, BinaryOp 7, UnaryOp 2, Pattern 5, Expr 8, Frame 9, Control 10, Outcome 4.

It covers 22 struct fields:
- Arm 2, Parameter 2, Function 4, Program 2, Snapshot 8, StepRecord 4.

**Per-variant columns.** I checked column use for every Frame and ControlRow variant, and no variant reuses a column. In particular:
- CaseResult keeps `bindingsPresent`/`bindings`, the value, `exprId`, `armSlice` and `environment` in distinct columns.
- PrimitiveResult uses a single `primitiveIsOk` discriminator.
- `Frame::Right` has no environment field, which matches A exactly.

**Sum and option distinctions.** These survive:
- `Option<Function>`, both `Option<Environment>` uses, `Result<Value,u8>` and `Option<Control>` (via `controlLength=0`).
- Nil, false, UInt0 and absence are all distinct.
- `Some(empty map)` is distinct from `None`.

**Values and environments.**
- Tree, List, Bool and UInt node encodings fully determine the decoded `Value`. The constructor table (Nil/Cons/Leaf/Branch, field types, 4/4/5 active rows) is consistent with A.
- The env chain with first-binding-wins decoding reproduces `BTreeMap` insert and shadow semantics for the Let return (145), `bind` and `matching`.
- Name order (UTF-8 byte-lexicographic) equals `String` order in `BTreeMap`.

**Program and reachable control.**
- Function lookup preserves first-match order.
- Suffix arm and expression slices model `arms.remove(0)` and `args[1..]`/`rest.remove(0)`.
- Machine-reachable control spines have length ≤2 (Push followed by Eval). The general C vector is a superset and is not wrong.

### L.2 Required repairs (exact location and genuine repair)

**R1 — Canonical control traversal is ambiguous** (design.md, "Canonical boundaries", sentence beginning "For state roots, visit ControlRows from root to leaf, each variant's fields in source constructor order").

The ambiguity is that `Push(Frame, Box<Control>, Environment)` has `next` before `environment` in source order. Two readings fit the text:
- row-major: visit the environment before row i+1;
- source-recursive: visit the environment after the entire tail.

The two readings produce different Data and EnvCells orders, so the canonical image is not unique. That violates A4's deterministic root order.

Repair: state explicitly, for example, "for row i: pendingFrame payload in Frame source order, then Push.environment, then row i+1; the terminal row's fields in source order." Also state the env-root expansion order: for each binding in sorted name order, the value (child-before-parent) and then its cell.

**R2 — Tie-breaks for code references are incomplete** (design.md Functions paragraph; interfaces.md "first equal source occurrence").

Functions have "least equal row", and expressions have "first equal occurrence" stated only in interfaces.md. The following have no rule:
- `armSlice` (`Frame::Match`, Cases, CaseResult);
- `remainingExprSlice`;
- `Frame.expr0`/`expr1`;
- Bound/CaseResult `exprId`.

Repair: state normatively, in design.md, that canonical encoding chooses the least ExprId, or the least slice start, among structurally equal candidates. Also state that boundary projection may therefore rewrite the runtime occurrence a reference points to, and that provenance lives only in `ExecutionOrigins` (L08).

**R3 — StepRecord event encoding is missing** (crosswalk `source_struct_fields.StepRecord` maps to `ObservedRecordA`, which has no entry in `ordered_record_columns`).

Repair: add ordered columns to `ordered_record_columns`:
- `ruleStartLine` as an enum over the finite A rule-line set in `reference.rs` (80, 82, 84, 102–131, 135, 140, 145–195, 200–225), with an explicit tag order;
- `charge` as u8, with A values {0,1} stated as a domain invariant.

Without this, the "22 fields" coverage claim is incomplete at the circuit and event boundary.

**R4 — Decoding and well-formedness domain is unstated** (design.md "Domain and parameters"; "the prepared AST graph must unfold finitely").

Make these explicit normative invariants of the representation. They are decode-domain definitions, not proofs:
- **References:** every id is below the active length of its space; every slice satisfies `start+len ≤ active`; ConstantFields carry `space=Constant`.
- **Lanes:** tags are in their listed range; byte-lane high bits are zero; Bool lanes are Boolean; inactive rows and columns are zero.
- **Typing:** node `typeId`/`ctorId` agree with `Constructors.owningType`. `fieldLength` equals the declared count, and each field node's type equals the declared field type: Cons is (UInt, List), Leaf is (UInt), Branch is (Tree, Tree).
- **Acyclicity:** replace "must unfold finitely" with checkable strict orders:
  - expression children have a greater ExprId than their parent (preorder);
  - Data and Constant children are earlier than their parent;
  - an EnvCell's parent is earlier than the cell.

Without R4, a witness node such as `Cons(Bool, Nil)` or a cyclic expression table has no defined meaning. Decoder and circuit could silently disagree, which is the misdecode risk. These are also the A4 `StepInv` row checks I own.

**R5 — Observation-domain invariants and the stuck state** (design.md Root and outcome text; interfaces.md dispatch).

State the machine-reachable invariants. A violating hand-constructed Snapshot gets a located refusal, never a coerced encoding:
- `remainingFuel ≤ initialFuel`;
- `depth ≤ stackLimit`, `depth ≤ S`, `controlLength ≤ C`;
- every non-final control row is Push and the final row is not Push;
- outcome ≠ Pending implies `controlLength=0`;
- Pending implies `controlLength>0`.

Alternatively, specify that `(Pending, None)` yields no StepRecord and therefore no accepted post-state. The dispatch table currently omits this case.

### L.3 Security conditions on any A adoption (my owned scope; obligations, not results)

- **L04 binding.**
  - The ProgramBlock must be bound to the statement, either as public data or as a committed digest with an in-circuit opening. A prover-chosen ProgramBlock must never be accepted.
  - Pre and post StateBlocks need a reviewed chaining binding so that each step's `post` equals the next step's `pre` across proofs.
  - Profile, layout and source identity must be bound into the statement.
  - None of these is selected yet. Metadata equality is not binding, and nothing is inherited from G's demonstration wrapper.
- **L04/A4 canonicality.** R1, R2 and R4 are preconditions.
  - Every value reachable from a state root must be in the Data space at the boundary. This rule should be a stated constraint, not an implication.
  - A4 hostile cases apply unchanged: inactive garbage, referenced unreachable node, foreign codeId, tag/layout mismatch, write below activeLength, and nondeterministic post-image.
  - The operation and write manifest (interfaces.md) is mandatory before any determinism claim.
- **L05 capacity separation.** When `depth = S < stackLimit`, or any arena is full, the step relation must be unsatisfiable, with tooling reporting `Capacity`. It must never accept error4, Exhausted, or another application outcome. Admission must state the semantic domain for which S ≥ SL (or the equivalent) holds. No numbers are chosen here.
- **L08 provenance.** An A adoption with origins absent is acceptable. Any provenance claim requires producer-supplied origins and reports absence as absent.
- **L09 specialization.** In the baseline the ProgramBlock is a dynamic witness. Any CTFE or specialization is a separate, separately identified decision.
- **L06/L07.** These are B-only. They are excluded from any A adoption and retained unchanged.
- **L10.** All theorem, hostile-test, native-recursion, privacy, history, ledger and target obligations are retained. UISEC-001…012 and B001–B009 remain controlling.

### L.4 B scope alignment (incremental layer test)

The A layout can serve as an aligned incremental layer, provided no narrower end state is substituted:
- **Value schema.** The node schema (type, ctor, ordered field slots) is already B's `Constructor(TypeId, CtorId, [..])` shape.
- **Scalars.** The byte scalar baseline matches the stated Clean comparison baseline.
- **Environments.** Persistent env roots support B's explicit EnvGet/EnvPut roots.
- **Arenas.** Append-only arenas, zeroed reusable slots and physical active lengths match A3/A4 vocabulary. Logical allocation counters are correctly absent from A and present in the B annex.

The following conflicts remain open, correctly. A adoption must not resolve them implicitly:
- top-first versus B bottom-to-top frames (needs an explicit adapter);
- the `PrimRight` saved-environment discrepancy;
- the `ReferenceState` values/limits/layoutVersion omissions;
- the `EnvPut` root;
- the optional-pair PrimitiveResult;
- Name versus BinderId;
- B `controlOrigin` as state rather than an observation.

The B helper, phase, resume and task rows, the counters, profile outcomes, nominal ADTs/MatchPlans, and the complete financial state, phases and await obligations remain normative open work. The annex correctly refuses to represent them as empty or zero data. An A-only adoption must explicitly exclude B execution and close no UIREQ-012…020/027…035, UNI, or financial clause.

### L.5 Expected limits after R1–R5 (for the agreeing vote)

After R1–R5 I expect to vote ADOPTABLE_WITH_LIMITS, scoped to:
- an ordinary A structural representation and codec interface for the declared closure domain;
- no native ABI, binding, admission, cost or specialization choice;
- no B freeze;
- the L.3 conditions attached;
- the G.4 components (guard, w-bit lanes, id reconstitution, padding) listed as required manifest entries.

The cost of the top-first shifting (O(S·row width) per push or pop) is acknowledged as unmeasured. A physical bottom-first variant remains open under an explicit adapter.

---

**Status unchanged.**
- G and L are unadopted and unregistered. All tests and SDK operations are UNRUN.
- Any source edit invalidates the affected hashes and requires fresh review of those bytes.
- This review is one security vote, not agreement. Muse's independent vote and Root's explicit scoped decision are still required.
