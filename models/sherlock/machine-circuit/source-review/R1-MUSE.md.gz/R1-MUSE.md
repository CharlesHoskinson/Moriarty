## Scope

This is the non-security, normal source/design/concept vote for the exact frozen candidate `ff8dc257…3f9e37`. It does not provide security, resource-admission, theorem, hostile-input, privacy, constraint-binding or native-proof acceptance. Literature `G` and `L` remain unexecuted; the separate Opus security/design votes remain necessary.

Three independent verdicts follow.

---

## G — Gadget/source correctness and normal tests

### Verdict: **CHANGES_REQUIRED — normal row-selection logic is correctly wired, but the standalone emitted identifiers are inconsistent with the pinned SDK serialized-operand format; all tests remain SOURCE-ONLY / UNRUN.**

### What is correct in `emit_fetch_block`

Against `reference_types.rs` the constructor correctly does nothing machine-specific. It is a generic bounded scalar fetch:

1. `TableShape::new` rejects zero capacity/columns, empty or duplicated column names and checked host-size overflow.
2. `emit_fetch_block` checks `rows.len() == capacity` and each row width, then constrains `active_rows` and `index` as UInt128 (`ConstrainBits(128)`) and every supplied cell to its declared `UInt`/`Bool` kind.
3. Capacity/prefix logic is correct in the normal intended domain:
   - `LessThan(capacity, active_rows) == 0` means `active_rows <= capacity`.
   - `Assert(LessThan(index, active_rows))` means `index < active_rows`.
   - There are therefore exactly `capacity` candidate rows, and `index` lies in the active prefix.
4. The selector logic is sound at the source level. Each `TestEq(index, r)` selector is constrained `Bool`; the running `Add` chain is finally constrained equal to `1`. Given the two guards above, exactly one selector is intended to be true.
5. Each column `CondSelect` lane starts from immediate `0` and visits every row in order. The final lane value is constrained to the column kind. This selects the complete row, not merely one distinguished column. The zero seed is honestly documented as construction data, not an accepted default/out-of-prefix row.
6. Preservation is exact operand aliasing: `FetchBlock::preserved` returns the original `active_rows`, `index` and all row operands. No supplied row is rewritten, including Boolean `false`, and inactive rows are still supplied and preserved.
7. The second normal shape (2 rows of `Bool, UInt, UInt`) is a genuine generic-shape test, not merely a copy of the first 3×2 fixture.

The standalone positional map is also correct. For `N` rows and `C` columns, inputs are `active_rows, index, rows[r][c]` at `2 + r*C + c`; outputs are `C` selected cells followed by the same active count, index and all row cells, for `C + 2 + N*C` outputs. For the 3×2 fixture, that gives 8 inputs and 10 outputs, exactly as the tests expect.

The hand-derived expected data are independent of the emitter at the relevant level: `amount: UInt128 / enabled: Bool`, rows `(7,true), (9,false), (12,true)`, indices `0,1,2`. The tests assert wiring and packed ordering rather than actual evaluated outputs, and they do not claim native acceptance. Boolean `false` and integer zero are treated as ordinary data.

### Actual predicted bug

**Generated variable identifiers will fail the pinned SDK JSON operand deserializer unless the consuming backend normalizes them.**

The gadget generates identifiers such as:

- `row_fetch.input.0`
- `row_fetch.temp.0`
- caller/test names such as `caller.count`

The pinned SDK source in `ir.rs` states that in serialized `Operand` deserialization, variable operands must begin with `%`; non-`%` strings that are not hex immediates are rejected. Identifiers used as `Operand::Variable(...)` are serialized as the raw string. Therefore a JSON round trip through the documented `IrSource::load` path would reject variables like `row_fetch.input.0`.

This is a *predicted source bug against the stated future serialized-SDK consumer*, not a claim that in-memory Rust construction fails. The fragment author correctly notes that serialization/load are not performed. The required correction, before any SDK-load or native-consumption claim, is one of:

1. generate SDK-serializable identifiers consistently, including the temporary namespace, e.g. a `%`-prefixed namespace, and state that caller-supplied operands must use the same serialized-variable convention; or
2. demonstrate, from the actual consuming backend, a normalization step that converts these identifiers before `IrSource::load`.

The temporary-name collision rule must then be restated in terms of the final serialized namespace. The current `{scope}.temp.` reservation is not sufficient if another layer later adds prefixes differently.

### Test-construct gaps

The four tests are credible normal construction tests, but they do not yet cover several normal promises made by the source:

- No serialized identifier or future `IrSource::load` round-trip check is possible while execution remains unauthorized; this must remain an explicit future admission check.
- Error/negative constructors are authored only implicitly. There are no tests for `EmptyShape`, repeated column names, wrong row/column counts, mismatched witness cell type, empty scope or temporary-name collision.
- The selection test checks `CondSelect` cell inputs and final outputs, but does not fully assert the `bit`/`b` chain order for every crossing, the first guard `ConstrainEq(...,0)`, or the sum-to-one terminator. These are visible in the source, but the test suite does not lock them.
- The fixture test checks expected-file shape and preserved-row equality only. It deliberately does not compare actual selected outputs, because no SDK evaluation exists. That limitation is honest and must not be upgraded by later prose.

One construction-level caution remains for future integration, without becoming a resource judgment here: a shape with very large `capacity` can attempt proportional vector allocation before any resource owner has admitted that shape. Admission remains external, as the reports state.

---

## L — Substantive normal data / semantic design: complete A circuit-facing representation with separate B annex

### Verdict: **ADOPTABLE_WITH_LIMITS — as the incremental full current-A reference-machine representation only. This is not a B freeze, not a native ABI, not a security vote and not an execution admission.**

This verdict can serve as the fresh Muse non-security substantive vote for `L01–L03`, subject to the exact limits and corrections below. It cannot substitute for the required fresh Opus security vote on `L04–L10`.

### Coverage checked

The crosswalk really does account for the current public A type space:

- 55 enum variants: Tree 2, Value 4, Type 4, BinaryOp 7, UnaryOp 2, Pattern 5, Expr 8, Frame 9, Control 10, Outcome 4.
- 22 struct fields: Arm 2, Parameter 2, Function 4, Program 2, Snapshot 8, StepRecord 4.
- All eight Snapshot cells: program, control, environment, frames, `stack_limit`, `remaining_fuel`, `initial_fuel`, outcome.

The important semantic distinctions are present, not flattened:

- `Snapshot.control = None` is `controlLength = 0`; a positive spine ends in a non-`Push` row.
- `Control::Push` is stored as a root-to-leaf bounded spine; the pending frame is inline and distinct from installed `FrameSlots`.
- Frames are top-first, matching `Snapshot.frames`, where row 0 is the next frame to consume. A `Push` does not increment depth until the actual push rule.
- `Frame::Right` has no environment, preserving the actual A source distinction. The conflicting B `PrimRight(..., savedEnvironment)` sketch is correctly identified as a B discrepancy rather than silently copied into A.
- `Option<Environment>` is not collapsed with an empty environment. `Bound.bindingsPresent`, `CaseResult.bindingsPresent`, and `EnvRoot.present` preserve failed binding versus successful empty map.
- `Control::Enter(Option<Function>)` preserves missing versus present function. 
- `PrimitiveResult` uses one `Result` discriminator, avoiding the ambiguous two-option draft.
- Outcomes preserve `Pending`, `Done(value)`, `Rejected(u8)`, `Exhausted`, with the full `u8` error payload retained rather than an invented whitelist.
- Saved environments are complete `EnvRoot`s per frame/control site. The environment is treated as a finite map by meaning; canonical encoding by sorted distinct names is semantically faithful to the `BTreeMap` A environment.
- Recursive values are represented structurally. `List` is unfolded as Nil/Cons, `Tree` as Leaf/Branch, and scalar payloads remain distinct. Empty list, `UInt 0`, `Bool false` and absence remain different.
- Function lookup retains original function-table order and first matching name. Duplicate names are not sorted away.
- Program preparation includes the entry expression and every function body, including unused bodies and parameters. Names remain exact UTF-8 strings rather than hashes.
- The proposal does not invent B counters in A. Charged A work remains derivable from `initial_fuel - remaining_fuel` only for observations satisfying the machine invariant, while both fuel values themselves are retained.

The B annex is genuinely separable. It keeps B helper controls, helper work, reference cursor, logical allocation counters, physical occupancy, B outcome reasons, origins, values root, limits and layout identity as explicit extension material. It does not claim that setting any of those to zero yields B, and it does not let A coverage close B helper, financial, ADT or proof obligations.

### Corrections and limits required for adoption

Adoption should be recorded with these exact qualifications:

1. **Domain limit.** The adopted A domain is finite, typed A programs and post-startup A observations whose expressions, functions, arms and names belong to that program’s structural closure and which fit the chosen symbolic capacities. A foreign expression/function/name must produce a located `OutsideProgramClosure` tooling result. It must not be dropped, coerced, or reported as `Rejected`/`Exhausted`.

2. **Program identity check must be explicit.** `encodeObservedA` and `materializeRecordA` must state that the observation’s `program` is checked against `PreparedA.fullProgram`, with `ProgramMismatch` on difference. For a StepRecord, the current design assumes before and after share the same ProgramBlock; that is true for the reference machine and must be named as the record-domain condition.

3. **`Enter(Some(function))` matching rule must be pinned in implementation terms.** The design’s “matching function row” should be read as exact structural `Function` equality, choosing the least structurally equal row where duplicates exist. A function with the same name but different parameters, return type or body is not a match. This preserves the typed Snapshot value even though it does not preserve an unobservable original table-index identity.

4. **ProgramBlock header needs a concrete column specification before implementation.** The prose says the header is `{entryExprId, activeLengths}` with one count per table in block order, but `crosswalk.json` does not give the header as an ordered record with widths. Before implementation, freeze only the ordinary format detail: `entryExprId: id(X)` followed by the 15 active-length counts in the stated ProgramBlock table order, each width `count(Z)` for its own table. This is an encoding completion, not a scope expansion.

5. **Trace metadata remains outside the A image.** `ruleStartLine` and charge are StepRecord materialization data. If a serialized trace envelope is later defined, its `ruleStartLine` width/range and identity binding must be specified separately. The A StateBlock adoption does not freeze trace identity, statement binding or public/private exposure.

6. **Circuit implementation remains blocked on the operation manifest.** The layout may be adopted as the representation target now, but no emitter may claim step correctness until the per-rule operation/write manifest covers fetch, dispatch, environment operations, frame/control movement, preservation of untouched rows, fuel/outcome update and append order. Symbolic capacities do not admit degree, `k`, rows, proof budgets or any numeric bound.

7. **B stays unadopted and unfrozen.** B requires separate resolution of helper phases/events, failure and allocation rows, counter widths, step-cap precedence, bottom-to-top frame adaptation, control origins/resume state and the listed interface discrepancies. No A implementation may add placeholder zero B counters or claim B helper/resource coverage.

8. **Financial and general ADT scope remains open.** Pure A has no financial cells. Commit/Yield/Await, effects, duties, pending operations, phases and history obligations remain required extensions and are not represented by empty A fields.

Subject to those limits, this is aligned with real full-machine construction: it is an incremental complete current-A representation into which the row-fetch gadget can later be bound, rather than an alternate restricted end state.

---

## V — Opus-authored visual concept log: grounding, brand and iteration faithfulness

### Verdict: **ACCEPTABLE AS A BRAINSTORM LOG WITH PUBLICATION CORRECTIONS — visually legitimate Tron/PCB/Three.js evolution, grounded mainly in Iteration 001, with no fake proof/performance and no website implementation claim.**

### Grounding against the actual gadget

Iteration 001 is materially accurate against the frozen G source:

- It correctly states the module is unregistered and that compilation, four tests, serialization, SDK load/check, evaluation, native checks and proving are all UNRUN.
- The 8-input / 10-output map for the 3×2 fixture is correct.
- Packed inputs `[3, index, 7, 1, 9, 0, 12, 1]` are correct.
- The temporary allocation summary is correct: `2 + N(C+2)` temporaries. For the wrapper, `temp.0` and `temp.1` are guards, `temp.2/4/6` selectors, `temp.3/5/7` running sums, `temp.8–10` the amount lane and `temp.11–13` the enabled lane. The hand count of 57 standalone instructions is also correct as a scene-sizing count.
- The duplicate range checks in the standalone wrapper are correctly observed: the wrapper constrains each public input, and the fragment constrains its inputs again.
- The note correctly distinguishes supplied inputs, Root’s independent expected outputs and actual outputs, with Actual shown as UNRUN. It correctly refuses to let the browser compute the selected row.
- Boolean `false`, numeric zero and lane seed zero are visually distinct proposals. That is exactly the right treatment for this fixture.
- Status channels are honest: proposed light is decoration/selection; example figures belong to hand-derived cases; “measured” light is reserved until a real run is forwarded. No proof, speed, circuit-size, fee or recursion-completion claim is made.

The scene ideas are legitimate Three.js concepts without pretending to be a site: generate scene data from instruction/operand structure, instance pads/vias/parts, use distance tiers, keep labels in DOM overlays, offer an SVG fallback, support keyboard navigation and reduced motion, and mark recursive-call imagery conceptual until source exists.

### Brand judgment

The notes handle the current style system honestly. The existing site styles say “Nothing glows,” but the user has now explicitly directed a Tron/PCB visual evolution, so emissive circuitry is no longer blocked by that old rule for this concept log. The notes nevertheless preserve the parts that should survive:

- the Moriarty wordmark stays flat, in the existing sans, never extruded and never lit;
- tabular monospace figures remain exact and non-abbreviating;
- ink/paper grounds and the copper accent remain the base palette;
- any cyan or emission is explicitly proposed and pending design/contrast review rather than silently adopted into `site/`.

That is the right balance. The Tron reference is used as luminous routes on dark layered boards, with no franchise logos, typefaces, characters or set identity.

Iteration 000 and Iteration 001 are correctly one note per actual frozen circuit iteration. Iteration 001 extends 000 by reference rather than rewriting it. Notes 000 and 001 are concepts, not site code, and the atlas README says that plainly.

### Publication corrections required

1. **Do not use Iteration 000 to validate the current G gadget.** Iteration 000 describes an earlier scalar literal-step candidate (`sherlock_step`, layout `sherlock-scalar-literal-step/1`) whose source is not part of the current frozen G package. Its 30-field description, five-test statement and 125/124 hand counts are therefore **unverified in this review** and must remain attached only to that older pinned iteration.

2. **Fix the provenance base ambiguity.** `AUTHORSHIP.json` records a single `source_worktree_base` (`f7ff06ed…`), while Iteration 001 states its source base is `1fb794d1…`. Before publication, either record the base per iteration or relabel the field so it does not appear to pin both iterations to one base.

3. **Verbatim-materialization remains only partially auditable.** `AUTHORSHIP.json` records requested and returned `claude-opus-5-5`, high effort, original-reply hashes and `note_materialized_verbatim: true`. The original replies themselves are not in the reviewed package, so a reader cannot independently verify verbatim materialization from the notes alone. Provenance should either retain those original reply artifacts with the publication record or present the verbatim claim as Root/Opus-recorded provenance rather than reader-verifiable evidence. The attribution itself is honest: it belongs to the planning notes and is not website copy.

4. **Keep range notation explicit in any eventual UI.** Iteration 001 already notices the half-open-range ambiguity in source documents. Any future page should list explicit output positions—selected `0..1`, preserved count/index `2..3`, preserved rows `4..9` for the 3×2 case—rather than copying ambiguous range prose.

5. **Keep the “Actual: UNRUN” channel until a recorded run exists.** A later recorded normal run may populate actual outputs and the measured-light channel. Until then, no animated trace should imply execution, constraint satisfaction or proving activity.

---

## Final separated outcomes

- **G:** **CHANGES_REQUIRED** — fix or eliminate the serialized-identifier inconsistency before SDK-load consumption; row-selection logic and normal test intention are otherwise coherently constructed but unrun.
- **L:** **ADOPTABLE_WITH_LIMITS** — adopt only the complete current-A representation as an incremental full-machine layer, with the stated domain/header/identity/manifest limits and with B, financial, ADT, native-binding and resource decisions left open.
- **V:** **ACCEPTABLE WITH PUBLICATION CORRECTIONS** — publishable as Opus-authored concept log under `wiki-llm` after fixing the authorship-base ambiguity and keeping Iteration 000 separate/unverified relative to the current gadget; no site, CI, code or dependency change is implied.
