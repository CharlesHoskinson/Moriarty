# PRECONDITION_DISPOSITION_CONDITIONAL

This covers only the observed enumeration gap. It is not a source vote, not a command classification, not a grant, and not a prediction of the pending Opus review.

## Bound identities

| Item | Bytes | SHA-256 |
|---|---|---|
| Precheck record `P4-ARITHMETIC-FUEL-QUINT-SOURCE-PRECHECK-r1.json` | 30199 | `b68dfc83b7d9df21d0bde32f49b87a28a461b905b968a4d05c26df08ac17f2ce` |
| Outer `SOURCE-MANIFEST.json` (frozen r1) | 11769 | `cbbf343371f20ada8b308a50d33ac9dea316555abce6589bc3c8042808ffa180` |
| Included `INPUT-MANIFEST.json` (listed member of the outer manifest) | 17117 | `b829f0d97af9736fbe223431aebb29c61df12133e9977a15826a3c303e1b84e5` |
| Extra `inputs/adopted-candidate/SOURCE-MANIFEST.json` | 662 | `42d45bd3bea826469408a774984318d1ae473b82636ae5f32c0bf4ca8b23c6a2` |
| Proposed sequence `PROPOSAL.json` | 4920 | `469c8e57b3f27faf68702ec76645845df34a05606b22f75e2589fb78ea8b89ec` |

I did not compute any hash myself. All hash and byte equalities rest on Root's recorded rechecks, and condition 2 requires Root to repeat them.

## Reasons the gap is not blocking

1. **The extra file is identity-bound.** The chain is: outer manifest `cbbf…` → `INPUT-MANIFEST.json` `b829…` → an entry with snapshot `inputs/adopted-candidate/SOURCE-MANIFEST.json`, 662 bytes, `42d45…`, role "Complete adopted aux/2 candidate". So the full closure is determined by `cbbf…`. Nothing about it is unbound or unknown.

2. **The cause is a self-exclusion bug, not drift.** The manifest says it "excludes itself and OUTPUT_SHA256". A basename match on `SOURCE-MANIFEST.json` would also drop the nested file of the same name. The counts support this:
   - The 40 INPUT-MANIFEST snapshots minus the nested one leave 39 listed `inputs/` files.
   - 17 top-level files + 4 `history/` files + 39 `inputs/` files = 60 listed.
   - 60 + top `SOURCE-MANIFEST.json` + `OUTPUT_SHA256` + the nested file = the 63 entries in `actual_source_listing`.

3. **The supplied 662-byte body matches what was already disclosed.** By inspection it is inert metadata:
   - Status `FROZEN_UNADOPTED_SOURCE_PROPOSAL_ALL_EXECUTION_UNRUN`, with `native_authority: 0`.
   - It pins three files. Their bytes and hashes (`88887f1d…`, `63182dc1…`, `4d99c6ed…`) equal the outer-manifest entries for the same adopted-candidate files.
   - The README already discloses "Historical source-manifest UNADOPTED text is retained as its authoring snapshot", which matches this content.

4. **The extra file is not an execution input of `469c8e…`, by source inspection only.** No argv in the proposal names it. The only Quint import in the supplied sources is `./arithmeticFuel`. Whether the commands are eligible remains for the separate classification.

5. **No bytes changed and nothing ran.** Root's strict assertion stopped before any tool or model execution. Re-evaluating the precheck against the bound closure is a source recheck. It is not a retry of any proposed command, and no counter is consumed or reset.

## Exact conditions

All of the following must hold before the first command of `469c8e…`. A failure of any one is a stop, with no retry.

1. **Root records a separate closure binding.** Do not edit the outer manifest, INPUT-MANIFEST or PROPOSAL. The record defines the source closure of frozen r1 as exactly:
   - (a) the 60 paths, bytes and hashes listed in `cbbf…`;
   - (b) top `SOURCE-MANIFEST.json` at 11769 bytes and `cbbf…`;
   - (c) `OUTPUT_SHA256`, whose content must bind exactly `cbbf…` (its body was not supplied here, so Root must check it);
   - (d) `inputs/adopted-candidate/SOURCE-MANIFEST.json` at 662 bytes and `42d45…`, bound only through INPUT-MANIFEST `b829…`.

2. **Immediately before execution, Root re-verifies all of the following:**
   - The actual listing equals exactly those 63 paths, as regular files, with no symlinks and no other entries, hidden files or extra directories.
   - Every byte count and hash in (a)–(d) matches.
   - All 40 original-to-snapshot pairs in INPUT-MANIFEST still match.
   - The Node pin (`7fde7b8a…`, 126595440 bytes) and the CLI pin (`ac12595b…`, 16807 bytes) still match.

3. **The pending full original Opus source review receives the complete 662-byte nested body plus this closure binding, and independently approves the closure.** If the original Muse vote transport lacked the nested body, Root records that as a transport limit on the Muse vote. It is not a ground for transferring or extending that vote.

4. **The observation and tmp directories stay outside the packet,** as stated in the proposal. After execution, the packet is rechecked against the same 63-entry closure. Any packet change invalidates the observations.

5. **`PROPOSAL.json` stays at `469c8e…`.** Its `source_manifest_sha256` stays `cbbf…`, read together with the condition 1 record.

## When fresh reviews are needed

Fresh full source reviews (original Opus and Muse) and a fresh command classification are required if any of the following happens:
- the packet is regenerated or re-manifested;
- the nested file is removed, moved or rewritten;
- `OUTPUT_SHA256` or any closure member changes;
- the proposal bytes change.

Changed bytes inherit no prior vote. I recommend against regenerating the manifest to "fix" the gap, because the binding in condition 1 resolves it without changing any source bytes.

## Not waived or affected

- The pending full original Opus source review and its exact ordinary-check classification, which must independently approve.
- The Muse source review requirement.
- The original command classification.
- All source and tool rechecks, stage gates, and the 10s/256MB/90s/30s resource caps.
- All counters, historical failures, the C4 compile-revert rule and the full roadmap.
- No retry, counter reset, new campaign, runner, native authority or partial classification grant.

Native authority stays at 0. All model and native operations remain **UNRUN**.
