# APPROVED_SCOPED_RESULT_WITH_LIMITS

## Verdict

**APPROVED_SCOPED_RESULT_WITH_LIMITS** — Root faithfully applied the existing owner gate and stopped the sequence after phase zero. This approval covers only the scoped actual result stated below. It supplies no execution authority, retry, gate weakening, new wrapper, or new campaign.

Stop record: `P4-QUINT-PHASE-ZERO-STOP-r1.json`, SHA-256 `1d20669fdf6a994dd03635257af8a440df32d3b0b24c64c1c292e7c20e891428`.

## Findings

**1. The gate that fired is explicit and exception-free (repository observation from supplied owner record).** The Muse fallback owner review (`3887543a…c51a5d`, muse-wonder-1.0, high effort, explicitly *not* Opus) states: any traced `%network` syscall attempt — expressly including `socketpair` and `recvfrom` — regardless of success or failure, stops the sequence, with "no DNS, localhost, or 'internal socket' exceptions." Root's stated stop basis quotes that condition accurately.

**2. The raw trace, inspected directly, contains the decisive syscalls.** In the supplied 956,035-byte trace (SHA-256 `e2ceee4e…af68`):

- Line 1: PID 2750270 `execve("/usr/bin/timeout", …)` with the exact original phase-0 argv.
- Line 23: `2750270 socketpair(AF_UNIX, SOCK_SEQPACKET|SOCK_CLOEXEC, 0, [3<UNIX:[33429811->33429812]>, 4<…>]) = 0`.
- Line 25: `2750270 recvfrom(3<UNIX:…> <unfinished ...>`, later `<... recvfrom resumed>, "", 8, 0, NULL, NULL) = 0` — the unfinished/resumed pair is matched, so no ambiguity arises on the decisive lines.
- The next line is `clone(...) = 2750271`, and only then does 2750271 `execve` the pinned Node path with the exact original Quint `typecheck` argv. The trace tail shows Node threads `exit(0)`, `2750271 exit_group(0)`, `2750270 wait4(... WEXITSTATUS == 0 ...)`, `2750270 exit_group(0)`.

The exec-chain gate is therefore satisfied, but the network-family gate is triggered earlier and independently. The mechanical match is real; Root's stop follows necessarily from the gate as written.

**3. Causal interpretation (source-inspected inference only).** Because both syscalls occur in the `timeout` process before `clone`/`execve` of Node, and the pair is an `AF_UNIX` `SOCK_SEQPACKET` self-pair with no `connect`, `bind`, `listen`, or external address anywhere in the inspected trace, the plausible inference is that this is the timeout utility's internal IPC/signalling plumbing, not activity of the Quint model, Node, or the model source. I do **not** claim network egress, external communication, malicious behavior, or any security compromise, and no such claim may be published. This inference does not create an exception: the gate as adopted forbids *any* network-family attempt including internal sockets, so benign origin and gate violation coincide here. That tension is a property of the pre-existing gate, not a Root error, and resolving it would require an owner decision I do not make and do not propose automating.

**4. Source normal correctness (source inspection, all execution UNRUN).** I inspected the complete supplied `arithmeticFuel.qnt` (10,516 bytes, `f83a0d9f…f4817`), `arithmeticFuelTest.qnt` (11,248 bytes, `66f96bbb…4269d`), and `expected.json` (28,236 bytes, `05439876…3a37`):

- Add/Sub/Lt share the 17-link ripple chain; Mul uses the 33-link product chain with carries bounded `< 4096` and `carry.nth(32) == 0`, consistent with E4 (attained maximum 4079 < 2^12). Constructor recurrences are checked against independent global-integer oracles (`wordOf` equations and `outcomeRelation`), so constructor and relation are not the same computation restated.
- Overflow separation is correct in form: Add/Sub yield `Err10` exactly on final carry/borrow, Mul yields `Err10` exactly when `highSum ≠ 0`, and Lt yields `BoolOk(packedA < packedB)` — matching literal tests 1–8, including max² with `highSum 4079`.
- Fuel precedence is correct in form: terminal control (Error, or Ret at depth 0) is examined before exhaustion; charge is `evt · ¬terminal · (1 − prefix16)`; the whole-word oracle (`wordOf(remaining) > 0`) is equivalent to the prefix construction because `prefix16 = 1` iff enabled and all bytes are zero. Disabled, DoneFree, RejectedFree, ExhaustedFree, and Charged are mutually ordered as the ten literal fuel tests require, with E1/E-FUEL (A108 charged, corrected counts 24+8+4 = 36) preserved as binding reading, not re-derived from the non-normative inventory lists.
- I find no blocking defect in the stated source-only scope. This is a source reading, not execution evidence: the same-author, non-blinded provenance of `expected.json` is disclosed in its own header and remains a caveat.

**5. Timing and stop handling (from supplied captures).** Pre-phase check at `2026-10-16T11:44:10.229Z` reports all pins matching (63 source files / 35 directories, 40 original-snapshot pairs, package 4,667 files / 28,588,829 bytes / 79 packages / 3 symlinks, proposal `469c8e57…89ec`, plan `96d3c43d…f520`, closures `094aa910…f3` and `a18adf8d…fce1`). Phase 0 started `11:44:14.239Z`, ran 1.568 s, `exit_code 0`, `parent_timeout false`, empty stdout and stderr (both `e3b0c442…b855`), capture `0d06713c…efc1`. Stop recorded `11:44:52.776Z`. Phases 1 (18 normal tests) and 2 (32×8 seeded run) were never started and never retried. Root did not convert raw exit 0 into a pass, did not adjudicate the rest of the trace into a security approval, and left the result pending fresh review. That is the faithful application of the gate.

## Provenance caveats — sufficiency

The source/tool provenance is sufficient *for this scoped publication* provided the limits travel with it: Root's pre/post rehash receipts are supplied and internally consistent, and the frozen phase-0 driver (`49e62358…a2ed`) matches its pre-phase record byte-for-byte. However, the underlying ~1.28 MB installed-package metadata list (closure `a18adf8d…fce1`) was **not retransmitted and was not independently rehashed by this reviewer**. Package-closure claims therefore rest on Root's receipts, not on reviewer inspection; this reading limitation is explicit and must be retained verbatim wherever the result is cited. It is not sufficient basis for any independent installed-package source audit claim.

## Exact claims that may be published

1. The pinned root Quint model typecheck command was attempted exactly once under the strace capture wrapper, completed with raw exit 0 in ~1.57 s, empty stdout/stderr, no parent timeout.
2. Its raw trace contains `socketpair` and `recvfrom` by the initial `timeout` PID before Node started, mechanically triggering the pre-existing owner gate forbidding any network-family syscall including internal sockets.
3. Root stopped the sequence at phase zero with no retry; the 18 normal tests and the 32-sample × 8-step run are **UNRUN**; K33 checks remain **UNRUN**; no native SDK, Rust, K, circuit, PCD, or stagenet execution occurred.
4. Source closure (63 files / 35 dirs), 40 snapshot pairs, tool/proposal pins, and observation inventory are unchanged per Root's supplied pre/post receipts; `native_authority` remains 0.

## Claims that may not be published

That the model QA passed, that any test passed, that exit 0 is accepted complete model QA, that `socketpair` shows network egress or a security compromise, or that the package closure was independently rehashed by this reviewer. Historical source-only approvals (including both `ADOPT_COMPLETE_ARITHMETIC_FUEL_SOURCE_WITH_CONDITIONS` votes with E1–E7) remain historical and are not execution evidence.

## Retained limits and dissent

All original identities and records stand unchanged: the Opus concrete-executor request ended with no public result (`06119deb…a13`, not evidence of provider-wide outage and not approval by silence); the concrete executor owner review is the Muse fallback under user authorization, not Opus; this audit does not retroactively convert either. Preserved without alteration: E1–E7 and E-FUEL, full39 conditions 1–10 / F1–F7, P3 conditions 1–8, errata R2-1, R2-3–R2-6, the Muse R2-4 dissent in both prongs, G4-FIELD / G4-ISA-1–4 / G4-FETCH / G4-BYTE / G4-APPEND as unproved requirements, IO-1–IO-8 open, native authority 0, the old 90 s/30 s caps and counters, C4 unchanged, and the full roadmap. No automatic rerun, gate weakening, wrapper, or campaign is proposed or authorized by this result.
