phase_index = 0
from pathlib import Path
import subprocess, os, signal, time, json, datetime, hashlib
# phase_index is chosen separately, exactly once in 0,1,2; no auto-dispatch.
b = Path('/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-reference-20261015/opus-sprint-loop-20261015')
proposal = json.loads((b/'p4-arithmetic-fuel-quint-command-proposal-r1/PROPOSAL.json').read_bytes())
obs = Path(proposal['working_directory'])
# Root completes exact source/tool/package prechecks before invoking this capture.
if phase_index == 0:
    assert not obs.exists()
    obs.mkdir()
    (obs/'tmp').mkdir()
else:
    assert obs.is_dir() and (obs/'tmp').is_dir()
cmd = proposal['commands'][phase_index]
env = {k: proposal['environment'][k] for k in ['PATH','LANG','TMPDIR']}
trace = obs/(cmd['id']+'.strace')
assert not trace.exists()
# strace arguments are a proposed observation wrapper, subject to owner classification.
argv = ['/usr/bin/strace','--kill-on-exit','-f','-qq','-s','4096','-yy','-e','trace=%file,%network,%process','-o',str(trace),'--'] + cmd['argv']
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
t0 = time.monotonic()
with (obs/(cmd['id']+'.stdout')).open('xb') as out, (obs/(cmd['id']+'.stderr')).open('xb') as err:
    proc = subprocess.Popen(argv,cwd=obs,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
    try:
        exit_code = proc.wait(timeout=15)
        parent_timeout = False
    except subprocess.TimeoutExpired:
        parent_timeout = True
        os.killpg(proc.pid,signal.SIGTERM)
        try: exit_code=proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL)
            exit_code=proc.wait()
record = {'id':cmd['id'],'argv_original_child':cmd['argv'],'argv_observation_wrapper':argv,'environment':env,'HOME':'UNSET','started_at':start,'duration_seconds':time.monotonic()-t0,'exit_code':exit_code,'parent_timeout':parent_timeout,'native_authority':0,'scope':'Raw capture only. No pass, eligibility, or security decision; no automatic following command.'}
for suffix in ['stdout','stderr','strace']:
    p=obs/(cmd['id']+'.'+suffix)
    if p.exists():
        raw=p.read_bytes();record[suffix]={'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(obs/(cmd['id']+'.capture.json')).write_text(json.dumps(record,indent=2)+'\n')
