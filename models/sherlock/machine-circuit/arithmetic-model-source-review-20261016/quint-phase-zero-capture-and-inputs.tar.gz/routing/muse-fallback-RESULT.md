# ELIGIBLE_CONCRETE_ORDINARY_CAPTURE_WITH_CONDITIONS

**Capture plan SHA-256:** `96d3c43d3ea1c28285a13d9d4d3882b872088fde083d21b42c5dba5cf736b520`  
**Original proposal SHA-256:** `469c8e57b3f27faf68702ec76645845df34a05606b22f75e2589fb78ea8b89ec`  
**63-file closure SHA-256:** `094aa9106e6e2a8cbf3a0742e5d4c77f5f391b743539ff715eae8a9a2b480bf3`  
**Package closure SHA-256:** `a18adf8d976874568c6984bab180b0d988f26e041c4a28f3392079ff62f3fce1`

This is a fresh **Muse Wonder 1.0, high-effort** vote acting only as the user-authorized temporary security-owner fallback. I am not Opus, I do not claim Opus saw this supplement, and this vote is not an execution grant, native authority, counter reset, new campaign, or resource increase. No execution has occurred. Historical Opus and earlier Muse identities remain exactly as recorded.

## Closure condition 3: disposition

The original condition required the designated owner to receive the complete 662-byte nested `SOURCE-MANIFEST.json` and the explicit 63-file closure and independently approve them.

I have now received and inspected:

- the complete 662-byte body, SHA-256 `42d45bd3bea826469408a774984318d1ae473b82636ae5f32c0bf4ca8b23c6a2`;
- the explicit closure `094aa9106e6e2a8cbf3a0742e5d4c77f5f391b743539ff715eae8a9a2b480bf3`;
- the outer manifest `cbbf343371f20ada8b308a50d33ac9dea316555abce6589bc3c8042808ffa180`;
- `INPUT-MANIFEST.json` at `b829f0d97af9736fbe223431aebb29c61df12133e9977a15826a3c303e1b84e5`;
- `OUTPUT_SHA256` at `d183d1d6025045dbb6dad01e7589ab9f1cdf4c7ce90e97b9c1a28370c081a114`, whose listed hashes include the outer manifest and the nested manifest.

The nested body is inert status metadata with `native_authority: 0`. Its three pinned files match the corresponding outer-manifest entries by supplied bytes and hashes (`88887f1d…`, `63182dc1…`, `4d99c6ed…`). No command argv names it; the only Quint import in the supplied model sources is `./arithmeticFuel`. It is therefore not an execution input.

**Disposition:** the substantive identity and correctness purpose of closure condition 3 is satisfied by this fallback receipt and inspection. The literal statement “Opus received and approved the supplement” is **not** satisfied and must never be recorded. If Root’s governance requires literal Opus identity rather than the user-authorized designated-owner fallback role, execution remains blocked until an actual Opus review exists. Under the fallback authorization given for this pending audit, I do not waive any identity, byte, hash, or correctness requirement; I satisfy them under a different, explicitly recorded reviewer identity.

## Wrapper classification

The strace wrapper changes the immediate `execve`: the first executed program is pinned `/usr/bin/strace`, not `/usr/bin/timeout`. It therefore does not literally satisfy the earlier “exactly the three argument vectors via execve” wording.

I classify and authorize it only in this amended, narrow form:

- after strace’s `--`, the child argv must be byte-for-byte the original proposal argv for that phase;
- no shell may be involved;
- cwd remains the fresh observation directory;
- the environment passed to the child remains exactly `PATH`, `LANG`, and `TMPDIR`, with `HOME` unset and no other variables;
- the inner command remains `timeout 10s` with 2-second kill grace and Node `--max-old-space-size=256`;
- the parent’s 15-second wait plus 2-second cleanup does not extend the child’s 10+2 limit; any parent timeout is a failed, stopped phase, never a pass and never a retry;
- `--kill-on-exit` is documented in the supplied strace 6.19 manual and is not assumed by this vote: if the actual pinned strace rejects it, phase 0 fails, stops, and the flag may not simply be removed and retried.

Subject to every gate below, this is an observational capture wrapper around the same ordinary Quint commands. It is not containment, not a sandbox, and not a new physical mechanism.

## Concrete driver-source findings

No blocking defect exists in the supplied driver text when it is used strictly as a raw capturer, with these mandatory qualifications:

1. ** `phase_index` is externally supplied and undefined inside the fragment.** Before any execution, Root must freeze each invocation separately with exactly one literal `phase_index` value (`0`, then separately `1`, then separately `2`), record the SHA-256 of those exact driver bytes, use each frozen invocation at most once, and provide no loop or auto-dispatch. If Root cannot instantiate `phase_index` in that frozen, single-phase form, execution is blocked until that minimal correction is recorded.
2. **The driver intentionally performs no pin, pass, eligibility, or security checks.** Root must perform every pre- and post-phase check below outside the driver. Invoking the driver before those checks are mechanically recorded does not satisfy this vote.
3. The final writer suffix is accepted as supplied: characters `39,92,110,39`, i.e. a normal Python `'\n'` literal in the driver source. No defect is taken from display escaping, and no driver change is required for it.
4. Trace observation is incomplete by design: the filter `%file,%network,%process` does not trace plain `write` syscalls. The mutation gate therefore rests on traced opens and other path-based mutation syscalls, the inherited-fd inventory, and before/after closure rehashes. It must not be described as proof that no untraced write primitive could ever exist. Any ambiguity stops the sequence rather than being resolved in the child’s favor.

## Mandatory pre-execution gates — before phase 0, and repeated before each later phase

All of the following must pass mechanically. Any failure stops the sequence with no retry of that phase and no later phase.

1. **Source closure.** The packet listing is exactly 63 regular files and exactly the 35 listed prefix directories from `094aa910…`, with no extras, hidden extras, symlinks, or non-regular files. Every byte count and SHA-256 in the closure matches, including outer `cbbf3433…`, `INPUT-MANIFEST.json`, `OUTPUT_SHA256`, and the nested 662-byte manifest. All 40 original-to-snapshot pairs still match. `PROPOSAL.json` remains `469c8e57…` and its `source_manifest_sha256` remains `cbbf3433…`.
2. **Package closure.** The installed-package record remains `a18adf8d…`: exactly 4667 files, 28,588,829 bytes, 79 packages, no unresolved declarations, and exactly the three recorded in-tree symlinks resolved to their recorded targets. Any file, byte, hash, package, or symlink difference stops execution.
3. **Tool pins.** Node remains 126,595,440 bytes at `7fde7b8afa198da66257f42ee2001d874c7355631e6d1579a5fb5ef1f246df4c`; `cli.js` remains 16,807 bytes at `ac12595b1cb7253feec93c79417615c6eb20fc3b6a3df35c5e3530b24e90a501`; strace remains 2,370,264 bytes at `f47342683309e807bca57d6d89b82f94a9b39aa614e9c28c2b67cefbc35eee58`.
4. **Frozen driver and proposal agreement.** The phase-specific driver bytes and `phase_index` are recorded. The driver’s `argv_original_child` for the selected phase must equal the proposal argv exactly, token for token, including `--backend typescript` where present. The observation wrapper prefix must be exactly `["/usr/bin/strace","--kill-on-exit","-f","-qq","-s","4096","-yy","-e","trace=%file,%network,%process","-o",<obs>/<id>.strace,"--"]`.
5. **Environment and directories.** The capture environment contains exactly the proposal’s `PATH`, `LANG`, and `TMPDIR`; `TMPDIR` is `<obs>/tmp`; `HOME`, `NODE_OPTIONS`, and `NODE_PATH` are absent. Before phase 0, `<obs>` does not exist. Before phase 1 or 2, `<obs>` contains only `tmp` and the exact completed prior-phase artifacts, and `tmp` is empty.

## Mandatory trace and capture gates — after each phase, before any dependent phase

Root must inspect the actual raw stdout, stderr, strace, and `<id>.capture.json` before selecting the next `phase_index`.

1. **Capture integrity.** `<id>.stdout`, `<id>.stderr`, `<id>.strace`, and `<id>.capture.json` all exist. Recomputed byte counts and SHA-256 values match the capture record. `exit_code` is exactly `0`; `parent_timeout` is exactly `false`; `native_authority` is `0`. A missing trace, hash mismatch, signal exit, inner timeout exit (`124`/`137`), or parent timeout stops the sequence.
2. **Exec chain.** The trace shows exactly one successful initial `execve` of `/usr/bin/timeout` with the original timeout argv, followed by exactly one successful `execve` of the pinned Node path with the original Node/Quint argv. Any other attempted or successful `execve`/`execveat`, to any other path or with any altered argument, stops the sequence. Thread/process creation without a different exec is recorded but does not by itself pass any later gate.
3. **Network attempts.** Any traced `%network` syscall attempt — including `socket`, `socketpair`, `connect`, `bind`, `listen`, `accept`, `accept4`, `sendto`, `sendmsg`, `sendmmsg`, `recvfrom`, `recvmsg`, `recvmmsg`, or `shutdown` — regardless of success or failure, stops the sequence and is recorded as a defect. There are no DNS, localhost, or “internal socket” exceptions in this vote.
4. **Filesystem mutation attempts.** Any traced mutating operation, attempted regardless of return value, stops the sequence. This includes any `open`, `openat`, `openat2`, or `creat` whose flags contain `O_WRONLY`, `O_RDWR`, `O_CREAT`, `O_TRUNC`, or `O_APPEND`; and any `unlink`, `unlinkat`, `rename`, `renameat`, `renameat2`, `mkdir`, `mkdirat`, `rmdir`, `link`, `linkat`, `symlink`, `symlinkat`, `mknod`, `mknodat`, `chmod`, `fchmod`, `fchmodat`, `chown`, `fchown`, `lchown`, `fchownat`, `truncate`, `ftruncate`, `fallocate`, `utime`, `utimes`, `utimensat`, `futimens`, `mount`, `umount`, `umount2`, `pivot_root`, or `chroot`. Read-only startup and source/package reads are the only file opens allowed to pass this gate.
5. **Inherited descriptors and observation inventory.** The only inherited writable descriptors permitted are the driver-created stdout and stderr files inside `<obs>`, with stdin from `/dev/null`. Any traced descriptor annotation showing another writable path, any file present in `<obs>/tmp` at the gate, or any `<obs>` entry beyond the exact expected cumulative capture artifacts stops the sequence.
6. **Ambiguity fails closed.** Any unparseable trace line, unknown `syscall_` entry, detached tracee, `<unfinished …>` without a matching `<… resumed>`, ellipsis-truncated path or argv relevant to a gated syscall, or missing trace termination evidence stops the sequence for owner adjudication. Root must not infer safety from a partial trace and must not rerun the phase to obtain a cleaner one.
7. **Post-phase rehash.** Immediately after each phase, Root repeats the 63-file source closure, proposal, package closure, Node, CLI, and strace pins. Any change invalidates the observations and stops the sequence.

## Output gates per phase

- **Phase 0 — `model-root-typecheck`:** proceed to tests only if `exit_code == 0`, `parent_timeout == false`, and every trace/capture gate above passes. No later phase may start on a typecheck warning adjudicated informally; the raw capture remains the evidence.
- **Phase 1 — `normal-tests`:** the literal original wording requiring printed “zero failed and zero ignored” is not attainable from the pinned CLI output and must not be invented. The attainable predicate authorized by this vote is: exit `0`; parent timeout false; stdout contains each of the 18 exact names from `NORMAL-EXPECTATION-NAMES.json` (`dae6fafdcdb39f574032f74000ea4acb8935420635e07b563af7071ea4c07399`) exactly once in an `ok <NAME> passed 1 test(s)` result; exactly 18 such `ok` lines and no extras; and an `18 passing` summary. Root’s record must label zero failed/ignored as **INFERRED_NOT_PRINTED**, derived only from exit 0, complete exact-name coverage of the mechanically selected 18 tests, and the `18 passing` summary. Any missing, duplicate, or extra test name, any failure/ignored indication, or any other summary count stops the sequence before the run.
- **Phase 2 — `short-seeded-run`:** there is no dependent phase. Completion may be reported only if exit `0`, parent timeout false, and all trace, inventory, and post-phase rehash gates pass. A pass remains finite sampled ordinary QA only: seed `1`, at most 32 samples and 8 steps, over the model’s finite sampled domain. It establishes no exhaustive 280-combination result, no all-u128 coverage, no hostile-witness coverage, no native/Rust/K/SDK correspondence, no milestone acceptance, and no change to counters, caps, C4, the roadmap, or native authority `0`.

Each of the three commands may be attempted once only, in order, under this capture plan. The first failed, timed-out, ambiguous, mutating, network-attempting, or closure-changing phase ends the sequence.

**Vote: ELIGIBLE_CONCRETE_ORDINARY_CAPTURE_WITH_CONDITIONS** for capture plan `96d3c43d3ea1c28285a13d9d4d3882b872088fde083d21b42c5dba5cf736b520`, proposal `469c8e57b3f27faf68702ec76645845df34a05606b22f75e2589fb78ea8b89ec`, 63-file closure `094aa9106e6e2a8cbf3a0742e5d4c77f5f391b743539ff715eae8a9a2b480bf3`, and package closure `a18adf8d976874568c6984bab180b0d988f26e041c4a28f3392079ff62f3fce1`.
