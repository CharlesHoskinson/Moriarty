# Fresh non-author security and physical-design audit: proposed `sherlock-k-a-aux/2` (arithmetic and fuel witnesses)

**Candidate manifest (full):** `42d45bd3bea826469408a774984318d1ae473b82636ae5f32c0bf4ca8b23c6a2`

| File | Bytes | SHA-256 (as supplied, not recomputed) |
|---|---|---|
| ARITHMETIC-FUEL-DESIGN.md | 51590 | `88887f1d30aee2c5c0f473d2276a8aecd5e8f4e12018a34b0037ec11d51b13c3` |
| ARITHMETIC-FUEL-MANIFEST.json | 19457 | `63182dc1b10c5dc93080ab8a5149b89de56308a75e7008a39b9c2cc065d5df4f` |
| OWNER-RESULT.json | 55926 | `4d99c6edab866cf3d906302d9821f9b094028d42fdbda4464461db9156bd767f` |

## Reviewer identity, independence and limits

**Who reviewed.** This review was done by Claude Opus 5.5 (`claude-opus-5-5`) in a fresh context, acting as the designated security and physical-design owner reviewer.

**Independence.** The author is the same model family in a different context. This is not a cross-family independent review. I had no access to the author's context. The author result is not counted as a vote.

**What I did not use.** I used no tools, filesystem, web, commands, parsers, models, SDK or native execution, writes or delegation. I recomputed no hashes. Every identity is as supplied. All derivations below are by hand.

**Reading coverage:**
- I read the full DESIGN and MANIFEST.
- The OWNER-RESULT `text` field matches DESIGN by reading only. I did not compare them byte for byte.
- Primary sources read:
  - P3 MD and JSON;
  - the Root P3 adoption record;
  - publication-binding;
  - full39 P1;
  - `reference.rs` and `reference_types.rs`;
  - `main.k`;
  - `literal_step.rs`;
  - all seven L4 files.
- For the 616 KB R5 JSON, I read the A080/A082/A084, A102, A108/A111, A153, A225 and coverage sections. I did not read it exhaustively line by line.

**Not supplied, so not verified:**
- the exact texts of R2-1, R2-3, R2-4, R2-5 and R2-6 (only README summaries reach me through publication-binding);
- the aux/1 SOURCE-MANIFEST body (`e7c34e52…`), which is referenced only;
- the R5 MD (`48580e13…`);
- `super::*` (the Instruction semantics and `emit_enabled_fetch_block`);
- the P3 Opus and Muse review captures (only their Root excerpts).

**Identity limits:**
- The candidate pins `source_commit 192972dc…`.
- publication-binding names `8194011…` (PR #97).
- `e0740ced…` is truncated and user-stated.
- I can reconcile none of these.

## Independent derivations

### Add and Sub (16-byte carry/borrow)

**ADD-i.** With byte inputs and outputs and Boolean carries, E = a_i+b_i+c_i−r_i−256c_{i+1} lies in [−511, 511]. So the field equation is an integer equation whenever p > 511.

Telescoping over ℤ gives a+b = r + 2^128·c₁₆, with r < 2^128. Therefore c₁₆ = [a+b ≥ 2^128]. This matches `checked_add` and K `uiChecked`. The witness is unique, because each digit is a residue and each carry a quotient.

**SUB-i.** E lies in [−511, 511]. Telescoping gives a−b = r − 2^128·bo₁₆, so bo₁₆ = [a<b]. This matches `checked_sub`, `<` and `<Int`.

Lt enables SUB (enSUB = (selSub+selLt)·uu), so its remainder is forced and the borrow cannot be chosen freely.

**Hand checks (all agree with the candidate):**

| Specimen | Result |
|---|---|
| A-3 (255+1) | r₀ = 0, c₁ = 1, r₁ = 1 |
| A-4 (max+1) | all carries 1, c₁₆ = 1 → Err10 |
| A-5 (max+max) | r = [FE, FF×15], c₁₆ = 1 |
| S-2 (0−1) | r = [FF×16], bo₁₆ = 1 |
| S-3 (256−1) | bo₁ = 1, r = [FF, 00…] |
| L-1 (3<5) | r = [FE, FF×15], bo₁₆ = 1 |
| **L-4 (high byte)** | 2^120 − 255: byte 0 gives −255 → r₀ = 1, bo₁ = 1; bytes 1–14 give −1 → FF, borrow continues; byte 15 gives 1−0−1 = 0 → r₁₅ = 0, bo₁₆ = 0. r = [01, FF×14, 00] = 2^120 − 256 + 1 ✓. Result false ✓ |
| **L-5** | r = [FF, 00×14, FF] = 255·2^120 + 255 ✓, bo₁₆ = 1 → true ✓ |

### Mul (convolution, full high/low split, 12-bit carries)

**Column sums.** S_k ≤ 65025·m_k, where m_k = min(k+1, 31−k). The peak is S₁₅ ≤ 1,040,400, and S₃₁ = 0.

**Equation range.** With 12-bit carries admitted:
- E_max = 1,040,400 + 4095 = 1,044,495;
- E_min = −255 − 256·4095 = −1,048,575.

So |E| < 2^20 = 1,048,576. The exact requirement is p > 1,048,575. The stated p > 2^20 is slightly stronger and sufficient.

**Exactness.** Σ 256^k·(MUL-k), with c₀ = c₃₂ = 0, gives a·b = r + 2^128·h over ℤ.
- Uniqueness holds by forward induction from the fixed c₀ = 0: p_k is (S_k + c_k) mod 256, and c_{k+1} is the quotient.
- The 12-bit range is used only for integer-exactness.

**Carry bounds.**
- The inductive bound is c ≤ ⌊(1,040,400 + 4080)/256⌋ = 4080.
- The true maximum is 4079. Each carry is monotone in S_j, so the maximum occurs at max×max (k = 16). Both values are below 4096.

**M-6 (max×max) recomputed:**

| k | Value | Digit | Carry out |
|---|---|---|---|
| 0 | 65025 = 254·256 + 1 | p₀ = 1 | c₁ = 254 |
| 1–15 | 65280k + 65024 = 256(255k + 254) | p_k = 0 | c_{k+1} = 255(k+1) − 1 |
| 15 | 1,040,400 + 3,824 = 1,044,224 = 256·4079 | 0 | c₁₆ = 4079 |
| 16 | 975,375 + 4079 = 979,454 = 254 + 256·3825 | p₁₆ = FE | c₁₇ = 3825 |
| 17–30 (n = 31−k) | 65280n + 255 | FF | 255n |
| 31 | T = 255 | FF | c₃₂ = 0 ✓ |

- Result: r = [01, 00×15] and h = [FE, FF×15], which equals 2^128 − 2.
- Check: (2^128 − 1)² = 2^128(2^128 − 2) + 1 ✓.
- hSum = 4079 ✓.

**Other Mul specimens:**
- M-3: [01, FE] ✓.
- M-4: S₁₅ = 128·2 = 256, so c₁₆ = 1 and h₀ = 1 → Err10 ✓.
- M-5: S₁₆ = 1 → h₀ = 1 ✓.
- M-2: S_k = 255 for k ≤ 15, no carries ✓.

**hZero.** hSum = Σh_j ≤ 4080 < p. Since every h_j ≥ 0, Σh_j = 0 if and only if h = 0. So TestEq on hSum is exact.

### Branch separation (Err10 vs Err11)

**Selectors and enables.**
- The selectors are mutually exclusive because op is a single enum.
- uu ≤ en_ar.
- Each block enable multiplies uu, so uu = 0 zeroes every limb block.

**ovf.** At most one summand is nonzero:
- ADD.c₁₆ only under Add;
- selSub·bo₁₆, which masks Lt's borrow;
- enMUL − hZero, which lies in {0,1}.

**Branches.**
- bERR11 = en_ar − uu.
- bERR10 = ovf, which is a subset of uu.
- bLT = enLT.
- bOK = uu − enLT − ovf.

The branches sum to en_ar, each lies in {0,1}, and each holds if and only if its Rust/K match arm holds. Err11 can only arise from a sort failure, and Err10 only from overflow on two UInt operands. This matches the source `(op, UInt, UInt)` arm first, then `_ => Err(11)`.

### Fuel

**Probe.** isZero = en_evt·Π[f_i = 0].

**Partition.** A080 + A082 + A084 + cg = en_evt, with term = tRet0 + tErr (disjoint tags). This reproduces the Rust order at lines 46–66: Done before Rejected, Rejected before fuel-zero, and fuel-zero before the charged transition.

**FD-2 range.** E ∈ [−511, 256], and post is forced by pre and bw. Pre bytes need to be ranged; post bytes are forced and need no separate range for soundness.

**Hand checks:**
- F-1 (1 → 0) ✓.
- F-2 (65536 → 65535): bw₁ = bw₂ = 1 → [FF, FF, 00…] ✓.
- F-3 (2^120 → [FF×15, 00]) ✓.
- F-4 (max → [FE, FF×15]) ✓.
- **Free events before exhaustion:**
  - F-5a: A080 at f = 0 preserves fuel (Return with empty frames is matched before the fuel check).
  - F-7: A082 at f = 0 preserves fuel.
  - F-5b: A084 at f = 0 (Eval) preserves fuel.
- FD-3 is consistent: en_chg = 1 implies f ≠ 0, which kills the borrow.

### Local versus global field bound

**Local.** Each relation is lifted from 𝔽_p to ℤ by its own bound |E| < p:

| Relation(s) | Required |
|---|---|
| ADD, SUB, FD-2 | p > 511 |
| MUL-HS and the hZero TestEq | p > 4095 |
| MUL-k | p > 1,048,575 |

The 2^128 and 2^256 identities are telescoped at the meta level over ℤ and are never formed as field equations. That is why a field near 2^20 is enough for aux/2 itself.

**Global.** G4-FIELD (p > 2^20) is the maximum of those local bounds. It is a profile-wide requirement for aux/2. It is **not** a sufficiency claim for any composed step circuit, because:
- the existing A102 fragment uses `LessThan{bits:128}` for every lane maximum;
- the G4-FETCH index guard needs a comparator.

Both carry their own unknown field and ISA requirements.

## Inventory of everything added (no unbound truth, carry or oracle found)

**Columns.** Every column is listed with its forcing relation:

| Column(s) | Forced by |
|---|---|
| opL, opR | ARH-1 |
| nL, nR | ARH-2 via G4-FETCH, plus ZERO |
| selAdd, selSub, selMul, selLt | ARH-0 |
| uu | ARH-3 |
| ovf | ARH-5 |
| ltOut | ARH-6 |
| ADD.r, ADD.c | ADD-i, ZERO, RANGE |
| SUB.r, SUB.bo | SUB-i, ZERO, RANGE |
| MUL.r, MUL.h, MUL.c₁…₃₁ | MUL-k (32 equations, 63 unknowns; unique by range plus induction) |
| hSum | MUL-HS |
| hZero | MUL-HZ |
| z, zp | FP-1, FP-2 |
| bw | FD-1, FD-3 |

**Lane count.** The total of 232 logical lanes checks: 55 (header) + 32 + 32 + 65 = 184, plus 32 + 16.

**Inputs read:**
- pre: outcomeTag, controlLength, CR0.tag, CR0.valueRef, depth, FS0.tag, FS0.binaryOp, FS0.valueRef, remainingFuel bytes, D0, Data;
- program: K0, Constants;
- post: remainingFuel, Data[D0], activeData, CR0;
- envelope.charge.

All flags derive from pre and program. Post is only constrained.

**Premises:**
- G4-FIELD;
- G4-ISA-1 through G4-ISA-4;
- G4-FETCH;
- G4-BYTE;
- G4-APPEND;
- INV-TY-D and INV-TY-K;
- O1–O4;
- representation-domain byte ranges on pre fuel lanes;
- IO-1 through IO-8.

**Disabled branches and padding.** Disabled blocks are all-zero by ZERO and by the FD-1 chain, so there is no free witness on a disabled branch. Costs and caps are kept open, with no numbers.

**aux/1 prefix.** The aux/1 prefix is preserved by reference: the four schemas, their order and their enables are unchanged. aux/2 realizes the cg fuel conjunct and does not redefine cg.

## Defects and precise binding readings on unchanged bytes

None of these requires a new mechanism.

**E1 — inventory error (most material).**
- §9 and the manifest `fuel_rules` omit **A108** entirely.
- The text says "36 = 23 + 8 + 5", but the third group lists 4 rules (A153, A157, A204, A214). The lists cover only 35 charged plus 3 free rules.
- **Binding reading:**
  - A108 is charged (L4 `rule_line_tags` line 108, charge 1).
  - The `fuel_rules` lists are non-normative inventory.
  - The normative fuel relation is §5/§8 (en_chg, FD-1 to FD-4). It is rule-agnostic and covers A108.
  - The correct count is 36 = 23 + A108 + 8 + 4.
- No consumer may derive charge or FuelDec enablement from those lists. Per-tag charge stays with L4 O4 and P5.

**E2 — §9 wording.** §9 places the A153 successes in the column headed "Semantic-failure branches still charged". **Reading:** that column lists every charged A153 branch, not only failures.

**E3 — G4-ISA-3 status.** G4-ISA-3's status "Inferred from usage" is not evidence. **Reading:** it is UNKNOWN, like G4-ISA-1, G4-ISA-2 and G4-ISA-4.

**E4 — §10 carry and field-bound wording.** **Reading:**
- The inductive bound is 4080 and the attained maximum is 4079. Both are below 2^12.
- The exact field need is p > 1,048,575.
- The stated p > 2^20 remains the binding requirement.

**E5 — "No LessThan" scope.** "No LessThan" applies only to aux/2's own relations. **Reading:** the G4-FETCH guard comparator and the A102 fragment's 128-bit `LessThan` carry their own ISA and field requirements. G4-FIELD is necessary for aux/2, not globally sufficient.

**E6 — carrier serialization.** The 12-bit carriers are serialized as 2 byte lanes. **Reading:**
- aux/2's relations bind logical carriers only.
- Lane reconstitution (lo + 256·hi, with hi < 16) is part of G4-BYTE.
- No claim binds the serialized lanes before G4-BYTE.

**E7 — errata texts not supplied (IO-5).** **Reading:** adoption is subordinate to R2-1 and R2-3 through R2-6. Any conflict voids the conflicting aux/2 portion, and repairing it requires fresh bytes, not reinterpretation.

## Conditions on this vote

1. **Scope.** The vote covers only the arithmetic and fuel source relations on these exact bytes, with E1–E7 binding.
   - It does not cover P4, the spine, P5 dispatch or exactly-one selection, the native witness ABI, L04 or L05.
   - It does not cover Eq, Cons, Branch or A157 sort reads (IO-4).
   - It is not G4 operator certification.
2. **Requirements stay requirements.** G4-FIELD, G4-ISA-1 to G4-ISA-4, G4-FETCH, G4-BYTE and G4-APPEND remain requirements, not native evidence. Separately, INV-TY, D-NAMES and IO-1 to IO-8 remain open.
3. **No emitter acceptance yet.** There is no emitter acceptance until P3 condition 5 and IO-7 are met. Profile identity and dimensions must be bound into L04 (P3 condition 6) before any native use.
4. **C4 is unchanged.** No dependent circuit source edit happens before admitted A102 compilation. A compile failure means registration revert. The IO-3 equivalence with the A102 fuel chain is required afterward.
5. **Execution remains unrun.** Formal correspondence, K, Quint and Clean checks, the negative checks N1–N16 and all native execution remain **UNRUN**. None is demanded or authorized.
6. **Prior bindings retained.**
   - full39 conditions 1–10 and F1–F7;
   - P3 conditions 1–8;
   - errata R2-1, R2-3, R2-4, R2-5 and R2-6;
   - the Muse R2-4 dissent, preserved verbatim in both prongs;
   - native authority 0;
   - the old 90s/30s caps, counters and terminal failures;
   - the full roadmap, unchanged.
7. **Votes needed.** This is one fresh substantive vote. A second fresh substantive vote (Muse normal audit of these exact bytes) and a Root adoption record are still required. No historical vote transfers. Any byte change voids this vote for the changed bytes.

No adoption, grant or execution authorization is made here.

**ADOPT_COMPLETE_ARITHMETIC_FUEL_SOURCE_WITH_CONDITIONS** — candidate manifest `42d45bd3bea826469408a774984318d1ae473b82636ae5f32c0bf4ca8b23c6a2` (DESIGN `88887f1d…13c3`, MANIFEST `63182dc1…df4f`, OWNER-RESULT `4d99c6ed…767f`), subject to errata E1–E7 and conditions 1–7.