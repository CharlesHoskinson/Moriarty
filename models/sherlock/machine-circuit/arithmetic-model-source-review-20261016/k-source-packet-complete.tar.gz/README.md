# Arithmetic and fuel K source projection

This source-only projection follows the exact adopted arithmetic/fuel design
`42d45bd3bea826469408a774984318d1ae473b82636ae5f32c0bf4ca8b23c6a2`, under Root
adoption `921176b271ea1aec27877a59eed703a7b539e1c9ef6e2de144ffbb217d5ffc64`
and both complete source reviews. Those votes do not approve these new K bytes.
The frozen append-model publication checkout was read only. No circuit, Rust,
existing model or source-profile file changed.

The callable source predicates are `afArithmetic(op,leftType,left16,rightType,
right16)` and `afFuelAttempt(outcomeTag,controlLength,controlView,depth,fuel16,
initialFuel16)`. They are pure mathematical reference functions. Two request
rewrites expose the same functions through the `P4-ARITHMETIC-FUEL` module.
They are not accepted current-A machine transitions, native constraints, or a
validator of arbitrary supplied witnesses. K parsing, compilation, execution,
proof and all 33 positive checks remain UNRUN.

## Scope and explicit adapters

| Current source/design fact | Projection |
|---|---|
| A153 op tags Add=0, Sub=1, Mul=2, Lt=4 | Arithmetic op argument accepts exactly these four tags |
| Left operand is Right-frame value, right operand is returned control value | Request left/right argument order; caller projection obligation, no frame fetch implemented |
| UInt has typeId=0; Bool/List/Tree are 1/2/3 under INV-TY | Explicit already-fetched type IDs; non-UInt pair gives the normal semantic Err11 |
| UInt uintBytes are exactly 16 LE bytes | afWord requires length16 and every lane in 0..255 |
| ADD/SUB | Sixteen local recurrences; complete result plus 17 carry/borrow endpoints |
| MUL | 32 convolution columns; all i,j in 0..15 with i+j=k; 16 low plus 16 high bytes and 33 carry endpoints |
| Lt | Same full subtraction remainder/borrow as Sub; only the semantic result is Bool(last borrow) |
| Overflow | Err10 with full remainder/high diagnostics retained; no StateBlock append modeled |
| Ten current control tags | Ten AFControl constructors; nonterminal payloads erased, Return payload and Error code retained |
| Pending and controlLength>0 | afEvent; no charged-rule inventory lookup |
| Done / Rejected before zero-fuel exhaustion | afRegime derives terminal priority, then Exhausted or Charged |
| FuelProbe z/zp and FuelDec bw | Complete 16 z values, 17 prefix endpoints and 17 borrow endpoints |
| Remaining fuel / initial fuel | Full 16-byte post and unchanged full 16 initialFuel in AFFuel |

This is a semantic projection, not a new source representation or witness ABI.
It erases ProgramBlock, refs, node metadata other than type/bytes, full frames,
environment, arenas, other control payloads and other Root cells. It does not
implement G4-FETCH, en_bin binding, node kind/type/constructor consistency,
append/capacity, POP/W1, exact rule dispatch or preservation of a full Snapshot.
A requester must supply the stated already-fetched view; there is no importer
from Rust/K/main.k, no profile parser and no executed cross-layer adapter.

P-1-values-only checks the paper's 7+5 arithmetic projection. Constant/Data
spaces, indexes C0/D2 and their fetches are deliberately not claimed tested.
T-1/T-2 retain the normal semantic type-failure result while erasing the
non-UInt value payload. Eq, Cons, Branch and A157 operations stay outside this
module; no model cases or claims are supplied for their arithmetic disablement.

AFValue preserves UInt bytes and Bool directly. `afOpaque(2|3,token)` is only
an uninterpreted List/Tree publication token; it does not decode those values
or establish their semantic equality. None of the normal cases uses opaque
payloads. Error payloads accept the complete u8 range in the projection domain,
but the normal publication specimens use code4 only.

The domain predicates check projected shapes/ranges, not all L4 O1–O4 or
Snapshot invariants. In particular they do not prove fuel<=initialFuel, a
control-spine shape, depth consistency or the prohibition on Pending/None.
`afNoEvent` means the formula's event enable is zero; it is not a MachineOutcome.
`afCharged` means that the fuel relation decrements; it does not select a rule
or compute that rule's nonfuel successor. All other state/continuity obligations
remain outside the projection.

## Mathematical implementation and outputs

The model uses mathematical K Int for local scalar operations, with the full
fixed 16-byte input domain. It never substitutes smaller-word fixtures or
packs a full UInt into a single field element. `afQuot256` and `afRem256` are
explicit recursive subtraction definitions, so no undocumented K division or
remainder helper is assumed. Their host evaluation cost and recursion behavior
are unmeasured; no model execution/resource admission follows from this source.

`afAdd` and `afSub` structurally recurse over all 16 lanes. Sub locally adds256
only when its signed difference is negative. `afMul` computes every column
0..31, with the last column's product sum zero. All carry endpoints are visible,
including c0 and c32. The function computes honest recurrence outputs; it does
not check an adversarial supplied carry, prove the 12-bit bound or constrain a
native field. No precomputed expected vectors are consulted by implementation.

AFArith's exact field order is outcome, ADD.r, ADD.c[0..16], SUB.r,
SUB.bo[0..16], MUL.r, MUL.h, MUL.c[0..32], hSum, hZero. Disabled arithmetic
blocks are explicit zero vectors. hZero is1 only for enabled multiplication
with a zero high half; other blocks have zero hSum/hZero. An overflow preserves
the diagnostic arrays even though its semantic result is Error 10. These error
terms describe checked primitive results, not publication or tooling Capacity.

AFFuel's field order is regime, charge, postFuel16, initialFuel16, z[0..15],
zp[0..16], bw[0..16]. Prefix endpoint0 is en_evt; borrow endpoint0 is en_chg.
The functional recurrence computes post_i=pre_i-bw_i+256*bw_(i+1). Terminal
publication derives zero charge before consulting whether fuel is zero. For
charged requests a nonzero byte stops the borrow. On free requests every borrow
endpoint is zero and the original fuel bytes are preserved.

Endpoint-inclusive diagnostic vectors are intentional: aux/2 serializes only
ADD/SUB endpoints1..16, MUL endpoints1..31, zp1..16 and bw1..16. This model does
not serialize those columns or bind the diagnostic endpoint fields as new wire
lanes. It adds no profile/statement field or dimension.

## Independent expectations and normal source checks

`expected.json` was frozen before either `.k` file existed. Its 23 arithmetic
and 10 fuel cases transcribe the paper specimens independently of model source.
`EXPECTATIONS-FIRST.json` pins that data and records the absent implementation
and check files at freeze time. No new Quint source or results were read.
The same author transcribed these expectations and authored this K source;
this is not an independent-author oracle or a completed oracle audit.

The normal K checks compare the complete result terms, including every disabled
block and all carry endpoints. Expected sides contain only literal constructors
and scalars, no implementation helpers. `examples/` supplies each request and
complete expected term; CASE-INDEX maps them to the checks. The mechanical
JSON-to-K literal formatting performs no arithmetic recurrence or model
execution and introduces no new expected values.

Coverage includes all A-1..5, S-1..4, L-1..5 and M-1..6 specimens, T-1/T-2
normal semantic type failures, and the value-only projection of P-1. In M-6,
the complete 33 carry endpoints are:

`[0,254,509,764,1019,1274,1529,1784,2039,2294,2549,2804,3059,3314,3569,3824,4079,3825,3570,3315,3060,2805,2550,2295,2040,1785,1530,1275,1020,765,510,255,0]`.

The expected low half is `[1,0×15]`, high half `[254,255×15]`, hSum 4079,
hZero 0 and Error 10. The closed identity is
`(2^128-1)^2 = 1 + 2^128*(2^128-2)`; it is paper reasoning, not an executed
comparison. High-byte Lt includes both directions and the entire otherwise
unstored remainder. Sub underflow retains sixteen255 bytes and every borrow.

The fuel suite includes F-1..F-8 with F-5a/F-5b separate: charged1→0,
65536→65535, 2^120 decrement, max decrement, zero-fuel Done, zero-fuel
Exhausted, Error publication at positive/zero fuel, and charged primitive-error
propagation. It compares all z/zp/bw entries and preserved initialFuel bytes.
F-5a/b use the independently specified zero state following F-1; they are not
an executed linked trace. F-3's ERR10 and F-8's A225 labels are paper-context
annotations; the fuel request does not compute those primitive/control steps.

E1/E-FUEL is explicit: charged inventory 24+8+4=36, including A108; free lines
80/82/84. FUEL-INVENTORY.json compares those39 line/charge pairs to the actual
L4 crosswalk as JSON data. No K function consumes that list. E-FUEL-A108 uses
the same Eval fuel view as the paper's bound-variable step; it checks the
formula projection, not a lookup or a rule-tag/charge binding. IO-1 remains.

All33 checks are UNRUN. A future harness must require exactly
`afCheckedNormal(true)` for the normal entry, and exact complete terms for
request rewrites. False, a stuck/unreduced term, absent output or a timeout
cannot count as a successful check. Pure-function checks and request rewrites
are separate proposed paths; neither has an executed harness here. There are
no malformed/security/hostile cases and no N1–N16 implementation. Uncovered
cases include disabled events, most control constructors/error codes, opaque
payload publication and arbitrary word pairs. Finite positives would not prove
general arithmetic, whole-machine, cross-model or native correspondence.

## Imports, source grounding and unresolved tool closure

`arithmetic-fuel.k` requires `domains.md`; its syntax module imports
DOMAINS-SYNTAX, its functions module imports its syntax and DOMAINS, and its
request module imports the functions. `normal-checks.k` requires that local
file; its functions import only the arithmetic/fuel functions, and its request
module imports only its own check functions. Main request and normal request
configurations are separate modules, not imported into each other.

The syntax idioms are grounded in pinned repository main.k and the published
ValueSlots model: custom inductive sorts, `[function]` definitions, guarded
rules, K Int/Bool operators, `==K`, modules/imports and a single `<k>` cell.
Every newly named `af*` helper is defined in the supplied source. The model
does not import main.k or its evaluator as its expected-output producer.

Actual K executable/version/installation and `domains.md` path/hash remain
UNKNOWN. The historical main.k README's K7.1.337 draft label is not installed
tool evidence. No tool detection, help, parser or setup was run. No exact
executable command is proposed without that closure. Minimum next evidence is
a separately reviewed read-only identification of the intended tool and complete
domain source closure, then classification of an exact pinned source-only
frontend or model command and its bounded environment. No such admission is
made here. C4 does not grant a model or compiler run.

## Preserved owner and normal conditions

The full design, manifest, adoption and fresh reviews are frozen under inputs/
and reviews/. Historical UNADOPTED labels are retained as author-time facts.
Every E1–E7 reading and owner condition1–7, Muse E-FUEL and condition1–6 remains
binding. In particular:

- E1/E-FUEL correct only the inventory; the normative enable is §5, not a list.
- E2 treats A153's listed branches as charged successes as well as failures.
- E3 keeps every G4-ISA status, including ISA-3, UNKNOWN.
- E4 distinguishes bound 4080, attained maximum 4079 and binding field p>2^20;
  the exact local requirement p>1,048,575 is not an observed native fact.
- E5 limits “no LessThan” to aux/2; G4-FETCH and A102 still have their own needs.
- E6 leaves 12-bit carrier LE reconstitution/high4-bit checks with G4-BYTE.
- E7 keeps adoption subordinate to exact P3 errata, with conflicts requiring
  fresh bytes; copying those prior records does not discharge IO-5.

G4-FIELD/ISA1–4/FETCH/BYTE/APPEND, INV-TY/D-NAMES and IO1–8 remain open.
No P4 spine/P5 dispatcher, append mechanism, profile identity binding, L04/L05,
F4/MD2/StepInv/chaining, Eq/Cons/Branch/A157, B/generalADT/financial, proof,
ledger or Midnight stagenet acceptance is supplied. Full39 conditions 1–10/F1–F7,
P3 conditions 1–8, errata R2-1/3/4/5/6 and the complete Muse R2-4 dissent remain.
Native authority 0, C4 and registration revert on admitted compile failure,
old 90s/30s caps/counters/terminal failures and every roadmap exit are unchanged.
Fresh owner and Muse review of these exact new model sources is still required.
