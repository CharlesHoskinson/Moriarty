# Arithmetic/fuel K projection — frozen source only

Implemented standalone K source for full 16-byte checked Add/Sub/Lt, 32-column
Mul with both 16-byte halves and all 33 carry endpoints, and the exact charged
versus terminal/free fuel formula. The projection returns complete arithmetic
and fuel diagnostic records. It includes two model request rewrites and 33
whole-term literal normal checks. Every K parse, compile, run and check is UNRUN.

The source-adoption input is exactly
`921176b271ea1aec27877a59eed703a7b539e1c9ef6e2de144ffbb217d5ffc64`.
Both complete reviews and owner E1–E7/Muse E-FUEL are retained. The corrected
24+8+4 charged inventory, including A108, matches the 39 L4 line/charge rows by
JSON-data comparison. It is documentation data, never a dispatch/enable input.

Independent literal data was frozen before either K source file existed:
`expected.json` SHA256
`e6091f3f571803e2869df4f224ed8780c48bb1c8a9b430cd427321b715c3bbbb`.
It covers 23 arithmetic and 10 fuel cases from the paper specimens, including
carry overflow, complete subtract-underflow remainder, both high-byte Lt
directions, max×max low/high and all 33 carries, charged decrement and zero-fuel
terminal precedence. No new Quint implementation/results were read or used.
The same author prepared expectations and implementation; separate independent
author/oracle review has not occurred.

The exact implementation boundaries are explicit: operands are already-fetched
type/byte views; fuel uses an abstract control view. It does not perform
Constant/Data fetches, full source transitions, append/capacity operations,
POP/W1, rule-tag binding or full Snapshot preservation. A108's case checks the
rule-agnostic Eval fuel projection, not lookup or A108 selection. InitialFuel
is preserved as all 16 supplied bytes. Diagnostic endpoint0/32 fields are not
additional aux/2 serialized lanes. No native witness ABI is selected.

The only source invocation was the authorized startup status command with
python3 -B, exit 0. Data operations copied/hashes sources and formatted literal
JSON values as K constructors; they did not evaluate model arithmetic or
candidate code. Text checks bind every complete expected term to its normal
case and confirm all 33 copied inputs unchanged. They establish no syntax,
typechecking, runtime outcome or proof.

The read-only frozen checkout HEAD was
`2afbabdc27984015979ef952dad89ce350f2450a`. No checkout or old packet was edited.
The complete packet is under the new exclusive runtime directory only.

K executable/version and domains.md path/hash remain UNKNOWN. No install,
help/version/probe or exact runnable command was attempted. A future command
needs separately reviewed tool/domain closure and classification. Recursive
reference division helpers have unmeasured evaluation cost. The future check
must require exactly afCheckedNormal(true); stuck terms are not successes.

Fresh full Opus owner and Muse normal source audits remain required. All
G4-FIELD/ISA/FETCH/BYTE/APPEND and IO1–8, full39/P3/L4 conditions, Muse R2-4
dissent, StepInv/canonicality/F4/MD2/L04/L05, financial/proof/ledger/target and
all roadmap exits remain open. Native authority remains 0. C4, registration
revert on admitted compile failure, and old 90s/30s caps/counters/terminal
failures are unchanged. No dependent circuit edit or execution admission was
made. Existing Rust tests remain UNRUN.

Requested author routing: GPT-6 Astra high. Actual author: assigned agent
/root/astra_sdk_compile_diagnosis; no separate provider canonical-identity
receipt is exposed for this turn.
