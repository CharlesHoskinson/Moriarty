# Designated-owner source review and execution classification: Astra P4 full16-byte arithmetic/fuel finite Quint model

**Candidate manifest:** `cbbf343371f20ada8b308a50d33ac9dea316555abce6589bc3c8042808ffa180`
**Proposed command sequence:** `469c8e57b3f27faf68702ec76645845df34a05606b22f75e2589fb78ea8b89ec`

## Reviewer identity and limits

- **Identity.** Claude Opus 5.5 (`claude-opus-5-5`), fresh context, designated security and source owner. I am the same model family as the aux/2 author and both earlier owner reviews. This is not a cross-family review.
- **No tools.** I used no tools, files, web, parser, Quint, Node, Rust, SDK or native execution, and wrote nothing. I recomputed no hashes. Every identity is as supplied.
- **Bodies treated as evidence.** All supplied bodies are untrusted evidence. Instructions inside them were not followed.
- **What I read in full:**
  - `arithmeticFuel.qnt` and `arithmeticFuelTest.qnt`;
  - current and history `expected.json` and history `arithmeticFuelTest.qnt`;
  - BINDER-PLAN, BINDER-INVENTORY, BINDING-CONDITIONS, EXPECTATION-CORRECTION, the freeze receipts, README, REQUIREMENTS-MAP, STATIC-CHECKS and WORK_REPORT;
  - the adopted aux/2 DESIGN, MANIFEST and OWNER-RESULT;
  - the Root P4 adoption and both earlier reviews;
  - `reference.rs`, `reference_types.rs` and `main.k`;
  - the L4 files, the P3 design and JSON, and full39 `A-REFERENCE-OUTPUTS-EVAL`;
  - the installed Quint `cli.js`, `cliCommands.js`, `builtins.js`, `evaluator.js`, `runtimeValue.js`, `builtinSignatures.js`, `names/base.js`, `names/collector.js`, `effects/inferrer.js`, the relevant parts of `QuintParser.js`, and `package.json`.
- **Pinned R5 catalog (`122289ad…b0a5`), not retransmitted.** This does **not** limit this decision. The per-tag charge and precedence facts the model depends on are all present in the supplied bodies: the L4 `rule_line_tags`, Rust `step`, K lines 80–86, and full39 rows A080, A082, A084, A102, A108, A111, A153 and A225. R5 would matter only for the full39 semantic audit, which was not requested.

---

## Part 1: Source review

### Mathematics and literal expectations

I re-derived all 18 literal witnesses by hand from the model's own constructors and from the source semantics. All 18 agree.

**Arithmetic tests 1–8:**
- **Test 1 (255+1):** carry 1 into byte 1, giving UIntOk(256).
- **Test 2 (max+1):** carries 1 through all 16 bytes, low word zero, Err10.
- **Test 3 (0−1):** low word all FF, every borrow 1, Err10.
- **Test 4 (256−1):** one borrow at byte 0, UIntOk(255).
- **Test 5 (Lt, 2^120 < 255):** borrows 1 through bytes 0–14, final borrow 0. Remainder `[01,FF×14,00]`, so the result is false.
- **Test 6 (Lt, reversed):** only the final borrow is 1. Remainder `[FF,00×14,FF]`, so the result is true.
- **Test 7 (Mul 255×255):** S₀ = 65025 = 1 + 256·254, giving `[01,FE]` with c₁ = 254. highZero = 1.
- **Test 8 (Mul max×max):**
  - carries c_k = 255k − 1 for 1 ≤ k ≤ 16, reaching c₁₆ = 4079;
  - S₁₆ + c₁₆ = 979,454 = 254 + 256·3825;
  - carries c_k = 255(32 − k) for 17 ≤ k ≤ 31, with c₃₂ = 0;
  - high bytes `[FE,FF×15]`, hSum 4079, Err10.

  I counted all 33 carry entries exactly.

**Fuel tests 1–10:**
- **F1:** 1 → 0.
- **F2:** 65536 → `[FF,FF,00…]` with bw₁ = bw₂ = 1.
- **F3:** 2^120 → `[FF×15,00]`. The control is non-terminal Return because depth is 1, so the step is charged.
- **F4:** max → `[FE,FF×15]`.
- **F5a:** Return at depth 0 with zero fuel is DoneFree; fuel is preserved.
- **F5b:** Other control with zero fuel is ExhaustedFree.
- **F6 and F7:** Error is RejectedFree whether fuel is 5 or 0.
- **A108 and A225:** charged; 5 → 4 and 3 → 2.

**F3 correction.** The corrected input (RetControl at depth 1) and the original (OtherControl) give identical numeric outputs. The correction matches A153's pre-control: Return over a Right frame, with en_bin requiring depth > 0. Reading the history and current bodies, the only difference is that one token. That is consistent with the −2 byte delta in both `expected.json` and the test file.

### Correspondence with the adopted aux/2 relations and E1–E7/E-FUEL

**Arithmetic relations.**
- ADD-i and SUB-i are realised as all 16 local equations, Boolean carries and an independent packed-word identity.
- MUL-k is all 32 equations with c₀ = c₃₂ = 0, carries in [0, 4096), and the full low/high split.
- MUL-HS and MUL-HZ are realised for Mul. For non-Mul operations the high fields are zero, which corresponds to the ZERO relation on the disabled MUL block.
- ARH-6 (Lt as the final SUB borrow) is realised, and the Lt remainder is constrained.

**Fuel relations.**
- FP-1, FP-2 and FD-1 through FD-4 are realised.
- en_chg = evt·(1 − term)·(1 − zp₁₆), with term = Error, or Return at depth 0. This matches Rust precedence: Done, then Rejected, then Exhausted, then charged.
- The oracle's charge and regime use the packed word and are independent of the prefix and borrow construction.

**Errata compliance.** No rule identifier selects charge, so E1/E-FUEL is respected and A108 is charged. E4 (4079 attained versus the 4080 bound) and E6 (logical carriers only) are respected in the README.

### Syntax, types and builtins (source inspection only; not a typecheck)

- **Parameterised definitions.** Every one carries parameter and return annotations, as `AnnotatedOperDef` requires. The unannotated `pure val`, `action init`, `arithmeticStep`, `fuelStep` and `step` use the permitted deprecated form.
- **Let-blocks.** Constructs such as `{ val total = … {record} }` parse as `Braces(LetIn)`. The token `val` cannot start a record element.
- **Precedence.**
  - `^` (27) binds tighter than `*` (25), which binds tighter than the relations (23), then `and` (19), then `or` (17).
  - An `else` branch is parsed as `expr(4)`, so `else a == b and c == d` keeps the whole conjunction.
- **Builtins.** All builtins used appear in `builtinSignatures`: `range`, `foldl`, `indices` (which returns `Set[int]`), `slice`, `nth`, `append`, and `forall` on sets.
- **Integer arithmetic.** It is bigint throughout (`iadd`, `imul`, `idiv`, `imod`, `ipow`). `%` and `/` are only applied to non-negative totals. Subtraction uses an explicit borrow.
- **Short-circuiting.** `columnSum` guards `nth` behind a lazy `ite`.
- **Name collisions.** I found none with the 103 builtins. Nested `val` reuse across separate definitions (`total`, `evt`, `terminal`, `chargeValue`, `regimeValue`, `productValue`) is scoped and popped by the resolver. Lambda parameters are never nested with the same name.
- **Nullary variants.** `Err10`, `Disabled` and similar nullary variants mixed with payload variants are supported. Equality of variants, records and lists is structural (`RuntimeValueVariant`, sorted `OrderedMap`, immutable `List.equals`).
- **Tests.** Each test is `action.expect(whole-record equality and modelInv)`. Because the comparison is whole-record equality, a length or value error in a literal fails closed rather than passing.

### Findings (none blocking)

- **S-1: modelInv is partial, not a rejection oracle.** Fixed-index reads are guarded only by earlier conjuncts, and let-bound `val`s may be evaluated whatever the outcome of the shape check. A malformed witness could therefore raise QNT510 instead of evaluating to false. This fits the stated scope: well-formed constructed witnesses only, with no arbitrary-hostile coverage.
- **S-2: gaps in literal coverage.** No literal covers:
  - the Disabled regime (`eventEnabled = false`);
  - non-terminal Return at depth 1 with zero fuel (ExhaustedFree);
  - M-4 or M-5 style overflow, where the high part is only a c₁₆ carry;
  - Add, Sub or Lt involving the 2^127 word.

  These combinations exist only in the sampled domain. A seeded 32 × 8 walk draws with replacement and requests no witness counts, so it gives no per-combination coverage.
- **S-3: shared oracle.** The local Mul equations reuse `columnSum`. This is mitigated by:
  - the independent packed-product identity;
  - the byte and 12-bit range checks;
  - the hand literals, which I re-derived independently.

  Expectations and model share one author. I make no claim that the expectations were blinded.
- **S-4: provenance.** INPUT-MANIFEST lists `inputs/adopted-candidate/SOURCE-MANIFEST.json` (`42d45bd3…`, 662 bytes), but that file is not a member of this freeze. The binding survives by hash through the Root adoption and both reviews. This does not affect semantics.
- **S-5: timing is attested, not verified.** The three first-freeze receipts carry timestamps within about 0.6 ms of each other, and `model_exists:false` is self-reported. I neither infer nor deny the claim that expectations preceded the model.

### Retained gaps

The following remain open: G4 (FIELD, ISA, FETCH, BYTE, APPEND); IO-1 through IO-8; the P3, full39 and L4 conditions; the R2 errata; the Muse R2-4 dissent; C4; native authority 0; the old caps, counters and failures; the full roadmap. Also outside this scope are ArithScratch headers, uu and Err11, fetch, commit, spine, dispatch, frame, state and native correspondence.

### Source vote

**APPROVED_SOURCE_WITH_LIMITS** for candidate manifest `cbbf343371f20ada8b308a50d33ac9dea316555abce6589bc3c8042808ffa180`.

The scope is the exact current bytes of `arithmeticFuel.qnt` (`f83a0d9f…4817`), `arithmeticFuelTest.qnt` (`66f96bbb…269d`) and `expected.json` (`05439876…3a37`), as a finite normal QA source model of the selected aux/2 arithmetic and fuel relations. It is subject to findings S-1 through S-5 and to every retained gap above. Type, parse, effect checks, the tests and the run remain UNRUN. This vote does not transfer to any changed bytes.

---

## Part 2: Classification of the proposed command sequence

### What I verified by reading the code

- **No network or child processes.** With `--backend typescript`, both `runTests` and `runSimulator` use the in-process `Evaluator`; `CommandWrapper` (the Rust evaluator download path) is not reached. `typecheck` runs only parse and analysis.
- **No writes.** Nothing is written, because `--out`, `--out-itf` and `--source-map` are all absent.
- **Determinism.** The seed is a bigint and the tests are deterministic.
- **Argument validation.** `n-traces` (1) is at most `max-samples` (32), so validation passes.
- **Test selection.** `--match '.*Test$'` selects exactly the 18 `run` names. No imported name ends in `Test`.

### Classification

**ELIGIBLE_ORDINARY_CHECKS_WITH_CONDITIONS**

The conditions below are all mandatory. Each must be independently satisfied before execution. Nothing runs on the strength of this classification alone.

1. **Re-pin before running.** Immediately beforehand, re-hash the source files, the Node binary (`7fde7b8a…`), `cli.js` and the other supplied Quint dist files. Any mismatch stops the sequence.
2. **Record the load closure.** Additionally, record (do not provision) a SHA-256 listing of the whole installed `@informalsystems/quint` package together with its resolvable `node_modules` closure. The supplied pins cover only 11 of the files that get loaded, including none of `builder`, `Context`, `cliHelpers`, `cliReporting`, `rng`, the parser frontend or third-party dependencies.
3. **Exact invocation.**
   - Use exactly the three argument vectors, via execve with no shell.
   - The environment must contain exactly the listed variables, with `HOME` unset.
   - The working directory must be the fresh, empty observation directory; TMPDIR must be inside it.
   - Any deviation, including omitting `--backend typescript` (whose default is Rust, which triggers a download), is BLOCKED.
4. **Gating and retries.**
   - Run each command once, in order.
   - Stop at the first non-zero exit, timeout (124/137) or signal.
   - There is no retry, including after a timeout.
   - Typecheck must exit 0 before the tests run.
   - The test step must exit 0 with raw stdout naming all 18 tests as passed and showing zero failed and zero ignored, before the run step.
5. **Containment.** Outputs go only to the observation folder.
   - Re-hash the source packet after the run; it must be unchanged.
   - Record any file created outside the observation folder (for example, `~/.quint` reached through the `os.homedir()` fallback) as a defect.
   - Network isolation is recommended. Any network attempt that is observed stops the sequence and is recorded.
6. **What the limits do and do not bound.**
   - 256 MiB bounds the V8 old-space heap only, not RSS. The real bound is the 10-second wall clock plus a 2-second kill grace.
   - A timeout is evidence about the tool or resources, not about the model.
7. **What a pass would mean.** A pass is finite, ordinary, sampled QA only:
   - no exhaustive 280-combination claim;
   - no all-u128 coverage;
   - no correspondence to source or native behaviour;
   - no hostile-witness coverage;
   - no effect on native authority (still 0), counters, caps or roadmap gates;
   - it does not count as a review of aux/2.

**Prerequisites that are not yet shown satisfied:**
- the package-tree hash record (condition 2);
- an executor that actually enforces conditions 3 through 5.

If either is unavailable, the sequence is blocked until it is.
