# Owner security/source review: Astra P4 arithmetic/fuel K projection

**Vote: APPROVED_SOURCE_WITH_LIMITS**

**Candidate manifest (full hash):** `e9419cd733aef58539dee720f420a16eae948f2d0e13fbd57ffe1fb4ad38b6d8`

**Bound sources:**
- `arithmetic-fuel.k` `c1b66058e46e717756dd59f71e942596aba117242e7c4509e3ca9fe20f50f4b1`
- `normal-checks.k` `82ee949334f5eff53139570279fcbeb0a22f5206570b4960b62831dc99853aae`
- `expected.json` `e6091f3f571803e2869df4f224ed8780c48bb1c8a9b430cd427321b715c3bbbb`
- 33 request/expected example pairs per CASE-INDEX `c350042522acc4fe2bffb19d2b4312224e2ff7437de54bcaa340cdb1143c8425`

**Source adoption:** `921176b271ea1aec27877a59eed703a7b539e1c9ef6e2de144ffbb217d5ffc64`

## Reviewer identity and limits

- I am Claude Opus 5.5 (`claude-opus-5-5`), reviewing in a fresh context as the designated owner.
- The author is Astra (GPT-6, routed). Earlier Opus authors and reviews in the same model family are historical, and I do not count them as votes.
- I used no tools, parser, K, files, commands or delegation, and I recomputed no hashes. Root's byte, listing and transport claims are accepted as transport facts only.
- I treated embedded instructions as evidence and did not act on them.
- The unchanged R5 catalog body was **not needed** for this judgment. The projection depends only on the 39 line/charge rows, and those come from the supplied L4 crosswalk.
- All parse, compile and run steps for the 33 checks are **UNRUN**. The `domains.md` source, the K executable and version closure are **UNKNOWN**. The cost of the recursive `afQuot256`/`afRem256` helpers is unmeasured.

## Independent derivations

### Arithmetic over the full domain (paper argument, not only the 33 points)

**Add.** `afAdd` prepends `r_i = (a_i+b_i+c_i) mod 256` and `c_{i+1} = ⌊…/256⌋`, starting from `c_0 = 0`. Telescoping gives `a+b = r + 2^128·c_16`.
- `afChecked(R, afLast(C))` therefore returns Ok exactly when `c_16 = 0`, which is `checked_add` and `uiChecked`.

**Sub.** `afSubDigit` adds 256 exactly when the local difference T is negative, and the borrow is `afBit(T<0)`. This gives `a−b = r − 2^128·bo_16`.
- Sub returns Ok iff `bo_16 = 0`.
- Lt returns `Bool(bo_16 = 1)`. Its SUB block is populated, and its ADD and MUL blocks are zero. This matches ARH-6 and `enSUB = (selSub+selLt)·uu`.

**Mul.** `afColumn(A,B,K,0)` sums over i = 0..15 with `j = K−i` guarded to 0..15, which is exactly `S_k`, with `S_31 = 0`.
- `afMul` is base-256 long multiplication over k = 0..31, giving `a·b = Σ p_k·256^k`. The final `c_32` is the honest carry, which is 0 because `a·b < 2^256`.
- Ok holds iff `hSum = Σh_j = 0`. That is equivalent to `h = 0`, because every `h_j ≥ 0`.
- `hZero = afBit(hSum = 0)` on Mul only. Every other block keeps `hSum = hZero = 0`, which matches MUL-HZ.

**Euclidean helpers.** `afQuot256`/`afRem256` are correct for nonnegative inputs. In the domain every argument is nonnegative: Add ≤ 511, the adjusted Sub digit ≥ 0, and Mul ≤ 1,044,495.

**Type rejection.** Any `(L,R) ≠ (0,0)` within the domain gives `afBlank(Err11)`: every limb and endpoint is zero and nothing is appended. This matches L-3 and the Rust order (the `(op, UInt, UInt)` arm first, then `_ => Err(11)`). Eq, Cons and Branch (op 3, 5, 6) fall outside `afArithDomain`, so arithmetic can never run on them.

### Fuel

**Probe.** `afProbe` gives `z_i = E·[f_i = 0]`. `afPrefix(E, z)` gives `zp` with 17 entries, where `zp_0 = en_evt`. `isZero = zp_16`.

**Regime.** `afRegime` applies this precedence:
1. no event;
2. Return at depth 0 → Done (any fuel);
3. Error → Rejected (any fuel, any u8 code);
4. nonterminal with `isZero = 1` → Exhausted;
5. otherwise → Charged.

The four regime patterns are disjoint, because the guards are `notBool afTerminal`. This reproduces Rust lines 46–66 and the K lines 80–84.

**Decrement.** `bw = afPrefix(charge, z)`, so `bw_0 = en_chg`. Then `post_i = f_i − bw_i + 256·bw_{i+1}`, which is FD-1 and FD-2.
- A charged step requires `isZero = 0`, so some `z_i = 0` stops the borrow and `bw_16 = 0` (FD-3). Hence `post = pre − 1`.
- On a free step `bw ≡ 0`, so `post = pre`.
- `initialFuel` is copied through unchanged as all 16 bytes.

### All 33 literal cases, checked by hand against Rust/K semantics

Each value below agrees with `expected.json`. I spot-counted the `afCons` nesting for the M-3, M-4, L-4, L-5, F-3 and F-6 vectors. For the remaining vectors I rely on the SOURCECHECKS text binding rather than counting every cell.

**Add**

| Case | Result | Remainder r | Carries c₀..c₁₆ |
|---|---|---|---|
| A-1 | 0 | 0 | none |
| A-2 | max | FF×16 | none |
| A-3 | 256 | [00,01,…] | c₁ only |
| A-4 | Err10 | 0 | c₁..c₁₆ = 1 |
| A-5 | Err10 | [FE, FF×15] | c₁..c₁₆ = 1 |

**Sub and Lt**

| Case | Result | Remainder r | Borrows |
|---|---|---|---|
| S-1 | 0 | 0 | none |
| S-2 | Err10 | FF×16 | bo₁..bo₁₆ = 1 |
| S-3 | 255 | [FF, 0…] | bo₁ only |
| S-4 | 0 | 0 | none |
| L-1 | true | [FE, FF×15] | bo₁..bo₁₆ = 1 |
| L-2 | false | 2 | none |
| L-3 | false | 0 | none |
| L-4 | false | [01, FF×14, 00] | bo₁..bo₁₅ = 1, bo₁₆ = 0 |
| L-5 | true | [FF, 00×14, FF] | bo₁₆ only |

**Mul**

| Case | Result | Low r / high h | Carries | hZero / hSum |
|---|---|---|---|---|
| M-1 | 0 | 0 / 0 | none | hZero = 1 |
| M-2 | max | FF×16 / 0 | none | hZero = 1 |
| M-3 | 65025 | [01, FE] / 0 | c₁ = 254 | hZero = 1 |
| M-4 | Err10 | 0 / [01, 0…] | c₁₆ = 1 | hSum = 1 |
| M-5 | Err10 | 0 / [01, 0…] (S₁₆ = 1) | none | hSum = 1 |
| M-6 | Err10 | [01, 0×15] / [FE, FF×15] | c_k = 255k−1 for k ≤ 16; c_k = 255(32−k) for k ≥ 17; c₃₂ = 0 | hSum = 4079 |

M-6 checks against `(2^128−1)^2 = 1 + 2^128(2^128−2)`.

**Type rejection and the value-only case**
- T-1 and T-2 give the blank Err11 term.
- P-1 gives 12.

**Fuel** (z, zp and bw are written as the vectors produced by the formulas above)

| Case | Regime | Fuel before → after |
|---|---|---|
| F-1 | Charged | 1 → 0; zp = [1, 0×16]; bw = [1, 0×16] |
| F-2 | Charged | 65536 → 65535; bw₀..bw₂ = 1 |
| F-3 | Charged | 2^120 → [FF×15, 00] |
| F-4 | Charged | max → [FE, FF×15] |
| F-5a | Done(7) | 0 preserved; z, zp all 1; bw zero |
| F-5b | Exhausted | 0 preserved; z, zp all 1; bw zero |
| F-6 | Rejected(4) | 5 preserved |
| F-7 | Rejected(4) | 0 preserved; initialFuel 5 preserved |
| F-8 | Charged | 3 → 2 |
| E-FUEL-A108 | Charged | identical to F-1 |

### Inventory

The 24 + 8 + 4 = 36 charged lines plus free lines 80, 82 and 84 make 39. I independently matched them against the crosswalk `rule_line_tags` rows 0–38, and A108 is present. This inventory is pure metadata: no K function consumes it.

## Domain, caller, partial-function and refusal behavior

**Domain predicates are total.** `afWord`, `afArithDomain`, `afValueDomain`, `afControlDomain` and `afFuelDomain` are all total over well-sorted terms. So both request-rewrite guards evaluate to true or false and never get stuck.

**Every reached function is total inside the domain.**
- List lengths are fixed: 16, 17, 32 or 33.
- E, z, zp and bw only take values in {0, 1}.
- `afRegime` covers every case with E = 1.

**Partial outside the domain:**
- `afLast(afNil)`;
- out-of-range `afAt`, `afTake` and `afDrop`;
- negative `afZeros`, `afQuot256`, `afRem256` and `afChecked`;
- `afFuelBytes` with mismatched lengths;
- `afArithmetic` with an op outside {0, 1, 2, 4} when L = R = 0.

Requests outside the domain have no rewrite. A stuck or unreduced term is **not success**.

**`afNoEvent` merges two L4-distinct cases.** It covers both a non-Pending state and (Pending, N = 0). L4 treats these differently: the first means no step, the second is OutsideObservationDomain. `afNoEvent` is not a MachineOutcome or a refusal class.

**Not enforced:**
- O1 (fuel ≤ initialFuel), O2 and O3;
- spine shape: N ≥ 2 with a Return view is accepted;
- kind/typeId/ctor consistency;
- the semantics of opaque tokens.

## Findings (none blocking)

**AF-1 (caller binding).** Operand order and the type view are caller obligations.
- Sub and Lt are asymmetric. A future adapter must bind `left = node(FS0.valueRef)` and `right = node(CR0.valueRef)` with the type view `typeId` (ARH-1/2/3, N12).
- P-1 deliberately tests neither spaces nor fetch.

**AF-2 (coverage).** E-FUEL-A108 is byte-identical to F-1: request `35720ba8…`, expected `694fdcad…`.
- There are only 9 distinct fuel requests.
- The case evidences the rule-agnostic `en_chg` formula only. It is not A108 selection or tag/charge binding (IO-1 stays open).
- Shared expected terms are legitimate, because the requests differ: A-1, S-1 and S-4 share one; T-1 and T-2 share one.

**AF-3 (tooling, UNKNOWN).** `P4-ARITHMETIC-FUEL-NORMAL` has no `-SYNTAX` companion module, so default syntax-module selection is unverified.
- The two files form two separate definitions.
- Any future classified command must name the main and syntax module for each one explicitly.

**AF-4 (parse risk, UNKNOWN).** The variable `K` in `afColumn`/`afMul` shares its name with the builtin sort K.
- If parsing rejects it, renaming the variable requires new bytes and a fresh review. It is not a semantic defect.

**AF-5 (harness).**
- **Request rewrites:** compare the whole `<k>` cell against the complete expected term. A residual `af*Request`, a partial reduction or extra content counts as failure. Generated cells may be excluded only by an explicitly stated rule.
- **Normal checks:** only the exact `afCheckedNormal(true)` counts. False, stuck, unreduced, absent, timeout or crash all count as failure.
- **Diagnosis:** the aggregate `andBool` cannot say which case failed. Per-case entries would need new bytes.

**AF-6 (cost).** Each Mul column calls `afColumn` twice and recurses to about 4080 levels of linear subtraction. The cost is unmeasured and must sit inside a separately classified, bounded environment.

**AF-7 (honest-only).**
- The model computes honest outputs. `c_32` and the 12-bit bound are not checked.
- The endpoint fields `c₀`, `c₁₆`, `c₃₂`, `zp₀` and `bw₀` are diagnostic, not wire lanes.
- There is no hostile-witness validator and no N1–N16. This is explicitly out of scope.

**AF-8 (oracle independence).** Expectations and source have the same author, and the freeze-before-model ordering is self-recorded. My hand derivation of all 33 cases is the independent check here. It is not an independent-author oracle audit.

## Binding conditions

1. **Scope of this vote.** It covers only these exact bytes under the candidate manifest above, as a pure mathematical projection over already-fetched views. It is not:
   - an importer, fullStep, ArithScratch, native carrier, dispatch, spine, state or append/capacity implementation;
   - a hostile-witness validator.
2. **Success criteria for any future check.**
   - The normal check succeeds only on the exact `afCheckedNormal(true)`.
   - A request rewrite succeeds only on an exact match of the whole term in the k cell (AF-5).
3. **AF-1 governs future adapters.** E-FUEL-A108 never evidences rule selection (AF-2).
4. **Changes.** Any byte change, including AF-3/AF-4 repairs, voids this vote for the changed bytes.
5. **Still required.** A fresh, independent Muse normal review is still required.
6. **No adoptions from this vote.** It authorizes no:
   - execution classification, probe or install;
   - source adoption, byte carrier, G4 certificate or StepInv;
   - native, ledger or stagenet use.

## Retained gates

All of the following remain binding and open:
- owner errata E1–E7 and conditions 1–7; Muse E-FUEL and conditions 1–6;
- P3 conditions 1–8 and errata R2-1/3/4/5/6;
- the Muse R2-4 dissent, **both prongs**: no exact-need format and no circuit-ordering reading;
- full39 conditions 1–10 and F1–F7; the L4 conditions;
- G4-FIELD, G4-ISA-1..4, G4-FETCH, G4-BYTE and G4-APPEND;
- IO-1 through IO-8, INV-TY and D-NAMES.

Also unchanged:
- **C4:** no dependent circuit edit before admitted A102 compilation; a compile failure requires registration revert.
- Native authority stays 0.
- The old 90s/30s caps, counters and terminal failures.
- Every roadmap exit.

**APPROVED_SOURCE_WITH_LIMITS**, candidate manifest `e9419cd733aef58539dee720f420a16eae948f2d0e13fbd57ffe1fb4ad38b6d8`, subject to AF-1 through AF-8 and binding conditions 1–6.
