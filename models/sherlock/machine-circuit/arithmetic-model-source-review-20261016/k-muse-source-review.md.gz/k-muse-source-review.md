## Vote

**APPROVED_NORMAL_SOURCE_WITH_LIMITS** for candidate manifest `e9419cd733aef58539dee720f420a16eae948f2d0e13fbd57ffe1fb4ad38b6d8`.

This is a fresh normal source/conformance vote only. It is not a security judgment, execution result, native-feasibility finding, or cost approval.

### Read coverage

I reviewed the complete supplied `arithmetic-fuel.k`, `normal-checks.k`, all 33 cases in `expected.json`, the corresponding whole literal request and expected terms, `CASE-INDEX.json`, `SOURCECHECKS.json`, the fuel inventory, the adopted arithmetic/fuel design and manifest, the owner and Muse source reviews, the P3/aux source material, the reference Rust implementation, `reference_types.rs`, `main.k`, the value-slots K precedent, and the applicable L4/full39 material.

One disclosure is required: the unchanged legacy R5 catalog `A-RULE-OPERATIONS.json` (`122289ad639de0e0d527106e2da8cfd19dd9ddf2fb16781a3ca742ab0731b0a5`) was pinned but not retransmitted, so I did not perform a fresh full audit of that historical body. This vote does not depend on re-auditing it, but it also supplies no fresh R5 or full39 approval.

### Arithmetic conformance

`afArithmetic` correctly projects the already-fetched operand view for Add, Sub, Mul, and Lt:

- `afAdd` and `afSub` recurse over all 16 little-endian byte lanes and expose all 17 carry or borrow endpoints, including endpoints 0 and 16.
- Add returns `Err10` exactly when the final carry is nonzero, while retaining the 16-byte remainder and complete carry vector.
- Sub returns `Err10` exactly when the final borrow is nonzero, while retaining the complete wrapped remainder and borrow vector.
- Lt uses the same full subtraction chain and returns `Bool(bo16)`, with the otherwise unstored remainder still present in the diagnostic record.
- `afMul` evaluates all 32 convolution columns, with every in-range `i+j=k` product included, `S31=0`, 16 low bytes, 16 high bytes, and all 33 carry endpoints from `c0` through `c32`. It returns `Err10` exactly when the high half is nonzero. `hSum` and `hZero` implement the equivalent zero-high test because all high bytes are nonnegative in the stated domain.
- M-6 correctly carries the complete endpoint vector ending in `4079` at `c16`, then descending to `c32=0`, with low half `[1,0×15]`, high half `[254,255×15]`, `hSum=4079`, `hZero=0`, and `Err10`.

The output constructors explicitly zero every disabled arithmetic block. `hSum` and `hZero` are zero outside Mul, and `hZero` is 1 only for enabled Mul with zero high half.

Type handling also conforms within the projection: the four specific rules require both type IDs to be UInt type 0 and both words to satisfy `afWord`. Any other type pair inside `afArithDomain` reaches the single `Err11` rule and returns the fully zeroed diagnostic record. T-1 and T-2 are therefore normal expected `Err11` outcomes, not hostile-control cases. P-1 is values-only; it does not test Constant/Data space selection, indexes, or a real fetch.

The functions compute honest recurrence witnesses from their inputs. They do not validate an adversarially supplied carry, borrow, witness column, or native binding. `afQuot256` and `afRem256` are explicit recursive-subtraction definitions; their K evaluation and recursion cost remain unmeasured. No cost number or optimization mechanism follows from this vote.

### Fuel conformance

`afFuelAttempt` implements the ten-constructor control view, event enable, terminal precedence, zero probe, borrow chain, and initial-fuel preservation correctly:

- `afEvent` is 1 only for outcome tag 0 with positive control length.
- `afProbe` produces all 16 `z` values; `afPrefix` produces all 17 `zp` endpoints, with `zp16` acting as `isZero` for an admitted event.
- `afRegime` gives Return-at-depth-0 publication and Error publication precedence over Exhausted, independently of fuel. Those terminal rules are separated from Exhausted and Charged by the `afTerminal` guards, not merely by accidental rule ordering.
- Nonterminal controls at zero fuel produce Exhausted; the same controls with nonzero fuel produce Charged.
- The charged borrow vector has all 17 endpoints, `bw0=en_chg`, and each post byte satisfies `post_i = pre_i - bw_i + 256*bw_{i+1}`. Free and no-event regimes have zero borrow throughout and preserve fuel exactly.
- `initialFuel16` is passed through as the full unchanged 16-byte sequence in every `AFFuel` result.

F-1 through F-8, with F-5a and F-5b separated, cover charged decrement, multi-byte and high-byte borrows, maximum-fuel decrement, zero-fuel Done, zero-fuel Exhausted, Error publication at positive and zero fuel, and charged primitive-result propagation. E-FUEL-A108 checks only the rule-agnostic Eval fuel projection; it does not implement A108 lookup, EnvGetScan, selection, or rule-tag binding.

The corrected inventory of 24 charged rules without a special failure group, 8 charged failure rules, and 4 charged rules with failure branches, totaling 36 charged plus 3 free, is documentation data only. No K function consumes that inventory for dispatch or enablement; the normative mechanism remains the event, terminal, and `isZero` formula.

### Checks, modules, and stuck-term hazards

All 33 checks are present as `afNormal0` through `afNormal32`, joined by `afAllNormal`. Their expected sides are complete literal `afArith` or `afFuel` terms containing every disabled block and endpoint; they do not call implementation helpers to construct the expected result. `CASE-INDEX.json` maps all 23 arithmetic and 10 fuel cases to the corresponding request, expected file, and check function. The expectations were frozen before the model and check files existed, with `expected.json` pinned as `e6091f3f571803e2869df4f224ed8780c48bb1c8a9b430cd427321b715c3bbbb`; however, the same author prepared the expectations and implementation, so this is a shared-author oracle, not a blinded independent oracle.

The module paths are coherent at source-reading level: the syntax module imports `DOMAINS-SYNTAX`, the functions module imports that syntax and `DOMAINS`, the main request module imports the functions, and the normal-check functions import only the function module. The two request rewrites and the normal-check path are separate paths. A future normal harness must require exactly `afCheckedNormal(true)` for `afCheckAll()`; `false`, an absent result, a timeout, or an unreduced or stuck term must not count as success.

Within `afArithDomain` and `afFuelDomain`, the definitions appear total for the intended finite inputs. Outside those domains, terms can remain stuck rather than producing an error value. In particular, arithmetic op tags other than 0, 1, 2, and 4, malformed or non-16-byte words, out-of-range bytes, and helper calls on negative integers have no completing rule. The request rewrites likewise have no transition when their domain guards fail. This is acceptable only because those inputs are outside the declared callable projection; it must not be reinterpreted as an `Err11`, Capacity, Exhausted, or machine outcome.

### Limits and preserved obligations

All 33 cases and all K parse, compile, and run results remain **UNRUN**. The actual K version and the complete `domains.md` source closure remain **UNKNOWN**; no command classification or execution was requested or performed. K syntax, builtin-domain resolution, reduction, termination cost, and runtime behavior therefore remain unverified.

This approval covers only the finite, already-fetched arithmetic/fuel projection. It does not cover a real operand fetch, importer, full machine step, ArithScratch or native byte binding, StateBlock append or capacity, POP/W1, global dispatch, ProgramBlock or Snapshot preservation, Eq, Cons, Branch, A157, or cross-layer correspondence. Finite positive cases do not prove general arithmetic correctness, whole-machine conformance, or native correspondence. Any new Quint model or results were not read or copied by the author, and none were used here.

E1–E7, E-FUEL, the P3 conditions and dissent, full39, L4, IO1–8, G4, and C4 remain preserved and open as stated. Native authority remains 0, and all existing caps, counters, failure classifications, and roadmap obligations remain unchanged.

**Final substantive vote: APPROVED_NORMAL_SOURCE_WITH_LIMITS — `e9419cd733aef58539dee720f420a16eae948f2d0e13fbd57ffe1fb4ad38b6d8`.**
