# Inherited source conditions (verbatim bodies)

The following are exact strings from the pinned Root adoption. Historical vote-process statements retain their original timing; this model has no review/adoption or execution vote.

## Defects and precise binding readings on unchanged bytes

None of these requires a new mechanism.

**E1 — inventory error (most material).**
- §9 and the manifest `fuel_rules` omit **A108** entirely.
- The text says "36 = 23 + 8 + 5", but the third group lists 4 rules (A153, A157, A204, A214). The lists cover only 35 charged plus 3 free rules.
- **Binding reading:**
  - A108 is charged (L4 `rule_line_tags` line 108, charge 1).
  - The `fuel_rules` lists are non-normative inventory.
  - The normative fuel relation is §5/§8 (en_chg, FD-1 to FD-4). It is rule-agnostic and covers A108.
  - The correct count is 36 = 23 + A108 + 8 + 4.
- No consumer may derive charge or FuelDec enablement from those lists. Per-tag charge stays with L4 O4 and P5.

**E2 — §9 wording.** §9 places the A153 successes in the column headed "Semantic-failure branches still charged". **Reading:** that column lists every charged A153 branch, not only failures.

**E3 — G4-ISA-3 status.** G4-ISA-3's status "Inferred from usage" is not evidence. **Reading:** it is UNKNOWN, like G4-ISA-1, G4-ISA-2 and G4-ISA-4.

**E4 — §10 carry and field-bound wording.** **Reading:**
- The inductive bound is 4080 and the attained maximum is 4079. Both are below 2^12.
- The exact field need is p > 1,048,575.
- The stated p > 2^20 remains the binding requirement.

**E5 — "No LessThan" scope.** "No LessThan" applies only to aux/2's own relations. **Reading:** the G4-FETCH guard comparator and the A102 fragment's 128-bit `LessThan` carry their own ISA and field requirements. G4-FIELD is necessary for aux/2, not globally sufficient.

**E6 — carrier serialization.** The 12-bit carriers are serialized as 2 byte lanes. **Reading:**
- aux/2's relations bind logical carriers only.
- Lane reconstitution (lo + 256·hi, with hi < 16) is part of G4-BYTE.
- No claim binds the serialized lanes before G4-BYTE.

**E7 — errata texts not supplied (IO-5).** **Reading:** adoption is subordinate to R2-1 and R2-3 through R2-6. Any conflict voids the conflicting aux/2 portion, and repairing it requires fresh bytes, not reinterpretation.



## Conditions on this vote

1. **Scope.** The vote covers only the arithmetic and fuel source relations on these exact bytes, with E1–E7 binding.
   - It does not cover P4, the spine, P5 dispatch or exactly-one selection, the native witness ABI, L04 or L05.
   - It does not cover Eq, Cons, Branch or A157 sort reads (IO-4).
   - It is not G4 operator certification.
2. **Requirements stay requirements.** G4-FIELD, G4-ISA-1 to G4-ISA-4, G4-FETCH, G4-BYTE and G4-APPEND remain requirements, not native evidence. Separately, INV-TY, D-NAMES and IO-1 to IO-8 remain open.
3. **No emitter acceptance yet.** There is no emitter acceptance until P3 condition 5 and IO-7 are met. Profile identity and dimensions must be bound into L04 (P3 condition 6) before any native use.
4. **C4 is unchanged.** No dependent circuit source edit happens before admitted A102 compilation. A compile failure means registration revert. The IO-3 equivalence with the A102 fuel chain is required afterward.
5. **Execution remains unrun.** Formal correspondence, K, Quint and Clean checks, the negative checks N1–N16 and all native execution remain **UNRUN**. None is demanded or authorized.
6. **Prior bindings retained.**
   - full39 conditions 1–10 and F1–F7;
   - P3 conditions 1–8;
   - errata R2-1, R2-3, R2-4, R2-5 and R2-6;
   - the Muse R2-4 dissent, preserved verbatim in both prongs;
   - native authority 0;
   - the old 90s/30s caps, counters and terminal failures;
   - the full roadmap, unchanged.
7. **Votes needed.** This is one fresh substantive vote. A second fresh substantive vote (Muse normal audit of these exact bytes) and a Root adoption record are still required. No historical vote transfers. Any byte change voids this vote for the changed bytes.

No adoption, grant or execution authorization is made here.

**ADOPT_COMPLETE_ARITHMETIC_FUEL_SOURCE_WITH_CONDITIONS** — candidate manifest `42d45bd3bea826469408a774984318d1ae473b82636ae5f32c0bf4ca8b23c6a2` (DESIGN `88887f1d…13c3`, MANIFEST `63182dc1…df4f`, OWNER-RESULT `4d99c6ed…767f`), subject to errata E1–E7 and conditions 1–7.

## One concrete non-mechanism erratum

The fuel inventory enumeration is arithmetically incomplete on the candidate bytes: A108 is a charged rule but is omitted from §9/manifest `charged_no_failure`, and the printed subtotals say `23+8+5` while the listed with-failure-branch group has four rules.

**Binding reading E-FUEL:** the normative selector is the `en_chg` formula, not the illustrative rule list. Read the charged partition as A108 included and corrected counts:

- charged without a special failure-branch group: 24, including A108;
- charged failure rules: 8;
- charged rules with failure branches: 4 — A153, A157, A204, A214;
- total charged: 36; free: A080, A082, A084.

This requires no new mechanism because A108 already follows from `en_chg`.



## Conditions of this vote

1. Root must bind this vote to the exact candidate manifest `42d45bd3bea826469408a774984318d1ae473b82636ae5f32c0bf4ca8b23c6a2`; any byte change voids this vote for changed bytes.
2. E-FUEL above governs §9 and the manifest fuel-rule enumeration on unchanged bytes.
3. Before any native/emitter use, the pinned field must be shown to satisfy G4-FIELD `p>2^20`; if it does not, this byte-limb profile is inapplicable and any nibble alternative requires fresh reviewed bytes.
4. G4-ISA-1..4, G4-FETCH, G4-BYTE and G4-APPEND remain unproved requirements, not native evidence or operator certification.
5. IO-1–IO-8 remain open in their stated scopes: P5 dispatch/pre-post binding, P4 spine/POP/W1 wiring, A102/FuelDec equivalence after the C4 gate, Cons/Branch and A157 sort-read witnesses, exact R2-1 reconciliation, L04 profile/layout/statement binding, emitter acceptance and all UNRUN K/Quint/Clean checks.
6. The adopted P3 conditions 1–8, errata R2-1/3/4/5/6, the preserved Muse R2-4 dissent, full39 conditions/F-readings, costs and capacities remain open and binding. This vote decides only the complete source proposal for A153 Add/Sub/Mul/Lt witnesses and the 39-rule fuel probe/decrement/preservation relations; it does not adopt complete P4, the spine, global dispatch, a native witness ABI or G4 operators.

With those conditions and E-FUEL, I find no blocking mathematical, selector, disabled-witness, overflow-separation or fuel-precedence defect in the stated source scope.

**ADOPT_COMPLETE_ARITHMETIC_FUEL_SOURCE_WITH_CONDITIONS**
