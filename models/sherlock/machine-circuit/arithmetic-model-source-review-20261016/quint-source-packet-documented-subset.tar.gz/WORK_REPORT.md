# P4 arithmetic/fuel Quint source handoff

Frozen two-module source proposal with 18 authored normal tests: eight complete arithmetic witnesses and ten complete fuel witnesses. The model keeps all 16 bytes, full 32-byte multiplication, both carry endpoints and 12-bit carries, low/high output, remainder-constrained Lt, and terminal-before-exhaustion fuel handling. Sampling is finite (196 arithmetic plus 84 fuel input combinations); no full-machine or native correspondence is claimed.

All model/parser/type/effect/test/run/verify/native execution is UNRUN. Only source reading and literal text/JSON/hash bookkeeping occurred. No checkout, circuit, prior packet, cap or grant changed. The previous append QA was not rerun.

`BINDER-PLAN.json` preceded source. The final full inventory has 201 binding occurrences / 152 distinct spellings, no collision with 103 installed builtin names. Typed action return annotations, List fold signatures, import closure and bigint operators were inspected in pinned installed consumer sources. These are not typecheck results.

The complete original expectations and 18 test sources were frozen before implementation. One source cross-check later corrected F3's input class to RetControl at depth 1 (actual A153 pre-control); all numerical expected outputs are unchanged. Original bytes and receipts remain under `history/expectations-first/`. `EXPECTATION-CORRECTION.json` records the exception. The author is shared between expectations and model; expectations are candidate-output independent, not blinded external review.

The exact adopted source candidate, both full reviews, Root adoption, public semantic/L4 contexts and installed consumer sources are snapshotted in `inputs/` and pinned by `INPUT-MANIFEST.json`. Binding E1-E7 and E-FUEL are preserved verbatim. Correct fuel inventory is 24+8+4=36 charged, three free, A108 included; rule labels never compute charge.

Future falsifiable predicates require separate admission: load this model as root, then test the 18 whole literals, then sample `step` with `modelInv`. No commands or retry authority are granted here. This model checks selected local relations only: no full ArithScratch/dispatch/fetch/typecheck, physical carrier lanes, state framing, hostile-witness completeness, P4 spine, Eq/Cons/Branch/A157, B/general-ADT/financial/ledger/proof/stagenet acceptance. All G4/IO1-8/P3/full39/L4/C4/resource/roadmap obligations remain.

See `SOURCE-MANIFEST.json` and `OUTPUT_SHA256` for exact frozen bytes; `README.md` for the state/action/type/adapter and shared-oracle limits. `SOURCE.patch` contains the two new source files; before-images are explicit absence records.
