# Finite arithmetic and fuel relation model — source only

This increment models selected logical relations from conditionally adopted `sherlock-k-a-aux/2`. It keeps base 256 and every one of the 16 word bytes. Finite sampling restricts input values, not word width or the source equations. Nothing in this packet has been parsed, typechecked, tested, simulated or verified by Quint. Native authority is zero. The model itself requires fresh review and separate command classification before execution.

`arithmeticFuel.qnt` is the root module. `arithmeticFuelTest.qnt` imports only `./arithmeticFuel`. There are no external Quint imports, uninitialized constants, callbacks, second actor or Choreo layer. Installed Quint 0.32.0 source was read, not invoked. No command/grant is issued here. A future separately admitted check should load the model as root before loading the test module so an importee diagnostic is not hidden by import errors.

## State, action and finite domain

One variable, `observed`, stores either an arithmetic input with its constructed witness, or a fuel input with its constructed witness. `observeArith` and `observeFuel` each assign the entire variable atomically. `init` constructs the zero-plus-zero observation; `step` selects either action. An observation is a local relation sample, not a Sherlock machine step or a transition between prior and next Snapshots.

The sampled arithmetic domain is seven explicit full words: 0, 1, 255, 256, 2^120, 2^127 and max-u128. Each of Add/Sub/Mul/Lt chooses both operands independently: 196 combinations. Fuel chooses seven full words (0, 1, 3, 5, 65536, 2^120, max-u128), three control classes, depths 0/1 and enabled false/true: 84 combinations. Thus the two sampled actions describe 280 input combinations, not a claim that a simulator explored them. Parameterized constructors support valid full-word inputs beyond this sampled set. No capacity, degree, native range, budget or production default is selected here.

Fuel depth 0/1 represents only empty/nonempty stack for the terminal predicate. It is not a source stack bound. `eventEnabled` stands for Pending AND nonempty control; `RetControl`, `ErrorControl` and `OtherControl` abstract the pre-control kind. These are adapter assumptions, not facts established by this model. Inactive observations exercise the stated disabled fuel formula but are not O4 admitted observed records. No full Program, initial fuel, other Snapshot cell, state framing, typed node fetch, source-rule membership or charge-to-wire-tag binding is checked.

## Witness and relation map

| Source relation | Constructor | Invariant/oracle |
|---|---|---|
| ADD-i | `rippleAdd` propagates quotient/remainder per byte | all 16 local equations, Boolean carry endpoints, packed-word equation, source UInt/Err10 result |
| SUB-i | `rippleSub` uses nonnegative remainder plus Boolean borrow | all 16 local equations, whole-word difference/remainder, UInt/Err10 result |
| Lt / ARH-6 | same complete SUB remainder and final borrow | independent whole-word `<`, Bool result; remainder is retained and constrained |
| MUL-k / MUL-HS / MUL-HZ | `product` constructs every column and carry | all 32 local equations; all low/high bytes; 12-bit carry range; zero final carry; high sum/zero; packed 256-bit product and UInt/Err10 result |
| FP-1 / FP-2 | gated byte zero probes and prefix products | full probe/prefix recurrence and bit ranges |
| FD-1..4 | charge from event/control/zero prefix; full borrow chain | every byte equation, final borrow zero, independent packed decrement/preservation and terminal-first regime |

Arithmetic witnesses retain only the selected enabled byte block. The common `high`/`highSum`/`highZero` fields are zero for non-Mul. The 232-lane physical ArithScratch layout, other disabled arithmetic blocks, H1-H4, node/ValueRef fetches, sort guards, `uu`, ARH-0..3, full branch selectors and output commit/append are not implemented here. This is an explicit projection, not a replacement profile. Carry lists include the fixed c0 and, for Mul, c32 endpoints for inspection; they do not add physical ABI columns. Logical 12-bit carriers are integers here; their two-lane serialization/reconstitution is still G4-BYTE.

`modelInv` dispatches to `arithRelation` or `fuelRelation`. The global packed-word arithmetic oracle does not call the ripple/product constructor. Local Mul equations share `columnSum` with construction; the model and oracle also share `wordOf`, `bit`, types and handwritten interpretation. They are not independent implementations of the whole source semantics. The separate literal vectors reduce those shared-oracle limits but do not prove source/native correspondence or exclude arbitrary malicious witnesses. Malformed/refusal/security test design remains with the designated owner.

Quint's installed TypeScript consumer uses bigint for these integer operations; this supports proposing full-u128 specimens without a floating-point encoding. This is source inspection, not an observed tool result. Division and remainder constructors operate on nonnegative totals; subtraction uses an explicit borrow and does not rely on negative `%` behavior. No SDK, finite-field modulus or target runtime is involved.

## Expectations and authored tests

`expected.json` contains eight full arithmetic witnesses and ten full fuel witnesses. `arithmeticFuelTest.qnt` contains 18 named normal tests, all UNRUN. Every test compares the complete constructed observation against literal typed input and witness records, then checks `modelInv`. No test obtains its expected value from the constructor, evaluator, model output or source runtime.

The arithmetic literals include the two opposite high-byte Lt directions and max×max's complete 32 product bytes, 33 carry endpoints and high sum 4079. The chain reaches 4079 at c16; the source owner distinguishes this attained value from the inductive bound 4080. Fuel covers F-1 through F-8 (including both F-5 variants) plus A108. A153's semantic failure remains charged; A225 is charged while the pre-control is PrimitiveResult, before Error publication. A080 and A082 win over zero-fuel exhaustion; nonterminal zero fuel takes A084. Labels are explanatory metadata only, not inputs selecting charge. The F-1/F-5 examples are separate relation observations, not a checked machine continuity trace.

The initial 18 complete literals and tests were frozen before model implementation. A subsequent direct source cross-check corrected only F-3's input control class from OtherControl to RetControl with depth 1: A153 starts at Return with a Right frame. No expected numeric byte, carry, charge, regime or result changed. `history/expectations-first/` retains the original full files and timing receipts; `EXPECTATION-CORRECTION.json` records the exact late correction. Current test bytes therefore include that one post-implementation input correction. One author wrote expectations and model; these are output-independent hand-derived expectations, not a blinded external audit.

## Binding conditions and retained work

The full original candidate and both complete reviews are copied under `inputs/`. `BINDING-CONDITIONS.md` preserves the Root adoption's owner E1-E7, owner conditions and Muse E-FUEL/conditions verbatim. Historical source-manifest UNADOPTED text is retained as its authoring snapshot; current aux/2 source adoption is conditional. No vote transfers to this changed model.

E1/E-FUEL governs: 24 + 8 + 4 = 36 charged events, including A108; A080/A082/A084 are the three free events. The source inventory is non-normative and never drives this model's charge. E2 applies to all listed A153 branches; E3 leaves G4-ISA-3 UNKNOWN; E4 retains p>2^20 and the distinct 4080/4079 readings; E5 limits the aux/2 no-LessThan statement to aux/2; E6 leaves lane reconstitution open; E7 subordinates this source to P3 R2-1/3/4/5/6 and requires fresh bytes for conflicts.

Eq, Cons, Branch, A157 sort reads, type-error 11 dispatch, full P4 spine and P5 dispatch are outside this increment. G4-FIELD/ISA/FETCH/BYTE/APPEND, INV-TY, D-NAMES, IO1-8, all P3/full39/L4 conditions, the Muse R2-4 dissent, P1-P6/F4/MD2/L04/L05, byte parsing, StepInv, observation/projection correspondence, B/general ADTs, financial/authority/residual-duty composition, proofs, native binding, ledger and Midnight stagenet remain owed. A finite normal model cannot close them.

C4 is unchanged: no dependent circuit edit before admitted A102 compilation; a compile failure requires registration revert. This packet changes no circuit or checkout. All existing 90s/30s caps, counters, terminal failures and complete roadmap remain unchanged. Old append QA is historical and was not rerun. No new grant, retries, security conclusion or runtime acceptance follows from this source packet.
