# Audit result: **APPROVED_SCOPED_RESULT_WITH_LIMITS**

**What this approves.** The phase-zero stop record is a faithful, correctly scoped record of what happened. Root applied the existing gate as written. The approval does **not** extend to typecheck QA, test or run results, eligibility, a security conclusion, or any execution or retry authority.

**Stop record:** `P4-QUINT-PHASE-ZERO-STOP-r1.json` — sha256 `1d20669fdf6a994dd03635257af8a440df32d3b0b24c64c1c292e7c20e891428`

**How I reviewed.** I used no tools, shell, writes or execution. I read every supplied body, including the full raw strace text. I did not rehash any file; every hash below is as supplied. The 1.28 MB installed-package metadata listing was not transmitted, so the package closure `a18adf8d…` is accepted only as Root's receipt.

---

## Findings

### F1. Root applied the gate faithfully

- Muse fallback trace gate 3 names `socketpair` and `recvfrom` explicitly. It says "regardless of success or failure" and allows "no DNS, localhost, or internal socket exceptions".
- The raw trace contains exactly the two lines Root quoted:
  - line 23: `socketpair(AF_UNIX, SOCK_SEQPACKET|SOCK_CLOEXEC, …) = 0`
  - line 25: `recvfrom(3<UNIX:[…]> <unfinished ...>`
- Both are from PID 2750270, the `timeout` process, before Node's exec. I counted the line numbers independently and they match.
- Root stopped the sequence, did not start `normal-tests` (18) or the 32×8 `short-seeded-run`, did not retry, and did not reinterpret the gate.
- Root's `stop_basis` does not diagnose egress, malice or a source defect. That is correct.

### F2. Raw trace: what it does and does not show

These are observations within the trace filter `%file,%network,%process` only.

**Exec chain**
- Exactly one initial `execve("/usr/bin/timeout", …)` with the original argv.
- Exactly one `execve` of the pinned Node path, by PID 2750271, with the original Node/Quint argv. The `<unfinished>`/`<resumed>` pair matches and returns 0.
- No other `execve` or `execveat`.
- `envp` appears only as `/* 3 vars */`, which agrees with `capture.json`. The values themselves are not in the trace (no `-v`).

**Network-family syscalls**
- Only lines 23 and 25.
- No `socket`, `connect`, `bind`, `listen`, `accept*`, `send*`, or other `recv*` appears anywhere, including from Node PID 2750271.

**Filesystem**
- Every `openat` I read is `O_RDONLY`, or `O_RDONLY|O_NONBLOCK|O_DIRECTORY` for directories.
- No `O_WRONLY`, `O_RDWR`, `O_CREAT`, `O_TRUNC` or `O_APPEND`.
- No `mkdir`, `unlink`, `rename`, `chmod`, `truncate`, `utimens` or `mount`-class calls.
- No path under `<obs>/tmp` is touched.

**Unmatched or ambiguous lines**
- All `<unfinished>` lines have matching `<resumed>` lines (`recvfrom`, `execve`, two `exit`s).
- No `syscall_NNN` entries.
- The only `...` are strace struct-field abbreviations inside `statx`. They are not truncated paths or argv.

**Termination**
- `exit_group(0)` appears for 2750271 and 2750270.
- `wait4` shows the child exiting with status 0.
- Thread 2750278 has no individual `exit`. That is consistent with being reaped by `exit_group` under `-qq`.

**Descriptor carry-over (supports F3)**
- Node's first `openat` (`/etc/ld.so.cache`) returned fd **3**.
- So fds 3 and 4 were not open in the Node image after exec, which is consistent with `SOCK_CLOEXEC`.

**Capture record**
- Exit 0, `parent_timeout:false`, stdout and stderr each 0 bytes (empty-string hash), 1.568 s.
- The wrapper argv prefix matches the required prefix token for token.
- `argv_original_child` matches `PROPOSAL.json` command 0 exactly.

### F3. What the socketpair probably was (inference only)

This is not verified against pinned bytes, and cannot be, because the `timeout` binary is unpinned (see F4).

- `readlink /proc/self/exe` resolves to `/usr/lib/cargo/bin/coreutils/timeout`, which is the uutils (Rust) multi-call binary.
- The sequence is `socketpair(SEQPACKET|CLOEXEC)` → `clone` → parent 8-byte `recvfrom` → child `execve` succeeds → `recvfrom` returns 0 (EOF).
- That sequence matches the pattern a Rust std child-spawn helper uses for an exec-status channel: an 8-byte error report, where EOF means the exec succeeded.
- The pair is anonymous, carries no address, and has no `connect`/`bind`/`send*`.

**Do not publish this as fact.** It also does **not** support a claim of "no egress". It supports only "no other traced network-family syscall in this trace".

Also inference: because the call comes from `timeout`'s spawn path and not from Quint or Node, an identical invocation with this `timeout` binary would be expected to hit the same gate again. I record this only so that no one treats a repeat as a possible clean path. I propose nothing.

### F4. The provenance caveats are insufficient as currently published

`tool_and_proposal_pins: MATCH` is true for the **declared** pins: Node, `cli.js` and strace. But the trace shows facts the record omits:

1. `/usr/bin/timeout` was never pinned, in either `PROPOSAL.json` or `CAPTURE-PLAN.json`. It is uutils, not GNU coreutils.
2. `timeout` loads unpinned `libsystemd`, `libselinux`, `libpcre2`, `libgcc_s`, `libm` and `libc`.
3. Node loads unpinned system `libstdc++`, `libc` and others.
4. **The syscalls that triggered the stop came from an unpinned binary.**

Any publication must carry this caveat. It does not invalidate the stop: the gate is categorical regardless of which binary made the call.

### F5. Node-side observations (all read-only, nothing gated)

During `typecheck`, Node read:
- `/etc/ssl/openssl.cnf`
- `/etc/resolv.conf`, which resolves to `/mnt/wsl/resolv.conf`
- `/etc/nsswitch.conf`

It also loaded `@grpc/grpc-js` (including `resolver-dns.js`), `protobufjs` and `tar`.

My inference is that these are static imports from Quint's `apalache`/`rust` modules plus resolver initialisation. No network syscall from Node appears. I record this as an observed fact for future owner awareness, not as a finding of misbehaviour.

### F6. Source normal correctness (hand review only, nothing executed)

**Model relations.** I found no defect in the model relations as normal-path source:
- `rippleAdd`, `rippleSub`, `product` and `columnSum` are correct.
- Lt is computed as Sub borrow-out.
- Overflow, underflow and Mul-high separation are correct.
- The fuel zero/prefix/borrow chain and the regime precedence (Disabled → DoneFree → RejectedFree → ExhaustedFree → Charged) are correct.
- The independent whole-word oracle in `fuelRelation` and `outcomeRelation` is sound.
- The sampled domain is 4·7·7 + 7·3·2·2 = **280**, which matches the proposal.

**Literal expectations.** I hand-recomputed all 18:
- Add/Sub/Lt cases 1–6 match.
- 255² gives low `(1,254)` and carry `c1=254` (I did not count the 33 zeros mechanically).
- max² gives low `(1,0…)`, high `(254,255×15)` and `highSum 4079`. All 33 carries match, including peak 4079, `c31=255` and `c32=0`.
- Fuel cases F1–F7, E1 and A225 all match.

**Limits of F6:**
- This is reviewer hand arithmetic, not execution.
- `expected.json` remains same-author and not blinded.
- The "late F3 input correction" history was not supplied to me.
- There is no hostile-witness or negative coverage (N1–N16 UNRUN).

### F7. Typecheck exit 0: what it does and does not establish

- The trace shows `arithmeticFuel.qnt` opened read-only, then a clean exit 0 with empty output.
- That is consistent with Quint typecheck success.
- It is **not accepted model QA**, because the phase's gate failed and acceptance depends on all gates passing.

### F8. Binding and timing

**Hash chain** (all consistent as supplied):
- plan `96d3c43d…`
- proposal `469c8e57…`
- fallback review `3887543a…`
- `phase-0.py` `49e62358…`, 2382 bytes, equal to the plan driver plus the line `phase_index = 0`
- capture `0d06713c…`
- trace `e2ceee4e…` (956035 bytes)

**Timeline:**
- 11:38:31 Opus handle gone
- 11:44:10 prephase checks
- 11:44:14 capture start (1.57 s run)
- 11:44:52 stop record

The order is consistent. The post-phase rehash fields (`UNCHANGED`/`MATCH`, `tmp` empty) are Root summary assertions; I did not rehash them independently.

---

## Claims that may be published (exact wording)

1. "Phase 0 (`model-root-typecheck`) of plan `96d3c43d…` was attempted once under the strace observation wrapper and exited 0, with empty stdout and stderr, in 1.57 s."
2. "The mandatory trace gate failed: the unpinned `/usr/bin/timeout` process (resolving to uutils coreutils) made `socketpair(AF_UNIX, SOCK_SEQPACKET)` and `recvfrom` calls before executing Node. The sequence stopped as required; `normal-tests` and `short-seeded-run` were never started and remain UNRUN; nothing was retried."
3. "No other traced network-family syscall, no traced mutating filesystem syscall, and no unexpected exec appear in the trace, within the limits of the `%file,%network,%process` filter."
4. "The raw typecheck exit 0 is not accepted model QA."

## Claims that must not be published

- Network egress, compromise, or a security-clean result.
- A causal diagnosis stated as fact.
- "Typecheck passed" as QA, or any test or run result.
- Native, SDK, Rust, K, circuit, PCD or stagenet evidence.
- That Opus approved the capture plan.
- That Opus availability or provider status has been established. This response is evidence of recovery only if it is captured as a completed canonical result.

## Retained limits and dissent

- **Not covered by this audit:** native authority 0; C4 unchanged; the full roadmap unchanged; old 90s/30s caps, counters and terminal failures retained.
- **Still open or unrun:** E1–E7 and E-FUEL; conditions 1–7; P3 conditions 1–8; full39 conditions and F1–F7; errata R2-1 and R2-3 to R2-6; IO-1 to IO-8; G4-FIELD, ISA, FETCH, BYTE and APPEND remain requirements only. The K33 checks, Quint/Clean/negative N1–N16 checks and all native work remain UNRUN.
- **Muse R2-4 dissent:** preserved verbatim, as recorded.
- **Identities:**
  - The Muse fallback vote stays a Muse vote.
  - The literal requirement that Opus received and approved the supplement remains **unsatisfied**.
  - The earlier Opus request remains "no public result".
  - This review does not convert any fallback approval into an Opus approval.
- **Source-only approvals** remain historical.
- **Unverified by me:** the package closure, the 63/35/40 source closure, and the pre/post rehash receipts. I did not independently rehash any of them.
- **Strace blind spots:** `read`, `write`, `mmap` and `ioctl` were untraced, so "no untraced write primitive" cannot be claimed.
- **Required amendment (F4):** the unpinned-`timeout` provenance caveat must be added before publication.
- **Forward path:** this audit grants no execution or retry, and proposes no wrapper, gate change or campaign. Any continuation needs a separate owner decision.
