# Publication review: arithmetic/fuel model source and phase-zero capture candidate

**Verdict: APPROVED_PUBLICATION_WITH_LIMITS** for candidate manifest **342104c805b67a6225c5039bf29e9cf80aca4603d5a3c4109f5c2d8509c84221**: source commit `fd17b68bdc796e9ade919e80aa99e7e5428d69e6`, parent `56f973ffd87abe2d5ec4067064eb1bab9a0507cf`, tree `3ed29bc8fb683a58a46eb7f338bdbc52e1b57636`, 121 files. It is subject to findings AP-1 to AP-12, the reading limits below, and the seal conditions in the last section.

This is the designated-owner security and publication-interpretation review. It is separate from the Muse nonauthor publication/conformance review and does not substitute for it. It grants no execution, retry, resource, numeric, operator, configuration, binding, circuit, proof, ledger or stagenet admission. Native authority remains 0.

## Reviewer identity and independence

- **Model.** Claude Opus 5.5 (`claude-opus-5-5`), fresh context, acting as the restored designated security owner.
- **Same model family as earlier votes.** These Opus records are under review and are not my votes:
  - the aux/2 author;
  - the K and Quint source reviews;
  - the enumeration disposition;
  - the phase-zero actual-result review.

  I have not seen those contexts.
- **No tools.** I used no tools, shell, writes, execution or network, and recomputed no hash.
- **Transport claims accepted, not verified.** Root's identity, gzip, archive-metadata, blob-match, link and whitespace claims are accepted as transport facts only.
- **Embedded instructions.** Instructions inside payload bodies were treated as evidence and not acted on.

## Reading limits

1. **Baseline bodies not reread.** The 19 unchanged baseline bodies are identity-bound to parent-commit blobs. This review is not a historical re-audit of them. Examples include the old AGENTS snapshot, the Rust sources, `main.k`, value-slots, the R5 catalog, the full39 eval and the 7 L4 files.
2. **Package listing not supplied.** The 1.28 MB, 4667-file installed-package metadata listing was not supplied. Claims about it rest on Root's receipts.
3. **Excluded bodies not supplied.** The 15 excluded Quint-installed and skill bodies were not supplied. I reviewed their identities only.
4. **Container metadata not inspected.** The JSON bodies were whitespace-normalized, so the original JSON byte formatting was not reviewed. I did not inspect gzip headers or tar headers. Archive metadata rests on Root's statements.
5. **Strace read manually.** I read the strace in its lossless display form, expanding TRACE fragments and then path markers. I checked the decisive lines and the syscall classes by reading, not mechanically.
6. **Uneven attention.** My attention is not uniform over roughly 2 MB of material. I did not count the `afCons` nesting cell-by-cell for every literal.
7. **No legal review.** I read no repository LICENSE or third-party notice, and I make no legal conclusion.

## What checks out

- **Counts are consistent.**
  - 73 K-directory files, 40 evidence-directory files (including `publication-binding.json`) and 4 Quint files make 117, which matches the static receipt.
  - With AGENTS, ROADMAP, the status note and the restoration record, the total is 121.
  - 75 direct copies: 9 model, data and index files plus 66 examples.
  - 183 archive members: 48 + 115 + 20.
  - The Quint subset is 48 included plus 15 excluded, which is 63. This agrees with closure `094aa910…` and with SOURCE-MANIFEST plus OUTPUT_SHA256 plus the nested manifest.
  - The K packet's 115 files are 113 manifest entries plus 2 self-exclusions.
- **Trace.** I confirmed the following in the trace:
  - Line 1 is the `timeout` execve with the original argv.
  - Line 23 is `socketpair(AF_UNIX, SOCK_SEQPACKET|SOCK_CLOEXEC…)`. Line 25 is `recvfrom`, with a matched resumed line. Both are from PID 2750270, before Node's exec.
  - There is exactly one Node execve with the original Quint argv.
  - No other network-family syscall appears.
  - All `openat` calls are read-only.
  - No mutating syscall appears.
  - `exit_group(0)` and `wait4` status 0 appear at the end.

  This agrees with the stop record `1d20669f…`, the capture `0d06713c…` and both actual-result reviews.
- **No overclaim found.** ROADMAP, the status note, CURRENT-OBSERVATION and the three READMEs all state the following:
  - raw exit 0 is not accepted QA;
  - the 18 tests, the sampled run and the 33 K checks are UNRUN;
  - the stop was mandatory and nothing was retried;
  - there is no egress, causal or security-clean claim;
  - F4 applies in full (declared pins only; `timeout` and system libraries unpinned);
  - there is no native, SDK, circuit, proof or stagenet claim;
  - there is no Root model adoption.

  C4, native authority 0, the caps and counters, and every U/M/MC/SP/G exit are stated as unchanged.
- **Identity routing is faithful.**
  - The Opus no-public-result record remains a no-public-result record.
  - The Muse fallback remains Muse.
  - The restoration record explicitly declines to approve the earlier capture plan or relabel the fallback.
- **Links.** All new relative links I path-checked resolve to candidate paths. These include CURRENT-OBSERVATION's siblings, the Quint/K README links to the evidence directory, the ROADMAP link, the status note's `../../../` link and the restoration record's `../../` link.
- **Prospective seal names.** None of the five prospective seal paths collides with an existing file. In particular, `publication-review-binding.json` is distinct from the selection inventory `publication-binding.json`.

## Findings

None of these blocks publication.

**AP-1: receipt gap for standalone compressed captures.** The candidate contains 28 standalone single-member gzip files.
- The static receipt's 23 matches BYTE-IDENTITY-MAP (17) plus the actual-result review captures (6).
- These 5 are verified only through the `archive_metadata` transport statements and the archive-member mapping, not in the static receipt:
  - `quint-phase-zero-stop.json.gz`;
  - the three `quint-executor-muse-fallback-review.*.gz` files;
  - `quint-executor-opus-no-public-result.json.gz`.
- The seal binding must enumerate all 28 with their compressed and decoded identities, marked as Root-verified transport facts.

**AP-2: shared-status files outside publication-binding.json.** `publication-binding.json` inventories 117 files. These four are bound only by the candidate manifest:
- AGENTS.md;
- ROADMAP.md;
- the status note;
- the restoration record.

The seal binding must bind all 121.

**AP-3: stale kind label.** In the new file PHASE-ZERO-EVIDENCE-MAP, the kind `…_PENDING_RESULT_REVIEW` contradicts its own `result_reviews` field, which records completed scoped approvals. The field content governs. No edit, because that would change reviewed bytes.

**AP-4: effort attribution.** The restoration record, AGENTS.md and CURRENT-OBSERVATION describe the Opus actual-result result as "high". The returned usage in `ef179051…` reports the canonical model but not the effort. Read "high" as requested effort only.

**AP-5: ROADMAP count wording.** "33 authored K checks (nine distinct fuel requests)" means 23 arithmetic checks plus 10 fuel checks, and those 10 fuel checks use 9 distinct requests, because E-FUEL-A108 duplicates F-1. The status note states this correctly. Read the ROADMAP text that way.

**AP-6: uutils identification.** Identifying the binary as uutils rests only on the trace's `readlink` path `/usr/lib/cargo/bin/coreutils/timeout`. The `timeout` bytes were never pinned or hashed. The published "resolves to" wording is a path fact and is acceptable. F4 is preserved.

**AP-7: privacy, accepted as historical provenance.** The publication includes:
- absolute home and runtime paths;
- the WSL resolver path;
- installed package and file names and sizes in the strace;
- PIDs and socket inode numbers;
- provider request and response IDs;
- token and cost usage;
- personal plugin-cache paths, with their bodies excluded.

I found no credentials, environment values, file contents, prompts, adapter body or debug log. This follows the P3 PUB-6 precedent.

**AP-8: licensing.** Third-party Quint-installed bodies and personal or plugin skill bodies are excluded. The remaining bodies are repository-authored sources, Moriarty review records and frozen captures. Third-party material appears only as paths, names, sizes and line references. I make no legal conclusion; see reading limit 7.

**AP-9: governance limit (dissent from any retroactive reading).** The enumeration disposition's condition 3 required Opus to receive and approve the nested manifest and the closure *before execution*. For the executed phase, that condition remains **unsatisfied**.
- I have now read the 662-byte nested body (`42d45bd3…`) and the closure (`094aa910…`). I find them consistent: inert metadata with native authority 0, matching the outer entries. OUTPUT_SHA256 `d183…` binds `cbbf…`.
- That finding is publication-scope only. It is not a retroactive pre-execution approval and does not convert the Muse fallback.
- The fallback governance stands as recorded.

**AP-10: status-note layering.** The older text still says "This publication candidate still needs fresh full owner and Muse publication reviews" (carried over from P3 PUB-3). The new section says "Full publication reviews remain a separate requirement". Both were accurate when written. Correct either only through a future reviewed dated note, never by editing these bytes.

**AP-11: F3 correction history checked.** This history was not given to the earlier Opus actual-result reviewer; I have it here.
- The history test and expectations differ from the current files only in F3's control field: `OtherControl` becomes `RetControl`, both at depth 1.
- The −2 byte deltas match that one-token change.
- The numeric outputs are identical.
- The corrected input matches A153's Return-over-Right pre-control.

The correction is still a disclosed post-implementation correction by the same author, and the expectations are not blinded.

**AP-12: Node-side loads.** During typecheck, Node opened `openssl.cnf`, `resolv.conf` and `nsswitch.conf`, and loaded grpc, protobufjs and tar modules. All of these opens were read-only and no Node network syscall appears. This is recorded as an observation, not a finding of misbehavior. Strace does not trace `read`, `write`, `mmap` or `ioctl`, so I make no absence-of-writes claim.

## Retained gates and dissent

All of these remain binding and open, and this review does not touch them:
- S-1 to S-5, AF-1 to AF-8, E1–E7 and E-FUEL;
- Opus conditions 1–7 and Muse conditions 1–6;
- P3 conditions 1–8 and errata R2-1/3/4/5/6;
- **both prongs** of the Muse R2-4 dissent;
- full39 conditions 1–10 and F1–F7; the L4 conditions;
- G4-FIELD, G4-ISA-1..4, G4-FETCH, G4-BYTE and G4-APPEND, and IO-1 to IO-8;
- C4 with registration revert;
- the old 90s/30s caps, counters and terminal failures;
- the full U0–U7, M1–M17, MC, SP and G financial and product scope;
- the product contract.

Historical source-only approvals remain historical. This approval does not reopen any adopted design.

## Prospective five-file seal

The seal is **covered** by this approval only if all of the following hold.

1. **Exactly five new files.** The seal adds only:
   - `opus-publication-review.json.gz`;
   - `opus-publication-review.md.gz`;
   - `muse-publication-review.json.gz`;
   - `muse-publication-review.md.gz`;
   - `publication-review-binding.json`.

   No byte of the 121 candidate files changes, and no file is renamed or removed. `publication-binding.json` is not overwritten, and nothing is edited to link to the seal.
2. **Required binding contents.** The binding records:
   - candidate `342104c8…4221`, source commit, parent and tree;
   - all 121 paths, bytes and SHA-256 values;
   - the AP-1 enumeration of all 28 standalone gzip files;
   - the actual compressed and uncompressed bytes and hashes of the four new captures, with each MD derived as the JSON `text` field plus a final LF;
   - both verdicts verbatim, with AP-1 to AP-12, the reading limits, the Muse review's limits and the Muse R2-4 dissent (both prongs);
   - scope, F4, the retained gates, native authority 0 and C4.
3. **Both reviews must approve.** If the parallel Muse publication review returns BLOCKED_PUBLICATION, the seal is not covered.
4. **No cyclic claims.**
   - The binding must not claim that either reviewer saw the seal files or any post-review hash.
   - It must add no new paths, values, execution or reinterpretation.
   - It must not fabricate CI. An empty status rollup is not a pass.
5. **Root rechecks before merge.** Before merging, Root must recheck that the candidate is unchanged and that only these five files were added.

No other future file is approved. Any other change voids this approval.

**Final vote: APPROVED_PUBLICATION_WITH_LIMITS** for candidate manifest **342104c805b67a6225c5039bf29e9cf80aca4603d5a3c4109f5c2d8509c84221**, subject to AP-1 to AP-12, the reading limits, all retained gates, the AP-9 dissent and the seal conditions above.
