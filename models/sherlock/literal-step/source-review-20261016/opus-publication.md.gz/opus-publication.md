# Opus 5.5 publication review: A102 registration and atlas 004

**Verdict: APPROVED_SOURCE_PUBLICATION_WITH_CONDITIONS**

- **Candidate manifest:** `1c70379f61f908c39a00b036e9ad1b126590e77717bf6b7b86d438ce4ec90735`
- **Source commit:** `0f2108b759dea9e7bedc46399450f89efddcd825`
- **Base:** `8b32c0a491c7adfaa658cc32eb34c7c7f93986d6`
- **Integration manifest:** `2ccd8027e250a5b6a57049c5da39570ad96518fe4745fbc683ad490c130afd63`

I read only the supplied text. I recomputed no hashes, decoded no gzip, ran no command and observed no tree. This approval grants no user authority, compile result, test result or execution admission. Native authority remains 0.

## 1. Source publication scope (security owner)

### Secret and private leakage

I read all 23 views, all decoded gzip members, the before-images and the 21-member packet. I found no credentials, API keys, tokens, signing material, witness secrets or private Clean/Fenrir source. "Fenrir" appears only as an obligation name.

The material exposes the following low-sensitivity, non-blocking metadata:
- Absolute local paths that reveal the account name `charl` and the runtime directory layout. These appear in SOURCE-FREEZE, the packet INPUT-MANIFEST and P1 files, the 004 AUTHORSHIP entry, and the Gemini adapter `actual_command`.
- Provider request and response IDs (Muse).
- Token counts and costUSD (Opus).

None of these is a credential. Root may keep them. Do not add more in the seal files (see §3).

### Rust surface

- **`lib.rs`.** The only delta from the before-image is `pub mod sherlock_machine;`, at +26 bytes. Neither `compile`, `compile_signed`, `compile_mode` nor `lower_action_segment` references it. No CLI path is among the 23 files.
- **`mod.rs`.** The delta is the doc comment, a private `mod literal_step`, re-exports of exactly two functions and nine types, and a `cfg(test)` registration. The fetch code is unchanged.
- **Newly public surface.** The crate now publicly exposes:
  - the existing fetch API: `emit_public_fetch`, `EmittedFetch::pack_witness`, `emit_fetch_block` and `emit_enabled_fetch_block`;
  - the two Literal constructors.

  Nothing in the candidate consumes any of them. This is acceptable under Opus's existing condition (C2 below).
- **Tamper resistance.** `LiteralSchema.capacities` is private, so external callers cannot forge a schema. Tampering with the public lane metadata yields `SchemaMismatch`.
- **Panics.** Every indexing `expect` and literal index is reachable only after the schema re-derivation and `check_image`. The capacity minima (X, K, C ≥ 1; header length 16) make `root[5]`, `root[14]`, `tables[4]` and `tables[5][0]` safe. These are host-only paths in any case.

### Build risk (non-security, material)

Registration makes `mori-backend`, and anything built from `main`, compile eight sherlock_machine files that have never been compiled. A source reading found no evident error:
- the glob imports of the parent's private `use` items resolve;
- the private `Result` alias is transparent;
- every `From` conversion exists;
- the moves and reassignments in the borrow loop are sound.

This is not a compile result. No Rust workflow exists, so nothing on `main` will catch a failure. Condition C4 addresses this.

### Hash and provenance consistency (cross-reading only)

The following identities agree across every place they appear:

| Object | Hash | Locations that agree |
|---|---|---|
| `lib.rs` | `dcc9f256…` | candidate, SOURCE-FREEZE, Opus receipt |
| `mod.rs` | `5f193ee1…` | same three |
| `MAPPING.md` | `60d5c626…` (10407 bytes) | same three |
| `literal_step.rs` | `b5d2…` | current and historical pins |
| `literal_step_normal_tests.rs` | `2554…` | current and historical pins |
| README | `78a5950b` → `ab3a44b1` | `readme_integration_changes` and `readme_sha256` |
| Note | `3edc3f4d…` | AUTHORSHIP, captured metadata, work report |

The before-images agree with `068307ea…` and `e2af2fe0…`. The base→candidate change set has five paths, and the earlier worktree-relative change set has three; SOURCE-FREEZE labels the two separately, so they do not contradict each other.

Two distinct manifests must not be conflated:
- the runtime SOURCE-MANIFEST `b5835237…` in the work report;
- the publication candidate manifest `1c70379f…`.

### Receipts

- The **decoded md captures** equal the `text` fields of their adapter JSON (Opus, Muse, Gemini and the atlas Opus reply).
- **Muse's `.md.gz` holds JSON.** This is disclosed.
- The **identity claims in the source-review README** match the receipts:
  - Opus: canonical `claude-opus-5-5`, `is_error=false`;
  - Muse: `muse-wonder-1.0`, high effort, terminal state completed.
- The **oracle packet** has 21 members: 20 listed in MANIFEST.json plus the manifest itself. The three loose copies carry the same hashes as their packet members.

### History preservation

- The twelve 000–003 files are reported unchanged.
- The four AUTHORSHIP iteration objects in the before and after images are textually identical.
- The only top-level AUTHORSHIP change is `source_and_visual_status`. It now reads accurately.
- `publication_history` is unchanged.

### Docs accuracy

- **Test count.** The source-review README's count of 16 tests (4 + 2 + 5 + 5) matches the test files.
- **Opus conditions.** The README restates them faithfully.
- **Relative links.** Both directions resolve: four levels up and two levels up.
- **Stale wording in reviewed bytes (non-blocking, disclosed).** These cannot change without re-review:
  - the `literal_step.rs` header comment says "Unregistered";
  - MAPPING.md says the candidate "needs fresh review".

### Workflow

None of the 23 paths, or the 5 future seal paths, falls under `site/**`. No workflow, configuration or dispatch change is present.

### Whitespace

The only `diff --check` failure is note line 21, the two-space line inside the exact Opus string. I accept retaining it for verbatim identity, scoped to that line.

## 2. Atlas 004 grounding (my observations; Muse's normal verdict is separate)

**Source facts.** I checked each feature in the note against `literal_step.rs`:
- the MinimumShape condition;
- lane counts of 16, `[2,1,4,1,11,1,6,2,3,2,3,4,1,22,2]`, 45 and `[22,2,5,2,17,36]`;
- the pre guards;
- the fetch index, rows and `root[5]`/`root[14]` bounds;
- the 28 preserved Root lanes;
- 33 zero CR0 columns;
- `tables[0..5]` preserved;
- the borrow chain with 9-bit bounds and an unconditional final borrow of 0;
- maximum checks only on lanes that carry a maximum;
- envelope tag 3 with charge 1 and no line-102 operand.

All are accurate. The Opus corrections are real: the RULE_LINES claim is unsourced, the 6-table claim should be 5+1, and Constants are range-checked rather than keep-outs.

**Authorship.**
- Gemini is credited for the initial concepts. The `plan` request and the `always-proceed` return are both recorded.
- Gemini's canonical ID and returned effort are `NOT_REPORTED`, and Opus's returned effort is `NOT_SELF_REPORTED`. Nothing is relabelled.
- The wrong Gemini draft exists only in the provenance gzips.

**Note pins.** The note pins the historical MAPPING `72411a42…`, which correctly scopes it to the earlier unregistered three-file freeze.

**Minor defects (non-blocking):**
- In the wiki README, the 004 index row follows a blank line after the 003 row. It will render as a stray pipe line rather than a table row.
- The 004 AUTHORSHIP entry keeps the author-time strings `PROPOSED_CORRECTED_MATERIALIZATION_NOT_COMMITTED` and `PREPARED_UNCOMMITTED`. After merge these read stale. They are qualified by `original_author_placeholders` and must not be rewritten.
- `publication_history` has no entry for the G3/003 publication. This predates the base and is not a regression.
- Several referenced receipts are unpublished, so the public cannot verify them:
  - Muse `LAUNCH.stdout` `496f…`;
  - the scoped reviews `f3ba…` and `09c4…`;
  - the P1 votes.

No site, code or deployment claim appears.

## 3. Five-file future seal: **APPROVED, conditionally**

The sealed files are `opus-publication.md.gz`, `opus-publication.json.gz`, `muse-publication.md.gz`, `muse-publication.json.gz` and `publication-binding.json`, all under `models/sherlock/literal-step/source-review-20261016/`. Conditions:

1. **Gzip captures.** Each `.md.gz` is the exact `RESULT.text` encoded as UTF-8, with no newline added and no normalization. Each `.json.gz` is the exact original adapter JSON. Every gzip is single-member, with mtime 0, a valid CRC and ISIZE, and no trailing bytes.
2. **Muse receipts.** The Muse files must be a completed, separate Muse review of this same manifest and commit. I cannot approve content I have not seen, and my verdict does not substitute for it.
3. **Binding file contents.** `publication-binding.json` lists:
   - the exact 23 initial paths and the 4 receipts, each with SHA256, byte count and mode `100644`;
   - the manifest `1c70379f…`, the commit `0f2108b7…` and the base;
   - no self-hash.

   It adds no new absolute paths, credentials or provider debug output, and makes no compile, test or acceptance claim.
4. **No other changes.** Nothing else in source or docs changes after approval. Root verifies exactly 28 paths in the final tree, and the 23 must remain byte-identical to this candidate.

## Conditions on this approval

- **C1 – Tree verification.** Before push, Root verifies that the tree of `0f2108b7` contains exactly the 23 paths with these blob hashes, with no end-of-line or text conversion and with the `.gz` files stored as binary. Any difference blocks publication.
- **C2 – Public fetch wrapper.** `emit_public_fetch` and `pack_witness` stay unused and unbound. Any consumer requires a binding review first, or a reviewed change that narrows them to `pub(crate)`.
- **C3 – Literal fragment use.** The fragment is never composed with a free enable. Its enable must come from constrained exactly-one dispatch, and consumers must gate `selected_expression` with that same enable.

  The following remain unwaived:
  - constant typing and `uiValid`;
  - F4 and least-equal projection;
  - StepInv and O1–O4;
  - the nonfuel byte bridge;
  - the 39-rule dispatch and free publication;
  - statement, trace and public/private binding;
  - resources;
  - B and general ADTs;
  - financial, PCD and target obligations.
- **C4 – Uncompiled code on `main`.** No publication text may imply compilation, emission or a passing test. Root acknowledges that `main` now compiles unbuilt sherlock_machine code into `mori-backend`. An admitted compile run should precede any dependent change. On failure, revert the registration rather than hot-patching unreviewed source.
- **C5 – Whitespace exception.** It covers note line 21 only.

## Read limitations

- **Hashes and gzip.** I verified no SHA256 values, byte counts or modes. I relied on the supplied decoded gzip views and representation claims.
- **Git state.** I did not observe the source commit, the base tree, the Git object modes, or the effects of `.gitattributes`.
- **SDK semantics.** I assessed `LessThan`, `CondSelect` and `ConstrainBits` only from prior review descriptions.
- **Compiled form.** I have no actual compiler or test evidence, and I did not inspect the whole compiler closure or `Cargo.lock`.
- **Published content I could only check for internal consistency.** These are new publications whose correctness I did not independently verify:
  - the packet's L4 and P1 documents and the `mori-core` reference sources;
  - `normal_tests.rs`, `identifier_rejection_tests.rs` and the fetch code (unchanged and previously reviewed).
- **Unavailable.** I had no access to the Muse publication review, future GitHub state, or the unpublished runtime receipts.
- **Method.** I applied no automated scanner. The leakage judgment comes from a manual reading of the supplied text only.