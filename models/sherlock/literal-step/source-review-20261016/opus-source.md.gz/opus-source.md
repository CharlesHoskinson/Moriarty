# A102 integrated source and raw-oracle review

**Reviewer:** Opus 5.5 high, designated security owner. This covers both the normal source/conformance review and the security judgment.
**Mode:** I read only the supplied text. No tools, commands, compiler, parser, SDK, tests or native operations ran. Native authority remains 0. All historical caps and counters are untouched.

**Subjects (hashes as declared, not recomputed):**
- Current candidate manifest `2ccd8027e250a5b6a57049c5da39570ad96518fe4745fbc683ad490c130afd63`.
- Independent raw oracle `deaaa61f5d1157ea99444c2cb9d5d729659740be02ba3f356e8ab46c7ae5d600`.

---

## 1. Source verdict: **APPROVED_SOURCE_WITH_LIMITS**

The scope is the exact 10-file graph: the 8 `sherlock_machine` Rust files, the full `crates/mori-backend/src/lib.rs`, and `models/sherlock/literal-step/MAPPING.md`.

I found no blocking defect in the actual constraint graph, the module graph or the scoped A102 conformance.

### 1.1 Module graph, imports and registration

- **`lib.rs`.** The only change is `pub mod sherlock_machine;`.
  - The pre-registration lib (`068307ea…`) had no `sherlock_machine` declaration. The whole directory was therefore previously outside this worktree's compiled crate.
  - The byte delta of +26 matches exactly that one line plus its newline.
  - `compile`, `compile_signed`, `compile_mode` and `lower_action_segment` do not reference A102.
- **`mod.rs`.**
  - Declares `mod literal_step;` privately.
  - Re-exports both constructors and the nine public types: `LiteralCapacities`, `LiteralConstructionError`, `LiteralEnvelope`, `LiteralImage`, `LiteralLane`, `LiteralSchema`, `LiteralStepBlock`, `LiteralStepInputs`, `LiteralTable`.
  - Adds `#[cfg(test)] mod literal_step_normal_tests;`.
  - The fetch types and functions are byte-unchanged; only the doc comment changed.
- **Name resolution, by reading only:**
  - The `use super::*` globs in the siblings pick up the parent's private imports (`Operand`, `Instruction`, `Identifier`, `Type`, `Fr`) and the private helpers `immediate` and `constrain`.
  - The test's two globs (`super::literal_step::*` and `super::*`) reach the same items through both paths, so they are not ambiguous.
  - Private `literal_step` items are not visible to the sibling test module, and the test does not need them.
  - The private alias `type Result<T>` in public signatures is transparent.
  - `?` converts `ConstructionError` through `From`.
  - Under Rust 2024, `operands()` returning `impl Iterator<Item=&Operand>` is well formed.
- **Test count.** There are exactly 16 tests: `normal_tests` 4, `identifier_rejection_tests` 2, `enabled_fetch_tests` 5, `literal_step_normal_tests` 5.
  - Both `include_str!` targets resolve to `<repo>/models/sherlock/{machine-circuit,enabled-fetch}/expected.json`.
  - The supplied bodies satisfy every asserted field.
  - The `enabled_fetch_tests` count of 41 instructions and 19 temporaries recomputes correctly from the source.
- **Public fetch wrapper.** `pub mod` makes the unchanged `emit_public_fetch` and `EmittedFetch::pack_witness` part of the public crate API.

### 1.2 Schema (`literal_schema`) against the normative L4 layout

- **Width formulas.**
  - `id(Z)` = bitlen(Z−1), at least 1, equal to ceil(log2 Z).
  - `count(Z)` = bitlen(Z), at least 1, equal to ceil(log2(Z+1)). It never overflows at `u128::MAX`.
  - `tag(v)` uses the `id(v)` width with maximum v−1. This excludes unused codes for ownerTag 2, Patterns 5, ConstantNode 3, binaryOp 7, FrameRow 9, ControlRow 10 and rule_tag 39.
- **Lane counts.** I recounted every lane against the crosswalk `ordered_record_columns`.
  - ProgramHeader has 16 lanes: `entryExprId` at index 0, `activeExpressions` at index 5, `activeConstants` at index 14.
  - Program tables have `[2,1,4,1,11,1,6,2,3,2,3,4,1,22,2]` lanes.
  - Root has 45 lanes.
  - State tables have `[22,2,5,2,17,36]` lanes, including the inline 17-lane `pendingFrame`.
- **Specific shapes.**
  - `OccurrencePaths.childPosition` is `count(max(XC,A+1))`, using checked addition.
  - `ValueRef.index` is `id(max(K,D))`.
  - `stackLimit` is `count(SL)` and is kept separate from `S`.
- **Minimum shape:** X, K and C must be nonzero, with T≥4, Q≥4, QF≥5.
- **Host overflow:** the cell count uses checked arithmetic.
- **Tamper resistance:** `emit_literal_step` recomputes the schema from its private capacities, so altered public lane metadata yields `SchemaMismatch`.

### 1.3 Every bit, Boolean, tag and count range

- **Unconditional ranges on all supplied operands.**
  - Every program, pre, post and envelope lane gets `ConstrainBits(w)` or `ConstrainToBoolean`.
  - Lanes with a maximum also get `LessThan(max, v, 128) == 0`.
  - The selected expression row is range-checked unconditionally as well. When disabled it is all zeros, which satisfies every range.
- **Instruction preconditions.**
  - Every `LessThan` operand is at most 128 bits, including the SL immediate, so the SDK's undefined-behaviour precondition is never violated.
  - Every `CondSelect` bit and every `Assert` condition is constrained Boolean.
- **Effect when disabled.** In the disabled branch, these constraints impose only representation validity. That is the G3 contract: the result is fail-closed incompleteness for invalid images, not a soundness gap.

### 1.4 Local A102 guards when enabled

- **Pre-state:**
  - `outcomeTag`, `outcomeValue` (both lanes) and `outcomeError` are all 0.
  - `controlLength` = 1.
  - Every column of CR0 is 0 except `exprId`, so `tag` = Eval and `pendingFrame` is 0.
  - Every column of rows 1..C−1 is 0.
- **Real G3 fetch:**
  - Uses `active_rows` = header[5] and `index` = `CR0.exprId`.
  - Enforces `activeExpressions ≤ X` and `exprId < activeExpressions`, with exactly one selector when enabled.
- **Selected row:**
  - `tag` = Literal, `valueRef.space` = Constant.
  - `nameId`, `binaryOp`, `unaryOp` and all four slice lanes are 0.
  - `occurrenceId` = `exprId`.
  - `valueRef.index < activeConstants`. This check matters because the width `id(max(K,D))` can exceed K.
  - All 11 expression lanes are covered.
- **Constants are not unfolded.** Neither the `Constants` nor the `ConstantFields` table is read. The post-state copies the reference by alias.

### 1.5 Post-state totality and preservation

When enabled, every post cell is fully determined by pre-state and program:

- Root: `controlLength` = 1. The 16 `remainingFuel` bytes are fixed by the borrow equations. The other 28 lanes equal pre, including all 16 `initialFuel` bytes, `stackLimit`, `depth`, `environment`, the outcome lanes and the four arena counts.
- `Data`, `DataFields`, `EnvCells`, `ValueSlots` and `FrameSlots`: every cell equals pre.
- `ControlRows`: CR0 has `tag` = Return and `valueRef` equal to the selected value reference. Every other control cell is 0.

No post cell is free.

The gating pattern is `ConstrainEq(CondSelect(enable,post,x), x)`. When disabled it is trivially satisfied, so another rule can constrain the shared post image.

### 1.6 Fuel

- **Nonzero check.** `zero_i = TestEq(pre_i, 0)`, folded as `all_zero` through Boolean `CondSelect`s starting from 1. When enabled, `all_zero` must be 0.
- **Borrow chain.**
  - `borrow₀ = enable`.
  - `next = borrow ∧ zero_i`, which is Boolean.
  - Per byte: `pre_i + 256·next = post_i + borrow`.
  - The intermediates `carry ∈ {0,256}`, `left ≤ 511` and `right ≤ 256` each get a 9-bit range check.
  - The byte lanes are 8-bit, so this is exact integer arithmetic with no field wrap and no packed 128-bit shortcut.
  - The final borrow is constrained to 0 unconditionally. When disabled every borrow is 0, so this stays satisfiable.

### 1.7 Envelope

- The envelope is `{rule_tag, charge}`, held outside StateBlock.
- `rule_tag` is unconditionally range-checked to 6 bits with maximum 38. `charge` is 8 bits.
- When enabled, `rule_tag` = 3 and `charge` = 1.
- Host `RecordEnvelopeA.rule_start_line` 102 in `observation.rs` is untouched and never conflated with the wire tag.

### 1.8 Namespaces

- The fragment uses two scratch namespaces: `%{scope}.local.temp.` and `%{scope}.expression_fetch.temp.`.
- After `%{scope}.`, they differ at the first character, so generated names can never collide and neither prefix nests inside the other.
- Inputs in either namespace, unprefixed inputs and an empty scope are all rejected.

### 1.9 The five literal tests (UNRUN)

- They inspect actual emitted wiring:
  - schema membership;
  - an embedded window of the real G3 fetch with the identical scope;
  - guarded post-to-pre equations for all preserved root and arena cells;
  - envelope and Return padding;
  - all 16 borrow edges plus the final borrow being 0.
- The `find_map` lookups in the decrement test match unique instructions; the `all_zero` chain uses distinct `CondSelect` bits.
- Specimen dimensions are construction data only.

### 1.10 Security findings and conditions (non-blocking)

1. **Public exposure.** `pub mod` makes `emit_public_fetch`/`pack_witness` public. That wrapper publishes every cell through PublicInput plus `Impact`, and its statement binding has never been reviewed. No consumer may treat its output as a bound statement. Narrow it to `pub(crate)`, or keep it unused, until a binding review exists.
2. **Enable provenance.** The fragment constrains `enable` only to be Boolean. With all rules disabled, any post image is accepted. The exactly-one dispatch derived from the constrained pre-state is mandatory before any composition, and this fragment must never be composed alone with a free `enable` witness.
3. **Unpaired selected operands.** `selected_expression` returns plain `Operand`s and drops the G3 `EnabledTypedOperand.enable` pairing. Any consumer must gate their use with the same `enable`.
4. **Constant row validity is not checked.** The fragment copies the Constant reference without checking typing or `uiValid` of `Constants` or `ConstantFields`. This is sound only under an F4-bound ProgramBlock, and with the binding mechanism unselected a prover-chosen ProgramBlock leaves this open.
5. **`O = 0` is accepted.** The fragment does not check `activeOccurrences ≥ activeExpressions`. This belongs to StepInv and ProgramBlock validation.
6. **Unchecked pre-state preconditions.** The fragment does not check pre-state O1, active bounds on preserved references, or `depth ≤ S`. Preservation introduces no new invalidity, but StepInv must establish the precondition.
7. **Stale comment.** The provenance comment at the top of `literal_step.rs` still says "Unregistered". It is disclosed and harmless.

**Unwaived:**
- the nonfuel Native-carrier to canonical L4 byte/Boolean bridge (OBL.G4@A102 / StepInv);
- full Program typing and `uiValid`;
- O1–O4;
- F4 and least-equal projection;
- global exactly-one dispatch over 39 rules and free-publication precedence;
- the other 38 events;
- the 27 unwritten P1 rows and P2–P6;
- statement, trace and public/private binding;
- resources and capacity admission;
- B and general ADTs;
- financial, PCD, ledger and stagenet obligations.

This approval does not authorise execution, admission, publication, or any claim about compiler or SDK behaviour.

---

## 2. Oracle data verdict: **ORACLE_DATA_APPROVED_WITH_LIMITS**

**Scope:** one hand-derived positive raw Step expectation for A102.

### 2.1 Typed snapshots

- The full Program is `Literal(UInt7)` plus `unused(ignored:UInt)->UInt99`.
- Before: Eval of that literal, env `{ignored→UInt42}`, frames `[Right(Mul,UInt9)]`, stack limit 5, fuel 256/257, Pending.
- After: identical except `Return(UInt7)` and fuel 255.
- This matches Rust lines 140–141 and K lines 102–104.
- A102 neither consumes nor touches the Right frame, which is correct.

### 2.2 ProgramBlock: all 15 tables and the 16-column header, with padding

- **Names.** The closure is {ignored, unused}, sorted by UTF-8 bytes.
  - NameBytes `[105,103,110,111,114,101,100 | 117,110,117,115,101,100]`, 13 active bytes.
  - Function nameId is 1; parameter nameId is 0.
- **Occurrences.** Entry is (0,0,(0,0)); function body is (1,0,(0,0)).
- **Expressions.**
  - Expression 0 is `(Literal, occ 0, Const 0)`; expression 1 is `(Literal, occ 1, Const 1)`.
  - Constant 0 = UInt 7 and Constant 1 = UInt 99, with no interning.
- **Builtin tables.** Types, Constructors and ConstructorFieldTypes `[0,2,0,3,3]` match the crosswalk builtins, with slices (0,0), (0,2), (2,1), (3,2).
- **Header.** All 16 values are correct.
- **Padding.** Every padding row is zero.

### 2.3 State tables and Root

- **Active rows.** Data `{42, 9, 88}` with row 3 as padding; DataFields inactive; EnvCell 0 (root) and EnvCell 1, an unreachable shadow whose parent is EnvCell 0; ValueSlots `{Const1, Data2}`.
- **Reference bounds.** Every reference lies within the active bounds of its own space.
- **Retained old rows.** Unreachable old rows are explicitly permitted for mid-segment arenas by L4 design and P5.
- **Frame.** FrameSlot 0 is Right/Mul with `(Data,1)`. Its `savedEnv` is 0, which is correct because Right carries no environment.
- **Control.** Pre CR0 is Eval with `exprId` 0. Post CR0 is Return with `(Const,0)`.
- **Constant alias versus Data.** The post references Constant 0 (UInt 7), while Data 0 holds UInt 42, so a Data-space reference to row 0 would decode to 42 rather than 7. This correctly distinguishes the aliasing behaviour from an unfold or a wrong-space copy.
- **Fuel bytes.** Pre `[0,1,…]`, post `[255,0,…]`, initial `[1,1,…]`. This is a real borrow across byte 1.
- **Dimensions.** Physical frame capacity `S` = 3, the `SL` bound = 9, and the semantic stack limit = 5 are all distinct.
- **Changed lanes.** Exactly three raw lanes change.

### 2.4 Hand evaluation against the fragment

I evaluated every A102 constraint in §1 against this assignment, with `enable` = 1 and capacities `program=[3,14,3,1,3,1,2,2,1,1,5,5,6,3,1]`, `state=[4,2,3,3,3,3]`, `SL=9`.

- Every lane range and maximum holds, including value index width 2 (from `max(K,D)` = 4), stackLimit 5 ≤ 9, and active types/constructors 4 ≤ 5.
- Every guard holds.
- The fetch selects row 0.
- Every preservation equation holds.
- The borrow equations hold.

So under my reading, the oracle is a satisfying assignment.

### 2.5 Observation domain

O1–O4 hold. There is no claim of startup reachability, a canonical boundary, or a result.

### 2.6 Limits on the oracle approval

- **Shared authoring model.** The candidate source and the oracle were both authored by Astra. Independence means the oracle was produced without reading the prospective fragment or its outputs. It is not a blinded, separate-author oracle.
- **Single positive case.** There are no negative, disabled-branch or hostile cases.
- **Not consumed by any test.** No actual comparison is possible until an admitted witness packer and SDK evaluation exist.
- **Logical rows only.** No byte stream or native carrier is defined.
- **Static checks not relied on.** `STATIC-CHECKS.json` (290 checks) is an author claim; I did not rely on it.

### 2.7 Hostile cases required later (owner-authored, unsatisfiable when enabled)

- remaining fuel = 0;
- post CR0 pointing at `(Data,0)`;
- `exprId ≥ activeExpressions`;
- Data-space value in the expression row;
- any tampered FrameSlot, EnvCell or initial-fuel cell;
- `rule_tag` = 102, or `charge` = 0;
- nonzero `pendingFrame` in pre, or `controlLength` = 2.

A further case must be satisfiable: disabled with an arbitrary valid post.

---

## 3. Coverage and reading limitations

**Read in full:**
- all 10 candidate files;
- the registration patch and work report;
- the L4 adoption record and all 7 L4 files;
- the P1 subject, adoption, r2 and both votes;
- the Argon envelope clarification;
- the exact A102 R5 object and all non-rule fields;
- `reference.rs`, `reference_types.rs`, `main.k`;
- `layout_a` `rows`, `state`, `observation`;
- the pre-registration `mod.rs` and `lib.rs`;
- backend and workspace `Cargo.toml`, plus `mori-core` `lib.rs` and `ir.rs`;
- SDK `ir.rs`;
- both `include_str!` fixtures;
- the prior Argon and Muse A102 reviews;
- the r2 build-worktree manifest;
- every oracle file, with inputs matching the pinned sources.

**Identity-only, not reviewed:** `A-RULE-OPERATIONS.md` body; `Cargo.lock`; the other 41 raw rule objects.

**Not supplied:**
- SDK circuit implementations: `ir_vm`, zk-stdlib `LessThan`, `CondSelect`, `ConstrainBits`. I relied on the `ir.rs` doc comments.
- `layout_a` `limits`, encode and decode.
- The bodies of other backend modules referenced by `lib.rs`.
- The `enabled-fetch` and `machine-circuit` `MAPPING.md` files.
- `ENABLED-FETCH-OWNER-REQUIREMENTS.md`.
- `INPUTS.json`.

**Not checked:**
- Byte identity of `lib.rs` and `mod.rs` beyond the patch hunks; I relied on the patch plus byte deltas.
- Every SHA256 value; all were taken as declared.

**Not claimed:** type-checking, compilation, whole compiler closure, instruction emission, test results, SDK acceptance, or native behaviour. All are UNRUN and unobserved.