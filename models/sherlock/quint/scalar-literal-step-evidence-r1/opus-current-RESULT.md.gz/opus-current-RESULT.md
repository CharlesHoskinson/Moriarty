# Verdict: **ACCEPT_SCOPED / PUBLISH_AND_REGULAR_MERGE_APPROVED_WITH_PREDICATES**

This is a tool-free static review of the text you supplied. I ran nothing and recomputed no SHA-256. Every digest below is taken as stated and must be machine-checked by Root.

This review does not do any of the following:

- admit an execution, reset a counter, or authorise a retry;
- change source, argv or env;
- change any U0–U7, M1–M17, MC, SP or G exit.

Native authority stays **0**. The old 98/126 cohorts remain unrun, and their counters, debits and failures are unchanged. Neither merging nor publishing promotes anything beyond the scope stated under *Result* below.

| Subject | Disposition |
|---|---|
| Source (qnt, fixture, two READMEs) | **ACCEPT**, normal two-case scope only |
| Captured actual results | **ACCEPT** as one finite normal observation |
| Source/evidence privacy | **ACCEPT**, with condition P3 and the residuals listed below |
| GitHub publication | **APPROVED**, conditional on P1–P7 and Q1–Q4 |
| Regular merge to `main` | **APPROVED**, conditional on M1–M5; within my assigned scope |

I found no concrete source or receipt gap that blocks any of these.

## Source

I derived both traces independently against the `c62c12…` model as supplied.

**UInt 7 case: `initProgram(p,1,0)`**
- Startup gives `Eval(0)`, an empty environment and frame list, limit 0, remaining 1, initial 1, `Pending`, rule 74, charge 0.
- `advance` sees `Eval` with remaining 1 and `evaluate` reaches `Literal(UInt(7))`. `validValue` holds, so rule 102 fires with charge 1, giving `Return(UInt(7))` and remaining 0.
- `advance` then sees `Return` with empty frames. Publication comes before the fuel check: rule 80, charge 0, `EmptyControl`, `Done(UInt(7))`, remaining 0.

**Bool false case: `initProgram(p,3,4)`** follows the same rules 74/102/80 with charges 0/1/0, ending at remaining 2.

**Snapshot comparison.** All six `.expect` snapshots match every field. Stack limit 0 is harmless because no `Push` is reached.

**Fixture.** `scalarLiteralStep.expected.json` is semantically consistent with the trace:
- depth 0 matches the empty frame list;
- charged steps 0, 1, 1 equal initial minus remaining;
- `EvalLiteral` and `None` are a dereferenced representation of the state, not serialization equality.

Quint never consumed the fixture.

**Statements that are true only of their freeze time.** These are accurately framed by the current README and must also be framed by the REVIEW-BINDING (P6):
- the qnt comment "Tests UNRUN";
- the fixture's "specified-only" status;
- "Current … reviews are pending" in both READMEs.

The original guide (`fa11ba…`) is the README that was bound into the executed candidate through SOURCE-PINS `c59ff0…`. It is preserved in the packet, and the current README (`f1660a…`) was never in the execution.

## Result

The receipts are internally consistent as supplied.

**Cross-references.** All of these resolve to the captured files:
- the admission references `25661867` (typecheck result), `28f949` (classification), `08e192` (stdout clarification), `1c0864` (argv) and `4230f6` (env);
- the 24 CAPTURES entries map one-to-one to the 24 `.gz` manifest members, with stored and decompressed digests agreeing as supplied.

**Typecheck.**
- Exit 0 in 1.24 s.
- stdout and stderr are both 0 bytes.
- Pins are equal before and after.
- Scratch is empty and the unit is unloaded.

**Test.**
- Exit 0 in 1.17 s; stderr is 0 bytes.
- stdout is 162 bytes. I counted the six-line form by hand and get exactly 162: 25 + 59 + 59 + 1 + 18.
- The stdout has LF endings and no SGR. It contains both named tests, `2 passing (9ms)`, and no failed, ignored or `[DEBUG]` lines.
- Pins (4 candidate files, 4667 package files, 3 symlinks) are equal before and after. Scratch is empty and the unit is unloaded.
- The observed `passed 1 test(s)` resolves the clarification's `nsamples` residual.

**Launch preconditions.**
- `memory` and `pids` are delegated.
- Both mask targets exist, and the kernel release matches `uname -r`.
- Both units were not-found before launch.
- stdin was `/dev/null`, file descriptors were closed, and captures went outside both candidate and scratch.

**What this establishes, and only this.** The Quint 0.32.0 TypeScript evaluator, under these pins, reproduced two finite deterministic three-state traces of the unchanged generic model. It does not establish any of the following:
- Rust-evaluator, K, Lean, Clean or circuit correspondence;
- any theorem, constraint check or native proof;
- any target, ledger, financial or security result;
- acceptance of any parent milestone.

## Privacy

**No sensitive content found.** In the decompressed text supplied, I found no credentials, tokens or keys, and no private Fenrir or Clean content. ENV contains only path, locale and session-socket variables.

**Accepted low-sensitivity disclosures.** These are host and identity metadata, not secrets:
- the username `charl` and `/home/charl/...` absolute paths;
- uid 1000;
- the WSL kernel release;
- model usage and cost figures;
- provider request and response IDs.

**Not verifiable from text.** I cannot see `.gz` header bytes. The three 20-byte empty captures are consistent with a filename-less, minimal gzip header. The others need P3.

## Publication predicates

All checks below are byte or metadata observations made by Root. None executes models or tests.

**Before commit**

- **P1. Path set and bytes.** The staged path set is exactly the 29 manifest members, plus the 4 fresh review captures, plus 1 REVIEW-BINDING, for 34 paths. Each of the 29 is byte-equal to its manifest SHA-256 and byte count. Each of the 5 new paths is bound by digest in REVIEW-BINDING. `CAPTURES.json` is unchanged.
- **P2. Diff against base.** The diff against base `9a7c042` touches only those 34 paths, and only under `models/sherlock/quint/`. In particular:
  - no `.github/**` or `site/**` path is touched;
  - `kProfileMachine.qnt` is untouched, and its base blob has SHA-256 `c62c12…`;
  - if `SCALAR-LITERAL-STEP-README.md` already exists at base, its base blob must be `fa11ba…`, and the change must be recorded as a modification.
- **P3. Gzip headers.** Every committed `.gz` (24 + 4) has MTIME 0, no FNAME, FCOMMENT or FEXTRA field, and decompresses to the bound uncompressed SHA-256.
- **P4. No filters.** No `.gitattributes` text, eol, filter or LFS rule applies to these paths, and the committed blob bytes are identical to the worktree bytes.
- **P5. Privacy re-scan.** A re-scan of all decompressed new review captures finds no secrets and no private Fenrir or Clean content.
- **P6. REVIEW-BINDING content.** It states that the "UNRUN", "specified-only" and "pending" texts are freeze-time status. It records each reviewer's disposition and scope limit, preserves all historical identities (Root, Sol, Muse, prior Opus, Astra steering) without relabelling, and states native authority 0 with old counters unchanged.
- **P7. Commit.** A single commit with parent `9a7c042`. The author comes from the existing git config. The commit message and PR body make no acceptance claims beyond the *Result* scope, and the user's email appears nowhere other than the standard author field.

**Push and PR**

- **Q1. Push target.** Push to a new non-default branch whose absence on the remote is verified before pushing. No force push, no tags, and no direct push to `main`.
- **Q2. Remote equals local.** The remote branch head equals the local commit SHA, and the remote blob SHAs for all 34 paths equal the local ones.
- **Q3. PR contents.** The PR has base `main` and head equal to that SHA, and its files list is exactly the 34 paths with the statuses recorded in P2.
- **Q4. Bounded metadata capture.** Within a bounded window, capture verbatim: the PR, the head SHA, check-suites and check-runs for that SHA, and workflow runs for the branch.
  - Expected: zero `site` runs (path filters not met) and zero `rust` runs (the file returns 404 on every ref involved).
  - Any other check run is recorded as a residual. Do not cancel, re-run or dispatch anything.

## Merge predicates

- **M1. Hold conditions.** Merge only if all of the following hold; otherwise hold:
  - the PR head still equals the verified SHA;
  - GitHub reports the PR mergeable with no conflicts;
  - if `main` has advanced beyond `9a7c042`, none of its intervening changes touch the 34 paths;
  - no required check is failing.

  If any observed check run concludes failure or action_required, hold for owner review and do not merge over it.
- **M2. Merge method.** Use a regular merge commit, not squash or rebase, with no admin or branch-protection bypass.
- **M3. Post-merge tree.** The new `main` head is the merge commit, with parents equal to the prior `main` head and the PR head. The diff from the prior `main` to the merge commit is exactly the 34 paths, with bytes as in P1.
- **M4. Post-merge metadata.** Capture workflow runs and the latest Pages build or deployment for the merge commit, before and after. Expected: no `site` run and no Pages deploy. Any run that appears is recorded as an anomaly and not cancelled.
- **M5. Branch.** Do not delete the branch in this step.

**Failure handling.** If any predicate fails, stop and record it. Do not amend, force-push or retry. Any altered content needs a fresh exact-candidate review.

## Residuals

None of these is blocking, none is promoted, and all are retained.

1. **Shared timestamps.** Each admission record shares its exact UTC timestamp with the matching STARTED record, and with its no-other-writer attestation. The order "admission before launch" is therefore attested by Root's process, not shown by distinct timestamps.
2. **Muse membership digest.** Muse bound membership `facbb25b…`, which is not reproduced in this packet. This review's independent re-derivation of the source is what I rely on, not that binding.
3. **K digest.** The K digest `b3746ff5…` refers to source not in this packet. No K claim depends on it.
4. **README date.** "October 16, 2026" in the README is the UTC date of the captures. The local date may have been October 15.
5. **Scratch inspection method.** The receipts do not record that scratch was inspected with lstat. An empty listing is sufficient for this observation.
6. **Not enumerated by this review:** installed GitHub Apps, future automation, and anything beyond the observed workflow list.
7. **Not recomputed by me:** every digest and every equality claim. Hash equality is a machine observation, not a correctness proof.
