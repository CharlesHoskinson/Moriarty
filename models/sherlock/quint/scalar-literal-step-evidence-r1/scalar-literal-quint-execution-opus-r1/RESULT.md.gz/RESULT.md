# Verdict: **ELIGIBLE_FOR_ROOT_ORDINARY_ADMISSION_WITH_CONDITIONS**

I found no actual gap that blocks admission. This is a tool-free static review of the text you supplied. I did not run anything, and I did not recompute any SHA-256, including the proposal, argv, env, source, package and executable digests. Every digest below is taken as stated and must be bound by Root at launch. Native authority stays **0**. This classification admits nothing, resets no counter, changes no global policy, and allows no automatic retry.

## Basis

**Model semantics.** I derived the two traces independently and they agree with Muse.
- `initProgram(p,1,0)` produces `Eval(0)`, an empty environment and frames, `Pending`, remaining 1, rule 74, charge 0.
- `advance` sees `Eval` with remaining 1 and takes `evaluate` → `Literal(UInt(7))`. `validValue` holds, so rule 102 fires with charge 1, giving `Return(UInt(7))` and remaining 0.
- `advance` then sees `Return` with empty frames and publishes before the fuel check: rule 80, charge 0, `Done(UInt(7))`, remaining 0.
- The Bool case is the same with fuel 3 and limit 4, ending with remaining 2.
- All three `.expect` snapshots match every field.
- `scalarLiteralStep.expected.json` and the README are **never read by Quint**. The fixture-to-Quint equivalence rests only on the Muse source review, not on this execution.

**Input closure.**
- `load` reads `scalarLiteralStepTest.qnt` relative to the `--chdir` candidate directory.
- `fileSourceResolver` reads only the one static import, `./kProfileMachine(.qnt)`.
- Tests come from `definitionsByModule.get("scalarLiteralStepTest")`, filtered to `kind==='def'` and the anchored regex. There is no file discovery. The imported `init` and `step` cannot match.

**Tool branch.**
- `--backend typescript` is a declared yargs choice, and `.strict()` accepts every supplied option.
- `runTests` takes the `Evaluator` branch, so `CommandWrapper` is never constructed.
- `getRustEvaluatorPath`, `fetchEvaluator` and `spawn` are unreachable on this path.
- The top-level code of `binaryManager.js` and `config.js` only defines functions.
- `prepareOnTrace` writes only when `outItf` is set, and it is unset. `--out` and `--source-map` are absent.
- Neither stage reads stdin, because the only reader, `askUserYesNo`, is reached only through `verify`.

**Containment.** This carries the boundary for any transitive package code I was not shown.
- `--unshare-net` removes both TCP and abstract-socket reach, including DBus and WSL interop.
- `--unshare-pid` together with `--die-with-parent` means that killing bwrap kills the whole namespace.
- `--new-session` blocks TIOCSTI injection.
- The root is an empty tmpfs remounted read-only, so `/tmp` is read-only too. Only the leaf binds are visible, and `/home/charl` has no contents.
- The only writable places are scratch and the memory-backed `/dev`, which is charged to the scope.
- `--clearenv` leaves 7 variables, plus `PWD`, `SHLVL` and `_` from bash. There is no `BASH_ENV`, `NODE_PATH`, `QUINT_HOME` or `FORCE_COLOR`, and no token.
- `ulimit -f 16384` is 16 MiB in 1 KiB blocks.
- Exit status passes through cleanly: systemd-run `--scope` execs timeout, timeout runs bwrap, bwrap runs bash, and bash execs node.

## Prerequisites (each has a concrete execution reason)

1. **Root formal admission is recorded separately.** It must cover freshness, no other writers, input pins, units currently unloaded, and the launch conditions, as you already require.
2. **Exact binding.** The executed argv must be byte-identical to the corresponding ARGV.json entry, and the outer environment must be exactly ENV.json. Any edit, including one to work around a launch error, needs a new proposal.
3. **Pins are taken on the bound copies.**
   - Hash the candidate paths that are actually bound, not the worktree, immediately before and after each stage.
   - The candidate directory must contain the four regular files, with no symlinks and link count 1. A hardlink to the worktree would let an outside writer change the input mid-run.
   - The package manifest must re-verify at 4667 files and 3 symlinks. Any symlink that resolves outside the package should be recorded, since it fails closed inside the sandbox.
   - Executable pins must re-verify pre and post.
4. **Scratch hygiene.**
   - Before launch, scratch must exist, be empty, belong to the user, and not be a symlink.
   - Post-stage inspection must use lstat and must not follow links. The sandbox can plant symlinks there, and a following reader would pull host files into the receipts.
   - Any entry at all counts as unexpected output.
5. **Stdio and file descriptors.**
   - stdin is `/dev/null`.
   - Only fds 0, 1 and 2 are inherited, because bwrap passes extra fds through and an inherited socket would cross the netns.
   - stdout and stderr go to separate captures outside both candidate and scratch.
6. **Launch preconditions.** If any of these fails, abort before launch, which does not consume a run.
   - Both mask targets exist: `/usr/lib/wsl` and `/usr/lib/modules/6.18.33.2-microsoft-standard-WSL2`, the latter matching `uname -r`.
   - Neither unit name is loaded.
   - The user manager's delegated subtree includes the `memory` and `pids` controllers. Without them, `MemoryMax`, `MemorySwapMax` and `TasksMax` are silently not enforced.
7. **Stage gating.** The test stage launches only if the typecheck predicate holds. Before launching it, re-verify condition 3, verify scratch is empty again, and confirm the test unit is unloaded.

## Result predicates

**Typecheck PASS.** All of the following must hold:
- Outer exit is literally 0, with no signal and wall time under 60 s.
- stdout and stderr are byte-empty. On success `outputResult` prints nothing, because there is no `--out` and no seed.
- Scratch is empty afterwards.
- All pins are equal pre, post and as declared.
- The unit is no longer loaded and no process remains.

**Test PASS.** Every typecheck condition must hold, and in addition stdout, with ANSI SGR stripped, consists only of:
- an empty line, then `  scalarLiteralStepTest`;
- exactly two lines of the form `    ok <name> passed 1 test(s)`, one for each of `uint7LiteralAndFreePublicationTest` and `falseLiteralAndFreePublicationTest`, in either order;
- an empty line, then `  2 passing (<int>ms)`;
- no `failed`, `ignored` or `[DEBUG]` lines.

**Exit 0 alone is insufficient.** If zero tests match, `runTests` returns `right`, so the process exits 0 with nothing tested. The stdout predicate is what guards against that.

**Failure handling.** Anything else counts as a terminal failure or anomaly for that exact subject. That covers a typecheck failure (the test stage then never runs), exit 124 or 137, SIGXFSZ, any stderr bytes, or pin drift. There is no retry. If you expect a fixed Node warning on stderr from the prior capture, freeze its exact bytes before launch, not afterwards.

**What a PASS establishes.** Only that the Quint 0.32.0 TypeScript evaluator, under these pins, reproduces two finite deterministic three-state traces for the unchanged generic model. It establishes nothing about the Rust evaluator, K, Lean, Clean, circuit or native behaviour, or correspondence to any target. It also does not mechanically check the JSON fixture.

## Residuals (recorded, not promoted, not blocking)

- Host `/usr`, `/etc`, `node` and its libraries; any Debian Node module fallback paths; and the transitive top-level code of the pinned package. All of these are bounded by the containment above.
- uutils `timeout` process-group semantics. Process closure does not depend on them, because pid-namespace teardown through `--die-with-parent` handles it.
- The IPC, UTS and cgroup namespaces are not unshared. This is not material on the reachable path, so I am not adding a condition.
