# Scalar literal transition comparison sources

The two tests in `scalarLiteralStepTest.qnt` exercise the unchanged generic
`sherlock-k-a/1` model on the same independent UInt 7 and Bool false rows used
by the handwritten step and Clean source candidates. `scalarLiteralStep.expected.json`
is the exact hand-derived fixture frozen before emitter implementation. No
model or interpreter generated its expectations.

Each test compares all Snapshot fields before execution, after charged literal
rule 102 and after free publication rule 80. Startup rule 74 is explicit. The
UInt case publishes at zero remaining fuel; the Bool case retains two units.
Depth derives from the empty frame list and consumed work from initial minus
remaining. No Candidate B helper/allocation counter is invented.

Both tests, parsing and typechecking are UNRUN. These sources add no observed
K/Quint/Clean/circuit correspondence, theorem, constraint check, native proof
or target result. The earlier normal model receipts remain scoped to their
own files and were not rerun. Independent source review and separately inspected
ordinary execution remain pending. All parent exits and native authority zero
remain unchanged.
