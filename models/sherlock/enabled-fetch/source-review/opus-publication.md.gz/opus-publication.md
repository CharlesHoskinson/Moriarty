# Opus 5.5 high: L4 layout vote and enabled-fetch publication review

## Scope, limits and correlation

- **What I read.** I read the complete supplied text of:
  - the seven L4 files, SOURCE.patch, MATERIALIZATION-MAP, WORK_REPORT and STATIC-CHECKS;
  - my prior L3 findings and Muse's L3 vote, as history only;
  - the publication manifest and all 21 selected files, using the decompressed text for the gzip files;
  - the base-context files (`lib.rs`, `site.yml`, AGENTS.md and the product contract);
  - Root's independent normal examples.
- **Nothing executed.** I recomputed no hashes, inspected no gzip header bytes, and saw no remote, ruleset or Git object state. All hashes are Root-recorded.
- **No authority granted.** I classify no command and grant no runtime, admission or user permission. Native authority remains 0.
- **Correlation.** This vote comes from the same model and effort that wrote:
  - F1–F5 and G1–G4; the G1/G2 text was materialized verbatim from my prior review;
  - the captured G3 security source review;
  - concept note 003 and the original 003 README proposal.

  This review will also become one of the seal receipts. Treat these votes as correlated with that work, not as independent confirmation of it.

---

# Verdict 1: L4 current-A representation

## Vote: ADOPTABLE_WITH_LIMITS

This is my vote as host codec interface and source basis for `sherlock-k-a/1`, within the security scope. I found no real defect in the L4 bytes. My L3 votes are history only; this vote covers the current L4 bytes.

### Disposition of G1–G4

**G1: field-block append timing. Resolved, verbatim.**
- The design.md paragraph and the crosswalk `G1` string match my required text character for character.
- With post-order (F1(c)), each parent's field block is appended after all of its children's blocks, at the moment the parent is appended. That makes ConstantFields and DataFields a total function of traversal order.
- Fieldless nodes (Nil, UInt, Bool) are explicitly (0,0), which agrees with the empty-slice rule.
- It does not conflict with the strict orders: field entries still point to earlier nodes or to Constants.
- The interfaces.md summary ("appended with their parent node after its children") is faithful and adds no rule.

**G2: non-Match child positions, root paths and Entry functionIndex. Resolved, verbatim.**
- "In the order listed above" resolves to the preceding paragraph's list: Let value/body, Binary left/right, Unary operand, If condition/then/else, Call arguments.
- Non-Match positions therefore equal the index within `childSlice`. Match scrutinee 0 also equals its `childSlice` index, and arms take k+1.
- Root paths are (0,0). The `count(max(XC,A+1))` width covers every case.

**G3: StepInv labelled as future work. Resolved.** The label appears in design.md and in crosswalk `step_inv_status`. It is placed at the start of the Observation-domain section, although StepInv is first used in the Representation-domain references bullet. That placement is only a nit.

**G4: map provenance. Resolved.**
- The L4 map has equal, replace and insert spans that reconstruct both snapshots.
- It pins the two unchanged F4 paragraphs separately.
- The design.md F4 character offsets shift by exactly 800, which equals 32861 − 32061. All three insertions precede that paragraph, so the offsets are consistent.
- In OWNER-REPAIR-PROVENANCE, the single L3 sentence that was false ("map records exact edits") was rewritten to acknowledge the stale map. The historical packet itself is untouched. That is a proper correction of the current file, not history rewriting.

### Integrity: no scope narrowing

The patch is confined to:
- the provenance heading and the one corrected sentence;
- two crosswalk keys added after an unchanged equal span (lines 0–1378);
- three design.md insertions;
- one interfaces.md paragraph;
- the proposal.md revision lines.

I hand-recounted these values and they are unchanged:

| Item | Count | Detail |
|---|---|---|
| Variants | 55 | Tree 2, Value 4, Type 4, BinaryOp 7, UnaryOp 2, Pattern 5, Expr 8, Frame 9, Control 10, Outcome 4 |
| Struct fields | 22 | |
| Snapshot roots | 8 | |
| Header columns | 16 | |
| Rule rows | 39 | |
| Refusal classes | 7 | |

The following are also unchanged:
- no numeric capacity, cost or k;
- no B counters;
- no change to semantic or observation domains;
- F3, F5 and H1 text unchanged;
- F4 still UNSELECTED, with the per-step in-circuit search prohibition intact.

### Residual items

These are nits and implementation notes, not defects.

1. **Stale labels.**
   - proposal.md still says "neither L3 vote is asserted here".
   - The design.md preamble mentions only L3.
   - Crosswalk `prepare_a_determinism.authority` still says "L3 clarification pending fresh review".

   These are cosmetic. Fix them in the next substantive revision, not as a reason to re-vote.
2. **Inactive id columns (implementation note).** G2's Entry `functionIndex=0` is consistent only if the decoder treats it as a zero-padded column under the Padding rule, not as a range-checked `id(F)`. Otherwise a program with no functions (activeFunctions=0) would decode as WrongRepresentation. The same applies to every inactive `nameId`, `valueRef` and similar column when its table is empty. Range checks apply only to columns the active variant actually uses.
3. **Function-owned occurrences.** For these, `functionIndex` is implied to be the owning function's source index. The column name implies this, but an explicit statement would help. Encoders should follow that reading.

### Root's independent normal examples (partial expectations only)

I hand-checked all ten cases against L4 and found no real normal discrepancy. The cases cover:
- Nil, false and 0 distinct;
- the [7,9] post-order;
- `Branch(Leaf7,Leaf7)` unfolding to 5 nodes and 4 field slots;
- Invoke slots (0,2);
- Some(empty) versus None bindings;
- Enter at row 0;
- Push payload, then environment, then the next row, then frames;
- independent per-root EnvCells for the shadowed name;
- duplicate literals giving occurrence 2 with held reference 1 and two uninterned Constants;
- Match paths [], [0], [1], [2].

Limits of these examples:
- They were derived from the L3 manifest (`d46e3f…`), not the L4 bytes.
- They list node fields but not `fieldStart`/`fieldLength`, so they do not discriminate G1.
- They exercise G2 only at depth one and only for Binary and Match.

Before codec tests, I recommend adding:
- explicit field-slot positions;
- Let, If and Call positions;
- a path of depth two or more;
- a function-owned occurrence with nonzero `functionIndex`;
- decoder negative cases for an empty slice with nonzero start and for a non-suffix slice.

These examples are not a selected wire schema.

### Implementation start

From the security scope, source drafting may begin now. "Source" means writing host-only code; no build, test, SDK or native execution is requested or granted. The permitted adapters are:
- `prepareA`;
- `encodeObservedA`;
- `decodeObservedA`, in Canonical and Step modes;
- `projectA`; host-side least-equal search is allowed, because F4 restricts only in-circuit enforcement;
- `materializeRecordA` and `materializeTraceA`;
- a call into the existing `first_difference` comparator.

These conditions apply unchanged:
- H1: host tooling only, with no untrusted or network consumer.
- F5: refuse incrementally at the first overflow, including during closure search and F3 unfolding.
- F3: unfolded-envelope capacity is an input; this work admits none.
- Exactly the seven located refusal classes, never coerced, never an Outcome or StepRecord.
- Structural ProgramMismatch only, never a digest or Arc identity.
- No numeric defaults.
- No B fields, and no origins inferred from structural equality.

**Muse's L3 conditions.** Muse's L3 vote conditioned implementation on Root recording adoption. A fresh Muse L4 normal vote on these bytes and Root's adoption record are therefore still required before:
- any adoption claim;
- a complete or deterministic codec claim;
- registration;
- publication of codec source as adopted.

I do not substitute for that vote.

**Still not permitted:**
- `emitStepA`, or acceptance logic in `packStepWitnessA`;
- any ProgramBlock digest or statement binding;
- any F4 mechanism;
- P1–P6 masks or append sequences;
- any SDK, native, ledger or target work.

F4, the physical P1–P6 decisions, B, financial, native and target work all remain unselected. No codec exists today.

---

# Verdict 2: Enabled-fetch publication candidate

## Verdict: PUBLICATION_APPROVED_WITH_CONDITIONS

This covers source commit, push, PR and a regular merge to main. It is not native acceptance or product acceptance, and none is required for an expressly unregistered source proposal.

### Change scope

**The 16 changed paths.** Classified from the manifest flags; base blob identity still needs Git verification.
- 3 modified:
  - `sherlock_machine/mod.rs`: the G2 bytes plus the enabled export and test module;
  - `AUTHORSHIP.json`;
  - the atlas `README.md`.
- 13 added:
  - `enabled_fetch.rs` and `enabled_fetch_tests.rs`;
  - enabled-fetch `MAPPING.md` and `expected.json`;
  - source-review `README.md` and `SOURCE-FREEZE.json`;
  - the four review gzips;
  - `ITERATION-003-ENABLED-FETCH.md`;
  - the two iteration-003 provenance gzips.

**The 5 unchanged paths** are `fetch.rs`, `identifier_rejection_tests.rs`, `normal_tests.rs`, and machine-circuit `MAPPING.md` and `expected.json`.

**Consistency checks:**
- SOURCE-FREEZE's ten pins equal the manifest hashes.
- AUTHORSHIP's iteration-003 pins, `note_sha256`, `readme_sha256` (`78a595…`), reply gzip (`00831ab0…`) and snapshot gzip (`d6af72…`) all equal the selected hashes.
- `opus-source.md.gz` and the provenance reply gzip are intentionally the same bytes.

**What is excluded:**
- Base `lib.rs` has no `sherlock_machine`, and no registration or Cargo change is selected. G3 therefore stays UNREGISTERED and cannot affect main's Rust build.
- No `site/**`, `.github/**`, openspec or L4 layout bytes are included.
- No Fenrir/Clean source, credential, key or witness material is included.
- Notes 000–002 are not selected, so they stay unchanged.

**Code.** The G3 source bytes equal the bytes both source reviews covered. On re-reading `enabled_fetch.rs` and its tests I found no new defect; my earlier construction findings carry over. All eleven tests and every compiler, SDK, model, k, proof, ledger and stagenet step remain UNRUN, and the files disclose this.

### Real defects in the 21 bytes

None are blocking.

### Observations (non-blocking)

1. **Review coverage of README and AUTHORSHIP.** The captured Muse source review covered an earlier README and AUTHORSHIP. Its quoted wording matches README `0cf515…`, before Root's third provenance edit to `78a595…`. The captured Opus review predates both. The final README and AUTHORSHIP bytes are therefore covered only by this review and the final Muse publication review. The source-review README already says those captures are not publication approvals.

   I reviewed Root's edits and found them accurate:
   - PR #91 and merge `5178d576`;
   - iteration 003 local at its freeze and now carried with G3;
   - no note text changed.
2. **Freeze-time wording.** Several statements are stale but explicitly freeze-scoped:
   - AUTHORSHIP's iteration-002 and iteration-003 `review_scope` ("pending");
   - the note-003 sentence saying G2 is not merged;
   - the stale gap-1 wording in G2's machine-circuit MAPPING.

   The current README and publication history carry the present status. Leave these as they are.
3. **Absolute paths.** The Muse capture contains absolute local paths (`/home/charl/...`). They reveal a username and directory layout, not a credential. They are part of a verbatim capture and must not be edited.
4. **Fenced text in a `.json.gz`.** `iteration-003-opus-public-reply.json.gz` contains fenced Markdown text, not parseable JSON. This is disclosed in `original_reply_capture_scope`.
5. **Schema drift.** AUTHORSHIP `readme_integration_changes` uses `editor` in one entry and `by`/`change` in another. This is cosmetic.

### Receipt seal contract

This defines the contract now. It does not review the future receipt bytes.

The seal adds exactly five new files under `models/sherlock/enabled-fetch/source-review/`. It changes no existing path, and none of the 21 selected bytes. Recommended names, distinct from the existing captures:
- `opus-publication.md.gz`
- `opus-publication.json.gz`
- `muse-publication.md.gz`
- `muse-publication.json.gz`
- `FINAL-REVIEW-BINDING.json`

**Gzip format.** Applies to each of the four captures.
1. A single member with a 10-byte header: `1f 8b 08`, FLG = 0x00, so no FTEXT, FEXTRA, FNAME, FCOMMENT or FHCRC.
2. One fixed MTIME, 0 recommended, identical across all four. A fixed OS byte, recorded in the binding.
3. Valid CRC32 and ISIZE, and the file ends at the trailer with no trailing data.

**Capture content.**
4. **Text captures (`.md.gz`).** The decompressed bytes are exactly the UTF-8 encoding of the JSON-decoded `text` field of the canonical RESULT.json:
   - no BOM;
   - no LF/CRLF normalization;
   - no Unicode normalization;
   - no newline added or removed.
5. **Adapter captures (`.json.gz`).** The decompressed bytes are byte-identical to the adapter's RESULT.json as written. It must not be re-serialized.
6. **Cross-check.** The `text` field of each decompressed `.json`, UTF-8 encoded, must equal the decompressed `.md` exactly.

**Binding file (`FINAL-REVIEW-BINDING.json`).** Deterministic UTF-8 JSON, LF line endings, one final LF, stable key order. It must list:
- base `5178d576…`, the branch name, and optionally the pre-seal commit and tree;
- the 21 selected paths with sha256, byte count, Git mode (100644) and a changed-from-base flag; exactly 16 must be true;
- the 4 receipts with path, kind, gzip sha256 and bytes, decompressed sha256 and bytes, and reviewer key;
- per reviewer:
  - **Requested identity:** recorded verbatim with its adapter field path; for Opus `claude-opus-5-5`, for Muse `muse-wonder-1.0`.
  - **Returned identity:** recorded verbatim with its adapter field path, never inferred.
  - **Effort:** requested `high`. Returned effort is recorded as NOT_REPORTED unless the adapter actually reports it. Neither existing adapter schema does.
  - **Terminal status:** recorded verbatim in each adapter's own fields, for example Muse `terminal` or Opus `is_error`. "Completed" must not be synthesized where the record lacks it.
  - **Ids and scope:** request and response ids where present, and the review scope.
  - **Verdict:** omitted, or quoted verbatim; never paraphrased.
- these limitations:
  - Root-recorded, not provider-signed; this applies to the existing archive captures too;
  - source-only and UNREGISTERED;
  - all eleven tests and all compile, SDK, model, k, proof, ledger and stagenet work UNRUN;
  - native authority 0;
  - the registered backend candidate excluded;
  - no product acceptance;
  - U0–U7, M1–M17 and all gates unchanged.

**Self-reference.**
- The binding contains no self-hash. It states that Root's independent runtime final manifest records the binding's sha256.
- The seal makes no README, index, CI, feature, pin, lib-registration or source edits.

### Pre-push predicates

1. **Ancestry.** The pre-seal commit C1 has its parent chain ending exactly at `5178d576`. The seal commit C2 has exactly one parent, C1.
2. **C1 scope.** `git diff --name-status base..C1` shows exactly the 16 paths: 3 M and 13 A. There are no deletions, renames, copies, mode changes, symlinks or submodules.
3. **Seal scope.** `C1..C2` shows exactly the five seal paths, all A.
4. **Hash source.** Hashes are computed from the Git object store (`git cat-file`), not the working tree, because the WSL checkout could apply CRLF conversion or filters. Check `.gitattributes` for any `eol` or `filter` affecting `*.md`, `*.json` or `*.gz`. Every hash is checked:
   - all 21 selected paths against the manifest;
   - all 5 unchanged paths against the base;
   - all 25 binding entries.
5. **Integrity and hygiene.**
   - All six existing gzips and four new gzips decompress with a valid CRC.
   - The new gzips meet the seal contract.
   - A secret scan of all 26 blobs finds no credentials or keys.
6. **Push.** Push the feature branch only, with no force-push to main. The commit message and PR body state source-only, unregistered, UNRUN, no native or product acceptance, and the seal.

### Pre-merge predicates

1. **Base unchanged.** Remote main is still `5178d576`. If main has moved, stop. Do not silently rebase; any new base needs a fresh scope check.
2. **Head re-check.** The PR head SHA equals the locally verified C2. Re-check head, parents, path set, modes and blob contents against the 25 binding hashes. The binding blob's sha equals Root's runtime-manifest record.
3. **Muse review.** The final Muse publication review of these exact 21 bytes completed with no blocking defect.
4. **Checks.** Record every check run actually attached to the PR head.
   - `site.yml` is path-filtered to `site/**` and should not run. "No checks" is not a pass.
   - Do not assume no other automation exists. Any failing or unexpected run blocks the merge until diagnosed.
   - No admin or branch-protection bypass.
5. **Merge type.** Regular merge commit only, not squash or rebase.

### Post-merge predicates

1. **Merge structure.** Main is a merge commit M with parents exactly [`5178d576`, C2]. M's tree equals C2's tree.
2. **Path set.** At M, all 26 blobs match. The diff from base to M is exactly 21 paths: 16 plus 5.
3. **No deploy.** No Pages deploy or other automation ran for the merge; record any that did.
4. **History.** Record the merge as source publication only: unregistered, UNRUN, no acceptance. Preserve the branch until verification is done.

### Honest limitations

- I verified no hash, gzip byte, Git mode, base blob, remote state, ruleset or workflow list.
- The 3 M versus 13 A split is inferred from the manifest flags.
- My approval does not cover the future receipt bytes, beyond the contract they must satisfy.

---

## Real defects versus future work

**Real defects:** none in the L4 bytes, and none in the 21 publication bytes.

**Nits:**
- stale L3 labels in proposal.md, the design.md preamble and the crosswalk authority string;
- StepInv label placement;
- implicit `functionIndex` for function-owned occurrences;
- AUTHORSHIP schema drift;
- the fenced-text `.json.gz` name;
- absolute paths in the Muse capture.

**Implementation notes:**
- inactive-column range checks;
- Root's examples should add field-slot, depth-two-or-more and function-occurrence cases.

**Future work, unchanged:**
- F4 selection; P1 reference outputs, then P2–P6;
- the MD5–MD7 manifest corrections;
- StepInv and the G.4 components;
- L04 binding, L05 capacities and L06–L10;
- G3 registration and execution;
- dispatch provenance and consumer gating;
- the Fr adapter for 2^128;
- B, financial, native, privacy, history, ledger and target obligations.

No U0–U7 or M1–M17 obligation is closed.