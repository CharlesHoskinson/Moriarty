## Review scope and evidence limits

This is a fresh, non-author, source-reading review only. I inspected the ten frozen G3 candidate files listed in `SOURCE-MANIFEST.json` (`d5443f78…`), the owner requirements supplied as context, the real backend/core/SDK declarations forwarded with the packet, the five new tests, the six inherited tests, the independent enabled-fetch fixture, concept note 003, the updated atlas README, and `AUTHORSHIP.json`.

I ran nothing. Compilation, all eleven tests, serialization, SDK load/check/evaluation, model/k, proof behaviour, and every owner-prescribed executable rejection/satisfaction case remain **UNRUN**. I do not recompute the supplied SHA256 pins in this session; hash values below are the frozen, Root-recorded values from the packet. SDK `ir_vm` and `ir_instructions` implementations were not provided, so I make no claim about actual instruction semantics, preprocessing, redefinition handling, satisfiability, or SDK support — only about the declarations visible in `ir.rs`/`ir_types.rs` and the construction edges in the candidate source. I give no security, hostile-prover, theorem, privacy, binding, resource, layout, native-ABI, financial, profile, or target-acceptance judgment. The owner-prescribed rejection cases are treated only as supplied context.

---

# Verdict 1 — G3 enabled-fetch source, construction, and normal tests

## Verdict: PASS at source-construction level, with no blocking defect found

The separate enabled constructor in [enabled_fetch.rs](/home/charl/Moriarty/.worktrees/sherlock-astra-step-20261015/crates/mori-backend/src/sherlock_machine/enabled_fetch.rs) faithfully implements the prescribed construction dataflow on source reading. The unconditional G2 constructor remains unchanged, and `mod.rs` changes are limited to the enabled module export and the `#[cfg(test)] mod enabled_fetch_tests;` declaration. No library registration was added: `crates/mori-backend/src/lib.rs` still declares no `sherlock_machine`, so the module and its eleven tests are presently unregistered and cannot be treated as compiled or run.

## Construction and dataflow checked

- **Enable validation.** `enable` is included with the other caller operands in the `%`-prefix and `%{scope}.temp.` collision checks, including when it is a variable. Its first emitted constraint is an unconditional `ConstrainToBoolean`. Immediates have no variable-name rule, matching the test that supplies `Immediate(0)` as a static disabled enable.
- **Effective index versus raw index.** `index_eff` is `CondSelect(enable, index, 0)` at temp.0 and is then constrained as UInt128. The raw `index` appears as an instruction operand only in that true arm; it receives no direct range/Boolean constraint in the fragment. Every `TestEq` and the prefix comparison consume `index_eff`, never the raw index.
- **Unconditional count, rows, and capacity guard.** `active_rows` is constrained UInt128, every row cell is constrained by its column kind in row order, and `LessThan(capacity, active_rows, 128) == 0` is emitted without enable gating. Row-count/column-count validation still comes first through `TableShape::check_rows`.
- **Guarded prefix.** `in_prefix = LessThan(index_eff, active_rows, 128)` is Boolean-constrained, `guarded = CondSelect(enable, in_prefix, 1)` is temp.3, and the sole `Assert` consumes temp.3. At source level this permits the disabled `active_rows = 0` case while retaining the enabled prefix obligation; the actual SDK effect is unobserved.
- **Gated selectors and sum.** Each `eq_r = TestEq(index_eff, r)` is Boolean-constrained, each `sel_r = CondSelect(enable, eq_r, 0)` is Boolean-constrained, the sum is seeded at immediate 0 and accumulated in row order, and the final equality is `sum == enable`, not `sum == 1`. Only `sel_r` values enter the selected lanes; ungated `eq_r` values do not.
- **Zero-seeded lanes and exact enable tag.** Each column lane starts from immediate 0, folds `CondSelect(sel_r, rows[r][c], previous)` in row order, receives the original column-kind constraint, and is returned as `EnabledTypedOperand { kind, value, enable: inputs.enable.clone() }`. Disabled-zero is therefore represented at construction level as the gated zero result, not as a fetched/default/padding row.
- **Preserved aliases.** `preserved: inputs.clone()` returns the exact caller `enable`, `active_rows`, raw `index`, and complete row matrix. It does not substitute `index_eff`, a success flag, an after-state, or rewritten cells.
- **Temporaries, namespace, and shape.** The checked host expression covers exactly `4 + N*(C+3)` temporaries before allocation. For the 3×2 test shape that is 19 temporaries and 41 instructions, matching `12 + 2NC + 5N + C`. The namespace format is `%{scope}.temp.`, scope emptiness is rejected, and input variables inside that namespace are rejected. Distinct non-nested composition namespaces remain a caller obligation; there is no global registry.

## New tests checked as source

The five tests in [enabled_fetch_tests.rs](/home/charl/Moriarty/.worktrees/sherlock-astra-step-20261015/crates/mori-backend/src/sherlock_machine/enabled_fetch_tests.rs) are constructor-wiring tests, not evaluators. They pin: all eleven `CondSelect` tuples for 3×2; both `LessThan` tuples with `bits: 128`; all `TestEq`/`Add` edges; the capacity `ConstrainEq` to 0; the final sum `ConstrainEq` to the exact enable operand; exactly one `Assert`; the ordered temp.0–temp.18 identifiers; selected kinds/values; exact enable tags; preserved equality; absence of `PublicInput`/`Output`; unconditional checks in the disabled construction; absence of a direct constraint on the raw-index variable; both owner-prescribed identifier rejection families across enable/count/index/cell positions; and fixture metadata showing `actual: "UNRUN"`, four cases, the decimal string `340282366920938463463374607431768211456`, and expected disabled selections `["0", false]`.

The six inherited tests remain in the unchanged G2 files. The G2 `fetch.rs` hash remains `6e71e0dc…`; the normal tests still cover the unconditional constructor and public wrapper ordering, and the identifier tests still cover the original G2 rejection positions.

## Non-blocking observations

1. **Guarded temp.3 has no separate Boolean constraint.** Its operands are drawn from the Boolean-constrained `in_prefix`, the Boolean-constrained enable, and immediate 1. I do not count this as a source defect because the owner text did not prescribe a separate constraint on that select output, but actual SDK treatment is a future executable check, not an inference from the declaration alone.
2. **Test 1’s kind coverage is indirect.** The main wiring test does not by itself name the enable Boolean, count UInt128, and cell-kind constraints as separate assertions; the disabled-construction test supplies those checks, partly with immediate enable/count operands. The exact 41-instruction count and edge pins narrow the gap, but the combined coverage remains a source-reading statement about UNRUN tests.
3. **Only the temporary count is separately overflow-checked.** The total instruction count is not given an independent checked expression. This matches the stated owner requirement and the G2 pattern; it is not promoted here to a concrete defect or resource judgment.

## Future checks, not defects inferred now

Registration in `lib.rs`, Rust typechecking, the eleven tests, a composing harness for the fragment, serialization/load round-trip, SDK check/evaluation of the four fixture cases, the disabled 2^128 Fr binding (which cannot pass through the G2 `u128` witness packer), enabled out-of-prefix behaviour, non-Boolean enable behaviour, and `active_rows > N` behaviour for either enable all require separate admitted execution. No host-selected answer, evaluator, or UInt128 coercion of the disabled 2^128 raw index is present in the candidate.

**Changed G3 source would require a fresh applicable review.**

---

# Verdict 2 — Opus-authored concept note 003 and updated Root provenance

## Verdict: PASS as a faithful concept/provenance record, within stated limits

Note 003 in [ITERATION-003-ENABLED-FETCH.md](/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-reference-20261015/opus-sprint-loop-20261015/enabled-fetch-and-atlas-normal-muse-r1/wiki-llm/sherlock-circuit-atlas/ITERATION-003-ENABLED-FETCH.md) faithfully visualizes the new G3 construction as a **source scene**, and the updated README/AUTHORSHIP material correctly separates Opus-authored concept text from Root-captured provenance. This is not a security-status judgment and does not convert the separate Opus security review into concept approval.

## Fidelity to the actual 3×2 source scene

I independently recounted the scene quantities the note uses: **19 temporaries** and **41 instructions** for `N = 3`, `C = 2`. The note uses those counts only to size a proposed board and explicitly denies that they measure constraints, rows, cost, or k. Its guard/select visualization matches the source: temp.0 is the effective-index select with the raw index only on the true arm; temp.3 is the guard select in front of the sole `Assert`; temps.4+3r are the equality nets; temps.5+3r are the gated selectors tapped by the lanes; and the sum terminator is drawn on the enable operand rather than on immediate 1. The note correctly distinguishes real instruction terminals of `enable` from the host-struct enable tags on `EnabledTypedOperand`, showing the latter as silkscreen flags rather than vias.

The note also preserves exact operand identities from the test (`%dispatch.selected`, `%state.active_rows`, `%branch.raw_index`, `%state.row.{r}.amount`, `%state.row.{r}.enabled`, `%enabled_fetch.temp.0`–`.18`) and explicitly labels them test operands, not a machine ABI. Disabled-zero is presented as construction data through the zero seed and a DOM card, never as a table row, padding, or animated lane, and the board remains identical across fixture cases. Supplied, Expected, and Actual are kept as three independent channels, with Actual uniformly **UNRUN**, including the disabled raw-index `340282366920938463463374607431768211456` case.

Brand and access treatment is faithful to the prompt boundaries: the Moriarty wordmark remains flat and unlit; no franchise identity, logo, typeface, or set design is proposed; the Tron/PCB reference remains an aesthetic; copper emission and cyan selection remain proposals pending design/contrast review; iteration 003 adds no new hue; reduced-motion behaviour, an SVG/fan-out fallback, DOM-readable identifiers, and keyboard routes (`E`, `I`, `C`, plus inherited `T`/`N`) are all specified as proposals. There is no website code, asset, package, build, or deployment in the note or README update.

## Provenance assessment

Notes 000–002 are treated as immutable historical notes. The updated README now records their publication in [PR #91](https://github.com/CharlesHoskinson/Moriarty/pull/91), merge `5178d576e3f1931560e626738dd8ddfe6de243f7`, and states that iteration 003 is materialized only in the local concept working tree for separate G3 publication. AUTHORSHIP records the README before/after hashes for both the iteration-002 reply-link completion and the iteration-003/PR91 provenance update, and records note 003 as verbatim with its original public reply retained as raw fenced JSON text plus source captures.

Those captures are explicitly **Root-recorded provenance, not provider-signed bytes**. I therefore accept them as the packet’s provenance record, not as independently verified provider evidence. One apparent tension is correctly handled by that layering: note 003’s verbatim freeze-time paragraph still says G2/notes 000–002 were not yet merged, while the later Root README/AUTHORSHIP update records the actual PR91 merge after the author reply. Because the note is preserved verbatim and the update is provenance-only, I do not count the stale freeze-time sentence as a concept defect; readers must take current publication status from the updated README/AUTHORSHIP, not from the frozen note.

**Overall:** Verdict 1 passes the frozen G3 enabled-fetch construction and its normal test source with no blocking source defect, subject to registration and all executable SDK checks remaining UNRUN. Verdict 2 passes note 003 and the updated README/AUTHORSHIP provenance as a faithful, clearly bounded concept record. Neither verdict is a final publication-packet review or an L vote, and neither closes any U0–U7, M1–M17, layout, native, financial, profile, or target gate.