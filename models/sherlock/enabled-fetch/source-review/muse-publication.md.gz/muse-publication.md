## Scope and limits

I used no tools or execution. I did not independently recompute any SHA-256; every hash, byte count, and before/after identity below is Root-recorded. This review is normal-source only: I make no security, resource, hostile-input, theorem, financial, privacy, runtime, admission, or grant judgment; those remain with their designated owners, with Opus for the excluded scopes. Existing archive captures are Root-recorded, not provider-signed. The independent Root codec examples were treated as partial expectations only, not as a selected wire schema.

---

# Verdict 1 — L4 full seven-file current-A representation

## Vote: ADOPTABLE_WITH_LIMITS as host codec interface/source basis

This is a fresh Muse high independent normal vote on the changed L4 bytes supplied. The earlier L2/L3 Muse votes and the earlier Opus findings are treated as history only and do not approve these bytes.

### G1 — parent field block timing: correct

[design.md](/home/charl/Moriarty/.worktrees/sherlock-astra-step-20261015/openspec/changes/sherlock-machine-circuit-layout/design.md) now contains, verbatim, "When a node is appended to Constants (respectively Data), its ordered field references are appended at that same moment, as one contiguous block at the current end of ConstantFields (respectively DataFields), in field order. A node with no fields has fieldStart=0 and fieldLength=0," with an adjacent provenance label pointing to Opus G1. [crosswalk.json](/home/charl/Moriarty/.worktrees/sherlock-astra-step-20261015/openspec/changes/sherlock-machine-circuit-layout/crosswalk.json) carries the identical G1 string under `canonical_append_and_path_clarifications.G1`. [interfaces.md](/home/charl/Moriarty/.worktrees/sherlock-astra-step-20261015/openspec/changes/sherlock-machine-circuit-layout/interfaces.md) summarizes this consistently: field blocks are appended with their parent node after its children, and fieldless nodes have (0,0) slices.

This closes the F1(c)-class ambiguity. Node order remains child-before-parent (left-to-right post-order, no interning), and the G1 rule now fixes the field-slot order as a consequence of that same post-order: a constructor parent's ordered field block enters the field table at the parent node's append moment. The fieldless (0,0) convention is explicit rather than only implied by the general empty-slice rule. Acyclicity is preserved, because fields appended at the parent moment reference earlier constant nodes, and a runtime field may reference an earlier data node or a constant, exactly as the strict orders already require.

### G2 — non-Match paths, root paths, functionIndex: correct

design.md now contains, verbatim, "For non-Match nodes, childPosition is the child's zero-based index in the order listed above. A root occurrence (entry or function body) has pathStart=0, pathLength=0, and an Entry occurrence has functionIndex=0," labeled as the verbatim Opus G2 path clarification. crosswalk.json carries the identical G2 string, and interfaces.md summarizes it consistently.

This completes the path convention set without narrowing anything: Match keeps scrutinee 0 and arm k at k+1 (F1(b), expressly not execution ordinals), non-Match children are now expressly zero-based in the listed semantic source order, root occurrences (entry or any function body) have the empty path (0,0), and the Entry occurrence's `functionIndex` is fixed at 0 rather than left implicit. No new execution ordinal or alternative numbering is introduced.

### G3 — StepInv future label: correct

design.md now states, at the head of the Observation-domain conditions, "StepInv is only a label for a future row-check obligation. It is not an existing component, implemented invariant checker or proved result (Opus G3)." crosswalk.json states the same in `step_inv_status`, and interfaces.md repeats it. The F2 suffix-membership obligation remains tied to that label in the Representation-domain definitions, in the `runtime_code_reference_rule`, and in interfaces.md. The suffix rule itself is unchanged and remains consistently classified: nonempty non-suffix state slices are WrongRepresentation in both Canonical and Step decode modes, empty slices are (0,0), and absence of a closure candidate on encode remains OutsideProgramClosure.

### G4 — corrected map: accepted as supplied

The SOURCE.patch shows changes to exactly five of the seven files (OWNER-REPAIR-PROVENANCE.md, crosswalk.json, design.md, interfaces.md, proposal.md); extensions-and-obligations.md and tasks.md are unchanged, as the MATERIALIZATION-MAP records them with equal spans. The patch touches only: the provenance title and L4 section, the two new crosswalk keys (`canonical_append_and_path_clarifications`, `step_inv_status`), the three design.md insertions (G3 label, G2 paragraph, G1 paragraph), the interfaces.md L4 paragraph, and the proposal.md L4 revision note. No other text changed.

The new provenance section correctly discloses the real historical defect: the original L3 map's two F4 replacement strings did not match the final L3 text; the final L3 prohibition was correct and the map was not; the original packet remains immutable history. The map is stated to be regenerated from complete actual before/after bytes with reconstructable span edits, and it separately records the two unchanged current F4 paragraphs from both snapshots without claiming obsolete wording matches final bytes. The STATIC-CHECKS record asserts reconstruction, span/hash agreement, and both F4 entries matching unchanged source. Subject to the no-recomputation limit above, I found no internal inconsistency between the patch, the map's changed spans, and the seven after-files supplied.

### Scope preservation check

I confirm from the supplied bytes that nothing else was narrowed and no default was introduced:

| Preserved item | State in L4 |
|---|---|
| Variant coverage | 55 variants across the ten enums in crosswalk `source_enum_variants` |
| Source struct fields | 22, including all eight Snapshot roots |
| ProgramHeader | 16 columns; entryExprId plus fifteen active lengths |
| Rule-line table | 39 rows, tags 0–38, charges 0 for lines 80/82/84 and 1 otherwise |
| Refusal classes | 7 located classes, none an Outcome, error code, or StepRecord |
| Capacities | Symbolic parameters only; no numeric defaults; T>=4, Q>=4, QF>=5 remain builtin active lengths, not capacity choices |
| Capacity versus domain | depth<=S, controlLength<=C, stack_limit<=SL, and active-length limits remain Capacity, never observation conditions or semantic outcomes |
| F4 | UNSELECTED; both owner alternatives retained; per-step in-circuit least-equal search prohibited |
| B / financial / ADT / binding / target | All retained unadopted and unselected; no B counters defaulted into A |

### Independent Root normal examples

I checked the supplied partial examples against the L4 text as normal-source expectations. I found **no real normal discrepancy** in them. In particular: Nil/Bool-false/UInt-0 remain three distinct nodes with zero fields; `List [7,9]` yields the stated five nodes in left-to-right post-order; the shared tree child is visited twice with duplicated nodes (no interning); two distinct Invoke arguments occupy two Data slots in order; `Some(empty map)` retains outer presence with an empty EnvRoot while `None` does not; `Enter` with an exact clone of functions[0] yields functionPresent with functionId 0; the Push pending-frame payload is visited before the terminal Return value and before the installed frame's value, matching the canonical ControlRows-first visit order; the shadowed Scope frame contributes a second independent EnvCell with current environment at index 0 and saved at index 1; duplicate literal occurrences keep distinct ExprIds 1 and 2 while a held reference selects the least equal ExprId 1 and produces two distinct constant nodes; and Match occurrence paths are `[]`, `[0]`, `[1]`, `[2]` for root, scrutinee, and the two arm bodies. These remain partial semantic expectations for a future codec, not a wire schema, and they do not expand the adopted surface.

### Limits and permitted start

Adoption under this vote extends only to the current-A (`sherlock-k-a/1`) structural representation and host codec interface, with capacities as supplied parameters. The following remain outside: owner F4 (canonical-representative enforcement stays UNSELECTED, so no ProgramBlock digest, canonical-uniqueness, statement-binding, or pre/post chaining claim), physical P1–P6 (per-rule reference outputs, write masks, append sequences all remain undecided), and B, financial, general-ADT, native, ledger, and target matters remain unselected with their original owners.

Within those unchanged limits, host preparation source may begin: specifically `prepareA` implementing F1(a) Names membership, preorder occurrences with F1(b)/G2 path numbering, F1(c)/G1 post-order constant and field-block append timing, plus the related host `encodeObservedA`/`decodeObservedA`/`projectA` and record/trace materialization, all under H1 (host tooling only, no untrusted or network consumer), F5 (incremental first-overflow refusal), and F3 (unfolded capacity envelope; overflow is Capacity only). No codec is already implemented by this vote, and no determinism, round-trip, or execution claim follows without separately admitted evidence.

---

# Verdict 2 — Final publication candidate (21 selected paths)

## Classification: APPROVED_WITH_CONDITIONS for source commit / push / PR / regular merge to main

This approves only publication of the exact supplied source as an expressly **unregistered, source-only proposal**. It is not native acceptance, not product acceptance, and not registration. Requiring product acceptance for this publication would contradict its disclosed status.

### Selected set and change scope

The manifest `ENABLED-FETCH-ATLAS-PUBLICATION-CANDIDATE-r1.json` (base `5178d576e3f1931560e626738dd8ddfe6de243f7`) lists 21 full paths. The per-file `changed_from_publication_base` flags mark exactly 16 as changed and five as unchanged context: `fetch.rs`, `identifier_rejection_tests.rs`, `normal_tests.rs`, `models/sherlock/machine-circuit/MAPPING.md`, and `models/sherlock/machine-circuit/expected.json`. The changed set is the enabled-fetch constructor and its tests, the `mod.rs` module export plus test declaration, the enabled-fetch mapping and fixture, the source-review package (README, SOURCE-FREEZE, and the four source-review captures), the machine-circuit context files' unchanged companions excluded, and the atlas AUTHORSHIP/iteration-003/README plus two provenance captures. I cross-checked textual consistency across the supplied copies: the SOURCE-FREEZE ten-file pins match the manifest values for those paths, and AUTHORSHIP iteration 003 pins the same ten files with the same Root-recorded values. Hash agreement is asserted from the supplied records, not recomputed by me.

G3 remains UNREGISTERED in this candidate. The supplied base `crates/mori-backend/src/lib.rs` declares no `sherlock_machine` module, lib.rs is not among the 21 selected paths, and the `mod.rs` change adds the module export and `#[cfg(test)] mod enabled_fetch_tests;` only. The separate registered backend candidate is not included, and no lib-registration edit is part of this approval. No website source is included: the atlas files are concept notes and provenance records, and the supplied `.github/workflows/site.yml` triggers only on `site/**` and its own path, none of which this candidate touches. No private Clean/Fenrir source and no selected L design source is included; the L4 candidate above is a separate decision and is not part of these 21 paths.

### Source findings

Opus note 003 (`ITERATION-003-ENABLED-FETCH.md`) is present verbatim; notes 000–002 are unchanged; the atlas README/AUTHORSHIP publication-provenance updates after the author reply (recording PR #91, merge `5178d576e3f1931560e626738dd8ddfe6de243f7`) are disclosed in AUTHORSHIP's `readme_integration_changes`, whose final entry's after-hash matches the selected README's Root-recorded hash. The source-review README states honestly that the supplied Opus and Muse source reviews are not publication approvals, that all eleven tests (five new, six inherited) plus compiler, SDK load/check/evaluation, model/k, proofs, ledger, and stagenet are UNRUN, and that the gzip captures are Root-recorded, not provider-signed. The stale freeze-time sentence inside the verbatim note 003 (G2/notes not yet merged) is correctly layered: the updated README/AUTHORSHIP carry current publication status, and AUTHORSHIP records that publication statements in notes describe their recorded freeze time. The stale G2-scoped wording in the unchanged `machine-circuit/MAPPING.md` gap 1 is likewise scoped to the unconditional block and is explained by the enabled-fetch MAPPING as a separate sibling constructor.

On normal source reading I found **no real blocking defect** in the 21 selected files. Remaining items are future work, not defects: registration and typechecking, execution of the eleven tests, a composing harness, SDK checks including the disabled raw-index 2^128 Fr binding, dispatch-provenance and consumer-gating obligations, and all retained byte/lane, binding, padding, machine, financial, proof, and target gaps. None of these blocks publication of an expressly unregistered source proposal.

### Receipt-seal contract — approved as a contract, not as future bytes

The only permitted follow-on change, without altering any of the 21 selected bytes, is a receipt seal of exactly five new files under `models/sherlock/enabled-fetch/source-review/`:

- exactly four fixed-mtime gzip captures: for each of the final Muse and final Opus reviews, one capture of the exact UTF-8 `text` bytes taken from the canonical RESULT.json `text` field, and one capture of the complete RESULT.json adapter bytes; and
- exactly one `FINAL-REVIEW-BINDING.json`.

The contract is approved with these binding requirements. Each gzip must be a single member with the fixed mtime, no trailing data, and no header filename, comment, or extra field; the captured raw text must undergo no LF normalization. `FINAL-REVIEW-BINDING.json` must list the hashes (and byte counts) for all 21 selected files and for the four receipt captures, must not contain a hash of itself, and must bind, for each reviewer, the requested identity, the returned identity, the effort, the terminal status, and the limitations of that review, including that its archive capture is Root-recorded and not provider-signed. No other README, index, CI, feature, pin, lib-registration, or source edit is permitted in the seal. This review approves that contract; it does not approve the future receipt bytes, which must be verified when produced, and Root's independent runtime final manifest must hash the binding file itself.

### Predicates

Pre-push: remote `main` is still exactly base `5178d576e3f1931560e626738dd8ddfe6de243f7`; the working tree contains exactly the 21 selected paths with their Root-recorded hashes plus, after sealing, exactly the five seal files; every gzip passes the structural checks above (single member, fixed mtime, no trailing data or header fields, decompresses to the exact canonical text or adapter bytes with no LF normalization); the binding lists all 21 + 4 hashes with identities, effort, terminal statuses, and limitations, and has no self-hash; Root's runtime final manifest hashes the binding.

Pre-merge: remote `main` remains that same base; the exact PR head commit, its parents, file modes, and blob contents are rechecked against the approved hashes for all 26 paths (21 selected + 5 seal); the merge is a regular merge, not a squash or rebase that would rewrite the approved head.

Post-merge: the merge commit's parents and tree blobs are rechecked so `main` contains exactly the approved bytes; G3 remains unregistered on `main` (lib.rs unchanged); and any automation actually triggered is observed and reported — the absence of unseen future automation is not assumed.

### Blockers and honest limitations

This approval is void if any of the 21 selected bytes changes (fresh applicable review is then required), if the seal adds or edits anything beyond the five permitted files, if any gzip is normalized, multi-member, or carries trailing data or header fields, if the binding omits any of the 25 hashes or any identity/effort/terminal-status/limitation element or contains a self-hash, if remote `main` has moved from the stated base, or if PR head, parents, modes, or blob contents differ at merge time. It confers no compilation, test, SDK, proof, ledger, stagenet, native, or product acceptance: all eleven tests and every executable layer remain UNRUN, the module remains unregistered and cannot compile in the crate today, and all U0–U7/M1–M17 and target obligations remain open and unclosed by either verdict.