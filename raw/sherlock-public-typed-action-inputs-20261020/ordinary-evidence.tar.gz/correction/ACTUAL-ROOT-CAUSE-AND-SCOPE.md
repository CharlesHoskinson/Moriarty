# Actual original07 failure: HostOnly identity expectation

Observed failure: original07 exited101 at old line172, after its whitespace
value/digest/full-admission assertions completed. Both serialized identity
objects have program_membership_digest, bounds_digest and layout_digest
Unselected. No controller/resource failure occurred. All six child raw receipts
are retained in the stopped attempt; original04-06 passed. Original08-24 were
not run. No complete positive artifact capture exists yet. The attempt freeze
records allActualsFrozenBeforeAnyProtectedExpectedRead=false because the required
two captures did not happen; expectedBodiesRead remainsfalse. This is a closed
failed-attempt freeze, not the later all-actual semantic-comparison barrier.

Cause: the author test selected the wrong report field. owner_prepare::admit
explicitly creates DigestC::Unselected for all three digests; wire projects the
actual observation unchanged. The handoff Digest contract says never fabricate
Selected. The map consumer constructs concrete entry Literal arguments in source
declaration order and sends their real program to prepare/admit. These are
separate fields. Equal HostOnly identity metadata does not imply equal programs.

The adopted typed-input design says concrete maps can change admitted constants/
tables/program identity; it does not introduce a selected native/program hash or
change owner identity/admission semantics. Existing first-batch wire preserves
actual identity and complete program_view. No new security-owned hash policy is
needed or authorized for this ordinary follow-on. Selected/canonical/native
identity obligations remain separate gaps; this patch does not close them.

C3 changes only one test body/name and truthful chronology comments. It retains
the original whitespace/raw-byte digest checks; then asserts unchanged/unselected
HostOnly identity and different complete program_view. The existing structure()
helper validates units9/flat4 versus units10/flat4 entry literals in declaration
order and retained parameters/Vars/Let/Mul/Sub. The complete visible typed map is
also checked. All helpers and14 other test chunks and17 other afterimages remain
byte-exact. The predicate was frozen before this source edit, derived from public
inputs/schema/source and actual metadata-kind failure, not private expectations.
The corrected case is UNRUN. This is not a TDD/red-green or independent-oracle
claim. Source inspection supports the proposed binding predicate; actual changed
10 table observation remains to be tested. Original04/05 passes support their own
source binding/result assertions but are not a retained independent comparison.

No Core, producer, owner, decoder, guard, Value/UInt, SHA, admission, runtime,
limits, serializer or fixture/config/source changes. Qualified normal Corec75e5624
remains immutable; no prefix compile or passing04-06 test replay. Future plan:
C3 eleven-input consumer link/list/corrected07 once, then original08-24 exact
reviewed objects. Reuse retained qualified C2 binary for untouched08-18; do not
select old wrong07 again. All future checks remain unselected pending fresh
source/API review and Root full retained caller read/selection. Both complete
future captures and all raw evidence must be durable before independent expected
read. Source author remains blind to private expected/derivation/freeze/proof.
