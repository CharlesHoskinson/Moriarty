# Public typed action input source candidate

Implemented R-only afterimages; all subject checks UNRUN. No PW, canonical,
Git, provider, SDK, Cargo, rustc, native, wallet or private-oracle-body operation.
The exact adopted design and two design opinions precede this source cut.

Five production files change: central compile artifact/API, mechanical shared
Draft constructor, compile Args, top-level route condition, selected handler.
The sole existing compile Args literal changes mechanically in one old test.
New: one real-handler 15-test consumer, one literal positive capture consumer,
five exact SAFE fixtures, three Diataxis files and one additive OpenSpec leaf;
B04 tasks gets a link without checking acceptance. Eighteen afterimages total.

compile_host delegates LegacyEmpty to one private sequence. The new public
compile_host_with_inputs supplies ExplicitTypedMap. Config/target/validate order
is retained; explicit JSON/Value decode occurs before source parse. Both modes
use unchanged preflight and the same prepare or run branch, each owning exactly
one actual admitted pair. Existing consumers, decoders, guards, limits,
projection/owner/runtime and full wire implementation remain byte-unchanged.
The 36 design-readset files still match their current public preimages.

InputPolicy adds public Option<InputBinding>, omitted None. InputBinding is
Serialize-only values then file_digest. Explicit mode reports declared source
order, supplied ascending keys, concrete values and original-byte hash; Legacy
and Draft serialize their original three input-policy keys. The public struct
literal source compatibility break is explicitly adopted by Root.

The Core-only check follows original select_source and precedes observe refusals,
config-path requirement and file I/O. The top-level route also checks Some input
flag so programmatic Args cannot fall into native/default dispatch. No new
SelectedSherlockArtifact variant or output tag is introduced.

TESTS-BEFORE-PRODUCER-FREEZE records the initial 13 tests, capture and fixtures
before any producer edit. Two supplemental reader/runtime controls were added
afterward, transparently recorded in TEST-SOURCE-REVISION-02. The exact original
13-test prefix is retained separately and verified byte-identical. No red/green
or passing-test claim is made. The final 15-test source is the reviewed candidate.
Author arithmetic and codec/shared-producer equivalence are not independent
semantic expectations. Independent SAFE input freeze predates all producer code.

Source-cut retains all mori-core/mori-lexer/mori-diagnostics src files/manifests,
the public readset, candidates and three old fixture dependencies. It is not yet
a tool/extern-qualified full normal Core. Root must qualify that future build and
actual canonical dep-info before consumers; previous Core rlibs remain immutable.
No exact tool/extern invocation or operation authority is invented by this lane.

Formal impact: no Lean/Quint specification or guard is changed. INP1-12 are local
additive acceptance clauses; no compiler-correctness theorem or EARS parent closes.
The existing input binding semantics are exposed publicly; witness/input relation,
full state/work/ID/trace correspondence, financial effects and native acceptance
remain open. Different concrete maps can change admitted program identity.

No HostOnly report importer was found in inspected prove/verify/admit consumers.
The artifact remains visible concrete binding, not private witnesses or a fixed
circuit. Existing prove/verify native consumers are not modified. Whole backend
CLI and default-Core actual regression remain separate coverage gaps.
