# A3 Task 1 swap fixture handoff

Status: DONE within the two-file Task 1 implementation scope; root's nonauthor
acceptance remains required. No Task 2, lifecycle, harness, commit or Council work.
Author: execution_adversarial_tests; this is an author report, not independent review.

## Authority and source scope

Repository observation: worktree `/home/charl/Moriarty/.worktrees/s01-audit-start`.
Pre-dispatch base: `82d2c0b1d35ecf2f954603e4b8d54b248bda2663`.
Command-time HEAD: `90e89f835ccc624ea40326e132b21cd5504aa9cc` (root's ledger-only
follow-up). Both owned files remain uncommitted for root acceptance.

Read the entire adopted swap plan, SHA256
`a6160ad728502368f62dd0923196e1ba95e8c037211290dc836ca5889d85a5ab`, and the scoped
`.superpowers/sdd/a3-task1-brief.md`. The controlling completion XML lives in
main, not this worktree: `/home/charl/Moriarty/deliverables/moriarty-candidate-a-completion-prompt-2026-09-05.xml`.
Root resolved that locator during intake; no copy or merge was made. Read its
actual main location and A3 OpenSpec contract. Identity receipt pins both.

Implemented only:

- `specs/quint/s02/candidate_a_authority_swap_fixtures.qnt`
  SHA256 `fb407555584e167ae0fddc3e59fbf6d64ecd79a00d2ad03d02f159da8429ed15`.
- `specs/quint/s02/candidate_a_authority_swap_test.qnt`
  SHA256 `1113f8a8c69de0832644248aba907ab62d5a2c97a209638c6aed3c7e7a61645b`.

No common/A evaluator, adapter, boundary, Python, installment, plan, progress,
main documentation, archive or database edits. Other workers' files were preserved.

## Implementation and coverage

Repository observation: fixtures transcribe the adopted Task 1 interfaces with
literal whole sixteen-node program, six-account maps and five optional-choice
maps. `beforeS(0)` retains N6/minimumTime0; unsigned authority has physicalTime1.
Funding requests use Alice10 at1 and Bob20 at2. Both profile policy constructors,
exact nonce/key sets, facts and ordered payment/effect expectations are provided.
`projectedS` retains the plan's intentionally unused predecessor parameter.

The twelve scenario literals include settle1, settle0, timeout at100/101 with
funding0/1/2, and supplied choice0/1 at100/101 with funding2. Expected deadline
rejections retain N4, accounts10/20, absent choices, minimumTime2, contract_closed,
empty warnings/payments/effects and reductions0. Empty timeout expects accepted
Core, reductions1, empty effects and zero required keys; it does not invent
authority or a financial commit.

`literalFidelityTest` checks all twelve scenarios and three attempt positions:
actual adapter output equals the complete independent literal observation,
the complete resolved plan is faithful, and required keys equal literal keys.
It also checks program equality, raw minimumTime0 and physicalTime1.
`authorityTimeZeroTest` checks that raw state is valid while an authority request
atTime0 is explicitly invalid. Expected values are not derived with the adapter,
Core evaluator or projection producer; only the actual side invokes the adapter.

Scope limit: these two tests do not execute signing or stateful authority paths,
nor iterate the profile policy constructors. Those are Task 2/3 obligations.
Complete-body/profile signing validity and actual no-effect envelope rejection
must not be inferred from this fixture gate. EvidenceValid remains a symbolic
external premise, not cryptographic or semantic proof. No new correspondence,
model-checking or full A3 lifecycle claim follows.

## Actual RED, correction and GREEN

Experiment observation: initial source deliberately changed only settlement
expected reductions3 to2. Refund remained3, timeout remained1+funded and Core
rejection remained0. Both RED fixture and test standalone typechecks exited0.
The full original fourteen-file import closure was copied using apply_patch,
then verified byte-identical. No source correction occurred before the terminal
RED receipt was written.

Exact RED command (cwd above):

```bash
quint test specs/quint/s02/candidate_a_authority_swap_test.qnt --backend=rust --seed=42 --match '^literalFidelityTest$'
```

Terminal exit1: `literalFidelityTest failed after 1 test(s)`; `1 failed`;
`Error [QNT508]: Assertion failed` at test line16. This is a compiling behavioral
assertion failure, not a parser/type failure. Full diagnostic and every earlier
empty/output chunk are preserved in `red/literal-fidelity.json`. The CLI's
reproduction hint is `--seed=0x2a --match=literalFidelityTest`.

After that receipt and post-command closure equality check, restored the exact
plan expression `if (settlement or s.mode == RefundS) 3 else 1 + s.funded`.
No test, actual-side evaluator or common behavior was changed to obtain GREEN.
The untouched test subsequently passing with this one correction establishes
the local causal reduction-count control. This was the only behavioral RED.

Exact GREEN command:

```bash
quint test specs/quint/s02/candidate_a_authority_swap_test.qnt --backend=rust --seed=42 --match '^(literalFidelityTest|authorityTimeZeroTest)$'
```

Complete terminal test output, exit0:

```text
  candidate_a_authority_swap_test
    ok literalFidelityTest passed 1 test(s)
    ok authorityTimeZeroTest passed 1 test(s)

  2 passing (4386ms)
```

Both corrected standalone typechecks also exited0 with empty output:

```bash
quint typecheck specs/quint/s02/candidate_a_authority_swap_fixtures.qnt
quint typecheck specs/quint/s02/candidate_a_authority_swap_test.qnt
```

The separate corrected fixture typecheck was already launched before root noted
the test-module check recursively covers it; all active jobs were allowed to
finish. No jobs were restarted or terminated. No full boundary/Python regression
or sampled run was performed in this narrowly authorized fixture task.

## Reproduction evidence

Receipt root: `.superpowers/sdd/a3-task1-receipts/`.

- `identity.json`: exact tool/plan/XML/OpenSpec/base commands and raw output.
- `red/source/specs/quint/s02/`: all14 exact RED import-closure source files.
- `red/*-typecheck.json`: both successful RED typechecks and all returned chunks.
- `red/literal-fidelity.json`: terminal behavioral RED and complete closure hashes.
- `green/source/specs/quint/s02/`: all14 exact final import-closure source files.
- `green/*-typecheck.json`: both corrected successful typechecks.
- `green/task1-tests.json`: both named GREEN tests and all raw returned chunks.
- `final-source-audit.json`: independently re-read all28 snapshot files; each
  matches its captured hash. All14 GREEN sources remain byte-identical to live
  source. Only the RED fixture differs from final source, by the planned control.

Receipts retain combined tool output because the command tool does not supply
separate stdout/stderr streams. No separate stream identity is claimed. Source
closures were captured before each behavioral test and checked unchanged after
each stage. The RED closure snapshot was written while the initial typechecks
were already running, before either completed; their source remained unchanged.
Tool: Quint0.32.0, `/home/charl/.npm-global/bin/quint`, SHA256
`ac12595b1cb7253feec93c79417615c6eb20fc3b6a3df35c5e3530b24e90a501`.
Rust evaluator: `/home/charl/.quint/rust-evaluator-v0.6.0/quint_evaluator`, SHA256
`b2efdeac5713d153e41bf2143b94ed75d888fdd5637f4a5d61a04c695313510a`.

The Quint modeling/language skills guided literal/actual separation and complete
finite maps. TDD required the preserved compiling RED before correction;
verification-before-completion required terminal results. Root coordinates the
subagent-driven nonauthor review. No implementation concern found in this scoped
self-review; independent review remains open. Source and receipts are frozen
for that review, with no Task2 or commit until explicit root authorization.
