# A3 Task 1: independent swap fixtures

Execute Task1 only of the adopted plan:
docs/superpowers/plans/2026-09-05-moriarty-s02-candidate-a-authority-swap.md
SHA256 a6160ad728502368f62dd0923196e1ba95e8c037211290dc836ca5889d85a5ab.
Worktree: /home/charl/Moriarty/.worktrees/s01-audit-start.
A1 adoption/pre-dispatch base:82d2c0b (resolve full git hash).
Read all global constraints and Task1 before implementation.

Use required Quint, TDD and subagent-driven-development skills. Root has reviewed
the complete frozen plan and captured passing final static typecheck receipts.
Those are not your behavioral RED/GREEN evidence.

Own only:
- specs/quint/s02/candidate_a_authority_swap_fixtures.qnt
- specs/quint/s02/candidate_a_authority_swap_test.qnt
- .superpowers/sdd/a3-task1-report.md
- .superpowers/sdd/a3-task1-receipts/ with unique immutable stage directories.

Do not edit common/A modules, Python, either plan, installment files, lifecycle
or harness files, main docs, evidence, DB, or progress ledger. Another agent owns
A2 in parallel. Root owns independent acceptance and commits. Do not commit or
begin Task2 before the next explicit root message.

Implement the two literal-fidelity tests defined by Task1. Start with the planned
compiling behavioral RED: settlement expected reduction count2 instead of3.
Typecheck the exact RED fixture/test; then run literalFidelityTest Rust/seed42 and
retain the actual assertion failure. Parse/type errors are diagnostics, not RED.
Before correction, preserve complete original source/import closure bytes and
hashes plus every raw output chunk and terminal exit. Restore literal3 and run
the two Task1 tests GREEN, capturing the same complete evidence.

Expected values remain independently literal. Preserve raw N6/minTime0, physical
time1 then2, whole16-node program, all account/choice keys, ordered effects,
rollback at100/101, both profiles and zero-key empty-timeout semantics.
No invented helper types, identity checks or common changes. The early test
module imports fixtures and common/A preamble only, not later lifecycle/harness.

Use apply_patch for edits. Capture exact command, cwd, source stage, tool
path/version/hash and terminal output; no environment dumps/secrets.
Do not overwrite RED. Do not run full boundary/Python regressions for this
fixture task; focused tests during iteration, complete regressions at final
lifecycle gate. Wait on existing command sessions rather than duplicate runs.
Report exact implemented files, RED reason, GREEN selected names/counts, paths
to closure/receipts and remaining concerns. Stay available for nonauthor review.
This is not A3 lifecycle completion, model checking, correspondence or Council.
