# A3 Task 2 swap lifecycle handoff

Status: DONE within Task 2's local implementation/test scope. No Task 3, harness,
sampling, regression-suite, commit, Council or full Candidate A completion claim.
Root's nonauthor source/spec/receipt review remains required.
Author: execution_adversarial_tests; this is not an independent review.

## Scope and pins

Worktree: `/home/charl/Moriarty/.worktrees/s01-audit-start`.
Pre-dispatch base and HEAD observed by the initial identity receipt:
`3f440d2494cf41db289905b15663559e400a6387` (accepted A3 Task 1).
Executed `.superpowers/sdd/a3-task2-brief.md` and Task 2/global constraints of
`docs/superpowers/plans/2026-09-05-moriarty-s02-candidate-a-authority-swap.md`,
SHA256 `a6160ad728502368f62dd0923196e1ba95e8c037211290dc836ca5889d85a5ab`.
During this task root advanced shared HEAD for other accepted work and a Task 3
verification addendum; final observed HEAD is
`a314549b6ba64fbfa10e7ef37012896413fe8571`. Receipt `sourceCommit` identifies the
pre-dispatch baseline plus the explicit uncommitted source closure, not a claim
that shared HEAD stayed fixed. The exact Task 2 import closure did stay fixed.
The controlling completion XML/OpenSpec remain in main; their location was
resolved and read during Task 1, not copied into this worktree.

Owned implementation outputs, uncommitted for root review:

- NEW `specs/quint/s02/candidate_a_authority_swap.qnt`, SHA256
  `6a3d32f147653196cd83fafb3ccf64d118b8424acc00948947d7484a88f9909d`.
- Extended `specs/quint/s02/candidate_a_authority_swap_test.qnt`, SHA256
  `d0efb0823c4bed3c15b5d89ce9ef61dab8d5c2123d928da6a71e3c04edc724fc`.

Accepted fixtures remain unchanged at SHA256
`fb407555584e167ae0fddc3e59fbf6d64ecd79a00d2ad03d02f159da8429ed15`.
No common/A/Python, plan, fixture, harness, other-lane, root evidence, main wiki,
database or progress edits. Task 1 receipts were not changed.

## Implemented behavior

Repository observation: the new pure dispatcher transcribes the adopted
CommandS, route, evidence, guard, common-update, prefix and terminal interfaces.
Every prefix step checks `canCommandS` before `applyCommandS`; success requires
the persistent `ok` flag, valid execution/escrow coupling, conserved TokenA10
and TokenB20, unchanged parent inventory, and the planned atomicity predicate.
Disabled dispatch fallbacks cannot yield a successful prefix. No action or
unconditional stutter was added. These helpers are exercised on the admitted
finite route states, not claimed as an arbitrary malformed-state API.

The initial candidate stays raw N6/minimumTime0 with environment1. Actual Alice
nonce0 prepare/sign/propose/verify/commit deposits10 at1. Explicit environment
advance to2 precedes the separate Bob nonce0 pipeline depositing20. Dispositions
prepare fresh nonce1 policies for the exact one/two escrow owners and use actual
adapter observations, A-specific verify/commit guards and unchanged common updates.

The deterministic matrix runs twelve scenarios under both profiles: six positive
financial outcomes per profile (settle1, settle0 and four funded timeout paths),
and six retained refusals per profile (four supplied deadline inputs plus two
empty timeouts). Refusals use an empty signature map when their required-key set
is empty. Genuine contract_closed remains CoreRejected; accepted empty Core
timeout is UnauthorizedEffect at the envelope. Neither refusal is represented
as a financial terminal state. Exact original observation, evidence, context,
reason/stage and unchanged financial state are checked against literal records.
Replay cannot re-propose or re-commit the completed DispositionAttempt.

All financial expectations remain the independent accepted Task 1 literals.
EvidenceValid is a finite symbolic external premise, not cryptographic proof.
Pure prefix evaluation executes actual guards/updates; it is not a sampled
stateful trace, an independent Python comparison, or universal verification.
The unused RejectedOperation match payload in the matrix follows the adopted
test, which compares the entire resulting state against a literal retained record.

## Genuine compiling RED before correction

Test additions were written before the compiling lifecycle scaffold. Only the
scaffold's `applyCommandS` CommitS branch was deliberately incomplete:
`CommitS(id) => state`. Other helpers and all five tests were already present.
Captured the full fifteen-file transitive source/import closure before launching
the recursive typecheck and focused RED test. All source bytes remained unchanged
until both terminal outcomes and their receipts were preserved.

```bash
quint typecheck specs/quint/s02/candidate_a_authority_swap_test.qnt
quint test specs/quint/s02/candidate_a_authority_swap_test.qnt --backend=rust --seed=42 --match '^fundingTest$'
```

Experiment observation: typecheck exit0 with empty output. Test exit1:
`fundingTest failed after 1 test(s)`, `1 failed`, `Error [QNT508]: Assertion failed`
at line27. The full diagnostic covers the compound funding assertion, including
Alice's first candidate/ledger update and Bob's subsequent state and consumption.
It does not identify a separately evaluated failed conjunct. Source inspection
identifies the unchanged first commit as the causal defect; the one-line GREEN
correction below confirms the local control without changing expected outcomes.
CLI repeat hint: `--seed=0x2a --match=fundingTest`.

`red/funding-test.json` retains every returned output chunk and the full terminal
error. Before correction, its closure was re-read and checked equal to the exact
source snapshot. Then changed only `CommitS(id) => applyCommit(state, id)`.

Separate diagnostic: a read-only Node snapshot-audit command initially had one
extra trailing brace and exited1 with `SyntaxError: Unexpected token '}'` under
Node24.18.1. It changed no files, was corrected, and the audit then verified all15
snapshots byte-identical. This is disclosed in `red/source-byte-audit.json`; it is
not Quint failure or behavioral RED. No Quint parser/type failure occurred.

## Final GREEN results

Captured the full fifteen-file GREEN closure before launching these commands:

```bash
quint typecheck specs/quint/s02/candidate_a_authority_swap_test.qnt
quint test specs/quint/s02/candidate_a_authority_swap_test.qnt --backend=rust --seed=42 --match '.*Test'
```

Experiment observation: recursive typecheck exit0, empty output. Full test
terminal exit0; all five required names are present:

```text
  candidate_a_authority_swap_test
    ok literalFidelityTest passed 1 test(s)
    ok authorityTimeZeroTest passed 1 test(s)
    ok fundingTest passed 1 test(s)
    ok dispositionMatrixTest passed 1 test(s)
    ok replayTest passed 1 test(s)

  5 passing (19528ms)
```

No duplicate standalone imported-module checks, restarted jobs, killed jobs,
sampling, full boundary/adapter/Python regressions or Task 3 edits. All commands
reached terminal outcomes. The source was frozen during each stage.

## Evidence and review handoff

Receipt root: `.superpowers/sdd/a3-task2-receipts/`.

- `identity.json`: exact cwd/base/tool/plan/fixture identity command and raw output.
- `red/source/specs/quint/s02/`: fifteen exact original source files.
- `red/typecheck.json`, `red/funding-test.json`: compiling RED command receipts.
- `green/source/specs/quint/s02/`: fifteen exact final source files.
- `green/typecheck.json`, `green/task2-tests.json`: final command receipts.
- `final-source-audit.json`: all30 snapshots match their captured hashes;
  all15 GREEN sources remain byte-identical to live source. Only the historical
  lifecycle CommitS branch differs between stages.

Receipts include exact commands, cwd, base, source-stage hashes, tool identity,
every returned raw chunk and terminal exit. The tool exposes combined output,
so no separate stdout/stderr stream identity is claimed. Original source
snapshots were made using apply_patch before each stage's commands; no recorder
source file was introduced or altered. Both stages bind the complete import
closure rather than moving shared-module names alone.

Tool: Quint0.32.0 at `/home/charl/.npm-global/bin/quint`, SHA256
`ac12595b1cb7253feec93c79417615c6eb20fc3b6a3df35c5e3530b24e90a501`.
Rust evaluator: `/home/charl/.quint/rust-evaluator-v0.6.0/quint_evaluator`, SHA256
`b2efdeac5713d153e41bf2143b94ed75d888fdd5637f4a5d61a04c695313510a`.

Quint modeling/language and TDD skills governed guard/update separation,
successful-prefix accounting and original RED preservation. Root coordinates
the subagent-driven independent review. No concrete implementation concern found
in scoped self-review. Stale bindings, adversarial mutations, stateful action
witnesses and full regressions remain Task 3; no completion is inferred for them.
Source/report/receipts are frozen for root acceptance and no commit or Task 3
will start without the next explicit assignment.
