# A3 Task 3 source/test/sample handoff

Status: DONE for local Task 3 implementation, recursive typechecking, seventeen
tests and the approved hundred-sample witness run. Root's shared regressions,
artifact intake and full A3 acceptance remain pending at this author handoff.
No commit, A4 implementation, bounded model-checking, Council or integration claim.
Author: execution_adversarial_tests; this is an author report, not independent review.

## Authority and unchanged inputs

Worktree: `/home/charl/Moriarty/.worktrees/s01-audit-start`.
Pre-dispatch base: `c3c89faef1b5723c1520a05c88eb26ff4529d6c5`.
Task: `.superpowers/sdd/a3-task3-brief.md`, the complete adopted swap plan's
Task 3 and global constraints, plus the reviewed command addendum at a314549.

Plan SHA256:
`a6160ad728502368f62dd0923196e1ba95e8c037211290dc836ca5889d85a5ab`.
Addendum SHA256:
`0612f1bfafad7f6a5b2e0497b980e917870c035f62cc03be37da83376596eb49`.

Root advanced shared HEAD for other work during this task; one later observation
is `7c17b27b42bcc50069f7489200dada6959c0804c`. Receipt sourceCommit means the
pre-dispatch baseline plus the exact uncommitted closure, not a claim that HEAD
stayed fixed. Full source closures were captured before each command stage and
re-read unchanged afterward. No other lane's source was edited.

Final four-module unit:

| File under specs/quint/s02 | SHA256 | Worker change |
| --- | --- | --- |
| candidate_a_authority_swap_fixtures.qnt | fb407555584e167ae0fddc3e59fbf6d64ecd79a00d2ad03d02f159da8429ed15 | Read-only accepted Task 1 |
| candidate_a_authority_swap.qnt | 294633d4213d44075df76085f67b9bd24fab23d07bc863fff8b4f22e79d10024 | Add stale scenario/route only in final source |
| candidate_a_authority_swap_test.qnt | 5aed1719310ef472f8fdd5a19e8cc5188a47c7c136f7fc3158bb5a12943636c5 | Twelve added tests, seventeen total |
| candidate_a_authority_swap_harness.qnt | bb8991e439153af69f3c8ec52df1771786a0ce0d5360f975189958b978555e29 | New action harness |

All common/A evaluator, adapter and boundary sources remain frozen. Task 1/2
receipts, Python, plans, main documents, root evidence, database and progress
files were not changed. Root retains commit authority.

## Behavior and tested scope

Repository observation: final lifecycle additions are exactly staleScenarioS
and staleRouteS. Task 2's A-specific verify guard and common commit update are
restored unchanged. The stale route actually funds both accounts, prepares/signs
both disposition nonce1 policies, proposes/verifies, advances the environment
to100, then retains a CommitBoundary rejection with reason StaleBindings.

Added pure tests cover stale prepared signing; current then stale verified
commit guards; fully rebound successor unused-node, effect order, reduction count
and neutral chooser mutations; an invalid second planned operation; wrong Core
chooser, signed signer and old nonce; and stale planned predecessor facts.
Tests preserve BeforeResolution's deliberate lack of concrete-plan resolution
at signing. A changed attempt.actor alone is not claimed to authenticate a sender.

Mutation inputs are constructed from guard-checked actual prefixes. Constructed
VerifiedOperation mutants are commit-boundary controls, not claims that A's
verification accepted them or that ordinary harness transitions produced them.
Exact retained rejection records and unchanged predecessor authority are tested.
The actual wrong Core chooser result has full no_matching_input rollback.

The stateful harness uses one cohesive authority state plus scenario/profile,
stale flag, cursor, command history and last-atomicity predicate. One guarded
command occurs per action. The terminal fallback has an explicit false guard
and assignments, so it is disabled rather than an unconditional stutter.
Every action witness reads actual command history; profile completion also
requires route exhaustion, not merely an initializer label.

The ordinary pure matrix retains all24 scenario/profile pairs from Task 2;
stale pure tests cover both profiles. Four deterministic action paths cover
settlement, refund, verified-stale rejection and empty timeout refusal.
Financial terminal still requires actual N0, zero escrow and no pending
attempt/signing records. Route completion can instead mean retained refusal.

Maximum ordinary/stale route length is19 transitions; samples use max-steps22,
the adopted margin3. This is unrelated to Core's internal reduction bound22.
The random workload selects these finite routes; it is not arbitrary concurrent
interleaving exploration. No model-checking or universal safety claim follows.

## Preserved compiling behavioral RED

Wrote all added tests and the complete harness, with only VerifyS deliberately
using generic `canVerify` instead of `canVerifyAuthorityA`. Captured all16 exact
transitive source files before the original typecheck and focused test:

```bash
quint typecheck specs/quint/s02/candidate_a_authority_swap_test.qnt
quint test specs/quint/s02/candidate_a_authority_swap_test.qnt --backend=rust --seed=42 --match '^mutationTest$'
```

Experiment observation: recursive typecheck exit0, empty output. mutationTest
exit1, `mutationTest failed after 1 test(s)`, `1 failed`, QNT508 assertion at
test line116. Its set contains the fully rebound unused-successor-node mutant
and all three other prescribed mutants. The raw diagnostic reports the compound
assertion rather than naming an individual set member; no isolated failing-member
trace is claimed. Full output is in red/mutation-test.json, including the CLI
repeat hint `--seed=0x2a --match=mutationTest`.

Both terminal receipts and exact original source-byte closure were preserved
before restoring the sole guard call. Re-reading the closure showed no intervening
source change. Then changed only the generic VerifyS guard back to the accepted
A-specific guard. Tests, mutants, expected outcomes and harness stayed identical.
The subsequent complete GREEN confirms this local guard-control experiment.
This is the single original Task 3 behavioral RED, not a claim that every added
test independently failed first. No parser/type failure or ineffective RED was
counted as the behavioral control.

## Final recursive typecheck and seventeen tests

Exact commands:

```bash
quint typecheck specs/quint/s02/candidate_a_authority_swap_test.qnt
quint test specs/quint/s02/candidate_a_authority_swap_test.qnt --backend=rust --seed=42 --match '.*Test'
```

Experiment observation: both terminal exit0. The recursive entry imports the
verified full16-file closure, explicitly including fixtures, lifecycle, harness
and tests. This implements the adopted static-check consolidation; no additional
duplicate standalone imported-module typechecks were run.

Complete combined test output:

```text
candidate_a_authority_swap_test
    ok literalFidelityTest passed 1 test(s)
    ok authorityTimeZeroTest passed 1 test(s)
    ok fundingTest passed 1 test(s)
    ok dispositionMatrixTest passed 1 test(s)
    ok replayTest passed 1 test(s)
    ok staleSigningTest passed 1 test(s)
    ok staleVerifiedTest passed 1 test(s)
    ok mutationTest passed 1 test(s)
    ok identityBindingTest passed 1 test(s)
    ok wrongActorTest passed 1 test(s)
    ok staleFactsTest passed 1 test(s)
    ok settleActionTest passed 1 test(s)
    ok refundActionTest passed 1 test(s)
    ok staleActionTest passed 1 test(s)
    ok emptyTimeoutActionTest passed 1 test(s)
    ok initialWitnessesFalseTest passed 1 test(s)
    ok boundsTest passed 1 test(s)

  17 passing (58852ms)
```

## Approved hundred-sample result

Ran only after all17 tests were GREEN, on the unchanged final source:

```bash
quint run specs/quint/s02/candidate_a_authority_swap_harness.qnt --backend=rust --seed=42 --max-samples=100 --max-steps=22 --invariant=swapSafetyS --witnesses alicePreparedS aliceSignedS aliceProposedS aliceVerifiedS aliceCommittedS bobPreparedS bobSignedS bobProposedS bobVerifiedS bobCommittedS dispositionAlicePreparedS dispositionAliceSignedS dispositionBobPreparedS dispositionBobSignedS dispositionProposedS dispositionVerifiedS dispositionCommittedS proposedRejectedS verifiedRejectedS advanced2S advanced100S advanced101S afterCompletedS beforeCompletedS --verbosity=1
```

Terminal exit0. Complete combined output:

```text
[ok] No violation found (16252ms at 6 traces/second).
Witnesses:
alicePreparedS was witnessed in 92 trace(s) out of 100 explored (92.00%)
aliceSignedS was witnessed in 92 trace(s) out of 100 explored (92.00%)
aliceProposedS was witnessed in 92 trace(s) out of 100 explored (92.00%)
aliceVerifiedS was witnessed in 92 trace(s) out of 100 explored (92.00%)
aliceCommittedS was witnessed in 92 trace(s) out of 100 explored (92.00%)
bobPreparedS was witnessed in 89 trace(s) out of 100 explored (89.00%)
bobSignedS was witnessed in 89 trace(s) out of 100 explored (89.00%)
bobProposedS was witnessed in 89 trace(s) out of 100 explored (89.00%)
bobVerifiedS was witnessed in 89 trace(s) out of 100 explored (89.00%)
bobCommittedS was witnessed in 89 trace(s) out of 100 explored (89.00%)
dispositionAlicePreparedS was witnessed in 73 trace(s) out of 100 explored (73.00%)
dispositionAliceSignedS was witnessed in 73 trace(s) out of 100 explored (73.00%)
dispositionBobPreparedS was witnessed in 70 trace(s) out of 100 explored (70.00%)
dispositionBobSignedS was witnessed in 70 trace(s) out of 100 explored (70.00%)
dispositionProposedS was witnessed in 100 trace(s) out of 100 explored (100.00%)
dispositionVerifiedS was witnessed in 73 trace(s) out of 100 explored (73.00%)
dispositionCommittedS was witnessed in 24 trace(s) out of 100 explored (24.00%)
proposedRejectedS was witnessed in 27 trace(s) out of 100 explored (27.00%)
verifiedRejectedS was witnessed in 49 trace(s) out of 100 explored (49.00%)
advanced2S was witnessed in 89 trace(s) out of 100 explored (89.00%)
advanced100S was witnessed in 76 trace(s) out of 100 explored (76.00%)
advanced101S was witnessed in 20 trace(s) out of 100 explored (20.00%)
afterCompletedS was witnessed in 54 trace(s) out of 100 explored (54.00%)
beforeCompletedS was witnessed in 46 trace(s) out of 100 explored (46.00%)
Use --seed=0x153 --backend=rust to reproduce.
```

All24 required names are present and nonzero, so no1000-sample escalation,
diagnostic rerun or extra output-flag run was authorized or needed.
Requested seed42 and the tool's printed reproduction hint0x153 are preserved as
different strings, not silently normalized. The elapsed16252ms is the tool's
reported sampling time, not the preceding compiler wall time.

Trace paths are empty: the approved verbosity1 command requested no ITF output.
There is no per-sample ITF archive or individual-event export in this task.
The saved artifact is the actual invariant summary, all counts and terminal
output, as explicitly confirmed by root. A4 requires dedicated actual-record
instrumentation/inventory later. Counts do not prove every possible scenario
occurred in sampling or replace the deterministic case matrix.

## Evidence, self-review and remaining gates

Receipt root: `.superpowers/sdd/a3-task3-receipts/`.

- identity.json: actual tool/base/plan/addendum/fixture command and output.
- red/source/specs/quint/s02/: all16 original RED source files.
- red/source-byte-audit.json: byte identity before correction.
- red/typecheck.json and red/mutation-test.json: full RED commands and terminal chunks.
- green/source/specs/quint/s02/: all16 final source files.
- green/typecheck.json and green/task3-tests.json: final type/test receipts.
- green/samples100.json: exact sampling command, all24 parsed counts, raw output,
  terminal exit, source pins and explicit empty tracePaths.
- final-source-audit.json: all32 RED/GREEN snapshot files match their captured
  hashes; all16 final source files remain byte-identical to live source.
  The historical lifecycle guard call is the only RED/GREEN source difference.

The unit closure includes the test file; the harness runtime entry imports15
of those16 files and excludes the test. Receipts explicitly describe that scope.
Source snapshots use apply_patch; no recorder source file was introduced.
Inline read-only collection/audit commands are retained in receipts. Every
returned command-output chunk, including empty yields, is retained. The command
tool supplies combined output, not separately attributable stdout/stderr streams.

Tool: Quint0.32.0 at `/home/charl/.npm-global/bin/quint`, SHA256
`ac12595b1cb7253feec93c79417615c6eb20fc3b6a3df35c5e3530b24e90a501`.
Rust evaluator: `/home/charl/.quint/rust-evaluator-v0.6.0/quint_evaluator`, SHA256
`b2efdeac5713d153e41bf2143b94ed75d888fdd5637f4a5d61a04c695313510a`.

All local validation jobs terminated naturally. No duplicate jobs, killed
processes, hidden source edits, shared regression runs or commits were made.
Quint modeling/language skills guided guarded actions/history witnesses;
TDD required the preserved compiling RED before guard restoration; verification
required terminal results. Root coordinates subagent-driven nonauthor review.

Root communicated nonauthor source approval at the final four-module hashes.
That message is not this author's independent review or full acceptance claim.
Root still owns the shared boundary/adapter/Python regression receipt after both
lifecycle closures freeze, final archive intake and acceptance. No concrete
implementation issue found in scoped self-review. A4 exports, A5 bounded checking,
A6 Council and A7 integration remain separate/open. I read the proposed A4 design
as permitted while waiting, but did not plan or implement A4 in this task.

Final source/report/receipts are frozen for root intake; available for concrete
review corrections. No next unit or commit without explicit root authorization.
