#!/usr/bin/env python3
"""One shared final regression snapshot; exact commands, streams and source pins."""
import datetime
import hashlib
import importlib.metadata
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parent
PYTHON = '/home/charl/Moriarty/.venv/bin/python'
COMMANDS = {
    'boundary': ['quint', 'test', 'specs/quint/s02/candidate_a_authority_boundary_test.qnt', '--backend=rust', '--seed=42'],
    'adapter': ['quint', 'test', 'specs/quint/s02/candidate_a_authority_adapter_test.qnt', '--backend=rust', '--seed=42'],
    'python': [PYTHON, '-m', 'pytest', '-q'],
}

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write_json(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def pins(entries):
    return [{'path': e['path'], 'sha256': digest(e['path'])} for e in entries]

mode = sys.argv[1]
if mode == 'prepare':
    assert not (BASE / 'snapshot.json').exists()
    installment = ROOT / 'specs/quint/s02/candidate_a_authority_installment.qnt'
    assert '| ProposedAttempt(a) => canVerifyAuthorityA(state, id, evidenceI' in installment.read_text(), 'A2 final guard not restored'
    tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
    paths = {ROOT / p for p in tracked if p and not p.startswith(('.foreman/', '.superpowers/')) and (ROOT / p).is_file()}
    units = []
    for lane in ('installment', 'swap'):
        for suffix in ('', '_fixtures', '_harness', '_test'):
            relative = f'specs/quint/s02/candidate_a_authority_{lane}{suffix}.qnt'
            path = ROOT / relative
            assert path.is_file(), relative
            paths.add(path)
            units.append({'path': relative, 'sha256': digest(path)})
    paths.add(Path(__file__).resolve())
    graph = ROOT / 'graphs/marlowe-org-full/graphify-out'
    for name in ('graph.json', 'GRAPH_REPORT.md', 'DIAGNOSTICS.md', '.graphify_analysis.json', '.graphify_extract.json', '.graphify_labels.json', 'graph.html', 'GRAPH_TREE.html', 'cost.json'):
        paths.add(graph / name)
    external = Path('/home/charl/defiformal')
    paths.update((external / 'corpus50/lanes').glob('*.json'))
    for directory in (external / 'expansion').glob('[0-9][0-9]-*'):
        paths.add(directory / 'verdicts.json')
        paths.update((directory / 'specs').glob('*.json'))
    for name in ('formal/v2/tables.mjs', 'viz/src/data.ts', 'algebra/blind-test-set.json'):
        paths.add(external / name)
    entries = []
    with tarfile.open(BASE / 'source-inputs.tar.gz', 'x:gz') as archive:
        for path in sorted(paths):
            raw = path.read_bytes()
            prefix = 'moriarty' if path.is_relative_to(ROOT) else 'defiformal'
            relative = path.relative_to(ROOT if prefix == 'moriarty' else external)
            name = str(Path(prefix) / relative)
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            import io
            archive.addfile(info, io.BytesIO(raw))
            entries.append({'path': str(path), 'archivePath': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    tools = []
    for name, path in [('quint', Path(shutil.which('quint'))), ('rust', Path('/home/charl/.quint/rust-evaluator-v0.6.0/quint_evaluator')), ('python', Path(PYTHON)), ('node', Path(shutil.which('node'))), ('git', Path(shutil.which('git')))]:
        tool = {'name': name, 'path': str(path), 'resolvedPath': str(path.resolve()), 'sha256': digest(path)}
        if name == 'rust':
            tool.update(versionLabel='v0.6.0', versionProvenance='Installation-directory label; binary --version unsupported, original diagnostic preserved in A2 Task1 archive.')
        else:
            result = subprocess.run([str(path), '--version'], capture_output=True, text=True)
            tool.update(versionExit=result.returncode, versionStdout=result.stdout, versionStderr=result.stderr)
            assert result.returncode == 0
        tools.append(tool)
    packages = sorted([{'name': d.metadata['Name'], 'version': d.version} for d in importlib.metadata.distributions()], key=lambda d:d['name'].lower())
    metadata = {'observedAt': now(), 'cwd': str(ROOT), 'sourceCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), 'externalCommit': subprocess.check_output(['git', '-C', str(external), 'rev-parse', 'HEAD'], text=True).strip(), 'units': units, 'sourceAndInputClosure': entries, 'tools': tools, 'installedPythonDistributions': packages, 'commands': COMMANDS, 'archiveSha256': digest(BASE / 'source-inputs.tar.gz'), 'limits': ['Conservative tracked repository/input superset plus explicit graph and DeFiFormal test inputs; ignored unrelated files not captured', 'Interpreter and CLI/backend binaries pinned; installed Python distributions recorded by version, not a full virtualenv byte archive', 'No liveness, Council, correspondence or model-checking claim']}
    assert pins(entries) == [{'path':e['path'], 'sha256':e['sha256']} for e in entries], 'source changed during capture'
    write_json(BASE / 'snapshot.json', metadata)
    print(json.dumps({'snapshot':str(BASE / 'snapshot.json'), 'files':len(entries), 'archiveSha256':metadata['archiveSha256'], 'units':units}), flush=True)
else:
    assert mode in COMMANDS
    metadata = json.loads((BASE / 'snapshot.json').read_text())
    entries = metadata['sourceAndInputClosure']
    expected = [{'path':e['path'], 'sha256':e['sha256']} for e in entries]
    assert pins(entries) == expected, 'source/input snapshot stale before dispatch'
    assert all(digest(t['path']) == t['sha256'] for t in metadata['tools']), 'tool snapshot stale'
    stage = BASE / mode
    stage.mkdir(exist_ok=False)
    write_json(stage / 'input.json', {'observedAt':now(), 'argv':COMMANDS[mode], 'cwd':str(ROOT), 'snapshotSha256':digest(BASE / 'snapshot.json'), 'sourceUnchangedBefore':True})
    start = time.monotonic()
    with (stage / 'stdout.txt').open('xb') as out, (stage / 'stderr.txt').open('xb') as err:
        result = subprocess.run(COMMANDS[mode], cwd=ROOT, stdout=out, stderr=err)
    after = pins(entries)
    changes = [{'path':old['path'], 'before':old['sha256'], 'after':new['sha256']} for old,new in zip(expected,after) if old != new]
    terminal = {'exitCode':result.returncode, 'durationSeconds':time.monotonic()-start, 'completedAt':now(), 'sourceChanges':changes, 'toolsUnchanged':all(digest(t['path']) == t['sha256'] for t in metadata['tools']), 'stdoutSha256':digest(stage / 'stdout.txt'), 'stderrSha256':digest(stage / 'stderr.txt')}
    write_json(stage / 'result.json', terminal)
    sys.stdout.buffer.write((stage / 'stdout.txt').read_bytes())
    sys.stderr.buffer.write((stage / 'stderr.txt').read_bytes())
    print(json.dumps({'stage':str(stage), **terminal}), flush=True)
    raise SystemExit(result.returncode if not changes and terminal['toolsUnchanged'] else 2)
