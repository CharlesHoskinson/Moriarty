# A4 checker Task4 bounded execution

Task3 admitted0655354. Resolve its full SHA for taskbase. Read Task4 in immutable
independent-replay plan and ab7c827 replay-interface addendum completely.
Own scripts/a4_inventory.py and Task4 test additions only; ignored unique
.superpowers/sdd/a4-checker-task4-receipts/ and report are yours. Preserve all
Task1–3 source/tests and other agents' files. No commits/main/DB/Foreman.

The addendum is binding: exact78cases/1557events, I638/S919; the adopted plan's
old1757 total is an arithmetic error. Apply only that count correction at every
Task4 assertion; omit no descriptors/events. Compare root's frozen inventory
canonical SHA8a1a6136afc9fda3c29e050df8b80144750cc21365e9194924401c155dc6402b.
Include lifecycle-specific guard restrictions, negative schedules, denied
unchanged probes, explicit derivations and retained terminal/rejection records.
No exported states/producer code may provide expected authority updates.

Prescribed compiling RED omits the old-nonce inventory entry; the fixed inventory
assertion must fail with successful imports. Restore it, then run all current
checker tests without exclusions. Preserve original RED/GREEN source/import/
runtime snapshots, separate raw streams, actual argv/cwd/exits/timing and no
mid-command movement. Reuse Task1 runtime by exact manifest/archive hashes.
Run names/case counts are distinct; report both. No Task5/package admission
implementation until root independently admits Task4. Any unexpected semantics
failure is diagnosed, not bypassed with source-generated expected records.
