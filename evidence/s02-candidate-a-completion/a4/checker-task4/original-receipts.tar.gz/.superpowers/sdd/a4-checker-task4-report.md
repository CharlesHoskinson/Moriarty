# A4 checker Task4 implementation report

Status: Task4 implementation and local verification complete. Root admission pending; no Task5, package admission, commit, index update, producer import/change or Council claim.

Task base and all recorded runtime source commits: `06553541596a955f56f317df9866f9b2e595bf38`.
Adopted plan SHA256: `2edb50ec93c88c62d8fddf1ba9d29b893e494b1564d28fdef6dd82674fca739e`.
Binding immutable addendum: `ab7c827`.

## Final source

- `scripts/a4_inventory.py`: `adc536fd1eceeee7e023d8b184b64450f08399690dec8bc8fefd04188b33b69a`.
- `tests/test_s02_candidate_a_integrated.py`: `5714f4efab6679ce4a0c189253dc7788700d68ae26df3000ad506b4f34c83736`.
- Ignored recorder `a4-checker-task4-receipts/recorder.py`: `52cdcc1c66edcb2d36d2785874936717d04e39342a82c4e6b63004c3b65414cd`.

Inventory module equals the adopted Task4 code byte-for-byte. Tests equal the exact committed Task3 file plus one separating newline and the adopted Task4 block, with only the addendum's1757-to1557 and591-to391 corrections. Existing four checker modules and test prefix remain unchanged. Other agents' producer/B/A5 files were preserved.

## Original verification receipts

Directory: `.superpowers/sdd/a4-checker-task4-receipts/`. Each stage has original source archive, input manifest, separate stdout/stderr, and terminal manifest with actual exit and elapsed time. Interpreter is `/home/charl/Moriarty/.venv/bin/python`; cwd is the experiment worktree. Fresh per-command pycache paths and disabled bytecode writes prevent stale bytecode reuse.

| Stage | Exit | Outcome |
| --- | --- | --- |
| tests-first | 2 | Missing inventory module collection error before implementation; not behavioral RED |
| red-import | 0 | Five checker modules import successfully |
| red-tests | 1 | Intended fixed inventory assertion fails76 versus78;15 other tests pass |
| green-syntax | 0 | Six final Python source/test files compile |
| green-import | 0 | Five final checker modules import |
| green-tests | 0 | All16 tests pass, no exclusions;25.74s pytest time |
| green-inventory | 0 | Independently executed histories equal every frozen descriptor/count record and canonical hash |

RED inventory source SHA256: `a094b1a9cc1be815ec4fb2513e7916453fc7afbc2c1bc9f81573df6dc5b4fdfa`. The sole behavioral RED-to-GREEN change restores `('old-nonce','recover-r0-choice2')`. Its omission removes both profiles and produces76 descriptors. The corrected count assertions were already present during RED; no test was weakened. The recorder gained a separate green-inventory command after RED, with each version retained in its original source archive.

All seven complete terminal manifests report no source or environment changes during the command. Behavioral and GREEN archives have37 source members; tests-first has36 because the new module did not exist. Final read-only audit verified archive hashes, every archived member, both stream hashes, exact adopted module, corrected test block, unchanged Task1–3 module bytes, and sole prescribed RED source difference.

The unchanged Task1 shared Python environment is referenced, not duplicated:3,329 files, manifest SHA256 `cd004057c4067bf7cc536d2cec5038add88d0852c1a7de5030e402ff2204f9c4`, archive SHA256 `7363d106d464f976af2a0e7f1f56e3c7bed237c7a3396a60d073369add068dac`. Per-stage source pins include all local Python imports, common/A sources, accepted lifecycle fixtures/modules/tests/harnesses, root inventory, recorder, brief, plan, and addendum. No unexpected runtime or receipt preflight failure occurred in Task4.

## Executed fixed inventory

| Family | Cases | Events |
| --- | ---: | ---: |
| Installment ordinary | 22 | 516 |
| Installment negative | 10 | 122 |
| Swap ordinary | 24 | 484 |
| Swap verified-stale | 2 | 44 |
| Swap negative | 20 | 391 |
| Total | 78 | 1557 |

Installment total638; swap919. Counts include case-start and case-end. The16 collected tests are distinct from the78 profile-specific cases and1557 generated events. Ordinary route coverage remains11 installment and12 swap scenarios under both signing profiles.

The separate green-inventory command computes every history using the independent checker, forms the ordered descriptor/event_count inventory, compares it to the frozen root JSON, then independently hashes canonical compact sorted-key UTF-8 JSON. Exact canonical SHA256 is `8a1a6136afc9fda3c29e050df8b80144750cc21365e9194924401c155dc6402b`. The root JSON is a comparison target, not input to descriptor/history generation. No producer function or submitted authority state supplies expected transitions.

## Source self-review

- Descriptor order, exact literal case IDs, full profile names, scenarios and all five installment/ten swap negative control families match the adopted plan plus arithmetic addendum. Both verified-stale profiles are distinct from ordinary cases.
- Public command/guard aliases retain full records. Lifecycle recovery prepare/sign requires cancelled parent; installment race commits require both retained verified attempts with the exact current context; proposal checks retain A execution validity. Fixed Advance descriptors satisfy the corresponding lifecycle time/mode restrictions. Generic control probes deliberately use common/A rather than stronger lifecycle guards when specified.
- Every transition requires its actual independently calculated gate. Every denied probe requires false and keeps the complete state unchanged. Financial, parent cancellation and slot probes retain full explicit parameters. Ordinary replay probes cover executed installment IDs and all swap funding/disposition IDs, including refused disposition; cancelled ordinary parents receive cancellation and both slot probes.
- Adversarial derivation changes only the prescribed attempt cell and retains authority state. It explicitly names the original case/sequence and rebuilds full evidence bindings to the changed attempt. Proposed and constructed-verified observation mutations both start from the original proposal, with the prior rejection still present in history. They are not presented as real verification transitions.
- Retained rejection transitions use the Task2 classifier/update and preserve full attempt/evidence/context/stage/reason. No-cancel, unsigned, old-nonce, duplicate cancellation, stale signing, unused successor, reversed effects, reductions, neutral chooser, bad second plan, wrong Core chooser, wrong signer/nonce and stale facts all execute their prescribed denied guards and applicable rejection transitions.
- Agreement computation fields come from a separate frozen Python Core evaluation of the actual retained call, not the adversarial claimed projection. The reductions test establishes that the changed claim is one higher than raw computation. Preparation/signing observes every agreement call in the full after-resolution plan; before-resolution and cancellation have no invented computation. Cancellation's empty list follows its explicit call discriminator.
- Ordinary case-end distinguishes actual financial terminal from refusal terminal. Negative-complete is a completed negative schedule, not a financial claim; pending unrelated attempts or stale signing checks can remain. Complete-case resets are not ordinary authority transitions.

## Limits and handoff

This is author self-review and finite independently generated Python histories, not independent acceptance, actual exported Quint execution, source/ITF provenance admission, model checking, cryptographic verification, or Council evidence. Full raw adjacency and reset provenance checks, package CLI and semantic/provenance mutant triples remain later tasks. No package was accepted here.

The implementation and TDD skills kept Task4 bounded to the adopted block, binding arithmetic correction, and genuine compiling fixed-inventory RED. Root owns independent review and byte/receipt admission before Task5.
