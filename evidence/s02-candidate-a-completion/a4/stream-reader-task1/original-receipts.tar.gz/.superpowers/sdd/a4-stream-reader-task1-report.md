# A4 streaming reader Task1 report

Status: reader-only implementation and local verification complete; root admission pending. No writer/hash implementation, consumer edits, package invocation, commit or Council claim.

Task base and every runtime sourceCommit: `22cdec6e561b4def3bd7c4a9bd723e2ad824d800`. Adopted plan SHA256: `a75dbb9283027d2937e663653289f3761a3813f82603cd99532042b0de571d95`.

## Final bytes

- `scripts/a4_json_stream.py`: `e10d2e6275915de219d64eb1eb93c1220a602021a6a597fedfe319a19c908fae`.
- `tests/test_a4_json_stream.py`: `e046b30575d651b0adc12ecf3a23da0dd768f03af3cd095fc60d500f9b538479`.
- Ignored recorder `a4-stream-reader-task1-receipts/recorder.py`: `f2a3de869e73529d94a915a4fbf1c7b1fae9971d3ccaa8fe10070772fe738dd5`.

Both source and tests equal their complete adopted Task1 code blocks byte-for-byte. No existing producer/checker/runtime helper source was changed. Imports are standard library only; hashlib/Iterable are present as adopted but no writer/hash API is implemented yet.

## Original terminal inventory

Original receipts reside in `.superpowers/sdd/a4-stream-reader-task1-receipts/`. Each retains actual source archive, input manifest, separate stdout/stderr and terminal manifest. Interpreter is `/home/charl/Moriarty/.venv/bin/python`; cwd is the experiment worktree. Both recorder and child commands start with -B and a unique -X pycache_prefix; child environment additionally disables bytecode writes and identifies the same unique cache path.

| Stage | Exit | Result |
| --- | --- | --- |
| tests-first | 2 | Expected missing reader module collection error, before source creation; not behavioral RED |
| red-import | 0 | Reader imports successfully |
| red-tests | 1 | Escaped duplicate-key test fails with DID NOT RAISE JsonStreamError |
| green-syntax | 0 | Final source and tests compile |
| green-import | 0 | Final reader imports |
| green-tests | 0 | All29 reader tests pass, no exclusions;0.03s pytest time |

Original RED source SHA256: `74322e813a3e45177a79c6b805b7384f01d2d017ed398a2b758d0dca44968663`. Its sole difference from final source is omission of `_object`'s duplicate-key rejection line. The escaped x/u0078 object test reaches the missing rejection after successful imports. Restore changes that one line only.

All six stages have empty sourceChanged/environmentChanged. The original runtime closure is the unchanged3329-file Task1 Python archive, reused by path and exact hash, not copied: manifest `cd004057c4067bf7cc536d2cec5038add88d0852c1a7de5030e402ff2204f9c4`; archive `7363d106d464f976af2a0e7f1f56e3c7bed237c7a3396a60d073369add068dac`. Focused local source archives have seven members (reader, test, pyproject, uv.lock, plan, brief, recorder), six before reader creation. There are no local semantic imports to archive in this utility unit.

Final read-only audit verified all original archive hashes, every archived source member, stdout/stderr hashes, actual -B/-X command prefixes, exact plan equality and sole prescribed RED difference. No original failed run or stream was reconstructed.

## Source/spec self-review

The reader incrementally decodes strict UTF-8, retains only the current selected array item plus bounded input/value buffers, and rejects duplicate nested/top-level keys including escaped aliases. The stdlib JSON decoder checks each value's syntax, with explicit nonfinite rejection and integer/float/bool preservation. Character, integer-conversion and recursion resource failures remain distinguishable ResourceLimit errors.

Top-level fields before/after the selected array are emitted in order. End is emitted only after the complete object and trailing whitespace are consumed and the selected array was present. Invalid suffixes cannot yield complete success. Consumers still must exhaust the iterator and impose their independent schemas; a yielded item alone is not acceptance.

Tests cover every chunk size of a Unicode/escape/bracket fixture,24 malformed/duplicate/nonfinite/UTF8/BOM/trailing inputs under four chunk sizes, suffix failure before end, empty arrays, laziness, explicit limits and AST import isolation. This is29 collected tests, not29 authority cases. No semantic inventory is imported or altered.

Limits: per-value Python codec copies and one character list are permitted bounded allocations, not zero-copy parsing. Escaped unpaired surrogates follow the adopted standard-decoder behavior; actual malformed UTF-8 fails. Generic decoding does not establish ITF carrier validity, authority semantics, raw provenance, full package acceptance, native export feasibility, model checking or cryptography. Root's prior synthetic4MiB plan-code probe is not counted as an implementation test here.

The implementation/TDD skills governed the reader-only scope and genuine compiling RED. Root must independently admit this unit before writer Task2 or either consumer integration. Sharing this utility later is a disclosed transport dependency, not shared semantic authority judgment.
