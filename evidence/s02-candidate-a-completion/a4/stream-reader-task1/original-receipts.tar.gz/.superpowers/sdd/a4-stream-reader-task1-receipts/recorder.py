"""Stream reader Task1 immutable original-byte snapshots and per-command terminal receipts."""
import datetime
import hashlib
import importlib.metadata
import io
import json
from pathlib import Path
import subprocess
import sys
import sysconfig
import tarfile
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
PYTHON = '/home/charl/Moriarty/.venv/bin/python'
BASE = '22cdec6e561b4def3bd7c4a9bd723e2ad824d800'
SOURCES = ('scripts/a4_json_stream.py','tests/test_a4_json_stream.py',
           'pyproject.toml','uv.lock',
           'docs/superpowers/plans/2026-09-05-candidate-a-streaming-json.md',
           '.superpowers/sdd/a4-stream-reader-task1-brief.md',
           '.superpowers/sdd/a4-stream-reader-task1-receipts/recorder.py')
COMMANDS = {
 'tests-first':[PYTHON,'-m','pytest','-q','tests/test_a4_json_stream.py'],
 'red-import':[PYTHON,'-c','import scripts.a4_json_stream; print("Reader imports succeeded")'],
 'red-tests':[PYTHON,'-m','pytest','-q','tests/test_a4_json_stream.py::test_reader_escaped_duplicate_key_red'],
 'green-import':[PYTHON,'-c','import scripts.a4_json_stream; print("Reader imports succeeded")'],
 'green-syntax':[PYTHON,'-c','from pathlib import Path; [compile(Path(p).read_bytes(),p,"exec") for p in ("scripts/a4_json_stream.py","tests/test_a4_json_stream.py")]; print("Reader syntax succeeded")'],
 'green-tests':[PYTHON,'-m','pytest','-q','tests/test_a4_json_stream.py'],
}

def sha(data): return hashlib.sha256(data).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path, value):
    with path.open('x') as stream: json.dump(value, stream, indent=2, sort_keys=True); stream.write('\n')
def pin(path): return {'path': str(path), 'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size}
def archive(target, paths):
    entries=[]
    with tarfile.open(target, 'x:gz') as tar:
        for path in sorted(paths):
            raw=path.read_bytes(); name=str(path).lstrip('/')
            info=tarfile.TarInfo(name); info.size=len(raw); tar.addfile(info, io.BytesIO(raw))
            entries.append({'path':str(path),'archivePath':name,'sha256':sha(raw),'bytes':len(raw)})
    return entries

mode=sys.argv[1]
if mode.endswith('-retry'): COMMANDS[mode]=COMMANDS[mode.removesuffix('-retry')]
assert mode in COMMANDS
stage=OUT/mode; stage.mkdir(exist_ok=False)
COMMANDS[mode]=[PYTHON,'-B','-X','pycache_prefix='+str(stage/'fresh-pycache'),*COMMANDS[mode][1:]]
ENVIRONMENT=OUT.parent/'a4-checker-task1-receipts'/'python-environment.json'
assert sha(ENVIRONMENT.read_bytes())=='cd004057c4067bf7cc536d2cec5038add88d0852c1a7de5030e402ff2204f9c4'
environment=json.loads(ENVIRONMENT.read_text())
assert sha((ENVIRONMENT.parent/'python-environment.tar.gz').read_bytes())==environment['archiveSha256']
env_before=[pin(Path(e['path'])) for e in environment['sourceBytes']]
assert all(a['sha256']==b['sha256'] for a,b in zip(env_before,environment['sourceBytes']))
present=sorted(ROOT/name for name in SOURCES if (ROOT/name).is_file())
missing=[name for name in SOURCES if not (ROOT/name).is_file()]
if not mode.startswith('tests-first'): assert not missing, missing
source_entries=archive(stage/'source.tar.gz',present)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
import os
env=os.environ.copy(); overrides={'PYTHONDONTWRITEBYTECODE':'1','PYTHONPYCACHEPREFIX':str(stage/'fresh-pycache')}
if mode.startswith('direct-help'): overrides['PYTHONPATH']=''
env.update(overrides)
write(stage/'input.json',{'createdAt':now(),'argv':COMMANDS[mode],'cwd':str(ROOT),'baseCommit':BASE,'sourceCommit':head,
    'environmentOverrides':overrides,'pythonEnvironmentManifestPath':str(ENVIRONMENT),'pythonEnvironmentManifestSha256':sha(ENVIRONMENT.read_bytes()),'pythonEnvironmentArchiveSha256':environment['archiveSha256'],
    'sourceArchiveSha256':sha((stage/'source.tar.gz').read_bytes()),'sourceBytes':source_entries,'absentSources':missing,
    'namespacePackagesWithoutInit':['scripts','tests'],'pythonBefore':pin(Path(PYTHON)),
    'environmentBefore':env_before})
start=time.monotonic()
with (stage/'stdout.txt').open('xb') as stdout, (stage/'stderr.txt').open('xb') as stderr:
    result=subprocess.run(COMMANDS[mode],cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
after=[pin(p) for p in present]
env_after=[pin(Path(e['path'])) for e in environment['sourceBytes']]
source_changed=[e['path'] for e,a in zip(source_entries,after) if e['sha256']!=a['sha256']]
environment_changed=[a['path'] for a,b in zip(env_before,env_after) if a!=b]
terminal={'completedAt':now(),'elapsedSeconds':time.monotonic()-start,'exitCode':result.returncode,
    'sourceAfter':after,'environmentAfter':env_after,'sourceChanged':source_changed,'environmentChanged':environment_changed,
    'pythonAfter':pin(Path(PYTHON)),'stdoutSha256':sha((stage/'stdout.txt').read_bytes()),'stderrSha256':sha((stage/'stderr.txt').read_bytes())}
write(stage/'terminal.json',terminal)
sys.stdout.buffer.write((stage/'stdout.txt').read_bytes()); sys.stderr.buffer.write((stage/'stderr.txt').read_bytes())
print(json.dumps({'stage':str(stage),'exitCode':result.returncode,'elapsedSeconds':terminal['elapsedSeconds'],
    'sourceChanged':source_changed,'environmentChanged':environment_changed}),flush=True)
raise SystemExit(result.returncode if not source_changed and not environment_changed else 2)
