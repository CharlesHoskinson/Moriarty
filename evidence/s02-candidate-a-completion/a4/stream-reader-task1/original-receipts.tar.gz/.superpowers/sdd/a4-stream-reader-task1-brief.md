# A4 streaming reader Task1 dispatch

Root read/admitted all491lines of streaming JSON plan
docs/superpowers/plans/2026-09-05-candidate-a-streaming-json.md,
SHA256a75dbb9283027d2937e663653289f3761a3813f82603cd99532042b0de571d95.
Implement only Task1 exact reader/tests. Own scripts/a4_json_stream.py,
tests/test_a4_json_stream.py and unique ignored source/runtime receipts/report.
No existing checker/producer files or shared runtime helper edits.

Use apply_patch, tests first, retain missing-module diagnostic separately, then
importable duplicate-key-guard-omission RED, restore exact line, full reader
GREEN. Pin original plan, this brief, recorder and actual source/test/runtime
bytes before/after each command. Reuse already admitted3329-file Python archive,
no duplication. Use fresh process-start -B/-X cache settings and unique stages.
Record actual pre-dispatch experimental HEAD, not a guessed future commit.

Root requires complete source/spec and original receipt audit before Task2.
No writer/hash, consumer integration, package acceptance or commit in this unit.
Report .superpowers/sdd/a4-stream-reader-task1-report.md then await admission.
Concurrent producerTask2 does not import these files yet; do not edit its
recorder/source lists. Coordinate later addition to both consumer closures.
