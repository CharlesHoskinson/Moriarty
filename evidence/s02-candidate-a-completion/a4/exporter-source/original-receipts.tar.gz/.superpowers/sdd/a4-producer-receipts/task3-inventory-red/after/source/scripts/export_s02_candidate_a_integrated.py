class ExportError(ValueError):
    pass

def validate_inventory(actual, expected):
    return None
