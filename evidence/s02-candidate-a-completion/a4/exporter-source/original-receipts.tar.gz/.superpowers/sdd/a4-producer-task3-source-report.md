# A4 producer Task3 exporter source-unit author report

Status: frozen bounded source-unit handoff. Original two-case inventory RED recorded; non-actual unit GREEN55passed/4deselected. No author jobs remain. Actual-package validation and root admission remain separate.

## Authority, ownership and unchanged boundaries

Root dispatched only the exporter source unit under adopted e221eaf plan `docs/superpowers/plans/2026-09-05-candidate-a-sharded-exporter.md`, SHA25661c7571cd97f3fc211818a7016cb3414acb8a6da508495d69ff2c2283c8e6501. The whole1062-line plan was read before changes. The current pre-dispatch source base wasb08a2da7180015ef017a6b89926f2cd5a5276ef6; the separate original producer/runtime dispatch base remains386bf0ae10f767e051b414a7231be105cc4b0f71. Both original command receipts have sourceCommit and sourceCommitAfter equal tob08a2da.

Only new scripts/export_s02_candidate_a_integrated.py and the approved append to tests/test_s02_candidate_a_integrated_export.py changed. No recorder, utility, checker, Task6, frozen Quint/Core/A/lifecycle/A5 source or previous receipt changed. No commits, native pilot/export, real aggregate parser, package staging/sealing or RH002 runner implementation occurred.

The executing-plans and TDD skills governed the bounded sequence. This report is author evidence, not independent review, formal correspondence, native execution attestation, integration or Council acceptance.

## Original RED before implementation

An importable ExportError plus validate_inventory returningNone was created first. Both unchanged planned assertions were appended: dropped whole case and reordered profiles. The recorded command reached both actual DID NOT RAISE ExportError failures, not an import/parser error.

Exact original command:

```bash
/home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/a4-producer-receipts/task3-inventory-red/python-cache scripts/record_s02_candidate_a_integrated.py --stage task3-inventory-red -- /home/charl/Moriarty/.venv/bin/python -m pytest tests/test_s02_candidate_a_integrated_export.py -q -k 'dropped_whole_case or reordered_profiles'
```

Terminal child/recorder1;2failed/15deselected;0.785130870seconds recorder duration. Empty stderr. Full original stdout:

```text
FF                                                                       [100%]
=================================== FAILURES ===================================
_____________________ test_dropped_whole_case_is_rejected ______________________

    def test_dropped_whole_case_is_rejected():
        fixed = inventory()["cases"]
>       with pytest.raises(ExportError, match="case inventory"):
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       Failed: DID NOT RAISE ExportError

tests/test_s02_candidate_a_integrated_export.py:116: Failed
_____________________ test_reordered_profiles_are_rejected _____________________

    def test_reordered_profiles_are_rejected():
        fixed = inventory()["cases"]
        changed = list(fixed)
        changed[0], changed[1] = changed[1], changed[0]
>       with pytest.raises(ExportError, match="case inventory"):
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       Failed: DID NOT RAISE ExportError

tests/test_s02_candidate_a_integrated_export.py:123: Failed
=========================== short test summary info ============================
FAILED tests/test_s02_candidate_a_integrated_export.py::test_dropped_whole_case_is_rejected
FAILED tests/test_s02_candidate_a_integrated_export.py::test_reordered_profiles_are_rejected
2 failed, 15 deselected in 0.03s
```

Both before/after closures contain121source files, now including the actual new exporter stub rather than a missing-future-source label. The original source bytes and complete runtime observations preceded the command and remain unchanged.

## Implementation and exact plan correspondence

After the original terminal RED, the structural functions, selector mapping and complete schema3 transport blocks were assembled exactly as adopted. The only assembly removal is the earlier verify_pins implementation explicitly superseded by Task3.2; the final source contains37unique top-level function/class definitions, with no duplicate obsolete definition. A fresh read-only byte comparison verifies the final exporter equals the prescribed block concatenation with that sole removal. All four test blocks (original inventory assertions, strict parser/domain tests, sharded transport controls and actual-package tests) occur unchanged in the final test source.

The exporter retains the fixed78-case/1557-event inventory, exact wrapper/global ordinal/native recipe mapping, strict typed raw carriers, required computation cardinality/order and cancellation discriminator checks. It streams raw/stored events through the admitted utility, keeps source/runtime/receipt admission separate, and creates outputs exclusively. The parser receives the required900-second wall budget and4096MiB explicit Node heap argument and retains its original argv/stdout/stderr/terminal sidecars. These are source/predicate observations, not claims that real native data has traversed them.

Supplemental tests exercise the real structural functions with synthetic data. The three parser failure modes replace only subprocess.run with an explicitly synthetic callable; original fake-produced bytes, budgets and failure classification are checked through the actual parser receipt code. They do not execute Quint and do not establish native parser memory or timeout behavior. The old omission/reorder assertions now pass against the implemented validator. Supplemental tests were first added with the adopted implementation and are honestly coverage, not additional original behavioral RED claims.

## Non-actual unit GREEN

Exact authorized command:

```bash
/home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/a4-producer-receipts/task3-unit-green/python-cache scripts/record_s02_candidate_a_integrated.py --stage task3-unit-green -- /home/charl/Moriarty/.venv/bin/python -m pytest tests/test_s02_candidate_a_integrated_export.py -q -k 'not actual' --basetemp=.superpowers/sdd/a4-producer-receipts/task3-unit-green/basetemp
```

Terminal child/recorder0;55passed/4deselected;1.557858489seconds recorder duration. Empty stderr. Full original stdout:

```text
.......................................................                  [100%]
55 passed, 4 deselected in 0.82s
```

Both commands report source_stable=true/runtime_stable=true. Each before/after source closure has121members; fresh read-only verification checked all484source-byte members. No ITF was emitted, so the original recorder artifacts maps are empty. Original nested parser test receipts and exclusive-output fixtures remain under the specified basetemp; no cleanup or reconstruction occurred.

The four mandatory real-package tests are present but unexecuted:

- test_actual_complete_sharded_corpus_matches_manifest
- test_actual_case_omission_cannot_pass_fixed_inventory
- test_actual_event_omission_cannot_pass_case_inventory
- test_actual_reordered_computation_requests_rejected

They use the canonical evidence/s02-candidate-a-completion/a4 archive directly, with no scratch fallback or skip. The scoped -k filter explicitly excludes them only for this source-unit gate. A future separately authorized full-module command must execute all four against the actual admitted package;55unit passes are not that gate.

## Frozen source and original artifact intake

Final exporter SHA25651028d697cd9be91ebfa97b5d7d6f69127ca700fd47313648cb4138877dddcd5 (35326bytes).
Final producer test SHA2563e99e7069d28ec661ac6c45f64809505bfcd10c18cd202c477545d5fbf5ed33f.

Original index: `.superpowers/sdd/a4-producer-task3-source-artifact-index.json`. It pins515regular original files and separately records13original test symlink targets, including pytest current aliases and the deliberate unsafe-path fixture. It retains all484before/after source members, source manifests, recorder/helper/runtime receipts, stdout/stderr and nested synthetic parser artifacts. It excludes only regenerated python-cache trees. Directory/symlink test metadata is not relabeled as admitted semantic source. The index does not hash itself or this report; root must bind both outer artifacts separately.

Source/report are frozen for root source/evidence review and admission. Task2 and RH001 originals remain immutable. Actual native pilot/export, complete package predicates, downstream checker acceptance and runtime resource feasibility remain open external gates, not inferred successes.
