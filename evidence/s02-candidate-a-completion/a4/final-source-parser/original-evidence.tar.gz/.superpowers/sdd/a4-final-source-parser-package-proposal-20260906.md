# Final-source parser evidence packaging proposal

Status: proposed preservation only; no archive, builder, audit code, native command or test created or run. Root must review the frozen proposal before a separate packaging dispatch. Package target: `evidence/s02-candidate-a-completion/a4/final-source-parser/`. Scope: preserve the one admitted parse and its original data/source/receipt evidence for pilot-only structural inspection. No pilot, full78 exporter, final115/native acceptance, semantic correspondence or H1 follows. The full exporter still owes its own later fresh parser calls.

## Exact original membership

Base set: all **263** relative paths in `originals` of `.superpowers/sdd/a4-final-source-parser-admission-20260906.json`, SHA256 `29a427818e9894ce6674e9f4f26dfe4527736fa6289bde6b5b3a5e6664caec71`. This map is byte-for-byte equivalent as parsed data to `originals` in the actual chunk02536f stdout embedded in `.superpowers/sdd/a4-final-source-parser-independent-intake-20260906.md`, SHA256 `c1d219a8dc772807f6b729f328eecee0998d9c4a526ad1e87add46805fbf06f4`. The source-only proposal checked this equality. Require it again at build and audit; do not use a live recursive glob to define membership.

These 263 regular files total **44,384,917 bytes**: 242 before/after source copies (121 each), both closure maps, the complete inner stage and original IR, six RH002 files, five transport files, dispatch, adopted plan and root file-backed data check. Preserve every path and byte, including empty streams. The IR is exactly 38,527,047 bytes, SHA256 `cbf57ad5a7f194ba62bf897553d3750ddba899190683ab8293cc633282886e1e`; do not reserialize, regenerate or split its contents.

Add exactly the following **26** existing regular files, deduplicated by full worktree-relative path. They close the 11 parser dispatch bindings, independent/root review, producer/shared dispatch, both runtime manifests and all twelve original version streams. Prefix `S/` below means `.superpowers/sdd/` and must be expanded in the archive/index; other paths are already worktree-relative.

| Additional original path | SHA256 |
| --- | --- |
| `S/a4-checker-task1-receipts/python-environment.json` | `cd004057c4067bf7cc536d2cec5038add88d0852c1a7de5030e402ff2204f9c4` |
| `S/a4-final-source-parser-admission-20260906.json` | `29a427818e9894ce6674e9f4f26dfe4527736fa6289bde6b5b3a5e6664caec71` |
| `S/a4-final-source-parser-independent-intake-20260906.md` | `c1d219a8dc772807f6b729f328eecee0998d9c4a526ad1e87add46805fbf06f4` |
| `S/a4-final-source-parser-plan-root-review-20260906.md` | `5c2b542db9a5660d782700039eed1a3f904afca6459cee6c957b8eef0a312fa5` |
| `S/a4-producer-dispatch.json` | `cc8ab817598c84a4d44c6464d9ce341d4ea7959461370634488c995858dc9147` |
| `S/a4-task6-resumption-20260906/fresh97/outer-tool-receipt.json` | `4783b46637cfc0ee34302ece1f15079c283187bb699c6ebf94fe5d3e0dadb723` |
| `S/a4-task6-resumption-20260906/fresh97/terminal.json` | `1ecd99090a183136fe205edfabf766f905259efabf0d7c43efd344f16626ea34` |
| `S/a4-task6-resumption-20260906/root-admission114.json` | `2b112e8273b7f2a1b12adf9cc1404dc7c3da5fb933e14a972fc12f35519aba08` |
| `S/a5-compiler-phase-diagnostic-20260906/full/terminal.json` | `831cfb143987611d83aa2f86fc3959053fc115d9fdac00411ad3859403dd9563` |
| `S/a5-compiler-phase-diagnostic-20260906/transport/full/terminal.json` | `3938090a70a53149dd1c437ee939e05a439f7e1053fcd6aea391f47015b44cc8` |
| `S/a5-factoring-receipts/dispatch.json` | `393a8aa904bcd9473670ac48934b3dca4ed611ca9b9accbfa94f15bb4798ac2f` |
| `S/a5-factoring-receipts/tool-store/manifest.json` | `fa3e9838c66480557ed6d928a2d159ebc074d05f67f15ef08ab20388d9c49e0b` |
| `S/a5-factoring-receipts/tool-store/java.stderr` | `7ccd1bd8325e9df64f66fa6c599aa31328ee31932cc12b7d8df78a8790e550d0` |
| `S/a5-factoring-receipts/tool-store/java.stdout` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `S/a5-factoring-receipts/tool-store/libc.stderr` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `S/a5-factoring-receipts/tool-store/libc.stdout` | `63b5af6d126f4c1a7dda90b9e95ff7f5562cd0b8866c73a3dca18c3736a8c286` |
| `S/a5-factoring-receipts/tool-store/node.stderr` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `S/a5-factoring-receipts/tool-store/node.stdout` | `1f2f55b6a7002be8f9992bdfa80f6a4a2b133df9201a4cbc2c35fb471256cd48` |
| `S/a5-factoring-receipts/tool-store/python.stderr` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `S/a5-factoring-receipts/tool-store/python.stdout` | `c4a684e859efa868ffdfb4967e90ffd847a0fc1f293e16ed50ea18af8e3b95f6` |
| `S/a5-factoring-receipts/tool-store/quint.stderr` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `S/a5-factoring-receipts/tool-store/quint.stdout` | `e0ccf7913110f807adecc59be43ce6fb334f82a8a7f70f70fbbba34bf1eeaaf2` |
| `S/a5-factoring-receipts/tool-store/rust.stderr` | `b04370a7d69875d970e86cd64af81c83c8e516a8040c40e876c3868cce969785` |
| `S/a5-factoring-receipts/tool-store/rust.stdout` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `evidence/s02-candidate-a-completion/a4/native-resources/runner.py` | `d8973d3541269d1be2ce524f2482e5f5b858f15f7d9117e3fe6d5cd2171d660d` |
| `scripts/run_s02_candidate_a_factoring_pilot.py` | `816c3ad79dc3a67ca9a03729af56d74188c161a7546b9c43e821c222a4bce7f2` |

Archive these **289 existing original files**, plus this frozen proposal at its original relative path, for exactly **290 regular members** in `original-evidence.tar.gz`. No directory entries or links are needed. The proposal's final hash is recorded by root review and the external index; this document has no self-referential hash. Reject missing files, duplicate names, conflicting pin declarations, symlinks, escaping/absolute names or additional members. The original independent Markdown is kept intact, including its actual invocation/response objects; any parsed representation used by the audit is derived data, never a replacement original.

Two runtime archives remain external and are not reread or copied by packaging/audit:

| External original relative path | Bytes | SHA256 |
| --- | ---: | --- |
| `.superpowers/sdd/a5-factoring-receipts/tool-store/runtime.tar.gz` | 315704660 | `f0687656d30c0d59ece8dfd027508a9228020506d29b97aea3abe7568186c31c` |
| `.superpowers/sdd/a4-checker-task1-receipts/python-environment.tar.gz` | 66716078 | `7363d106d464f976af2a0e7f1f56e3c7bed237c7a3396a60d073369add068dac` |

The proposal read their file sizes only. The independent original intake reports both archive hashes and installed-tree verification; the package audits those recorded bindings. Neither an OS image nor installed runtime bytes are included. The manifest contains all 124 original dynamic-library receipt bodies, so no synthetic separate ldd records are created. Prior A4/A5 prerequisite files close direct parser dispatch pins only; their own large evidence sets remain separately admitted external packages, not recursively duplicated here.

## Standalone standard-library audit contract

Create new `README.md`, `index.json`, `build_archive.py`, `audit.py`, and separate actual build/audit tool receipts and reports outside the original archive. The index enumerates every member's original relative path, bytes and SHA256, compressed archive hash/bytes, external runtime bindings, exact package-support pins and proof limits. It excludes its own hash and later review/transport records from self-hashing; root records those separately. The builder uses exclusive destinations and reads only the approved original set. Preserve every failed build/audit attempt under a fresh actual receipt; no overwrite or reconstructed successful output. Compression changes representation only; original file bytes remain exact.

The audit accepts a standalone package directory from any cwd. It imports only the standard library, reads archive members in memory/streams without extracting, rejects optimization before validation, and never imports/executes archived source, runs subprocesses, accesses original absolute paths, hashes installed runtime trees or requires the worktree. Absolute path strings in originals are mapped by the exact historical root prefix to archive-relative lookup keys; external runtime path strings remain recorded identifiers.

Required checks:

1. Verify the archive and support pins; exact safe 290-member set, uniqueness, regular types, declared member size and streamed SHA256, and bounded total/uncompressed reads. Derive the 263-member base independently from both original admission and parsed actual chunk02536f stdout, then require the fixed 26 additions and proposal. Bound strict metadata reads; bound raw IR acceptance at 134,217,728 bytes. Reject duplicate JSON keys, nonfinite constants and nonfinite exponent floats; require strict EOF. Do not execute Markdown command blocks.
2. Verify the exact adopted plan/review/dispatch/admission pins. Dispatch and both recorded source commits remain `08e426c7163880b9312f1f1f029a4dde9d0e7593`; producer base remains `386bf0ae10f767e051b414a7231be105cc4b0f71`; runtime bootstrap remains `900bb2051225b4a3d99bf422c3b2e5e386e3e7bc`. Preserve distinct bases and current packaging HEAD as distinct facts.
3. Both closure maps, inner before/after maps, dispatch and admission must equal the same 121-source map with no missing entries. Each of 242 archived copies must match its original source pin. Independently derive the 104-module/17-Python closure from the archived recorder declarations and archived Quint imports (standard-library AST/literal analysis and text parsing only). Require exact member coverage and the two corrected case032/lowering hashes. No current-source comparison or model execution occurs.
4. Verify exact recorded command/argv/cwd/cache/bytecode/budget bindings across plan, transport command, RH002 launch and inner receipt, including explicit pinned Node heap4096, CLI parse aggregate root and the original fresh IR output path. Require actual parser/recorder/RH002/tool exits0, stable source/runtime statements, eligible true, complete unforced cleanup, no timeout/errors/signals. RH002's authentic `inner_receipt_complete:false` is not rewritten: independently check the actual inner receipt. Its `artifacts:{}` and empty inner stdout/stderr remain original; root's separate IR pin closes the artifact gap.
5. Verify RH002 sidecars and inner hash, exact GNU-time command and all23 unique resource fields, original outer stdout recorder result, and the three separate original transport response files equal the ordered terminal response objects. Check launch session54358/chunks f81ea6 and2535e8, then actual terminal88c051/exit0. Preserve resource scope: full recorder/native-descendant wall16.09s and max RSS968996KiB; inner parse elapsed12130368479ns; outer bound900s includes setup. No runtime measurement rerun or new claim of current group absence.
6. Reconstruct the complete expected **8102** runtime pin map and four tree memberships from packaged producer/shared/Python manifests, helper binding and version streams, rejecting collisions. Require exact equality to inner before/after and root admission `runtimePins`; match shared endpoint references, actual executable pins and original version outputs. Preserve Rust's original unsupported `--version` exit1 as a probe result distinct from parser exit0. Validate all archived runtime-reference bytes, but treat the two runtime archives and installed libraries as external recorded pins. Do not claim the package reverified their bytes.
7. Independently strict-load the original raw IR, require exact hash/bytes, fields `stage,warnings,modules,table,errors`, stage `parsing`, empty warnings/errors, 99 modules, 122 unique typedef names, and the seven required declarations in their original modules. Match all admission predicates. Preserve the raw IR without reserialization; this structural schema audit neither typechecks nor proves compiler correctness.
8. Preserve and validate the original independent report's actual audit launch40b973/session21304, terminal02536f/exit0 and supplementary f5dd8e/exit0 objects. Check embedded audit stdout SHA256 `7c9bb66987de1c5bd30f0f53d23fa189bc6dbb923b90ce1a07d22897b6f058e0` and the recorded canonical response-object digest without calling that canonical encoding an unavailable wire original. Root's file-backed data check must retain actual7660c0/exit0 and the exact adopted data-check command. Root plan review is the adoption record, not a new retrospective approval.

Package audit success means consistent preserved parser evidence and recorded external bindings. It does not rerun the original independent current-source/runtime audit, recreate historical process ownership, re-admit prerequisites, discharge later exporter parser calls or accept a pilot. Independent root package review remains outside the original archive; no commit is included in this proposal.

## Preserved audit history and limits

Keep root admission's exact `rootIntakeHistory`: initial root81c702 refused the interim independent-review hash before any admission write; final c1d219a8 handoff was reviewed before corrected intake. No parser was repeated. Keep root original intake chunk references0f83eb/0ba97b/7660c0. Only7660c0 has the designated file-backed check here; do not invent files containing unavailable full original responses for the other transcript-only references or the refusal.

The original independent report also discloses metadata-display chunk9364b1/exit1 from a list/dict assumption, and preserves authentic successful comprehensive audit output separately. Do not erase or promote that display failure into a native failure. This proposal's own bounded metadata inspection initially attempted to JSON-decode the empty nonterminal launch output (chunkb9e411/exit1); the next read selected actual terminal02536f and established exact263-map equality. No original changed, no archive was built and no parser ran. This is proposal-author display history, not original parser/audit evidence.
