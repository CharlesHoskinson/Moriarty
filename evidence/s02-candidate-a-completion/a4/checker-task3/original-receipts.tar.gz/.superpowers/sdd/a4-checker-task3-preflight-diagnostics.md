# Task3 preflight diagnostics

These are disclosed recorder setup failures, not behavioral RED or reconstructed command receipts.

The original recorder listed nonexistent `candidate_a_authority_installment_lifecycle.qnt` and `candidate_a_authority_swap_lifecycle.qnt`. Actual lifecycle filenames have no `_lifecycle` suffix. The source-pin preflight stopped before subprocess launch.

- `red-import`: original tool command chunk `c1fc29`, terminal exit1, recorder line77 `assert not missing, missing`; missing list contains the two names above.
- `red-tests`: original tool command chunk `e7ff4b`, terminal exit1, identical preflight assertion. No pytest process launched.
- A following read-only `rg` lookup of those same wrong names also failed, original chunk `e7d479`, terminal exit2. `rg --files` then resolved the actual names.

Original tool outputs remain in the agent transcript. Empty original stage directories are retained; no input/terminal/stream files were fabricated in them. Original recorder bytes are preserved as `a4-checker-task3-receipts/preflight-recorder-original.py`, SHA256 `6acb219afa1881c12577f96b5e79b76a2c3504956c2d68047d0372ef40f3fd11`, and within the earlier tests-first archive.

The correction changed only the two source snapshot paths and added explicit retry stage-name support. `red-import-retry` and `red-tests-retry` retain complete original commands, source bytes, streams and terminal receipts. There was no behavioral source change between the preflight failures and retries. The prescribed wrong-ledger variant was still installed for the compiling behavioral RED.
