# A4 checker Task3 bounded execution

Root admitted Task2 at71db4f25a5b8a0ac05428daed3df298c3eafbf5b.
Read Task3 in immutable independent-replay plan
SHA2562edb50ec93c88c62d8fddf1ba9d29b893e494b1564d28fdef6dd82674fca739e
and replay-interface addendum ab7c827. Own only scripts/a4_cases.py and Task3
additions to tests/test_s02_candidate_a_integrated.py, plus ignored task-specific
recorder/receipts/report under .superpowers/sdd/a4-checker-task3-*.

Implement independently fixed program/policy/request/ordinary-route construction.
No import of producer code or its exported expected states. Exact original Python
Core/fixture decoder is the disclosed shared foundation. Preserve existing
Task1/2 source and tests. Required compiling RED: installment initial ledger
uses ledger(loop,2), while candidate retains its actual initial balances. Observe
the intended coupling assertion failure. Restore only this fault, then all tests
must pass without exclusion; both profiles run all11installment/12swap scenarios.

Reuse the exact unchanged Task1 Python environment snapshot by archive/manifest
hash, with fresh bytecode cache paths and before/after pins. Archive original
new+existing Python source/imports, recorder, plan/addendum/brief, and all frozen
common/A/lifecycle sources used in fixture derivation. Separate actual stdout,
stderr, exit, elapsed time and source bytes per command; no reconstructed RED.
Source mismatch or failed route is investigated, never bypassed using raw export
successors. Preserve every failed diagnostic separately. No Task4, other source,
main/wiki/DB/evidence/index/commit/Foreman edits. End with exact source/report
pins and terminal outcome inventory for independent root admission.
