"""Task3 immutable original-byte snapshots and per-command terminal receipts."""
import datetime
import hashlib
import importlib.metadata
import io
import json
from pathlib import Path
import subprocess
import sys
import sysconfig
import tarfile
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
PYTHON = '/home/charl/Moriarty/.venv/bin/python'
BASE = '71db4f25a5b8a0ac05428daed3df298c3eafbf5b'
SOURCES = ('scripts/a4_carrier.py', 'scripts/a4_agreement.py', 'scripts/a4_authority.py', 'scripts/a4_cases.py',
           'tests/test_s02_candidate_a_integrated.py',
           'scripts/check_s02_candidate_a_correspondence.py',
           'moriarty/core.py', 'moriarty/swap.py', 'moriarty/__init__.py',
           'pyproject.toml', 'uv.lock',
           'docs/superpowers/plans/2026-09-05-candidate-a-replay-interface-addendum.md',
           'specs/quint/s02/candidate_a_authority_installment_fixtures.qnt',
           'specs/quint/s02/candidate_a_authority_installment_lifecycle.qnt',
           'specs/quint/s02/candidate_a_authority_installment_test.qnt',
           'specs/quint/s02/candidate_a_authority_installment_harness.qnt',
           'specs/quint/s02/candidate_a_authority_swap_fixtures.qnt',
           'specs/quint/s02/candidate_a_authority_swap_lifecycle.qnt',
           'specs/quint/s02/candidate_a_authority_swap_test.qnt',
           'specs/quint/s02/candidate_a_authority_swap_harness.qnt',
           'specs/quint/s02/effects.qnt', 'specs/quint/s02/consumption.qnt',
           'specs/quint/s02/observations.qnt', 'specs/quint/s02/policies.qnt',
           'specs/quint/s02/authorization.qnt', 'specs/quint/s02/execution.qnt',
           'specs/quint/s02/candidate_a_authority_adapter.qnt',
           'specs/quint/s02/candidate_a_authority_boundary.qnt',
           'specs/quint/s02/candidate_a_types.qnt', 'specs/quint/s02/candidate_a_core.qnt',
           'specs/quint/s02/candidate_a_programs.qnt', 'specs/quint/s02/candidate_a_projection.qnt',
           'docs/superpowers/plans/2026-09-05-candidate-a-independent-replay.md',
           '.superpowers/sdd/a4-checker-task3-brief.md',
           '.superpowers/sdd/a4-checker-task3-receipts/recorder.py')
COMMANDS = {
    'tests-first': [PYTHON, '-m', 'pytest', '-q', 'tests/test_s02_candidate_a_integrated.py'],
    'red-import': [PYTHON, '-c', 'import scripts.a4_carrier, scripts.a4_agreement, scripts.a4_authority, scripts.a4_cases; print("Task3 imports succeeded")'],
    'red-syntax': [PYTHON, '-c', 'from pathlib import Path; files=("scripts/a4_carrier.py","scripts/a4_agreement.py","scripts/a4_cases.py","tests/test_s02_candidate_a_integrated.py"); [compile(Path(p).read_bytes(),p,"exec") for p in files]; print("Task3 syntax succeeded")'],
    'red-tests': [PYTHON, '-m', 'pytest', '-q', 'tests/test_s02_candidate_a_integrated.py'],
    'green-syntax': [PYTHON, '-c', 'from pathlib import Path; files=("scripts/a4_carrier.py","scripts/a4_agreement.py","scripts/a4_authority.py","scripts/a4_cases.py","tests/test_s02_candidate_a_integrated.py"); [compile(Path(p).read_bytes(),p,"exec") for p in files]; print("Task3 syntax succeeded")'],
    'green-import': [PYTHON, '-c', 'import scripts.a4_carrier, scripts.a4_agreement, scripts.a4_authority, scripts.a4_cases; print("Task3 imports succeeded")'],
    'green-tests': [PYTHON, '-m', 'pytest', '-q', 'tests/test_s02_candidate_a_integrated.py'],
}

def sha(data): return hashlib.sha256(data).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path, value):
    with path.open('x') as stream: json.dump(value, stream, indent=2, sort_keys=True); stream.write('\n')
def pin(path): return {'path': str(path), 'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size}
def archive(target, paths):
    entries=[]
    with tarfile.open(target, 'x:gz') as tar:
        for path in sorted(paths):
            raw=path.read_bytes(); name=str(path).lstrip('/')
            info=tarfile.TarInfo(name); info.size=len(raw); tar.addfile(info, io.BytesIO(raw))
            entries.append({'path':str(path),'archivePath':name,'sha256':sha(raw),'bytes':len(raw)})
    return entries

mode=sys.argv[1]
assert mode in COMMANDS
stage=OUT/mode; stage.mkdir(exist_ok=False)
ENVIRONMENT=OUT.parent/'a4-checker-task1-receipts'/'python-environment.json'
assert sha(ENVIRONMENT.read_bytes())=='cd004057c4067bf7cc536d2cec5038add88d0852c1a7de5030e402ff2204f9c4'
environment=json.loads(ENVIRONMENT.read_text())
assert sha((ENVIRONMENT.parent/'python-environment.tar.gz').read_bytes())==environment['archiveSha256']
env_before=[pin(Path(e['path'])) for e in environment['sourceBytes']]
assert all(a['sha256']==b['sha256'] for a,b in zip(env_before,environment['sourceBytes']))
present=sorted(ROOT/name for name in SOURCES if (ROOT/name).is_file())
missing=[name for name in SOURCES if not (ROOT/name).is_file()]
if not mode.startswith('tests-first'): assert not missing, missing
source_entries=archive(stage/'source.tar.gz',present)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
import os
env=os.environ.copy(); overrides={'PYTHONDONTWRITEBYTECODE':'1','PYTHONPYCACHEPREFIX':str(stage/'fresh-pycache')}
env.update(overrides)
write(stage/'input.json',{'createdAt':now(),'argv':COMMANDS[mode],'cwd':str(ROOT),'baseCommit':BASE,'sourceCommit':head,
    'environmentOverrides':overrides,'pythonEnvironmentManifestPath':str(ENVIRONMENT),'pythonEnvironmentManifestSha256':sha(ENVIRONMENT.read_bytes()),'pythonEnvironmentArchiveSha256':environment['archiveSha256'],
    'sourceArchiveSha256':sha((stage/'source.tar.gz').read_bytes()),'sourceBytes':source_entries,'absentSources':missing,
    'namespacePackagesWithoutInit':['scripts','tests'],'pythonBefore':pin(Path(PYTHON)),
    'environmentBefore':env_before})
start=time.monotonic()
with (stage/'stdout.txt').open('xb') as stdout, (stage/'stderr.txt').open('xb') as stderr:
    result=subprocess.run(COMMANDS[mode],cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
after=[pin(p) for p in present]
env_after=[pin(Path(e['path'])) for e in environment['sourceBytes']]
source_changed=[e['path'] for e,a in zip(source_entries,after) if e['sha256']!=a['sha256']]
environment_changed=[a['path'] for a,b in zip(env_before,env_after) if a!=b]
terminal={'completedAt':now(),'elapsedSeconds':time.monotonic()-start,'exitCode':result.returncode,
    'sourceAfter':after,'environmentAfter':env_after,'sourceChanged':source_changed,'environmentChanged':environment_changed,
    'pythonAfter':pin(Path(PYTHON)),'stdoutSha256':sha((stage/'stdout.txt').read_bytes()),'stderrSha256':sha((stage/'stderr.txt').read_bytes())}
write(stage/'terminal.json',terminal)
sys.stdout.buffer.write((stage/'stdout.txt').read_bytes()); sys.stderr.buffer.write((stage/'stderr.txt').read_bytes())
print(json.dumps({'stage':str(stage),'exitCode':result.returncode,'elapsedSeconds':terminal['elapsedSeconds'],
    'sourceChanged':source_changed,'environmentChanged':environment_changed}),flush=True)
raise SystemExit(result.returncode if not source_changed and not environment_changed else 2)
