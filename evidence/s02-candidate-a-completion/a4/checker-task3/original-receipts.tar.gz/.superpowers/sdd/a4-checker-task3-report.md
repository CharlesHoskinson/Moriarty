# A4 checker Task3 implementation report

Status: Task3 implementation and local verification complete; root admission pending. No Task4 implementation, commit, index update, producer changes, or Council claim.

Task base: `71db4f25a5b8a0ac05428daed3df298c3eafbf5b`. Root concurrently advanced HEAD to `900bb2051225b4a3d99bf422c3b2e5e386e3e7bc`; each receipt records actual sourceCommit separately from task base. No owned existing source changed outside the authorized test append.

## Final source pins

- `scripts/a4_cases.py`: `91f172edb127f36bebb2cb93e21be53b71f49e4cff4c1a2f13827a65c2a02669`.
- `tests/test_s02_candidate_a_integrated.py`: `86c66d094bc2baa5b2de1b4047b9d34a5e3612bb72186558fb8c5648f19a76b3`.
- Ignored recorder `a4-checker-task3-receipts/recorder.py`: `eaebebcaa79c79bacc85639342add1955c72d3eb709a7af04ece100d80a0010b`.

The new module is byte-for-byte the adopted Task3 code. The test file is the exact Task2 committed file plus one newline and the adopted Task3 test block. Existing carrier, agreement and authority modules remain byte-for-byte Task2. Plan SHA256 remains `2edb50ec93c88c62d8fddf1ba9d29b893e494b1564d28fdef6dd82674fca739e`; addendum `ab7c827` was read and is unchanged.

## Terminal inventory

Original receipts are under `.superpowers/sdd/a4-checker-task3-receipts/`. Interpreter: `/home/charl/Moriarty/.venv/bin/python`; cwd: experiment worktree. Commands use fresh pycache paths and disable bytecode writes.

| Stage | Exit | Result |
| --- | --- | --- |
| tests-first | 2 | Expected missing `scripts.a4_cases` collection error before implementation; not behavioral RED |
| red-import / red-tests | 1 each | Recorder preflight failure before Python child launch; see separate diagnostics |
| red-import-retry | 0 | All four implemented modules import successfully |
| red-tests-retry | 1 | Intended initial coupling assertion fails; both installment profile route groups also fail their guard; ten tests pass |
| green-syntax | 0 | All five final Python source/test files compile |
| green-import | 0 | All four final modules import |
| green-tests | 0 | Thirteen tests pass, no exclusions, in4.35s pytest time |

The full GREEN includes both profiles for every one of 11 installment and 12 swap ordinary scenarios: 46 complete independently evaluated routes. Parametrized tests group scenarios in loops;13 collected tests does not mean13 scenarios. Existing seven tests remain included.

RED cases SHA256: `d2c689e15120f061a5fe57790cf40500878c24563c33a12e01ef77f9025950a9`. The sole RED-to-GREEN source difference is restoring installment `initial` from ledger stage2 to stage0. The bad ledger sets initial escrow to0 while candidate retains10. Initial coupling fails at test line80; downstream installment route failures have the same cause. No test or authority gate was weakened.

Separate setup record: `.superpowers/sdd/a4-checker-task3-preflight-diagnostics.md`. It preserves the distinction between failed recorder setup and compiling behavioral failure. Original failed-stage directories and recorder bytes remain available; no raw receipt was reconstructed.

All six complete stage manifests report no source or environment changes during their commands. Final read-only audit verified source archive hashes, every archived member against input pins, both terminal stream hashes, exact adopted code, unchanged existing module bytes, and append-only test prefix. Complete behavioral/ GREEN source archives have35 members. Tests-first has32 because cases did not yet exist and the two then-mistyped lifecycle paths were absent; later archives include both actual lifecycle modules and all eight accepted lifecycle/fixture/test/harness files.

The existing 3,329-file Task1 environment archive is reused by reference, never copied. Manifest SHA256: `cd004057c4067bf7cc536d2cec5038add88d0852c1a7de5030e402ff2204f9c4`; archive SHA256: `7363d106d464f976af2a0e7f1f56e3c7bed237c7a3396a60d073369add068dac`. Per-stage pins include actual interpreter, local Python Core/import closure, common/A and accepted lifecycle source, recorder, brief, plan, and addendum.

## Fixture and route source self-review

Compared against accepted installment/swap fixture literals and lifecycle route/evidence/action definitions, plus the frozen schema1 `_fixture_nodes` foundation. No discrepancy found for the bounded ordinary inventory.

- Full programs:16 nodes are reconstructed from the disclosed frozen independent Python fixture table. Installment uses N4/N2/N0 and both Bob fill choices plus Alice recovery; swap uses N6/N5/N4 funding/disposition and settlement choice. Unused Close nodes remain binding data. No producer import or exported successor is used.
- Initial and predecessor state: complete account/choice/ledger maps preserve NoInt versus IntValue, minimum times, Alice10/Bob20 swap funding, and installment10/5/0 escrow plus Bob0/5/10 wallet balances. Initial registries, signing checks, parents and attempts are genuinely empty.
- Calls and results: actual independent Core evaluation derives all agreement successors, projections, ordered payments/effects and rollback results. Cancellation uses CancellationCallA with no Core evaluation. Supplied deadline inputs retain their refusal/rollback instead of becoming timeout successes.
- Plans and policies: parent plan retains all four ordered full planned records; nonce1 recovery uses its own plan. Parent facts include residual/cancelled status, exact slots, paid/allowance and revision. Both signing profiles use the same complete policy bodies, bounds, principal debit locations, capabilities, and exact effect lists; each route prepares and signs rather than seeding registrations.
- Installment routes: both race attempts are proposed and verified before the chosen commit; the losing verified record is explicitly rejected. Residual recovery uses FreshCancelAttempt rather than recycling CancelAttempt. Recovery is prepared/signed only after the actual ordinary cancellation path, then committed or retained as refused.
- Swap routes: each funding operation has its actual principal and nonce0 registration; the second funding follows the Time2 advance. Successful disposition signs all required nonce1 principals. Empty-funding timeout and supplied-input refusal paths propose and reject, with no fabricated financial commit.
- Actor/evidence fields and tuple ordering match source route definitions. Evidence derives from retained attempts and independently fixed full policies, not supplied export success labels.

## Scope limits

This Task3 runs ordinary routes through the Task2 common/A guards. The stricter public lifecycle-command guard dispatch, expanded negative inventory, event records, raw continuity, package admission and semantic mutants belong to later tasks. The fixed ordinary sequences satisfy the additional lifecycle ordering requirements by construction; Task3 does not yet expose or test arbitrary lifecycle-command dispatch.

The tests establish valid coupled final states and absence of pending attempts, not universal financial termination. Refused and empty-timeout outcomes retain their appropriate state and rejection records. Full event inventory terminal classification is not implemented here.

This is author self-review and focused Python runtime evidence, not independent acceptance, model checking, cryptographic proof, exported-trace verification or Council evidence. The implementation/TDD skills governed the bounded code block and real RED-to-GREEN sequence; the debugging skill kept receipt setup failures separate from behavioral evidence. Root owns admission before Task4.
