# A4 checker Task5 case-sharded supplement report

Status: source frozen for root admission. Author implementation and self-review only; not independent acceptance, Council review, native export acceptance, or full A4 completion.

## Scope and pins

Dispatch base: `fdb81c70e1ed4e6fc5bd044482918fddac5c94f6`. Each original command records its actual HEAD separately; final commands record `9d26d9ba1e5cd970ff7be599473901be0d1eb33f` after parallel root commits. No commit was made by this author.

Only these tracked paths changed:

- `scripts/check_s02_candidate_a_integrated.py`: SHA256 `ce055ac1a611f6eecc74248da64962a5c899ebbf282d41f3ca243dde51365c66`.
- `tests/test_s02_candidate_a_integrated.py`: SHA256 `f6e547364e3d7707237654bb135229a414857ac64a414aaaa2178ce06957db26`.

The original 17-test file prefix is byte-identical to dispatch base. The semantic carrier, agreement, authority, cases, inventory, frozen Core/common/A models, and admitted streaming utility and utility tests were not edited. Producer files were not edited or imported.

## Implementation and self-review

The checker now requires the complete schema3 manifest and full admission, exact 78 global wrapper entries, exact raw/case pinsets, disjoint raw/case/receipt pins, and independent ordered shard descriptors. The independent inventory remains 78 cases and 1557 events with its existing canonical hash. Schema2 and capture-only staging admissions fail.

Actual package admission hashes files in chunks, then reads submitted events and raw states in lockstep. It retains one independent expected case history and the adjacent raw-state window, with bounded lexical/codec temporaries. It checks every event's complete semantic fields, before/after states, raw-field provenance, global case index, local cursor/index/sequence, first unsigned state, adjacency, and absence of hidden resets. Both documents must exhaust through metadata after their arrays and strict EOF. Unknown metadata keys fail before retention. Buffered `compare_case` and `bind_event` remain small-test adapters, not the package implementation.

The complete source closure includes all 78 wrappers, their transitive imports, the static aggregate wrapper typecheck root, existing test roots, and the admitted lexical utility/test. Frozen pins and actual imported Python origins remain checked. Producer confirmed the new lowering module is transitive and the separately runtime-pinned recorder helper is not a semantic Python source. Focused receipts exclude those unused moving producer modules; final package admission does not waive any producer source pin.

The shared streaming utility supplies lexical transport only. Producer and checker semantic rules remain independent. `ResourceLimit` receives a resource failure classification and is not a semantic mutant kill.

## Original command evidence

Receipts: `.superpowers/sdd/a4-checker-sharded-receipts/`. Every stage contains original input, source archive, stdout, stderr, and terminal receipt. Each archive has 42 source members. All 10 stages had empty source/runtime drift lists.

| Stage | Exit | Result |
|---|---:|---|
| tests-first | 2 | New test collection failed because bounded helper did not yet exist. Not behavioral RED. |
| red-import | 0 | Mutated implementation imported successfully. |
| red-tests | 1 | Changed exported profile bound to unchanged raw profile without rejection when the exact raw-field equality guard was omitted. Genuine compiling behavioral RED. |
| green-syntax | 0 | Initial corrected source compiled. |
| green-import | 0 | Initial corrected source imported. |
| direct-help-green | 0 | Direct CLI help worked with empty PYTHONPATH. |
| green-tests | 1 | 76 passed, one suffix fixture failed at earlier provenance linkage. Original failure retained. |
| metadata-red | 1 | Both new unknown-metadata tests failed to raise before yielding array items. Separate genuine behavioral RED. |
| final-syntax | 0 | Final corrected source compiled. |
| final-tests | 0 | 79 passed in 64.97 seconds: 37 checker tests plus 42 utility tests. |

The first behavioral RED correction restores only the omitted raw-field equality guard. Subsequent self-review added an independent test-first metadata-key rejection: previously arbitrary unknown fields could be accumulated until final metadata validation. The final implementation rejects unknown keys immediately.

The failed raw-suffix fixture initially updated the raw file hash but not the submitted events' input hash references. This correctly caused provenance rejection before EOF parsing. The fixture now rebinds those temporary event references to the changed raw hash, so the test reaches and detects the intended trailing-data failure. No checker equality was weakened. The complete failed run remains in its original stage.

New tests cover both signing profiles with small file-backed valid cases, buffered/bounded agreement, global/local indices, booleans in integer positions, raw metadata/status/variable order, sequence mismatch, missing/extra events and states, descriptor changes, initial-before mutation, suffix parsing/EOF, early unknown metadata, and closed schema/pin/path inventories. These synthetic files are not native generator evidence or actual package admission.

## Receipt audit and runtime reuse

Author audit checked all 10 source archive hashes and all 42 members per archive against recorded pins, original stdout/stderr hashes, process-start parent `-B`/`-X` arguments, final current source bytes, and all 3329 runtime files. Audit completed with exit 0. Root must independently admit these bytes and receipts.

Shared Task1 environment was referenced, not copied:

- Manifest `.superpowers/sdd/a4-checker-task1-receipts/python-environment.json`, SHA256 `cd004057c4067bf7cc536d2cec5038add88d0852c1a7de5030e402ff2204f9c4`.
- Runtime archive SHA256 `7363d106d464f976af2a0e7f1f56e3c7bed237c7a3396a60d073369add068dac`.
- Parent and child process-start cache settings are recorded. The environment archive covers the interpreter and Python standard/site-package files, not operating-system libraries.

## Remaining gates

No actual 78-shard package was invoked. Native pilot feasibility, full native exports, root receipt admission, and Task6's complete semantic/locator/package mutant families remain open. The focused manifest test exercises schema/pin shape only and does not claim full package acceptance. Symbolic evidence/signature premises remain; this is not model checking or cryptographic verification. Producer launches remain paused until root releases the window. No Task6 work, main/wiki/DB changes, or commit was performed.
