# A4 checker Task5 case-sharded supplement

Root admitted strict streaming utility42tests and original short-write RED.
Implement checker Task5 transport supplement specified by adopted5829639 and
original checker plan d4f6196 plus1557/initializer addendum ab7c827. The complete
stream utility is independently admitted; do not change its source/tests.
Record actual dispatch HEAD in fresh receipts, separately from historical bases.

Owned paths: scripts/check_s02_candidate_a_integrated.py and focused additions
to tests/test_s02_candidate_a_integrated.py. Additional checker-only modules or
test files require explicit source-closure list before use. No producer/helper,
frozen common/A, a4_carrier/agreement/authority/cases/inventory edits. Reader and
writer/hash utilities may be shared only as disclosed lexical transport.

Read full5829639 transport contract before editing. Implement schema3 manifest/
fulladmission with exact78globalentries, raw andcase pinsets, disjointreceipts,
independent descriptors/eventcounts and unchangedinventoryhash. Preserve complete
frozen source/Core/import-origin checks. Include all78wrappers and the new static
aggregate test root in closed Quint source discovery, and admittedstreamutility/
test in Python source pins. Coordinate final required source names with producer.
No missing producer source/pin may pass actual package admission.

Implement bounded check_package(manifest_path,admission_path,source_root,
input_root,inventory_path); CLI --cases points to manifest. Hash in chunks,
iterate raw states and submitted events in lockstep, keep previous/current window
and only one independent casehistory. Validate metadata/fieldsets even after
arrays and demand EOF/end for both; no list() ofactualpackageeventstreams.
Preserve exact scalar/carrier/semantic comparisons; factor compare_event from
existing compare_case without weakening it. Preserve old focused bind_event API
through an adapter to a shared bounded raw-window binding helper if useful.
Firstevent must bind before=after to actual unsigned expectedstate. Allother
localindices/rawcaseIndex(globalordinal)/cursor/sequence/guards/computations/full
authoritystates and terminalstatus must match. Reject hiddenreset/omittedextra
states/cases, schema2 or staging-only admission. Imported utility origin is pinned.

Test-first focused behavioral control: omit raw-window latestfield equality,
retain importable RED that binds a changed profile to unchangedraw; restoreonly
the guard and require all prior17checks plus new boundedstream/metadata/count/
schema/ordinal controls and utility42tests. Add small validfile-backed case
controls with matching buffered+bounded judgments, suffixfailure/EOF/index/global
ordinal errors. Synthetic controls remain explicitly not actualpackage acceptance.
Never count ResourceLimit, parserfailure or filehash failure as semanticmutantkill.
Actualpackage and full27semantic/5locator/7packagecontrols remain Task6 later.

Producer currently has one scaffoldtypecheck live; WAIT for root's explicit
editwindow release before touching existing checker/testfiles. You may prepare
implementation patch in unique ignored handoff text meanwhile. Duringeditwindow,
producer maywrite its ownfiles but launches no recordedcommand. Focusedchecker
receipts must exclude unusedmoving producer files while retaining every actual
import/fixture/plan/brief/recorder/runtime byte. Finalpackagepins remaincomplete.
Use process-start -B/-X and record parentargv. Freeze/report once localtests pass;
root admits exactsource/receipts before producer resumes recordedcommands.

No actualpackage invocation, commits, main/wiki/DB, Council or Foreman action.
Report .superpowers/sdd/a4-checker-sharded-report.md. FullA4 is stillopen.
