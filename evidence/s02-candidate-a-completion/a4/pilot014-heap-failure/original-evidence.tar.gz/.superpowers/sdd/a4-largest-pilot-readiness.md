# A4 largest-native-case pilot readiness

Read-only repository observation at HEAD `9ccbf0ed571e4055bc05962e5681fdf2fa75ad96`.
No native execution, aggregate parse, model edit or package acceptance occurred.
Root must first admit the full 114-instance Task6 synthetic gate, freeze the
complete A4 source closure, and explicitly dispatch this pilot. Task2 factoring
admission is not a substitute. This note introduces no new harness.

## Exact largest rows and source anchors

The adopted transport table and current producer inventory agree:

| Global ordinal | Exact case_id | Events / max-steps | Prior compact estimate |
| --- | --- | --- | --- |
| 014 | installment/recover-r1-timeout100/ordinary/SignAfterResolve | 28 / 27 | 153736575 bytes |
| 044 | swap/funded2-timeout100/ordinary/SignAfterResolve | 27 / 26 | 34024584 bytes |

These are the largest estimated complete cases per lifecycle, not measured
native sizes. Original estimates excluded native bigint/Rust-envelope overhead.
The Node string cap remains 536870888 characters; no heap increase fixes it.

Controlling locators: transport5829639 section1.6 and native_command recipe;
NW4465863 corrects the old variable-order assumption; RH002 plan3a7d32d requires
the measured invocation and all-path owned-group cleanup. Admitted runner commit
`1df388ac422188341db0ab07d5369406b915b742`; exporter commit
`9a263d74f1fe687abbd29ab2b5d908740fcfc6be`.

Current SHA256 pins (recheck at dispatch):

```text
scripts/record_s02_candidate_a_integrated.py dc30b764e2603dfe3c39ef6e2063a7082d116dc9d3eb9a012072f468beb8f8e9
evidence/s02-candidate-a-completion/a4/native-resources/runner.py d8973d3541269d1be2ce524f2482e5f5b858f15f7d9117e3fe6d5cd2171d660d
scripts/export_s02_candidate_a_integrated.py 51028d697cd9be91ebfa97b5d7d6f69127ca700fd47313648cb4138877dddcd5
specs/quint/s02/candidate_a_integrated_case_014.qnt 1729321dd658e923f29ed2bbcfc254ce756f3ea646c40d703b5bd91d1f4bf879
specs/quint/s02/candidate_a_integrated_case_044.qnt 6576d9dda701c40555ce914c7f0065b4486476fe1084180cb3de6c4091274685
scripts/check_s02_candidate_a_integrated.py b46af0796b9a6e868cfdbdde67b162ebc98d006daf9a07345d43c70290ff3bfd
tests/test_s02_candidate_a_integrated.py b84ec39090328490f54f480da094852a0f27f600ff74f0c7931b2d65651c5db2
```

Actual source closure currently has 121 files: recursive imports of all 78
wrappers, aggregate/template, integrated test, both lifecycle tests, and the
17 explicit Python files. The recorder and exporter root lists agree. Do not
replace original Candidate A imports with the factored verification modules.
Keep the admitted all-78 native aggregate typecheck/generated-body evidence.
Record a new pilot authorization/base separately from the recorder's immutable
producer beforeDispatchCommit386bf0a; do not rewrite its original dispatch.

## Measured commands, specified only

Cwd is `/home/charl/Moriarty/.worktrees/s01-audit-start`. Run separately, to
terminal, only after root dispatch. The proposed outer destinations below must
be absent; `.superpowers/sdd` must exist. Inner stage014/044 destinations were
absent at inspection. The outer receipt directory is separate from the inner
receipt, as required by the admitted path refinement.

```sh
/home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/a4-largest-native-pilot-014-parent-cache evidence/s02-candidate-a-completion/a4/native-resources/runner.py --receipt-dir .superpowers/sdd/a4-largest-native-pilot-014 --inner-receipt .superpowers/sdd/a4-producer-receipts/case-014-export/receipt.json --wall-seconds 900 -- /home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/a4-producer-receipts/case-014-export/python-cache scripts/record_s02_candidate_a_integrated.py --stage case-014-export -- quint run specs/quint/s02/candidate_a_integrated_case_014.qnt --backend=rust --seed=42 --max-samples=1 --n-traces=1 --max-steps=27 --invariants noDiagnosticA4 sourceInvariantA4 --witnesses completeA4 --out-itf .superpowers/sdd/a4-producer-receipts/case-014-export/case-014.itf.json
/home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/a4-largest-native-pilot-044-parent-cache evidence/s02-candidate-a-completion/a4/native-resources/runner.py --receipt-dir .superpowers/sdd/a4-largest-native-pilot-044 --inner-receipt .superpowers/sdd/a4-producer-receipts/case-044-export/receipt.json --wall-seconds 900 -- /home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/a4-producer-receipts/case-044-export/python-cache scripts/record_s02_candidate_a_integrated.py --stage case-044-export -- quint run specs/quint/s02/candidate_a_integrated_case_044.qnt --backend=rust --seed=42 --max-samples=1 --n-traces=1 --max-steps=26 --invariants noDiagnosticA4 sourceInvariantA4 --witnesses completeA4 --out-itf .superpowers/sdd/a4-producer-receipts/case-044-export/case-044.itf.json
```

The inner `quint run` argv is exactly exporter.native_command(row), including
canonical output names. The recorder resolves pinned Node/Quint paths. The outer
runner executes `/usr/bin/time -v -o <outer>/resources.txt` plus the unchanged
recorder argv, in its own process group. Wall900 covers the entire recorder,
runtime checks, compilation/execution and output retention, not only Rust.
No extra Node heap override is introduced. GNU maximum RSS is invocation scope
in KiB, not simultaneous Node+Rust sum, evaluator-only RSS, or a hard RSS cap.

## Mandatory original intake

- Outer originals: runner.py, launch.json, stdout.bin, stderr.bin, resources.txt,
  terminal.json; exact parent/child/GNU-time argv and source/interpreter/time
  before/after hashes. Require exit0, eligible=true, stable pins, resource
  completeness, positive RSS, exact 23 fields/command binding, no forced cleanup,
  no lingering group, no timeout/error. Record actual wall/RSS/raw file bytes.
- Inner originals: receipt.json, stdout.bin, stderr.bin, runtime-helper.py,
  both full source trees and closure.json files, exact raw ITF. Require both
  exit codes0, source/runtime stability, no missing source entries, equality of
  full before/after/root-admitted source map, unchanged admitted tool identities,
  and artifact map exactly `{case-014.itf.json:hash}` or `{case-044.itf.json:hash}`.
  Root externally pins all receipt files; the outer runner alone does not
  certify the inner receipt. Preserve the admitted shared runtime/Python archive
  references and original helper/dispatch bindings, not a new environment.
- Native terminal output: both invariants hold and completeA4 witnessed in the
  single requested trace. Retain failures verbatim, including incomplete output.
- Strict full raw ITF: exact vars `[authorityState,caseIndex,cursor,latestEvent]`;
  exact wrapper metadata source and selected module; metadata status ok; source
  format fields/types; exactly 28/27 states and strict EOF. caseIndex remains
  14/44; cursor and event sequence equal local indices0..27/0..26. First event is
  genuine unsigned case-start; final is case-end; every intermediate selector,
  raw authority record and computation remains present. No diagnostic accepted.
- Use the actual admitted aggregate parse/type IR and original parser receipts
  for full A4Event/AAuthorityExecution raw-carrier type/domain checks. The
  exporter parser API retains unique argv/stdout/stderr/terminal files and has
  a separate900s/4096MiB-Node parse budget. A retained matching final-source IR
  may be inspected; do not claim parsing succeeded from prior source typecheck
  alone. Root must explicitly include any fresh parse invocation in dispatch.

## Real gate boundaries and final capture admission

No current code/contract mismatch was found in this read-only check. The real
open prerequisites are Task6 terminal admission, full source freeze and explicit
native dispatch. Runtime feasibility and actual raw carrier validation remain
unperformed. If timeout, string cap, OOM, parser failure or incomplete trace occurs,
stop and retain originals; do not increase limits, omit fields, subdivide a case,
reuse a directory, or substitute expected checker states without reviewed action.

The exporter intentionally cannot admit a two-case package: export_shards first
requires all78 receipts/raw files. Pilot-only inspection must therefore remain
root-scoped original receipt/raw/type inspection, not a new allow-subset mode or
package-acceptance claim. This is an intake sequencing boundary, not grounds to
weaken the exporter. Existing parser_types/raw_events may support that scoped
inspection without creating another harness; source/type checks are structural,
not independent semantic correspondence.

Once the eventual full78 runs all succeed under the same final source/tool
closure, root copies raw bytes without reserialization to `raw/case-NNN.itf.json`
and preserves inner receipts under `case-NNN-export/`, with outer originals at
separate root-admitted receipt-relative paths. Pilot014/044 may supply their two
rows only if root admits them as those exact unchanged final runs. If the source
changes or either pilot fails, canonical stages are consumed evidence; any retry
needs an explicit fresh staging decision, never overwrite or implicit reuse.

Root capture admission must bind schema_version3, transport case-sharded-itf-v1,
the unchanged schema2 inventory digest (78 cases/1557 events), exact121 source
pins, all78 raw input hashes, full externally audited receipt pins, and all78
case-id-to-entry mappings. It deliberately omits case_pins. Source snapshot and
input_root must hold those exact files, including receipt-relative paths.

Only then run stage-cases with a unique required --parser-receipts directory;
root reviews/pins all78 incrementally written case files. Full admission adds
their exact case_pins. seal-manifest independently rechecks raw/event linkage,
EOF/counts and unchanged admission; independent checker/package gates and all
mandatory actual-package tests follow. No successful two-case pilot closes any
of those final gates or proves arbitrary interleavings/model-checking success.
