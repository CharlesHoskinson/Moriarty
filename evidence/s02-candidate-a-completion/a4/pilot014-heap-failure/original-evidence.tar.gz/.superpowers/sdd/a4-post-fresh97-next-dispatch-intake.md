# A4 intake after fresh97: next native dispatch prerequisites

Source-only observation at HEAD `4c36aba2fd2fc668aacdd76aa39189fe059d70b5`.
This checklist neither adopts a new plan nor authorizes native execution. No
tests, native commands, helper imports, or large-artifact hashes were run for
this intake. Frozen sources, runtime files, receipts and dispatches were not
modified. At inspection, `fresh97/terminal.json` was absent; live progress is not
a terminal success or admission of the amended preliminary gate.

## Controlling evidence and supersession

- `docs/superpowers/plans/2026-09-05-candidate-a-case-sharded-transport.md`
  and its admitted review under `evidence/s02-candidate-a-completion/a4/planning/`
  replace the original integrated-producer whole-loop export recipe with 78
  independently initialized complete cases. The inventory remains 78 cases and
  1557 events. The old installment/swap whole-loop exports with 637/918 steps
  are superseded; they are not the next native commands.
- `docs/superpowers/plans/2026-09-05-candidate-a-native-resource-runner.md`
  and `a4/native-resources/review.md` admit the resource runner's source and 41
  local controls. They do not admit a native trace. Runner implementation commit:
  `1df388ac422188341db0ab07d5369406b915b742`.
- `docs/superpowers/plans/2026-09-05-candidate-a-sharded-exporter.md`
  and `a4/exporter-source/review.md` admit exporter source and 55 controls;
  four actual-package tests remain deferred. Exporter implementation commit:
  `9a263d74f1fe687abbd29ab2b5d908740fcfc6be`.
- `.superpowers/sdd/a4-largest-pilot-readiness.md` supplies the exact two
  measured pilot commands and receipt/raw-data gates. This intake retains them.
- `a4/pre-native-recovery-admission/README.md`, the original
  `.superpowers/sdd/a4-task6-resumption-20260906/root-admission17.json`, and
  `root-dispatch-fresh97.json` establish the reviewed partition: 17 admitted
  original child controls plus 97 exact fresh nodes must cover 114 preliminary
  controls. The original interrupted parent's exit remains unknown. The actual
  package node and final 115-instance run remain owed.

In evidence locators above, `a4/` means
`evidence/s02-candidate-a-completion/a4/`; abbreviated fresh97 paths are below
`.superpowers/sdd/a4-task6-resumption-20260906/`.

## Next native command, specified only

After root admits the completed fresh97 originals and exact 114-node aggregate,
freezes the complete A4 source/runtime closure, and separately authorizes the
pilot, the first native stage is `case-014-export`: the largest estimated
installment case, `installment/recover-r1-timeout100/ordinary/SignAfterResolve`.
It has 28 events and 27 steps. Its prior compact size estimate, 153736575 bytes,
is not a measured native output size and excludes native envelope overhead.

Cwd: `/home/charl/Moriarty/.worktrees/s01-audit-start`.

```sh
/home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/a4-largest-native-pilot-014-parent-cache evidence/s02-candidate-a-completion/a4/native-resources/runner.py --receipt-dir .superpowers/sdd/a4-largest-native-pilot-014 --inner-receipt .superpowers/sdd/a4-producer-receipts/case-014-export/receipt.json --wall-seconds 900 -- /home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/a4-producer-receipts/case-014-export/python-cache scripts/record_s02_candidate_a_integrated.py --stage case-014-export -- quint run specs/quint/s02/candidate_a_integrated_case_014.qnt --backend=rust --seed=42 --max-samples=1 --n-traces=1 --max-steps=27 --invariants noDiagnosticA4 sourceInvariantA4 --witnesses completeA4 --out-itf .superpowers/sdd/a4-producer-receipts/case-014-export/case-014.itf.json
```

Hold this one command to terminal and preserve the actual outer tool result.
The second separately gated command is the exact `case-044-export` command in
the readiness note: `swap/funded2-timeout100/ordinary/SignAfterResolve`, 27 events,
26 steps, prior compact estimate 34024584 bytes. Do not start a 78-run loop from
this checklist. Both outer pilot directories and both canonical inner stage
directories were absent at inspection; root must check them and fresh parent
cache destinations again before dispatch.

The runner's 900-second wall budget covers the entire recorder invocation,
including checks, native execution and retention. It adds no Node heap override.
The exporter's separate parser budget is 900 seconds with a 4096 MiB Node heap;
that is not a native pilot RSS cap. Native wall time, RSS and output bytes remain
unmeasured. Stop on failure and retain originals; no implicit retry, overwrite,
heap increase, partial-case subdivision or expected-state substitution is
authorized.

## Immutable helper interfaces

| Existing source | Interface and binding to retain |
| --- | --- |
| `a4/native-resources/runner.py` | `capture(argv, receipt_dir, inner_receipt, *, wall_seconds=900, cwd=None, ...)`; CLI requires `--receipt-dir`, `--inner-receipt`, then unchanged recorder argv after `--`. Captures GNU time, original streams, launch/terminal and process-group cleanup. `eligible=true` requires complete bound resource evidence and stable successful execution; `inner_receipt_complete` remains false. |
| `scripts/record_s02_candidate_a_integrated.py` | `--stage case-NNN-export --` followed by exact `native_command(row)` argv. Preserve its original dispatch, shared runtime/helper references, before/after source snapshots, receipt schema and bounded streaming artifact hashing. It resolves pinned Node/Quint paths. |
| `scripts/export_s02_candidate_a_integrated.py` | `required_sources`, `native_command`, `validate_receipt`, `parser_types`, `admission`, `export_shards`; all 78 inputs/receipts are required before export. CLI requires `--mode stage-cases\|seal-manifest`, `--input-root`, `--source-root`, `--inventory`, `--admission`, `--output`, and unique `--parser-receipts`. Older recipe examples that omit the last required flag are incomplete for the admitted implementation. |

Small source-file SHA256 values rechecked during this intake:

```text
scripts/record_s02_candidate_a_integrated.py dc30b764e2603dfe3c39ef6e2063a7082d116dc9d3eb9a012072f468beb8f8e9
evidence/s02-candidate-a-completion/a4/native-resources/runner.py d8973d3541269d1be2ce524f2482e5f5b858f15f7d9117e3fe6d5cd2171d660d
scripts/export_s02_candidate_a_integrated.py 51028d697cd9be91ebfa97b5d7d6f69127ca700fd47313648cb4138877dddcd5
scripts/check_s02_candidate_a_integrated.py b46af0796b9a6e868cfdbdde67b162ebc98d006daf9a07345d43c70290ff3bfd
tests/test_s02_candidate_a_integrated.py b84ec39090328490f54f480da094852a0f27f600ff74f0c7931b2d65651c5db2
```

These five hashes are not a new complete source or runtime admission. The
readiness note identifies 121 required source files: the recursive imports of
all 78 wrappers and aggregate/template/test roots plus 17 explicit Python
sources. Root must bind the complete map. Keep original Candidate A import
routes and the admitted aggregate typecheck/generated-body evidence.
Record the new actual execution base separately from the immutable producer
`beforeDispatchCommit` `386bf0ae10f767e051b414a7231be105cc4b0f71`.

## Concrete remaining root admissions

1. Admit actual fresh97 terminal, process, JUnit, streams and outer tool records,
   source/runtime/support and retained-artifact bindings, and exact collection
   and node identities. Then record that retained17 plus fresh97 are precisely
   the 114 required controls, with no overlap, omission or credit for the partial
   eighteenth original child. The fresh97 dispatch alone does not establish this.
2. Freeze the complete 121-file source map and existing admitted runtime/tool
   identities for a separate native dispatch, check unused destinations, and
   bind the current actual base without rewriting the original producer dispatch.
3. After each pilot, independently admit outer resource originals and inner
   producer originals. Require authentic outer success, resource completeness,
   positive RSS, exact 23-field GNU-time/command binding, stable pins and absent
   owned process group; independently require child and recorder exits zero,
   exact before/after/root source map, stable runtime/tool identities, no missing
   source entries and the exact single raw-artifact map. Preserve external
   runtime archive references without copying or changing that runtime.
4. Inspect the whole raw trace against the admitted actual parser IR: vars
   `[authorityState,caseIndex,cursor,latestEvent]`, wrapper identity/status,
   exact 28/27 states, fixed case index 14/44, sequential local cursor, genuine
   unsigned case-start, final case-end, all intermediate records and strict EOF.
   Require both named invariants and `completeA4` in the native output. A source
   typecheck is not an actual parse receipt. Root must identify a matching
   admitted parse IR or explicitly dispatch a fresh parser call with original
   receipts before claiming full carrier/type validation.
5. Admit pilot feasibility and raw/type evidence before the remaining native
   shards. The exporter has no two-case acceptance mode; do not add one or call
   its full-package path on a pilot subset. Successful unchanged canonical pilot
   stages may supply their two eventual final rows only after root admission.
6. After all 78 native runs, root must preserve raw bytes without reserialization
   under `raw/case-NNN.itf.json`, all inner receipts and separate outer resource
   receipts, and supply schema-3 `case-sharded-itf-v1` capture admission binding
   the unchanged schema-2 inventory, all inputs, full audited receipt pins,
   exact source pins and entries. This admission deliberately lacks `case_pins`.
7. Only then may `stage-cases` produce all 78 cases with its own parser receipts;
   root must admit those exact case bytes, add `case_pins`, and dispatch
   `seal-manifest` with fresh parser receipts. Independent checker, all four
   deferred actual-package exporter tests, actual package admission, final
   115-instance gate, direct native CLI, shared regressions and remaining
   independent review are still required by their controlling plans.

At inspection neither pilot directory, neither canonical pilot stage,
`a4/capture-admission.json`, `a4/admission.json`, nor `a4/cases.json` existed.
Fresh97 success would discharge only its fresh-control obligation; the remaining
root admissions above do not follow from it automatically. No A4 completion,
arbitrary-interleaving verification, A5 phase result or H1 conclusion is claimed.
