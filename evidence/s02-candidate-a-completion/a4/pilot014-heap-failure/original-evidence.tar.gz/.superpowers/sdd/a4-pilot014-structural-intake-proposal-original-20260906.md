# Pilot014 structural intake: source-only proposal

Status: proposed command for independent root review, not executed. The earlier reviewed native pilot recipe remains unchanged and is not dispatched here. No parser, native process, test, helper import or data-intake implementation was executed while preparing this proposal.

Source facts: `export_s02_candidate_a_integrated.py:352–366` creates each genuine row from the complete inventory and defines its exact native command; `:466–528` defines `raw_events`; `:596–601` initializes one empty `initial_hashes` dictionary and passes it through the full export. The current exporter pin remains `51028d697cd9be91ebfa97b5d7d6f69127ca700fd47313648cb4138877dddcd5`. The literal wrapper `candidate_a_integrated_case_014.qnt:22–31` selects installment case14, index14 and the actual `initialA4`/`startA4` initializer. Its pin remains `1729321dd658e923f29ed2bbcfc254ce756f3ea646c40d703b5bd91d1f4bf879`.

Use `row = shards()[14]` unchanged, then require the exact row below. Do not handcraft a shortened inventory or change its entry/input/case-path fields. The actual original raw path differs from its canonical future package path; both are named explicitly in the resulting candidate record.

`initial_hashes = {}` is the existing interface's initial value. On the genuine case-start event, `raw_events` computes `digest(canonical(after))` from that raw authority state and adds `initial_hashes['installment']`. Preserve that observed digest after full exhaustion. Do not seed it from checker states, a hypothetical baseline or a hash invented before native execution. **For this one-case intake, the initial-hash equality is self-seeded and supplies no independent canonical-initialization comparison across cases.** Source binding and the actual native initializer supply separate provenance. The full exporter retains its own dictionary across all rows, where later same-lifecycle states are compared; this proposal does not replace that obligation. Pilot044 is a different lifecycle and cannot independently establish the installment baseline either.

Preconditions, checked by root before executing the proposed data command:

- Admit the newly captured final-source parser IR with its original inner/RH002/outer receipts, full121 source/runtime binding and strict128MiB/122-type/seven-name predicates under `docs/superpowers/plans/2026-09-06-candidate-a-final-source-parser-capture.md`.
- Independently admit pilot014's native capture eligibility: original inner/RH002/tool exits0, no timeout/forced or unresolved group, matching final121 source/runtime/tool closure, the exact reviewed native command, `noDiagnosticA4` and `sourceInvariantA4` holding, and `completeA4` witnessed. Preserve original raw ITF and all actual receipts.
- Compare the exact original IR path/bytes/hash below to the **actual completed root parser admission**. Its JSON layout is not assumed by this proposal. The command records that admission's hash, but does not treat file existence as an automated substitute for this external linkage check.
- Require source and raw-file ownership stable throughout intake. Preserve this data command's actual stdout/stderr and tool terminal in fresh root-owned intake receipts. A raised error or incomplete tool terminal is a failed/incomplete candidate, with all originals retained.

Exact proposed command, from `/home/charl/Moriarty/.worktrees/s01-audit-start`, after those prerequisites and separate root review:

```sh
PYTHONOPTIMIZE=0 /home/charl/Moriarty/.venv/bin/python -B - <<'PY'
from pathlib import Path
import hashlib, json, sys
root = Path('/home/charl/Moriarty/.worktrees/s01-audit-start')
if sys.flags.optimize != 0 or not sys.dont_write_bytecode:
    raise SystemExit('Require optimization zero and -B')
exporter = root / 'scripts/export_s02_candidate_a_integrated.py'
if hashlib.sha256(exporter.read_bytes()).hexdigest() != '51028d697cd9be91ebfa97b5d7d6f69127ca700fd47313648cb4138877dddcd5':
    raise SystemExit('Exporter source changed')
from scripts.export_s02_candidate_a_integrated import (
    bounded_load, fields, Types, PARSER_LIMIT, file_digest, require,
    required_sources, verify_pins, shards, validate_receipt, raw_events,
)
producer = root / '.superpowers/sdd/a4-producer-receipts'
parser = producer / 'task6-final-source-aggregate-parse-20260906'
pilot = producer / 'case-014-export'
raw = pilot / 'case-014.itf.json'
ir = parser / 'aggregate-ir.json'
dispatch = root / '.superpowers/sdd/a4-final-source-parser-dispatch-20260906.json'
parser_admission = root / '.superpowers/sdd/a4-final-source-parser-admission-20260906.json'
outer_terminal = root / '.superpowers/sdd/a4-largest-native-pilot-014/terminal.json'
inputs = [exporter, dispatch, parser_admission, parser / 'receipt.json',
          pilot / 'receipt.json', outer_terminal, ir, raw]
require(all(p.is_file() and not p.is_symlink() for p in inputs), 'original input/admission files required')
before = {str(p): file_digest(p) for p in inputs}
freeze = bounded_load(dispatch)
source_pins = freeze['sources']
require(len(source_pins) == 121 and set(source_pins) == required_sources(root), 'complete final source closure')
verify_pins(root, source_pins)
parser_receipt = bounded_load(parser / 'receipt.json', 64 * 1024 * 1024)
require(parser_receipt['exit_code'] == parser_receipt['recorder_exit_code'] == 0 and
        parser_receipt['source_stable'] and parser_receipt['runtime_stable'], 'admitted parser terminal')
require(parser_receipt['sources_before'] == parser_receipt['sources_after'] == source_pins and
        parser_receipt['not_yet_created_before'] == parser_receipt['not_yet_created_after'] == [], 'parser final source binding')
row = shards()[14]
require(row == {
    'case_id': 'installment/recover-r1-timeout100/ordinary/SignAfterResolve',
    'lifecycle': 'installment', 'profile': 'SignAfterResolve',
    'scenario': 'recover-r1-timeout100', 'control': 'ordinary', 'event_count': 28,
    'global_index': 14, 'entry': 'specs/quint/s02/candidate_a_integrated_case_014.qnt',
    'input_path': 'raw/case-014.itf.json', 'case_path': 'cases/case-014.json',
}, 'genuine complete-inventory row014 mapping')
receipt_name = 'case-014-export/receipt.json'
tools = validate_receipt(producer, row, before[str(raw)], parser_receipt['tools']['quint']['path'],
                         source_pins, {receipt_name: before[str(pilot / 'receipt.json')]})
require(all(tools[k][field] == parser_receipt['tools'][k][field]
            for k in ('node', 'quint') for field in ('path', 'sha256')), 'parser/pilot tool identity')
outer = bounded_load(outer_terminal)
require(outer['eligible'] is True and outer['actual_exit'] == outer['return_code'] == 0 and
        outer['cleanup']['complete'] and not outer['cleanup']['forced'] and
        not outer['cleanup']['errors'] and not outer['timed_out'] and
        outer['inner_receipt_sha256'] == before[str(pilot / 'receipt.json')], 'native outer receipt binding')
parsed = bounded_load(ir, PARSER_LIMIT)
fields(parsed, ('stage', 'warnings', 'modules', 'table', 'errors'), 'parser IR')
require(parsed['stage'] == 'parsing' and parsed['warnings'] == [] and parsed['errors'] == [], 'clean parser IR')
types = Types(parsed)
require(len(types.types) == 122 and {'A4Event', 'AAuthorityExecution', 'A4Arguments', 'A4Command',
        'A4Computation', 'AProgram', 'AState'} <= set(types.types), 'admitted typedef inventory')
initial_hashes = {}
count, first_kind, last_kind = 0, None, None
for event in raw_events(raw, row, before[str(raw)], types, initial_hashes):
    if count == 0: first_kind = event['kind']
    last_kind = event['kind']
    count += 1
require(count == row['event_count'] == 28 and first_kind == 'case-start' and last_kind == 'case-end',
        'complete pilot014 structural event sequence')
require(set(initial_hashes) == {'installment'}, 'observed lifecycle baseline key')
verify_pins(root, source_pins)
require({str(p): file_digest(p) for p in inputs} == before, 'original input/admission bytes changed during intake')
print(json.dumps({'scope': 'pilot014 structural candidate only; independent root linkage/admission required',
    'row': row, 'actualRawPath': str(raw), 'canonicalFutureInputPath': row['input_path'],
    'originalParserIR': str(ir), 'inputHashes': before, 'eventCount': count, 'strictEOFCompleted': True,
    'firstKind': first_kind, 'lastKind': last_kind, 'observedInitialHashes': initial_hashes,
    'initialHashComparisonScope': 'first installment case self-seeds; no independent baseline comparison',
    'semanticCorrespondenceProven': False, 'fullExporterAccepted': False, 'finalA4Accepted': False}))
PY
```

The generator is fully exhausted before a success candidate is printed: `raw_events` validates final metadata, exact vars order and strict EOF only after its final yielded event. It checks all 28 actual raw A4Event/AAuthorityExecution carriers, counters0..27, selected commands/guards, computations, and denial/end stability without materializing a list of all events. Before/after hashes bind the original ITF and IR without reserialization; the only canonicalization is the existing initial-state comparison digest.

No `parser_types`, `export_shards`, stage-cases, seal-manifest, or package writer is called. The full78 exporter remains unchanged, including both later required fresh aggregate parses and its same-lifecycle initialization comparisons. This command proposes a scoped structural candidate; root's native/source/runtime/parser/outer receipt review remains essential, and no semantic-correspondence, final115/native, full78, or Council conclusion follows.
