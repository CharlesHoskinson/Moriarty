"""Experimental Moriarty reference semantics."""
