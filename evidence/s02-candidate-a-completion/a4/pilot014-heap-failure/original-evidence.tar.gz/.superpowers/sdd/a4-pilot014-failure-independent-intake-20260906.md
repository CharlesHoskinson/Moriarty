# A4 case014: independent original failure intake

**Evidence-preservation verdict: PASS. Pilot/eligibility verdict: FAILED.** This is preservation of one failed native invocation, not a successful structural intake or root acceptance. No concrete original-evidence mismatch was found.

Original Node exit is **-6**; integrated recorder exit is **134**; RH002 actual/return codes are **134/134**; actual outer tool exit is **134**. The original1510-byte stderr contains `FATAL ERROR: Ineffective mark-compacts near heap limit Allocation failed - JavaScript heap out of memory` and the Node OOM stack. RH002 timed_out=false, eligible=false, resource_complete=true and unforced cleanup complete without signals/errors. Owned PGID3461384 was absent at independent intake. This is a JavaScript heap OOM failure, not an outer timeout. It does not establish which internal compiler/evaluator operation consumed the memory.

Original inner stdout is empty, `artifacts` is `{}`, and no ITF exists in the original stage. Both case044 destinations are still absent. The canonical `case-014-export` stage is consumed failure evidence. The014 gate closes; there is no044 dispatch, retry, source change, limit increase, structural raw-event intake or package/H1 acceptance in this review.

## Independent checks

- Matched the root-dispatch command byte-for-byte to the admitted readiness command and actual transport. Exact row is installment/recover-r1-timeout100/ordinary/SignAfterResolve, global ordinal14,28 intended events and27 max-steps. Requested `quint run` resolves to pinned Node/CLI, Rust backend, seed42, one sample/trace, both named invariants, completeA4 witness and original canonical ITF path. No extra heap argv is present; the unchanged recorder clears inherited NODE_OPTIONS. No4096MiB explicit heap flag or total-RSS cap is inferred for this invocation.
- All121 source pins equal the separate root freeze and both original source maps. Reconstructed the full104-Quint/17-Python closure from source without imports. Every one of242 copied source files and all current source bytes match; missing-source lists are empty. Both source commits and root-dispatch HEAD are `08e426c7163880b9312f1f1f029a4dde9d0e7593`. Producer base386bf0a and runtime bootstrap900bb20 retain their separate historical meanings.
- Compared all8,102 runtime pins and four tree memberships to the producer/shared manifests and root `runtimeExpected`; rehashed both admitted runtime archives. Both endpoint maps, shared-runtime records, helper copy, four actual tool identities and RH002 source/interpreter/time pins agree. Version probes retain their original outcomes, including unsupported Rust `--version` exit1. The independent audit hashed8,525 distinct current paths. No project/runtime helper was imported or executed.
- Verified original RH002 parent/child/time argv, cwd/cache fields,900-second wall bound,5-second grace/cleanup, actual environment receipt, runner copy and all five sidecar pins. Independent body validation supplies the inner-receipt check; RH002's unconditional `inner_receipt_complete:false` remains unchanged and is not an invented missing receipt.
- The complete original GNU-time document has23 unique fields, exact recorder-command binding and original diagnostic `Command exited with non-zero status 134`. Wall time **5:56.80**, user **394.76s**, system **16.91s**, maximum RSS **4,371,180KiB** measure the whole recorder/native-descendant invocation. They are not evaluator-only metrics or a simultaneous RSS sum. The recorder separately measures its Node subprocess elapsed interval as352,649,572,797ns.
- All37 original returned responses equal the ordered original outer-terminal list: session69003 starts at chunke3a437, ends at chunk8cda68/exit134, with no intermediate terminal. Exact command/cwd and original exec parameters agree. The closed original native root cell315 is parent-reported context; authentic retained tool objects carry the session/chunk/exit evidence.
- Rechecked all nine root-dispatch bindings, including the admitted preliminary114 and final-source parser admission. Parser/source maps agree and parser admission precedes dispatch. Recorded prior groups3365488/3365545/3430331/3452479 and new group3461384 were all absent. The prior114 admission retains its existing unknown-parent/polling limitations; this failure neither weakens nor completes that gate.

## Original pins and audit receipts

| Evidence | SHA-256 |
| --- | --- |
| Root dispatch `.superpowers/sdd/a4-pilot014-root-dispatch-20260906.json` | `2d0394ee7fd47075dc365d9213f5218cc3ba6e873ec97f1611f9a770fa559f8e` |
| Original inner `case-014-export/receipt.json` | `8909e53ae4e66cfa2e9866f5aee3edcbb11792ae56eb4cc6e4c6984524ba3c06` |
| Both original closure JSON files | `1f77147416ee0ee079845456552657a8834a55187492356758cb1d3f7cd30860` |
| Original inner stderr | `6ab5a839fdf570641f6df939a1cd9c036152004336565da901c00a1eeb7a896e` |
| Original RH002 terminal | `6efe155209200a679b0739d0ae475e82be84a9cdc3a8bcac1dfea49cf2f10f5d` |
| Original outer transport terminal | `5473054609de2ed5cea11c0af9c724231944bcc17b47219d8196dc7c5d7f1653` |
| New independent303-file index `.superpowers/sdd/a4-pilot014-failure-independent-index-20260906.json` | `e0f7cfda8a2ef9bd9cf913485d24d1928f9b211f795b4a6c40af4e99da8b4599` |
| New exact tool receipt `.superpowers/sdd/a4-pilot014-failure-independent-tool-receipt-20260906.json` | `b300809e38b782488ec89cab390963d9acf2efe514224cb6b9499ec5d68f90ff` |

The303-file index covers every original inner/outer/transport file, both source-copy trees, root dispatch and all its bound support files; it also preserves the exact stderr text. It is a new post-terminal audit index, not a retroactive native receipt. Its own file is excluded.

Actual independent data audit: chunk62b47c, exit0. Its complete303-file stdout exceeded the tool's output budget, so the exact returned response contains explicit truncation and is preserved that way. A separate small data-index command, chunk5b70df/exit0, wrote the complete fresh index and checked that ITF and044 destinations remain absent. No full unavailable original stdout was fabricated; no native or runtime audit was repeated for indexing. The tool receipt includes both exact command arguments and actual returned objects. This reviewer changed only these three new independent evidence files, with no original/source/runtime edits or commit. Root owns final failed-preservation admission and any separately reviewed next decision.
