# Failed case014 evidence packaging proposal

Status: source-only proposal for root review. No package, archive, builder or audit code is created or run by this proposal. No original, model, runtime, native command, source or commit changes are authorized. Proposed separate package: `evidence/s02-candidate-a-completion/a4/pilot014-heap-failure/`.

Preserve the admitted failed invocation: Node -6, recorder134, RH002 actual/return134, actual outer tool134; original JavaScript heap OOM stderr; `timed_out:false`, **`eligible:false`**, complete unforced cleanup and no ITF. The canonical case014 stage is consumed failure evidence. Case044, retry, raw-event structural intake and full78 dispatch were not authorized. No internal phase, explicit4096MiB heap argv, hard RSS bound or H1 result is inferred.

## Exact original members

Base set: every one of the **303** original relative paths in `.superpowers/sdd/a4-pilot014-failure-independent-index-20260906.json`, SHA256 `e0f7cfda8a2ef9bd9cf913485d24d1928f9b211f795b4a6c40af4e99da8b4599`. Its `originals` map totals **10,005,925 bytes**. Preserve exact original paths, lengths and hashes. It contains both121-source snapshots (242 copied sources), closure maps, all inner/RH002 originals, the37 individual transport responses plus command/terminal, root dispatch and its nine bound support files. Define membership from the pinned index, not a current recursive glob. No stage file is renamed, regenerated or reserialized.

Add exactly these **21** existing originals. Prefix `S/` denotes `.superpowers/sdd/` and must be expanded in archive/index paths. The base already contains producer dispatch and RH002, so neither is added twice.

| Additional original path | SHA256 |
| --- | --- |
| `S/a4-checker-task1-receipts/python-environment.json` | `cd004057c4067bf7cc536d2cec5038add88d0852c1a7de5030e402ff2204f9c4` |
| `S/a4-pilot014-failure-independent-index-20260906.json` | `e0f7cfda8a2ef9bd9cf913485d24d1928f9b211f795b4a6c40af4e99da8b4599` |
| `S/a4-pilot014-failure-independent-intake-20260906.md` | `4259ddd09d8073edb158a2140f0d78cfcf7ea1e4c607d1303ccc8aeb38d3924b` |
| `S/a4-pilot014-failure-independent-tool-receipt-20260906.json` | `b300809e38b782488ec89cab390963d9acf2efe514224cb6b9499ec5d68f90ff` |
| `S/a4-pilot014-failure-root-admission-20260906.json` | `f0676a056c57464478954ecc9ae622acfee14102bfcec8079b6900584dc3f758` |
| `S/a5-factoring-receipts/dispatch.json` | `393a8aa904bcd9473670ac48934b3dca4ed611ca9b9accbfa94f15bb4798ac2f` |
| `S/a5-factoring-receipts/tool-store/manifest.json` | `fa3e9838c66480557ed6d928a2d159ebc074d05f67f15ef08ab20388d9c49e0b` |
| `S/a5-factoring-receipts/tool-store/java.stderr` | `7ccd1bd8325e9df64f66fa6c599aa31328ee31932cc12b7d8df78a8790e550d0` |
| `S/a5-factoring-receipts/tool-store/java.stdout` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `S/a5-factoring-receipts/tool-store/libc.stderr` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `S/a5-factoring-receipts/tool-store/libc.stdout` | `63b5af6d126f4c1a7dda90b9e95ff7f5562cd0b8866c73a3dca18c3736a8c286` |
| `S/a5-factoring-receipts/tool-store/node.stderr` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `S/a5-factoring-receipts/tool-store/node.stdout` | `1f2f55b6a7002be8f9992bdfa80f6a4a2b133df9201a4cbc2c35fb471256cd48` |
| `S/a5-factoring-receipts/tool-store/python.stderr` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `S/a5-factoring-receipts/tool-store/python.stdout` | `c4a684e859efa868ffdfb4967e90ffd847a0fc1f293e16ed50ea18af8e3b95f6` |
| `S/a5-factoring-receipts/tool-store/quint.stderr` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `S/a5-factoring-receipts/tool-store/quint.stdout` | `e0ccf7913110f807adecc59be43ce6fb334f82a8a7f70f70fbbba34bf1eeaaf2` |
| `S/a5-factoring-receipts/tool-store/rust.stderr` | `b04370a7d69875d970e86cd64af81c83c8e516a8040c40e876c3868cce969785` |
| `S/a5-factoring-receipts/tool-store/rust.stdout` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `evidence/s02-candidate-a-completion/a4/final-source-parser/index.json` | `19348e1089004e998e096b3c59dff2cbc7888a98a5b31fd7ae89db5dc6a00932` |
| `scripts/run_s02_candidate_a_factoring_pilot.py` | `816c3ad79dc3a67ca9a03729af56d74188c161a7546b9c43e821c222a4bce7f2` |

Archive the **324 existing originals plus this frozen proposal**, exactly **325 regular members**, as `original-evidence.tar.gz`. This proposal's final hash is recorded externally after freeze; no self-referential hash appears in it. Exclude directory entries, links, escaping/noncanonical paths and all undeclared members. Reject changed/missing/conflicting original pins before archive creation. The original report/index/tool receipt remain exact separate files, including deliberate truncation disclosure. Copying the parser package's small original index closes its archive/member declarations without duplicating its raw IR.

## External dependencies

| External original path | Bytes | SHA256 |
| --- | ---: | --- |
| `.superpowers/sdd/a5-factoring-receipts/tool-store/runtime.tar.gz` | 315704660 | `f0687656d30c0d59ece8dfd027508a9228020506d29b97aea3abe7568186c31c` |
| `.superpowers/sdd/a4-checker-task1-receipts/python-environment.tar.gz` | 66716078 | `7363d106d464f976af2a0e7f1f56e3c7bed237c7a3396a60d073369add068dac` |
| `evidence/s02-candidate-a-completion/a4/final-source-parser/original-evidence.tar.gz` | 5434195 | `7233f85c03bfacf80d83d50a657a10f05a23d4863c157ecc81a4c37b13ee8119` |

The parser dependency index is78,831 bytes with the SHA above. Its original archive holds the admitted38,527,047-byte IR, SHA256 `cbf57ad5a7f194ba62bf897553d3750ddba899190683ab8293cc633282886e1e`. The failure package retains the existing parser root-admission bytes in its303 base, and must match that admission's raw IR declaration to the copied parser index member and external archive declaration. It does not reread that archive or raw IR. Its copied index binds archive content by recorded hash; it does not itself reperform parser-package acceptance. Root owns final external dependency admission. If that package index is revised before this proposal is adopted/built, preserve this proposal and seek a specific hash correction, rather than silently following a new index.

No large runtime archives or installed runtime files are copied or reread. The complete manifests, all twelve version streams, producer/shared dispatch and helper source close the recorded runtime map; the124 dynamic-library receipt bodies already reside in the runtime manifest. Other preliminary114/parser historical references retain their own admitted scope and external packages; no recursive duplication of unrelated evidence.

## Standalone audit and preservation contract

The later authorized build may reuse the reviewed parser package's standard-library preservation pattern in new source files under this separate failure package. Do not change that earlier package or blindly copy its success/IR predicates. New `build_archive.py`, `audit.py`, `README.md` and `index.json` remain outside the original archive, alongside original actual build/audit tool receipts, any expected optimization rejection, derived reports and a final artifact index. Use exclusive fresh outputs. Preserve any failed build/audit and its exact actual response before correcting package code; no overwritten failure or fabricated terminal. Freeze scripts/index/archive after passing audit and hand off to an independent reviewer; no commit is authorized.

Audit from any cwd using only packaged bytes and the standard library. Reject optimization before reads. Do not import/execute archived code or helpers, run native commands, inspect current groups or rehash installed files. Parse archived source with AST/literal inspection and Quint import text only. Map original absolute paths to safe archive-relative identifiers without opening them. Bound compressed/uncompressed/member/metadata reads; stream hashes; reject duplicate members/JSON keys, nonfinite numbers, trailing JSON, links and path escapes. Exact325 membership, byte lengths and SHA256 are mandatory. The original index itself excludes its own file; package index and final artifact index must explicitly exclude their own hashes and later receipts/reviews from circular pinning.

Required substantive checks:

1. All303 original pins, plus21 additions and proposal, exactly match. Check root failure admission's independent report/index/tool pins and all nine original native root-dispatch bindings. Preserve actual source/dispatch HEAD `08e426c7163880b9312f1f1f029a4dde9d0e7593`, producer base `386bf0ae10f767e051b414a7231be105cc4b0f71`, runtime bootstrap `900bb2051225b4a3d99bf422c3b2e5e386e3e7bc`, and any later packaging HEAD as distinct facts.
2. Independently derive the archived104-Quint/17-Python closure; require exact121 dispatch/inner-before/inner-after/parser-admission source maps, both complete121-copy trees, no missing-source lists and stable final corrected case032/lowering bytes. Check source commits and helper/runner copies. Do not compare current sources or execute their behavior.
3. Reconstruct exact8102 runtime pins/four tree memberships from packaged manifests/version streams/dispatch/helper, reject conflicts, and match native root `runtimeExpected`, inner before/after and parser admission's recorded runtime map. Match both shared runtime endpoints, actual executable hashes, and outer source/interpreter/GNU-time pins. Preserve Rust unsupported `--version` exit1. Validate archived small-reference bytes; external archive/installed-library verification is recorded historical evidence only.
4. Exact row is installment/recover-r1-timeout100/ordinary/SignAfterResolve, global ordinal14,28 intended events and27 max-steps. Compare native root command byte-for-byte with original readiness and transport; validate requested `quint run` and actual pinned Node/CLI command, Rust backend, seed42, one sample/trace, both `noDiagnosticA4`/`sourceInvariantA4` invariants, `completeA4` witness and canonical original ITF output path. These were requested checks, not observed passing invariants or witness completion. No extra heap argv is present and `extraNodeHeapOverride:false` is retained; archived unchanged recorder source clears inherited `NODE_OPTIONS`. Do not turn observed GC figures or a different parser command's heap flag into an explicit014 heap limit.
5. Check actual Node -6, recorder134, RH002 actual/return134 and original outer134, matching original recorder stdout/result and receipt mapping. Require `timed_out:false`, `eligible:false`, resource complete, no launch/monitor error and complete unforced cleanup with no signals/errors. Preserve RH002 unconditional `inner_receipt_complete:false` and validate its actual present inner receipt independently. These are admitted failure predicates; never require or rewrite successful eligibility.
6. Preserve exact original1510-byte inner stderr SHA256 `6ab5a839fdf570641f6df939a1cd9c036152004336565da901c00a1eeb7a896e`, and require byte equality to the independent index's `stderrOriginalUtf8` encoding. Require the original OOM diagnostic and stack, empty inner stdout and `artifacts:{}`. Exact original inner-stage membership contains no ITF. Original `noITF`/`case044DestinationsAbsent` and root no044 statements establish recorded absence at intake; offline audit does not assert present-day filesystem absence.
7. Require all37 original response files equal the ordered transport terminal objects: session69003 starts at chunke3a437 and ends at8cda68/exit134, with no intermediate terminal. Preserve exact args/cwd and response bytes, not reconstructed polling metadata. Validate all original RH002 sidecars, parent/child/time argv, cache/environment and900-second outer/5-second grace/cleanup declarations.
8. Parse all23 original GNU-time fields and its extra diagnostic `Command exited with non-zero status 134`; match exact recorder command, wall5:56.80, user394.76s, system16.91s and max RSS4371180KiB. These describe the whole recorder/native-descendant invocation, not the evaluator alone or summed RSS. Match inner elapsed352649572797ns. The OOM is not an outer timeout and locates no internal phase.
9. The original independent tool receipt preserves actual audit62b47c/exit0 with the tool's truncated output (15,621 reported original tokens), then separate indexing5b70df/exit0. Validate the latter's complete output binds the fresh70,090-byte303 index by its actual SHA and reports noITF/no044/nativeRerunfalse. Do not parse truncated audit output as complete JSON, synthesize its unavailable full stdout or relabel indexing as another native/runtime audit. Original report/index/root admission provide complementary preserved evidence.
10. Match copied parser package index pin, external archive bytes/hash, raw IR member path/bytes/hash and parser admission. No raw parser IR schema audit is performed in this failure package. Root parser admission history, preliminary114 unknown-parent/polling limits and proposal correction history remain intact in the bound originals. The unused structural proposal is preserved as a plan, never represented as executed raw-event intake.

Successful standalone audit means internally consistent **failed-pilot preservation** and recorded external dependencies. It supplies no pilot feasibility, invariants holding, witness completion, structural events, native acceptance, case044/full78 authorization, stage localization, remediation cause or H1. The original case014 stage remains consumed. Any retry, changed hypothesis, resource change or new diagnostic needs its own reviewed decision; this packaging task creates none.

## Proposal validation

This proposal inspected the original report, index, admission, dispatch and tool receipt as data. It checked the303 count/10,005,925-byte total and the21 additional file hashes against the actual small originals, without runtime archive reads, parser-package archive reads, native activity, imports of project code, original mutation or build. Final hash handoff freezes this document for review.
