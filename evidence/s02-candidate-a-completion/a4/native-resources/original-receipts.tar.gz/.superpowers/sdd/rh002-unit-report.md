# RH002 receipt-only runner author handoff

Status: source frozen; original presence-only completeness RED retained and full41-control GREEN passed. Root source/evidence review and admission remain separate. No live author jobs.

## Authority and bounded scope

Adopted plan3a7d32d: docs/superpowers/plans/2026-09-05-candidate-a-native-resource-runner.md, SHA256ad92bc6e9001a948632e8b8e3de3b1e12e427f64037b1aceb44404b62f9b2e85. The full176-line plan was read. Pre-dispatch base3a7d32d3a812207e860e340851aa17c1a8b3494a. Root approved the dedicated harness/API before any validation and approved the narrow resolved-path refinement before GREEN: the inner receipt must be outside the dedicated outer directory, including sidecar aliases via ..; symlink and dangling-link destinations are rejected.

Only receipt-only evidence/s02-candidate-a-completion/a4/native-resources/runner.py and test_runner.py plus dedicated ignored harness/artifacts were changed. No A4 exporter/recorder/semantic tests, Quint/Core/A5/utility/checker source, completed Task3 report or earlier original evidence changed. No commits, native job/pilot/export, package gate, model-checking, Foreman or Council action occurred.

The executing-plans/TDD skills governed the test-first sequence. This is author evidence, not independent review or native acceptance. The runner's eligible field is only local wrapper eligibility; independent validation of the inner receipt is always required and inner_receipt_complete is always false. Short test children deliberately write actual tiny dummy inner files; these are not fabricated native or semantic receipts and never claim to satisfy the independent inner gate.

## Dedicated original receipt harness

Ignored harness .superpowers/sdd/rh002-unit/record.py is archived before and after each command with the runner, test, adopted plan and exact imported runtime-only helper:5source files per side,20original source members across2stages. The helper is reused solely for current runtime/archive validation, never imported as an A4 semantic receipt. Its exact SHA256816c3ad79dc3a67ca9a03729af56d74188c161a7546b9c43e821c222a4bce7f2 and shared dispatch SHA256393a8aa904bcd9473670ac48934b3dca4ed611ca9b9accbfa94f15bb4798ac2f are enforced.

Each command separately retains8089current runtime/reference file hashes before/after, including the already admitted Python archive/manifests and GNU time/runtime store. The helper also verifies its complete admitted tree membership and saved version-stream hashes. The count differs from the semantic recorder's8102 because this dedicated harness does not duplicate that recorder's producer-dispatch/version-sidecar map; it still checks the shared verifier's exact admitted runtime. No runtime store was created or modified.

Parent and test-child Python launch with -B and fresh explicit -X pycache_prefix. Every generated short Python subprocess also receives -B/fresh-X. Exact parent/child argv, raw stdout/stderr, terminal results and all test artifacts remain under exclusive per-stage directories; environment metadata retains removed names, not values. The environment test prints only its explicit fixed/test-key subset, never an unredacted environment.

## Genuine RED

Initial resource_complete(path,argv) returned Path(path).is_file(), exactly reproducing the earlier presence-only proposal. The unchanged test creates a real empty resources.txt and asserts false. The actual result was assertTrueisFalse, child/recorder exit1;0.791302309seconds recorder duration; empty stderr. No parser/import failure substitutes for this behavioral RED.

Exact launch:

```bash
/home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/rh002-unit-receipts/red/python-cache .superpowers/sdd/rh002-unit/record.py red -k present_empty_resource
```

Full original stdout:

```text
============================= test session starts ==============================
platform linux -- Python 3.13.14, pytest-9.1.1, pluggy-1.6.0 -- /home/charl/Moriarty/.venv/bin/python
cachedir: .pytest_cache
rootdir: /home/charl/Moriarty/.worktrees/s01-audit-start
configfile: pyproject.toml
plugins: anyio-4.14.2
collecting ... collected 1 item

evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_present_empty_resource_is_incomplete FAILED [100%]

=================================== FAILURES ===================================
__________________ test_present_empty_resource_is_incomplete ___________________

tmp_path = PosixPath('/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/rh002-unit-receipts/red/basetemp/test_present_empty_resource_is0')

    def test_present_empty_resource_is_incomplete(tmp_path):
        resource = tmp_path / "resources.txt"
        resource.write_bytes(b"")
>       assert runner.resource_complete(resource, ["python", "child.py"]) is False
E       AssertionError: assert True is False
E        +  where True = <function resource_complete at 0x70af8eb54180>(PosixPath('/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/rh002-unit-receipts/red/basetemp/test_present_empty_resource_is0/resources.txt'), ['python', 'child.py'])
E        +    where <function resource_complete at 0x70af8eb54180> = runner.resource_complete

evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py:13: AssertionError
=========================== short test summary info ============================
FAILED evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_present_empty_resource_is_incomplete - AssertionError: assert True is False
 +  where True = <function resource_complete at 0x70af8eb54180>(PosixPath('/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/rh002-unit-receipts/red/basetemp/test_present_empty_resource_is0/resources.txt'), ['python', 'child.py'])
 +    where <function resource_complete at 0x70af8eb54180> = runner.resource_complete
============================== 1 failed in 0.05s ===============================
```

The original failing test AST is identical in the final source. Additional planned controls were appended honestly as coverage after this RED, not described as additional original REDs.

## Implementation and control scope

The parser accepts exactly the23installed C-locale GNU time verbose fields once each, binds the quoted space-joined original child argv, rejects malformed/nonfinite/negative/missing/duplicate/unexpected fields, requires positive maximum RSS and bounds the resource read to65537bytes to enforce a64KiB maximum. Original reports and diagnostic prefixes remain intact. A genuine short measured child confirmed all23field names; its original report records17672KiB maximum RSS and exit0. That is a short-child measurement only, not Candidate A memory or simultaneous Node+Rust RSS.

Capture verifies admitted GNU time, hashes its runner/interpreter/time sources before/after, copies original runner bytes, launches unchanged child argv under time in a new process group and retains all sidecars. The CLI cannot expose shortened cleanup intervals. Test-only API overrides use0.1/0.15seconds; real defaults are900seconds wall and5seconds each grace/reap/group-check bound.

Every post-spawn path checks the owned group, including ordinary leader exit, timeout and monitor failure. A remaining or uncertain group triggers bounded cleanup; SIGKILL is attempted after SIGTERM even if the leader exited. Cleanup exceptions remain terminal/incomplete and do not erase the triggering failure. Only owned process-group IDs or specifically recorded descendant PIDs are inspected/signaled; no host-wide scan or unrelated termination occurs.

Actual process controls cover normal measured output, exit7, no inner receipt, invalid working-directory launch failure, simple timeout, SIGTERM-ignoring descendants after timeout and after ordinary leader exit, and a real CLI invocation. The two descendant controls prove their recorded children cannot continue via specific-PID /proc state and stable heartbeat length. Both happened to disappear completely in this run; the tests and code explicitly keep any zombie/lingering group incomplete instead of treating leader exit as sufficient.

Monitor/TERM-error and pin-instability controls inject deterministic faults while retaining real owned process execution; they are labeled injected faults, not naturally observed kernel failures. Malformed resource tests preserve both the actual successful report and the separately mutated file. No resource failure is labeled a semantic counterexample.

## Full GREEN and original process outcomes

Exact launch:

```bash
/home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/rh002-unit-receipts/green/python-cache .superpowers/sdd/rh002-unit/record.py green
```

Child/recorder exit0;41passed in5.90seconds pytest time,6.593939886seconds recorder duration. Empty stderr. Both stages report identical before/after source and runtime maps.

Full original stdout:

```text
============================= test session starts ==============================
platform linux -- Python 3.13.14, pytest-9.1.1, pluggy-1.6.0 -- /home/charl/Moriarty/.venv/bin/python
cachedir: .pytest_cache
rootdir: /home/charl/Moriarty/.worktrees/s01-audit-start
configfile: pyproject.toml
plugins: anyio-4.14.2
collecting ... collected 41 items

evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_present_empty_resource_is_incomplete PASSED [  2%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_honest_measured_child_and_all_sidecar_hashes PASSED [  4%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_missing_inner_is_not_eligible PASSED [  7%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_nonzero_child_preserves_actual_status PASSED [  9%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_malformed_or_substituted_resource_report[truncated] PASSED [ 12%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_malformed_or_substituted_resource_report[duplicate] PASSED [ 14%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_malformed_or_substituted_resource_report[unknown] PASSED [ 17%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_malformed_or_substituted_resource_report[negative] PASSED [ 19%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_malformed_or_substituted_resource_report[nan] PASSED [ 21%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_malformed_or_substituted_resource_report[inf] PASSED [ 24%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_malformed_or_substituted_resource_report[malformed-wall] PASSED [ 26%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_malformed_or_substituted_resource_report[zero-rss] PASSED [ 29%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_malformed_or_substituted_resource_report[command] PASSED [ 31%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_resource_limit_uses_bounded_read PASSED [ 34%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_invalid_wall_does_not_create_destination[True] PASSED [ 36%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_invalid_wall_does_not_create_destination[False] PASSED [ 39%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_invalid_wall_does_not_create_destination[0] PASSED [ 41%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_invalid_wall_does_not_create_destination[-1] PASSED [ 43%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_invalid_wall_does_not_create_destination[1.5] PASSED [ 46%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_invalid_wall_does_not_create_destination[1] PASSED [ 48%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_invalid_wall_does_not_create_destination[None] PASSED [ 51%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_invalid_argv_fails_before_launch[argv0] PASSED [ 53%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_invalid_argv_fails_before_launch[python] PASSED [ 56%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_invalid_argv_fails_before_launch[argv2] PASSED [ 58%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_invalid_argv_fails_before_launch[argv3] PASSED [ 60%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_invalid_argv_fails_before_launch[argv4] PASSED [ 63%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_exclusive_destinations_and_existing_inner PASSED [ 65%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_symlink_destination_rejected[outer] PASSED [ 68%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_symlink_destination_rejected[ancestor] PASSED [ 70%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_symlink_destination_rejected[inner] PASSED [ 73%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_environment_values_are_not_leaked PASSED [ 75%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_time_pin_mismatch_is_prelaunch PASSED [ 78%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_inner_cannot_alias_outer_sidecars_or_dangling_link PASSED [ 80%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_real_launch_error_retains_terminal PASSED [ 82%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_simple_timeout_is_incomplete PASSED [ 85%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_monitor_error_still_cleans_actual_owned_process PASSED [ 87%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_cleanup_error_keeps_terminal_and_attempts_kill PASSED [ 90%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_leader_exit_never_hides_live_descendant[timeout] PASSED [ 92%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_leader_exit_never_hides_live_descendant[ordinary-exit] PASSED [ 95%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_source_instability_is_ineligible_without_editing_source PASSED [ 97%]
evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py::test_cli_uses_actual_short_process_and_hides_cleanup_options PASSED [100%]

============================== 41 passed in 5.90s ==============================
```

Original21capture terminal summaries follow. Rows are individual actual capture records, not independent Candidate A cases. Each path, original child script, resource report, inner dummy file and all sidecar hashes are retained in the artifact index.

| Local control directory | Actual outer exit | Wrapper code | Timeout | Forced cleanup | Cleanup complete | Eligible |
| --- | ---: | ---: | --- | --- | --- | --- |
| test_cleanup_error_keeps_termi0 | -9 | 124 | true | true | false | false |
| test_cli_uses_actual_short_pro0 | 0 | 0 | false | false | true | true |
| test_environment_values_are_no0 | 0 | 0 | false | false | true | true |
| test_honest_measured_child_and0 | 0 | 0 | false | false | true | true |
| test_leader_exit_never_hides_l0 | -15 | 124 | true | true | true | false |
| test_leader_exit_never_hides_l1 | 0 | 2 | false | true | true | false |
| test_malformed_or_substituted_0 | 0 | 0 | false | false | true | true |
| test_malformed_or_substituted_1 | 0 | 0 | false | false | true | true |
| test_malformed_or_substituted_2 | 0 | 0 | false | false | true | true |
| test_malformed_or_substituted_3 | 0 | 0 | false | false | true | true |
| test_malformed_or_substituted_4 | 0 | 0 | false | false | true | true |
| test_malformed_or_substituted_5 | 0 | 0 | false | false | true | true |
| test_malformed_or_substituted_6 | 0 | 0 | false | false | true | true |
| test_malformed_or_substituted_7 | 0 | 0 | false | false | true | true |
| test_malformed_or_substituted_8 | 0 | 0 | false | false | true | true |
| test_missing_inner_is_not_elig0 | 0 | 2 | false | false | true | false |
| test_monitor_error_still_clean0 | -15 | 2 | false | true | true | false |
| test_nonzero_child_preserves_a0 | 7 | 7 | false | false | true | false |
| test_real_launch_error_retains0 | none | 2 | false | false | false | false |
| test_simple_timeout_is_incompl0 | -15 | 124 | true | true | true | false |
| test_source_instability_is_ine0 | 0 | 2 | false | false | true | false |

Timeout has return124 even when cleanup completes; ordinary early leader exit/live descendant has return2 despite actual exit0 and complete resource syntax because cleanup was forced. The honest nonzero child returns7; missing inner and launch/pin/monitor failures remain2. No inner receipt is called complete from presence alone.

## Frozen source and artifact intake

Frozen runner SHA256d8973d3541269d1be2ce524f2482e5f5b858f15f7d9117e3fe6d5cd2171d660d.
Frozen test SHA256e1e81c5105a8872b20a526a6f9e8bf1add1c498ba31e65f5019938a9a0986dc3.

Original index .superpowers/sdd/rh002-unit-artifact-index.json pins215regular original files and25original test symlink targets, including all20source snapshot members,2original command receipts, generated short-child source/outputs, actual resource records, mutated fixtures and21capture terminal records. Regenerated parent python-cache is excluded; no subprocess artifact was removed. Final source/harness files are also pinned. The index does not hash itself or this report; root must pin those outer documents separately.

Root retains source/evidence admission, independent inner validation and pilot authority. This completed short-process unit does not establish native feasibility, exact78-shard export, semantic correctness or package acceptance. Source/report are frozen at handoff.
