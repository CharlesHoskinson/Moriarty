from pathlib import Path
Path('/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/rh002-unit-receipts/green/basetemp/test_malformed_or_substituted_7/inner.json').write_text('{}')
print('honest child stdout')
