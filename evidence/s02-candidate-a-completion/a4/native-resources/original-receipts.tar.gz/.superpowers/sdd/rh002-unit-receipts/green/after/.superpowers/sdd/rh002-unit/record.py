"""Short RH002 tests only; runtime reuse, not an A4 semantic receipt."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
BASE = "3a7d32d3a812207e860e340851aa17c1a8b3494a"
PYTHON = Path("/home/charl/Moriarty/.venv/bin/python")
HELPER = ROOT / "scripts/run_s02_candidate_a_factoring_pilot.py"
HELPER_SHA = "816c3ad79dc3a67ca9a03729af56d74188c161a7546b9c43e821c222a4bce7f2"
DISPATCH = ROOT / ".superpowers/sdd/a5-factoring-receipts/dispatch.json"
DISPATCH_SHA = "393a8aa904bcd9473670ac48934b3dca4ed611ca9b9accbfa94f15bb4798ac2f"
STORE = DISPATCH.parent / "tool-store"
SOURCE = (
    "evidence/s02-candidate-a-completion/a4/native-resources/runner.py",
    "evidence/s02-candidate-a-completion/a4/native-resources/test_runner.py",
    ".superpowers/sdd/rh002-unit/record.py",
    "docs/superpowers/plans/2026-09-05-candidate-a-native-resource-runner.md",
    "scripts/run_s02_candidate_a_factoring_pilot.py",
)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while data := stream.read(1048576):
            h.update(data)
    return h.hexdigest()


def write_json(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def snapshot(destination):
    pins = {}
    for name in SOURCE:
        source = ROOT / name
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(source.read_bytes())
        pins[name] = sha(target)
    return pins


def runtime():
    assert sha(HELPER) == HELPER_SHA and sha(DISPATCH) == DISPATCH_SHA
    spec = importlib.util.spec_from_file_location("rh002_runtime_only", HELPER)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    dispatch = json.loads(DISPATCH.read_text())
    verification = helper.verify_runtime(dispatch["beforeDispatchCommit"])
    manifest = json.loads((STORE / "manifest.json").read_text())
    python_manifest = Path(manifest["reusedPythonManifest"])
    python = json.loads(python_manifest.read_text())
    assert Path(python["pythonResolved"]) == Path(sys.executable).resolve()
    refs = [HELPER, DISPATCH, STORE / "manifest.json", STORE / "runtime.tar.gz",
            python_manifest, Path(manifest["reusedPythonArchive"])]
    pins = {str(p): sha(p) for p in refs}
    for item in manifest["files"] + manifest["pythonFiles"]:
        pins[item["path"]] = sha(item["path"])
        assert pins[item["path"]] == item["sha256"]
    return {"verification": verification, "files": pins,
            "runtime_manifest": str(STORE / "manifest.json"),
            "python_manifest": str(python_manifest), "tree_members": manifest["treeMembers"]}


def main():
    stage_name, *selection = sys.argv[1:]
    assert re.fullmatch(r"[a-z0-9-]+", stage_name)
    stage = ROOT / ".superpowers/sdd/rh002-unit-receipts" / stage_name
    cache = stage / "python-cache"
    assert sys.dont_write_bytecode and sys.pycache_prefix
    assert Path(sys.pycache_prefix).resolve() == cache
    assert not stage.exists()
    stage.mkdir(parents=True)
    before = snapshot(stage / "before")
    runtime_before = runtime()
    command = [str(PYTHON), "-B", "-X", f"pycache_prefix={cache / 'child'}", "-m", "pytest",
               SOURCE[1], "-vv", f"--basetemp={stage / 'basetemp'}", *selection]
    environment = dict(os.environ)
    removed = [k for k in environment if k.startswith(("PYTHON", "PYTEST", "NODE_", "LD_"))]
    for key in removed:
        environment.pop(key)
    environment.update(PYTHONNOUSERSITE="1", PYTHONDONTWRITEBYTECODE="1", NODE_DISABLE_COMPILE_CACHE="1", LC_ALL="C")
    write_json(stage / "launch.json", {"original_parent_argv": sys.orig_argv, "command": command,
               "cwd": str(ROOT), "before_dispatch_base": BASE, "removed_environment_keys": sorted(removed)})
    started = time.time_ns()
    with (stage / "stdout.bin").open("xb") as out, (stage / "stderr.bin").open("xb") as err:
        result = subprocess.run(command, cwd=ROOT, stdout=out, stderr=err, env=environment, check=False)
    ended = time.time_ns()
    after = snapshot(stage / "after")
    try:
        runtime_after = runtime()
    except Exception as error:
        runtime_after = {"error": type(error).__name__ + ": " + str(error)}
    stable = before == after and runtime_before == runtime_after
    terminal = {"command": command, "exit_code": result.returncode, "recorder_exit_code": result.returncode if stable else 2,
                "started_ns": started, "ended_ns": ended, "elapsed_ns": ended - started,
                "source_before": before, "source_after": after, "runtime_before": runtime_before,
                "runtime_after": runtime_after, "source_stable": before == after,
                "runtime_stable": runtime_before == runtime_after,
                "stdout_sha256": sha(stage / "stdout.bin"), "stderr_sha256": sha(stage / "stderr.bin")}
    write_json(stage / "terminal.json", terminal)
    print(json.dumps({"stage": str(stage), "exit_code": result.returncode, "stable": stable}))
    return terminal["recorder_exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
