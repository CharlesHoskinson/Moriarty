import subprocess,signal,time
from pathlib import Path
subprocess.Popen(['/home/charl/Moriarty/.venv/bin/python', '-B', '-X', 'pycache_prefix=/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/rh002-unit-receipts/green/basetemp/test_leader_exit_never_hides_l0/descendant-cache', '/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/rh002-unit-receipts/green/basetemp/test_leader_exit_never_hides_l0/descendant.py'])
while not Path('/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/rh002-unit-receipts/green/basetemp/test_leader_exit_never_hides_l0/descendant.pid').exists(): time.sleep(0.01)
Path('/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/rh002-unit-receipts/green/basetemp/test_leader_exit_never_hides_l0/inner.json').write_text('{}')
signal.signal(signal.SIGTERM,lambda *args:exit(0))
time.sleep(60)
