import os,signal,time
from pathlib import Path
signal.signal(signal.SIGTERM,signal.SIG_IGN)
Path('/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/rh002-unit-receipts/green/basetemp/test_leader_exit_never_hides_l1/descendant.pid').write_text(str(os.getpid()))
while True:
 with Path('/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/rh002-unit-receipts/green/basetemp/test_leader_exit_never_hides_l1/heartbeat').open('a') as f: f.write('x')
 time.sleep(0.02)
