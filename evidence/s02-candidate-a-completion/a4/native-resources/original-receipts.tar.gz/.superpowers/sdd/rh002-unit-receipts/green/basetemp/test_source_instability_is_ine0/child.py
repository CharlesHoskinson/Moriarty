from pathlib import Path
Path('/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/rh002-unit-receipts/green/basetemp/test_source_instability_is_ine0/inner.json').write_text('{}')
print('honest child stdout')
