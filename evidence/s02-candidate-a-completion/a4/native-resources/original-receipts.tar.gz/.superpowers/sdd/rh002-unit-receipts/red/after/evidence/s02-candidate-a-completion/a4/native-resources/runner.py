from pathlib import Path


def resource_complete(path, argv):
    return Path(path).is_file()
