from pathlib import Path
Path('/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/rh002-unit-receipts/green/basetemp/test_cli_uses_actual_short_pro0/inner.json').write_text('{}')
