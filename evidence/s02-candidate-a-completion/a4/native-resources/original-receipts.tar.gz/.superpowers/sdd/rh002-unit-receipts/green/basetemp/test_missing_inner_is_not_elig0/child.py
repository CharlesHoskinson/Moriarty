print('no receipt')
