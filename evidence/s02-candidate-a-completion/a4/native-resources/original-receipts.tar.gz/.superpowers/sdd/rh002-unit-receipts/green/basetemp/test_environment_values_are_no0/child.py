import os,json
from pathlib import Path
Path('/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/rh002-unit-receipts/green/basetemp/test_environment_values_are_no0/inner.json').write_text('{}')
print(json.dumps({k:os.environ[k] for k in ['PYTHON_FAKE', 'PYTEST_FAKE', 'NODE_FAKE', 'LD_FAKE', 'PYTHONNOUSERSITE', 'PYTHONDONTWRITEBYTECODE', 'NODE_DISABLE_COMPILE_CACHE', 'LC_ALL'] if k in os.environ}))
