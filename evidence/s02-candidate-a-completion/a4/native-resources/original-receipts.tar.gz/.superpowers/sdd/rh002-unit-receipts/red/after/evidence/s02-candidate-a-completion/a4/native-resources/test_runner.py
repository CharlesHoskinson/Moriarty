import importlib.util
from pathlib import Path


spec = importlib.util.spec_from_file_location("native_resource_runner", Path(__file__).with_name("runner.py"))
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


def test_present_empty_resource_is_incomplete(tmp_path):
    resource = tmp_path / "resources.txt"
    resource.write_bytes(b"")
    assert runner.resource_complete(resource, ["python", "child.py"]) is False
