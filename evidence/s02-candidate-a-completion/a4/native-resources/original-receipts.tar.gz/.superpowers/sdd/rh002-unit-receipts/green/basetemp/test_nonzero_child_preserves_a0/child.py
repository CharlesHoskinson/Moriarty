from pathlib import Path
Path('/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/rh002-unit-receipts/green/basetemp/test_nonzero_child_preserves_a0/inner.json').write_text('{}')
raise SystemExit(7)
