from pathlib import Path
Path('/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/rh002-unit-receipts/green/basetemp/test_honest_measured_child_and0/inner.json').write_text('{}')
print('honest child stdout')
