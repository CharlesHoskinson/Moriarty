# A4 checker Task5 implementation report

Status: Task5 source frozen and local tests complete. Root admission pending. No Task6, actual package invocation, producer import/change, commit, index update, or Council claim.

Task base and all runtime source commits: `94f5824e5e050011c7bea8c74a1e68d1e3a25a78`.

## Final pins and authorized deviations

- `scripts/check_s02_candidate_a_integrated.py`: `c23adb6e60e446554af15e6e2fc9762c4ad66000e76a0456c4407ef8854b2d20`.
- `tests/test_s02_candidate_a_integrated.py`: `117529548b18117e0b2afd41ab9d151d814b7ee970b50d4d8f9743718fa68443`.
- Ignored `a4-checker-task5-receipts/recorder.py`: `da0ad3303c0c3abe0b79eedbda0fd95873a6b19c6e7a8a552245e163c7e1cb93`.

The checker equals the adopted Task5 block with only these authorized changes:

1. Addendum ab7c827 adds `moriarty/__init__.py` to PYTHON_SOURCES and FROZEN_EXTRA with SHA256 `6d6b58f9875c357d5d16858e55ce81edd1e56ecb1c5b28476c7a911cad2e1127`.
2. The addendum changes the successful report's event total1757 to1557.
3. Root authorized a direct-script CLI repair: before scripts imports, when `__package__` is None or empty, prepend the resolved repository root to sys.path using the already imported Path/sys. The original failing direct CLI invocation and corrected passing invocation are both retained.

The test append is the exact adopted focused test. Existing five checker modules and full Task4 test prefix remain unchanged. No moving producer files were imported or included in focused runtime snapshots; the eventual package source inventory remains exact and does not waive missing producer files.

## Original terminal inventory

Receipts: `.superpowers/sdd/a4-checker-task5-receipts/`. Interpreter: `/home/charl/Moriarty/.venv/bin/python`; cwd: experiment worktree. Every command has original source archive, input manifest, separate stdout/stderr and terminal manifest, with actual elapsed time and exit. Fresh per-stage pycache paths and disabled bytecode writes are recorded. Both direct CLI invocations additionally set PYTHONPATH to the empty string.

| Stage | Exit | Result |
| --- | --- | --- |
| tests-first | 1 | Newly appended test fails at missing checker import;16 existing tests pass; not behavioral RED |
| direct-help-red | 1 | Direct script fails importing scripts.a4_carrier with empty PYTHONPATH |
| red-import | 0 | Six checker modules import successfully in package context |
| red-tests | 1 | Focused substituted-profile test fails with DID NOT RAISE Invalid |
| green-syntax | 0 | Seven final Python source/test files compile |
| green-import | 0 | Six final checker modules import |
| direct-help-green | 0 | Direct script --help succeeds with empty PYTHONPATH |
| green-tests | 0 | All17 current tests pass without exclusions;29.48s pytest time |

RED checker SHA256: `dd12570a0ef937a74fabc1e6fbc4b1f3f79bf1918e2dd732f5cefa3989cdf9a4`. RED-to-GREEN diff contains the restored raw-field equality and the separately authorized two-line CLI bootstrap. The bootstrap is inactive during package imports, so it does not explain the focused pytest change. The equality omission was the sole behavioral provenance control; no semantic assertion or package pin gate was weakened.

All eight complete terminal manifests report empty sourceChanged/environmentChanged. Original source archives have38 members, except tests-first37 because the new module was absent. Final read-only audit verified every archive digest, every source member, both stream hashes, exact adopted/addendum/bootstrap comparison, unchanged existing modules and append-only test prefix. No original failure was reconstructed or replaced.

Shared Task1 runtime remains referenced, not copied:3,329 files; manifest SHA256 `cd004057c4067bf7cc536d2cec5038add88d0852c1a7de5030e402ff2204f9c4`; archive SHA256 `7363d106d464f976af2a0e7f1f56e3c7bed237c7a3396a60d073369add068dac`. Per-stage snapshots retain local Python import closure, frozen common/A/lifecycle sources, inventory, brief, recorder, plan, and addendum. Unneeded concurrently moving producer files are excluded from this focused command closure only, not from eventual required package pins.

## Boundary self-review

- Document and independent root-admission fields are exact schema2 records. Admitted source/input/receipt maps must match submitted maps; paths reject traversal, absolute names and symlinks. SHA256 pins bind actual file bytes.
- Required package sources are the entry/test transitive Quint import closure plus the fixed Python tool/checker set, including the package initializer. Frozen hashes and actual imported/executed checker/Core source origins are checked. No missing producer source is accepted as a temporary substitute.
- The inventory is independently regenerated from fixed descriptors and histories. All78 cases and their exact ordered events are mandatory. Semantics compare against independently computed expected fields/states, with strict scalar, unit, list, tuple, map and set carrier checks and typed execution records.
- Exactly two raw ITFs and their root-admitted receipt byte set are required. Input/receipt pin maps are disjoint. Receipt hashes authenticate only the admitted bytes; root must independently audit original commands, tool identity, streams and terminal outcomes.
- Each exported event binds every latest-event field to its actual raw state. Sequence has an explicit strict integer comparison; all other values retain exact raw JSON equality. Before/after authority states bind to adjacent indices max(0,k-1)/k. Complete raw state count, metadata fields, variables/order, case index, cursor and state index are checked.
- Case-start is the sole explicit reset boundary and must immediately follow case-end except the first state. First before equals after; within-case before equals prior after. Semantic comparison does not mistake the previous case's final state for the new case's unsigned state.
- CLI requires cases, admission, inventory, source-root and input-root with no subset option. Failure returns a failed report and nonzero status. The successful report remains explicitly finite-record agreement-and-authority replay with symbolic premises and stated limitations.

## Limits and handoff

The17-test GREEN includes the existing ordinary and negative expected-history checks and the new focused raw-profile binding test. It does not establish complete package acceptance, all semantic/provenance mutant triples, actual producer execution, model checking, cryptography, or Council evidence. The direct CLI test establishes command entry only, not successful package validation. No missing producer artifact was fabricated.

The implementation/TDD skills preserved the compiling behavioral RED. Root's authorized CLI repair was based on a separately observed original failure, not a weakened import or package boundary. Source is frozen for root review and producer-pause release; root owns admission before any Task6 or actual package invocation.
