# A4 checker Task5 bounded execution

Task4 admitted94f5824e5e050011c7bea8c74a1e68d1e3a25a78. Execute Task5 only in
immutable independent-replay plan plus ab7c827 addendum. Own
scripts/check_s02_candidate_a_integrated.py and Task5 test append; prior checker
modules/tests stay exact. Own ignored unique task5 receipts/report. No commits.

Apply initializer-pin addendum: moriarty/__init__.py belongs to PYTHON_SOURCES
and FROZEN_EXTRA, SHA2566d6b58f9875c357d5d16858e55ce81edd1e56ecb1c5b28476c7a911cad2e1127.
Respect corrected78cases/1557events wherever relevant. Full producer source set
is still in progress; Task5 focused unit does not require actual package success.
Never weaken exact source/raw/receipt map admission to accommodate missing files.

Required compiling RED disables the raw field equality in bind_event. The
focused substituted-profile assertion must fail; restore only that check and
require complete current checker tests GREEN, no exclusions. Retain original
source/import/runtime closure and streams/argv/terminal outcomes before/after.
Use shared Task1 Python snapshot, unique fresh bytecode paths and no new archive
duplication. Producer files may be added concurrently but are not imported by
this focused unit; do not read moving unneeded sources into your unit snapshot.
Package admission itself retains the exact final required producer/checker pins.

Producer is pausing recorded commands for your source edit window. Please finish
Task5 source/RED/GREEN and report source freeze promptly; root will release that
pause only after independent review. No Task6 edits or actual-package invocation
until separately dispatched. No producer source, frozen Quint, main/wiki/DB,
evidence tree, index/commit or Foreman changes.
