# Independent A4 recorder lifecycle control intake

**Verdict: PASS for the four short-process controls. No blocking mismatch found.**

Reviewed original receipt root:
`.superpowers/sdd/a4-task6-lifecycle-controls-20260906/`.

| Artifact | SHA256 |
| --- | --- |
| `terminal.json` | `962c70aa8b73779e34a9fecee24b6ad4dc04a7a0e20317cd27c130ce9833fe5f` |
| `outer-tool-receipt.json` | `1b3a6c7badcf08594e43cf471e47c3ccb31e20e88b1f87836631e8f86db70887` |
| `artifact-index.json` | `2d36121b0bdb4bca9e2d3faee6c518d9ed5885374e85bbc38834a7adaec5ec36` |

Repository observation from independent read-only checks: all 47 indexed original
files match their recorded sizes/hashes, and the index covers exactly every file
other than itself. All three archived source copies match both before/after pins
and live frozen files: recorder `63d8f00d...dcf666`, controls `689d7675...ccd7c7`,
and unchanged RH002 cleanup helper `d8973d35...1d660d`. Every generated child.py
equals the complete CHILD source extracted statically from the archived controls.
Actual outer tool exit is zero; its emitted JSON equals retained terminal.json.

Experiment observations from original control records:

| Control | Authentic child exit | Forced cleanup | Eligible |
| --- | ---: | --- | --- |
| Normal completion | 0 | false | true |
| Exception after spawn | -15 | true | false |
| Zero-exit leader with surviving descendant | 0 | true | false |
| SIGTERM during wait | -15 | true | false |

All four retain complete cleanup with no cleanup errors, original stream hashes,
matching owned leader PID records, and observations that the leader was reaped.
The injected process-record exception is preserved as OSError and the absent
process-record file confirms the injection occurred. The signal control retains
RecorderInterruption and exactly the received SIGTERM. The descendant control
preserves the leader's true zero exit, an actually sent SIGKILL, absent descendant
state, and unchanged heartbeat size 245 to 245; the retained heartbeat is 245
bytes. These observations distinguish descendant cleanup from leader completion.

Experiment observation: all real children report optimization zero. Their command
inputs record removal of attempted inherited PYTHONOPTIMIZE, its absence from
the child environment, and nonoptimized parent flags. All stream bytes and flags
match the individual command terminals and control reports. Fallback cleanup was
not needed, and all frozen source hashes stayed stable.

Scope: this intake supports the revised recorder's tested normal, post-spawn
exception, surviving-descendant and signal-cleanup behavior. It does not establish
every possible host-failure behavior or exercise the entire A4 recorder modes.
Retained17 admission, fresh97 execution, aggregate114 admission and native final115
remain separate gates. No A4 semantic/native control was credited by these short
process experiments. No Council or A4-completion conclusion follows.

The reviewer inspected original records and ran read-only JSON/AST/hash/index
checks. No process control, recorder mode, pytest body, native command or solver
was executed or rerun during this review. Process absence statements above refer
to the retained original observations; no new signal or process probe was used.
