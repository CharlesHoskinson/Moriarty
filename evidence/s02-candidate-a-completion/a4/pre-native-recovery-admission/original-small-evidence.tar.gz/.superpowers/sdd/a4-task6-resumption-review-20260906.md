# Independent A4 Task6 recovery amendment review

**Spec verdict: PASS. Quality verdict: PASS for the amended procedure.**
No remaining planning blocker was found. This is not admission of the retained
17 controls, execution of the fresh 97, or completion of the preliminary gate.
The new recorder still requires its separate implementation review.

Reviewed SHA256 bindings:

| Artifact under `.superpowers/sdd/` | SHA256 |
| --- | --- |
| `a4-task6-resumption-plan-20260906.md` | `15bbb108e2a9cd3ce0c2d1fa458f0bcdb5fd9daf91dcc43976f23a3ac4015ab3` |
| `a4-task6-recovery-20260906.json` | `1437366a220d08a26506d189c508d6fdad21a6d978f724410fec2d6166432f9e` |
| `a4-task6-recovery-20260906.md` | `7771af73be3f24fac44671e2142207ab9cdde4c67940e9d3cb9b985eccb137e0` |

Repository observation: read-only checks verified the retained collection's
exit-zero stdout enumerates exactly 115 unique nodes. Removing only the exact
native-package node yields the reviewed 114-node inventory. The retained 17
and fresh 97 are individually unique, disjoint, exhaustive, and the fresh list
preserves collection order. No test bodies were executed during this review.

Repository observation: all 46 original source pins match current bytes. The
original source archive has exactly the same 46-member set, and each member
matches its recorded digest. Its SHA256 is
`ec66420dafcaa62948db74ba9c752196f021e39cc402a3c2e29526ef7357a723`.
The reviewer statically extracted the child runner string from the archived
test source and compared all 17 original child argv arrays exactly, including
interpreter, bytecode/cache options, script, test source, mode, mutation and
directory. Every retained small-record hash matches; every retained child
terminal is exactly exit zero with empty stderr and the matching JSON report.
All report fields satisfy the original parent assertions, including positive
changed-event count and successful raw linkage.

Repository observation from the pinned worker body: a semantic report is
returned only after effective mutation and changed-artifact checks, successful
raw/provenance linkage of the mutant, expected semantic rejection, corrected
acceptance and unrelated honest acceptance. Thus these child reports carry
the substantive assertions required by their parent test. They do not recover
the absent parent after-pins, summary, or exit. The original parent terminal
remains absent. The partial fabricated-cancellation triple receives no credit
and appears in the fresh complement in full.

Inference: an explicitly adopted 17-plus-97 aggregate can honestly establish
the amended preliminary coverage predicate if the remaining admission and
execution requirements all pass. It must be described as aggregate coverage,
not as a successful original parent run. The plan correctly preserves this
distinction and the delayed-endpoint provenance limitation. It does not claim
continuous historical source/runtime stability.

Remaining required implementation/admission work, not completed by this review:

- Stream-hash and inventory all retained generated artifacts, without following
  symlinks; bind each admitted node to its original parent/source and child
  records. Large data had only size/mtime inventory in the recovery observation.
- Reauthenticate original interpreter, environment manifest/archive and all
  3,329 runtime pins, with separate fresh before/after checks. This reviewer
  inspected those recovery claims and requirements but did not repeat the full
  runtime inventory verification.
- Implement and independently review the new recorder, exact partition and
  exclusive staging; then capture an authentic fresh exit-zero 97-pass receipt
  with no skips, xfails, omissions or changed source/runtime pins.
- Bind every required node to its authentic retained or fresh receipt before
  root admits the amended preliminary gate.

Resolved review finding: the earlier R004 argv allowed pytest's default shared
`.pytest_cache` writes despite requiring fresh paths. The reviewed final plan
explicitly disables the cache provider with `-p no:cacheprovider` for fresh
pytest invocations and includes it in the literal command shape. This changes
cache writes only and resolves the fresh-staging mismatch.

Repository observation: the actual native package controls, seven package
mutants, eight complete 78-shard/1,557-event honest traversals, full final
115-instance suite without deselection/skips, direct native CLI report, shared
regressions and non-author review remain required. The original source files,
recorder and interrupted evidence remain immutable; recovery creates separate
observations and fresh execution receipts. No native substitution, A4 completion,
Council acceptance, or actual-package result follows from this review.

Review activity consisted of source/plan/receipt inspection and read-only Python
JSON, AST and archive checks. No pytest collection or test body, native command,
compiler, checker or solver was invoked; no source or runtime was modified.
