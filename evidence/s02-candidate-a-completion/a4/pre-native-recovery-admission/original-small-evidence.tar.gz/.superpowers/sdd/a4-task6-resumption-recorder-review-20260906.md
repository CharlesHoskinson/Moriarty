# Independent A4 resumption recorder source review

**Spec verdict: PASS. Quality verdict: PASS for frozen source.**
No remaining source blocker was found. The four short-process controls still
require execution and intake before either recorder mode. This review admits
no retained control, fresh test result, aggregate coverage or native package.

Frozen artifact SHA256 bindings under
`.superpowers/sdd/a4-task6-resumption-20260906/`:

| Artifact | SHA256 |
| --- | --- |
| `recorder.py` | `63d8f00d024dbafb08fef0d48da96c91ca594bfe33476946ab0960bfd7dcf666` |
| `lifecycle_controls.py` | `689d767510ae4f3bf610b254bbdef7cd72600846e997593ab243484781ccd7c7` |
| `support.json` | `9da5267f46318171340d11cd6f25b3baebf98aa75b2312f23f8ecd9f12b76a93` |
| `receipt-supplement.md` | `01e663d18a91bc57414b319818b82c1e0cf868b31a5c94fbc2a88cc2c3905ca7` |

The controlling amendment remains SHA256
`15bbb108e2a9cd3ce0c2d1fa458f0bcdb5fd9daf91dcc43976f23a3ac4015ab3`;
the reviewed recovery inventory remains
`1437366a220d08a26506d189c508d6fdad21a6d978f724410fec2d6166432f9e`.
Root explicitly authorized the receipt-only JUnit addition and scoped process
cleanup. No test or checker body changes are part of these additions.

Repository observation: static checks confirm both Python sources parse, all
12 support pins match, and the partition remains identical to the reviewed
inventory. The pinned cleanup helper is included in support and stage archives.
Neither `admit17` nor `fresh97` existed during the frozen-source check.

Repository observation: `admit17` authenticates the original input/source archive,
all 46 source members/live pins, interpreter, environment manifest/archive and
3,329 runtime pins. It matches each original child's exact argv to the runner
string extracted from archived source, checks original terminal integer zero,
empty stderr, strict report identity/shape and every required success predicate,
then compares the original small-record hashes with recovery. It inventories
all original artifacts using chunked hashing and records symlinks without
following them. Small child records are rechecked after tree hashing. Original
parent exit remains null and delayed endpoint limitations are explicit.

Repository observation: `fresh97` requires successful retained admission and
rehashes the original artifact tree before running the exact reviewed complement.
Both modes independently recollect the full 115-node inventory without executing
test bodies at collection. Fresh execution uses exclusive stage/basetemp/cache
paths, disabled bytecode and pytest cache, and the exact 97 argv elements.
JUnit supplies the ordered executed-node identity check as well as rejection of
failure/error/skipped records; the authentic pytest exit and passed summary are
checked separately. The suite's flat function/parameter naming matches the
reviewed inverse of pinned pytest JUnit naming. The 16 fresh semantic/substitution/
locator subprocess receipts are individually validated. All 114 aggregate nodes
bind their retained or fresh original receipt, and the result remains a candidate
until successful outer source/runtime/support checks and root admission.

Resolved lifecycle finding: the earlier draft could catch a post-spawn exception
while leaving a child running. Frozen `run_command` creates an owned session and
uses the unchanged, hash-checked RH002 `group_exists`/`cleanup_group` implementation
on every post-spawn exceptional or surviving-group path. SIGTERM/SIGINT during
launch are deferred until ownership exists; signals cannot interrupt the bounded
cleanup phase. Authentic child returncode, monitoring error, received signals,
owned PGID and cleanup state remain distinct. Forced cleanup cannot be eligible
even when the original leader exited zero. Live or uncertain group status blocks
command stream hashing and outer artifact finalization; the stage is failed and
requires root takeover. SIGKILL/host-loss limitations remain explicit rather than
inventing terminal evidence.

Repository observation: the four source-only lifecycle controls cover normal
completion, an exception after real spawn, a zero-exit leader with a TERM-ignoring
descendant, and SIGTERM during wait. They check actual leader identity/reaping,
true returncodes, ineligibility of forced cleanup, descendant nonexecution and
heartbeat cessation. Incomplete cleanup, including an unreaped group zombie,
remains ineligible. Failed controls attempt cleanup only of recorded owned groups.
These controls do not invoke either A4 mode or semantic/native test bodies.

Assertion-integrity disposition: the new recorder requires optimization zero,
clears inherited `PYTHONOPTIMIZE` for children and records those facts. Original
17-child evidence lacks direct flag records, but source inspection resolves the
historical concern: `task6_rebind` unconditionally creates a new directory, writes
the required raw file only inside an assertion, then unconditionally hashes that
file. Optimized source execution would omit the writer and fail before a successful
report. Exact archived runpy source, fresh-directory provenance and authentic
successful child records support the recorded inference that assertions executed,
under the stated pinned-runtime and sole-writer assumptions. The reviewer retracts
the earlier hypothesized optimized-success path for this exact worker; no extra
historical test is required for that concern. The supplement correctly distinguishes
this inference from directly recorded historical flags.

Review activity: source, plan, support and pinned helper/pytest inspection;
read-only Python AST/hash/partition checks. No recorder mode, lifecycle control,
pytest collection/test body, compiler, simulation, checker or solver was invoked.
No original source/runtime/evidence was modified. All native-package and final
115-instance obligations, direct CLI, shared regressions and independent admission
remain outstanding. This is not Council approval or A4 completion.
