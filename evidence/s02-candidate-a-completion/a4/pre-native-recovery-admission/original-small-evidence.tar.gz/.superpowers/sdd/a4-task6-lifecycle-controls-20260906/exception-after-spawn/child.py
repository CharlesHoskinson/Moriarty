import json,os,signal,subprocess,sys,time
from pathlib import Path
folder,mode=Path(sys.argv[1]),sys.argv[2]
(folder/'child-flags.json').write_text(json.dumps({'optimize':sys.flags.optimize}))
if sys.flags.optimize!=0:raise RuntimeError('child inherited Python optimization')
(folder/'leader-pid.txt').write_text(str(os.getpid()))
if mode=='descendant':
    code="""import os,signal,sys,time
from pathlib import Path
folder=Path(sys.argv[1])
signal.signal(signal.SIGTERM,signal.SIG_IGN)
(folder/'descendant-pid.txt').write_text(str(os.getpid()))
while True:
    with (folder/'heartbeat.txt').open('a') as f:f.write('x');f.flush()
    time.sleep(0.02)
"""
    subprocess.Popen([sys.executable,'-B','-c',code,str(folder)])
    while not (folder/'heartbeat.txt').exists():time.sleep(0.01)
(folder/'ready.txt').write_text('ready')
if mode=='normal':
    print('normal-complete',flush=True)
elif mode=='descendant':
    print('leader-exits-with-live-descendant',flush=True)
else:
    time.sleep(30)
