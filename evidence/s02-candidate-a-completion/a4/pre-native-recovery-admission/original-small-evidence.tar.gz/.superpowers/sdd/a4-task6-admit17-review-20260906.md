# Independent A4 retained17 admission intake

**Verdict: PASS. No remaining logical or receipt-binding blocker to root admission
of the exact 17 retained controls under the adopted amendment.**

Reviewed root: `.superpowers/sdd/a4-task6-resumption-20260906/admit17/`.

| Artifact | SHA256 |
| --- | --- |
| `terminal.json` | `1db49479a8f3edb3ddd901978dc30ddb9f499dc992703adf1b5ea3193d9af075` |
| `retained-controls.json` | `b339b8095bed87c285c11d5a623a39885e897b8911fb03251b689aad7ef43d13` |
| `original-artifacts.json` | `043f61247e1fdafeab98d74ba9487e578aa386227da2855b9df28b805720ba7b` |
| `outer-tool-receipt.json` | `faf532af46ba5b1641a0c3f2a2a964b766a72085b569d9440b5b0b887eeec02d` |

Repository observation from independent read-only checks: the actual outer tool
exit and recorder terminal are both zero, with null error and no artifact
finalization block. The outer emitted summary matches the retained stage outcome.
The sole spawned command is collection-only: it returned the exact 115 unique
node IDs, with an eligible lifecycle, complete unforced cleanup and no monitoring
error. Removing the single exact native node reproduces the reviewed 114-node
inventory. No fresh97 execution is represented by this receipt.

Repository observation: the new source/support archive has exactly 59 unique
regular members, precisely equal to its input manifest. Every member's bytes,
size and SHA256 match. This includes the original source closure, new recorder
and support inputs; the original runtime archive remains an authenticated reused
reference. All top-level files pinned by the outer terminal match. The recorded
46 source and 3,329 environment before/after pin lists agree exactly and both
change lists are empty.

Repository observation: the 17 retained nodes exactly equal the reviewed retained
partition. The reviewer extracted the runner string statically from archived test
source and checked every child's entire argv, including interpreter, bytecode/cache
flags, script, source path, semantic mode, mutation name and directory. Every
original child terminal is zero, stderr empty, and report matches its retained
copy with positive effective mutation and all raw-linkage/rejection/corrected/
unrelated predicates true. All small-record bytes/hash bindings also match the
original-artifact manifest. The incomplete fabricated-cancellation triple receives
no credit and remains in the fresh complement.

Repository observation: manifest accounting is 318 regular files totaling
9,795,796,111 bytes, 88 directories and 16 symlinks. Root separately reported
successful live streaming rehash of this complete tree and live verification of
the 46 source plus 3,329 runtime pins, owned-file and child-record pins (tool chunk
`09cfac`). This reviewer verified manifest bindings and small files/archive members;
the 9.8 GB live rehash was not duplicated. Symlinks remain inventoried as targets,
not followed or admitted as substituted regular artifacts.

Evidence limitations remain explicit and unchanged. Original parent exit is null;
its terminal and artifact manifest are still absent. Recovery-time hashes and
delayed endpoint comparisons do not prove continuous historical stability. The
original assertion-integrity conclusion is recorded as a source-bound inference:
optimized runpy execution would remove the sole asserted raw-file writer and fail
the immediately following unconditional digest after fresh directory creation.
The successful archived child records support assertion execution under the stated
pinned-runtime/source/fresh-directory/sole-writer assumptions; no historical flags
were invented. This is the inference previously reviewed and accepted by root.

Scope: root may now record the exact 17 retained controls as individually admitted
preliminary evidence under the amended procedure. The original parent is not
declared successful. Fresh97, aggregate114 admission, actual native package,
final115 suite, direct CLI, shared regressions and remaining independent review
are still separate obligations. This intake is not A4 completion or Council.

Review activity was read-only JSON/AST/archive/hash comparison. No recorder mode,
pytest collection or test body, native command, checker or solver was executed
or rerun by this reviewer. Original evidence/source/runtime was not modified.
