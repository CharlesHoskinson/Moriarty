# A4 Task6 recovery observation — 2026-09-06 UTC

**Repository observation:** The original pre-native `green-tests` parent has no recoverable terminal result. It must remain an interrupted/incomplete parent receipt with unknown exit. Seventeen semantic children have original exit-zero records and complete success reports. No test was restarted during this recovery. The recommended continuation requires root review of a recovery amendment before any implementation.

## Scope and observation

This read-only audit covers `.superpowers/sdd/a4-task6-receipts/recorder.py`, the adopted sharded Task6 plan, the original `green-tests` receipts, and retained child artifacts. The adjacent recovery JSON is a new observation, not a replacement original receipt. It records exact child control records, source/runtime comparisons, artifact size/mtime inventory, and the complete collected test partition. Large original data files were not hashed or replayed in this audit.

- Original source HEAD: `5843ff69b73cd35972d37803e53759e25438108e`.
- Recovery HEAD: `a09d34a73c0872035e8ec5fb27983aea69a28a8b`.
- Original dispatch: `2026-09-05T20:47:35.578863+00:00`.
- All 46 original pinned source files match current bytes. The complete source archive hash matches the input receipt, and every archived source member matches its recorded digest.
- All 3,329 original runtime files match current bytes. The Python binary, environment manifest, and retained environment archive also match their original pins.
- Current checker SHA256: `b46af0796b9a6e868cfdbdde67b162ebc98d006daf9a07345d43c70290ff3bfd`.
- Current test SHA256: `b84ec39090328490f54f480da094852a0f27f600ff74f0c7931b2d65651c5db2`.

**Limitation:** These are delayed endpoint comparisons, not an original recorder `sourceAfter` or proof of continuous historical stability. The tracked test file remains modified relative to HEAD; it nevertheless matches the actual original dispatch snapshot. HEAD movement alone does not invalidate these exact source matches.

## Original process and terminal evidence

**Repository observation:** Host `ps` inspection found no matching Python recorder, pytest, or Task6 worker. The inspected receipts contain no parent PID/start-identity record that could support a later `wait`. There is no original `green-tests/terminal.json` or `artifacts.json`; stdout contains exactly 54 dots, stderr is empty, and no pytest summary survives. Process absence does not establish exit zero, a signal, or a cause of interruption. No process was signalled.

**Inference:** Sequential source order makes 54 dots consistent with the 37 preexisting checker instances plus 17 completed semantic triples. The dots do not identify individual tests or substitute for a terminal receipt. The recommended aggregate credits only the 17 separately recorded child results, and re-executes the 37 earlier checker instances.

The original recorder performs `subprocess.run` before writing its after-pins, artifact index, and terminal. Its absence after interruption therefore leaves those records missing. It cannot resume a pytest process. Rerunning its current `green-tests` mode encounters its exclusive stage-directory creation; forcing directory reuse would also threaten retained pytest basetemp files. Preserve the complete old tree.

## Exact control inventory

**Repository observation:** Collection only, with bytecode writes and pytest cache disabled, returned 115 unique node IDs. No test bodies executed. The JSON retains the command, streams, exit, all 114 pre-native IDs, the retained 17 IDs, and exact fresh 97-ID complement. Assertions establish disjointness and exact union.

| Category | Required pre-native | Terminal-backed original child results | Fresh complement proposed |
|---|---:|---:|---:|
| Preexisting checker controls | 37 | 0 | 37 |
| Semantic rebound triples | 27 | 17 | 10 |
| Latest-field substitution | 1 | 0 | 1 |
| Locator triples | 5 | 0 | 5 |
| JSON/carrier and path functions | 2 | 0 | 2 |
| Utility controls | 42 | 0 | 42 |
| Total | 114 | 17 | 97 |

The native package test is the additional 115th instance. It contains seven package mutation controls and eight honest complete-package traversals; it is excluded only from this pre-native gate.

Original completed semantic children, in execution order:

| Child index | Mutation | Changed events | Original child exit |
|---|---|---:|---:|
| 0 | `optional-zero` | 27 | 0 |
| 1 | `nonce` | 14 | 0 |
| 2 | `signer` | 25 | 0 |
| 3 | `token` | 25 | 0 |
| 4 | `revision` | 26 | 0 |
| 5 | `parent-paid` | 26 | 0 |
| 6 | `rejection-reason` | 19 | 0 |
| 7 | `rejection-stage` | 19 | 0 |
| 8 | `raw-reductions` | 10 | 0 |
| 9 | `claimed-reductions` | 24 | 0 |
| 10 | `effects-order` | 10 | 0 |
| 11 | `request-chooser` | 24 | 0 |
| 12 | `plan-omission` | 24 | 0 |
| 13 | `unused-program` | 27 | 0 |
| 14 | `signing-snapshot` | 27 | 0 |
| 15 | `concealed-rejection` | 1 | 0 |
| 16 | `omitted-computation` | 1 | 0 |

Each completed child retains matching exact argv, empty stderr, terminal `{"exit": 0}`, and a JSON report with matching mutation identity, positive effective-mutation count, raw linkage, rejected mutant, corrected acceptance, and unrelated acceptance. The pinned parent test asserts these same fields before emitting its pytest pass dot.

**Repository observation:** Child 17, `fabricated-cancellation-core`, has argv plus empty stdout/stderr and generated honest, mutated, normalized, raw, and bad case files. It has no terminal, report, corrected control, or unrelated control. Its last retained data-file mtime is `2026-09-05T23:34:20.957871+00:00`; mtime is not an exit time or proof of a semantic phase completing. Do not credit any part of this triple as a killed mutant.

Remaining semantic controls to execute in full:

`fabricated-cancellation-core`, `denial-as-transition`, `observed-guard`, `event-order`, `payment-order`, `deposit-effect`, `rollback-time`, `retained-loser`, `proof-context`, `cancellation-identity`.

The substitution, five locator, two carrier/path, and 42 utility instances have no retained started evidence in this original stage. The completed RED/import/syntax sibling receipts remain separate: import exit 0, behavioral RED pytest exit 1, restored syntax exit 0, each with empty recorded change lists. They do not fill the green-suite terminal gap.

## Safe continuation recommendation

1. Preserve the original roughly 9.80 GB stage, including partial child files, symlinks, streams, and all receipts. About 630 GiB was available on its filesystem when inspected. No cleanup or native work is part of recovery.
2. Root reviews the separate recovery amendment. The adopted plan literally requests a complete 114-instance pre-native command with terminal evidence. A 17+97 aggregate changes its evidence procedure and cannot silently satisfy that wording. The final complete 115-instance native requirement remains unchanged.
3. Before crediting the retained 17, independently verify original source/archive/runtime linkage, exact child argv/report/exit records, and stream-hash the retained artifact tree into a new recovery manifest. Label hashes with the recovery time; never backdate them or create a purported original parent terminal. Reject aggregate credit if any control/source linkage is missing or inconsistent.
4. Create a new recorder and new receipt/cache/basetemp paths after root authorization; preserve the original recorder unchanged. Execute the exact reviewed 97-node complement serially, including the incomplete triple from its beginning. Capture original command, source/runtime bytes or authenticated existing archive references, stdout/stderr, per-child originals, terminal exit, and before/after source stability.
5. Independently validate the 17 retained plus 97 fresh node IDs equal the full 114-node pre-native inventory, with no omissions, overlaps, skips, failures, or synthetic native substitute. Report aggregate coverage and the unknown original parent exit separately.
6. If retained child evidence fails admission, rerun only those unadmitted controls in further fresh recorded stages and maintain an explicit exact-114 partition. If root retains the original one-command acceptance rule, a fresh complete 114-instance run is necessary instead. In either case the later full 115-instance native suite and native CLI gate remain owed.

**Actions taken:** Read-only source/runtime/archive comparisons, process inspection, metadata inventory, and collection-only enumeration. Only this recovery report, its JSON, and the requested planning-only amendment were written. No source, helper, test, original evidence, or checkpoint database was changed; no test body ran; no commit was made.
