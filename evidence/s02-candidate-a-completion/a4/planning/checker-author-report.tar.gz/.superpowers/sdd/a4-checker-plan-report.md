# A4 Independent Replay Plan Author Report

Status: complete concrete plan draft, specified-only; root review/adoption pending.

Plan: `docs/superpowers/plans/2026-09-05-candidate-a-independent-replay.md`

SHA256: `2edb50ec93c88c62d8fddf1ba9d29b893e494b1564d28fdef6dd82674fca739e`

Author: `/root/a0_final_review`. This is the checker-plan author report, not an independent review of this plan and not Council evidence.

## Scope delivered

- Six reviewable implementation tasks with complete Python code/test blocks, exact interfaces, behavioral RED corrections, future verification commands and explicit-path task commit commands.
- Six new checker modules plus a dedicated test file; existing schema1 checker/Core helpers remain read-only imports.
- Strict immutable typed ITF carriers, decoded tuple/list distinction, raw-shape checks, duplicate JSON/map/set rejection and boolean/integer separation.
- Frozen Python Core bridge tests include actual Close refund and supplied-input rollback; no Quint evaluator is copied into the agreement checker.
- Independent common/A guard/update rules, lifecycle fixture/policy construction, full program/plan comparison and exact expected event histories.
- Independently enumerated fixed inventory: 78 cases and 1757 events (specified counts, not a runtime measurement). All ordinary profiles, retained stale histories, negative records, replay probes and parent probes are required.
- Separate actual second deterministic Core computation records versus adversarial claimed projections; cancellation has no Core computation payload.
- Exact raw adjacent-state provenance, latest-event/full-history continuity, explicit resets, admitted source/import/tooling/input/receipt byte sets and no subset CLI mode.
- Twenty-seven semantic mutant families with full raw/provenance rebinding, corrected counterpart and unrelated honest controls; separate raw locator/field/carrier/source/inventory controls and mandatory actual complete-package integration tests.

## Cross-plan interface agreements

Producer owner `/root/execution_adversarial_tests` confirmed the full profile suffixes, exact control literals, scenario-major/profile-minor order, five-field descriptors, guard/command wrapper, derivation base sequence/stage, three case-end statuses, computation cardinality, extraction wrapper, two raw filenames, module paths, inventory schema and root-admission boundary.

The only outer scalar conversion is `sequence`, from a strict decoded raw ITF integer to a plain JSON integer. Nested arguments/computations/before/after remain raw value-exact. The checker binds sequence by strict integer equality and every other event field by raw JSON value equality.

Control suffix proposals and evidence/rejection boundaries use direct common/A guards; ordinary prefixes retain actual lifecycle guard variants. No-cancel recovery preparation denial remains the stricter installment lifecycle guard. This distinction prevents adding or removing lifecycle preconditions by relabeling a probe.

## Self-review changes

- Corrected direct `FinancialGuard` to call exactly `operationFinancialGuard` semantics, without invented context-validity or operation-validity conjuncts. Parent transfer identity/quantity, cancellation identity, recovery allowance/cancellation/escrow equality and non-parent nonempty effects match frozen `execution.qnt`.
- Checked rejection priority against frozen common/A: A coupling/fidelity/evidence-policy mismatch; stale bindings; invalid context/operation; missing evidence; invalid evidence; genuine known Core rejection; consumption conflict; unauthorized fallback.
- Added immediate tuple/list carrier negatives and actual Core bridge tests after root review.
- Corrected empty `EffectsExtractedA` list encoding, reset-before handling, strict metadata/source identity and imported checker origin checks.
- Added payment-order, deposit-effect, rollback-time, retained-loser, proof/context and cancellation-identity mutant families. Mutation setup requires changed canonical bytes before rebinding and cannot count a no-op as a killed mutant.
- Removed future fixture dependencies from the Task2 behavioral RED and added a self-contained Task5 provenance RED test.

## Limitations and open gates

- No implementation code was created, no embedded code was executed, no tests were run and no commits/index/session-status changes were made by this task. Only the assigned plan and this ignored report were written.
- The checker is intentionally a fixed-inventory finite-history checker, not acceptance of arbitrary authority traces, exhaustive correspondence, cryptographic verification or model checking.
- Root admission is an explicit byte-identity trust input, not authentication that a generator command ran. Root still audits original runtime receipts and complete admitted closures.
- The independent Core helper and its existing shared authorship are disclosed and pinned; checker-plan independence from the new producer does not rewrite that provenance.
- All six implementation gates, actual producer acceptance, behavioral RED/GREEN, mutation effectiveness and non-author source review remain future work. The expected counts have not been measured by this planner.
- Parent/root owns plan adoption, source/code assembly checks, implementation dispatch, broader A4 acceptance and integration.

No known remaining plan blocker was found in the final static self-review. This statement is an author finding, not independent acceptance.
