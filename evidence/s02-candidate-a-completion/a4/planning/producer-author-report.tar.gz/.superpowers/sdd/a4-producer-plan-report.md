# A4 producer plan handoff

Status: planning-only, ready for root review. No implementation, new Quint typecheck/test/run, behavioral RED/GREEN, export acceptance, commit, Council or integration was performed by this task.

Owned plan: `docs/superpowers/plans/2026-09-05-candidate-a-integrated-producer.md`.
Current plan SHA256: `edca754fafb2bba2ef4ead9fb97fa887e60aeb69bcd5890c0f0ca705e6d3d1f6`.
Earlier pre-runtime-correction handoff SHA256: `7d88b0af2a673c0a33157ca71271129c73b172f1a584f18a5aab551724733dc1` (superseded planning revision, not execution evidence).

Repository observations:

- A3 pre-dispatch anchor, confirmed by `git rev-parse 926b350`: `926b350cc4f5943dcf5555c091c58b8782b797e9`.
- Adopted design commit: `effb7af64918727fe105e49b61f4318113439c7e`; current design SHA256 `8de059dce852b3d0649af00e08586bab08f86b65cde4de8dd8f0ec8e55846ea7`.
- Main completion XML SHA256: `f185e1ec35dfff8c89c5eb962be6e46b9614b0ae603af8a1bdf232287c871c91`.
- Only this report and the owned producer plan were written. Other agents' source, adopted checker plan, evidence and main-worktree files were not changed.

The writing-plans skill determined the concrete task/file/interface structure, full code/test blocks, explicit source-byte RED/GREEN capture steps and self-review. Root already selected the execution workflow; no extra provider or worker dispatch occurred.

## Fixed interface

The separate checker planner and root agreed on the following interface:

- 78 cases: 32 installment and 46 swap. Exact full-profile suffixes and control spellings match the checker plan.
- 1,557 events: installment638 and swap919. Exact batch bounds are637 and918steps.
- Canonical inventory SHA256: `8a1a6136afc9fda3c29e050df8b80144750cc21365e9194924401c155dc6402b`.
- Root inventory is descriptor-five-fields plus event_count. Producer-private selectors specify every fixed event; they cannot shrink the submitted inventory.
- Raw authorityState/latestEvent/caseIndex/cursor; adjacent before/after positions; scalar outer sequence is losslessly decoded from raw #bigint, while all nested payloads remain raw value-identical.
- Generic fullargs plus explicit lifecycle/direct guard discriminator. Control suffixes use direct common/A guards; ordinary prefix guards remain lifecycle-specific.
- Computation extraction wrapper is ExtractionObservedA4(raw extraction) or ExtractionNotApplicableA4. Cancellation computations are empty. Diagnostics retain the actual request/evaluation or adapter diagnostic and cannot satisfy the fixed acceptance inventory.
- Input root holds the two raw ITFs plus root-admitted receipt-relative paths. No receipt-root flag. Individual admitted pins are checked, source closure is exact, and undeclared extra ITFs fail.
- Python source closure includes moriarty/__init__.py; root owns the narrow immutable checker-plan addendum for this strengthening and the count correction.

## Planning corrections preserved

Both planners initially made the same arithmetic mistake: swap control rows were summed as591 instead of391. Root executed the literal producer enumerator and found78cases/1,557events, not1,757. The displayed individual family rows were correct; no case or selector was removed. The author independently reran the pure enumerator and corrected every active total and swap bound. The earlier arithmetic is disclosed in the plan rather than erased from the process history.

Root review also caused these plan-only corrections: disabled action branches explicitly assign unchanged values to all four variables; normal terminal never evaluates an out-of-range next case; Task0 recorder precedes Task1 RED; Task1 tests immediately import the observer; producer/checker IDs and receipt layout are identical; package init belongs in source pins. Installed Quint supports the displayed plural --invariants flag.

A read-only syntax-check attempt using bare `python` terminated127 with `/bin/bash: line 1: python: command not found`. Commands now name `/home/charl/Moriarty/.venv/bin/python`. An intermediate AST scan found an accidental literal backslash-n in a plan code block; it was corrected, along with obsolete receipt_root references. Neither is a behavioral RED. The final scan below asserts no syntax errors.

## Final read-only plan validation

Command cwd: `/home/charl/Moriarty/.worktrees/s01-audit-start`.
Only the pure inventory and renderer functions were executed in memory. Python code blocks were AST-parsed, not installed. Generated Quint text was counted in memory and never written as source.

```bash
/home/charl/Moriarty/.venv/bin/python -c 'import sys,re,ast,hashlib,json; text=sys.stdin.read(); blocks=re.findall(r"```python\n(.*?)\n```",text,re.S); errors=[]
for i,b in enumerate(blocks):
 try: ast.parse(b)
 except SyntaxError as e: errors.append((i,str(e)))
print("Python blocks:",len(blocks),"syntax errors:",errors)
assert not errors
env={}; exec(next(b for b in blocks if b.startswith("from itertools import product")),env); cases=env["inventory"]()["cases"]; print("cases",len(cases),"events",sum(c["event_count"] for c in cases)); print("lifecycle",{life:(sum(c["lifecycle"]==life for c in cases),sum(c["event_count"] for c in cases if c["lifecycle"]==life)) for life in ("installment","swap")}); print("controls",sum(c["event_count"] for c in cases if c["lifecycle"]=="swap" and c["control"] not in ("ordinary","verified-stale"))); print("canonical inventory sha256",hashlib.sha256(json.dumps(env["inventory"](),sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()).hexdigest()); exec(next(b for b in blocks if "def quint_instruction(" in b),env); exec(next(b for b in blocks if b.startswith("def checked_quint_instruction")),env); rendered=env["quint_cases"](); print("rendered descriptors",rendered.count("descriptor: {"),"rendered bytes",len(rendered.encode())); print("Quint named tests",len(re.findall(r"^run (\w+Test)",text,re.M))); print("No behavior source files written")' < docs/superpowers/plans/2026-09-05-candidate-a-integrated-producer.md
```

Terminal output, exit0:

```text
Python blocks: 14 syntax errors: []
cases 78 events 1557
lifecycle {'installment': (32, 638), 'swap': (46, 919)}
controls 391
canonical inventory sha256 8a1a6136afc9fda3c29e050df8b80144750cc21365e9194924401c155dc6402b
rendered descriptors 78 rendered bytes 134708
Quint named tests 11
No behavior source files written
```

Read-only inspection also queried installed `quint parse --help`, `quint run --help`, and parsed the already-existing swap lifecycle through stdout to inspect actual type IR. Those terminal0 parser observations support the planned structural decoder interface only. They do not typecheck or validate the proposed observer/driver code.

## Handoff limits

Plan self-review covers adopted design R01–R05: fixed inventory and source-produced events (Tasks1–2); complete actual computation payload and cancellation separation (observer); strict carrier/position/admission validation (Task3); immutable terminal/source capture (Task0); independent checker/mutation intake and review (handoff gates). All proposed model/runtime predicates remain specified-only until root adopts and dispatches implementation.

This author previously wrote model/lifecycle units. The checker planner/implementer is separate for A4; this task coordinated literal interfaces only and did not author its semantic replay. No cross-vendor or Council independence claim is made.

## Narrow runtime correction and final freeze

Root's focused review identified that the earlier recorder pinned only tool entry files before execution, did not retain the imported Quint runtime closure, allowed stale Python bytecode, and could return success after a source change. The receiving-code-review skill guided a correction against the actual shared helper interface; this is still plan editing, not a new behavioral implementation.

Task0 now consumes the A5-owned shared runtime store and existing Python archive. It imports the separately hash-bound `scripts/run_s02_candidate_a_factoring_pilot.py` and calls `verify_runtime` with the A5 dispatch base. A separate root-created producer dispatch records the producer's own full pre-dispatch commit. Each command records its current sourceCommit independently. Neither the helper nor runtime files enter semantic source_pins; the exporter/checker envelope is unchanged.

The planned recorder checks all admitted current runtime files and tree membership before and after each command; retains the original helper bytes in its stage; invokes actual resolved Node plus pinned Quint CLI; requires a fresh stage-specific Python cache prefix with bytecode writes disabled; and returns2 if either source or runtime closure moves. Requested argv and executed argv remain separately recorded. The exporter requires stable terminal receipts and the explicit Node/CLI argv binding. Every displayed recorder command now supplies the required -B and -X flags. No duplicate runtime store was created by this author.

Root reported successful independent admission of the A5 store during this final planning pass:4758runtime files plus3329Python records. These are root-reported admission facts, not a repeated archive audit by this author:

- Runtime manifest SHA256: `fa3e9838c66480557ed6d928a2d159ebc074d05f67f15ef08ab20388d9c49e0b`.
- Runtime archive SHA256: `f0687656d30c0d59ece8dfd027508a9228020506d29b97aea3abe7568186c31c`.
- Shared dispatch SHA256: `393a8aa904bcd9473670ac48934b3dca4ed611ca9b9accbfa94f15bb4798ac2f`.
- Shared helper SHA256: `816c3ad79dc3a67ca9a03729af56d74188c161a7546b9c43e821c222a4bce7f2`.

The final read-only validation repeated the complete command printed above with `-B` added immediately after the Python executable; the subsequent command was `sha256sum docs/superpowers/plans/2026-09-05-candidate-a-integrated-producer.md`. Terminal exit0, full output:

```text
Python blocks: 14 syntax errors: []
cases 78 events 1557
lifecycle {'installment': (32, 638), 'swap': (46, 919)}
controls 391
canonical inventory sha256 8a1a6136afc9fda3c29e050df8b80144750cc21365e9194924401c155dc6402b
rendered descriptors 78 rendered bytes 134708
Quint named tests 11
No behavior source files written
edca754fafb2bba2ef4ead9fb97fa887e60aeb69bcd5890c0f0ca705e6d3d1f6  docs/superpowers/plans/2026-09-05-candidate-a-integrated-producer.md
```

The plan and report are now frozen for root admission. No recorder command, proposed model test, runtime-verifier invocation, or new archive was executed by this planning correction. No commit was made.
