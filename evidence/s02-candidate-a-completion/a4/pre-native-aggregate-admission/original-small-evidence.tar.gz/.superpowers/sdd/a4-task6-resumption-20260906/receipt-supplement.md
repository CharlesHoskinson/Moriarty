# Root-authorized receipt supplement and concrete source review

This supplements the adopted recovery amendment SHA256 `15bbb108e2a9cd3ce0c2d1fa458f0bcdb5fd9daf91dcc43976f23a3ac4015ab3`. Its original bytes remain in the parent plan and `reviewed-amendment.md`. The exact 17/97 partition and recovery inventory SHA256 `1437366a220d08a26506d189c508d6fdad21a6d978f724410fec2d6166432f9e` are unchanged.

## Authorized receipt-only argv addition

Root authorized appending `--junitxml=<absolute-fresh97-stage>/junit.xml` to the reviewed fresh97 command. This writes an original pytest report that identifies each executed parameter instance. It does not select or alter any test. The recorder requires the XML's 97 ordered node IDs to equal the reviewed fresh complement, rejects failure/error/skipped entries, checks the pytest passed summary, and binds the XML and original exit receipt into every fresh node's aggregate record. `-p no:cacheprovider` remains in all pytest commands.

## Concrete implementation and ownership

Only new ignored files under `.superpowers/sdd/a4-task6-resumption-20260906` are introduced: `recorder.py`, `partition.json`, `reviewed-amendment.md`, `receipt-supplement.md`, `support.json`, and `lifecycle_controls.py`. All original recorder/evidence/test/helper/source/runtime bytes remain untouched. `support.json` pins every source-support input, including the new recorder itself, the original input/source archive/streams, the reviewed recovery inventory, and original/copied plan. Each stage archives these small support/source bytes and pins the support manifest separately. The runtime archive is checked and reused without duplication.

Recorder functionality follows the original recorder's streaming file pins, source archive, environment reuse, source/runtime endpoint comparisons, original subprocess streams, and exclusive writes. The new explicit modes keep retained admission separate from fresh test execution:

1. `admit17` verifies 46 original source pins, 3,329 runtime pins, interpreter, environment archive/manifest, original source archive members, and exact reviewed partition; recollects all115 node IDs without executing test bodies; validates each of17 archived-source-bound child argv/report/exit records against recovery hashes; checks retained generated paths/sizes; hashes the entire original stage with chunked reads and symlink-safe traversal; records individually admissible retained controls plus delayed endpoint limitations.
2. `fresh97` requires a successful separate `admit17` outer terminal and exact retained evidence/owned-file bindings, rechecks/re-hashes those originals, recollects the identical115 inventory, then executes only the97 explicit node IDs. It retains original pytest command/process/streams/exit, JUnit, all generated artifacts, and16 fresh subprocess control records (10 semantic,1 substitution,5 locator). It builds an exact114 per-node aggregate candidate using17 retained and97 fresh results.

The old parent exit is always null. A successful child or aggregate candidate never supplies a missing old parent exit. The aggregate candidate requires the new outer terminal to succeed after source/runtime/support stability checks and remains subject to root admission. Native final115 remains mandatory.

Exclusive mode directories prevent accidental reuse. The modes cannot resume an interrupted stage; later retries require a separately reviewed fresh sibling root and partition if needed. Parent and subprocess cache paths must be nonexistent, and `-B` disables bytecode writes. Every pytest invocation disables the cache provider. The recorder's exact pinned virtualenv interpreter, parent `sys.orig_argv`, actual dispatch HEAD, subprocess PID/argv, original exit, and support/source archive are retained.

Every command now starts in an owned new session. The recorder reuses the exact admitted `group_exists` and `cleanup_group` from `evidence/s02-candidate-a-completion/a4/native-resources/runner.py`, SHA256 `d8973d3541269d1be2ce524f2482e5f5b858f15f7d9117e3fe6d5cd2171d660d`; that source is included in support pins and stage archives. Every post-spawn path, including process-record write failure, wait exception, SIGTERM/SIGINT interruption, and ordinary leader exit with surviving descendants, reaches a finally block. A remaining/uncertain group or any monitor exception triggers bounded owned-group SIGTERM then SIGKILL/reaping through the admitted helper. Repeated signals cannot bypass the cleanup block. Authentic child returncode, received signals, monitor errors, owned PGID, and complete/forced/error cleanup state are retained separately. Forced, failed, or incomplete cleanup is never eligible, even when the leader actually exited zero.

Cleanup state is published in memory before subsequent receipt writes or hashes can fail. If cleanup is incomplete or uncertain, both the command and outer stage block artifact finalization: streams remain original and unhashed, no artifact manifest/admission may be finalized, and root takeover is required. SIGKILL or host loss may prevent any final record; missing records remain incomplete and root must inspect recorded owned PIDs before retry. Only the owned process group is signalled. No artifact cleanup/deletion is implemented.

All new command environments remove `PYTHONOPTIMIZE` and record its removal/presence state; recorder startup requires `sys.flags.optimize == 0` and records the parent flags. The archived17 receipts lack direct optimization flags/environment. Their accepted behavioral inference is explicit: archived `task6_rebind` first creates a fresh directory, creates its raw file only inside an assertion, and immediately hashes that file unconditionally. Optimized runpy execution removes the writer and fails before a successful child report. The recorder checks that archived source structure and records the inference, its standard pinned-runtime/new-directory/sole-writer assumptions, and the absence of direct historical flag evidence. It does not invent historical flags.

`lifecycle_controls.py` defines four bounded real-process controls: normal exit, injected post-spawn process-record failure, zero-exit leader with a SIGTERM-ignoring heartbeat descendant, and SIGTERM during wait. Each intentionally sets inherited `PYTHONOPTIMIZE=2` and checks the command clears it and the real child records optimize zero. Controls inspect only recorded owned PIDs and heartbeat stability; zombies count as non-running but remain incomplete group cleanup and never eligibility. Control failures attempt scoped cleanup of their own recorded groups. Outputs go exclusively to the new sibling `.superpowers/sdd/a4-task6-lifecycle-controls-20260906`. Neither A4 recorder mode nor any semantic/native test is invoked by these controls.

## Review and dispatch

Root must verify `support.json` and recorder hashes against the accepted source review before invocation. Source-only implementation is complete; neither mode has been invoked. Source-only syntax compilation has succeeded. No runtime test, lifecycle control, large artifact hashing, or retained-control admission has been performed by this implementation worker. Root reviews the frozen control source and separately authorizes its invocation.

From the experimental worktree root, the separately authorized commands are:

```
/home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/a4-task6-resumption-20260906/recorder-cache-admit17 .superpowers/sdd/a4-task6-resumption-20260906/recorder.py admit17
/home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=/home/charl/Moriarty/.worktrees/s01-audit-start/.superpowers/sdd/a4-task6-resumption-20260906/recorder-cache-fresh97 .superpowers/sdd/a4-task6-resumption-20260906/recorder.py fresh97
```

These are distinct execution gates. Root reviews the concrete recorder before authorizing either. Fresh97 follows the A5 heavy native stages and any applicable source freeze; it must not overlap conflicting source edits or heavy native work. There is no command here that executes the deferred actual package test or grants native admission.
