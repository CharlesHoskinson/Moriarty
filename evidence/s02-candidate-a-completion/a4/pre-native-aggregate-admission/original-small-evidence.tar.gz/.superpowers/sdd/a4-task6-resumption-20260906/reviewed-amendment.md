# A4 Task6 pre-native recovery amendment — planning only

**Status:** Proposed for root review. This document authorizes no recorder implementation, test execution, source change, native export, or evidence admission. Root owns release and independent review. It amends only the interrupted pre-native green gate; all native and final full-suite obligations remain.

## Problem and scope

The original `green-tests` parent stopped without a terminal receipt. Recovery found 17 individually recorded semantic child exits/reports under unchanged original source/runtime pins, one incomplete child, and no complete parent result. Repeating the successful expensive semantic triples is avoidable only if root explicitly admits those child results into a new aggregate with complete provenance. The old parent remains exit-unknown.

Controlling sources are the adopted independent replay Task6, replay-interface addendum, case-sharded transport section 6, and sharded-adversarial plan. This amendment supersedes only the single-command form of the pre-native 114-instance green gate. It preserves all 114 required test instances, all 27 semantic triples, and the later 115-instance native final run with no deselection or skips.

## Fixed artifacts and ownership

- Original immutable root: `.superpowers/sdd/a4-task6-receipts/green-tests`.
- Original input source HEAD: `5843ff69b73cd35972d37803e53759e25438108e`.
- Original source archive SHA256: `ec66420dafcaa62948db74ba9c752196f021e39cc402a3c2e29526ef7357a723`.
- Original recorder remains unchanged at `.superpowers/sdd/a4-task6-receipts/recorder.py`.
- Unchanged checker SHA256: `b46af0796b9a6e868cfdbdde67b162ebc98d006daf9a07345d43c70290ff3bfd`.
- Unchanged test SHA256: `b84ec39090328490f54f480da094852a0f27f600ff74f0c7931b2d65651c5db2`.
- Proposed fresh root: `.superpowers/sdd/a4-task6-resumption-20260906`; fail rather than reuse if it exists. Any later retry uses a new unique sibling root.
- Proposed new recorder: `<fresh-root>/recorder.py`; proposed stage `<fresh-root>/fresh97`, pytest basetemp `<fresh-root>/fresh97/basetemp`, child cache `<fresh-root>/fresh97/fresh-pycache`, parent cache `<fresh-root>/recorder-cache-fresh97`. All must be new; Python executes with `-B -X pycache_prefix=<exact-absolute-path>`.
- The existing 3,329-file environment archive is reused by authenticated hash, not duplicated. Original source closure remains separately checked in full; new recorder/amendment/partition files receive additional pins rather than replacing old pins.
- Root authorizes and reviews the new recorder before dispatch. No source mutation window is opened: checker, tests, shared utility, producer, authority, and frozen modules stay byte-identical to their admitted snapshots.

## EARS requirements and OpenSpec scenarios

### R001 — Preserve the interrupted original

The recovery recorder SHALL retain every original parent and child artifact unchanged, including partial child 17, and SHALL record `originalParentExit: null` and its missing-terminal reason. It SHALL NOT write an original `terminal.json`, fabricate an exit, overwrite streams, reuse basetemp, or relabel a recovery-time hash as an original completion-time hash.

Scenario: WHEN the original terminal does not exist THEN the aggregate reports unknown original parent exit while assessing each child separately. Absence of a host process never supplies a successful exit.

### R002 — Authenticate the 17 retained controls

Before crediting an original child, the admission step SHALL verify the original `input.json` and source archive hash, every archived source member, all 46 current source pins, interpreter bytes, all 3,329 runtime pins, and environment manifest/archive hashes. It SHALL validate the exact original child argv against the archived `task6_process` construction, including test-file path, mode, mutation, directory, bytecode flags, cache path, and runner script. It SHALL require child terminal exactly exit zero, empty stderr, valid matching JSON report, positive changed-event count, and every original parent success assertion.

The admission step SHALL bind each retained node ID to its original parent input, exact source archive and test source, original argv/stdout/stderr/terminal hashes, and all retained generated files. It SHALL stream-hash data files, inventory directories and symlink targets without following symlinks, and retain original bytes in place. It SHALL disclose that original parent after-pins and terminal were absent and that recovery pin checks are delayed endpoint observations. It SHALL NOT use a new replay to invent missing original evidence.

Scenario: WHEN any child record is missing, inconsistent, or mismatched THEN that node receives no retained credit and must join a newly reviewed fresh partition. WHEN the incomplete fabricated-cancellation child has bad files but no report/terminal THEN its entire triple executes again from the beginning.

### R003 — Exact partition and complete coverage

The coordinator SHALL independently collect both unchanged test files with `--collect-only`, bytecode writes disabled, and pytest cache disabled. It SHALL verify 115 unique node IDs, remove only the exact native package node for the pre-native inventory, and compare the resulting 114 IDs with the reviewed JSON partition. It SHALL require the exact 17 retained IDs below and the exact 97 fresh IDs in the JSON to be disjoint with union equal to all 114. A count alone does not satisfy this requirement.

Scenario: WHEN collection differs from the reviewed inventory or any duplicate/missing node exists THEN execution and admission stop for root review. No `-k` substring approximation may select the fresh complement.

### R004 — Fresh execution and complete original receipts

The new recorder SHALL execute all 97 exact node IDs from `partition.freshComplementNodeids` as explicit pytest argv elements, in collected order, in a single sequential parent with existing per-triple subprocess isolation. It SHALL pin and retain its own bytes, exact `sys.orig_argv`, parent/child argv, source/runtime closure, environment overrides, collection/partition bytes, original stdout/stderr, original terminal, before/after comparisons, and every generated artifact. It SHALL explicitly clear `PYTHONPATH` and `PYTEST_ADDOPTS`, preserve declared import configuration, disable bytecode and the pytest cache provider (`-p no:cacheprovider`) in every fresh pytest invocation, and use only fresh paths. Disabling the cache provider changes cache writes only; it does not change test selection. It SHALL record actual dispatch HEAD without substituting a historical narrative base.

The reviewed command shape is `[PYTHON, '-B', '-X', 'pycache_prefix='+FRESH_CACHE, '-m', 'pytest', '-q', '-p', 'no:cacheprovider', *EXACT_97_NODEIDS, '--basetemp='+FRESH_BASETEMP]`. The recorder's exact implementation and argv are reviewed before execution. No helper/source/test change, parallel execution, timeout-as-success, skipped instance, xfail, mutant omission, or native substitution is permitted.

Scenario: WHEN fresh execution returns nonzero or is interrupted THEN preserve all streams and artifacts and admit no invented parent success. WHEN source/runtime pins change THEN reject admission regardless of pytest exit.

### R005 — Admission and final obligations

The independent reviewer SHALL admit pre-native coverage only after verifying all 17 retained controls and a fresh original exit-zero receipt with exactly 97 executed/passed instances, no skips/xfails/failures, and stable source/runtime pins. The aggregate SHALL retain separate original-parent unknown exit, retained-child statuses, and fresh-parent status. It SHALL bind every one of the 114 IDs to its specific authentic receipt.

Scenario: WHEN 17 retained plus 97 fresh controls pass all receipt predicates THEN root may admit the amended pre-native gate, without claiming the old parent succeeded or A4 completed. WHEN actual native package artifacts are absent THEN native admission and the final full 115-instance run remain blocked; the aggregate does not substitute for them.

The later actual-package seven mutants, eight honest 78-shard/1,557-event traversals, full 115-instance suite with zero deselection/skips, direct native CLI report, shared regressions, and non-author review SHALL remain exactly as required by the adopted plan.

## Review and execution gates

1. Root reviews this amendment and the recovery observations; records explicit adoption of the aggregate procedure.
2. An authorized worker implements only the new recorder/partition and recovery manifest; root independently reviews source closure, exclusive path creation, stream hashing, exact argv, and failure preservation before any test execution.
3. Root admits retained 17 individually. The delayed provenance limitation is an explicit acceptance decision. If any record fails, root revises the exact partition and reruns only unadmitted nodes in fresh stages; never silently adjusts counts.
4. Immediately before dispatch, assert old source/runtime pins still match, collection exactly matches the inventory, source changes are frozen, storage is sufficient, and no conflicting A4 source-edit or heavy native work overlaps.
5. Run the fresh exact complement and preserve its originals; independently review all 114 per-node evidence bindings.
6. Record amended pre-native admission only if every predicate succeeds. Continue the original native program after its separately required source/admission prerequisites.

No duration estimate or continuous historical stability claim is implied. Recovery currently provides complete small-record hashes and only size/mtime inventory for large data; the new streaming hash manifest is still required.

## Exact retained exclusions (17)

These node IDs are excluded from fresh execution only after successful individual admission:

```
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[optional-zero]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[nonce]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[signer]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[token]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[revision]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[parent-paid]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[rejection-reason]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[rejection-stage]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[raw-reductions]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[claimed-reductions]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[effects-order]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[request-chooser]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[plan-omission]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[unused-program]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[signing-snapshot]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[concealed-rejection]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[omitted-computation]
```

## Exact complete partition artifact

`a4-task6-recovery-20260906.json` is the independently collected inventory. Its `partition.requiredPreNativeNodeids`, `partition.retainedOriginalChildNodeids`, and `partition.freshComplementNodeids` enumerate every exact node, including parameter IDs. The original collection command/streams/exit are retained in `collectionOnly`. The 97 fresh nodes comprise 37 prior checker, 10 semantic, 1 substitution, 5 locator, 2 carrier/path, and 42 utility instances. The artifact SHA256 at plan preparation is `1437366a220d08a26506d189c508d6fdad21a6d978f724410fec2d6166432f9e`.

The exact 97-node fresh list follows for reviewer visibility:

```
tests/test_s02_candidate_a_integrated.py::test_duplicate_map_rejected
tests/test_s02_candidate_a_integrated.py::test_unknown_fields_and_boolean_integer_rejected
tests/test_s02_candidate_a_integrated.py::test_absent_is_not_zero
tests/test_s02_candidate_a_integrated.py::test_list_and_tuple_carriers_are_not_interchangeable
tests/test_s02_candidate_a_integrated.py::test_frozen_oracle_close_refund_and_rollback
tests/test_s02_candidate_a_integrated.py::test_uncoupled_rejection_is_reachable
tests/test_s02_candidate_a_integrated.py::test_transfer_order
tests/test_s02_candidate_a_integrated.py::test_independent_initial_coupling
tests/test_s02_candidate_a_integrated.py::test_independent_ordinary_routes[installment-scenarios0-SignAfterResolve]
tests/test_s02_candidate_a_integrated.py::test_independent_ordinary_routes[installment-scenarios0-SignBeforeResolve]
tests/test_s02_candidate_a_integrated.py::test_independent_ordinary_routes[swap-scenarios1-SignAfterResolve]
tests/test_s02_candidate_a_integrated.py::test_independent_ordinary_routes[swap-scenarios1-SignBeforeResolve]
tests/test_s02_candidate_a_integrated.py::test_complete_parent_program_plan
tests/test_s02_candidate_a_integrated.py::test_inventory_is_not_submission_defined
tests/test_s02_candidate_a_integrated.py::test_denials_rejections_and_derivations_are_distinct
tests/test_s02_candidate_a_integrated.py::test_observed_raw_is_not_forged_projection
tests/test_s02_candidate_a_integrated.py::test_binding_checks_observed_field
tests/test_s02_candidate_a_integrated.py::test_sharded_window_profile_red
tests/test_s02_candidate_a_integrated.py::test_sharded_bounded_matches_buffered[36]
tests/test_s02_candidate_a_integrated.py::test_sharded_bounded_matches_buffered[37]
tests/test_s02_candidate_a_integrated.py::test_sharded_raw_controls[ordinal]
tests/test_s02_candidate_a_integrated.py::test_sharded_raw_controls[cursor]
tests/test_s02_candidate_a_integrated.py::test_sharded_raw_controls[index]
tests/test_s02_candidate_a_integrated.py::test_sharded_raw_controls[status]
tests/test_s02_candidate_a_integrated.py::test_sharded_raw_controls[vars]
tests/test_s02_candidate_a_integrated.py::test_sharded_raw_controls[sequence]
tests/test_s02_candidate_a_integrated.py::test_sharded_raw_controls[missing]
tests/test_s02_candidate_a_integrated.py::test_sharded_raw_controls[extra]
tests/test_s02_candidate_a_integrated.py::test_sharded_case_controls[descriptor]
tests/test_s02_candidate_a_integrated.py::test_sharded_case_controls[missing]
tests/test_s02_candidate_a_integrated.py::test_sharded_case_controls[extra]
tests/test_s02_candidate_a_integrated.py::test_sharded_case_controls[initial-before]
tests/test_s02_candidate_a_integrated.py::test_sharded_stream_suffix_failure[case]
tests/test_s02_candidate_a_integrated.py::test_sharded_stream_suffix_failure[raw]
tests/test_s02_candidate_a_integrated.py::test_sharded_manifest_closed_schema_and_paths
tests/test_s02_candidate_a_integrated.py::test_sharded_unknown_metadata_rejected_before_items[states]
tests/test_s02_candidate_a_integrated.py::test_sharded_unknown_metadata_rejected_before_items[events]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[fabricated-cancellation-core]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[denial-as-transition]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[observed-guard]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[event-order]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[payment-order]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[deposit-effect]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[rollback-time]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[retained-loser]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[proof-context]
tests/test_s02_candidate_a_integrated.py::test_semantic_rebound_triples[cancellation-identity]
tests/test_s02_candidate_a_integrated.py::test_raw_latest_field_substitution_triple
tests/test_s02_candidate_a_integrated.py::test_provenance_locator_triples[0]
tests/test_s02_candidate_a_integrated.py::test_provenance_locator_triples[1]
tests/test_s02_candidate_a_integrated.py::test_provenance_locator_triples[2]
tests/test_s02_candidate_a_integrated.py::test_provenance_locator_triples[3]
tests/test_s02_candidate_a_integrated.py::test_provenance_locator_triples[4]
tests/test_s02_candidate_a_integrated.py::test_duplicate_json_map_set_and_unit_controls
tests/test_s02_candidate_a_integrated.py::test_path_traversal_and_symlink_triples
tests/test_a4_json_stream.py::test_reader_escaped_duplicate_key_red
tests/test_a4_json_stream.py::test_reader_fields_types_and_every_chunk_size
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":[] ,"states":[]}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":[],"x":1,"x":2}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":[{"a":1,"a":2}]}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":0}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[[]]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":[01]}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":[+1]}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":[1.]}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":[1e]}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":[NaN]}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":[Infinity]}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":[-Infinity]}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":[1e999]}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":[1,]}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":[],}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":[}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":["\q"]}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":["a\nb"]}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":[]} false]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[\xef\xbb\xbf{"states":[]}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":["\xff"]}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":["\xc3"]}]
tests/test_a4_json_stream.py::test_reader_rejects_invalid_at_chunk_boundaries[{"states":[]
tests/test_a4_json_stream.py::test_reader_end_only_after_suffix_and_eof
tests/test_a4_json_stream.py::test_reader_is_lazy_and_resource_limit_is_distinct
tests/test_a4_json_stream.py::test_transport_has_no_semantic_imports
tests/test_a4_json_stream.py::test_writer_short_write_roundtrip_red
tests/test_a4_json_stream.py::test_writer_lazy_items_empty_and_hash_chunks
tests/test_a4_json_stream.py::test_writer_rejects_duplicate_or_reserved_fields[before0-after0]
tests/test_a4_json_stream.py::test_writer_rejects_duplicate_or_reserved_fields[before1-after1]
tests/test_a4_json_stream.py::test_writer_rejects_duplicate_or_reserved_fields[before2-after2]
tests/test_a4_json_stream.py::test_writer_rejects_unencodable_values[nan]
tests/test_a4_json_stream.py::test_writer_rejects_unencodable_values[inf]
tests/test_a4_json_stream.py::test_writer_rejects_unencodable_values[-inf]
tests/test_a4_json_stream.py::test_writer_rejects_unencodable_values[value3]
tests/test_a4_json_stream.py::test_writer_rejects_unencodable_values[\ud800]
tests/test_a4_json_stream.py::test_writer_rejects_unencodable_values[value5]
tests/test_a4_json_stream.py::test_writer_rejects_unencodable_values[value6]
tests/test_a4_json_stream.py::test_writer_and_hash_reject_invalid_progress_or_streams
```
