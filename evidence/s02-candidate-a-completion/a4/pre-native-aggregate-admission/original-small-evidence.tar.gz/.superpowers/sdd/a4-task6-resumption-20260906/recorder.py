"""Reviewed A4 recovery transport. No native evidence or semantic oracle.

Modes are separately authorized: admit17 reads/hashes retained evidence;
fresh97 requires that admission and executes the exact fresh complement.
The original recorder, original stage, and semantic sources are never written.
"""
import ast
import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import re
import runpy
import signal
import stat
import subprocess
import sys
import tarfile
import time
import traceback
import xml.etree.ElementTree as ET


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
OLD = ROOT / '.superpowers/sdd/a4-task6-receipts/green-tests'
PYTHON = '/home/charl/Moriarty/.venv/bin/python'
TEST = 'tests/test_s02_candidate_a_integrated.py'
UTILITY = 'tests/test_a4_json_stream.py'
ENV_MANIFEST = ROOT / '.superpowers/sdd/a4-checker-task1-receipts/python-environment.json'
RECOVERY = ROOT / '.superpowers/sdd/a4-task6-recovery-20260906.json'
PLAN = ROOT / '.superpowers/sdd/a4-task6-resumption-plan-20260906.md'
OLD_ARCHIVE_SHA = 'ec66420dafcaa62948db74ba9c752196f021e39cc402a3c2e29526ef7357a723'
RECOVERY_SHA = '1437366a220d08a26506d189c508d6fdad21a6d978f724410fec2d6166432f9e'
PLAN_SHA = '15bbb108e2a9cd3ce0c2d1fa458f0bcdb5fd9daf91dcc43976f23a3ac4015ab3'
GROUP_RUNNER = ROOT / 'evidence/s02-candidate-a-completion/a4/native-resources/runner.py'
GROUP_RUNNER_SHA = 'd8973d3541269d1be2ce524f2482e5f5b858f15f7d9117e3fe6d5cd2171d660d'
COMMAND_LIFECYCLES = []
ORIGINAL_ASSERTION_WITNESS = None


class RecorderInterruption(BaseException):
    def __init__(self, signum):
        self.signum = signum
        super().__init__('recorder received ' + signal.Signals(signum).name)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, 'duplicate JSON key: ' + key)
            result[key] = value
        return result
    return json.loads(path.read_text(), object_pairs_hook=unique)


def pin(path):
    """Chunk hashing, copied in shape from the original file_pin recorder."""
    before = path.stat()
    require(stat.S_ISREG(before.st_mode), 'regular file required: ' + str(path))
    h = hashlib.sha256()
    with path.open('rb') as stream:
        while data := stream.read(1048576):
            h.update(data)
    after = path.stat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns,
             before.st_ctime_ns) ==
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns,
             after.st_ctime_ns), 'file changed during hash: ' + str(path))
    return {'path': str(path), 'sha256': h.hexdigest(), 'bytes': after.st_size}


def verify_pins(entries):
    actual = [pin(Path(e['path'])) for e in entries]
    require(len({e['path'] for e in entries}) == len(entries), 'duplicate pin path')
    require(all(a['sha256'] == e['sha256'] and a['bytes'] == e['bytes']
                for a, e in zip(actual, entries)), 'source/runtime/support pin mismatch')
    return actual


def artifact_pins(folder):
    """Never follow artifact symlinks; no native JSON is materialized."""
    entries = []
    def visit(directory):
        for path in sorted(directory.iterdir()):
            if path.is_symlink():
                entries.append({'path': str(path), 'kind': 'symlink',
                                'target': str(path.readlink())})
            elif path.is_dir():
                entries.append({'path': str(path), 'kind': 'directory'})
                visit(path)
            elif path.is_file():
                entries.append(pin(path) | {'kind': 'file'})
            else:
                raise RuntimeError('unsupported artifact kind: ' + str(path))
    if folder.exists():
        require(not folder.is_symlink(), 'artifact root is symlink')
        visit(folder)
    return entries


def archive(target, paths):
    """Small source/support bytes only; shared runtime archive is reused."""
    entries = []
    with tarfile.open(target, 'x:gz') as tar:
        for path in sorted(set(paths)):
            raw = path.read_bytes()
            name = str(path).lstrip('/')
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            tar.addfile(info, io.BytesIO(raw))
            entries.append({'path': str(path), 'archivePath': name,
                            'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)})
    return entries


def partition():
    require(pin(RECOVERY)['sha256'] == RECOVERY_SHA, 'reviewed recovery changed')
    require(pin(PLAN)['sha256'] == PLAN_SHA, 'reviewed amendment changed')
    require(pin(OUT / 'reviewed-amendment.md')['sha256'] == PLAN_SHA,
            'local reviewed amendment changed')
    p = read(OUT / 'partition.json')
    original = read(RECOVERY)['partition']
    require(all(p[k] == v for k, v in original.items()), 'partition differs from reviewed inventory')
    required, retained, fresh = (p[k] for k in
        ('requiredPreNativeNodeids', 'retainedOriginalChildNodeids', 'freshComplementNodeids'))
    require([len(required), len(retained), len(fresh)] == [114, 17, 97], 'partition counts')
    require(len(set(required)) == 114 and len(set(retained)) == 17
            and len(set(fresh)) == 97, 'duplicate node IDs')
    require(not set(retained) & set(fresh) and set(retained) | set(fresh) == set(required),
            'partition not exact disjoint union')
    require(p['nativeDeferredNode'] not in required, 'native node entered pre-native gate')
    return p


def verify_original():
    global ORIGINAL_ASSERTION_WITNESS
    support = read(OUT / 'support.json')
    verify_pins(support['files'])
    original = read(OLD / 'input.json')
    require(not (OLD / 'terminal.json').exists() and not (OLD / 'artifacts.json').exists(),
            'original parent state changed; re-review required')
    require(original['sourceArchiveSha256'] == OLD_ARCHIVE_SHA
            and pin(OLD / 'source.tar.gz')['sha256'] == OLD_ARCHIVE_SHA, 'original source archive')
    require(len(original['sourceBytes']) == 46 and len(original['environmentBefore']) == 3329,
            'original closure size')
    source_before = verify_pins(original['sourceBytes'])
    environment_before = verify_pins(original['environmentBefore'])
    verify_pins([original['pythonBefore']])
    require(pin(ENV_MANIFEST)['sha256'] == original['pythonEnvironmentManifestSha256'],
            'environment manifest')
    environment = read(ENV_MANIFEST)
    require(pin(ENV_MANIFEST.parent / 'python-environment.tar.gz')['sha256'] ==
            original['pythonEnvironmentArchiveSha256'] == environment['archiveSha256'],
            'environment archive')
    require([(e['path'], e['sha256'], e['bytes']) for e in environment['sourceBytes']] ==
            [(e['path'], e['sha256'], e['bytes']) for e in original['environmentBefore']],
            'environment manifest entries do not bind original runtime')
    archived_test = None
    with tarfile.open(OLD / 'source.tar.gz') as tar:
        expected = {e['archivePath'] for e in original['sourceBytes']}
        require(len(tar.getmembers()) == 46 and set(tar.getnames()) == expected,
                'archive member closure')
        for entry in original['sourceBytes']:
            member = tar.getmember(entry['archivePath'])
            require(member.isfile(), 'source member is not regular file')
            raw = tar.extractfile(member).read()
            require(len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256'],
                    'archived source bytes mismatch')
            if entry['path'] == str(ROOT / TEST):
                archived_test = raw
    require(archived_test is not None, 'archived test missing')
    module = ast.parse(archived_test)
    worker = next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == 'task6_process')
    script = next(ast.literal_eval(n.value) for n in worker.body if isinstance(n, ast.Assign)
                  and any(isinstance(t, ast.Name) and t.id == 'script' for t in n.targets))
    rebound = next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == 'task6_rebind')
    require(ast.unparse(rebound.body[0]) == 'folder.mkdir()', 'assertion witness requires new directory')
    raw_assertions = [n for n in rebound.body if isinstance(n, ast.Assert)
                      and isinstance(n.test, ast.Compare) and isinstance(n.test.left, ast.Call)
                      and isinstance(n.test.left.func, ast.Name) and n.test.left.func.id == 'task6_write'
                      and isinstance(n.test.left.args[0], ast.Name) and n.test.left.args[0].id == 'raw']
    require(len(raw_assertions) == 1, 'assertion witness requires unique raw writer')
    raw_assertion = raw_assertions[0]
    next_statement = rebound.body[rebound.body.index(raw_assertion) + 1]
    require(ast.unparse(next_statement) == 'sha = file_digest(raw)',
            'assertion witness requires unconditional digest immediately after asserted raw creation')
    ORIGINAL_ASSERTION_WITNESS = {
        'evidenceKind': 'inference from archived successful execution, not recorded sys.flags',
        'directOptimizeFlagRecorded': False, 'directPythonOptimizeEnvironmentRecorded': False,
        'sourceArchiveSha256': OLD_ARCHIVE_SHA,
        'testSourceSha256': hashlib.sha256(archived_test).hexdigest(),
        'mkdirStatement': ast.unparse(rebound.body[0]),
        'rawWriterStatement': ast.unparse(raw_assertion),
        'followingStatement': ast.unparse(next_statement),
        'predicate': 'optimized runpy execution removes the raw writer and fails the unconditional digest in a new directory',
        'inferredResult': 'each successful retained child executed assertions in its runpy-loaded test module',
        'assumptions': ['pinned standard runpy/compiler runtime', 'admitted exact source bytes',
                        'fresh directory and sole-writer provenance; no external injection of raw files'],
        'limit': 'historical flags/environment were not recorded; root must explicitly admit this behavioral inference'}
    return original, source_before, environment_before, support, script


def verify_child(folder, node, mode, name, script):
    require(folder.is_dir() and not folder.is_symlink(), 'child directory required')
    require(all(not (folder / n).is_symlink() for n in
                ('argv.json', 'stdout.txt', 'stderr.txt', 'terminal.json')),
            'child control records must not be symlinks')
    records = {n: pin(folder / n) for n in ('argv.json', 'stdout.txt', 'stderr.txt', 'terminal.json')}
    expected = [PYTHON, '-B', '-X', 'pycache_prefix=' + str(folder / 'fresh-cache'),
                '-c', script, str(ROOT / TEST), mode, name, str(folder)]
    require(read(folder / 'argv.json') == expected, 'child exact archived argv: ' + node)
    terminal = read(folder / 'terminal.json')
    require(terminal == {'exit': 0} and type(terminal['exit']) is int, 'child exit: ' + node)
    require(records['stderr.txt']['bytes'] == 0, 'child stderr not empty: ' + node)
    report = read(folder / 'stdout.txt')
    require(report['mode'] == mode and report['name'] == name, 'child report identity: ' + node)
    require(all(report[k] is True for k in ('mutant_rejected', 'corrected', 'unrelated')),
            'child positive/rejection controls: ' + node)
    if mode == 'semantic':
        require(type(report['changed_events']) is int and report['changed_events'] > 0
                and report['raw_linkage'] is True, 'effective rebound mutation: ' + node)
        expected_keys = {'mode', 'name', 'changed_events', 'raw_linkage',
                         'mutant_rejected', 'corrected', 'unrelated'}
    else:
        expected_keys = {'mode', 'name', 'mutant_rejected', 'corrected', 'unrelated'}
    require(set(report) == expected_keys, 'child report shape: ' + node)
    return {'nodeid': node, 'folder': str(folder), 'mode': mode, 'name': name,
            'argv': expected, 'records': records, 'originalChildExit': 0, 'report': report}


def fresh_env(cache):
    overrides = {'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPYCACHEPREFIX': str(cache),
                 'PYTHONPATH': '', 'PYTEST_ADDOPTS': ''}
    env = os.environ.copy()
    removed = ['PYTHONOPTIMIZE'] if 'PYTHONOPTIMIZE' in env else []
    env.pop('PYTHONOPTIMIZE', None)
    env.update(overrides)
    return env, overrides, removed


def run_command(stage, label, argv, cache):
    require(not cache.exists(), 'command cache already exists')
    env, overrides, removed = fresh_env(cache)
    write(stage / (label + '-input.json'), {'createdAt': now(), 'argv': argv,
          'cwd': str(ROOT), 'environmentOverrides': overrides, 'removedEnvironmentKeys': removed,
          'childPythonOptimizePresent': 'PYTHONOPTIMIZE' in env,
          'parentFlags': {'optimize': sys.flags.optimize, 'dont_write_bytecode': sys.flags.dont_write_bytecode}})
    require(pin(GROUP_RUNNER)['sha256'] == GROUP_RUNNER_SHA, 'admitted group cleanup source pin')
    group = runpy.run_path(str(GROUP_RUNNER))
    require(pin(GROUP_RUNNER)['sha256'] == GROUP_RUNNER_SHA, 'group cleanup source changed on load')
    cleanup_group, group_exists = group['cleanup_group'], group['group_exists']
    start, child, problem = time.monotonic(), None, None
    cleanup = {'forced': False, 'signals': [], 'errors': [], 'complete': False}
    received, phase = [], 'launch'
    lifecycle = {'ownedPgid': None, 'eligible': False, 'artifactFinalizationBlocked': True,
                 'cleanup': cleanup, 'status': 'launch/cleanup not finalized'}
    COMMAND_LIFECYCLES.append(lifecycle)

    def interrupted(signum, frame):
        received.append(signal.Signals(signum).name)
        # Defer during Popen construction until its owned PID is assigned, and
        # during bounded cleanup so a second signal cannot bypass group reaping.
        if phase == 'wait':
            raise RecorderInterruption(signum)

    previous = {sig: signal.signal(sig, interrupted) for sig in (signal.SIGTERM, signal.SIGINT)}
    try:
        with (stage / (label + '-stdout.txt')).open('xb') as stdout, \
                (stage / (label + '-stderr.txt')).open('xb') as stderr:
            try:
                child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr,
                                         start_new_session=True)
                lifecycle['ownedPgid'] = child.pid
                phase = 'wait'
                if received:
                    raise RecorderInterruption(signal.Signals[received[0]])
                write(stage / (label + '-process.json'), {'pid': child.pid, 'ownedPgid': child.pid,
                      'parentPid': os.getpid(), 'startNewSession': True,
                      'recordedAt': now(), 'argv': argv,
                      'meaning': 'owned identity at spawn, not current liveness'})
                child.wait()
            except BaseException as exc:
                problem = {'type': type(exc).__name__, 'message': str(exc)}
            finally:
                phase = 'cleanup'
                if child is not None:
                    observation_error = None
                    try:
                        remaining = group_exists(child.pid)
                    except BaseException as exc:
                        remaining = True
                        observation_error = {'type': type(exc).__name__, 'message': str(exc)}
                    try:
                        if problem is not None or child.returncode is None or remaining:
                            cleanup = cleanup_group(child, 5, 5)
                        else:
                            cleanup['complete'] = True
                        if observation_error is not None:
                            cleanup['errors'].append(observation_error)
                            cleanup['complete'] = False
                    except BaseException as exc:
                        cleanup['errors'].append({'type': type(exc).__name__, 'message': str(exc)})
                        cleanup['complete'] = False
                else:
                    # No child was constructed: no owned writer exists.
                    cleanup['complete'] = True
    except BaseException as exc:
        problem = problem or {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)
    code = child.returncode if child is not None else None
    complete = cleanup['complete'] and not cleanup['errors']
    eligible = (child is not None and code == 0 and problem is None and not received
                and complete and not cleanup['forced'])
    # Publish ownership/cleanup state before any file hashing or receipt write can
    # fail. The outer finalizer consults this in-memory state even without a file.
    lifecycle.update({'exitCode': code, 'ownedPgid': child.pid if child is not None else None,
                      'cleanup': cleanup, 'monitorError': problem, 'receivedSignals': received,
                      'eligible': eligible, 'artifactFinalizationBlocked': not complete,
                      'status': 'complete' if complete else 'root takeover required'})
    result = {'exitCode': code, 'completedAt': now(), 'elapsedSeconds': time.monotonic() - start,
              'ownedPgid': child.pid if child is not None else None,
              'cleanupHelper': pin(GROUP_RUNNER), 'cleanup': cleanup,
              'monitorError': problem, 'receivedSignals': received, 'eligible': eligible,
              'artifactFinalizationBlocked': not complete,
              'stdout': pin(stage / (label + '-stdout.txt')) if complete else None,
              'stderr': pin(stage / (label + '-stderr.txt')) if complete else None}
    lifecycle.update(result)
    write(stage / (label + '-terminal.json'), result)
    return result


def collect(stage, p):
    cache = stage / 'collection-cache'
    argv = [PYTHON, '-B', '-X', 'pycache_prefix=' + str(cache), '-m', 'pytest',
            '--collect-only', '-q', '-p', 'no:cacheprovider', TEST, UTILITY]
    result = run_command(stage, 'collection', argv, cache)
    require(result['eligible'], 'collection failed or owned process cleanup was required/incomplete')
    lines = (stage / 'collection-stdout.txt').read_text().splitlines()
    nodes = [line for line in lines if line.startswith('tests/') and '::' in line]
    require(len(nodes) == len(set(nodes)) == 115, 'collection must have 115 unique nodes')
    require(nodes.count(p['nativeDeferredNode']) == 1, 'native collection node')
    require([n for n in nodes if n != p['nativeDeferredNode']] == p['requiredPreNativeNodeids'],
            'ordered collection differs from reviewed exact inventory')
    write(stage / 'collected-nodeids.json', nodes)


def common_input(stage, mode, original, source, environment, support, p):
    entries = archive(stage / 'source.tar.gz', [Path(e['path']) for e in original['sourceBytes']]
                      + [Path(e['path']) for e in support['files']] + [OUT / 'support.json'])
    write(stage / 'input.json', {'createdAt': now(), 'mode': mode, 'parentOrigArgv': sys.orig_argv,
          'parentPid': os.getpid(), 'sourceCommit': subprocess.check_output(
              ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
          'headMeaning': 'actual recorder dispatch HEAD; original source hashes control reuse',
          'cwd': str(ROOT), 'scope': 'pre-native recovery only; final115 and native package owed',
          'originalParentExit': None, 'originalParentExitReason': 'no original terminal survives',
          'historicalStabilityLimit': 'delayed endpoint matches, not original parent after-pins',
          'originalAssertionWitness': ORIGINAL_ASSERTION_WITNESS,
          'parentFlags': {'optimize': sys.flags.optimize, 'dont_write_bytecode': sys.flags.dont_write_bytecode},
          'originalInput': pin(OLD / 'input.json'), 'originalSourceArchive': pin(OLD / 'source.tar.gz'),
          'sourceBefore': source, 'environmentBefore': environment,
          'pythonBefore': pin(Path(PYTHON)), 'supportBefore': verify_pins(support['files']),
          'supportManifest': pin(OUT / 'support.json'),
          'sourceBytes': entries, 'sourceArchive': pin(stage / 'source.tar.gz'),
          'runtimeArchive': pin(ENV_MANIFEST.parent / 'python-environment.tar.gz'),
          'partition': p, 'artifactRetention': 'all original bytes retained; no cleanup'})


def admit17(stage, p, script):
    require((OLD / 'stdout.txt').read_bytes() == b'.' * 54, 'original progress stream changed')
    require((OLD / 'stderr.txt').stat().st_size == 0, 'original stderr changed')
    children = []
    recovery_children = read(RECOVERY)['children']
    for index, node in enumerate(p['retainedOriginalChildNodeids']):
        name = node.split('[', 1)[1][:-1]
        folder = OLD / 'basetemp' / ('test_semantic_rebound_triples_' + str(index))
        child = verify_child(folder, node, 'semantic', name, script)
        recovered = recovery_children[index]
        require(recovered['nodeid'] == node, 'recovery child order')
        for record, entry in child['records'].items():
            require(entry['sha256'] == recovered['records'][record]['sha256'],
                    'original child record changed since recovery')
        recorded_files = {e['path']: e['bytes'] for e in recovered['retainedFilesMetadataOnly']}
        present_files = {str(f.relative_to(ROOT)): f.stat().st_size for f in folder.rglob('*')
                         if f.is_file() and not f.is_symlink()}
        require(present_files == recorded_files, 'retained generated file inventory changed')
        children.append(child)
    entries = artifact_pins(OLD)
    write(stage / 'original-artifacts.json', {'observedAt': now(), 'root': str(OLD),
          'timeMeaning': 'recovery-time hashes, never original completion-time hashes',
          'retention': 'original bytes retained, symlinks recorded without following', 'entries': entries})
    # Recheck small records after full-tree hashing so child identity/report bindings
    # and the artifact manifest cannot disagree even if external writers intervene.
    for child in children:
        require(verify_child(Path(child['folder']), child['nodeid'], 'semantic', child['name'], script)
                == child, 'child changed while recovery inventory was made')
    write(stage / 'retained-controls.json', {'originalParentExit': None,
          'delayedEndpointLimitationAcceptedByRoot': True,
          'assertionIntegrityEvidence': ORIGINAL_ASSERTION_WITNESS,
          'originalInput': pin(OLD / 'input.json'), 'originalSourceArchive': pin(OLD / 'source.tar.gz'),
          'artifactManifest': pin(stage / 'original-artifacts.json'), 'controls': children})


def verify_admission(p, script):
    admission = OUT / 'admit17'
    terminal = read(admission / 'terminal.json')
    require(terminal['exitCode'] == 0 and terminal['sourceChanged'] == []
            and terminal['environmentChanged'] == [], 'retained admission terminal')
    verify_pins(terminal['ownedFiles'])
    controls = read(admission / 'retained-controls.json')
    require(controls['originalParentExit'] is None, 'old parent exit must remain unknown')
    require([c['nodeid'] for c in controls['controls']] == p['retainedOriginalChildNodeids'],
            'retained admission partition mismatch')
    verify_pins([controls['originalInput'], controls['originalSourceArchive'], controls['artifactManifest']])
    for child in controls['controls']:
        require(verify_child(Path(child['folder']), child['nodeid'], 'semantic', child['name'], script)
                == child, 'retained child evidence changed')
    # Rehash retained original artifacts at fresh dispatch, using bounded reads.
    # This reads all original data but never regenerates or semantically reruns a control.
    manifest = read(Path(controls['artifactManifest']['path']))
    require(artifact_pins(OLD) == manifest['entries'], 'original retained artifact tree changed')
    return controls


def fresh_controls(basetemp, p, script):
    expected = {}
    for node in p['freshComplementNodeids']:
        if '::test_semantic_rebound_triples[' in node:
            expected[('semantic', node.split('[', 1)[1][:-1])] = node
        elif node.endswith('::test_raw_latest_field_substitution_triple'):
            expected[('substitution', 'profile')] = node
        elif '::test_provenance_locator_triples[' in node:
            expected[('locator', node.split('[', 1)[1][:-1])] = node
    require(len(expected) == 16, 'fresh child inventory')
    controls = {}
    for folder in sorted(basetemp.iterdir()):
        if folder.is_symlink() or not folder.is_dir() or not (folder / 'argv.json').is_file():
            continue
        argv = read(folder / 'argv.json')
        key = tuple(argv[-3:-1])
        require(key in expected and key not in controls, 'unknown or duplicate fresh child')
        controls[key] = verify_child(folder, expected[key], *key, script)
    require(set(controls) == set(expected), 'missing fresh child receipt')
    return {control['nodeid']: control for control in controls.values()}


def fresh97(stage, p, script):
    retained = verify_admission(p, script)
    write(stage / 'retained-admission-binding.json', {
        'terminal': pin(OUT / 'admit17/terminal.json'),
        'controls': pin(OUT / 'admit17/retained-controls.json'),
        'artifactManifest': pin(OUT / 'admit17/original-artifacts.json')})
    basetemp, cache = stage / 'basetemp', stage / 'fresh-pycache'
    require(not basetemp.exists(), 'fresh pytest basetemp already exists')
    argv = [PYTHON, '-B', '-X', 'pycache_prefix=' + str(cache), '-m', 'pytest', '-q',
            '-p', 'no:cacheprovider', *p['freshComplementNodeids'],
            '--basetemp=' + str(basetemp), '--junitxml=' + str(stage / 'junit.xml')]
    result = run_command(stage, 'pytest', argv, cache)
    require(not result['artifactFinalizationBlocked'],
            'owned process group still live/uncertain; root takeover required before artifact hashing')
    write(stage / 'fresh-artifacts.json', {'root': str(basetemp), 'observedAt': now(),
          'retention': 'all generated original files retained; no cleanup',
          'entries': artifact_pins(basetemp)})
    require(result['eligible'], 'fresh pytest failed or cleanup was forced; original streams retained')
    xml = ET.parse(stage / 'junit.xml').getroot()
    cases = xml.findall('.//testcase')
    require(len(cases) == 97, 'JUnit instance count')
    require(not xml.findall('.//failure') and not xml.findall('.//error')
            and not xml.findall('.//skipped'), 'JUnit non-pass outcome')
    nodes = [case.attrib['classname'].replace('.', '/') + '.py::' + case.attrib['name']
             for case in cases]
    require(nodes == p['freshComplementNodeids'] and len(set(nodes)) == 97,
            'executed JUnit nodes differ from exact97 partition')
    stdout = (stage / 'pytest-stdout.txt').read_text()
    require(re.search(r'(?m)^97 passed(?:, [0-9]+ warnings?)? in .+$', stdout) is not None,
            'pytest exact97 passed summary')
    require(not re.search(r'\b(?:skipped|xfailed|xpassed|deselected|failed|errors?)\b',
                          stdout.splitlines()[-1]), 'non-pass pytest summary')
    children = fresh_controls(basetemp, p, script)
    write(stage / 'fresh-controls.json', {'controls': list(children.values())})
    by_node = {c['nodeid']: {'nodeid': c['nodeid'], 'kind': 'retained-original-child',
               'receipt': pin(OUT / 'admit17/retained-controls.json'),
               'childRecords': c['records']} for c in retained['controls']}
    for node in nodes:
        require(node not in by_node, 'aggregate overlap')
        by_node[node] = {'nodeid': node, 'kind': 'fresh-pytest-pass',
                         'receipt': pin(stage / 'pytest-terminal.json'),
                         'junit': pin(stage / 'junit.xml')}
        if node in children:
            by_node[node]['childRecords'] = children[node]['records']
    require(set(by_node) == set(p['requiredPreNativeNodeids']) and len(by_node) == 114,
            'aggregate exact114 gate')
    # Candidate only: outer terminal must also succeed after source/runtime checks.
    write(stage / 'aggregate-candidate.json', {'originalParentExit': None,
          'freshParentExit': result['exitCode'], 'retainedCount': 17, 'freshCount': 97,
          'requiredCount': 114, 'status': 'candidate; requires outer terminal zero and root review',
          'nativeFinal115StillRequired': True,
          'controls': [by_node[n] for n in p['requiredPreNativeNodeids']]})


def main():
    require(len(sys.argv) == 2 and sys.argv[1] in ('admit17', 'fresh97'), 'mode admit17|fresh97 required')
    require(sys.executable == PYTHON and sys.orig_argv[0] == PYTHON,
            'recorder must use the exact pinned virtualenv interpreter')
    require(sys.flags.optimize == 0, 'recorder optimization must be disabled')
    mode = sys.argv[1]
    parent_cache = OUT / ('recorder-cache-' + mode)
    require(sys.flags.dont_write_bytecode and sys.pycache_prefix == str(parent_cache),
            'parent requires -B and exact fresh cache prefix')
    require(sys.orig_argv[1:4] == ['-B', '-X', 'pycache_prefix=' + str(parent_cache)]
            and not parent_cache.exists(), 'parent exact argv/fresh cache requirement')
    stage = OUT / mode
    stage.mkdir(exist_ok=False)
    start, code, original, support = time.monotonic(), 1, None, None
    error, after, environment_after, source_changed, environment_changed = None, [], [], [], []
    try:
        p = partition()
        original, source, environment, support, script = verify_original()
        common_input(stage, mode, original, source, environment, support, p)
        collect(stage, p)
        if mode == 'admit17':
            admit17(stage, p, script)
        else:
            fresh97(stage, p, script)
        code = 0
    except BaseException as exc:
        error = type(exc).__name__ + ': ' + str(exc)
        (stage / 'recorder-error.txt').write_text(traceback.format_exc())
    finally:
        try:
            if original is not None:
                after = [pin(Path(e['path'])) for e in original['sourceBytes']]
                environment_after = [pin(Path(e['path'])) for e in original['environmentBefore']]
                source_changed = [e['path'] for e, a in zip(original['sourceBytes'], after)
                                  if e['sha256'] != a['sha256'] or e['bytes'] != a['bytes']]
                environment_changed = [e['path'] for e, a in zip(original['environmentBefore'], environment_after)
                                       if e['sha256'] != a['sha256'] or e['bytes'] != a['bytes']]
                require(not source_changed and not environment_changed, 'after source/runtime stability')
                verify_pins([original['pythonBefore']])
                verify_pins(support['files'])
                require(pin(OUT / 'support.json') == read(stage / 'input.json')['supportManifest'],
                        'support manifest changed during stage')
        except BaseException as exc:
            code = 2
            error = (error + '; ' if error else '') + 'after-check: ' + str(exc)
        # Child subprocess exits are stored immediately by run_command. This is
        # the recorder's own outcome; interruption never becomes pytest exit zero.
        live_or_uncertain = any(r['artifactFinalizationBlocked'] for r in COMMAND_LIFECYCLES)
        if live_or_uncertain:
            code = 2
            error = (error + '; ' if error else '') + 'owned group live/uncertain; root takeover required'
        owned = [] if live_or_uncertain else [pin(path) for path in sorted(stage.iterdir()) if path.is_file()]
        terminal = {'exitCode': code, 'completedAt': now(), 'elapsedSeconds': time.monotonic() - start,
                    'originalParentExit': None, 'error': error, 'sourceAfter': after,
                    'environmentAfter': environment_after, 'sourceChanged': source_changed,
                    'environmentChanged': environment_changed, 'ownedFiles': owned,
                    'commandLifecycles': COMMAND_LIFECYCLES,
                    'artifactFinalizationBlocked': live_or_uncertain,
                    'parentOrigArgv': sys.orig_argv, 'status': 'candidate for root review' if code == 0 else 'failed'}
        write(stage / 'terminal.json', terminal)
        print(json.dumps({'stage': str(stage), 'exitCode': code, 'error': error}), flush=True)
    return code


if __name__ == '__main__':
    raise SystemExit(main())
