"""Four bounded process-lifecycle controls; no A4 semantic/native test executes.

Creates only a new sibling receipt root and owned short child processes. Invoke
with the pinned virtualenv Python, -B, after root review of this control source.
"""
import hashlib
import json
import os
from pathlib import Path
import runpy
import signal
import sys
import threading
import time


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
RECEIPTS = HERE.parent / 'a4-task6-lifecycle-controls-20260906'
PYTHON = '/home/charl/Moriarty/.venv/bin/python'
GROUP = ROOT / 'evidence/s02-candidate-a-completion/a4/native-resources/runner.py'
OWNED_LIFECYCLES = []

CHILD = '''import json,os,signal,subprocess,sys,time
from pathlib import Path
folder,mode=Path(sys.argv[1]),sys.argv[2]
(folder/'child-flags.json').write_text(json.dumps({'optimize':sys.flags.optimize}))
if sys.flags.optimize!=0:raise RuntimeError('child inherited Python optimization')
(folder/'leader-pid.txt').write_text(str(os.getpid()))
if mode=='descendant':
    code="""import os,signal,sys,time
from pathlib import Path
folder=Path(sys.argv[1])
signal.signal(signal.SIGTERM,signal.SIG_IGN)
(folder/'descendant-pid.txt').write_text(str(os.getpid()))
while True:
    with (folder/'heartbeat.txt').open('a') as f:f.write('x');f.flush()
    time.sleep(0.02)
"""
    subprocess.Popen([sys.executable,'-B','-c',code,str(folder)])
    while not (folder/'heartbeat.txt').exists():time.sleep(0.01)
(folder/'ready.txt').write_text('ready')
if mode=='normal':
    print('normal-complete',flush=True)
elif mode=='descendant':
    print('leader-exits-with-live-descendant',flush=True)
else:
    time.sleep(30)
'''


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def write(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def wait_file(path, seconds=3):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if path.is_file():
            return
        time.sleep(0.01)
    raise RuntimeError('short-process readiness timeout: ' + str(path))


def state(pid):
    try:
        return Path('/proc/' + str(pid) + '/stat').read_text().split(') ', 1)[1].split()[0]
    except FileNotFoundError:
        return None


def control(name):
    folder = RECEIPTS / name
    folder.mkdir(exist_ok=False)
    (folder / 'child.py').write_text(CHILD)
    module = runpy.run_path(str(HERE / 'recorder.py'))
    run = module['run_command']
    scope = run.__globals__
    OWNED_LIFECYCLES.append(scope['COMMAND_LIFECYCLES'])
    original_write = scope['write']
    mode = 'normal' if name == 'normal' else 'descendant' if name == 'leader-exit-descendant' else 'sleep'
    argv = [PYTHON, '-B', str(folder / 'child.py'), str(folder), mode]
    thread = None
    thread_errors = []
    if name == 'exception-after-spawn':
        def faulty_write(path, value):
            if path.name == 'control-process.json':
                wait_file(folder / 'ready.txt')
                raise OSError('injected process-record write failure after real child spawn')
            original_write(path, value)
        scope['write'] = faulty_write
    if name == 'sigterm-during-wait':
        def interrupt_owned_recorder():
            try:
                wait_file(folder / 'ready.txt')
                os.kill(os.getpid(), signal.SIGTERM)
            except BaseException as error:
                thread_errors.append(str(error))
        thread = threading.Thread(target=interrupt_owned_recorder)
        thread.start()
    result = None
    old_optimize = os.environ.get('PYTHONOPTIMIZE')
    os.environ['PYTHONOPTIMIZE'] = '2'
    try:
        result = run(folder, 'control', argv, folder / 'fresh-cache')
    finally:
        if old_optimize is None:
            os.environ.pop('PYTHONOPTIMIZE', None)
        else:
            os.environ['PYTHONOPTIMIZE'] = old_optimize
        scope['write'] = original_write
        if thread is not None:
            thread.join(timeout=4)
            require(not thread.is_alive() and not thread_errors, 'signal control thread did not complete')
    require(result is not None, 'missing real command lifecycle result')
    require(json.loads((folder / 'child-flags.json').read_text()) == {'optimize': 0},
            'child optimization not disabled')
    command_input = json.loads((folder / 'control-input.json').read_text())
    require(command_input['removedEnvironmentKeys'] == ['PYTHONOPTIMIZE']
            and not command_input['childPythonOptimizePresent'], 'optimization clearing not recorded')
    require(result['ownedPgid'] == int((folder / 'leader-pid.txt').read_text()), 'owned leader identity')
    observations = {'leaderStateAfter': state(result['ownedPgid'])}
    require(observations['leaderStateAfter'] is None, 'leader was not reaped')
    if name == 'normal':
        require(result['exitCode'] == 0 and result['eligible'], 'normal command not eligible')
        require(result['cleanup']['complete'] and not result['cleanup']['forced'], 'normal cleanup changed')
        require((folder / 'control-stdout.txt').read_text() == 'normal-complete\n', 'normal original stream')
    else:
        require(not result['eligible'] and result['cleanup']['forced'], 'interrupted/forced control eligible')
        require(result['artifactFinalizationBlocked'] == (not result['cleanup']['complete']),
                'incomplete cleanup must block artifact finalization')
        if name == 'exception-after-spawn':
            require(result['monitorError']['type'] == 'OSError', 'post-spawn exception lost')
            require(result['exitCode'] == -signal.SIGTERM, 'authentic terminated child exit lost')
            require(not (folder / 'control-process.json').exists(), 'injected process-record failure ineffective')
        elif name == 'sigterm-during-wait':
            require(result['monitorError']['type'] == 'RecorderInterruption', 'SIGTERM interruption lost')
            require(result['receivedSignals'] == ['SIGTERM'] and result['exitCode'] == -signal.SIGTERM,
                    'SIGTERM or authentic child returncode lost')
        else:
            require(result['exitCode'] == 0, 'ordinary leader exit must remain authentic zero')
            descendant = int((folder / 'descendant-pid.txt').read_text())
            observations['descendantPid'] = descendant
            observations['descendantStateAfter'] = state(descendant)
            before = (folder / 'heartbeat.txt').stat().st_size
            time.sleep(0.1)
            after = (folder / 'heartbeat.txt').stat().st_size
            observations['heartbeatBytesBeforeAfter'] = [before, after]
            require(observations['descendantStateAfter'] in (None, 'Z'), 'owned descendant can still execute')
            require(before == after, 'owned descendant still writes')
            require(any(s['signal'] == 'SIGKILL' and s['sent'] for s in result['cleanup']['signals']),
                    'SIGTERM-ignoring descendant did not exercise SIGKILL')
    write(folder / 'control-result.json', {'ok': True, 'scope': 'short-process lifecycle only',
          'commandTerminal': str(folder / 'control-terminal.json'), 'result': result,
          'observations': observations})
    return {'name': name, 'ok': True, 'eligible': result['eligible'],
            'cleanupComplete': result['cleanup']['complete'], 'observations': observations}


def main():
    require(sys.executable == PYTHON and sys.flags.dont_write_bytecode, 'pinned Python -B required')
    require(sys.flags.optimize == 0, 'control recorder optimization must be zero')
    require(sha(GROUP) == 'd8973d3541269d1be2ce524f2482e5f5b858f15f7d9117e3fe6d5cd2171d660d',
            'admitted group helper changed')
    RECEIPTS.mkdir(exist_ok=False)
    sources = [HERE / 'recorder.py', HERE / 'lifecycle_controls.py', GROUP]
    before = {str(p): sha(p) for p in sources}
    write(RECEIPTS / 'input.json', {'parentOrigArgv': sys.orig_argv, 'sourceBefore': before,
          'scope': 'four short-process lifecycle controls only; no A4 semantic/native execution'})
    for p in sources:
        (RECEIPTS / (p.parent.name + '-' + p.name)).write_bytes(p.read_bytes())
    results, error, fallback = [], None, []
    try:
        for name in ('normal', 'exception-after-spawn', 'leader-exit-descendant', 'sigterm-during-wait'):
            results.append(control(name))
    except BaseException as exc:
        error = type(exc).__name__ + ': ' + str(exc)
        # Failed controls must not leave their deliberately-created writers alive.
        # Act only on owned, recorded new-session group IDs from this process.
        for lifecycles in OWNED_LIFECYCLES:
            for entry in lifecycles:
                pgid = entry.get('ownedPgid')
                if pgid is None:
                    continue
                require(pgid != os.getpgrp(), 'refuse control-group collision')
                record = {'ownedPgid': pgid, 'reason': 'failed-control cleanup'}
                try:
                    os.killpg(pgid, signal.SIGKILL)
                    record['signalSent'] = True
                except ProcessLookupError:
                    record['signalSent'] = False
                try:
                    os.waitpid(pgid, os.WNOHANG)
                except ChildProcessError:
                    pass
                fallback.append(record)
    after = {str(p): sha(p) for p in sources}
    terminal = {'ok': error is None and len(results) == 4 and before == after,
                'error': error, 'controls': results, 'fallbackCleanup': fallback,
                'sourceAfter': after, 'sourceStable': before == after}
    write(RECEIPTS / 'terminal.json', terminal)
    print(json.dumps(terminal), flush=True)
    return 0 if terminal['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
