# A4 fresh97 independent original-evidence intake

Spec verdict: PASS for the adopted amended preliminary gate.
Evidence verdict: PASS, with the original-parent and polling-metadata limits
below preserved. Root admission remains separate. This does not admit an actual
native package, the final 115-instance run, A4 completion, Council or H1.

Original stage:
`.superpowers/sdd/a4-task6-resumption-20260906/fresh97/`.
This review used original inputs, archives, streams, JUnit, child records,
manifests and terminals. `intake-summary.json` was inspected as author handoff;
it was not used in place of those originals.

## Authentic terminal and exact selection

The original recorder terminal and pytest terminal both report integer exit
zero, with no monitor error, received signal, forced cleanup or blocked artifact
finalization. The recorder's source/environment change lists are empty. Actual
outer response chunk `31e729` reports exit 0 and the matching recorder summary.
The original recorded dispatch source HEAD is
`43f33721da7a3bfb11dd1a91f1f548d5110ab93c`; it was not replaced by a later HEAD.

Checked the exact parent orig_argv, virtualenv interpreter, absolute parent
cache, relative recorder path and fresh97 mode. Collection and pytest argv
match their original input/process records. Pytest selects all 97 reviewed
nodes as individual ordered argv elements, with the exact fresh basetemp/cache,
`-B`, disabled cache provider and authorized JUnit output. No substring selection
is used. The recorded environment clears PYTHONPATH/PYTEST_ADDOPTS and removes
PYTHONOPTIMIZE; parent optimization is zero and bytecode writes are disabled.

Original collection stdout, collected-nodeids.json and the reviewed partition
agree on 115 unique nodes. Removing only the exact deferred native-package node
produces the ordered 114 preliminary inventory. JUnit contains exactly the 97
fresh nodes in that reviewed order, with no failure, error or skipped element.
Original pytest stdout ends:

```text
97 passed in 4999.83s (1:23:19)
```

Both collection and pytest stderr are empty. The original pytest recorder
elapsed field is 5000.445858452003 seconds; the outer recorder elapsed field is
5011.037390458005 seconds. These fields have their respective recorder scopes;
no CPU or RSS metric was inferred from them.

Collection group 3365488 and pytest group 3365545 match the two original
process/lifecycle records. Both lifecycles are eligible with complete, unforced
cleanup and no errors/signals. Read-only process-group existence checks found
both groups absent at intake. No signal was delivered by this reviewer.

## All 16 fresh child controls and retained17

Statically extracted the task6_process runner string from the authenticated
original archived test source. Every fresh child's entire argv matches that
string, original test path, pinned Python, bytecode/cache flags, mode, name and
its own directory. Exactly 16 expected child directories contain argv records;
no additional or duplicate child identity was admitted. Every child has original
integer exit zero, empty stderr, exact report shape/identity and true
mutant_rejected, corrected and unrelated predicates.

The 10 semantic reports also have true raw_linkage and these original positive
changed_events counts:

| Semantic control | Changed events |
| --- | --- |
| fabricated-cancellation-core | 1 |
| denial-as-transition | 1 |
| observed-guard | 1 |
| event-order | 2 |
| payment-order | 10 |
| deposit-effect | 25 |
| rollback-time | 2 |
| retained-loser | 19 |
| proof-context | 22 |
| cancellation-identity | 24 |

The remaining six children are substitution/profile and locator/0 through
locator/4, each with the exact required report predicates. All original child
record hashes match fresh-controls.json and the terminal generated-file
manifest. These are results of the original test invocation; this reviewer did
not replay the semantic controls.

Rechecked all 17 retained children's original complete argv, report, exit,
stderr and small-record hashes against their admitted control records, original
archived runner and root admission. The original partial eighteenth child
receives no retained credit; fabricated-cancellation-core is one of the fresh
semantic controls above. The retained admission terminal, control map and
artifact-manifest pins match root-admission17 and the fresh retained-admission
binding. Original assertion execution remains the previously accepted
source-bound inference under pinned-runtime/fresh-directory/sole-writer
assumptions; no missing historical optimization flags were invented.

The aggregate's ordered 114-node inventory is exactly the disjoint union of
the 17 retained and 97 fresh inventories. Checked every aggregate row against
its authentic retained-control record or fresh pytest/JUnit receipt; all 16
fresh subprocess rows additionally bind their exact child records. Counts
alone were not used as the coverage predicate.

## Complete original trees and source/runtime evidence

Independently streamed all regular files in both terminal artifact trees and
matched the exact complete manifest entry sequence. Directories and symlink
targets were checked without following symlinks or treating them as regular
artifacts:

| Original tree | Regular files | Regular-file bytes | Directories | Symlinks |
| --- | --- | --- | --- | --- |
| fresh97/basetemp | 274 | 6,237,424,864 | 76 | 20 |
| original green-tests retained tree | 318 | 9,795,796,111 | 88 | 16 |

The fresh tree has 370 total entries. The retained tree remains byte-for-byte
bound to the original admitted recovery manifest, including available partial
child evidence. Nothing was regenerated, removed or rewritten.

The fresh source/support archive contains exactly 59 unique regular members.
Checked every member's exact name, size and SHA256 against its original archive
map and the complete union of 46 original source pins, 12 support pins and the
support manifest. Also checked all 46 original source archive members and its
fixed digest. Current source pins, interpreter, 3,329 runtime pins, all support
pins and the runtime manifest/archive match their recorded bindings. Fresh
before/after source and runtime pin lists match exactly. The runtime archive
was rehashed and reused, not duplicated.

All 18 top-level files in the original recorder terminal's ownedFiles map were
rehashed. The original terminal and later outer receipt remain distinct. The
frozen recorder SHA is `63d8f00d024dbafb08fef0d48da96c91ca594bfe33476946ab0960bfd7dcf666`;
support SHA is `9da5267f46318171340d11cd6f25b3baebf98aa75b2312f23f8ecd9f12b76a93`.
Current endpoint equality does not establish continuous historical immutability.

## Original digest anchors

Paths in this table are relative to the original fresh97 stage.

| Artifact | SHA256 |
| --- | --- |
| input.json | `ab605b237e8c8db7fbf85d9c8eaaa5e78bf80024f14ed025cbe74fa1234fc3ae` |
| source.tar.gz | `7055cbd12739c280180361b610813c475b84e5d9d18c432cfd9075d55fe72a8e` |
| terminal.json | `1ecd99090a183136fe205edfabf766f905259efabf0d7c43efd344f16626ea34` |
| pytest-terminal.json | `44a4947ee0021d7c2a31f55ceb992f4214ee93b5ba8b52d11d02b802d1734bef` |
| junit.xml | `95dbda943cdba7f74abe1d1c24c1bde2c42ede20b0984001d976a403beec2a7c` |
| fresh-controls.json | `bccd770eefe588cb4c98e1827c98ba48e102049f33addc87d17e76a69f9ed4e9` |
| fresh-artifacts.json | `5148c33e29abe44526f76825d31611f6938c46f3fa7986617412eaab72eed43c` |
| aggregate-candidate.json | `12ae6f549675ae12b037c49a1d6123b310afcedd80acb669b3e7aaf38ba0fc1b` |
| outer-tool-receipt.json | `4783b46637cfc0ee34302ece1f15079c283187bb699c6ebf94fe5d3e0dadb723` |

The sibling fresh97-outer-progress.ndjson SHA256 is
`5ef8921b8486eed8f32872c256ac6737b4a4a87706a8e0027c71819fc94d200d`.

## Explicit missing history and audit-attempt provenance

The outer receipt retains 87 actually returned responses: launch chunk 47f87b
with session 68260, subsequent retained nonterminal responses for that session,
and final chunk 31e729. Their ordered contents and indices exactly match the
progress log. The receipt and log both preserve one monitoring-metadata gap:
termination of monitoring cell 50 discarded intermediate buffered poll metadata.
The statement that only the monitor was terminated and the recorder was neither
signalled nor restarted remains the recorded operational account. Missing polls
are not reconstructed. The authentic launch/final response and process receipts
remain available; the 87 responses are not described as a complete poll history.

The old interrupted parent's terminal and artifact-manifest files remain absent,
and originalParentExit remains null in input, terminal, retained control map and
aggregate. This successful fresh parent does not supply the old parent's exit.
Delayed recovery hashes and accepted assertion inference retain their original
limitations.

The first independent read-only audit attempt exited 1 in tool chunk 5cc8c8
before artifact-tree hashing. Its actual output was:

```text
Traceback (most recent call last):
  File "<stdin>", line 32, in <module>
  File "<stdin>", line 5, in req
RuntimeError: recorded before-after
```

The failing source comparison was
`I['sourceBefore']==T['sourceAfter']==oldinput['sourceBytes']`. The original
sourceBytes rows additionally contain archivePath; fresh endpoint rows contain
path/bytes/SHA256 only. This was an audit-schema assumption, not an original
receipt failure. The original inline audit invocation and actual response remain
in the tool transcript; no standalone original audit source file was created or
reconstructed as an original artifact. The corrected audit compares explicit
path/bytes/SHA256 fields and validates archive metadata separately.

The corrected independent audit launched in chunk 8a69bf, session 13087, and
completed in actual terminal chunk 825f73 with exit 0 and PASS. It checked 4,010
distinct current pin paths and hashed 16,409,111,789 bytes, with per-file and
final cached-stat stability checks. These counts precede separate final hash
observations. Follow-up original hash/report inspection completed in chunk
7db639, exit 0. No semantic/native/test code or project recorder/helper was
imported, executed or rerun. Only this review file was written.

The exact amended 114-instance preliminary gate is now supported for separate
root admission. Actual native package/admission, all required actual-package
controls, final 115-instance suite, direct native CLI, shared regressions and
remaining independent review are still open under their controlling plans.
