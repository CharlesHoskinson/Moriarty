# Fresh97 durable package proposal — source inventory only

**Status: proposed, not an admission verdict.** Root has observed the completed original outer/recorder/pytest zero exits and exact97 JUnit result. Independent full114 intake is running. No package is created or claimed admitted by this document. Root's final intake decision and review must be present before packaging adopts the aggregate.

**Scope:** A future `evidence/s02-candidate-a-completion/a4/pre-native-aggregate-admission/` package would preserve the completed preliminary17+97 evidence only. It would not establish an actual native package, the final115-instance suite, direct native CLI acceptance, Council acceptance, or A4 completion. The earlier parent exit remains unknown. No further A4 command is proposed here.

## Inputs and original distinctions

The active completed source root is `.superpowers/sdd/a4-task6-resumption-20260906/fresh97/`. Preserve every original top-level byte, including the candidate aggregate as a candidate; record root's later adoption separately. Do not overwrite original statuses or add a fabricated original-parent terminal. The exact dispatch HEAD remains `43f33721da7a3bfb11dd1a91f1f548d5110ab93c` despite later unrelated commits.

Authoritative completed run pins:

| Artifact | SHA256 |
|---|---|
| `fresh97/terminal.json` | `1ecd99090a183136fe205edfabf766f905259efabf0d7c43efd344f16626ea34` |
| `fresh97/pytest-terminal.json` | `44a4947ee0021d7c2a31f55ceb992f4214ee93b5ba8b52d11d02b802d1734bef` |
| `fresh97/junit.xml` | `95dbda943cdba7f74abe1d1c24c1bde2c42ede20b0984001d976a403beec2a7c` |
| `fresh97/fresh-controls.json` | `bccd770eefe588cb4c98e1827c98ba48e102049f33addc87d17e76a69f9ed4e9` |
| `fresh97/aggregate-candidate.json` | `12ae6f549675ae12b037c49a1d6123b310afcedd80acb669b3e7aaf38ba0fc1b` |
| `fresh97/fresh-artifacts.json` | `5148c33e29abe44526f76825d31611f6938c46f3fa7986617412eaab72eed43c` |
| `fresh97/source.tar.gz` | `7055cbd12739c280180361b610813c475b84e5d9d18c432cfd9075d55fe72a8e` |
| `fresh97/outer-tool-receipt.json` | `4783b46637cfc0ee34302ece1f15079c283187bb699c6ebf94fe5d3e0dadb723` |

The original pytest result is97 passed, zero failures/errors/skips, with16 original subprocess exits zero:10 semantic controls, profile substitution, and locators0–4. Recorder and pytest cleanup are complete and unforced. Before/after comparisons cover46 source and3,329 runtime files. These are recorded completed-run observations, not this proposal's independent admission.

The final outer receipt keeps `args` and `responses` and explicitly discloses unavailable intermediate polling metadata. Archive both that receipt and `fresh97-outer-progress.ndjson`. Preserve the gap statement as-is; do not reconstruct missing polls or claim complete polling coverage. The exact launch,87 returned responses including the actual final outer zero, original file-backed streams, and terminal records remain distinguishable. The recorder and pytest were never restarted when the monitor changed.

## Exact small-original inclusion rule

1. Include all21 current top-level regular files below `fresh97/`, listed below.
2. Include all100 regular basetemp members at most2,000,000 bytes according to the authoritative completed `fresh-artifacts.json`. This selects64 original per-child argv/stdout/stderr/terminal records and36 other small artifacts, including the earlier checker cases/raw fixtures and path-control files. The exact100-member list with existing recorded hashes follows. Do not dereference pytest `current` aliases or archive symlinks as regular files. Keep all20 symlink targets and76 directory records in the full manifest.
3. Include the10 explicit resumption source/support/decision/progress files listed below. Include every remaining support input required by `support.json` through the already-pinned59-member `fresh97/source.tar.gz`; the archive audit must verify nested exact membership rather than silently trust its presence.
4. For portable independent assessment of the retained17 side, include the already durable prior compact archive and its index/audit/report/README listed below as original byte members. This duplicates only roughly1.9MB of small evidence, not its9.8GB external raw tree. Verify its exact archive digest/membership and original17 record bindings without executing its archived code.
5. After root intake passes, add the actual independent full114 review and root adoption/dispatch decisions under their real paths. These future paths/hashes are not invented here. Include any root intake receipt referenced by that decision, preserving original tool responses and scope.
6. Create new packaging source, index, standalone audit, README, and actual packaging/audit tool receipts only after root authorizes implementation. Exclusive output paths must reject accidental reuse. New observations cannot rewrite original small evidence.

Current exact fresh97 top-level list:

| Path relative to fresh97 | Bytes |
|---|---:|
| `aggregate-candidate.json` | 118374 |
| `collected-nodeids.json` | 10612 |
| `collection-input.json` | 918 |
| `collection-process.json` | 606 |
| `collection-stderr.txt` | 0 |
| `collection-stdout.txt` | 9994 |
| `collection-terminal.json` | 1114 |
| `fresh-artifacts.json` | 110138 |
| `fresh-controls.json` | 42105 |
| `input.json` | 828609 |
| `intake-summary.json` | 3037 |
| `junit.xml` | 12871 |
| `outer-tool-receipt.json` | 15413 |
| `pytest-input.json` | 10207 |
| `pytest-process.json` | 9898 |
| `pytest-stderr.txt` | 0 |
| `pytest-stdout.txt` | 192 |
| `pytest-terminal.json` | 1104 |
| `retained-admission-binding.json` | 791 |
| `source.tar.gz` | 722712 |
| `terminal.json` | 786710 |

Explicit resumption support/decision/progress members:

- `.superpowers/sdd/a4-task6-resumption-20260906/recorder.py` (33061 bytes)
- `.superpowers/sdd/a4-task6-resumption-20260906/lifecycle_controls.py` (9977 bytes)
- `.superpowers/sdd/a4-task6-resumption-20260906/partition.json` (22111 bytes)
- `.superpowers/sdd/a4-task6-resumption-20260906/reviewed-amendment.md` (20477 bytes)
- `.superpowers/sdd/a4-task6-resumption-20260906/receipt-supplement.md` (8185 bytes)
- `.superpowers/sdd/a4-task6-resumption-20260906/support.json` (3160 bytes)
- `.superpowers/sdd/a4-task6-resumption-20260906/root-dispatch-fresh97.json` (1484 bytes)
- `.superpowers/sdd/a4-task6-resumption-20260906/fresh97-outer-progress.ndjson` (12884 bytes)
- `.superpowers/sdd/a4-task6-resumption-20260906/root-admission17.json` (1771 bytes)
- `.superpowers/sdd/a4-task6-resumption-20260906/root-dispatch-admit17.json` (1505 bytes)

Prior retained17 portable evidence members:

- `evidence/s02-candidate-a-completion/a4/pre-native-recovery-admission/original-small-evidence.tar.gz` (1789372 bytes)
- `evidence/s02-candidate-a-completion/a4/pre-native-recovery-admission/index.json` (62207 bytes)
- `evidence/s02-candidate-a-completion/a4/pre-native-recovery-admission/audit-report.json` (683 bytes)
- `evidence/s02-candidate-a-completion/a4/pre-native-recovery-admission/audit-tool-receipt.json` (1121 bytes)
- `evidence/s02-candidate-a-completion/a4/pre-native-recovery-admission/README.md` (2740 bytes)
- `evidence/s02-candidate-a-completion/a4/pre-native-recovery-admission/audit.py` (17432 bytes)

## External large originals and storage

Do not copy or rehash large generated data while independent intake owns that check. The package's standalone audit must only validate the existing manifests and their original receipt bindings. It must not read external raw trees or the runtime archive.

| External evidence | Authoritative manifest/reference | Size and limitation |
|---|---|---|
| Original `a4-task6-receipts/green-tests/` tree | Retained17 `admit17/original-artifacts.json`, SHA256 `043f61247e1fdafeab98d74ba9487e578aa386227da2855b9df28b805720ba7b` |318 regular files,9,795,796,111 bytes;88 directories;16 symlinks. Original parent exit unknown. Root already admitted individual17 recovery evidence. |
| Fresh `fresh97/basetemp/` tree | `fresh97/fresh-artifacts.json`, SHA256 `5148c33e29abe44526f76825d31611f6938c46f3fa7986617412eaab72eed43c` |274 regular files,6,237,424,864 bytes;76 directories;20 symlinks.174 files exceed2,000,000 bytes and total6,204,874,085 bytes; they remain external. |
| Reused Python environment archive | `a4-checker-task1-receipts/python-environment.tar.gz`, SHA256 `7363d106d464f976af2a0e7f1f56e3c7bed237c7a3396a60d073369add068dac` |3,329-file environment manifest remains bound through original source/runtime receipts and prior compact package. Archive not duplicated or rehashed here. |

The two original data trees together account for16,033,220,975 recorded file bytes. They remain in place with no cleanup or alteration. The selected100 fresh small basetemp files total32,550,779 bytes. Including the enumerated top-level, support/progress, and prior compact evidence inputs gives 37,224,354 bytes before future intake decisions and packaging files. Reserve at least80MB for the small archive plus a possible uncompressed staging copy, or stream directly into a fresh archive; compression size is unmeasured and must not be promised. No duplicate6.2GB or9.8GB raw allocation is required.

## Proposed standalone audit obligations

The audit must open only the new package and nested compact archives, never import or execute archived recorders/tests/helper code, and never rehash large external data. It must verify:

- Exact archive member set, uniqueness, regular-file type, path safety, each recorded byte count/hash, and package source hashes. The manifest-selected100 small basetemp files must match their authoritative fresh-artifact pins exactly; all omitted data is explicitly external.
- The frozen recorder/helper/support hashes, nested59-member source/support archive, reused runtime manifest/archive references, exact46 source and3,329 runtime before-after pairs, zero change lists, and absence of forced/incomplete process cleanup.
- The authentic actual outer exit0 and exact argv/session-source bindings, pytest/recorder terminal0, original JUnit exact97 ordered unique node IDs, no failure/error/skip nodes, and all16 original fresh subprocess argv/report/exit/source-artifact bindings. Keep polling-gap disclosure explicit.
- The previously admitted17 exact identities and original receipts from the prior compact package. Do not credit original54 dots or the incomplete18th original child. Preserve historical assertion inference assumptions and absent historical optimization flags.
- Exact disjoint17+97 union equal to all114 required preliminary node IDs, with each node linked to its particular retained/fresh receipt. Confirm the native package node is excluded solely from this preliminary gate and the later final115 requirement remains.
- Separate root admission of the completed aggregate and independent review, once actually available. Before they exist, the package can only be proposed/candidate evidence; its audit must not emit an aggregate-admitted verdict.
- Unknown original-parent exit, recovery-time original artifact hashes, delayed source endpoints, behavioral historical assertion inference, externally retained raw/runtime archives, and the polling metadata gap. No A4 completion/native acceptance claim may follow.

## Exact100-member basetemp selection from existing manifest

The following inventory is copied from already-recorded manifest metadata/hashes. This proposal did not read or rehash these data files. Paths are relative to `fresh97/basetemp/`.

| Path | Recorded bytes | Recorded SHA256 |
|---|---:|---|
| `test_path_traversal_and_symlin0/honest.json` | 2 | `44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a` |
| `test_path_traversal_and_symlin0/other.json` | 2 | `4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945` |
| `test_provenance_locator_triple0/argv.json` | 632 | `378288bc6713b7d27ee589865ade9a999ef76e5a308266cae1f1ba5063055fee` |
| `test_provenance_locator_triple0/stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `test_provenance_locator_triple0/stdout.txt` | 96 | `93f6904862139222c937a9173bb56593df1d902ae0e57fffc277cf548dc48f13` |
| `test_provenance_locator_triple0/terminal.json` | 11 | `bfdedf06596faa2042b0fedd9653ec1023d2e96ed56dc40b607985bc8438c1d5` |
| `test_provenance_locator_triple1/argv.json` | 632 | `274349dda030b047427c53f0223276ecdbcaf1e99f87a294d7369749ca730c2e` |
| `test_provenance_locator_triple1/stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `test_provenance_locator_triple1/stdout.txt` | 96 | `0941d7bee33a6c7e477ab6086e3130e31a3f54440cf5c87834f186a0c587b552` |
| `test_provenance_locator_triple1/terminal.json` | 11 | `bfdedf06596faa2042b0fedd9653ec1023d2e96ed56dc40b607985bc8438c1d5` |
| `test_provenance_locator_triple2/argv.json` | 632 | `ddfa66a37c1d650508aec041809cfd9495c400b52d8933b36b1017d649c11ff4` |
| `test_provenance_locator_triple2/stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `test_provenance_locator_triple2/stdout.txt` | 96 | `205209965cb9ba9209ab1d90cf2231dea829554f9c55c2703abe21be6a1e312f` |
| `test_provenance_locator_triple2/terminal.json` | 11 | `bfdedf06596faa2042b0fedd9653ec1023d2e96ed56dc40b607985bc8438c1d5` |
| `test_provenance_locator_triple3/argv.json` | 632 | `eac44651e9b1ab30bd01b9815155f96b5ad6a2e7c674ef29bf0cfa968d795c25` |
| `test_provenance_locator_triple3/stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `test_provenance_locator_triple3/stdout.txt` | 96 | `e92b3932563e3de5fb06cee376be59fd25156203bb991b236b5c3a8a87323b4c` |
| `test_provenance_locator_triple3/terminal.json` | 11 | `bfdedf06596faa2042b0fedd9653ec1023d2e96ed56dc40b607985bc8438c1d5` |
| `test_provenance_locator_triple4/argv.json` | 632 | `c2f386f9f49192a2f6a20717f644cdc61bfd2e8a33ffb302bb357d866d0e991d` |
| `test_provenance_locator_triple4/stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `test_provenance_locator_triple4/stdout.txt` | 96 | `3892513ae63df196d7f6ac0ac2f372431eb6835e1195d89971fa0c6f3df29494` |
| `test_provenance_locator_triple4/terminal.json` | 11 | `bfdedf06596faa2042b0fedd9653ec1023d2e96ed56dc40b607985bc8438c1d5` |
| `test_raw_latest_field_substitu0/argv.json` | 643 | `853b7ba9b95607dea8da6ae9adb1db65186e82ebe3f8a84bd977857d32d0a5cb` |
| `test_raw_latest_field_substitu0/stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `test_raw_latest_field_substitu0/stdout.txt` | 107 | `ce51b9bb85011b76f90f3898d611046bebd2c0b3880bddd675754c75a55228d8` |
| `test_raw_latest_field_substitu0/terminal.json` | 11 | `bfdedf06596faa2042b0fedd9653ec1023d2e96ed56dc40b607985bc8438c1d5` |
| `test_semantic_rebound_triples_0/argv.json` | 660 | `ce8ac5286f829314ee5a11052a820d54238f85ef4a2ab72b89a5cfa25dc00d33` |
| `test_semantic_rebound_triples_0/stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `test_semantic_rebound_triples_0/stdout.txt` | 166 | `8addeedea7557bd0bb4e98363bd302831321f08d1c2ea3f0e8dd7f859036f60a` |
| `test_semantic_rebound_triples_0/terminal.json` | 11 | `bfdedf06596faa2042b0fedd9653ec1023d2e96ed56dc40b607985bc8438c1d5` |
| `test_semantic_rebound_triples_1/argv.json` | 652 | `ed1e1d29bd8e10dcee5c56a382246d7b82fb2f04fa21a7ff61728604d63198cd` |
| `test_semantic_rebound_triples_1/stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `test_semantic_rebound_triples_1/stdout.txt` | 158 | `ee19dac052bcc7cad3b30c5a50eaee879984725e3511e407826f450e189f1293` |
| `test_semantic_rebound_triples_1/terminal.json` | 11 | `bfdedf06596faa2042b0fedd9653ec1023d2e96ed56dc40b607985bc8438c1d5` |
| `test_semantic_rebound_triples_2/argv.json` | 646 | `e6081325faec3612eadb8e039f075d40087d68e36a70890ffad83ba642cb1d35` |
| `test_semantic_rebound_triples_2/stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `test_semantic_rebound_triples_2/stdout.txt` | 152 | `d01f5a1f702d464432dece2460288e1da36c156ef028d8a88e3755af523311b6` |
| `test_semantic_rebound_triples_2/terminal.json` | 11 | `bfdedf06596faa2042b0fedd9653ec1023d2e96ed56dc40b607985bc8438c1d5` |
| `test_semantic_rebound_triples_3/argv.json` | 643 | `4371a99c7657ccd67c9f29ab7f3377ce67ce0547e7042394554bbc3a32744aa6` |
| `test_semantic_rebound_triples_3/stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `test_semantic_rebound_triples_3/stdout.txt` | 149 | `538db70bd93c1b5dbd24b4f79f228e90dd9feff3934760dae53e1bd36eeec293` |
| `test_semantic_rebound_triples_3/terminal.json` | 11 | `bfdedf06596faa2042b0fedd9653ec1023d2e96ed56dc40b607985bc8438c1d5` |
| `test_semantic_rebound_triples_4/argv.json` | 645 | `5750da3966899d5638969f1461f13ed79baecf7065f7f64cad0cc47295019f18` |
| `test_semantic_rebound_triples_4/stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `test_semantic_rebound_triples_4/stdout.txt` | 152 | `4e60d733e1e12e6675ef5d3eebcab1ebbd2213d3a5597a69800cf84ae2ef1c3a` |
| `test_semantic_rebound_triples_4/terminal.json` | 11 | `bfdedf06596faa2042b0fedd9653ec1023d2e96ed56dc40b607985bc8438c1d5` |
| `test_semantic_rebound_triples_5/argv.json` | 646 | `a9fc19f6cd7a57e6a357b25bbf5948b0bdc6ae6f17cc885f81c8875c33576615` |
| `test_semantic_rebound_triples_5/stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `test_semantic_rebound_triples_5/stdout.txt` | 153 | `41350eb4ffcbddd906a87b1b5ac1509b0e8841342f69e4d1beeaf2a7d42728a8` |
| `test_semantic_rebound_triples_5/terminal.json` | 11 | `bfdedf06596faa2042b0fedd9653ec1023d2e96ed56dc40b607985bc8438c1d5` |
| `test_semantic_rebound_triples_6/argv.json` | 645 | `3009e793045ea4b02cd8a1b3025e40f9a7fa43393e53d54c7273e2c9494d87e4` |
| `test_semantic_rebound_triples_6/stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `test_semantic_rebound_triples_6/stdout.txt` | 151 | `30cb3904df671ae284172dbe23befcd52136626eac518390442e7738cb9ea4f2` |
| `test_semantic_rebound_triples_6/terminal.json` | 11 | `bfdedf06596faa2042b0fedd9653ec1023d2e96ed56dc40b607985bc8438c1d5` |
| `test_semantic_rebound_triples_7/argv.json` | 646 | `fc3ceee41b0380ec3a19fd9d48a73389d3440cd5e4a183042e1d3591af70c86b` |
| `test_semantic_rebound_triples_7/stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `test_semantic_rebound_triples_7/stdout.txt` | 153 | `a042e8f58d3e14317931e9338925ae2ec797ed2757833a3f8fca44d51b491912` |
| `test_semantic_rebound_triples_7/terminal.json` | 11 | `bfdedf06596faa2042b0fedd9653ec1023d2e96ed56dc40b607985bc8438c1d5` |
| `test_semantic_rebound_triples_8/argv.json` | 645 | `ac38b7c37bc8db7a925388b6cb2e1d98c84c7b8c96405a7a76c2b51130a04130` |
| `test_semantic_rebound_triples_8/stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `test_semantic_rebound_triples_8/stdout.txt` | 152 | `1ade524f3fa16d3a42ccb56e35c0fc3aabf6bdd7f7676725892374b882b4d481` |
| `test_semantic_rebound_triples_8/terminal.json` | 11 | `bfdedf06596faa2042b0fedd9653ec1023d2e96ed56dc40b607985bc8438c1d5` |
| `test_semantic_rebound_triples_9/argv.json` | 653 | `7da81752b1320637f5f676af991bdfb2e4d14ccc3cc410376a31ddba8454b008` |
| `test_semantic_rebound_triples_9/stderr.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `test_semantic_rebound_triples_9/stdout.txt` | 160 | `c6e76869159bdf3eafe05aa60c4f01de985c5ee32406fff79a89410bda347a72` |
| `test_semantic_rebound_triples_9/terminal.json` | 11 | `bfdedf06596faa2042b0fedd9653ec1023d2e96ed56dc40b607985bc8438c1d5` |
| `test_sharded_bounded_matches_b0/case-36.json` | 1190242 | `c6f266518ebe1d3dcf0fa5663ecd9b4d4d509fc11ade9d2513361530d791329f` |
| `test_sharded_bounded_matches_b0/raw-36.json` | 723766 | `cddfcf4569951f777a49c9d43fa9212985a5042b1f75dfa11ec6af04f6e4ee87` |
| `test_sharded_bounded_matches_b1/case-37.json` | 1190260 | `7a8756fdd82ce524a1941f9cce3ebe9813560756016cf45e7536b41b5ed2193d` |
| `test_sharded_bounded_matches_b1/raw-37.json` | 723782 | `ba8cfbede9eee7e54c0891cf11ae82d9bd27f3ee5893a61d971f37b71bc40ea9` |
| `test_sharded_case_controls_des0/case-36.json` | 1190243 | `34cc1172740ebcac7c193d4c0753799825161165b719ae780c0a02514d1cda2f` |
| `test_sharded_case_controls_des0/raw-36.json` | 723766 | `cddfcf4569951f777a49c9d43fa9212985a5042b1f75dfa11ec6af04f6e4ee87` |
| `test_sharded_case_controls_ext0/case-36.json` | 1433396 | `5377bfb61c15842aa36ea8b65367ba6b0153f3954a8778a6b541c2ad2fcac21e` |
| `test_sharded_case_controls_ext0/raw-36.json` | 723766 | `cddfcf4569951f777a49c9d43fa9212985a5042b1f75dfa11ec6af04f6e4ee87` |
| `test_sharded_case_controls_ini0/case-36.json` | 1190242 | `d72a1ed1e8a2b5244fcabb5e07feff61e207ecef17f4ef4b1440464fdb76a8da` |
| `test_sharded_case_controls_ini0/raw-36.json` | 723766 | `cddfcf4569951f777a49c9d43fa9212985a5042b1f75dfa11ec6af04f6e4ee87` |
| `test_sharded_case_controls_mis0/case-36.json` | 947088 | `41dc26eaf89f32a0dfc31b3a0caea20e5a415b68c81e1b4111771544dcad6aa0` |
| `test_sharded_case_controls_mis0/raw-36.json` | 723766 | `cddfcf4569951f777a49c9d43fa9212985a5042b1f75dfa11ec6af04f6e4ee87` |
| `test_sharded_raw_controls_curs0/case-36.json` | 1190242 | `a6a510ca4861ba602db6355c0dc24564a8cbd42eab7b1231f001621c0c5e708b` |
| `test_sharded_raw_controls_curs0/raw-36.json` | 723755 | `2af2b91e928d3a61ba0d600c6465d9104aa1466b15006c22358063db305684c1` |
| `test_sharded_raw_controls_extr0/case-36.json` | 1190242 | `c6516490b4ced67836498e1310adeb0e7b0f7ef15f6514c4d3d8dd496508dcfd` |
| `test_sharded_raw_controls_extr0/raw-36.json` | 845517 | `1994845715b43ddfc93e39e841f6c8287152389c34c8766aa3de2ec6db3225d8` |
| `test_sharded_raw_controls_inde0/case-36.json` | 1190242 | `36fffae8007caaa2286fd01cf7af37b6885ad1761a0ab8845a79345cfd3d5e93` |
| `test_sharded_raw_controls_inde0/raw-36.json` | 723767 | `31be17eb5fd86f2a28cffd273ed8d2e7d720c03199d5afc00dc097c3363a196a` |
| `test_sharded_raw_controls_miss0/case-36.json` | 1190242 | `aec62be33ea1c415531a728cab291a3c69301bfb50c507c9adf20cdcf04db375` |
| `test_sharded_raw_controls_miss0/raw-36.json` | 602015 | `65794f4a262f388549e2c15c240fe455a40c43ab4518b6cb8a06dab3c9d5b69a` |
| `test_sharded_raw_controls_ordi0/case-36.json` | 1190242 | `bd8e606f6ac5552f7cd30aa1a63f1909db5a6055227b780d044ae19a25bfd269` |
| `test_sharded_raw_controls_ordi0/raw-36.json` | 723765 | `c0dca3e2794926f07d0af70349c43333c4ed4c65f75ab8cfcf1e39516bac6706` |
| `test_sharded_raw_controls_sequ0/case-36.json` | 1190242 | `14a488ed21cb0ecd20fbd43f0c8bddb6d32113236c639854ec96818b1ed187d7` |
| `test_sharded_raw_controls_sequ0/raw-36.json` | 723767 | `c0b4a6b289debceeaf4b871d644bef0e585320e5019ea8056382f2a6398f8c8b` |
| `test_sharded_raw_controls_stat0/case-36.json` | 1190242 | `63ef263df6bfecb3801d970f947fc9e6ea33e787e314720f780240715a0263f4` |
| `test_sharded_raw_controls_stat0/raw-36.json` | 723769 | `6f2609f699d0fbf4bdab07bf00d0914f95d2ad6860e013e459ff36ff1a7b27dc` |
| `test_sharded_raw_controls_vars0/case-36.json` | 1190242 | `74f128d6c824011b6a0d3810d31fe60624853cd7fdd187c6b229bc7c61c164b3` |
| `test_sharded_raw_controls_vars0/raw-36.json` | 723766 | `7eb8971c0eb536a1ecb6d12b35d6d0e0d436e79ee8c5d7a10e7947a1755c1533` |
| `test_sharded_stream_suffix_fai0/case-36.json` | 1190251 | `41e7d7ab72db0e82a20aa5d5b099b084b7b88a6200b16f7ed2e9ef9353662c4f` |
| `test_sharded_stream_suffix_fai0/raw-36.json` | 723766 | `cddfcf4569951f777a49c9d43fa9212985a5042b1f75dfa11ec6af04f6e4ee87` |
| `test_sharded_stream_suffix_fai1/case-36.json` | 1190242 | `d9714ddadd6a3dd5c73198988d031264a57bce65cc43e995b9de95aa8e211368` |
| `test_sharded_stream_suffix_fai1/raw-36.json` | 723775 | `f3a4ba615a7f747e1f4a7d081a0aa77c260c02afe5926abfbee04bb0baed6bfb` |
| `test_sharded_window_profile_re0/case-36.json` | 1190242 | `c6f266518ebe1d3dcf0fa5663ecd9b4d4d509fc11ade9d2513361530d791329f` |
| `test_sharded_window_profile_re0/raw-36.json` | 723766 | `cddfcf4569951f777a49c9d43fa9212985a5042b1f75dfa11ec6af04f6e4ee87` |

**Actions in this proposal:** Read small JSON receipts/manifests, list/stat small original paths, and hash only small top-level completed receipts to bind the inventory. No package/admission verdict was created, no large raw file was copied or hashed, no native/test/source/runtime file was changed, and no commit occurred. A5's separately owned full diagnostic remains active; this task introduces no execution overlap.
