# A4 checker Task2 implementation report

Status: Task2 implementation and local verification complete. Root admission is pending. No Task3 work, commit, index update, producer change, or Council claim.

Base: `9f9cfda2569762eba8e4e2917ebf0e40b8609969`.
Plan SHA256: `2edb50ec93c88c62d8fddf1ba9d29b893e494b1564d28fdef6dd82674fca739e`.
Immutable interface addendum: `ab7c827`; no Task2 semantic change.

## Final source

- `scripts/a4_authority.py`: `d59770b3a15552d32164f573fe5b350ce98c9c7bdde3aafb7de31fe0a3551e61`.
- `tests/test_s02_candidate_a_integrated.py`: `2d405d87b74e252c11da4ca1a919ac7f2d53d1afc1831c798c8d25bc7218df59`.
- Ignored recorder: `.superpowers/sdd/a4-checker-task2-receipts/recorder.py`, SHA256 `4104866bea983855b791ace6ee39eb4fd2ab97255b7111ba422eafdf284ada19`.

The authority source equals the complete adopted Task2 code block byte-for-byte. The test file equals the committed Task1 file, one separating newline, and the exact adopted Task2 test block. Task1 carrier and agreement modules are unchanged. Other agents' three untracked plans were preserved.

## Original runtime evidence

Receipts are in `.superpowers/sdd/a4-checker-task2-receipts/`. Each stage retains exclusive-created original source archive, input manifest, separate stdout/stderr, and terminal manifest. Command cwd is this experiment worktree; actual interpreter is `/home/charl/Moriarty/.venv/bin/python`. Each command uses a fresh pycache path with bytecode writes disabled.

| Stage | Terminal exit | Result |
| --- | --- | --- |
| tests-first | 2 | Expected missing authority module collection error, before implementation; not behavioral RED |
| red-syntax | 0 | Carrier, agreement, and test syntax only |
| red-import | 0 | Actual carrier, agreement, and authority imports succeed; authority compiles here |
| red-tests | 1 | `test_uncoupled_rejection_is_reachable` fails at its intended `can_reject` assertion; six other tests pass |
| green-syntax | 0 | All four final Python files compile |
| green-import | 0 | All three final modules import |
| green-tests | 0 | Seven tests pass, no exclusions |

RED authority SHA256 is `cb40235d4874e2d7ae427b4803b410c36a94dca4713fadb7576a4d5f0917e6b8`. Its sole difference from final source is the prescribed early `return False` when current candidate/ledger coupling fails in `can_reject`. The typed uncoupled state reaches that assertion. The correction removes only this condition.

Recorder clarification: the original red-syntax command did not include authority in its explicit compile tuple. The retained red-import command imported authority successfully before the behavioral RED, so the RED is demonstrably compiling. Before GREEN, the recorder's green-syntax tuple was expanded to include authority. Original RED receipts and recorder bytes remain intact in their archives.

Every terminal manifest reports empty `sourceChanged` and `environmentChanged` lists. A final read-only audit verified every archived source member against its input pin, each archive hash, and both terminal stream hashes for all seven stages. It also compared archived RED authority bytes with final source and confirmed the sole prescribed line deletion.

Task1's existing 3,329-file Python environment is referenced by path and hash, not copied. Shared manifest SHA256: `cd004057c4067bf7cc536d2cec5038add88d0852c1a7de5030e402ff2204f9c4`. Shared archive SHA256: `7363d106d464f976af2a0e7f1f56e3c7bed237c7a3396a60d073369add068dac`. Every stage verifies its unchanged files and interpreter. Per-command archives include the local Python import closure, frozen common/A source closure used for derivation, recorder, brief, plan, and addendum.

## Rule-by-rule source self-review

Compared the complete implementation against frozen effects, consumption, observations, policies, authorization, execution, A adapter, and A boundary rules. No discrepancy found within the typed input domain and guarded-update contract.

- Effects: complete finite ledger, asset/location compatibility, positive transfers, ordered balance checks and updates, multiset policy constraints, and exact-order option are retained.
- Policy and fidelity: full policy body, capabilities, owner debit locations, finite mechanisms, inclusive policy validity bounds, conditions, optional choices, full planned records and predecessor facts are checked. Sign-after validates all 1–4 planned operations, original/future program content, and equality of the outer operations with the plan identity. Agreement results use the unchanged independent Python Core bridge; cancellation has no invented Core transaction.
- Parent accounting: exact Alice nonce0 parent, ordered slots, claim equality, allowance/paid/revision equations, cancellation residual, and prepared-entry equality match consumption rules.
- Preparation and signing: exact own registry cell and dependent parent cells/authorities are snapshotted; unrelated registry cells are excluded. Full policy, signer, token, current snapshot, unused key, and resulting context checks match common/A. Signing does not transfer funds or consume a nonce.
- Proposal and evidence: finite attempt IDs are single-use; permissive proposals retain their full observation/context without authenticating them prematurely. Required authority keys, exact proof domains, proof/attempt equality, signed registrations, and limited consumed-parent reuse are checked at verification and again at commit.
- Direct probes: FinancialGuard calls the exact financial predicate without extra context-validity or valid-operation conditions. Recovery requires cancellation, positive allowance, matching escrow balance, and exact refund. Cancellation requires empty effects; non-parent operations require nonempty effects. Parent cancel/consume probes retain full caller-supplied parent, entry, and prepared arguments.
- Rejection: only the four-map structural envelope is required, so failed coupling cannot strand proposed or verified records. A fidelity/policy/coupling failure precedes the common classifier. Common precedence remains stale bindings, invalid context/operation, missing evidence, invalid evidence, known Core rejection, consumption conflict, then unauthorized fallback. Rejected records retain attempt, evidence, observed context, reason, and stage; authority state is unchanged.
- Commit: the guard rechecks freshness and fidelity. Candidate, ordered ledger effects, registry consumption, parent accounting, and executed status change in one immutable returned state. Parent revisions increment from their actual entry; recovery consumes nonce1 without rewriting nonce0 parent history. Advance only changes the environment under its exact gate.

## Limits and handoff

This is author self-review plus seven focused local tests, not independent acceptance, full lifecycle replay, exported-trace checking, model checking, cryptographic verification, or Council evidence. Public raw-envelope validation and case inventory dispatch belong to later tasks. Internal rule functions assume structurally typed carriers; update helpers assume their guards, while `apply` checks the gate. Symbolic evidence dispositions remain modeled premises.

The implementation and TDD skills kept this change bounded to the adopted Task2 code and a genuine compiling behavior failure. Root owns independent byte/receipt admission before Task3. No source beyond the two owned Task2 paths changed.
