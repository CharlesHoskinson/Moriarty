# A4 checker Task2 bounded execution

Root admitted Task1 at9f9cfda. Base is that commit; record its full resolved SHA
before starting. Follow Task2 only in the immutable adopted independent-replay
plan (SHA2562edb50ec93c88c62d8fddf1ba9d29b893e494b1564d28fdef6dd82674fca739e),
plus replay-interface addendum ab7c827. Do not edit those documents.

Own scripts/a4_authority.py and append-only Task2 tests in
tests/test_s02_candidate_a_integrated.py. Existing Task1 source/tests stay exact.
Use ignored .superpowers/sdd/a4-checker-task2-receipts/ and report
.superpowers/sdd/a4-checker-task2-report.md. No other source, evidence tree,
main/wiki/DB/index/commit or Foreman work. Other agents own their plans.

Implement the complete independently derived authority guard/update/reason
block. The required compiling RED returns False in can_reject when coupling
fails; the typed uncoupled-rejection assertion must fail, not collection/import.
Restore only that fault and retain terminal all-tests GREEN with no exclusions.
Preserve original RED bytes, command/cwd, separate stdout/stderr, actual terminal
exit and unchanged before/after complete source/import and runtime closure.
Reuse Task1's unchanged shared Python environment snapshot by exact archive and
manifest hash, not a fresh duplicate. Include Task1 modules, new authority,
test, frozen common/A sources used for rule derivation, recorder, plan/addendum,
brief and actual Python Core import closure in per-command source snapshots.
Use fresh pycache paths, no previous bytecode; record actual interpreter.

Inspect rules against original effects, consumption, observations, policies,
authorization, execution and A-boundary modules. No invented context-validity
conjuncts in direct FinancialGuard. Preserve exact rejection precedence and
complete atomic state updates. Native implementation is not Council evidence.
Stop after Task2 terminal report. Root owns independent admission before Task3.
