# A4 streaming writer/hash Task2 dispatch

ReaderTask1 is independently admitted with29 GREEN tests and original escaped
duplicate-key RED; root's six-stage/seven-source/3329runtime audit passed.
Implement only Task2 of adopted streaming plan22cdec6, exact source/test appends.
Preserve all admitted reader bytes. No producer/checker consumer changes yet.

Use tests first, retain missing-function diagnostic separately, then importable
short-write advance omission RED, restoring only that line for full GREEN.
Use new .superpowers/sdd/a4-stream-writer-task2-receipts/ and report
.superpowers/sdd/a4-stream-writer-task2-report.md. Archive exact plan/brief/recorder/
source/test/config bytes with original streams and before/after runtime pins.
Reuse3329-file Python store; no duplication. Record actual current HEAD as base.

Future recorder input must retain sys.orig_argv for the parent process and assert
process-start -B and the exact fresh -X pycache_prefix. Child argv/cache stays
explicit. Do not rewrite reader original receipts, whose parent settings remain
author-reported. Do not import moving producer files into focused utility tests.

Root has read/reviewed complete writer/hash code and all tests. After full suite
GREEN, freeze source and await independent admission before consumer integration.
No commits/main/wiki/DB/Council/Foreman changes. Every original failure is retained.
