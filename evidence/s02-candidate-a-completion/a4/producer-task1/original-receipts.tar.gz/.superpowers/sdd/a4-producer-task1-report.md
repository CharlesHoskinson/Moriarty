# A4 producer Task0–1 author report

Status: Task0–1 author implementation and verification complete; frozen for root intake. This report is not admission, independent replay, or Council acceptance.

## Authority and scope

Adopted plan commit and producer pre-dispatch base: `386bf0ae10f767e051b414a7231be105cc4b0f71`.
Plan SHA256: `edca754fafb2bba2ef4ead9fb97fa887e60aeb69bcd5890c0f0ca705e6d3d1f6`.
The controlling brief is `.superpowers/sdd/a4-producer-task1-brief.md`.
Only the five authorized source/test files and this unique ignored report/receipt tree are owned by this task. No Task2 cases, driver, instantiations, acceptance traces, exporter, shared source edits, main/wiki/DB changes, or commits are authorized.

The executing-plans and test-driven-development skills guide the scoped RED/GREEN stages. Quint modeling/language guidance is used for typed pure observer functions, separate tests and diagnostic separation. This uses the already admitted shared-state model, not a new message-passing model. The existing linked worktree is reused; root owns baseline shared regressions. No new dependency installation or subagent dispatch occurs.

## Task0 bootstrap

Repository observation: the recorder was extracted verbatim from the adopted Task0 code block and created using apply_patch. AST parsing terminated0 before the smoke. The smoke requested Python --version and used the exact fresh stage-specific -B/-X launcher. Raw terminal files and receipt are under `.superpowers/sdd/a4-producer-receipts/recorder-smoke/`.

Experiment observation: terminal recorder exit0; child exit0; source_stable=true; runtime_stable=true. Child stdout was `Python 3.13.14` followed by newline; stderr had0bytes. Source closure contained31files and explicitly listed7not-yet-created planned files; runtime before/after maps each contained8102pins. This validates recorder execution/closure checks for this smoke, not model or interpreter semantics.

The shared A5 store was reused, never recreated or changed. Producer pre-dispatch base is separate from the shared A5 dispatch base and the per-command sourceCommit. Runtime helper source is separately pinned/copied in receipts, not added to semantic source_pins.

## Concurrency discipline

After the terminal smoke, root requested a checkerTask5 edit window. No producer command remained live. Recorder launches were paused while only owned inventory/observer tests and initial scaffolds were created. Root freeze confirmation is required before the next recorded stage. Existing dirty checker and A5 files are preserved read-only.

## Current behavioral stages

Root subsequently announced checkerTask5 source freeze; recorded work resumed.

Inventory RED terminated1 with exactly2assertion failures: `len(cases)==78` observed0 and `len(selected)==10` observed0. No import or syntax failure occurred. The original empty-body source closure and raw terminal streams are in `inventory-red`. Only then was the adopted fixed enumerator implemented. `inventory-green` terminated0 with `2 passed in 0.01s`. Both receipts show source_stable=true and runtime_stable=true.

Observer scaffold recursive typecheck terminated0 with empty stdout/stderr and stable source/runtime closure. `observer-red` then terminated1 with `actualDepositObservationTest` failing at the expected QNT508 assertion and `cancellationHasNoComputationTest` passing. This is a compiling behavioral RED for the missing actual deposit computation; no constructor, import, diagnostic, or fixture failure is substituted for RED.

Only after that terminal RED was the adopted Task1 observer implementation applied. Two planned supplemental tests were then added for preserving OutsideModelDomainA and the two agreement computations' plan order. Their first successful execution, if achieved, is supplemental coverage, not an original failing-first claim.

The first final `observer-types` and `observer-green` attempts both terminated1 at QNT404 during parsing. The adopted implementation block used the unsupported nested pattern `ExtractionObservedA4(EffectsExtractedA(_))` in computedA4. These are nonbehavioral parser failures, not additional semantic REDs. Both original closures and terminal streams remain retained. Systematic debugging compared the failure against the Quint language constraint that patterns match one layer; root approved a narrow correction to two sequential matches, with exactly the same predicate. No test assertion or source semantics was weakened. Fresh `observer-types-2` and `observer-green-2` were then launched; their successful terminal results appear below.

The new observer performs an actual second evaluation at the boundary, retaining original requests, tagged transaction outcomes and tagged effect extraction. It does not inspect an internal evaluator execution, independently establish correspondence, or convert diagnostics into Core rejection. Cancellation emits no computation. Direct guard/update helpers delegate to unchanged common/A operations; Task2 command lowering and full event replay remain outside this unit.


## Final verification and source freeze

Experiment observation: corrected observer-types-2 terminated0 with empty stdout/stderr; corrected observer-green-2 terminated0 with all4named tests passing. Final source is frozen for root admission. No producer jobs remain live. No commits were made. Task2 and the subsequently adopted case-sharded transport remain unimplemented here.

Artifact index: `.superpowers/sdd/a4-producer-receipts/task1-artifact-index.json`. It records exact requested/executed commands, sourceCommit before/after, nanosecond elapsed times, terminal exits, original receipt/stream/closure/helper hashes and a canonical sorted member-map digest per stage. A read-only audit verified every source snapshot byte against its closure map, raw stream hashes, copied runtime helper hashes and source/runtime stability for all9stages:692original stage files, including638source-byte snapshot files. The index and this report are additional handoff files, not counted among originals. No original source snapshot or failed receipt was modified.

Smoke had31source files; every subsequent stage had36. The remaining3explicitly missing future files are the old two full-loop export entries and exporter script. Their absence is not waived from final acceptance; the new transport addendum will replace those export roots. Producer beforeDispatchCommit remains386bf0ae10f767e051b414a7231be105cc4b0f71 even when root's unrelated commits change command sourceCommit. Runtime maps each contain8102pins.

| Stage | Child / recorder exit | Elapsed seconds | Interpretation |
| --- | --- | --- | --- |
| recorder-smoke | 0 / 0 | 0.002200054 | Nonbehavioral recorder smoke |
| inventory-red | 1 / 1 | 0.776980803 | Behavioral inventory RED:2assertion failures |
| inventory-green | 0 / 0 | 0.761673715 | Inventory GREEN:2tests |
| observer-scaffold-types | 0 / 0 | 273.091856156 | Typed observer scaffold |
| observer-red | 1 / 1 | 288.142917579 | Behavioral observer RED:1failure/1pass |
| observer-types | 1 / 1 | 2.379315235 | Nonbehavioral nested-pattern parser failure |
| observer-green | 1 / 1 | 2.391301672 | Same nonbehavioral parser failure |
| observer-types-2 | 0 / 0 | 337.997749866 | Corrected recursive typecheck |
| observer-green-2 | 0 / 0 | 354.813567421 | Corrected observer GREEN:4tests |

### Frozen owned source hashes

- `scripts/record_s02_candidate_a_integrated.py`: `968b61971e4e0a1f96fd788141e69b2561cee20de779f97a4cc3a533ba6a8754`.
- `scripts/s02_candidate_a_integrated_inventory.py`: `4cdeddd0750838833665bed4b458923f604cb0e04eb8dc56a0517751c615643b`.
- `specs/quint/s02/candidate_a_integrated_export_test.qnt`: `f1350eba6ec20e62459633d1d17b9bade1c823bd0fc552b7f6ff0b6661fac802`.
- `specs/quint/s02/candidate_a_integrated_observer.qnt`: `f1cb3a58c7678606c99cba650789da6816720075137d753f1dee97e3aab22c27`.
- `tests/test_s02_candidate_a_integrated_export.py`: `a0d6c8c54cdc30025fbd115b7ea4d414b5c627917ce005e279a8e8396aa7e2c5`.

A read-only filename-keyed comparison confirmed all5owned source bodies match the adopted Task0/1 blocks, except the approved sequential-match correction. An earlier ad-hoc comparison incorrectly assumed JSON map iteration order and aborted; correcting that comparison required no source edit. Neither comparison is behavioral test evidence.

### Exact commands and full child terminal streams

Cwd for every command: `/home/charl/Moriarty/.worktrees/s01-audit-start`. Raw bytes, including empty streams, remain in each named stage. Source/runtime were stable for all9commands. Durations above measure child execution, not bootstrap hashing overhead.

#### recorder-smoke

```bash
'/home/charl/Moriarty/.venv/bin/python' '-B' '-X' 'pycache_prefix=.superpowers/sdd/a4-producer-receipts/recorder-smoke/python-cache' 'scripts/record_s02_candidate_a_integrated.py' '--stage' 'recorder-smoke' '--' '/home/charl/Moriarty/.venv/bin/python' '--version'
```

Terminal recorder exit: 0; child exit: 0.

Full stdout:

```text
Python 3.13.14
```

stderr: empty (0bytes).

#### inventory-red

```bash
'/home/charl/Moriarty/.venv/bin/python' '-B' '-X' 'pycache_prefix=.superpowers/sdd/a4-producer-receipts/inventory-red/python-cache' 'scripts/record_s02_candidate_a_integrated.py' '--stage' 'inventory-red' '--' '/home/charl/Moriarty/.venv/bin/python' '-m' 'pytest' 'tests/test_s02_candidate_a_integrated_export.py' '-q' '-k' 'exact_inventory or mutant_dual'
```

Terminal recorder exit: 1; child exit: 1.

Full stdout:

```text
FF                                                                       [100%]
=================================== FAILURES ===================================
_____________________________ test_exact_inventory _____________________________

    def test_exact_inventory():
        cases = inventory()["cases"]
>       assert len(cases) == 78
E       assert 0 == 78
E        +  where 0 = len([])

tests/test_s02_candidate_a_integrated_export.py:5: AssertionError
________________ test_mutant_dual_boundaries_and_original_bases ________________

    def test_mutant_dual_boundaries_and_original_bases():
        selected = [(d, steps) for d, steps in instructions() if
                    d["control"] in ("unused-successor", "reversed-effects", "reductions", "neutral-chooser")]
>       assert len(selected) == 10
E       assert 0 == 10
E        +  where 0 = len([])

tests/test_s02_candidate_a_integrated_export.py:19: AssertionError
=========================== short test summary info ============================
FAILED tests/test_s02_candidate_a_integrated_export.py::test_exact_inventory
FAILED tests/test_s02_candidate_a_integrated_export.py::test_mutant_dual_boundaries_and_original_bases
2 failed in 0.02s
```

stderr: empty (0bytes).

#### inventory-green

```bash
'/home/charl/Moriarty/.venv/bin/python' '-B' '-X' 'pycache_prefix=.superpowers/sdd/a4-producer-receipts/inventory-green/python-cache' 'scripts/record_s02_candidate_a_integrated.py' '--stage' 'inventory-green' '--' '/home/charl/Moriarty/.venv/bin/python' '-m' 'pytest' 'tests/test_s02_candidate_a_integrated_export.py' '-q' '-k' 'exact_inventory or mutant_dual'
```

Terminal recorder exit: 0; child exit: 0.

Full stdout:

```text
..                                                                       [100%]
2 passed in 0.01s
```

stderr: empty (0bytes).

#### observer-scaffold-types

```bash
'/home/charl/Moriarty/.venv/bin/python' '-B' '-X' 'pycache_prefix=.superpowers/sdd/a4-producer-receipts/observer-scaffold-types/python-cache' 'scripts/record_s02_candidate_a_integrated.py' '--stage' 'observer-scaffold-types' '--' 'quint' 'typecheck' 'specs/quint/s02/candidate_a_integrated_export_test.qnt'
```

Terminal recorder exit: 0; child exit: 0.

stdout: empty (0bytes).

stderr: empty (0bytes).

#### observer-red

```bash
'/home/charl/Moriarty/.venv/bin/python' '-B' '-X' 'pycache_prefix=.superpowers/sdd/a4-producer-receipts/observer-red/python-cache' 'scripts/record_s02_candidate_a_integrated.py' '--stage' 'observer-red' '--' 'quint' 'test' 'specs/quint/s02/candidate_a_integrated_export_test.qnt' '--backend=rust' '--seed=42' '--match' '.*Test'
```

Terminal recorder exit: 1; child exit: 1.

Full stdout:

```text

  candidate_a_integrated_export_test
    1) actualDepositObservationTest failed after 1 test(s)
    ok cancellationHasNoComputationTest passed 1 test(s)

  1 passing (6869ms)
  1 failed

  1) actualDepositObservationTest:
       Error [QNT508]: Assertion failed
        at /home/charl/Moriarty/.worktrees/s01-audit-start/specs/quint/s02/candidate_a_integrated_export_test.qnt:20:36
        20: run actualDepositObservationTest = assert({
                                               ^^^^^^^^
        21:   val request = {before: beforeS(0), input: PresentAInput(DepositInputA({
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        22:     account: aliceA, depositor: Alice, quantity: 10})), now: Time1}
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        23:   val recorded = callComputationsA4(AgreementCallA(request))
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        24:   if (recorded.length() != 1) false else recorded.nth(0).request == request
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        25:     and recorded.nth(0).evaluation == computeTransaction(programS, request.before.state, request.input, Time1)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        26:     and match recorded.nth(0).evaluation {
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        27:       | TransactionComputedA(raw) => raw.accepted and raw.payments == List()
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        28:           and recorded.nth(0).extraction == ExtractionObservedA4(EffectsExtractedA(List({
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        29:             source: Wallet(Alice), destination: Escrow(aliceA), asset: TokenA, quantity: 10})))
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        30:       | _ => false }
            ^^^^^^^^^^^^^^^^^^^^
        31: })
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    Use --seed=0x2a --match=actualDepositObservationTest to repeat.


  Use --verbosity=3 to show executions.
  Further debug with: quint test --verbosity=3 specs/quint/s02/candidate_a_integrated_export_test.qnt
```

Full stderr:

```text
error: Tests failed
```

#### observer-types

```bash
'/home/charl/Moriarty/.venv/bin/python' '-B' '-X' 'pycache_prefix=.superpowers/sdd/a4-producer-receipts/observer-types/python-cache' 'scripts/record_s02_candidate_a_integrated.py' '--stage' 'observer-types' '--' 'quint' 'typecheck' 'specs/quint/s02/candidate_a_integrated_export_test.qnt'
```

Terminal recorder exit: 1; child exit: 1.

stdout: empty (0bytes).

Full stderr:

```text

 Error [QNT404]: Name 'match' not found

  at /home/charl/Moriarty/.worktrees/s01-audit-start/specs/quint/s02/candidate_a_integrated_observer.qnt:104:47
  104: pure def computedA4(c: A4Computation): bool = match c.evaluation {
                                                     ^^^^^

error: parsing failed
```

#### observer-green

```bash
'/home/charl/Moriarty/.venv/bin/python' '-B' '-X' 'pycache_prefix=.superpowers/sdd/a4-producer-receipts/observer-green/python-cache' 'scripts/record_s02_candidate_a_integrated.py' '--stage' 'observer-green' '--' 'quint' 'test' 'specs/quint/s02/candidate_a_integrated_export_test.qnt' '--backend=rust' '--seed=42' '--match' '.*Test'
```

Terminal recorder exit: 1; child exit: 1.

stdout: empty (0bytes).

Full stderr:

```text

 Error [QNT404]: Name 'match' not found

  at /home/charl/Moriarty/.worktrees/s01-audit-start/specs/quint/s02/candidate_a_integrated_observer.qnt:104:47
  104: pure def computedA4(c: A4Computation): bool = match c.evaluation {
                                                     ^^^^^

error: parsing failed
```

#### observer-types-2

```bash
'/home/charl/Moriarty/.venv/bin/python' '-B' '-X' 'pycache_prefix=.superpowers/sdd/a4-producer-receipts/observer-types-2/python-cache' 'scripts/record_s02_candidate_a_integrated.py' '--stage' 'observer-types-2' '--' 'quint' 'typecheck' 'specs/quint/s02/candidate_a_integrated_export_test.qnt'
```

Terminal recorder exit: 0; child exit: 0.

stdout: empty (0bytes).

stderr: empty (0bytes).

#### observer-green-2

```bash
'/home/charl/Moriarty/.venv/bin/python' '-B' '-X' 'pycache_prefix=.superpowers/sdd/a4-producer-receipts/observer-green-2/python-cache' 'scripts/record_s02_candidate_a_integrated.py' '--stage' 'observer-green-2' '--' 'quint' 'test' 'specs/quint/s02/candidate_a_integrated_export_test.qnt' '--backend=rust' '--seed=42' '--match' '.*Test'
```

Terminal recorder exit: 0; child exit: 0.

Full stdout:

```text

  candidate_a_integrated_export_test
    ok actualDepositObservationTest passed 1 test(s)
    ok cancellationHasNoComputationTest passed 1 test(s)
    ok diagnosticRemainsDiagnosticTest passed 1 test(s)
    ok planComputationOrderTest passed 1 test(s)

  4 passing (16903ms)
```

stderr: empty (0bytes).

## Scope limits and handoff

These results establish the finite inventory tests and pure observer assertions at frozen bytes. They do not establish complete authority-event replay, native export feasibility, full78case execution, source-independent correspondence, cryptographic evidence validity, model checking, integration, or Council acceptance. The diagnostic/order assertions are supplemental GREEN coverage. The2parser failures remain process deviations, not fabricated semantic REDs.

This author previously implemented Candidate A evaluator/lifecycle code and now authors the producer; no independent-source-review claim is made. Root owns nonauthor review, original archive admission and any subsequent commit/dispatch. No Foreman/session database, main-worktree, shared semantics, checker source, or evidence archive was changed. Ready for bounded Task1 intake only.
