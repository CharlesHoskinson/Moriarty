"""Finite A4 inventory: initial behavioral RED scaffold."""


def instructions():
    return iter(())


def inventory():
    return {"schema_version": 2, "cases": []}
