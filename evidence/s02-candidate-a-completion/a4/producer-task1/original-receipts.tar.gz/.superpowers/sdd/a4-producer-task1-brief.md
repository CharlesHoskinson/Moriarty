# A4 producer bootstrap and Task1

Plan adopted386bf0ae10f767e051b414a7231be105cc4b0f71, SHA256
edca754fafb2bba2ef4ead9fb97fa887e60aeb69bcd5890c0f0ca705e6d3d1f6.
Root fully reviewed source/interface/recorder/test blocks and exact inventory.
Execute Task0 and Task1 only. Root created the producer dispatch JSON at the
current exact base; A5 shared runtime store is byte-admitted, not model-checked.
Never recreate or modify it; imported helper is separately runtime-pinned.

Own scripts/record_s02_candidate_a_integrated.py,
scripts/s02_candidate_a_integrated_inventory.py,
specs/quint/s02/candidate_a_integrated_observer.qnt,
specs/quint/s02/candidate_a_integrated_export_test.qnt,
tests/test_s02_candidate_a_integrated_export.py, and ignored unique producer
receipts/report .superpowers/sdd/a4-producer-task1-report.md. Task2 creates the
literal Quint cases/lowering/driver/export instantiations later; do not create
them now. Task1 creates only Python selector inventory plus observer and tests.

Preserve compiling inventory missing-control RED and observer missing-computation
RED with original sources; restore each sole fault then capture complete current
unit GREEN. Follow four Task1 Quint tests and current Python inventory tests.
Diagnostics/import/type failures do not substitute for behavioral RED. Preserve
actual command/cwd/exit/streams/timing and before/after source/runtime identity.
Recorder requires exact fresh -B/-X pycache prefix. Early missing future files
must be explicitly listed; no final integrated export is admitted at this stage.

All common/A/lifecycle and checker sources are read-only. Checker Task4 is
currently frozen pending root admission. Coordinate with root before commands
if concurrent checker edits would change your broad source snapshot; source
movement invalidates a receipt, it must not be silently ignored. No acceptance
traces, Task2/3, full regressions, evidence/main/wiki/DB/index/commit or Foreman
work. Keep ownership of long jobs and poll their original handles. End at root
Task1 admission with source/report hashes, RED/GREEN and precise scope limits.
