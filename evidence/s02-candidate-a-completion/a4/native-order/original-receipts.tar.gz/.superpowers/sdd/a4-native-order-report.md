# A4 native ITF variable-order correction

Status: frozen for root admission. This is an author implementation report, not independent acceptance or native lifecycle/package evidence.

Controlling addendum: docs/superpowers/plans/2026-09-05-candidate-a-native-wrapper-compatibility.md, SHA256 a4a41278510897dc2f5d59fb540aad7380f29ac710fc8dccc7bfa0ed8212053e.

Only two tracked lines changed. The synthetic_shard fixture now uses the literal observed native order [authorityState,caseIndex,cursor,latestEvent], independent of checker VARS. The checker VARS tuple now requires that same order. No state meaning, semantic rule, inventory, test count, utility, producer source, or frozen source changed. Task6 append remains unapplied.

Final source pins:

- scripts/check_s02_candidate_a_integrated.py: b46af0796b9a6e868cfdbdde67b162ebc98d006daf9a07345d43c70290ff3bfd.
- tests/test_s02_candidate_a_integrated.py: a79285c42e694e395338267080280a1e5047e2c427a36703b07f1dfa7bf67614.
- .superpowers/sdd/a4-native-order-receipts/recorder.py: 1635d8aad059db48a9ee67abccb415ddd7372bffe77097573b2a07d1c994de61.

Original stages under .superpowers/sdd/a4-native-order-receipts:

| Stage | Exit | Observation |
|---|---:|---|
| red-import | 0 | Old checker and literal-native-order fixture imported. |
| red-tests | 1 | Both honest shard tests [36] and [37] failed at Invalid: exact raw vars and order. |
| green-syntax | 0 | Sole checker tuple correction compiled. |
| green-tests | 0 | All79 existing checker/utility tests passed in61.18 seconds. |

Every stage has original source.tar.gz, input.json, stdout.txt, stderr.txt, terminal.json, and artifacts.json. RED and GREEN pytest basetemp files remain in place. Each stage snapshots55 source/reference files and reuses the admitted3329-file Python environment archive without copying it. Parent/child process-start -B and -X settings and actual command-start HEAD are recorded. No stage reports source or runtime drift.

The observed tiny native probe SHA256 is7b14b09c806313f38548a689f1c909033d6fbb7182350ef82c70c4932744aaf4. Its original raw bytes, receipt, streams, before/after closure references, and three archived probe source files are included as reference inputs. This probe establishes the installed transport spelling only; it does not execute Candidate A or establish native largest-case feasibility.

Author audit checked all four source archive/member hashes, original output hashes, artifact manifests and retained files/symlink targets, final current source bytes, and all3329 current runtime file hashes. Audit exited0. Root must independently audit and admit the new baseline before any Task6 omitted-guard cycle; that cycle's restoration target must be the new checker hash above.

No commands imported unused moving producer modules. No Task6 tests, actual package, model job, commit, main/wiki/DB, or Council operation was run. Producer command-window release remains root-owned.
