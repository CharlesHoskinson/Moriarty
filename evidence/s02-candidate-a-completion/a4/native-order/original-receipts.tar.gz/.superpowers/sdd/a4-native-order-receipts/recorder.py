"""Native ITF variable-order original-byte recorder; actual package acceptance is excluded."""
import datetime
import hashlib
import importlib.metadata
import io
import json
from pathlib import Path
import subprocess
import sys
import sysconfig
import tarfile
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
PYTHON = '/home/charl/Moriarty/.venv/bin/python'
SOURCES = ('scripts/a4_carrier.py', 'scripts/a4_agreement.py', 'scripts/a4_authority.py', 'scripts/a4_cases.py', 'scripts/a4_inventory.py', 'scripts/check_s02_candidate_a_integrated.py', 'scripts/a4_json_stream.py', 'tests/test_a4_json_stream.py',
           'tests/test_s02_candidate_a_integrated.py',
           'scripts/check_s02_candidate_a_correspondence.py',
           'moriarty/core.py', 'moriarty/swap.py', 'moriarty/__init__.py',
           'pyproject.toml', 'uv.lock', 'docs/superpowers/plans/2026-09-05-candidate-a-case-sharded-transport.md', 'docs/superpowers/plans/2026-09-05-candidate-a-streaming-json.md', 'evidence/s02-candidate-a-completion/a4/inventory.json',
           'docs/superpowers/plans/2026-09-05-candidate-a-replay-interface-addendum.md',
           'specs/quint/s02/candidate_a_authority_installment_fixtures.qnt',
           'specs/quint/s02/candidate_a_authority_installment.qnt',
           'specs/quint/s02/candidate_a_authority_installment_test.qnt',
           'specs/quint/s02/candidate_a_authority_installment_harness.qnt',
           'specs/quint/s02/candidate_a_authority_swap_fixtures.qnt',
           'specs/quint/s02/candidate_a_authority_swap.qnt',
           'specs/quint/s02/candidate_a_authority_swap_test.qnt',
           'specs/quint/s02/candidate_a_authority_swap_harness.qnt',
           'specs/quint/s02/effects.qnt', 'specs/quint/s02/consumption.qnt',
           'specs/quint/s02/observations.qnt', 'specs/quint/s02/policies.qnt',
           'specs/quint/s02/authorization.qnt', 'specs/quint/s02/execution.qnt',
           'specs/quint/s02/candidate_a_authority_adapter.qnt',
           'specs/quint/s02/candidate_a_authority_boundary.qnt',
           'specs/quint/s02/candidate_a_types.qnt', 'specs/quint/s02/candidate_a_core.qnt',
           'specs/quint/s02/candidate_a_programs.qnt', 'specs/quint/s02/candidate_a_projection.qnt',
           'docs/superpowers/plans/2026-09-05-candidate-a-independent-replay.md',
           '.superpowers/sdd/a4-task6-sharded-plan.md',
           'docs/superpowers/plans/2026-09-05-candidate-a-sharded-adversarial-tests.md',
           'evidence/s02-candidate-a-completion/a4/planning/sharded-adversarial-review.md',
           '.superpowers/sdd/a4-task6-append.patch',
           '.superpowers/sdd/a4-native-order-receipts/recorder.py')
SOURCES += (".superpowers/sdd/a4-producer-receipts/task2-literal-probe-run/probe.itf.json",".superpowers/sdd/a4-producer-receipts/task2-literal-probe-run/receipt.json",".superpowers/sdd/a4-producer-receipts/task2-literal-probe-run/stdout.bin",".superpowers/sdd/a4-producer-receipts/task2-literal-probe-run/stderr.bin",".superpowers/sdd/a4-producer-receipts/task2-literal-probe-run/before/closure.json",".superpowers/sdd/a4-producer-receipts/task2-literal-probe-run/after/closure.json",".superpowers/sdd/a4-producer-receipts/task2-literal-probe-run/before/source/.superpowers/sdd/a4-producer-task2-probe/probe_driver.qnt",".superpowers/sdd/a4-producer-receipts/task2-literal-probe-run/before/source/.superpowers/sdd/a4-producer-task2-probe/probe_wrapper.qnt",".superpowers/sdd/a4-producer-receipts/task2-literal-probe-run/before/source/.superpowers/sdd/a4-producer-task2-probe/probe_test.qnt",)
SOURCES += ('docs/superpowers/plans/2026-09-05-candidate-a-native-wrapper-compatibility.md',)
COMMANDS = {
    'red-import': [PYTHON, '-c', "import scripts.check_s02_candidate_a_integrated; import runpy; runpy.run_path('tests/test_s02_candidate_a_integrated.py'); print('Native-order source imported')"],
    'red-tests': [PYTHON, '-m', 'pytest', '-q', 'tests/test_s02_candidate_a_integrated.py::test_sharded_bounded_matches_buffered'],
    'green-syntax': [PYTHON, '-c', 'from pathlib import Path; [compile(Path(p).read_bytes(),p,"exec") for p in ("scripts/check_s02_candidate_a_integrated.py","tests/test_s02_candidate_a_integrated.py")]; print("Native-order syntax succeeded")'],
    'green-tests': [PYTHON, '-m', 'pytest', '-q', 'tests/test_s02_candidate_a_integrated.py', 'tests/test_a4_json_stream.py'],
}

def sha(data): return hashlib.sha256(data).hexdigest()
def file_pin(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        while data:=stream.read(1048576): h.update(data)
    return {'path':str(path),'sha256':h.hexdigest(),'bytes':path.stat().st_size}
def artifact_pins(folder):
    entries=[]
    if not folder.exists(): return entries
    for path in sorted(folder.rglob('*')):
        if path.is_symlink():
            entries.append({'path':str(path),'kind':'symlink','target':str(path.readlink())})
        elif path.is_file(): entries.append(file_pin(path)|{'kind':'file'})
        elif path.is_dir(): entries.append({'path':str(path),'kind':'directory'})
        else: raise RuntimeError('Unsupported artifact kind: '+str(path))
    return entries
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path, value):
    with path.open('x') as stream: json.dump(value, stream, indent=2, sort_keys=True); stream.write('\n')
def pin(path): return {'path': str(path), 'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size}
def archive(target, paths):
    entries=[]
    with tarfile.open(target, 'x:gz') as tar:
        for path in sorted(paths):
            raw=path.read_bytes(); name=str(path).lstrip('/')
            info=tarfile.TarInfo(name); info.size=len(raw); tar.addfile(info, io.BytesIO(raw))
            entries.append({'path':str(path),'archivePath':name,'sha256':sha(raw),'bytes':len(raw)})
    return entries

mode=sys.argv[1]
expected_parent_cache=str(OUT/('recorder-cache-'+mode))
assert sys.flags.dont_write_bytecode and sys.pycache_prefix==expected_parent_cache
assert sys.orig_argv[1:4]==['-B','-X','pycache_prefix='+expected_parent_cache]
assert not Path(expected_parent_cache).exists()
assert mode in COMMANDS
stage=OUT/mode; stage.mkdir(exist_ok=False)
artifact_root=stage/'basetemp'
assert not artifact_root.exists()
if '-m' in COMMANDS[mode] and 'pytest' in COMMANDS[mode]:
    COMMANDS[mode].append('--basetemp='+str(artifact_root))
COMMANDS[mode]=[PYTHON,'-B','-X','pycache_prefix='+str(stage/'fresh-pycache'),*COMMANDS[mode][1:]]
ENVIRONMENT=OUT.parent/'a4-checker-task1-receipts'/'python-environment.json'
assert sha(ENVIRONMENT.read_bytes())=='cd004057c4067bf7cc536d2cec5038add88d0852c1a7de5030e402ff2204f9c4'
environment=json.loads(ENVIRONMENT.read_text())
assert sha((ENVIRONMENT.parent/'python-environment.tar.gz').read_bytes())==environment['archiveSha256']
env_before=[pin(Path(e['path'])) for e in environment['sourceBytes']]
assert all(a['sha256']==b['sha256'] for a,b in zip(env_before,environment['sourceBytes']))
present=sorted(ROOT/name for name in SOURCES if (ROOT/name).is_file())
missing=[name for name in SOURCES if not (ROOT/name).is_file()]
assert not missing, missing
source_entries=archive(stage/'source.tar.gz',present)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
import os
env=os.environ.copy(); overrides={'PYTHONDONTWRITEBYTECODE':'1','PYTHONPYCACHEPREFIX':str(stage/'fresh-pycache'),'PYTHONPATH':'','PYTEST_ADDOPTS':''}
env.update(overrides)
write(stage/'input.json',{'createdAt':now(),'parentOrigArgv':sys.orig_argv,'parentCachePrefix':sys.pycache_prefix,'argv':COMMANDS[mode],'cwd':str(ROOT),'baseCommit':head,'sourceCommit':head,'headMeaning':'actual command-start HEAD; not a historical narrative base',
    'scope':'native-order transport correction only; no Task6 append or native package acceptance',
    'packageExclusions':['test_actual_complete_package_and_inventory_triples'],
    'artifactRoot':str(artifact_root),'artifactRetention':'original files retained in place; no cleanup',
    'environmentOverrides':overrides,'pythonEnvironmentManifestPath':str(ENVIRONMENT),'pythonEnvironmentManifestSha256':sha(ENVIRONMENT.read_bytes()),'pythonEnvironmentArchiveSha256':environment['archiveSha256'],
    'sourceArchiveSha256':sha((stage/'source.tar.gz').read_bytes()),'sourceBytes':source_entries,'absentSources':missing,
    'namespacePackagesWithoutInit':['scripts','tests'],'pythonBefore':pin(Path(PYTHON)),
    'environmentBefore':env_before})
start=time.monotonic()
with (stage/'stdout.txt').open('xb') as stdout, (stage/'stderr.txt').open('xb') as stderr:
    result=subprocess.run(COMMANDS[mode],cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
after=[pin(p) for p in present]
env_after=[pin(Path(e['path'])) for e in environment['sourceBytes']]
source_changed=[e['path'] for e,a in zip(source_entries,after) if e['sha256']!=a['sha256']]
environment_changed=[a['path'] for a,b in zip(env_before,env_after) if a!=b]
artifacts=artifact_pins(artifact_root)
write(stage/'artifacts.json', {'root':str(artifact_root),'entries':artifacts,
    'retention':'original files retained; symlinks recorded without following',
    'childRecords':'argv.json, stdout.txt, stderr.txt, terminal.json under each triple directory'})
terminal={'artifactManifestSha256':sha((stage/'artifacts.json').read_bytes()),'artifactEntries':len(artifacts),'completedAt':now(),'elapsedSeconds':time.monotonic()-start,'exitCode':result.returncode,
    'sourceAfter':after,'environmentAfter':env_after,'sourceChanged':source_changed,'environmentChanged':environment_changed,
    'pythonAfter':pin(Path(PYTHON)),'stdoutSha256':sha((stage/'stdout.txt').read_bytes()),'stderrSha256':sha((stage/'stderr.txt').read_bytes())}
write(stage/'terminal.json',terminal)
sys.stdout.buffer.write((stage/'stdout.txt').read_bytes()); sys.stderr.buffer.write((stage/'stderr.txt').read_bytes())
print(json.dumps({'stage':str(stage),'exitCode':result.returncode,'elapsedSeconds':terminal['elapsedSeconds'],
    'sourceChanged':source_changed,'environmentChanged':environment_changed}),flush=True)
raise SystemExit(result.returncode if not source_changed and not environment_changed else 2)
