# A4 recorder RH001 author handoff

Status: frozen source, complete bounded RH001 implementation and verification; root admission and commits remain separate. No live author jobs.

## Authority and scope

Root explicitly dispatched RH001 only under adopted plan `docs/superpowers/plans/2026-09-05-candidate-a-recorder-streaming.md` (plan adoption9cea581; exact SHA256a133a45906d8ff972dc513f4253cb7d4aca221e1ffd823ad255f194a9690f21d). The current pre-dispatch source base was8be3cef9a3be94d7dd0b54f9393dded1c5437883, distinct from the unchanged original producer/runtime dispatch base386bf0ae10f767e051b414a7231be105cc4b0f71. Both command receipts retain sourceCommit and sourceCommitAfter equal to8be3cef.

Repository observation: the old recorder artifact comprehension read each whole native ITF using sha(path.read_bytes()). Implementation changed only the recorder and producer Python test. The extracted helper first retained exactly that behavior; both approved tests were added before executing the genuine guarded-read RED. After that terminal failure, only the approved script-entry bootstrap/import and helper implementation changed. The actual main artifact comprehension calls artifact_hash, and the existing receipt artifacts mapping publishes that result unchanged.

This is author evidence, not independent source review or Council disposition. The executing-plans/TDD skills governed the exact test-first sequence; verification-before-completion requires the original terminal outcomes reported below. No archived Task2 source/receipt was changed. No RH002 implementation, native pilot/export, Task3 exporter, checker, utility, formal-model or shared semantics edit occurred. No commits were made.

## Actual RED and GREEN

The RED helper was:

```python
def artifact_hash(path):
    return sha(path.read_bytes())
```

The exact source-byte closure was captured before execution and again afterward, together with the existing full runtime pins. This was an actual behavioral assertion failure, not a missing import or parser failure. The test's GuardedPath.read_bytes raised AssertionError: whole native artifact read_bytes. The same guarded test later passed without changes: its reader rejects nonpositive or greater-than1048576 read sizes and verifies digest equality on2100021known bytes. The structural main-path test is supplemental coverage, not a separate original RED claim.

Exact command launches:

```bash
/home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/a4-producer-receipts/recorder-stream-red/python-cache scripts/record_s02_candidate_a_integrated.py --stage recorder-stream-red -- /home/charl/Moriarty/.venv/bin/python -m pytest tests/test_s02_candidate_a_integrated_export.py -vv -k recorder_artifact_hash
/home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/a4-producer-receipts/recorder-stream-green/python-cache scripts/record_s02_candidate_a_integrated.py --stage recorder-stream-green -- /home/charl/Moriarty/.venv/bin/python -m pytest tests/test_s02_candidate_a_integrated_export.py -vv
```

RED child/recorder exit1;1failure,14deselected,1.585319138seconds recorder duration. GREEN child/recorder exit0;15passes,2.374563013seconds recorder duration. Both stderr streams are empty. Both receipts report source_stable=true and runtime_stable=true. Neither command emitted an ITF, so both actual artifacts maps are empty; no native emission smoke or native memory measurement is claimed.

### Original RED stdout

```text
============================= test session starts ==============================
platform linux -- Python 3.13.14, pytest-9.1.1, pluggy-1.6.0 -- /home/charl/Moriarty/.venv/bin/python
cachedir: .pytest_cache
rootdir: /home/charl/Moriarty/.worktrees/s01-audit-start
configfile: pyproject.toml
plugins: anyio-4.14.2
collecting ... collected 15 items / 14 deselected / 1 selected

tests/test_s02_candidate_a_integrated_export.py::test_recorder_artifact_hash_uses_bounded_reads FAILED [100%]

=================================== FAILURES ===================================
________________ test_recorder_artifact_hash_uses_bounded_reads ________________

    def test_recorder_artifact_hash_uses_bounded_reads():
        import hashlib
        import io
        from scripts.record_s02_candidate_a_integrated import artifact_hash
        payload = b"original native bytes" * 100_001
        sizes = []
        class GuardedReader(io.BytesIO):
            def read(self, size=-1):
                assert 0 < size <= 1_048_576, "whole/oversized native artifact read"
                sizes.append(size)
                return super().read(size)
        class GuardedPath:
            def read_bytes(self):
                raise AssertionError("whole native artifact read_bytes")
            def open(self, mode):
                assert mode == "rb"
                return GuardedReader(payload)
>       assert artifact_hash(GuardedPath()) == hashlib.sha256(payload).hexdigest()
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^

tests/test_s02_candidate_a_integrated_export.py:88: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
scripts/record_s02_candidate_a_integrated.py:45: in artifact_hash
    return sha(path.read_bytes())
               ^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <test_s02_candidate_a_integrated_export.test_recorder_artifact_hash_uses_bounded_reads.<locals>.GuardedPath object at 0x73a0099a17f0>

    def read_bytes(self):
>       raise AssertionError("whole native artifact read_bytes")
E       AssertionError: whole native artifact read_bytes

tests/test_s02_candidate_a_integrated_export.py:84: AssertionError
=========================== short test summary info ============================
FAILED tests/test_s02_candidate_a_integrated_export.py::test_recorder_artifact_hash_uses_bounded_reads - AssertionError: whole native artifact read_bytes
======================= 1 failed, 14 deselected in 0.13s =======================
```

### Original GREEN stdout

```text
============================= test session starts ==============================
platform linux -- Python 3.13.14, pytest-9.1.1, pluggy-1.6.0 -- /home/charl/Moriarty/.venv/bin/python
cachedir: .pytest_cache
rootdir: /home/charl/Moriarty/.worktrees/s01-audit-start
configfile: pyproject.toml
plugins: anyio-4.14.2
collecting ... collected 15 items

tests/test_s02_candidate_a_integrated_export.py::test_exact_inventory PASSED [  6%]
tests/test_s02_candidate_a_integrated_export.py::test_mutant_dual_boundaries_and_original_bases PASSED [ 13%]
tests/test_s02_candidate_a_integrated_export.py::test_unknown_selector_rejected[P:invented:first] PASSED [ 20%]
tests/test_s02_candidate_a_integrated_export.py::test_unknown_selector_rejected[M:invented] PASSED [ 26%]
tests/test_s02_candidate_a_integrated_export.py::test_unknown_selector_rejected[S:advance:99] PASSED [ 33%]
tests/test_s02_candidate_a_integrated_export.py::test_unknown_selector_rejected[D:verify:first:foreign] PASSED [ 40%]
tests/test_s02_candidate_a_integrated_export.py::test_every_selector_lowers_and_case_table_is_literal PASSED [ 46%]
tests/test_s02_candidate_a_integrated_export.py::test_all_literal_case_and_wrapper_bytes_match_renderer PASSED [ 53%]
tests/test_s02_candidate_a_integrated_export.py::test_wrapper_renderer_rejects_nonfinite_indices[-1] PASSED [ 60%]
tests/test_s02_candidate_a_integrated_export.py::test_wrapper_renderer_rejects_nonfinite_indices[78] PASSED [ 66%]
tests/test_s02_candidate_a_integrated_export.py::test_wrapper_renderer_rejects_nonfinite_indices[True] PASSED [ 73%]
tests/test_s02_candidate_a_integrated_export.py::test_wrapper_renderer_rejects_nonfinite_indices[32] PASSED [ 80%]
tests/test_s02_candidate_a_integrated_export.py::test_wrapper_renderer_rejects_nonfinite_indices[None] PASSED [ 86%]
tests/test_s02_candidate_a_integrated_export.py::test_recorder_artifact_hash_uses_bounded_reads PASSED [ 93%]
tests/test_s02_candidate_a_integrated_export.py::test_recorder_main_publishes_streamed_artifact_hashes PASSED [100%]

============================== 15 passed in 0.98s ==============================
```

## Exact source closure and final pins

Each stage has120source files in each before/after closure. Fresh read-only verification checked all480source-byte members and confirms each stage's before/after maps are identical. Across RED→GREEN, only scripts/record_s02_candidate_a_integrated.py changed; the119remaining closure members, including the tests, are unchanged. The precise correction is:

```diff
--- original RED recorder
+++ final GREEN recorder
@@ -13,6 +13,10 @@
 from pathlib import Path, PurePosixPath
 
 ROOT = Path(__file__).resolve().parents[1]
+if __package__ in (None, ""):
+    sys.path.insert(0, str(ROOT))
+from scripts.a4_json_stream import hash_stream
+
 STAGES = ROOT / ".superpowers/sdd/a4-producer-receipts"
 DISPATCH = ROOT / ".superpowers/sdd/a4-producer-dispatch.json"
 SHARED_DISPATCH = ROOT / ".superpowers/sdd/a5-factoring-receipts/dispatch.json"
@@ -42,7 +46,8 @@
 def sha(data): return hashlib.sha256(data).hexdigest()
 
 def artifact_hash(path):
-    return sha(path.read_bytes())
+    with path.open("rb") as stream:
+        return hash_stream(stream)[0]
 
 def write_json(path, value):
     with path.open("x", encoding="utf-8") as stream:
```

Frozen recorder SHA256dc30b764e2603dfe3c39ef6e2063a7082d116dc9d3eb9a012072f468beb8f8e9.
Frozen producer Python test SHA256e8cf739c2de53ce6dfe0a992acf25acf048e16221c69ebdc3998d41621d3b74c.

The original artifact index is `.superpowers/sdd/a4-recorder-streaming-artifact-index.json`. It retains492file pins covering both full source-byte closures, manifests, original stdout/stderr/receipt and runtime-helper copies, plus exact argv, terminal metadata, stdout text, final source pins and the RED/GREEN diff. It excludes only regenerated python-cache trees and does not hash itself or this report. Root must pin those two outer artifacts separately. Runtime/helper/archive identity and receipt schema are unchanged; this scope does not relabel ordinary metadata/tool archive reads as native ITF reads.

The bounded unit is ready for root source/evidence review and admission. Source and report are frozen at handoff.
