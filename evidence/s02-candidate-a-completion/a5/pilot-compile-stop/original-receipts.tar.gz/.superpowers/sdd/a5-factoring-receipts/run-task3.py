"""Task3 dispatch binding; immutable shared recorder/main remains unchanged."""
import hashlib
import io
import json
import re
import sys
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from scripts import run_s02_candidate_a_factoring_pilot as H

DISPATCH = H.RECEIPTS/"task3-dispatch.json"
TEST_FIRST = H.RECEIPTS/"task3-test-first.json"
TASK2_FROZEN = H.RECEIPTS/"task2-frozen-source.json"
BOOTSTRAP = "900bb2051225b4a3d99bf422c3b2e5e386e3e7bc"
DISPATCH_SHA = "51ca132878cf7dca7470b9fa5e82ef7e53e6088ea26b8a5b8b2838af4e73aeba"
HELPER_SHA = "816c3ad79dc3a67ca9a03729af56d74188c161a7546b9c43e821c222a4bce7f2"
PILOT_PINS = {
 "candidate_a_funding_pilot.qnt": "e8ef6d8d118f0c8fda1412ac8d1b6936850235a780d934b281d05a0b207a3480",
 "candidate_a_funding_pilot_f.qnt": "2f5fcc102d0ce526449fa1963fbe84f5cf3f8b8aff48d219b6f71a0aa5d34e7a",
 "candidate_a_funding_pilot_test.qnt": "31b2b7600199d24b668dcc202943199fcfd3423e879dc1f8209fa736cba9effb",
}
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def write(p,value):
    with p.open("x") as stream:
        json.dump(value,stream,indent=2)
        stream.write("\n")

def source_check():
    assert sha(DISPATCH) == DISPATCH_SHA
    assert sha(Path(H.__file__)) == HELPER_SHA
    assert sha(TASK2_FROZEN) == "97fad04118219a75017a738eb7dc4fb013d351161892cfa05e26c26528f55ab2"
    frozen = json.loads(TASK2_FROZEN.read_text())
    assert len(frozen["files"]) == 30
    assert all(sha(ROOT/e["path"]) == e["sha256"] for e in frozen["files"])
    assert all(sha(H.MODEL/name) == value for name,value in PILOT_PINS.items())
    d = json.loads(DISPATCH.read_text())
    assert d["actualTask3Base"] == "9ccbf0ed571e4055bc05962e5681fdf2fa75ad96"
    assert d["runtimeBootstrapBase"] == BOOTSTRAP
    return d

def passed(stage):
    r = json.loads((H.RECEIPTS/stage/"result.json").read_text())
    assert r["exitCode"] == 0 and not r["timedOut"]
    assert r["sourceAndToolsUnchanged"] and r["runtimeUnchanged"]

assert sys.dont_write_bytecode and sys.pycache_prefix
mode = sys.argv[1]
assert mode in ("typecheck","test","sample-original","sample-factored","compile-original","compile-factored")
d = source_check()
test = H.MODEL/"candidate_a_funding_pilot_test.qnt"
if mode == "typecheck":
    stage = "task3-pilot-typecheck"
    argv = [str(H.QUINT),"typecheck",str(test)]
elif mode == "test":
    passed("task3-pilot-typecheck")
    stage = "task3-pilot-prefix-test"
    argv = [str(H.QUINT),"test",str(test),"--backend=rust","--seed=42","--match","allPilotPrefixesTest"]
else:
    operation,variant = mode.split("-")
    passed("task3-pilot-prefix-test")
    if operation == "compile":
        passed("sample-original-pilotSafety")
        passed("sample-factored-pilotSafety")
    stage = operation+"-"+variant+"-pilotSafety"
    argv = [str(Path(H.__file__)),operation,variant,"pilotSafety",BOOTSTRAP]
assert not (H.RECEIPTS/stage).exists(), "No retry or overwrite"
binding = H.RECEIPTS/"task3-command-bindings"/stage
binding.mkdir(parents=True,exist_ok=False)
paths = [Path(__file__).resolve(),DISPATCH,TEST_FIRST,TASK2_FROZEN]
pins = [{"path":str(p),"sha256":sha(p)} for p in paths]
write(binding/"before.json",{
    "actualTask3Base":d["actualTask3Base"],"runtimeBootstrapBase":BOOTSTRAP,
    "parentArgv":sys.orig_argv,"parentCachePrefix":sys.pycache_prefix,
    "parentBytecodeDisabled":sys.dont_write_bytecode,
    "mode":mode,"stage":stage,"dispatchArgv":argv,"pins":pins,
    "pilotPins":PILOT_PINS,
    "scope":"Exact adopted Task3; typecheck/test/sample/compile only. No checker authorization."
})
with tarfile.open(binding/"source-and-dispatch.tar.gz","x:gz") as archive:
    for p in paths+[binding/"before.json"]:
        raw=p.read_bytes()
        member=tarfile.TarInfo(str(p.relative_to(ROOT)))
        member.size=len(raw)
        archive.addfile(member,io.BytesIO(raw))
code = None
error = None
try:
    if mode in ("typecheck","test"):
        code = H.record(stage,argv,1200,4096,
            "recursivePilotTypecheck" if mode=="typecheck" else "allPilotPrefixesTest",5,
            extra=tuple(paths),before_dispatch_base=BOOTSTRAP,
            domain="Task3 actual base "+d["actualTask3Base"]+
                "; helper beforeDispatchCommit is immutable runtime bootstrap; four complete funding routes; depth5; no checker")
    else:
        saved = sys.argv
        try:
            sys.argv = argv
            try:
                H.main()
            except SystemExit as done:
                assert isinstance(done.code,int)
                code=done.code
        finally:
            sys.argv=saved
except BaseException as exc:
    error=type(exc).__name__+": "+str(exc)
    raise
finally:
    unchanged = True
    try:
        source_check()
        assert all(sha(p["path"])==p["sha256"] for p in pins)
    except (AssertionError,OSError):
        unchanged=False
    result_path=H.RECEIPTS/stage/"result.json"
    input_path=H.RECEIPTS/stage/"input.json"
    write(binding/"after.json",{
        "exitCode":code,"exception":error,"sourceDispatchUnchanged":unchanged,
        "sourceAndDispatchArchiveSha256":sha(binding/"source-and-dispatch.tar.gz"),
        "originalInputSha256":sha(input_path) if input_path.exists() else None,
        "originalResultSha256":sha(result_path) if result_path.exists() else None,
        "actualTask3Base":d["actualTask3Base"],"runtimeBootstrapBase":BOOTSTRAP})
    assert unchanged, "Source or dispatch movement invalidates Task3 command"
assert code == 0,(stage,code)
passed(stage)
if mode == "test":
    actual=re.findall(r"ok (\w+) passed \d+ test\(s\)",(H.RECEIPTS/stage/"stdout.txt").read_text())
    assert actual==["allPilotPrefixesTest"],actual
elif mode.startswith("sample-"):
    text=(H.RECEIPTS/stage/"stdout.txt").read_text()
    witnesses=re.findall(r"(\w+) was witnessed in (\d+) trace\(s\) out of (\d+) explored",text)
    assert [name for name,_,_ in witnesses]==list(H.WITNESSES),witnesses
    assert all(int(count)>0 and total=="100" for _,count,total in witnesses),witnesses
elif mode.startswith("compile-"):
    result=json.loads((H.RECEIPTS/stage/"result.json").read_text())
    assert "measurementError" not in result and "generated" in result,result
print(json.dumps({"task3Stage":stage,"binding":str(binding),"terminal":code}),flush=True)

