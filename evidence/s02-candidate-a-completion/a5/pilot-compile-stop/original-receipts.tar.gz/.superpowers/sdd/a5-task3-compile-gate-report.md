# A5 Task3 compile-gate author report

**Experiment observation:** stopped at the original compilation gate. Four preceding commands passed; original compile failed with QNT404 during name resolution. No valid generated JSON exists, the factored compile was not run, and neither checker was launched. H1's size gate is unresolved. This is not an H1 semantic counterexample or a full A5 result.

## Scope, immutable sources and dispatch

Actual Task3 base: `9ccbf0ed571e4055bc05962e5681fdf2fa75ad96`.
Runtime bootstrap base: `900bb2051225b4a3d99bf422c3b2e5e386e3e7bc`.
Root dispatch `.superpowers/sdd/a5-factoring-receipts/task3-dispatch.json`:
SHA256 `51ca132878cf7dca7470b9fa5e82ef7e53e6088ea26b8a5b8b2838af4e73aeba`.

The exact adopted Task3 blocks were implemented test-first using apply_patch. A separate original `task3-test-first.json` records the test hash while both pilot modules were absent. Missing imports were not executed or represented as a semantic RED; this follows the explicit dispatch.

| New source | SHA256 |
| --- | --- |
| candidate_a_funding_pilot.qnt | e8ef6d8d118f0c8fda1412ac8d1b6936850235a780d934b281d05a0b207a3480 |
| candidate_a_funding_pilot_f.qnt | 2f5fcc102d0ce526449fa1963fbe84f5cf3f8b8aff48d219b6f71a0aa5d34e7a |
| candidate_a_funding_pilot_test.qnt | 31b2b7600199d24b668dcc202943199fcfd3423e879dc1f8209fa736cba9effb |

The two pilot module bodies differ only in module name and four import destinations. Root independently audited literal plan equality, these five differences and all22 scheduled prefix pairs. All30 previously admitted isolated files remain byte-identical to the frozen Task2 manifest. No common/A/lifecycle source, shared runtime helper, bootstrap, original Task2 receipt/index, other lane, main/wiki/DB or commit was changed.

The new ignored command wrapper is `run-task3.py`, SHA256 `beacf086d818651fbfeb04051678d8771f1511932832cd2c239dc2318858360d`. Root read and approved it before sample/compile use. The shared helper remains SHA256 `816c3ad79dc3a67ca9a03729af56d74188c161a7546b9c43e821c222a4bce7f2`.

## Original command and binding inventory

Full author index:
`.superpowers/sdd/a5-factoring-receipts/task3-compile-gate-index.json`.

It binds all original input/result/native output/resource files, all353 native source-archive members across five stages, five separate source/dispatch-binding archives with five members each, and actual outer wrapper terminal output/exit metadata. It also binds the three new sources, unchanged30-file manifest, dispatch/test-first/wrapper/plan and root source-audit source.

Every native command had a fresh stage and a fresh -B/-X parent cache. The original sample/compile CLI argv and bootstrap semantics came from unchanged H.main. Typecheck/test direct-record extras include the Task3 dispatch/wrapper; H.main sample/compile calls instead have separate immutable before/after source/dispatch archives that bind their original input/result hashes.

The helper's beforeDispatchCommit remains the bootstrap base, not the Task3 base. Per-command sourceCommit and the separate actualTask3Base remain distinct.

Every original command reports no timeout, runtimeUnchanged=true and sourceAndToolsUnchanged=true. Every separate binding reports sourceDispatchUnchanged=true. The actual outer terminal was separately captured after wrapper postchecks, not inferred merely from H.record exitCode.

| Stage | Native exit | Outer exit | Recorded seconds | Native max RSS KiB |
| --- | ---: | ---: | ---: | ---: |
| task3-pilot-typecheck | 0 | 0 | 347.44 | 2307944 |
| task3-pilot-prefix-test | 0 | 0 | 335.17 | 3008432 |
| sample-original-pilotSafety | 0 | 0 | 216.59 | 2133220 |
| sample-factored-pilotSafety | 0 | 0 | 226.12 | 2330668 |
| compile-original-pilotSafety | 1 | 1 | 214.02 | 1985960 |

The typecheck/test/sample wall ceiling was1200s; original compilation used900s. Node/JVM heap settings stayed4096MiB. Native max RSS is the observed GNU-time metric, not a strict whole-process-tree memory ceiling.

## Passing finite checks

The recursive import-aware typecheck passed. The one exact `allPilotPrefixesTest` passed and the wrapper required that literal single run name. It quantifies both profiles and honest/forged routes, all22 prefix pairs, full state equality, guards, next-state equality when ready, and each module's safety predicate.

Original and factored samples each ran100 traces at max-steps5, seed42 as requested; raw reproduction seed0xf0. All eight witnesses were positive, with identical counts:

| Witness | Original | Factored |
| --- | ---: | ---: |
| prepared | 100 | 100 |
| signed | 100 | 100 |
| proposed | 100 | 100 |
| verified | 50 | 50 |
| committed | 50 | 50 |
| rejected | 50 | 50 |
| afterCompleted | 53 | 53 |
| beforeCompleted | 47 | 47 |

The wrapper's ordered eight-name and positive-count assertions passed before each outer terminal0. These aggregate witnesses do not independently enumerate every joint profile/forgery combination; the deterministic22-prefix test supplies the four-route coverage.

This pilot retains the full execution record, history and raw-result list. Honest funding moves10 TokenA from Alice wallet to escrow; initial raw minimumTime0 remains unchanged and funding occurs at1. Fully rebound unused-node forgery is rejected under the original signed policy. The model is not a full swap or financial-terminal model. Finite tests/simulation are not model-checking evidence.

## Original compilation failure and exact retained artifacts

Original native argv, as retained in `compile-original-pilotSafety/input.json`:

```text
/home/charl/.foreman/tools/fnm/node-versions/v24.18.1/installation/bin/node /home/charl/.npm-global/lib/node_modules/@informalsystems/quint/dist/src/cli.js compile /home/charl/Moriarty/.worktrees/s01-audit-start/specs/quint/s02/factored_verification/candidate_a_funding_pilot.qnt --main=candidate_a_funding_pilot --target=json --invariant=pilotSafety --verbosity=0
```

Native exit1,214.022179673s; no timeout; native elapsed3:32.88; max RSS1985960KiB.

The original stderr reports seven QNT404 diagnostics:
`Type alias 'AuthorityKey' not found` at authorization.qnt14(two locations),16,17,22; consumption.qnt7; and execution.qnt19, ending with `error: name resolution failed`.

Stderr SHA256:
`606a4bf274f5499111b50b3897cc06064a2c953d3ef9fdbcf57e567baccba842`.

The retained original stdout file is
`.superpowers/sdd/a5-factoring-receipts/compile-original-pilotSafety/input.qnt.json`.
It has zero bytes, SHA256
`e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.
It is the actual empty output from the failed compile, **not valid generated JSON**. No JSON object/let/app counts or valid original input size are available. It must not be treated as a zero-sized successful baseline or compared by a size ratio.

The original source archive, stderr/resources/result, separate binding after.json and actual outer terminal1/AssertionError are all retained unchanged. The wrapper assertion stopped the planned sequence; it did not retry or launch a factored compile.

## Read-only diagnostic observations, not a fix

Source fact: AuthorityKey is explicitly declared in frozen consumption.qnt:5, and the relevant common modules import consumption. Passing typecheck/prefix/samples are separate observations, not proof that compile must succeed.

Installed-runtime source fact: Quint dist/src/cliCommands.js compile() appends synthesized q::* definitions, then reruns parsePhase3importAndNameResolution. Its error branch at423–427 emits the observed `name resolution failed`; flattenModules follows later at447. The original installed JS bytes are already retained in the admitted shared Quint runtime snapshot and separately pinned by the author index.

Inference limited to this evidence: the observed failure is in the compile-only second-resolution stage before flattening, not an Apalache resource result. The deeper cause of losing AuthorityKey resolution remains unresolved. No common/source/helper/runtime fix, alternate import, compiler version change, or additional reproduction was attempted by this author.

## Gates not reached and handoff

- Factored compile: not run after the original compile failure.
- Paired valid JSON metrics and size gate: unavailable/unresolved.
- Original checker: not run.
- Factored checker: not run.
- neverPrepared compile/check and state1 counterexample: not run.
- H1 support, full-workload A5, expanded A4 and unrestricted verification: not claimed.

All five owned sessions are terminal. Root has begun an independent read-only cause investigation. The three pilot sources, helper, wrapper, dispatch, original output/archives and all Task2-indexed originals remain frozen. Any changed hypothesis, source/tool correction, retry, resource change or checker run requires separate review and authorization.

