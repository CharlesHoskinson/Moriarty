# A5 Task3 independent source review

Verdict: no material source defect or adopted-plan mismatch found in this bounded
three-file review. This is source review only, not terminal verification, Task3
admission, full A5 acceptance or Council review. The author-owned typecheck was
active at assignment; I did not poll it, rerun native commands or modify source.
I did not author these pilot files; I did author earlier Candidate A dependencies.

Reviewed the Task3 root dispatch (actual base9ccbf0e; immutable runtime base900bb20)
and adopted plan900bb20, SHA256
`fe96c2343c369e9170952c04cfb847fc826d706a8f0ad6818efc283f37615563`.
Read the original pilot, the complete original/factored diff, the prefix test,
and relevant original lifecycle, fixture and authority-boundary definitions.
Independent read-only comparison matched all three source files byte-for-byte
to their adopted plan blocks, without invoking root's audit.

Exact source SHA256:

```text
candidate_a_funding_pilot.qnt e8ef6d8d118f0c8fda1412ac8d1b6936850235a780d934b281d05a0b207a3480
candidate_a_funding_pilot_f.qnt 2f5fcc102d0ce526449fa1963fbe84f5cf3f8b8aff48d219b6f71a0aa5d34e7a
candidate_a_funding_pilot_test.qnt 31b2b7600199d24b668dcc202943199fcfd3423e879dc1f8209fa736cba9effb
```

## Source observations

- Exactly five declaration/import changes: module name and fixture/lifecycle/
  boundary/Core import destinations. All expressions, literals, actions,
  invariants and witnesses otherwise match. Shared original adapter import
  supplies common types; actual calls resolve through the selected F/S/B/C
  aliases. This does not bypass the factored delegates.
- Initialization chooses both signing profiles and honest/forged flags, giving
  four fixed routes. Honest routes have five actions; forged routes have four.
  Inclusive prefixes are2*(6+5)=22 pairs. The single quantified test compares
  complete PilotState values, both safety predicates, readiness, and full next
  updates at every enabled prefix. It computes prefixes purely but also checks
  enabledness at each tested prefix; it does not silently excuse a blocked route.
- Honest sequence is actual prepare/sign/propose/verify/commit. Proposal uses
  actual adapter output, not the expected observation fixture. The funding Core
  evaluation is actually computed and retained at proposal: Alice deposits10
  TokenA atTime1. Full authority execution/history/raw-result records remain;
  there is no hash-only replacement or dropped registry/attempt/evidence map.
- Forgery changes the actual observation's retained successor program at unused
  N15 to a Mallory Pay node. Effect/signature proof records bind the changed
  attempt, while evidenceS retains the original policy/signature token. Thus
  rejection is tested beneath an actual prior signing pipeline, not from an
  unsigned initializer or deliberately invalid proof tag. Validity tags still
  abstract external proof verification; this is not cryptographic generation.
- Forged terminal checks exact restored signed predecessor context, exact
  changed attempt, regenerated evidence, UnauthorizedEffect/VerificationBoundary,
  and explicit canVerify denial from the proposed predecessor. Honest terminal
  checks the funded continuation/ledger, nonce0 consumption with exact signed
  policy and revision1, and ExecutedOperation. Complete honest retained records
  are compared between variants; terminalExact itself is not a separately
  reconstructed full honest execution-record oracle.
- safety includes actual lifecycle validity/conservation/parent preservation,
  history/cursor consistency, exact raw funding result, enabled nonterminal
  prefixes, disabled terminal, and unchanged agreement/ledger before commit.
  step is guarded by ready; no blanket stutter exists. Fallback pure update
  branches do not hide a diagnostic as a safe completed route: readiness and
  the invariant would fail before reaching a successful terminal.
- neverPrepared is true initially and false after the genuine first preparation
  action (cursor1). A real checker state1 counterexample remains mandatory after
  factored pilotSafety succeeds. The source predicate alone is not evidence that
  a checker explored state1; no such result is claimed here.

## Limits and outstanding gates

This is one first-funding transaction under two profiles plus a fully rebound
successor forgery. `scenario.funded=2` selects the unchanged swap fixture policy;
the pilot does not execute Bob's funding or disposition. Honest completion means
funding committed, not escrow drained, Close reached or full financial terminal.
The raw list records that transaction's actual evaluation, not every internal
boundary evaluation. All retained state/history records remain complete.

The four deterministic routes do not cover arbitrary interleavings, additional
authority inputs, full installment recovery/cancellation, all clocks/nonces,
all78 A4 cases, fairness or liveness. Compilation-size reduction would only
describe generated input, not successful InlinePass sharing or checker safety.
Both paired compile artifacts/metrics require root review before any checker
dispatch. Actual original/factored terminal samples, all action/profile
witnesses, factored states0–5 exploration with pilotSafety, and the subsequent
neverPrepared exit12/state1 trace remain separate mandatory evidence gates.
No automatic resource escalation or broader A5 conclusion follows from this
source-review verdict.
