---------------------------- MODULE counterexample ----------------------------

EXTENDS nullary_control

(* Constant initialization state *)
ConstInit == TRUE

(* Initial state [_transition(0)] *)
State0 == x = 0

(* State1 [_transition(0)] *)
State1 == x = 1

(* The following formula holds true in the last state and violates the invariant *)
InvariantViolation == x >= 1

================================================================================
(* Created by Apalache on Sat Sep 05 12:21:28 MDT 2026 *)
(* https://github.com/apalache-mc/apalache *)
