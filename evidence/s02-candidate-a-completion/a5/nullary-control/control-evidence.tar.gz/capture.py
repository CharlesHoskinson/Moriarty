"""Offline tool control only; not Candidate A verification."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
stage = sys.argv[1]
assert stage in ('compile-agreement', 'compile-wrong', 'check-agreement', 'check-wrong')
out = root / stage
out.mkdir(exist_ok=False)
compile_stage = stage.startswith('compile-')
property_name = stage.split('-', 1)[1]
quint = '/home/charl/.npm-global/bin/quint'
apalache = '/home/charl/.quint/apalache-dist-0.56.1/apalache/bin/apalache-mc'
jar = '/home/charl/.quint/apalache-dist-0.56.1/apalache/lib/apalache.jar'
argv = ([quint, 'compile', str(root / 'nullary_control.qnt'), '--main=nullary_control', '--target=json', '--invariant='+property_name, '--verbosity=0'] if compile_stage else [apalache, '--out-dir='+str(out / 'apalache'), 'check', '--init=q::init', '--next=q::step', '--inv=q::inv', '--length=2', '--no-deadlock', str(root / ('compile-'+property_name) / 'input.qnt.json')])
hash_file = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
paths = [str(root / 'nullary_control.qnt'), str(root / 'capture.py'), quint, apalache, jar]
if not compile_stage:
    paths.append(str(root / ('compile-'+property_name) / 'input.qnt.json'))
metadata = {'argv':argv, 'cwd':str(root), 'property':property_name, 'depth':2, 'domains':'x in0..2; no constants, fairness, concurrency or Candidate A imports', 'terminal':'x2 has no next action; deadlock checking disabled explicitly', 'resourceLimits':{'jvmHeapMiB':1024, 'wallSeconds':120}, 'pins':[{'path':p,'sha256':hash_file(p)}for p in paths], 'classification':'nullary-sharing tool control, not Candidate A evidence'}
(out / 'input.json').write_text(json.dumps(metadata, indent=2)+'\n')
stdout = out / ('input.qnt.json' if compile_stage else 'stdout.txt')
start = time.monotonic()
env = dict(os.environ, JVM_ARGS='-Xmx1024m')
with stdout.open('xb') as output, (out / 'stderr.txt').open('xb') as error:
    try:
        result = subprocess.run(argv, cwd=root, env=env, stdout=output, stderr=error, timeout=120)
        exit_code = result.returncode
        timed_out = False
    except subprocess.TimeoutExpired:
        exit_code = None
        timed_out = True
terminal = {'exitCode':exit_code,'timedOut':timed_out,'durationSeconds':time.monotonic()-start,'stdoutSha256':hash_file(stdout),'stderrSha256':hash_file(out/'stderr.txt'),'sourceAndToolsUnchanged':all(hash_file(p['path'])==p['sha256']for p in metadata['pins'])}
(out / 'result.json').write_text(json.dumps(terminal,indent=2)+'\n')
print(json.dumps({'stage':stage, **terminal}), flush=True)
if not compile_stage:
    print(stdout.read_text())
print((out / 'stderr.txt').read_text(), file=sys.stderr)
raise SystemExit(124 if timed_out else exit_code)
