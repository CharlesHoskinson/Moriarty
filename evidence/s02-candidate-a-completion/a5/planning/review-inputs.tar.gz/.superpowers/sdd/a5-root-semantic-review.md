# Root A5 H1 semantic plan review

Review in progress: semantic blocks reviewed; final recorder amendment and plan
digest admission are pending. This is not behavioral or model-checking evidence.

The joint kernel follows the frozen computeTransaction branch order: invalid
state/input, time-before-state, pre-reduction diagnostic, no-input terminal or
waiting-node rejection, supplied-input application diagnostic/error, post-
reduction diagnostic, accepted result. Every rejected transaction retains the
original state and empty payments/warnings/zero reductions through the original
rolledBackTransaction constructor. The new code does not promote diagnostics
into accepted/rejected Core results.

Accepted extraction uses the actual preliminary reduction retained by the same
pure computation. Its prefix payments precede an actual deposit transfer, if
present, and the suffix retains the finished payment order. For successful
no-input computation the prefix is the whole payment list and suffix empty.
The original extraction's repeated pre-reduction has identical arguments. Public
supplied-result validation compares the complete result after diagnostic dispatch,
including rejected results. The compiling mismatch-removal RED exercises that
boundary; parse failures do not discharge it.

The authority delegate retains invalid operation/time0 checks and cancellation's
valid-state/no-input requirement, identity successor, empty effects and no Core
projection. Financial operations expose the same raw projection and outcome.
No signed-policy validity premise is added to the raw equivalence argument.

Mechanical derivation pins28 exact originals and produces26 modules. Three
evaluation delegates change; other bodies are source-derived. Boundary wrappers
rename declarations only and bind identity arguments. Exact reverse transformation
must recover the original boundary bytes; record selectors and labels are not
identifier-rewritten. Full original/factored structural equality is required;
nominal typing problems must not be hidden by projection-only comparisons.

The pilot has four finite routes: both signing profiles, each with actual Alice
funding or a fully rebound unused-node successor forgery. Preparation/signing/
proposal/verification/commit remain distinct, and forged rejection retains its
attempt/evidence/context. Full execution and history records remain observable.
The no-deadlock option is paired with an explicit nonterminal-enabled predicate;
terminal actions disable rather than stutter. A state1 false-invariant control
must demonstrate actual preparation after the correct depth5 check passes.

H1 remains a hypothesis: nullary source bindings alone do not establish backend
sharing. Original and factored generated inputs and terminal resource outcomes
must be retained. A smaller input is only the launch gate, not correctness or
performance proof. Pilot success cannot close the full A5 interleaving/property
matrix or replace the78-case integrated A4 comparison. No frozen source changes,
heap-only retries, missing-case waiver, cryptographic claim or Council verdict.
