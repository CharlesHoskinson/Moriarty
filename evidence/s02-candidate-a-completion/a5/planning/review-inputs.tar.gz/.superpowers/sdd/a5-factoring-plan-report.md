# A5 factoring plan handoff

Classification: recommendation/specification, specified-only. Root review/adoption pending. No Candidate A behavioral run or checker experiment was performed for this plan.

Plan: `docs/superpowers/plans/2026-09-05-candidate-a-factored-verification.md`.
SHA256: `fe96c2343c369e9170952c04cfb847fc826d706a8f0ad6818efc283f37615563`.
Observed root HEAD at handoff: `ab7c82705419a465f65ed04708dae7414cc8fdbf`.

The plan has three review-gated units: joint evaluator/public supplied-result validation with compiling behavioral RED/GREEN; explicitly pinned mechanical variants and full original corpus/prefix equivalence; original/factored real Alice funding and rebound-forgery pilot with bounded offline measurements. Receipt/derivation tools are explicit pre-Task1 bootstrap. Full A5 property/interleaving/coverage obligations remain mapped and open; passing this pilot cannot admit A5.

## Self-review and syntax checks

- Read XML A5, adopted model-comparison and authority design, verification-command addendum, prior export/checking intake, nullary control README and actual frozen Core/projection/adapter/boundary/lifecycle source.
- Applied writing-plans and Quint modeling/language guidance. Source bodies and complete tests are specified in the plan, with exact ownership, arguments, result types, commands, resources and review gates.
- Root caught an unsafe draft identifier regex that would have changed selectors/record labels. Corrected it before implementation: wrappers only rename helper declarations, bind identity arguments and call unchanged bodies. A reverse transformation now requires full original source byte equality. No selector/value token replacement remains.
- Replaced source glob/count admission with an explicit28-name/SHA256 inventory deriving26 modules; types/programs remain original. Future A4 files cannot race that selection, but their later corpus comparison is explicitly mandatory.
- Root identified module qualification errors and section-order defects. Corrected aliases to `::`, preserving record selectors, and made the document linear Task1, Task2, Task3, full obligations, final review.
- Read-only Python AST parsing passed for all final Python code blocks. Executed derivation definitions in memory only: all28 pinned originals matched; all26 derived strings were formed; complete boundary wrapper reversal matched its source exactly. No implementation models were written in the repository.
- As explicitly requested by root, assembled32 temporary syntax-check modules with apply_patch under `/tmp/moriarty-a5-plan-parse.rMIksa/specs/quint/s02/factored_verification/`. Original imports are read-only symlinks. Ran `quint parse ENTRY --out ENTRY.parse.json` for each32-module entry; every terminal exit was0. CLI SHA256 was `ac12595b1cb7253feec93c79417615c6eb20fc3b6a3df35c5e3530b24e90a501`.
- Added complete original agreement-harness prefix comparison through original4/3-record bounds, covering the29 stateful corpus records in addition to24 diagnostic requests. Reparsed that final equivalence entry with terminal exit0; output `/tmp/moriarty-a5-plan-parse.rMIksa/equivalence-final.parse.json`.
- One initial read-only validation invocation used unavailable `python`; it exited127. Reissued with the actual `/home/charl/Moriarty/.venv/bin/python`. This was neither behavioral RED nor Candidate A failure. An initial simplistic selector-count audit also failed because wrappers duplicate parameter declarations; replaced that audit with exact body/source reversal and it passed.

## Remaining source-compatibility and evidence risks

Root requested a recorder-closure correction after the first handoff. The final plan now specifies one A5-owned shared tool-store bootstrap, also consumed (not recreated) by the A4 producer. It retains actual Node, complete installed Quint dist/node_modules/package metadata, Rust, Java runtime lib/conf/release, required launch tools and native dependencies once. It reuses the existing Python environment manifest `cd004057c4067bf7cc536d2cec5038add88d0852c1a7de5030e402ff2204f9c4` and archive `7363d106d464f976af2a0e7f1f56e3c7bed237c7a3396a60d073369add068dac` only after exact tar-member/current-byte validation. Every command binds shared manifest/archive digests, rechecks current file hashes and Node/Java tree membership before/after, records explicit actual Node argv, controls cache/loader variables, and receives an explicit full before-dispatch base separate from current sourceCommit. Raw tool/runtime version outputs remain in the shared store. Task1 uses this same provenance from its first RED command. The final Python blocks pass AST parsing; no snapshot/bootstrap was created or executed during planning. The32 Quint modules are unchanged by this recorder-only correction.

Quint parse validates syntax/name resolution, not typing or behavior. No new Quint typecheck, Rust test, simulation, compilation-to-checker input, or Apalache check was run. Full original/factored aliases and sums must typecheck under literal full-state equality; projection-only fallback is forbidden. The joint evaluator's malformed-input/diagnostic precedence and accepted pre-reduction reuse need independent branch review and actual compiling RED/GREEN. Tests must preserve all raw fields and effect order.

Nullary bindings already survive compilation in the original; wrappers may still inline poorly. Joint evaluation can reduce duplicate computation without making the full authority/history workload tractable. The plan measures generated size and separately records terminal checker results under fixed bounds; it does not infer backend sharing from local-val syntax. The prior93MB/4GiB/8GiB failures and tiny non-Candidate-A control are cited with their actual scope.

Complete original corpus comparison and all A2/A3 tests/witnesses are required before pilot checking. Full A5 still requires the accepted A4 expanded inventory and an explicitly reviewed adverse-interleaving driver for anchor/version changes; scheduled lifecycle routes alone do not cover that obligation. The pilot preserves full histories/state and makes no cryptographic or universal-equivalence claim.

Only this plan and this ignored report were changed for A5. Temporary parse artifacts are not behavioral implementation or acceptance evidence. No frozen common/A/lifecycle, A4/B lane, main/wiki/DB/evidence source was edited; no commit or Foreman work. No active jobs remain. Await independent root review/adoption and explicit next dispatch.
