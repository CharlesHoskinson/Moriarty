import hashlib,json,os,tarfile
from pathlib import Path
ROOT=Path('/home/charl/Moriarty/.worktrees/s01-audit-start')
OUT=ROOT/'.superpowers/sdd/a5-compiler-phase-diagnostic-20260906'
STAGE=OUT/'mocks'
def read(p):return json.loads(Path(p).read_text())
def digest(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def check(row):
 p=Path(row['path']);assert p.is_file() and not p.is_symlink();assert p.stat().st_size==row['bytes'] and digest(p)==row['sha256'],str(p)
f=read(OUT/'freeze.json');t=read(STAGE/'terminal.json');outer=read(OUT/'transport/mocks/terminal.json')
assert t['recorderExit']==0 and t['finalized'] is True and t['error'] is None
assert outer['wrapperExitCode']==0 and outer['toolResponses'][-1]['exit_code']==0
assert outer['toolResponses']==[read(p) for p in sorted((OUT/'transport/mocks').glob('response-*.json'))]
assert outer['command']=='PYTHONOPTIMIZE=0 /home/charl/Moriarty/.venv/bin/python -B '+str(OUT/'record.py')+' mocks' and outer['cwd']==str(ROOT)
for r in t['ownedFiles']:check(r)
assert len(t['ownedFiles'])==66
for r in f['sources']+f['runtime']['files']+f['runtime']['references']:check(r)
assert read(STAGE/'runtime-before.json')==read(STAGE/'runtime-after.json')==f['runtime']
expected={r['path']:r for r in f['sources']};expected[str(OUT/'freeze.json')]={'sha256':digest(OUT/'freeze.json'),'bytes':(OUT/'freeze.json').stat().st_size}
rows=[];members=0
for case in ['identity','open','write','partial','records','bytes','classify']:
 p=STAGE/case;start=read(p/'start.json');r=read(p/'result.json');code=0 if case=='identity' else 74
 assert r['childExit']==code and not r['timedOut'] and not r['monitorError'] and not r['receivedSignals']
 assert r['cleanup']=={'complete':True,'errors':[],'forced':False,'signals':[]} and not r['finalizationBlocked']
 try:os.killpg(r['ownedPgid'],0)
 except ProcessLookupError:pass
 else:raise AssertionError('group exists')
 assert start['argv']==['/home/charl/.foreman/tools/fnm/node-versions/v24.18.1/installation/bin/node',str(OUT/'controls.cjs'),case,str(p)]
 assert start['wallSeconds']==15 and start['fixedEnvironment']['NODE_OPTIONS']=='--max-old-space-size=128 --unhandled-rejections=strict'
 assert start['cwd']==str(ROOT) and start['actualDispatchHead']=='07c3a5462154d45e733d01d8a8bae856cb0f63c4'
 assert start['measuredArgv']==['/usr/bin/time','-v','-o',str(p/'resources.txt'),*start['argv']]
 check(start['sourceArchive']); archive_rows={x['archivePath']:x for x in start['sourceBytes']}
 assert len(archive_rows)==103 and {x['path'] for x in archive_rows.values()}==set(expected)
 with tarfile.open(p/'source.tar.gz','r:gz') as tar:
  ms=tar.getmembers();assert len(ms)==103 and {m.name for m in ms}==set(archive_rows)
  for m in ms:
   assert m.isfile(); b=tar.extractfile(m).read(); wanted=archive_rows[m.name];assert len(b)==wanted['bytes']==expected[wanted['path']]['bytes'];assert hashlib.sha256(b).hexdigest()==wanted['sha256']==expected[wanted['path']]['sha256'];members+=1
 fields={}
 for line in (p/'resources.txt').read_text().splitlines():
  if line.startswith('\t'):
   k,v=line[1:].rsplit(': ',1);assert k not in fields;fields[k]=v
 assert fields==r['resource']['fields'] and len(fields)==23
 assert fields['Command being timed']=='"'+' '.join(start['argv'])+'"'
 assert int(fields['Exit status'])==code and int(fields['Maximum resident set size (kbytes)'])>0
 stdout=(p/'stdout.bin').read_bytes();stderr=(p/'stderr.bin').read_bytes()
 if case=='identity':
  d=json.loads(stdout);assert d['ok'] is True and stderr==b''
  assert [x['mode'] for x in d['controls']]==['sync-right','sync-left','resolve','reject','throw','right-chain','left-chain']
  assert all(x['calls']==1 for x in d['controls'][:5])
  assert [x['rows'][1]['outcome'] for x in d['controls'][:5]]==['Right','Left','Right','rejected','thrown']
  assert d['controls'][5]['calls']==['load','parse','typecheck','compile','outputCompilationTarget','outputResult']
  assert d['controls'][6]['calls']==['load','parse','typecheck','compile','outputResult']
 else:
  assert stdout==b'' and stderr==b'phase-observer: diagnostic failure\n'
  called=p/'original-called.txt';assert (called.read_bytes()==b'1\n') if case=='classify' else not called.exists()
  if case=='open':assert (p/'trace.jsonl').is_dir()
  if case in ('write','bytes'):assert (p/'trace.jsonl').read_bytes()==b''
  if case=='partial':assert (p/'trace.jsonl').read_bytes() and not (p/'trace.jsonl').read_bytes().endswith(b'\n')
  if case=='records':assert len((p/'trace.jsonl').read_bytes().splitlines())==32
  if case=='classify':assert len((p/'trace.jsonl').read_bytes().splitlines())==1
 rows.append({'case':case,'actualChildExit':code})
print(json.dumps({'scope':'root original mock receipt intake only','ok':True,'cases':rows,'archiveMembers':members,'ownedFiles':len(t['ownedFiles']),'runtimeFiles':len(f['runtime']['files']),'actualOuterExit':outer['wrapperExitCode']}))
