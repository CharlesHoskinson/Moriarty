'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {PHASES, createTrace, install} = require('./observer.cjs');
const {left, right} = require('/home/charl/.npm-global/lib/node_modules/@informalsystems/quint/node_modules/@sweet-monads/either/cjs/index.js');
const [kind, directory] = process.argv.slice(2);
const trace = path.join(directory, 'trace.jsonl');
function memoryTrace() {
  const rows = [];
  const emit = createTrace('memory', {openSync: () => 9, writeSync: (fd, raw) => {
    rows.push(JSON.parse(raw.toString())); return raw.length;
  }}, () => BigInt(rows.length));
  return {emit, rows};
}
function commands(fn) { return Object.fromEntries(PHASES.map(p => [p, fn])); }
async function identity() {
  const report = [];
  for (const mode of ['sync-right', 'sync-left', 'resolve', 'reject', 'throw']) {
    const {emit, rows} = memoryTrace();
    const receiver = {}, argument = {mutable: 0}, result = mode === 'sync-left' ? left(argument) : right(argument);
    const error = new Error('identity sentinel');
    let calls = 0, promise;
    const exports = commands(function (...args) {
      calls += 1; assert.equal(this, receiver); assert.equal(args.length, 1); assert.equal(args[0], argument);
      argument.mutable += 1;
      if (mode === 'throw') throw error;
      if (mode === 'resolve') return promise = Promise.resolve(result);
      if (mode === 'reject') return promise = Promise.reject(error);
      return result;
    });
    install(exports, emit);
    if (mode === 'throw') assert.throws(() => exports.load.call(receiver, argument), e => e === error);
    else {
      const returned = exports.load.call(receiver, argument);
      if (mode === 'resolve' || mode === 'reject') {
        assert.equal(returned, promise);
        if (mode === 'resolve') assert.equal(await returned, result);
        else await assert.rejects(returned, e => e === error);
      } else assert.equal(returned, result);
    }
    assert.equal(calls, 1); assert.equal(argument.mutable, 1);
    assert.equal(rows.length, 2); assert.equal(rows[0].event, 'enter');
    assert.equal(rows[1].event, ({resolve: 'resolve', reject: 'reject', throw: 'throw'})[mode] || 'return');
    assert.equal(rows[1].outcome, ({'sync-left': 'Left', reject: 'rejected', throw: 'thrown'})[mode] || 'Right');
    report.push({mode, calls, rows});
  }
  for (const broken of [false, true]) {
    const {emit, rows} = memoryTrace(), called = [], objects = [];
    const exports = Object.fromEntries(PHASES.map(phase => [phase, function (arg) {
      called.push(phase); objects.push(arg);
      if (phase === 'outputResult') return undefined;
      return Promise.resolve(phase === 'compile' && broken ? left(arg) : right(arg));
    }]));
    const state = {};
    install(exports, emit);
    // Same asyncChain shape as cli.js:59–60,119–124. No synthetic skipped call.
    await exports.load(state).then(r => r.asyncChain(exports.parse))
      .then(r => r.asyncChain(exports.typecheck)).then(r => r.asyncChain(exports.compile))
      .then(r => r.asyncChain(exports.outputCompilationTarget)).then(exports.outputResult);
    const wanted = PHASES.filter(p => !broken || p !== 'outputCompilationTarget');
    assert.deepEqual(called, wanted);
    assert.deepEqual(rows.filter(r => r.event === 'enter').map(r => r.phase), wanted);
    assert.ok(objects.slice(0, -1).every(v => v === state));
    assert.equal(objects.at(-1).value, state);
    assert.equal(rows.at(-2).outcome, broken ? 'Left' : 'Right');
    report.push({mode: broken ? 'left-chain' : 'right-chain', calls: called, rows});
  }
  // A whole event-loop turn under strict rejection handling catches a rejected
  // unused observer continuation; there is no global event handler in this test.
  await new Promise(resolve => setImmediate(resolve));
  process.stdout.write(JSON.stringify({ok: true, controls: report}) + '\n');
}
if (kind === 'identity') {
  identity().catch(error => { process.stderr.write(String(error) + '\n'); process.exitCode = 1; });
} else {
  let io = fs, clock = process.hrtime.bigint;
  if (kind === 'open') fs.mkdirSync(trace);
  if (kind === 'write') io = {openSync: fs.openSync, writeSync: () => { throw new Error('injected write'); }};
  if (kind === 'partial') io = {openSync: fs.openSync, writeSync: (fd, raw) => fs.writeSync(fd, raw.subarray(0, raw.length - 1))};
  if (kind === 'bytes') clock = () => BigInt('1'.repeat(17000));
  const emit = createTrace(trace, io, clock);
  if (kind === 'records') {
    for (let i = 0; i < 33; i++) emit('load', 'enter', 'stage');
  } else if (kind === 'classify') {
    const exports = commands(() => {
      fs.writeFileSync(path.join(directory, 'original-called.txt'), '1\n', {flag: 'wx'});
      return {};
    });
    install(exports, emit); exports.load({});
  } else if (['open', 'write', 'partial', 'bytes'].includes(kind)) {
    const exports = commands(() => {
      fs.writeFileSync(path.join(directory, 'original-called.txt'), '1\n', {flag: 'wx'});
      return right(null);
    });
    install(exports, emit); exports.load({});
  } else throw new Error('unknown control');
  throw new Error('fault failed to stop observer');
}
