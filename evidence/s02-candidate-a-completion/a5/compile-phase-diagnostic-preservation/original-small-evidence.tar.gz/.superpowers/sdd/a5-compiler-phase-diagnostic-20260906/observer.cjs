'use strict';
const fs = require('node:fs');
const either = require('/home/charl/.npm-global/lib/node_modules/@informalsystems/quint/node_modules/@sweet-monads/either/cjs/index.js');
const prototype = Object.getPrototypeOf(either.right(null));
const PHASES = Object.freeze(['load', 'parse', 'typecheck', 'compile', 'outputCompilationTarget', 'outputResult']);
function fail() {
  try { fs.writeSync(2, 'phase-observer: diagnostic failure\n'); } catch (_) {}
  process.exit(74);
}
function outcome(value) {
  try {
    if (Object.getPrototypeOf(value) !== prototype) fail();
    const d = Object.getOwnPropertyDescriptor(value, 'type');
    if (!d || !Object.hasOwn(d, 'value') || !['Left', 'Right'].includes(d.value)) fail();
    return d.value;
  } catch (_) { fail(); }
}
function createTrace(path, io = fs, clock = process.hrtime.bigint) {
  let fd;
  try { fd = io.openSync(path, 'wx', 0o600); } catch (_) { fail(); }
  let sequence = 0, bytes = 0, previous = -1n;
  return function emit(phase, event, result) {
    try {
      if (!PHASES.includes(phase) || !['enter', 'return', 'resolve', 'throw', 'reject'].includes(event)) fail();
      if (!['stage', 'Left', 'Right', 'undefined', 'thrown', 'rejected'].includes(result)) fail();
      const ns = clock();
      if (typeof ns !== 'bigint' || ns < 0n || ns < previous) fail();
      const raw = Buffer.from(JSON.stringify({seq: sequence + 1, phase, event, outcome: result, ns: String(ns)}) + '\n');
      if (sequence >= 32 || bytes + raw.length > 16384) fail();
      if (io.writeSync(fd, raw) !== raw.length) fail();
      sequence += 1; bytes += raw.length; previous = ns;
    } catch (_) { fail(); }
  };
}
function install(commands, emit) {
  const safeEmit = (...args) => { try { emit(...args); } catch (_) { fail(); } };
  try {
  for (const phase of PHASES) {
    const descriptor = Object.getOwnPropertyDescriptor(commands, phase);
    if (!descriptor || typeof descriptor.value !== 'function' || !descriptor.writable) fail();
    const original = descriptor.value;
    const observed = function (...args) {
      safeEmit(phase, 'enter', phase === 'outputResult' ? outcome(args[0]) : 'stage');
      let value;
      try { value = Reflect.apply(original, this, args); }
      catch (error) { safeEmit(phase, 'throw', 'thrown'); throw error; }
      if (value instanceof Promise) {
        // Return the original promise. Both observing callbacks return undefined;
        // neither forwards rejection into the otherwise unused observing promise.
        try {
          Promise.prototype.then.call(value,
            result => { safeEmit(phase, 'resolve', outcome(result)); },
            error => { safeEmit(phase, 'reject', 'rejected'); });
        } catch (_) { fail(); }
      } else {
        safeEmit(phase, 'return', phase === 'outputResult' && value === undefined ? 'undefined' : outcome(value));
      }
      return value;
    };
    Object.defineProperty(commands, phase, {...descriptor, value: observed});
  }
  } catch (_) { fail(); }
}
module.exports = {PHASES, fail, createTrace, install};
