"""Finite diagnostic recorder. Observation preservation is not compiler acceptance."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import signal
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PYTHON = '/home/charl/Moriarty/.venv/bin/python'
NODE = '/home/charl/.foreman/tools/fnm/node-versions/v24.18.1/installation/bin/node'
PACKAGE = Path('/home/charl/.npm-global/lib/node_modules/@informalsystems/quint')
CLI = str(PACKAGE / 'dist/src/cli.js')
PLAN = ROOT / 'docs/superpowers/plans/2026-09-06-candidate-a-compiler-phase-diagnostic.md'
DESIGN = ROOT / 'docs/superpowers/specs/2026-09-06-candidate-a-compiler-phase-diagnostic-design.md'
PLANNING = ROOT / 'evidence/s02-candidate-a-completion/a5/compile-phase-diagnostic-planning'
OLD = ROOT / '.superpowers/sdd/a5-factoring-receipts'
VIEW = OLD / 'pilot-compilation-view'
ALIAS = OLD / 'alias-visibility-control'
RUNTIME = OLD / 'tool-store/manifest.json'
RH = ROOT / 'evidence/s02-candidate-a-completion/a4/native-resources/runner.py'
RH_SHA = 'd8973d3541269d1be2ce524f2482e5f5b858f15f7d9117e3fe6d5cd2171d660d'
A4 = ROOT / '.superpowers/sdd/a4-task6-resumption-20260906'
A4_SHA = '63d8f00d024dbafb08fef0d48da96c91ca594bfe33476946ab0960bfd7dcf666'
PHASES = ['load', 'parse', 'typecheck', 'compile', 'outputCompilationTarget', 'outputResult']
MODES = ['prepare', 'mocks', 'adopt-mocks', 'aliases', 'adopt-aliases', 'authorize-full', 'full', 'intake']

def require(value, message):
    if not value:
        raise RuntimeError(message)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

require(sys.flags.optimize == 0 and sys.flags.dont_write_bytecode, 'require optimization zero and -B')
require(sys.executable == PYTHON, 'exact admitted virtualenv interpreter required')
require(sha(A4 / 'recorder.py') == A4_SHA and sha(RH) == RH_SHA, 'admitted pure utilities changed')
# Import only; neither module's __main__ entry runs. No global variable overrides.
utility = runpy.run_path(str(A4 / 'recorder.py'))
group = runpy.run_path(str(RH))
pin, write, read, archive = (utility[n] for n in ('pin', 'write', 'read', 'archive'))
cleanup_group, group_exists = group['cleanup_group'], group['group_exists']
require(sha(A4 / 'recorder.py') == A4_SHA and sha(RH) == RH_SHA, 'utilities changed during import')

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()

def expected_argv(kind):
    if kind == 'full':
        entry = VIEW / 'view/specs/quint/s02/factored_verification/candidate_a_funding_pilot.qnt'
        main, invariant = 'candidate_a_funding_pilot', 'pilotSafety'
    else:
        require(kind in ('success', 'error'), 'bad input kind')
        suffix = 'direct' if kind == 'success' else 'original'
        entry = ALIAS / 'src' / ('driver_' + suffix + '.qnt')
        main, invariant = 'alias_visibility_' + suffix, 'safety'
    return [NODE, CLI, 'compile', str(entry), '--main=' + main,
            '--target=json', '--invariant=' + invariant, '--verbosity=0']

def check_pins(rows):
    require(len({r['path'] for r in rows}) == len(rows), 'duplicate pin')
    actual = [pin(Path(r['path'])) for r in rows]
    require(actual == rows, 'source bytes changed')
    return actual

def runtime():
    require(sha(RUNTIME) == 'fa3e9838c66480557ed6d928a2d159ebc074d05f67f15ef08ab20388d9c49e0b', 'runtime manifest changed')
    m = read(RUNTIME)
    for root, expected in m['treeMembers'].items():
        require(sorted({str(p.resolve()) for p in Path(root).rglob('*') if p.is_file()}) == expected,
                'runtime tree membership changed')
    refs = [pin(RUNTIME), pin(RUNTIME.parent / 'runtime.tar.gz'),
            pin(Path(m['reusedPythonManifest'])), pin(Path(m['reusedPythonArchive']))]
    require([r['sha256'] for r in refs[1:]] == [m['archiveSha256'],
            m['reusedPythonManifestSha256'], m['reusedPythonArchiveSha256']], 'runtime archive references changed')
    require(len(m['files']) == 4758 and len(m['pythonFiles']) == 3329, 'runtime inventory counts')
    expected = {}
    for row in m['files'] + m['pythonFiles']:
        require(row['path'] not in expected or expected[row['path']] == row['sha256'], 'inconsistent shared pin')
        expected[row['path']] = row['sha256']
    files = []
    for name, wanted in sorted(expected.items()):
        actual = pin(Path(name)); require(actual['sha256'] == wanted, 'runtime file changed: ' + name)
        files.append(actual)
    return {'references': refs, 'files': files, 'runtimeFiles': 4758, 'pythonFiles': 3329}

def prepare():
    require(set(p.name for p in OUT.iterdir()) ==
            {'observer.cjs', 'launch.cjs', 'controls.cjs', 'record.py', 'review-implementation.md', 'transport'},
            'fresh directory with four sources and independent implementation review required')
    require((OUT / 'review-implementation.md').read_text().startswith('PASS\n'), 'root implementation review required')
    blocks = dict(re.findall(r'^<!-- file: ([^ ]+) -->\n```(?:javascript|python)\n(.*?)^```$', PLAN.read_text(), re.S | re.M))
    require(set(blocks) == {'observer.cjs', 'launch.cjs', 'controls.cjs', 'record.py'}, 'exact four plan blocks')
    for name, source in blocks.items():
        require((OUT / name).read_bytes() == source.encode(), 'implementation differs from reviewed plan')
    fixed = {
        DESIGN: '19ff70c32004d824ee1b5e34e722425a354412d3548f321a943b6e32fc9ca67a',
        PLANNING / 'design-adoption.json': 'dfc706f891a44c2260f40e68fb2fd2f8b903f1448d7c603cbfcf561ae624fcb2',
        VIEW / 'view-manifest.json': '5b158d684be97052eb362f217c25f1fbaf03583fbd67fd46c5972b0662dcf1a2',
        OLD / 'task2-frozen-source.json': '97fad04118219a75017a738eb7dc4fb013d351161892cfa05e26c26528f55ab2',
        VIEW / 'compile-original/input.json': 'e61e0d68cfe73ca9b2f1e342a59c04637ba870beed781ece2517ec409ac1f026',
        ALIAS / 'original-file-hash-index.json': '7dc430fd098e7fded8ebac492cfbda9d486ffa863802bf830e21ef330e563fde',
        ALIAS / 'direct-compile/input.json': '94ca8f9d328c44aee9e32e212dd05fa8b1c41445600394e9381186fc2c6f2a01',
        ALIAS / 'original-compile/input.json': '8d029348ef1fa478c416bc479e56b13f466a866b899e98741251fca23538657b',
        RH: RH_SHA, A4 / 'recorder.py': A4_SHA,
        PACKAGE / 'dist/src/cli.js': 'ac12595b1cb7253feec93c79417615c6eb20fc3b6a3df35c5e3530b24e90a501',
        PACKAGE / 'dist/src/cliCommands.js': 'b18672d656782aefde254fe1021dc13fdffdcf8f4ad8709e3126fb5fa293362a',
        PACKAGE / 'node_modules/@sweet-monads/either/cjs/index.js': '4b789da6fbd347942c20977ccc140524dc8297179a3cd1d96a5b36327ad30757',
    }
    view = read(VIEW / 'view-manifest.json'); original = read(OLD / 'task2-frozen-source.json')['files']
    require(len(view['files']) == 24 and len(original) == 30, 'frozen input counts')
    for row in view['files']:
        fixed[ROOT / row['view']] = row['viewSha256']
        fixed[ROOT / row['original']] = row['originalSha256']
    for row in original:
        fixed[ROOT / row['path']] = row['sha256']
    index = read(ALIAS / 'original-file-hash-index.json')
    aliases = [r for r in index['originalFiles'] if r['path'].startswith(str(ALIAS.relative_to(ROOT)) + '/src/')]
    require(len(aliases) == 4, 'four frozen alias-control sources')
    for row in aliases:
        fixed[ROOT / row['path']] = row['sha256']
    for name, wanted in fixed.items():
        require(sha(name) == wanted, 'fixed source changed: ' + str(name))
    for kind, folder in [('full', VIEW / 'compile-original'), ('success', ALIAS / 'direct-compile'), ('error', ALIAS / 'original-compile')]:
        require(read(folder / 'input.json')['argv'] == expected_argv(kind), 'historical effective argv binding')
    paths = set(fixed) | {PLAN, RUNTIME, OUT / 'review-implementation.md'}
    paths.update(OUT / name for name in blocks)
    paths.update(PLANNING.glob('*.md'))
    snapshot = runtime()
    write(OUT / 'freeze.json', {'createdAt': now(), 'preparationHead': head(),
          'sources': [pin(p) for p in sorted(paths)], 'runtime': snapshot,
          'historicalDispatchHead': '43f33721da7a3bfb11dd1a91f1f548d5110ab93c',
          'runtimeBootstrapHead': '900bb2051225b4a3d99bf422c3b2e5e386e3e7bc'})
    print(json.dumps({'ok': True, 'scope': 'prepared source only', 'freeze': pin(OUT / 'freeze.json')}))

def environment(mock):
    env = dict(os.environ)
    removed = ['NODE_PATH', 'NODE_COMPILE_CACHE', 'PYTHONPATH', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS',
               'JDK_JAVA_OPTIONS', 'LD_PRELOAD', 'LD_LIBRARY_PATH', 'PYTHONOPTIMIZE']
    for key in removed:
        env.pop(key, None)
    fixed = {'PATH': '/usr/lib/jvm/java-25-openjdk-amd64/bin:' + str(Path(NODE).parent) + ':/usr/bin:/bin',
        'APALACHE_JAR': '/home/charl/.quint/apalache-dist-0.56.1/apalache/lib/apalache.jar',
        'JVM_ARGS': '-Xmx4096m',
        'JVM_GC_ARGS': '-XX:+UseG1GC -XX:G1PeriodicGCInterval=600000 -XX:+G1PeriodicGCInvokesConcurrent',
        'NODE_OPTIONS': '--max-old-space-size=128 --unhandled-rejections=strict' if mock else '--max-old-space-size=4096',
        'NODE_DISABLE_COMPILE_CACHE': '1', 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1'}
    env.update(fixed)
    return env, fixed, removed

def transport(mode):
    folder = OUT / 'transport' / mode
    result = read(folder / 'terminal.json')
    require(result['command'] == command(mode) and result['cwd'] == str(ROOT), 'outer command binding')
    responses = [read(p) for p in sorted(folder.glob('response-*.json'))]
    require(responses == result['toolResponses'] and responses and
            type(responses[-1].get('exit_code')) is int and
            result['wrapperExitCode'] == responses[-1]['exit_code'], 'authentic outer terminal required')
    return [pin(p) for p in sorted(folder.iterdir()) if p.is_file()]

def command(mode):
    return 'PYTHONOPTIMIZE=0 ' + PYTHON + ' -B ' + str(OUT / 'record.py') + ' ' + mode

def verify_stage(mode):
    terminal = read(OUT / mode / 'terminal.json')
    require(terminal['recorderExit'] == 0 and terminal['finalized'], 'previous recorder gate failed')
    check_pins(terminal['ownedFiles'])
    pins = transport(mode)
    require(read(OUT / 'transport' / mode / 'terminal.json')['wrapperExitCode'] == 0, 'previous actual outer gate failed')
    return pins + [pin(OUT / mode / 'terminal.json')]

def adopt(mode):
    review = OUT / ('review-' + mode + '.md')
    require(review.read_text().startswith('PASS\n'), 'separate root review required')
    files = verify_stage(mode) + [pin(review), pin(OUT / 'freeze.json')]
    write(OUT / ('adopt-' + mode + '.json'), {'rootDecision': 'admit wrapper controls only',
          'createdAt': now(), 'head': head(), 'files': files})
    print(json.dumps({'ok': True, 'adopted': mode, 'scope': 'wrapper controls only'}))

def verify_adoption(mode):
    a = read(OUT / ('adopt-' + mode + '.json'))
    check_pins(a['files']); verify_stage(mode)

def a4_terminal():
    folder = A4 / 'fresh97'
    terminal = read(folder / 'terminal.json')
    outer = read(folder / 'outer-tool-receipt.json')
    require(type(terminal['exitCode']) is int and not terminal['artifactFinalizationBlocked'], 'A4 not terminal/clean')
    require(outer['args']['workdir'] == str(ROOT) and outer['responses'] and
            type(outer['responses'][-1].get('exit_code')) is int and
            outer['responses'][-1]['exit_code'] == terminal['exitCode'],
            'A4 actual outer terminal missing')
    for lifecycle in terminal['commandLifecycles']:
        require(not lifecycle['artifactFinalizationBlocked'] and lifecycle['cleanup']['complete'], 'A4 uncertain writer')
        if lifecycle['ownedPgid'] is not None:
            require(not group_exists(lifecycle['ownedPgid']), 'A4 group still present; root must resolve identity')
    return [pin(folder / 'terminal.json'), pin(folder / 'outer-tool-receipt.json')]

def authorize_full():
    verify_adoption('mocks'); verify_adoption('aliases')
    review = OUT / 'review-dispatch.md'
    require(review.read_text().startswith('PASS\n'), 'separate root full-dispatch review required')
    require(not (OUT / 'full').exists(), 'full slot already used')
    files = a4_terminal() + [pin(review), pin(OUT / 'freeze.json'),
            pin(OUT / 'adopt-mocks.json'), pin(OUT / 'adopt-aliases.json')]
    write(OUT / 'root-dispatch.json', {'createdAt': now(), 'actualDispatchHead': head(), 'files': files,
          'argv': expected_argv('full'), 'wallSeconds': 900, 'nodeHeapMiB': 4096, 'jvmHeapMiB': 4096,
          'invocations': 1, 'scope': 'one original-view diagnostic observation only; H1 unresolved'})
    print(json.dumps({'ok': True, 'scope': 'separate root dispatch recorded; no native launch'}))

def trace_info(folder, code):
    path = folder / 'trace.jsonl'
    try:
        require(path.is_file() and not path.is_symlink(), 'missing trace')
        with path.open('rb') as stream:
            raw = stream.read(16385)
        require(0 < len(raw) <= 16384 and raw.endswith(b'\n'), 'trace byte bound/termination')
        def unique(pairs):
            value = {}
            for key, item in pairs:
                require(key not in value, 'duplicate trace key')
                value[key] = item
            return value
        rows = [json.loads(line, object_pairs_hook=unique) for line in raw.splitlines()]
        require(len(rows) <= 32, 'trace count bound')
        next_phase, pending, previous, last_entered, last_completed = 0, None, -1, None, None
        final_error, output_outcome = False, 'Right'
        for number, row in enumerate(rows, 1):
            require(set(row) == {'seq', 'phase', 'event', 'outcome', 'ns'} and
                    type(row['seq']) is int and row['seq'] == number, 'trace schema/sequence')
            require(type(row['ns']) is str and re.fullmatch(r'[0-9]+', row['ns']), 'trace clock encoding')
            ns = int(row['ns']); require(ns >= previous, 'trace clock order'); previous = ns
            if row['event'] == 'enter':
                require(not final_error and pending is None and next_phase < 6 and row['phase'] == PHASES[next_phase], 'phase entry order')
                require(row['outcome'] == (output_outcome if next_phase == 5 else 'stage'), 'entry classification')
                pending = row['phase']; last_entered = row['phase']
            else:
                require(pending == row['phase'] and pending != 'outputResult', 'completion without valid entry')
                require((row['event'] == 'resolve' and row['outcome'] in ('Left', 'Right')) or
                        (row['event'], row['outcome']) in [('throw', 'thrown'), ('reject', 'rejected')], 'completion classification')
                last_completed = {'phase': pending, 'event': row['event'], 'outcome': row['outcome']}
                pending = None
                if row['outcome'] == 'Left':
                    next_phase, output_outcome = 5, 'Left'
                elif row['outcome'] == 'Right':
                    next_phase += 1
                else:
                    final_error = True
        require(code != 74, 'observation failure exit 74')
        return {'valid': True, 'rows': rows, 'lastEntered': last_entered, 'lastCompleted': last_completed,
                'incompleteObservedInterval': pending, 'locationMeaning': 'includes observer I/O and scheduling margins'}
    except Exception as exc:
        return {'valid': False, 'lastEntered': None, 'lastCompleted': None,
                'incompleteObservedInterval': None, 'reason': type(exc).__name__ + ': ' + str(exc)}

def spawn(folder, argv, wall, mock, sources, lifecycle):
    folder.mkdir()
    source_bytes = archive(folder / 'source.tar.gz', [Path(r['path']) for r in sources])
    env, fixed, removed = environment(mock)
    measured = ['/usr/bin/time', '-v', '-o', str(folder / 'resources.txt'), *argv]
    write(folder / 'start.json', {'createdAt': now(), 'actualDispatchHead': head(), 'argv': argv,
          'measuredArgv': measured, 'cwd': str(ROOT), 'wallSeconds': wall, 'fixedEnvironment': fixed,
          'removedEnvironmentKeys': removed, 'parentOrigArgv': sys.orig_argv,
          'sourceArchive': pin(folder / 'source.tar.gz'), 'sourceBytes': source_bytes})
    child, problem, timed_out = None, None, False
    cleanup = {'forced': False, 'signals': [], 'errors': [], 'complete': False}
    phase, received = 'launch', []
    lifecycle.update({'finalizationBlocked': True, 'childExit': None, 'ownedPgid': None})
    def interrupted(signum, frame):
        received.append(signal.Signals(signum).name)
        if phase == 'wait':
            raise InterruptedError('recorder interrupted')
    previous = {sig: signal.signal(sig, interrupted) for sig in (signal.SIGINT, signal.SIGTERM)}
    started = time.monotonic()
    try:
        with (folder / 'stdout.bin').open('xb') as stdout, (folder / 'stderr.bin').open('xb') as stderr:
            try:
                child = subprocess.Popen(measured, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
                lifecycle['ownedPgid'] = child.pid
                phase = 'wait'
                if received:
                    raise InterruptedError('recorder interrupted during spawn')
                write(folder / 'process.json', {'pid': child.pid, 'ownedPgid': child.pid, 'parentPid': os.getpid(),
                      'startNewSession': True, 'recordedAt': now(), 'meaning': 'spawn identity; not present liveness'})
                remaining = max(0, wall - (time.monotonic() - started))
                child.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                timed_out = True
            except BaseException as exc:
                problem = type(exc).__name__ + ': ' + str(exc)
            finally:
                phase = 'cleanup'
                if child is None:
                    cleanup['complete'] = True
                else:
                    observation_error = None
                    try:
                        present = group_exists(child.pid)
                    except BaseException as exc:
                        present = True
                        observation_error = type(exc).__name__ + ': ' + str(exc)
                    try:
                        if timed_out or problem or received or child.returncode is None or present:
                            cleanup = cleanup_group(child, 5, 5)
                        else:
                            cleanup['complete'] = True
                        if observation_error is not None:
                            cleanup['errors'].append(observation_error)
                            cleanup['complete'] = False
                    except BaseException as exc:
                        cleanup['errors'].append(type(exc).__name__ + ': ' + str(exc))
                        cleanup['complete'] = False
    except BaseException as exc:
        problem = problem or type(exc).__name__ + ': ' + str(exc)
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)
    code = child.returncode if child is not None else None
    complete = cleanup['complete'] and not cleanup['errors']
    # Publish before any terminal serialization, stream hash, or source check.
    lifecycle.update({'finalizationBlocked': not complete, 'childExit': code,
          'ownedPgid': child.pid if child else None, 'cleanup': cleanup, 'timedOut': timed_out,
          'monitorError': problem, 'receivedSignals': received})
    write(folder / 'process-terminal.json', dict(lifecycle, completedAt=now(), elapsedSeconds=time.monotonic() - started))
    require(complete, 'owned process group uncertain: root takeover before hashing')
    check_pins(sources)
    resource, resource_error = None, None
    try:
        resource = group['parse_resource'](folder / 'resources.txt', argv)
    except Exception as exc:
        resource_error = type(exc).__name__ + ': ' + str(exc)
    result = dict(lifecycle, resource=resource, resourceError=resource_error,
                  stdout=pin(folder / 'stdout.bin'), stderr=pin(folder / 'stderr.bin'))
    write(folder / 'result.json', result)
    return result

def ordinary(result, code):
    require(result['childExit'] == code and not result['timedOut'] and not result['cleanup']['forced']
            and not result['monitorError'] and not result['receivedSignals'] and result['cleanup']['complete'], 'native terminal mismatch')
    require(result['resource'] is not None and result['resource']['exit_status'] == code, 'GNU-time exit binding')

def execute(mode):
    require(mode in ('mocks', 'aliases', 'full'), 'unknown execution mode')
    freeze = read(OUT / 'freeze.json')
    check_pins(freeze['sources'])
    if mode in ('aliases', 'full'):
        verify_adoption('mocks')
    if mode == 'full':
        verify_adoption('aliases'); a4_terminal()
        dispatch = read(OUT / 'root-dispatch.json'); check_pins(dispatch['files'])
        require(dispatch['actualDispatchHead'] == head() and dispatch['argv'] == expected_argv('full')
                and dispatch['wallSeconds'] == 900 and dispatch['invocations'] == 1, 'separate root dispatch mismatch')
    stage = OUT / mode
    stage.mkdir()
    life, error, code, before, after, checks = [], None, 1, None, None, None
    sources = freeze['sources'] + [pin(OUT / 'freeze.json')]
    if mode in ('aliases', 'full'):
        sources += [pin(OUT / 'adopt-mocks.json'), pin(OUT / 'review-mocks.md')]
    if mode == 'full':
        sources += [pin(OUT / 'adopt-aliases.json'), pin(OUT / 'review-aliases.md'),
                    pin(OUT / 'root-dispatch.json'), pin(OUT / 'review-dispatch.md')]
    try:
        before = runtime(); require(before == freeze['runtime'], 'runtime differs from preparation')
        write(stage / 'runtime-before.json', before)
        write(stage / 'start.json', {'createdAt': now(), 'mode': mode, 'head': head(), 'sources': sources,
              'parentOrigArgv': sys.orig_argv, 'scope': 'diagnostic observation only; H1 unresolved'})
        if mode == 'mocks':
            records = []
            for case in ['identity', 'open', 'write', 'partial', 'records', 'bytes', 'classify']:
                folder = stage / case; lifecycle = {}; life.append(lifecycle)
                argv = [NODE, str(OUT / 'controls.cjs'), case, str(folder)]
                result = spawn(folder, argv, 15, True, sources, lifecycle)
                ordinary(result, 0 if case == 'identity' else 74)
                stdout, stderr = (folder / 'stdout.bin').read_bytes(), (folder / 'stderr.bin').read_bytes()
                if case == 'identity':
                    report = json.loads(stdout)
                    require(report['ok'] and [r['mode'] for r in report['controls']] ==
                            ['sync-right', 'sync-left', 'resolve', 'reject', 'throw', 'right-chain', 'left-chain']
                            and stderr == b'', 'identity matrix failed')
                else:
                    require(stdout == b'' and stderr == b'phase-observer: diagnostic failure\n', 'fault did not fail closed')
                    called = folder / 'original-called.txt'
                    require(called.read_bytes() == b'1\n' if case == 'classify' else not called.exists(), 'fault original-call predicate')
                    if case == 'records':
                        require(len((folder / 'trace.jsonl').read_bytes().splitlines()) == 32, 'record bound fault')
                    if case == 'bytes':
                        require((folder / 'trace.jsonl').read_bytes() == b'', 'byte bound fault')
                records.append({'case': case, 'result': pin(folder / 'result.json'), 'ok': True})
            checks = {'ok': True, 'scope': 'mock observer controls only', 'cases': records}
        else:
            pairs = [('success', False), ('success', True), ('error', False), ('error', True)] if mode == 'aliases' else [('full', True)]
            results = {}
            for kind, instrumented in pairs:
                name = kind + ('-observed' if instrumented else '-direct')
                folder = stage / name; lifecycle = {}; life.append(lifecycle)
                effective = expected_argv(kind)
                if instrumented:
                    # Invocation is immutable, owned by the parent stage, and archived
                    # with this child. The child directory remains exclusive for spawn.
                    invocation = stage / (name + '-invocation.json')
                    write(invocation, {'effectiveArgv': effective, 'trace': str(folder / 'trace.jsonl'),
                          'argvReceipt': str(folder / 'argv.json')})
                    argv = [NODE, str(OUT / 'launch.cjs'), str(invocation)]
                    child_sources = sources + [pin(invocation)]
                else:
                    argv, child_sources = effective, sources
                result = spawn(folder, argv, 900 if mode == 'full' else 120, False, child_sources, lifecycle)
                if instrumented:
                    trace = trace_info(folder, result['childExit'])
                    actual = read(folder / 'argv.json') if (folder / 'argv.json').is_file() else None
                    argv_ok = (actual is not None and actual['actualLaunchArgv'] == argv and
                               actual['effectiveArgv'] == effective and actual['execPath'] == NODE and
                               actual['execArgv'] == [] and actual['cwd'] == str(ROOT))
                    if not argv_ok or type(result['childExit']) is not int or result['monitorError'] or result['receivedSignals']:
                        trace = {'valid': False, 'lastEntered': None, 'lastCompleted': None,
                                 'incompleteObservedInterval': None, 'reason': 'argv or recorder interruption'}
                    write(folder / 'trace-validation.json', {'argvMatched': argv_ok, **trace})
                    if mode == 'aliases':
                        require(trace['valid'] and argv_ok, 'baseline trace/argv rejected')
                        wanted = PHASES if kind == 'success' else [p for p in PHASES if p != 'outputCompilationTarget']
                        require([r['phase'] for r in trace['rows'] if r['event'] == 'enter'] == wanted, 'baseline phase order')
                        require(trace['rows'][-1]['phase'] == 'outputResult' and
                                trace['rows'][-1]['outcome'] == ('Right' if kind == 'success' else 'Left'), 'baseline final classification')
                if mode == 'aliases':
                    ordinary(result, 0 if kind == 'success' else 1)
                    if not instrumented:
                        if kind == 'success':
                            parsed = json.loads((folder / 'stdout.bin').read_bytes())
                            require(len(parsed['modules']) == 1 and parsed['main'] == 'alias_visibility_direct', 'successful JSON shape')
                            require({'q::init', 'q::step', 'q::inv'} <= {d['name'] for d in parsed['modules'][0]['declarations']}, 'selected declarations')
                            require((folder / 'stderr.bin').read_bytes() == b'', 'successful stderr')
                        else:
                            require((folder / 'stdout.bin').read_bytes() == b'' and b'name resolution failed' in (folder / 'stderr.bin').read_bytes(), 'genuine missing-alias baseline')
                    else:
                        direct = results[kind + '-direct']['folder']
                        for stream_name in ('stdout.bin', 'stderr.bin'):
                            require((direct / stream_name).read_bytes() == (folder / stream_name).read_bytes(), 'baseline raw output mismatch')
                results[name] = {'folder': folder, 'result': result}
            if mode == 'aliases':
                checks = {'ok': True, 'scope': 'four wrapper baseline controls only', 'runs': list(results),
                          'rawPairsEqual': True, 'successfulJSONByteIdentical': True}
            else:
                only = results['full-observed']; result = only['result']
                require(type(result['childExit']) is int and not result['monitorError'] and
                        not result['receivedSignals'], 'full launch or recorder monitor failed; preserve without admission')
                checks = {'ok': True, 'scope': 'preserved diagnostic observation only',
                          'compilerAcceptance': False, 'H1': 'unresolved', 'childExit': result['childExit'],
                          'timedOut': result['timedOut'], 'observationFailureExit74': result['childExit'] == 74,
                          'trace': read(only['folder'] / 'trace-validation.json')}
        write(stage / 'checks.json', checks)
        code = 0
    except BaseException as exc:
        error = type(exc).__name__ + ': ' + str(exc)
    finally:
        blocked = any(r.get('finalizationBlocked', True) for r in life)
        if not blocked:
            try:
                check_pins(sources)
                after = runtime(); require(before == after, 'runtime changed during stage')
                write(stage / 'runtime-after.json', after)
            except BaseException as exc:
                code = 2; error = (error or '') + '; after-check: ' + str(exc)
        else:
            code = 2; error = (error or '') + '; root takeover required; no artifact hashes finalized'
        owned = []
        if not blocked:
            try:
                for p in sorted(stage.rglob('*')):
                    require(not p.is_symlink(), 'unexpected output symlink')
                    if p.is_file():
                        owned.append(pin(p))
            except BaseException as exc:
                code = 2; error = (error or '') + '; artifact-finalization: ' + str(exc)
                owned = []
        terminal = {'recorderExit': code, 'completedAt': now(), 'error': error, 'lifecycles': life,
                    'finalized': not blocked and bool(owned), 'ownedFiles': owned,
                    'scope': 'preservation/control gate only; never H1 or compiler acceptance'}
        write(stage / 'terminal.json', terminal)
        print(json.dumps({'mode': mode, 'recorderExit': code, 'finalized': terminal['finalized'], 'error': error}), flush=True)
    return code

def intake():
    verify_adoption('mocks'); verify_adoption('aliases'); verify_stage('full')
    review = OUT / 'review-final.md'
    require(review.read_text().startswith('PASS\n'), 'independent final preservation review required')
    for mode in ('mocks', 'aliases', 'full'):
        for item in read(OUT / mode / 'terminal.json')['lifecycles']:
            require(not item['finalizationBlocked'] and item['cleanup']['complete'], 'unresolved diagnostic group')
            if item['ownedPgid'] is not None:
                require(not group_exists(item['ownedPgid']), 'group identity requires root resolution')
    require(not (OUT / 'intake.json').exists(), 'intake already exists')
    files, directories = [], []
    for path in sorted(OUT.rglob('*')):
        # Intake's own transport stays incremental until this process exits.
        if OUT / 'transport/intake' in path.parents or path == OUT / 'transport/intake':
            continue
        require(not path.is_symlink(), 'unexpected diagnostic symlink')
        if path.is_file():
            files.append(pin(path))
        elif path.is_dir():
            directories.append(str(path))
        else:
            raise RuntimeError('unexpected diagnostic artifact')
    write(OUT / 'intake.json', {'createdAt': now(), 'scope': 'preserved diagnostic only; H1 unresolved',
          'fullObservation': read(OUT / 'full/checks.json'), 'files': files, 'directories': directories,
          'selfExcluded': True, 'incrementalIntakeTransportExcluded': True,
          'historicalCompilerPhase': 'unknown', 'compilerAcceptance': False})
    print(json.dumps({'ok': True, 'scope': 'preservation intake only', 'intake': pin(OUT / 'intake.json')}))

def main():
    require(len(sys.argv) == 2 and sys.argv[1] in MODES, 'one finite mode required')
    require(sys.orig_argv == [PYTHON, '-B', str(OUT / 'record.py'), sys.argv[1]], 'exact recorder argv required')
    mode = sys.argv[1]
    if mode == 'prepare':
        prepare()
    elif mode.startswith('adopt-'):
        adopt(mode.removeprefix('adopt-'))
    elif mode == 'authorize-full':
        authorize_full()
    elif mode == 'intake':
        intake()
    else:
        return execute(mode)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
