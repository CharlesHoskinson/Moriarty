PASS
Root independently admits the seven exact mock controls from their original identity/fault outputs, authentic child and outer terminals, clean groups, and stable archived source/runtime bindings. This admits observer controls only and authorizes no full diagnostic.
