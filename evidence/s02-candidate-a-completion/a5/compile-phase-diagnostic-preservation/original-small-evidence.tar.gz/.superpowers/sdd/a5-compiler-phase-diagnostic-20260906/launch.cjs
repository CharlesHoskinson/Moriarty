'use strict';
const fs = require('node:fs');
const path = require('node:path');
let hooks;
try { hooks = require('./observer.cjs'); }
catch (_) {
  try { fs.writeSync(2, 'phase-observer: diagnostic failure\n'); } catch (_) {}
  process.exit(74);
}
const {fail, createTrace, install} = hooks;
const CLI = '/home/charl/.npm-global/lib/node_modules/@informalsystems/quint/dist/src/cli.js';
const NODE = '/home/charl/.foreman/tools/fnm/node-versions/v24.18.1/installation/bin/node';
const launched = process.argv.slice();
let spec;
try {
  if (launched.length !== 3 || process.execPath !== NODE) fail();
  spec = JSON.parse(fs.readFileSync(launched[2], 'utf8'));
  if (!Array.isArray(spec.effectiveArgv) || spec.effectiveArgv.length !== 8 ||
      spec.effectiveArgv[0] !== NODE || spec.effectiveArgv[1] !== CLI ||
      spec.effectiveArgv[2] !== 'compile' || spec.effectiveArgv[5] !== '--target=json' ||
      spec.effectiveArgv[7] !== '--verbosity=0') fail();
  if (!path.basename(launched[2]).endsWith('-invocation.json')) fail();
  const folder = path.join(path.dirname(launched[2]), path.basename(launched[2], '-invocation.json'));
  if (spec.trace !== path.join(folder, 'trace.jsonl') || spec.argvReceipt !== path.join(folder, 'argv.json')) fail();
  const raw = Buffer.from(JSON.stringify({actualLaunchArgv: launched, effectiveArgv: spec.effectiveArgv,
    execPath: process.execPath, execArgv: process.execArgv, cwd: process.cwd()}) + '\n');
  if (raw.length > 16384) fail();
  const fd = fs.openSync(spec.argvReceipt, 'wx', 0o600);
  if (fs.writeSync(fd, raw) !== raw.length) fail();
  fs.closeSync(fd);
} catch (_) { fail(); }
const emit = createTrace(spec.trace);
try {
  const commands = require('/home/charl/.npm-global/lib/node_modules/@informalsystems/quint/dist/src/cliCommands.js');
  install(commands, emit);
  process.argv = spec.effectiveArgv.slice();
  require(CLI);
} catch (_) { fail(); }
