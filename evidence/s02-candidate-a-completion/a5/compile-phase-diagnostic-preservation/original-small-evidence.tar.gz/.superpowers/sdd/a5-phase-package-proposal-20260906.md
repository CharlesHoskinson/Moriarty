# A5 closed compiler phase diagnostic: compact package proposal

Planning only. Create a new exclusive `evidence/s02-candidate-a-completion/a5/compile-phase-diagnostic-preservation/` package after root reviews this proposal. Preserve original paths and bytes; do not rewrite the diagnostic OUT, existing A4 packages, source, runtime or receipts. No native invocation, test, retry, solver, commit or H1 adoption is part of packaging.

## Scope and exact archive membership

OUT means `.superpowers/sdd/a5-compiler-phase-diagnostic-20260906/`. Its closed snapshot has **259 regular files, 27,733,617 bytes and 25 directories**, with no symlinks. The authoritative original `intake.json` SHA256 is `f52aabfe60056dfce067edefb3cae9e6fd4863761d1fda2275927599ef4bcac6`: archive exactly its 255 individually pinned files, plus original intake.json itself and exactly `transport/intake/{command.json,response-000.json,terminal.json}`. Preserve all 25 directory entries, including the intentional mock `mocks/open/trace.jsonl` directory. Verify its 24 indexed directories plus the later transport/intake directory exactly. These additions close the intake's explicit self and incremental-transport exclusions; do not alter that original index.

Archive the 22 external originals in the table below, and this proposal itself after its review hash is frozen: **282 regular archive members total** (259 + 22 + 1), plus the explicit directory inventory. Do not recursively include unrelated worktree files. All twelve existing child source.tar.gz files are original small evidence and remain byte-identical; do not deduplicate or regenerate them. Their nested source members also preserve the underlying checker, view, helper and planning source bytes.

The package contains README.md, exclusive build_archive.py, standalone audit.py, original-small-evidence.tar.gz, index.json, packaging-report.json and actual packaging-tool-receipt.json, audit-report.json and actual audit-tool-receipt.json. Preserve any actual failure receipts separately without retrying or replacing originals. A deliberate `-O` audit invocation may verify the rejection guard and must have its own expected-rejection receipt. The index records exact member names, kind, size and SHA256, archive bytes/hash, package support source pins, external runtime bindings, and provenance limits. Generated reports and receipts are new packaging evidence and are not labelled original diagnostic receipts.

## External original members

All paths below are worktree-relative; each row is one additional regular member. Current bytes are checked against these review-time pins during packaging.

| Path | Bytes | SHA256 |
| --- | ---: | --- |
| `.superpowers/sdd/a4-checker-task1-receipts/python-environment.json` | 1172160 | `cd004057c4067bf7cc536d2cec5038add88d0852c1a7de5030e402ff2204f9c4` |
| `.superpowers/sdd/a4-task6-resumption-20260906/fresh97/outer-tool-receipt.json` | 15413 | `4783b46637cfc0ee34302ece1f15079c283187bb699c6ebf94fe5d3e0dadb723` |
| `.superpowers/sdd/a4-task6-resumption-20260906/fresh97/terminal.json` | 786710 | `1ecd99090a183136fe205edfabf766f905259efabf0d7c43efd344f16626ea34` |
| `.superpowers/sdd/a5-factoring-receipts/tool-store/manifest.json` | 3452764 | `fa3e9838c66480557ed6d928a2d159ebc074d05f67f15ef08ab20388d9c49e0b` |
| `.superpowers/sdd/a5-phase-alias-transport-prelaunch-failure-20260906.json` | 1594 | `e6f749ae453e249b6d7362a967d2120a65872050a209bf50cc15467b67066b9b` |
| `.superpowers/sdd/a5-phase-alias-transport-prelaunch-failure-supplement-20260906.json` | 3216 | `8bef27ce84d62614cb7d351dc850cb76f8a50319ac90b4e07b5455983099e967` |
| `.superpowers/sdd/a5-phase-alias-transport-root-disposition-20260906.json` | 1879 | `26ae1732b874f3031837eee15e82b10ae9b2efc7e076750e323862d1a8788f26` |
| `.superpowers/sdd/a5-phase-aliases-independent-intake-20260906.md` | 9438 | `03da6e5dd8cf9297fcf8c2dbfb19a2c380ed601e23d43e318affd721c5ce733e` |
| `.superpowers/sdd/a5-phase-cp001-materialization-report.md` | 1820 | `ff043444a525d7542899103864afa7d8afedcf47609469b72289e4fa0e08c1c4` |
| `.superpowers/sdd/a5-phase-full-independent-intake-20260906.md` | 20562 | `e4b745a1c7d09b0a8cc11a7cd3d3666da1bd8a1da3309bfaa4057d49669fb4f4` |
| `.superpowers/sdd/a5-phase-mocks-root-audit.py` | 4935 | `be9cb254824c0fc79b08e4229953435ecd70fdc06ce2a75d28353cdaa411835b` |
| `docs/superpowers/plans/2026-09-06-candidate-a-compiler-phase-diagnostic.md` | 73437 | `b1df377b077cb7189f945ac493039e1f8d941f5076f61c1be6aaf8559de7bff9` |
| `docs/superpowers/specs/2026-09-06-candidate-a-compiler-phase-diagnostic-design.md` | 9950 | `19ff70c32004d824ee1b5e34e722425a354412d3548f321a943b6e32fc9ca67a` |
| `evidence/s02-candidate-a-completion/a5/compile-phase-diagnostic-planning/design-adoption.json` | 1734 | `dfc706f891a44c2260f40e68fb2fd2f8b903f1448d7c603cbfcf561ae624fcb2` |
| `evidence/s02-candidate-a-completion/a5/compile-phase-diagnostic-planning/design-review-final.md` | 3878 | `0706716986a03f929a7bbbb37a3954fb741a7d49bcee4500f1936cffe0a44d7d` |
| `evidence/s02-candidate-a-completion/a5/compile-phase-diagnostic-planning/design-review-original.md` | 7157 | `923af7c50626de40ed2db893662e6715e7ad52b5411ad1b9f11f1c3388207191` |
| `evidence/s02-candidate-a-completion/a5/compile-phase-diagnostic-planning/implementation-plan-adoption.json` | 2927 | `ad074e6412a58908e838d77c5069c0d2fb3d201c483e794e1e9b6574dfb988c1` |
| `evidence/s02-candidate-a-completion/a5/compile-phase-diagnostic-planning/implementation-plan-correction.md` | 2090 | `4952cefce0986df6d40be34105d1a1495345e9d0e224a633075ffbd46a9f82e4` |
| `evidence/s02-candidate-a-completion/a5/compile-phase-diagnostic-planning/implementation-plan-original.md` | 73186 | `6a861022ed8641e2674f36f5725636c79550fffe3550928012694331cc0d76e4` |
| `evidence/s02-candidate-a-completion/a5/compile-phase-diagnostic-planning/implementation-plan-review-final.md` | 3328 | `d5c029f9461a48ed161d30bd911804eb35f6fcca05ebcf8ade7d89051d88247c` |
| `evidence/s02-candidate-a-completion/a5/compile-phase-diagnostic-planning/implementation-plan-review-original.md` | 7015 | `9091fb1864de49500d048e5e7926a26b466b20c49c4e9e8ba67820cf6d4c31cc` |
| `evidence/s02-candidate-a-completion/a5/compile-phase-diagnostic-planning/source-diagnosis.md` | 9742 | `e62792296758b7cc87cdf18c7d1c13fa0f549d3b096d964cabe3dd86aaf118ee` |

## External large runtime bindings

Preserve both original runtime manifests in the archive and validate their mapping to freeze/runtime-before/runtime-after. Do not copy or rehash these external archives or their installed trees during packaging/audit:

| Original path | Bytes | Recorded SHA256 |
| --- | ---: | --- |
| `.superpowers/sdd/a5-factoring-receipts/tool-store/runtime.tar.gz` | 315704660 | `f0687656d30c0d59ece8dfd027508a9228020506d29b97aea3abe7568186c31c` |
| `.superpowers/sdd/a4-checker-task1-receipts/python-environment.tar.gz` | 66716078 | `7363d106d464f976af2a0e7f1f56e3c7bed237c7a3396a60d073369add068dac` |

The two archives require 382,420,738 external bytes. Their integrity was independently checked in the original full intake; this package audit checks recorded bindings only. Archive inputs are approximately 33.4 MB before compression, including repeated original runtime snapshots and source archives. Compression size is measured only after building. External raw runtime ownership/storage remains unchanged.

## Standalone archive audit requirements

Use Python standard library only. Reject `sys.flags.optimize != 0` with a non-assert guard before reading the archive; use explicit validation errors for every gate. Never import, runpy, eval, exec, subprocess, or otherwise execute archived recorder/helper/test/observer code. Parse source as data only. Read only the new package, including nested archives in memory; do not require the old absolute workspace to exist. Reject duplicate/unsafe tar paths, links, unexpected files or directories and changed bytes, including nested archive membership.

1. Validate exact 282-file membership and every byte hash, explicit directories and all 255 original intake pins. Independently validate the four postindex originals. Check all stage terminal ownedFiles inventories, full17-file closure and original intake scopes. Validate nested source inventories against each start.sourceBytes and corresponding stage sources: seven mock archives of103, two direct alias archives of105, two observed alias archives of106, one full archive of110; stage sources103/105/109. Verify the102 preparation pins against archived source bytes, exact four materialized plan source blocks, design/plan/adoption/review pins,24 view copies and30 original pins, without executing any source.
2. Validate all original transport command/response/terminal triples and their exact ordered response arrays. Full transport has91 returned responses, session86357, actual terminal chunk77d8d8/exit0. The later intake transport has its authentic actual0 receipt and must remain distinct from the255-file preindex. Validate root review-final PASS and external full review SHA `e4b745a1c7d09b0a8cc11a7cd3d3666da1bd8a1da3309bfaa4057d49669fb4f4`.
3. Validate preparation freeze and both control adoptions, all seven mock and four tiny alias original child records with their actual exits, clean unforced groups, output bytes, bounded raw trace rows and recorded control predicates. Check the root mocks audit as preserved source only. Preserve the earlier alias prelaunch save failure, missing nested-save response limitation, exact supplement and root disposition; do not infer an absent save exit or recreate a receipt. Preserve the independent full review's initial orchestration parse error disclosure.
4. Validate one full dispatch, exact archived compiler argv/environment/start HEAD07c3a5462154d45e733d01d8a8bae856cb0f63c4 and source/runtime endpoint records. Verify A4 predecessor terminal and original outer hashes/true exits and temporal order; retain that outer receipt's polling-metadata gap. This verifies the dispatch prerequisite bindings, not a new independent A4 admission. Check all runtime snapshot entries against the original4758 runtime and3329 Python manifest entries with8083 unique paths, accounting for aliases/overlap exactly; no current runtime hashing.
5. Validate full child's authentic GNU-time-wrapped exit-15, timedOut=true, forced/complete SIGTERM cleanup, no SIGKILL/errors, recorder finalized=true/exit0 and authentic outer0. Preserve the distinction between preservation success and compiler failure. Verify stdout/stderr/resources are empty, resource=null with incomplete field inventory, no generated JSON and no separately recorded Node exit. Independently parse the595-byte raw trace with duplicate-key rejection, exact schema/order/sequence/nonnegative monotonic decimal ns, newline and32-record/16-KiB bounds. Require exactly load enter/Right, parse enter/Right, typecheck enter/Right, compile enter, matching trace-validation/checks/intake. No compile return or output marker exists.

## Mandatory interpretation and execution boundary

The package claims only preservation of one closed diagnostic and the **new invocation's incomplete observed public compile interval**. Observer I/O and promise scheduling margins remain included. It does not locate an internal hot spot, prove the function was executing at the timeout instant, identify the historical timeout phase, establish arbitrary observer equivalence, claim compiler acceptance, or resolve H1. Empty resources establish no CPU/RSS/wall measurement. Endpoint pins establish no continuous historical immutability. The full slot remains closed; any future diagnostic needs a separate plan. A4 native/final115 and broader A4/A5 acceptance obligations remain separate.

After root proposal review, create only the new package, run only its archive audit and optional optimization rejection check, retain exact actual outer tool argv/responses/exits including failures, and report frozen source/archive/index/report hashes and size for independent package review. No original recorder intake mode is rerun. No native process or installed runtime is read or modified for the standalone audit. Root owns any later scoped commit.
