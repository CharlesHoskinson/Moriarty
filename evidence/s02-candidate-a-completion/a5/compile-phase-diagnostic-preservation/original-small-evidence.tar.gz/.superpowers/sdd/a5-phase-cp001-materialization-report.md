# CP001 source materialization report

Materialization completed from the adopted plan in worktree
`/home/charl/Moriarty/.worktrees/s01-audit-start`.

Plan SHA-256:

`b1df377b077cb7189f945ac493039e1f8d941f5076f61c1be6aaf8559de7bff9`

The exact CP002 source-only command was run:

```sh
PYTHONOPTIMIZE=0 /home/charl/Moriarty/.venv/bin/python -B - <<'PY'
from pathlib import Path
import re
root = Path('/home/charl/Moriarty/.worktrees/s01-audit-start')
plan = root / 'docs/superpowers/plans/2026-09-06-candidate-a-compiler-phase-diagnostic.md'
out = root / '.superpowers/sdd/a5-compiler-phase-diagnostic-20260906'
blocks = re.findall(r'^<!-- file: ([^ ]+) -->\n```(?:javascript|python)\n(.*?)^```$', plan.read_text(), re.S | re.M)
if len(blocks) != 4 or {name for name, source in blocks} != {'observer.cjs', 'launch.cjs', 'controls.cjs', 'record.py'}:
    raise SystemExit('Plan source block inventory mismatch')
out.mkdir(exist_ok=False)
for name, source in blocks:
    with (out / name).open('xb') as stream:
        stream.write(source.encode())
print('Created four source files only')
PY
```

| File | Bytes | SHA-256 |
|---|---:|---|
| `observer.cjs` | 3073 | `59f706006a73c795c303d84e7c1e3368acd1cf8a7547bfb0d46821f0d69fbd49` |
| `launch.cjs` | 1908 | `f14dc497792d6e440efa4ec974cf838e884adb0945d51c8c1844ed43578af06b` |
| `controls.cjs` | 5234 | `00499f501018da5786f1e692f0de2fc681adead0777aa4c96e15713a34b0aee0` |
| `record.py` | 32822 | `c6720e6941f9d226e780bba06c6aa382daeae2c90cf97381a45f06e15b5e22b8` |

Static exact-block verification passed: each materialized byte stream equals
its anchored plan block, with the expected four-file inventory.

No target file was executed or imported. No Node, Quint, compiler, native,
test, or control command was run. No existing file was edited and no commit
was created.
