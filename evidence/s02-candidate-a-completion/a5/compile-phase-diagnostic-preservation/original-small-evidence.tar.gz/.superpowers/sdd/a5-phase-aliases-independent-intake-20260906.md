# A5 CP003 alias controls: independent actual-evidence intake

Verdict: PASS for the four specified wrapper controls and their evidence
preservation. Root adoption remains separate. This is not full-pilot dispatch,
compiler equivalence for arbitrary inputs, model execution, solver evidence,
A4 admission, or H1 acceptance.

Evidence root:
`.superpowers/sdd/a5-compiler-phase-diagnostic-20260906/`.
The `aliases/` stage and `transport/aliases/` retain the original run records.
Actual recorded source HEAD: `07c3a5462154d45e733d01d8a8bae856cb0f63c4`.

The adopted plan and preparation freeze remain bound to these checked SHA256s:

```text
plan b1df377b077cb7189f945ac493039e1f8d941f5076f61c1be6aaf8559de7bff9
freeze.json 59a2ce768c0e26683ebec421d7ef091b9c3a8f5894b844ad6f8c57e599d9e405
record.py c6720e6941f9d226e780bba06c6aa382daeae2c90cf97381a45f06e15b5e22b8
adopt-mocks.json ff7b67a30a053272f5c2866afdd2ee50b043d2bf257c3edb6ff51f9f0331826a
```

## Actual four-child results

| Child, in recorded order | Actual exit | GNU wall | GNU maximum RSS, KiB | Source archive members | Owned PGID, absent at intake |
| --- | --- | --- | --- | --- | --- |
| success-direct | 0 | 0:00.30 | 127528 | 105 | 3422088 |
| success-observed | 0 | 0:00.28 | 114724 | 106 | 3422144 |
| error-direct | 1 | 0:00.27 | 122096 | 105 | 3422154 |
| error-observed | 1 | 0:00.28 | 114508 | 106 | 3422164 |

All four process-terminal records agree with the stage lifecycle inventory,
result records, process identities and raw GNU-time exits. All have complete,
unforced cleanup, no cleanup signals/errors, no timeout, no recorder monitor
error, no received interruption signal and no blocked finalization. Their
recorded times establish sequential invocations. Read-only `killpg(pgid, 0)`
checks found all four groups absent at this intake; no signal was delivered.

Each original start record binds the exact 120-second child budget, Node
`--max-old-space-size=4096`, JVM `-Xmx4096m`, all other fixed environment entries,
and the complete removed-key list to the adopted plan. Every measured argv is
the exact `/usr/bin/time -v -o <child>/resources.txt` wrapper around the recorded
child argv. All 23 raw resource fields and any nonzero-exit diagnostic lines
match the corresponding parsed result. These are GNU-time invocation metrics,
not an instrumented/uninstrumented performance comparison or a total RSS cap.

The direct effective argv equals the corresponding original alias compile
input receipt. Both instrumented invocation files and launcher argv receipts
match their actual launch paths, restored original CLI argv, empty execArgv,
pinned execPath and worktree cwd. Parent orig_argv agrees with the exact
planned Python recorder command.

## Raw output and selected declarations

The two success stdout files are byte-identical: 16,540 bytes, SHA256
`fd8e96c2ced2081dd5635ae8a42916e831895ae40fb5adb49d18b9189d6173c5`.
Both success stderr files are empty. JSON parses with no warnings/errors, main
and sole module `alias_visibility_direct`, and eight declarations:
`Concrete` (typedef), `box` (var), `init` and `step` (actions), `safety` (val),
`q::init` and `q::step` (actions), and `q::inv` (val).
The generated `q::init` expression names `init`; `q::step` names `step`;
`q::inv` is `and(safety)`. This verifies selected compilation declarations,
not a semantic run of those actions or proof of the invariant.

The two error stdout files are empty. Both error stderr files are byte-identical:
288 bytes, SHA256
`c3986e90aadcf07deab4ba9c1ee2e628640aa860d5e8a7f7069e5f299df68207`.
The original text reports `[QNT404]: Type alias 'Key' not found` at the frozen
`generic.qnt:3:23` alias use and ends with `error: name resolution failed`.
The expected native error remains actual exit 1; the recorder's preservation/
control success does not rewrite that exit.

## Original trace observations

- Success-observed: 978 bytes and 11 records. `load`, `parse`, `typecheck`,
  `compile`, and `outputCompilationTarget` each enter and resolve Right in
  that order. `outputResult` then enters with Right and has no return marker.
  Trace SHA256:
  `3c870aa89d4e485c1bfbf3aa5c8b5af135718035e46da8884bc6b413dccc79c0`.
- Error-observed: 770 bytes and 9 records. `load`, `parse`, and `typecheck`
  enter and resolve Right; `compile` enters and resolves Left.
  `outputCompilationTarget` is absent; `outputResult` enters with Left and
  has no return marker. Trace SHA256:
  `c7e66054e9177950a63f0ce6b43023a8c19c88ebdf301a3ebc67f4fb24936181`.

Independently parsed the raw JSONL with duplicate-key rejection and checked
exact schema, consecutive integer sequence numbers, decimal monotonic clocks,
record/byte bounds, exact phase/event/outcome tuples and final newline. Both
trace-validation records agree with the raw rows and actual argv. The final
outputResult entry is consistent with the original process.exit behavior;
it is not a fabricated completion marker.

## Source, runtime and original terminal bindings

All 44 finalized stage files were rehashed, and their exact set matches the
terminal's ownedFiles inventory; the terminal itself is separately retained.
All four source archives have exact unique membership, regular-file entries,
archive paths, sizes and member hashes matching their original sourceBytes
maps and current pins. Direct children contain the same 105 stage source pins;
each observed child adds its own immutable invocation, for 106 members.

| Child source.tar.gz | SHA256 |
| --- | --- |
| success-direct | `76c170117be880fdf68b0060c5d24a0f4b956697d524545316734eb6b4064d68` |
| success-observed | `b5741af8056575966504a6120d3e99ed0a88576f5a42d4828383b879b5c6087b` |
| error-direct | `f0f6fcb429585d7ce586ebfba98c98343d0317d5407d283d5e08dd9483f271d7` |
| error-observed | `d66f0ee4955411115befb651cd66c91e9b80856cb8dad0af92a8dcaa14f439a6` |

The 102 preparation source pins, 105 stage source pins and mock-adoption
bindings match their current files. All 24 compilation-view copies match the
admitted manifest: exactly two single import additions reverse to their exact
original bytes, and the other copies are identical. All 30 frozen original
pins also match. These unchanged full-pilot inputs were retained as bindings;
the four commands compiled only the tiny alias-control inputs.

Runtime-before and runtime-after are identical to preparation's full runtime
snapshot. Both JSON files have SHA256
`6279005c6766ae5780841c03039f71f83790175a88363be2e79e207ac27024ca`.
Independently checked all 8,083 unique runtime file pins against the manifest's
4,758 runtime and 3,329 Python entries, all four runtime-tree memberships and
four external references, including both original runtime archive hashes.
No replacement runtime archive was created. Endpoint pin equality does not
prove continuous historical immutability.

Actual recorder terminal: exit 0, finalized true, error null, SHA256
`f6b63050244ae0826ccf14670d5c81d99d66efa1ddc1c8e6e38c254f1e11d64c`.
Actual outer transport preserves response chunk `5a6670`, session 19278,
followed by terminal chunk `fdc322`, exit 0. Individual response files equal
the terminal's toolResponses array; command/cwd/exec arguments match exactly.
Outer terminal SHA256:
`5d6397caa50da8898ce89321fec4a491575dfe679de574e9703c4b0d3e993b61`.

## Prelaunch transport failure remains separate

Inspected both root-retained files outside the diagnostic output tree:

```text
.superpowers/sdd/a5-phase-alias-transport-prelaunch-failure-20260906.json
e6f749ae453e249b6d7362a967d2120a65872050a209bf50cc15467b67066b9b
.superpowers/sdd/a5-phase-alias-transport-prelaunch-failure-supplement-20260906.json
8bef27ce84d62614cb7d351dc850cb76f8a50319ac90b4e07b5455983099e967
```

The original narrative records a wrong interpreter path in the first transport
save command and the actual outer script failure. The supplement retains the
original exec input and explicitly marks the nested save exec response as
unavailable. Its failure point is `save('command.json', ...)`, before the
recorder exec call. This supports the scoped conclusion that the recorder and
native compile sequence were not reached by that failed transport call.
Historical empty-directory observations remain root-recorded observations;
this intake does not recreate them. No nested save exit code, stdout, terminal
or recorder outcome is invented. The completed aliases invocation above is
one native control sequence, distinct from that prelaunch transport failure.

## Performed independent audit and limits

The read-only standard-library archive/pin audit completed with actual tool
chunk `8cdbf7`, exit 0 and PASS output. It checked 8,237 distinct current pin
paths, hashing 1,283,902,669 bytes, with per-file stability and final cached
stat checks. The quoted count precedes separate terminal/prelaunch/supplement
hash observations. Follow-up source/metadata inspection completed in chunk
`7135e6`, exit 0. No project recorder/helper was imported or executed; no native,
mock, test, model, solver or full-pilot command ran during this intake.

Only this intake file was written. At final inspection the diagnostic `full/`
directory was absent. This PASS covers the actual pinned success/error wrapper
routes and their evidence, not arbitrary observer equivalence, phase location
for the historical timeout, future full-pilot behavior or H1. Root must make
its separate adoption and any later dispatch decision from these originals.
