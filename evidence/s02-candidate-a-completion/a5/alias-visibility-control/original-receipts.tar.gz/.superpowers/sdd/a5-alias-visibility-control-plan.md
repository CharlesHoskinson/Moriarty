# A5 alias visibility diagnostic control plan

> For agentic workers: use superpowers:executing-plans after root adoption and explicit dispatch. This document is specified-only.

**Goal:** Test the narrowly identified compile-time alias-visibility mechanism with four bounded frontend commands, without changing any Candidate A source or runtime.

**Architecture:** A fresh isolated keys module defines Key; a generic module directly imports it and defines Box[a]. The original driver imports only Box and instantiates Box[int]. A second driver adds only the missing direct Key import, preserving the complete state/actions/invariant. Existing immutable A5 recording/runtime infrastructure retains all originals. No solver runs.

**Tech stack:** Admitted Quint0.32.0, its actual pinned Node, existing4096MiB heap control, CPython3.13.14 with -B/fresh-X, unchanged helper SHA256816c3ad79dc3a67ca9a03729af56d74188c161a7546b9c43e821c222a4bce7f2.

## Hypothesis, syntax evidence and exclusions

The retained actual pilot compile failed at cliCommands.js:423–427, which re-runs name resolution after analyzeModules mutates parameterized type applications. TypeApplicationResolver preserves unqualified Key references from the defining generic type. Imported dependencies are not automatically re-exported, so the consumer may lack that name on the second pass. The original AuthorityKey failure was before flattening/Apalache, not an H1 size comparison or semantic counterexample.

Single-name syntax was inspected, not executed: installed dist/src/generated/QuintParser.js:870–900 accepts IMPORT name '.' identOrStar with optional FROM; parsing/ToIrListener.js:228–247 explicitly documents import Foo.x and sets defName. Both current files match the admitted runtime manifest:

```text
generated/QuintParser.js bf3d9df74e856811e94d564fefb5b7f3f7b85b9dac47b22ac776a38ca29efe1e
parsing/ToIrListener.js 7d7fcfe5c2bbbe2d48e8e921f2be58d1c723848f487f63e42944b6b2bee81104
```

Use `import keys.Key from "./keys"`, not wildcard imports, local duplicate type declarations, namespace substitution or an altered generic body. All work stays under fresh ignored `.superpowers/sdd/a5-factoring-receipts/alias-visibility-control/`. Only this plan exists before adoption. No model/view/helper/runtime patch, package install, native simulation, solver/checker invocation, full mirror, automatic retry, or resource increase is authorized.

Every command's child budget is120seconds, Node/JVM ceiling4096MiB. The unchanged helper verifies shared runtime before/after, retains source archives and GNU-time streams, and uses its existing controlled environment. Its historical beforeDispatchCommit is900bb2051225b4a3d99bf422c3b2e5e386e3e7bc; a new control dispatch binds the actual full40-hex dispatch commit separately. Runtime verification/archival is preparation, not a claim that the entire parent procedure has a120-second elapsed ceiling. Any timeout stops, with original terminal evidence; no solver or retry follows.

## Task1 — Freeze the three-module original and recording closure

**AV001/EARS:** When root dispatches the control, the implementer SHALL create only the following fresh ignored source/recorder files with apply_patch, bind their original bytes and the actual dispatch base, and retain the frozen actual-model/runtime references before any command.

**OpenSpec scenario AV001:** Given an absent control directory and an adopted plan, when root creates dispatch.json, then its actualDispatchBase equals current HEAD, its runtimeBootstrapBase remains900bb20, and its source pins include exactly the original three modules, recorder and plan. A reused directory/file or mismatching pin fails before a control child starts.

- [ ] Create `src/keys.qnt`:

```quint
module keys {
  type Key = {id: int}
}
```

- [ ] Create `src/generic.qnt`:

```quint
module generic {
  import keys.Key from "./keys"
  type Box[a] = {key: Key, value: a}
}
```

- [ ] Create `src/driver_original.qnt`:

```quint
module alias_visibility_original {
  import generic.Box from "./generic"
  type Concrete = Box[int]
  var box: Concrete
  action init = box' = {key: {id: 0}, value: 0}
  action step = box' = box
  val safety = box.key.id == 0 and box.value == 0
}
```

The toy stutter is explicit and local to a compiler control; it is not a new Candidate A transition or liveness assertion.

- [ ] Create `record.py` with this full source. It reuses record(), never modifies helper globals, and pins the complete control imports through extra. Original failed pilot artifacts and every previous control stage's top-level original files are included in later closures.

```python
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
CONTROL = Path(__file__).resolve().parent
PLAN = ROOT / '.superpowers/sdd/a5-alias-visibility-control-plan.md'
BOOTSTRAP = '900bb2051225b4a3d99bf422c3b2e5e386e3e7bc'
assert sys.dont_write_bytecode and sys.pycache_prefix
sys.path.insert(0, str(ROOT))
from scripts.run_s02_candidate_a_factoring_pilot import record, QUINT, RECEIPTS

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

STAGES = ['original-typecheck', 'original-compile', 'direct-typecheck', 'direct-compile']
stage = sys.argv[1]
assert stage in STAGES and len(sys.argv) == 2
dispatch_path = CONTROL / 'dispatch.json'
d = json.loads(dispatch_path.read_text())
assert d['runtimeBootstrapBase'] == BOOTSTRAP
assert re.fullmatch('[0-9a-f]{40}', d['actualDispatchBase'])
assert d['planSha256'] == sha(PLAN)
assert all(sha(ROOT / p) == h for p, h in d['sources'].items())
old = RECEIPTS / 'compile-original-pilotSafety'
prior = json.loads((old / 'input.json').read_text())
assert all(sha(e['path']) == e['sha256'] for e in prior['pins'])
assert sha(old / 'input.json') == d['originalPilotInputSha256']
assert sha(ROOT / 'scripts/run_s02_candidate_a_factoring_pilot.py') == d['runtimeHelperSha256']

original = (CONTROL / 'src/driver_original.qnt').read_text()
direct = stage.startswith('direct-')
if direct:
    expected = original.replace('module alias_visibility_original {', 'module alias_visibility_direct {', 1)
    needle = '  import generic.Box from "./generic"\n'
    assert expected.count(needle) == 1
    expected = expected.replace(needle, needle + '  import keys.Key from "./keys"\n', 1)
    assert (CONTROL / 'src/driver_direct.qnt').read_text() == expected

extras = [ROOT / name for name in d['sources']] + [dispatch_path]
extras += sorted(p for p in old.iterdir() if p.is_file())
if direct:
    extras.append(CONTROL / 'src/driver_direct.qnt')
for previous in STAGES[:STAGES.index(stage)]:
    parent = CONTROL / previous
    check = json.loads((parent / 'control-validation.json').read_text())
    assert check['ok'] is True
    extras += sorted(p for p in parent.iterdir() if p.is_file())
extras = list(dict.fromkeys(extras))
entry = CONTROL / ('src/driver_direct.qnt' if direct else 'src/driver_original.qnt')
module = 'alias_visibility_direct' if direct else 'alias_visibility_original'
compiling = stage.endswith('-compile')
argv = [str(QUINT), 'compile' if compiling else 'typecheck', str(entry)]
if compiling:
    argv += ['--main=' + module, '--target=json', '--invariant=safety', '--verbosity=0']
code = record('alias-visibility-control/' + stage, argv, 120, 4096,
              'aliasVisibilityFrontendControl', 0, compile_output=compiling,
              extra=tuple(extras), before_dispatch_base=BOOTSTRAP,
              domain='Tiny generic-alias visibility control only; no Candidate A execution or solver; actualDispatchBase=' + d['actualDispatchBase'])
out = CONTROL / stage
result = json.loads((out / 'result.json').read_text())
err = (out / 'stderr.txt').read_text()
output = out / ('input.qnt.json' if compiling else 'stdout.txt')
expected_code = 1 if stage == 'original-compile' else 0
checks = {'expectedExit': code == expected_code,
          'noTimeout': result['timedOut'] is False,
          'runtimeStable': result['runtimeUnchanged'] is True,
          'sourceStable': result['sourceAndToolsUnchanged'] is True,
          'originalPilotPinsStable': all(sha(e['path']) == e['sha256'] for e in prior['pins'])}
if stage == 'original-compile':
    diagnostics = re.findall(r'Error \[(QNT[0-9]+)\]: ([^\n]+)', err)
    checks['actualMissingKeyOnly'] = bool(diagnostics) and all(
        code == 'QNT404' and message == "Type alias 'Key' not found" for code, message in diagnostics)
    checks['nameResolutionFailed'] = 'error: name resolution failed' in err
    checks['emptyCompileOutput'] = output.stat().st_size == 0
else:
    checks['emptyStderr'] = err == ''
if stage == 'direct-compile':
    try:
        document = json.loads(output.read_text())
        checks['validGeneratedJSON'] = isinstance(document, dict) and bool(document)
        checks['measuredGeneratedBytes'] = result['generated']['bytes'] == output.stat().st_size > 0
    except (ValueError, KeyError):
        checks['validGeneratedJSON'] = False
ok = all(checks.values())
write(out / 'control-validation.json', {'ok': ok, 'checks': checks,
      'classification': 'Frontend visibility control; not semantic RED or H1 result',
      'actualDispatchBase': d['actualDispatchBase'], 'runtimeBootstrapBase': BOOTSTRAP,
      'parentArgv': sys.orig_argv, 'parentBytecodeDisabled': sys.dont_write_bytecode,
      'parentCachePrefix': sys.pycache_prefix, 'actualCommandExitCode': code,
      'dispatchSha256': sha(dispatch_path)})
raise SystemExit(0 if ok else 1)
```

- [ ] Root reviews these source bytes and creates the new exclusive dispatch with the following code only after adoption. This binds the actual current commit; it never changes the shared900bb20 dispatch. A root-approved runtime/source freeze covers all four commands.

```sh
/home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/a5-alias-control-dispatch-cache - <<'PY'
import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd()
c=root/'.superpowers/sdd/a5-factoring-receipts/alias-visibility-control'
plan=root/'.superpowers/sdd/a5-alias-visibility-control-plan.md'
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
paths=[c/'src/keys.qnt',c/'src/generic.qnt',c/'src/driver_original.qnt',c/'record.py',plan]
helper=root/'scripts/run_s02_candidate_a_factoring_pilot.py'
assert sha(helper)=='816c3ad79dc3a67ca9a03729af56d74188c161a7546b9c43e821c222a4bce7f2'
d={'schema':'moriarty.a5-alias-control-dispatch/v1',
   'actualDispatchBase':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
   'runtimeBootstrapBase':'900bb2051225b4a3d99bf422c3b2e5e386e3e7bc',
   'planSha256':sha(plan),'runtimeHelperSha256':sha(helper),
   'originalPilotInputSha256':sha(root/'.superpowers/sdd/a5-factoring-receipts/compile-original-pilotSafety/input.json'),
   'sources':{str(p.relative_to(root)):sha(p) for p in paths}}
with (c/'dispatch.json').open('x') as stream:
    json.dump(d,stream,indent=2);stream.write('\n')
print(json.dumps(d,indent=2))
PY
```

## Task2 — Preserve the original frontend control

**AV002/EARS:** When the original driver is typechecked and then compiled, the control SHALL retain typecheck exit0 and compile exit1/QNT404 Key with empty generated JSON. Any different result SHALL stop before creating the corrected driver.

**OpenSpec scenario AV002:** Given the three original modules and unchanged runtime, when the two commands below reach terminal, then original-typecheck is accepted only for0 and original-compile is accepted only for the actual missing-Key name-resolution error. A syntax/import parser error, timeout, solver error, different missing alias or unexpected compile success does not satisfy this hypothesis control.

- [ ] Run separately and wait to terminal; do not combine or automatically retry:

```sh
/home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/a5-alias-original-typecheck-parent-cache .superpowers/sdd/a5-factoring-receipts/alias-visibility-control/record.py original-typecheck
/home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/a5-alias-original-compile-parent-cache .superpowers/sdd/a5-factoring-receipts/alias-visibility-control/record.py original-compile
```

Each recording-wrapper expected exit is0 only when its required child outcome matches. The original compile child must still be preserved as exit1; do not report the wrapper0 as compiler success. Original archives must retain keys/generic/original-driver/record/plan/dispatch and the full frozen model/runtime source references before the correction exists. Source locations in the Key error may identify generic.qnt rather than the driver; retain the original diagnostic, not a rewritten locator.

- [ ] Root intakes this terminal pair before the next task. This is a genuine frontend RED, explicitly not the model's semantic behavioral RED and not an H1 falsification.

## Task3 — Single-name visibility correction and bounded handoff

**AV003/EARS:** After root accepts AV002, the implementer SHALL add only a new corrected driver with the necessary module-name change and single direct Key import; all original files remain immutable. Corrected typecheck and compile SHALL both exit0 and retain valid nonempty generated JSON under the same120s/4096MiB bounds.

**OpenSpec scenario AV003:** Given preserved original RED evidence, when the corrected driver is checked, then its normalized source equals the original after removing only its module-name change and direct Key import; both terminal commands pass and exact raw JSON/streams/source archives exist. Different imports, changed types/actions, heap escalation or a second trial do not count.

- [ ] Add only `src/driver_direct.qnt` with apply_patch:

```quint
module alias_visibility_direct {
  import generic.Box from "./generic"
  import keys.Key from "./keys"
  type Concrete = Box[int]
  var box: Concrete
  action init = box' = {key: {id: 0}, value: 0}
  action step = box' = box
  val safety = box.key.id == 0 and box.value == 0
}
```

- [ ] Run separately and retain terminal outcomes:

```sh
/home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/a5-alias-direct-typecheck-parent-cache .superpowers/sdd/a5-factoring-receipts/alias-visibility-control/record.py direct-typecheck
/home/charl/Moriarty/.venv/bin/python -B -X pycache_prefix=.superpowers/sdd/a5-alias-direct-compile-parent-cache .superpowers/sdd/a5-factoring-receipts/alias-visibility-control/record.py direct-compile
```

**AV004/EARS:** When the four outcomes are terminal, the author SHALL hand off exact original source, dispatch, runtime references, input/result/control-validation JSON, stdout or input.qnt.json, stderr, resources, original source-and-runner archives and Java-version streams. The report SHALL distinguish expected outcomes from actual outputs and keep any failure; root SHALL independently audit before any actual-model remedy plan.

**OpenSpec scenario AV004:** Given all four retained stage directories, when root verifies archive members against their input pins and compares both driver bytes, then the only claimed result is whether this tiny visibility mechanism reproduced and was removed by a single-name import. The control does not authorize modifying original/factored adapters, generating a mirror, compiling the real pilot again, running a solver, changing the runtime, or concluding H1.

- [ ] Write a concise new ignored report and exhaustive original-file/hash index under this control directory after terminal intake. Retain failures even if they prevent later stages. Reuse shared runtime4758-file and Python3329-file original archives by their admitted references; do not prepare another environment archive.
- [ ] Root reviews raw generated JSON and its declared module/init/step/safety, not just JSON syntax. No semantic execution is claimed by compile0. Stop after this bounded handoff; a separate reviewed plan is required for any full-source remedy.

## Planning self-review

All four work-unit contracts have explicit EARS/OpenSpec scenarios. Original three-module closure precedes the observed frontend RED; correction is isolated afterward. Single-name grammar was checked in pinned installed sources. Commands use unchanged helper/runtime, separate actual/bootstrap bases, fresh parent caches, exact120s child budget and no solver. This document contains complete proposed source/commands; none has been executed during planning.
