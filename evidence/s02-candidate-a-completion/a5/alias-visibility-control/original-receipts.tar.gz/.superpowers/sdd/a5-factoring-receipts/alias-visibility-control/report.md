# A5 alias visibility control — bounded frontend result

Experiment observation, reproduced: the original three-module control typechecks
successfully but compilation fails with QNT404, `Type alias 'Key' not found`.
Adding the single direct `import keys.Key from "./keys"` to a fresh driver,
together with the required module-name change, yields successful typecheck and
compilation. The original driver and all dispatch-pinned sources remain unchanged.

| Stage | Expected child exit | Actual child exit | Recording wrapper exit | Generated JSON bytes |
| --- | ---: | ---: | ---: | ---: |
| original-typecheck | 0 | 0 | 0 | n/a |
| original-compile | 1 | 1 | 0 | 0 |
| direct-typecheck | 0 | 0 | 0 | n/a |
| direct-compile | 0 | 0 | 0 | 16,540 |

All four `control-validation.json` files report `ok: true`. All stages reached
terminal without timeout, and the unchanged helper reports stable runtime and
source/tool pins. All four original-stage pin closures were independently checked
against current files during author handoff. Source archives contain 83, 93, 104,
and 114 regular members respectively; each member was checked against its recorded
input pin. Original compile stderr preserves the missing-Key location at
`src/generic.qnt:3:23`, followed by `error: name resolution failed`. Other stderr
streams are empty. Wrapper exit 0 records acceptance of the expected child
outcome; the original compiler still exited 1.

Repository observation: each driver matches its complete planned source block.
After removing only the direct driver's module-name change and direct Key import,
the driver bytes match the original. `keys.qnt`, `generic.qnt`, the original
driver, recorder and plan retain their dispatch hashes.

Experiment observation: generated JSON has `main: alias_visibility_direct` and
one module named `alias_visibility_direct`. Declarations are `Concrete`, `box`,
`init`, `step`, `safety`, `q::init`, `q::step`, and `q::inv`. `Concrete` and `box`
retain the nested integer record fields `key.id` and `value`; `init` assigns zero
to both fields, `step` assigns `box` to itself, and `safety` compares both fields
with zero. `q::init` is an action reference to `init`, `q::step` is an action
reference to `step`, and `q::inv` is a val with `and(safety)`. Generated JSON SHA256:
`fd8e96c2ced2081dd5635ae8a42916e831895ae40fb5adb49d18b9189d6173c5`.
Root's independent generated-JSON audit is a separate intake.

Inference: these outcomes support the narrow frontend alias-visibility mechanism
for this toy control. This is a frontend RED followed by a successful bounded
frontend correction. No semantic execution, Candidate A behavioral RED, H1 size
comparison or H1 conclusion follows from these commands. No actual-model remedy
was applied. A separately reviewed plan is required for any such remedy.

Repository observation: the inherited helper's `fairness`, `deadlock`, and pilot
classification prose in input metadata is retained verbatim but does not describe
this frontend control. Its domain string and control-validation classification
record the applicable scope. No solver or checker was invoked by these commands.

The actual dispatch base is `9ccbf0ed571e4055bc05962e5681fdf2fa75ad96`; the
historical runtime bootstrap base remains
`900bb2051225b4a3d99bf422c3b2e5e386e3e7bc`. The helper remains SHA256
`816c3ad79dc3a67ca9a03729af56d74188c161a7546b9c43e821c222a4bce7f2`.
Each exact planned parent command used Python `-B`, its own fresh cache prefix,
a 120-second child budget and the existing 4096 MiB Node/JVM ceilings. The
helper's duration includes post-child runtime checking; GNU-time resources retain
the actual child measurements. Neither is presented as the whole-parent budget.

Each stage retains input/result/control-validation JSON, raw stdout or generated
JSON, stderr, GNU-time resources, source-and-runner archive, Java-version streams
and `outer-command.json` with the actual tool terminal evidence. Later source
archives preserve every earlier stage's top-level originals, including outer
metadata. The admitted 4,758-file shared runtime and 3,329-file Python archives
are reused through their pinned references; no new environment archive was made.
`original-file-hash-index.json` indexes all control originals and this report,
plus external source/runtime references. The index excludes itself explicitly.
