import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
CONTROL = Path(__file__).resolve().parent
PLAN = ROOT / '.superpowers/sdd/a5-alias-visibility-control-plan.md'
BOOTSTRAP = '900bb2051225b4a3d99bf422c3b2e5e386e3e7bc'
assert sys.dont_write_bytecode and sys.pycache_prefix
sys.path.insert(0, str(ROOT))
from scripts.run_s02_candidate_a_factoring_pilot import record, QUINT, RECEIPTS

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

STAGES = ['original-typecheck', 'original-compile', 'direct-typecheck', 'direct-compile']
stage = sys.argv[1]
assert stage in STAGES and len(sys.argv) == 2
dispatch_path = CONTROL / 'dispatch.json'
d = json.loads(dispatch_path.read_text())
assert d['runtimeBootstrapBase'] == BOOTSTRAP
assert re.fullmatch('[0-9a-f]{40}', d['actualDispatchBase'])
assert d['planSha256'] == sha(PLAN)
assert all(sha(ROOT / p) == h for p, h in d['sources'].items())
old = RECEIPTS / 'compile-original-pilotSafety'
prior = json.loads((old / 'input.json').read_text())
assert all(sha(e['path']) == e['sha256'] for e in prior['pins'])
assert sha(old / 'input.json') == d['originalPilotInputSha256']
assert sha(ROOT / 'scripts/run_s02_candidate_a_factoring_pilot.py') == d['runtimeHelperSha256']

original = (CONTROL / 'src/driver_original.qnt').read_text()
direct = stage.startswith('direct-')
if direct:
    expected = original.replace('module alias_visibility_original {', 'module alias_visibility_direct {', 1)
    needle = '  import generic.Box from "./generic"\n'
    assert expected.count(needle) == 1
    expected = expected.replace(needle, needle + '  import keys.Key from "./keys"\n', 1)
    assert (CONTROL / 'src/driver_direct.qnt').read_text() == expected

extras = [ROOT / name for name in d['sources']] + [dispatch_path]
extras += sorted(p for p in old.iterdir() if p.is_file())
if direct:
    extras.append(CONTROL / 'src/driver_direct.qnt')
for previous in STAGES[:STAGES.index(stage)]:
    parent = CONTROL / previous
    check = json.loads((parent / 'control-validation.json').read_text())
    assert check['ok'] is True
    extras += sorted(p for p in parent.iterdir() if p.is_file())
extras = list(dict.fromkeys(extras))
entry = CONTROL / ('src/driver_direct.qnt' if direct else 'src/driver_original.qnt')
module = 'alias_visibility_direct' if direct else 'alias_visibility_original'
compiling = stage.endswith('-compile')
argv = [str(QUINT), 'compile' if compiling else 'typecheck', str(entry)]
if compiling:
    argv += ['--main=' + module, '--target=json', '--invariant=safety', '--verbosity=0']
code = record('alias-visibility-control/' + stage, argv, 120, 4096,
              'aliasVisibilityFrontendControl', 0, compile_output=compiling,
              extra=tuple(extras), before_dispatch_base=BOOTSTRAP,
              domain='Tiny generic-alias visibility control only; no Candidate A execution or solver; actualDispatchBase=' + d['actualDispatchBase'])
out = CONTROL / stage
result = json.loads((out / 'result.json').read_text())
err = (out / 'stderr.txt').read_text()
output = out / ('input.qnt.json' if compiling else 'stdout.txt')
expected_code = 1 if stage == 'original-compile' else 0
checks = {'expectedExit': code == expected_code,
          'noTimeout': result['timedOut'] is False,
          'runtimeStable': result['runtimeUnchanged'] is True,
          'sourceStable': result['sourceAndToolsUnchanged'] is True,
          'originalPilotPinsStable': all(sha(e['path']) == e['sha256'] for e in prior['pins'])}
if stage == 'original-compile':
    diagnostics = re.findall(r'Error \[(QNT[0-9]+)\]: ([^\n]+)', err)
    checks['actualMissingKeyOnly'] = bool(diagnostics) and all(
        code == 'QNT404' and message == "Type alias 'Key' not found" for code, message in diagnostics)
    checks['nameResolutionFailed'] = 'error: name resolution failed' in err
    checks['emptyCompileOutput'] = output.stat().st_size == 0
else:
    checks['emptyStderr'] = err == ''
if stage == 'direct-compile':
    try:
        document = json.loads(output.read_text())
        checks['validGeneratedJSON'] = isinstance(document, dict) and bool(document)
        checks['measuredGeneratedBytes'] = result['generated']['bytes'] == output.stat().st_size > 0
    except (ValueError, KeyError):
        checks['validGeneratedJSON'] = False
ok = all(checks.values())
write(out / 'control-validation.json', {'ok': ok, 'checks': checks,
      'classification': 'Frontend visibility control; not semantic RED or H1 result',
      'actualDispatchBase': d['actualDispatchBase'], 'runtimeBootstrapBase': BOOTSTRAP,
      'parentArgv': sys.orig_argv, 'parentBytecodeDisabled': sys.dont_write_bytecode,
      'parentCachePrefix': sys.pycache_prefix, 'actualCommandExitCode': code,
      'dispatchSha256': sha(dispatch_path)})
raise SystemExit(0 if ok else 1)
