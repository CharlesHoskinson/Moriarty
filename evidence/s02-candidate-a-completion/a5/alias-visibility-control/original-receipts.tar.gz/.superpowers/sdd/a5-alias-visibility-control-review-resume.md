# Independent resumed review: A5 alias visibility control

Reviewed plan: `.superpowers/sdd/a5-alias-visibility-control-plan.md`

Plan SHA256: `fef9ccbb68a3011d3ee76218eb7d0341d2a81e8e7825f5e619fbd5f84b8adcef`

Review scope: read-only review of the proposed isolated four-command compiler
control. This is a native independent review, not a Council verdict. No control
command, simulation, checker, or solver was executed by this reviewer. No model
or runtime was modified. The control remains specified-only at this review.

**Spec verdict: PASS. Quality verdict: PASS. Concrete blockers: none found.**

Repository observation: the plan's original control instantiates `Box[int]`
whose defining body contains unqualified `Key`, while the driver imports only
`Box`. The corrected driver changes only its module name and adds the direct
single-name `Key` import. State, actions, invariant, generic body and original
files remain unchanged. The four required outcomes distinguish the proposed
compile-stage visibility failure from parser, typecheck, timeout or solver
failures.

Repository observation: the inspected installed `TypeApplicationResolver`
expands the parameterized body; `compile()` performs another import/name
resolution before flattening; name copying excludes hidden definitions. This
supports the hypothesis represented by the tiny control. It does not establish
that the actual-model remedy succeeds.

Repository observation: the proposed recorder reuses the unchanged helper and
retains exclusive stage directories, frozen source/runtime pins, original failed
pilot artifacts, previous control stages, raw child exits and resource limits.
The expected original compiler exit 1 remains distinct from wrapper exit 0.
The plan requires root intake after the original terminal pair and before the
corrected driver is created.

Recommendations for root intake:

- Inspect generated module/init/step/safety declarations, as AV004 requires;
  valid JSON alone does not establish that the intended declarations compiled.
- Explain in the control report that the unchanged helper's inherited pilot
  fairness/deadlock/classification text does not describe this compiler control.
- Limit any successful conclusion to reproduction and removal of the tiny
  alias-visibility failure. Actual-model repair, semantic execution and H1 remain
  untested by these commands.

Inspected evidence: repository `AGENTS.md`, `WIKI_SCHEMA.md`, `wiki/index.md`,
the plan identified above,
`evidence/s02-candidate-a-completion/a5/pilot-compile-stop/review.md`,
`scripts/run_s02_candidate_a_factoring_pilot.py`, and installed compiler files
`types/typeApplicationResolution.js`, `cliCommands.js`, and `names/base.js`.

Root-reported observation, not independently rerun by this reviewer: root
revalidated the preserved pilot's 83-member original archive and both pilot
audit scripts. This report does not substitute for those retained audit results.
