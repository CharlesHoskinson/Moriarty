# Independent AV004 terminal intake

**Spec verdict: PASS. Quality verdict: PASS. Concrete blockers: none found.**

Scope: the four-command isolated generic-alias frontend control only. This is
a native independent review, not Council. The reviewer inspected retained
outputs and ran read-only Python archive/index consistency checks; no compiler,
simulation, checker, or solver was rerun. No actual-model remedy was reviewed.

Reviewed artifact SHA256 bindings:

| Artifact | SHA256 |
| --- | --- |
| `.superpowers/sdd/a5-alias-visibility-control-plan.md` | `fef9ccbb68a3011d3ee76218eb7d0341d2a81e8e7825f5e619fbd5f84b8adcef` |
| Control `report.md` | `07a5cb9d25bd60f0eb8d6f888469c0b117c7c94a80ddfa4004ffaa1009e4da11` |
| Control `original-file-hash-index.json` | `7dc430fd098e7fded8ebac492cfbda9d486ffa863802bf830e21ef330e563fde` |
| `evidence/s02-candidate-a-completion/a5/alias-visibility-control/audit.py` | `c3a50ea684f30db7e4051f3ce6054551dd8b74f55b41245ddffe969e4c808b54` |
| Control `direct-compile/input.qnt.json` | `fd8e96c2ced2081dd5635ae8a42916e831895ae40fb5adb49d18b9189d6173c5` |

The control directory is
`.superpowers/sdd/a5-factoring-receipts/alias-visibility-control/`.

Experiment observation from retained receipts: original typecheck, original
compile, direct typecheck and direct compile have child exits 0, 1, 0 and 0.
All four wrappers terminate with exit 0 because they accept the required child
outcome. No stage reports timeout or source/runtime movement. Original compile
stderr contains the single QNT404 missing `Key` diagnostic at `generic.qnt:3:23`
and `error: name resolution failed`; its output is empty. Direct compile retains
16,540 bytes of JSON. The report accurately distinguishes these outcomes.

Repository observation: direct inspection of the complete driver diff found
only the module-name change and direct `import keys.Key from "./keys"` addition.
The state, type alias, init, step and safety bodies are identical.

Experiment observation from raw generated JSON: the sole module and `main` are
`alias_visibility_direct`. Its declarations are `Concrete`, `box`, `init`,
`step`, `safety`, `q::init`, `q::step`, and `q::inv`. `Concrete` and the variable
type contain `key.id: int` and `value: int`. The complete init expression assigns
`{key: {id: 0}, value: 0}` to `box`; the step assigns `box` to itself. The complete
safety expression compares `box.key.id` and `box.value` to integer zero with
conjunction. `q::init` and `q::step` reference those actions; `q::inv` is the val
`and(safety)`. Errors and warnings are empty. These are inspected compilation
outputs, not observations of semantic execution.

Repository observation from independent read-only checks: the author's index
contains exactly all 47 control files other than itself, with matching sizes
and SHA256 values. The four source archives have exactly 83, 93, 104 and 114
members. For each archive, its member set equals all repository-local input
pins, and every member is a regular file whose bytes match its pin. Thus this
check establishes archive completeness as well as integrity for that closure.
Every outer terminal record ends in wrapper exit 0, and its emitted result
matches the corresponding retained result JSON field by field.

Repository observation: root's audit source checks planned source/recorder
bytes, dispatch, stage outcomes, live input pins, archive member hashes, output
hashes, resource bounds, missing-Key diagnostics and generated declaration
structure. No material mismatch was found. Its inner init/safety checks are
structural rather than full expression equality; this review's independent raw
inspection above covers the complete bodies for these retained outputs. This
review does not claim that the audit alone proves those bodies for arbitrary
future outputs. Root reported its audit passing; this reviewer did not rerun
that script or the shared runtime inventory verification.

Repository observation: the author report explicitly scopes the unchanged
helper's inherited fairness/deadlock/pilot metadata as inapplicable to this
control and identifies reused shared runtime/Python archive references. No
replacement environment archive is required by this handoff.

Inference: the retained control reproduces and removes the tiny frontend
alias-visibility failure through the direct import under the planned bounds.
It supports the proposed mechanism, but establishes neither an actual-model
repair nor semantic correctness, model-checker acceptance, H1, or Council
approval. The separate root preservation archive being prepared is outside
this intake; its integrity must be established by its own preservation audit.
