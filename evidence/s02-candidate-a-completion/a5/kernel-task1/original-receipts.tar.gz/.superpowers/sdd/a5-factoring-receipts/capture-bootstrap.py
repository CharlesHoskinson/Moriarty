from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import tarfile
import time

root = Path('/home/charl/Moriarty/.worktrees/s01-audit-start')
out = root / '.superpowers/sdd/a5-factoring-receipts/bootstrap-command'
out.mkdir(parents=True, exist_ok=False)
base = '900bb2051225b4a3d99bf422c3b2e5e386e3e7bc'
argv = ['/home/charl/Moriarty/.venv/bin/python', 'scripts/run_s02_candidate_a_factoring_pilot.py', 'bootstrap', base]
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == base
paths = [root/'scripts/derive_s02_candidate_a_factored.py', root/'scripts/run_s02_candidate_a_factoring_pilot.py',
    root/'specs/quint/s02/factored_verification/candidate_a_joint_f.qnt',
    root/'specs/quint/s02/factored_verification/candidate_a_joint_f_test.qnt',
    root/'docs/superpowers/plans/2026-09-05-candidate-a-factored-verification.md',
    root/'.superpowers/sdd/a5-kernel-task1-brief.md', Path(__file__).resolve()]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins = [{'path':str(p),'sha256':sha(p)} for p in paths]
with tarfile.open(out/'source.tar.gz','x:gz') as archive:
    for p in paths:
        archive.add(p,arcname=str(p.relative_to(root)),recursive=False)
(out/'input.json').write_text(json.dumps({'argv':argv,'cwd':str(root),'beforeDispatchCommit':base,
    'wallSeconds':900,'pins':pins,'sourceArchiveSha256':sha(out/'source.tar.gz')},indent=2)+'\n')
started = time.monotonic()
timed_out = False
env = dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPYCACHEPREFIX=str(out/'fresh-python-cache'))
with (out/'stdout.txt').open('xb') as stdout, (out/'stderr.txt').open('xb') as stderr:
    proc = subprocess.Popen(argv,cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
    try:
        code = proc.wait(timeout=900)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(proc.pid,signal.SIGTERM)
        try:
            code = proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL)
            code = proc.wait()
result = {'exitCode':code,'timedOut':timed_out,'durationSeconds':time.monotonic()-started,
    'sourceUnchanged':all(sha(p['path'])==p['sha256'] for p in pins),
    'stdoutSha256':sha(out/'stdout.txt'),'stderrSha256':sha(out/'stderr.txt')}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
print((out/'stdout.txt').read_text(),flush=True)
print((out/'stderr.txt').read_text(),flush=True)
raise SystemExit(124 if timed_out else code)
