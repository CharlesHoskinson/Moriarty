# A5 bootstrap and kernel Task1 handoff

Status: bootstrap completed and independently admitted by root; compiling behavioral RED captured; corrected recursive typecheck and all six kernel tests passed. Awaiting root Task1 admission. No Task2 derivation, pilot, checker, frozen-source edits, or commits performed.

The adopted plan and actual before-dispatch base are commit `900bb2051225b4a3d99bf422c3b2e5e386e3e7bc`; plan SHA256 is `fe96c2343c369e9170952c04cfb847fc826d706a8f0ad6818efc283f37615563`. Per-command `sourceCommit` records subsequent root commits separately; it does not replace the dispatch base.

## Runtime provenance

Shared store: `.superpowers/sdd/a5-factoring-receipts/tool-store/`.

- `manifest.json`: `fa3e9838c66480557ed6d928a2d159ebc074d05f67f15ef08ab20388d9c49e0b`.
- `runtime.tar.gz`: `f0687656d30c0d59ece8dfd027508a9228020506d29b97aea3abe7568186c31c`.
- Retains 4758 runtime files, including actual Node, Quint package/import closure, Rust evaluator, and bounded Java/native runtime dependencies. Reuses the existing admitted 3329-file Python snapshot without duplicating it.
- Reused Python manifest: `.superpowers/sdd/a4-checker-task1-receipts/python-environment.json`, SHA256 `cd004057c4067bf7cc536d2cec5038add88d0852c1a7de5030e402ff2204f9c4`; archive SHA256 `7363d106d464f976af2a0e7f1f56e3c7bed237c7a3396a60d073369add068dac`.
- Actual Node is `/home/charl/.foreman/tools/fnm/node-versions/v24.18.1/installation/bin/node`, used directly with the pinned Quint CLI. This installed executable path does not indicate Foreman execution.
- Version evidence includes Node 24.18.1, Quint 0.32.0, Python 3.13.14, Java, package metadata, and the Rust evaluator's unsupported `--version` exit 1. Rust executable bytes are pinned independently.

Bootstrap receipt directory `bootstrap-command` retains original sources, argv, separate streams, and terminal metadata. Exit 0, duration 66.34382718300913 seconds, source unchanged. Root independently audited runtime/Python archive members, current bytes, tree membership, versions, and bootstrap closure before admitting producer reuse.

## Commands and terminal outcomes

All command stages are under `.superpowers/sdd/a5-factoring-receipts/`. Each retains `input.json`, `result.json`, separate complete stdout/stderr, resource output, and its original 38-file `source-and-runner.tar.gz`. Requested commands below use `ENTRY=specs/quint/s02/factored_verification/candidate_a_joint_f_test.qnt`; recorded argv contains the absolute entry and actual Node/CLI paths. Each command had a 1200-second wall limit and 4096 MiB Node heap limit. No command timed out. Depth 0 is recorder metadata, not a model-checking bound or proof claim.

| Stage | Requested command | Exit | Wall seconds |
| --- | --- | --- | --- |
| kernel-red-typecheck | `quint typecheck ENTRY` | 0 | 138.25258077199396 |
| kernel-red-test | `quint test ENTRY --backend=rust --seed=42 --match suppliedResultRejectedTest` | 1 | 134.57961449299182 |
| kernel-green-typecheck | `quint typecheck ENTRY` | 0 | 145.8253545040061 |
| kernel-green-tests | `quint test ENTRY --backend=rust --seed=42 --match '.*Test'` | 0 | 156.9268277240044 |

Every stage reports `runtimeUnchanged: true` and `sourceAndToolsUnchanged: true`. All jobs reached terminal status; none remains active. GREEN typecheck and runtime were independent read-only jobs on the same frozen corrected closure.

RED was an actual QNT508 assertion failure in `suppliedResultRejectedTest`, after recursive typecheck succeeded. It was not a syntax/type diagnostic. Original RED source and output were archived before correction. The sole source correction was:

```diff
-      | TransactionComputedA(actual) => joint.extraction
+      | TransactionComputedA(actual) => if (supplied != actual) EffectResultMismatchA else joint.extraction
```

All 38 members of each command source archive were compared with current files after GREEN: only this kernel differs in each RED archive; every GREEN member matches. Tests, scripts, and all 34 original/common files stayed identical. Original RED kernel SHA256: `d4732b6b00e22462f6e4046df3a67ee1b90a53d9b1ca7290ddf8ccd4887e4ff2`.

Archive SHA256 values, in stage order above:

```text
e740b9907a7774552c18cc92e86a57371ee8ab8b4ab1754645c62661028deafe
2632b60581825a77a3ae38c856e16b2984af955c3a35f430aea3b8a39f8ed414
6f50f0616e43432d45d7a34397dc03bd4765e8c710ba8b7587b649295bb70ea4
a3c97e7fd2b0619195c65c9aac9cea229b7777dc06531f67a81af3c6234d2a14
```

GREEN output reports `6 passing (12973ms)`, with no exclusions: `completeCorpusTest`, `suppliedResultRejectedTest`, `orderedEffectsLiteralTest`, `malformedBeforeMismatchTest`, `timeoutRollbackLiteralTest`, and `authorityCorpusTest`. GREEN stdout SHA256 is `935888541102600406a1291f537b316193a2c099e3295ab534ff0ac1758e23a2`; stderr is empty. The focused RED stdout/stderr hashes are `421ffec25198ce74e5c76e767efef932ef673e49c2d5653ba91440330554e559` / `7880f94b001f34e172927175c742d4d8f3b7fafcfeb74def8d48056c0e134ba2`.

## Frozen owned source

| File | SHA256 |
| --- | --- |
| `scripts/derive_s02_candidate_a_factored.py` | `c3d7935787df233c29247e1ace49081cd7eada4397cf6d392e4fbecb27df6a52` |
| `scripts/run_s02_candidate_a_factoring_pilot.py` | `816c3ad79dc3a67ca9a03729af56d74188c161a7546b9c43e821c222a4bce7f2` |
| `specs/quint/s02/factored_verification/candidate_a_joint_f.qnt` | `0d45fd00855c0518d1682970bc7c78526212ae64b54f44b701e8c575caa8dcfe` |
| `specs/quint/s02/factored_verification/candidate_a_joint_f_test.qnt` | `130b59a06da52c315e9980c77d7af86f76084984ed99a47970b3ab368543f403` |

The six finite kernel tests support only Task1's specified raw/effect/diagnostic comparisons. They do not establish unrestricted interleaving equivalence, full-corpus derived-lifecycle correspondence, pilot resource improvement, or completion of A5. Those adopted later obligations remain gated. Other agents' worktree changes were preserved.
