# A5 bootstrap and kernel Task1 execution

Plan adopted900bb2051225b4a3d99bf422c3b2e5e386e3e7bc. Exact plan SHA256
fe96c2343c369e9170952c04cfb847fc826d706a8f0ad6818efc283f37615563.
Root completed full branch/derivation/pilot/recorder review. Execute pre-Task1
bootstrap and Task1 only. Root will not commit again until your bootstrap records
this exact before-dispatch HEAD. Notify root when shared snapshot is ready for
independent admission; producer may not consume an unadmitted store.

Own scripts/derive_s02_candidate_a_factored.py,
scripts/run_s02_candidate_a_factoring_pilot.py, and the two files
specs/quint/s02/factored_verification/candidate_a_joint_f.qnt and
candidate_a_joint_f_test.qnt. All frozen common/A/lifecycle files remain exact.
Own ignored .superpowers/sdd/a5-factoring-receipts/ shared store and Task1 stages,
and .superpowers/sdd/a5-kernel-task1-report.md. Preserve all other agent files.

Bootstrap is sole owner of new shared runtime store. Reuse the admitted Python
snapshot, never duplicate it. Apply the full recorder/derivation blocks from the
adopted plan. Do not invoke derivation to create Task2 models. Preserve failed
bootstrap outputs, do not overwrite existing stage directories. If tools differ,
stop and report exact evidence before considering any change. No installations.

Write tests first, add kernel with the prescribed missing full supplied-result
comparison. Require actual recursive typecheck0 and suppliedResultRejectedTest
assertion failure, then restore only the comparison and require recursive
typecheck0/all6testsGREEN. Preserve original source/runtime closures, argv,
separate streams, elapsed resources and actual terminal outcomes. Parse/type
errors are diagnostic only and must not replace the behavioral RED. Report
unexpected semantics/type incompatibility instead of weakening equality.

Keep ownership of every live command; poll the existing handle, do not duplicate
jobs, and report status promptly. No Task2/corpus derivation or Task3 compilation,
simulation/checker pilot, extra heap, alternate models, main/wiki/DB/evidence
integration, index/commit or Foreman work. Root owns review/admission after Task1.
