FAILED capability gate

Independent original evidence-preservation review: PASS. The planned tiny capability gate failed and is not admitted. No full dispatch, relaxed predicate, native replay, semantic acceptance, solver readiness, or H1 conclusion follows.

The authentic compiler, integrated recorder, RH002 time-wrapped child, RH002 return, and outer tool all exited 0. RH002 eligible=true, timed_out=false, and cleanup completed without forced signals or errors. The actual native transport is two exact responses: launch b637fc/session46237 and terminal 92b92b/0 (root cell390). PGID3518157 and all predecessor groups in the frozen slot were absent during this read-only audit. No missing native terminal metadata was found in the retained response objects. NF005 separately returned actual chunk2a1216/exit2 and recorded RuntimeError `retained Concrete=Box[int]`.

Original compiler stdout is 13,904 bytes, SHA256 `4638a8d77df74903912b7e023375116b5fdcbf62ea45cfd42246a8b9b1955ff2`. Strict JSON parsing found the exact eight serializer fields, one `alias_visibility_direct` module, ten declarations, two retained imports (`generic.Box`, `keys.Key`), and generated `q::init`, `q::step`, and `q::inv` selections. Compiler stderr is empty. Concrete is already a record whose key field is the const `Key` and value field is int; it is not the required generic application `Box[int]`. The variable annotation remains `Concrete`; direct init/step/safety bodies match the earlier flattened control after removing id/depth metadata. The record differs from that earlier fully flattened record because Key remains a const. These are additional data observations, not a replacement gate. Original NF005 stopped at its first failed Concrete predicate; later predicates were not recorded as executed by that command.

The authentic invocation is the frozen Node/CLI compile command, with `--flatten=false`, JSON target, main alias_visibility_direct, safety invariant, verbosity0, and explicit 4096 MiB Node old-space setting. RH002's120-second limit covers the recorder setup, four version probes, snapshots, and native child. GNU-time 0:04.40, user2.47s, system2.12s, and maximum RSS380,056 KiB measure that whole invocation. They are not compiler-only timings or a4GiB RSS cap. No simulation or semantic invariant check occurred.

The main independent audit (actual31d987/0) checked215 fixed source pins plus15 distinct dynamic pins (230 total); both exact230-member source archives; the separate one-member dispatch archive and its prerequisite seal; all484 source copies across root before/after and inner before/after; all121 integrated sources and current pins; the24 immutable A5 view copies,30 original derivation pins, and exactly two reversible adapter import additions. Every original source used to compare a view, including the three corrected pilot-root support pins, is in the frozen union.

It also hashed every one of the8,102 runtime pins, including both external runtime archives, and checked exact membership of all four runtime trees. Supplemental data audit1fa1ac/0 reconstructed the8,102 expected runtime pins from the original manifests/references, checked the104-Quint/17-Python recursive source closure, helper-copy byte identity, and all746 indexed originals again. All root/inner source and runtime endpoint maps agree. These observations establish endpoint agreement, not continuous historical immutability.

Actual adopted plan SHA256 is `79325d985b5f58a62a5f490b0ac51f60c873afcb36775be3d95e372d144b2260`; its independent re-review is `f0b40bf0d507cc177905c70e9f2ca5c7128a0beabb1774a3c6ecfaf9dfac4e7c`. Root dispatch and all source endpoints record HEAD `2a33b45f647c4ada426ff840bc9033cbbe913bfa`, distinct from the unchanged historical producer/bootstrap references. Data-only command-source comparison7bcf91/0 matched both151-line endpoint command bodies,63-line dispatch,29-line prelaunch, and210-line intake exactly to their complete adopted plan blocks. Retained original data responses include before e945be/session21266 then8c07bf/0; after cc3343/session28935 then9af3ae/0; dispatch72128d/0; prelaunchc22e80/0; intake2a1216/2. The original argv, streams, raw resources, response metadata, and failed intake remain unchanged.

The complete746-original index is `.superpowers/sdd/a5-no-flatten-tiny-independent-index-20260906.json`, SHA256 `a0310464e1382cfe0786012af951bb37c86e0a17d5825d21d72cfb4eff89d69e`. Exact independent audit arguments and returned objects are retained in `.superpowers/sdd/a5-no-flatten-tiny-independent-tool-receipt-20260906.json`, SHA256 `59fffd9211f2d4a2117f2217b96d93039ecbfad4fa3ddfdaee0e113626718324`. This also discloses a reviewer JavaScript encoding failure before any proposed file write or child execution; the actual data audit then passed on its first execution. No project/helper/archived code was imported or executed by this independent review.

Key original hashes:
- Before endpoint: `3ea882dcc3360eb51ee5980656cf5c92c8e88610c02fce803c70137ee9eb461b`.
- After endpoint: `5dc0560aa08b252d6b8965d3e51272c53f347ec158329b2c03f82dc4a943dca2`.
- Before source archive: `0901deff476ad61ccf2cfcbec13ec02cfbf09629ccb9b6639bbcd4d329a1cb43`.
- After source archive: `8a53220c5164179fd2d2541f0f6e1b46511e5e95989d93311afdc8406d3e59a4`.
- Root dispatch: `753148dce6406cffca02fa6e06af681a71dfed4b6b9ca40e7403e5c2e380006e`.
- Inner receipt: `c03d9b9eeb1d66f593599b244e9d22b7f8057255f53ea77b1d1e3a4f18c8d5da`.
- RH002 terminal: `4cb71a7bc7eb26233356d99aa996fe407744048977a8e7c43e8808865be04733`.
- Actual transport terminal: `63380ebb5126e655347317b309528e90198eeeade158ec2823a6910eb773a47a`.
- Failed planned intake: `2c39b46364d588dbe78f1505a657f5df003051b8a59ad67c411193becd44a988`.

No root tiny admission, full dispatch, or full outer stage existed at audit time. Compiler acceptance remains false and H1 unresolved. The original tiny slot is consumed; any further diagnostic requires a separate source decision and reviewed exact plan.

