# No-flatten tiny: type-application predicate diagnosis

Status: source-backed diagnosis and proposed **retained-data-only** correction. No compiler, helper, plan body, corrected intake or native command was executed for this report. No frozen plan, source, model, runtime or original receipt was edited. The systematic-debugging skill supplied the source/data tracing workflow; the delegated scope excludes reproduction or implementation runs.

The native tiny command returned0, but original NF005 stopped at its first failed predicate, `retained Concrete=Box[int]`. The original failed intake remains `.superpowers/sdd/a5-no-flatten-diagnostic-20260906/tiny-intake.json`,81,784 bytes, SHA256 `2c39b46364d588dbe78f1505a657f5df003051b8a59ad67c411193becd44a988`, capabilityOrFullSuccess=false. Root reports actual NF005 tool2a1216/exit2. That failure is authentic and is not overwritten. Predicates after that point were not completed by the original NF005 execution.

## Source cause

`--flatten=false` skips full module/alias flattening; it does not preserve parser-stage generic type applications. The reviewed plan and this reviewer's earlier plan review missed the preceding analyzer transformation.

1. Installed `cli.js:118–124` chains load, parse, typecheck, compile and output. `cliCommands.js:162–172` calls `analyzeModules(table, modules)` during typecheck, before compile sees the flatten option.
2. `quintAnalyzer.js:27–31` constructs an analyzer and replaces each module's declarations with `analyzeDeclarations`' returned declarations. Its constructor instantiates TypeApplicationResolver (`:63–64`), and `analyzeDeclarations` calls resolveTypeApplications before type inference (`:72–75`), returning the resolved declarations (`:93`). Thus the original module object returned by later no-flatten compilation is already analyzed/transformed.
3. `types/typeApplicationResolution.js:28–46` transforms both lookup definitions and declarations. Its type traversal resolves kind `app` (`:56–59`). It finds the constructor typedef in the lookup table, freshens its parameters and substitutes actual arguments (`:61–116,130–140`). For the frozen source `type Box[a] = {key: Key, value: a}`, applying Box[int] therefore yields `{key: Key, value: int}`.
4. `types/substitutions.js:37–100` substitutes type variables recursively through records/rows but returns `const` types unchanged (`:89–94`). `Key` here is the named field type of the Box body, not its actual generic argument; it remains a named constant. `box: Concrete` likewise remains a named annotation on this route.
5. `cliCommands.js:401–445` adds default selections, repeats resolution and incremental analysis, then returns before flattenModules for boolean flatten=false with JSON target. With flattening enabled, `flattening/fullFlattener.js:44–50` invokes inlineTypeAliases; `types/aliasInliner.js:30–42,115–122` recursively resolves named typedefs. This accounts for the old flattened Key record and expanded Concrete variable annotation. No internal timing or cost attribution follows.

Exact selected runtime pins, checked against the admitted tool-store manifest `fa3e9838c66480557ed6d928a2d159ebc074d05f67f15ef08ab20388d9c49e0b` without runtime execution:

| Under installed Quint package | SHA256 |
| --- | --- |
| `dist/src/cli.js` | `ac12595b1cb7253feec93c79417615c6eb20fc3b6a3df35c5e3530b24e90a501` |
| `dist/src/cliCommands.js` | `b18672d656782aefde254fe1021dc13fdffdcf8f4ad8709e3126fb5fa293362a` |
| `dist/src/quintAnalyzer.js` | `fd53e14aafb5b2e6c5846eddc8ef9f175b76a53b55fa187c0a519706472b512a` |
| `dist/src/types/typeApplicationResolution.js` | `7a48a13ecabdfdb0e46b7a68581c5fcfd558adb37f067127753eddf8b40d2535` |
| `dist/src/types/substitutions.js` | `6a26f0742bb6dc8e465e837c0c6cb99ad4ed487d49c161f13163bcb0a022c0c1` |
| `dist/src/types/aliasInliner.js` | `dbdbc0c1952ce5d5cf275862457498ab2539c995c3d51743ae5082f7af897428` |
| `dist/src/ir/IRTransformer.js` | `47251acd2fcc7710deca82d8d97c79ad77e998be1413c1f1608b5c700a123d31` |
| `dist/src/flattening/fullFlattener.js` | `91bb56f07bb49ed354617f2307fa7949921e224a0be300c4fc397e894b071a1b` |

The frozen direct driver remains `5f786022cef03df2ec4daa9cf83a1d0350079d7f131cfa4a3926c972f2b6a386`, generic.qnt `e20cc1a40213b5fdd7d429709e8dd4e671580838ed302d440c2dd0e23f07c1e8`, keys.qnt `14ae188b68e357c311a334b48b45aadfee24293bb7f855dbaea27e25d17187c7`. This is a wrong acceptance expectation, not evidence that these source files or the no-flatten switch changed unexpectedly.

## Narrow original-data comparison

Actual standard-library comparison86e22c/exit0 read the two original JSON outputs only. The new raw stdout is13,904 bytes, SHA256 `4638a8d77df74903912b7e023375116b5fdcbf62ea45cfd42246a8b9b1955ff2`; old `.superpowers/sdd/a5-factoring-receipts/alias-visibility-control/direct-compile/input.qnt.json` is16,540 bytes, SHA256 `fd8e96c2ced2081dd5635ae8a42916e831895ae40fb5adb49d18b9189d6173c5`.

| Property after removing only id/depth annotations | New no-flatten original | Old flattened original |
| --- | --- | --- |
| Concrete | record `{key: Key, value: int}` | record `{key: {id: int}, value: int}` |
| box annotation | named constant Concrete | expanded Concrete record above |
| Imports | exact generic.Box and keys.Key imports retained | none |
| Top-level declarations |10 |8 |
| init/step/safety and q::init/q::step/q::inv bodies | exactly equal to the old normalized bodies | exactly equal to the new normalized bodies |

These finite observed structures match the source transformation above. This comparison is not full receipt admission, compiler equivalence or a successful corrected intake; another reviewer owns the complete original evidence intake. No statement about a future full-view output is established by this tiny data.

## Proposed bounded corrected intake

A separate reviewed data-only intake is justified. Preserve original plan SHA256 `79325d985b5f58a62a5f490b0ac51f60c873afcb36775be3d95e372d144b2260` at its current path and in all original before/after archives. Do not edit it. Preserve original tiny-intake and its actual failed tool response. The new file is exclusively `.superpowers/sdd/a5-no-flatten-diagnostic-20260906/tiny-retained-type-application-intake.json`; no existing receipt or archive is an output.

The exact future command below extracts only original NF005 from the hash-pinned plan and executes its data-only body. It keeps every original predicate except the source-disproved Concrete=Box[int] shape, replacing that with the exact resolved record retaining Key. It additionally tightens the old Concrete/box comparison to the exact fully expanded shape. Only output path/provenance metadata are otherwise changed. The original128MiB/strict JSON/whole receipt/source/runtime/archive/cleanup/argv/stream/import/action/default-selection checks remain. The only project-source import remains original NF005's pinned RH002 parse_resource data parser; no recorder main, compiler or runtime verifier is called. Any prerequisite failure aborts, and any original intake predicate failure produces a failed fresh intake/exit2. Existing raw files are pinned before and after even if the data body raises.

This command is proposed for review, **not executed here**:

```sh
env -u PYTHONPATH -u PYTHONHOME -u PYTHONSTARTUP -u PYTHONINSPECT -u PYTHONOPTIMIZE -u PYTEST_ADDOPTS -u PYTEST_PLUGINS -u NODE_PATH -u NODE_OPTIONS -u NODE_COMPILE_CACHE -u LD_PRELOAD -u LD_LIBRARY_PATH -u JAVA_TOOL_OPTIONS -u _JAVA_OPTIONS -u JDK_JAVA_OPTIONS PYTHONOPTIMIZE=0 PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 LC_ALL=C PATH=/usr/lib/jvm/java-25-openjdk-amd64/bin:/home/charl/.foreman/tools/fnm/node-versions/v24.18.1/installation/bin:/home/charl/.npm-global/bin:/usr/bin:/bin JVM_ARGS=-Xmx4096m JVM_GC_ARGS='-XX:+UseG1GC -XX:G1PeriodicGCInterval=600000 -XX:+G1PeriodicGCInvokesConcurrent' APALACHE_JAR=/home/charl/.quint/apalache-dist-0.56.1/apalache/lib/apalache.jar NF_MODE=tiny /home/charl/Moriarty/.venv/bin/python -B - <<'PY'
from pathlib import Path
import ast, hashlib, json, re, sys
R=Path('/home/charl/Moriarty/.worktrees/s01-audit-start')
M=R/'.superpowers/sdd/a5-no-flatten-diagnostic-20260906'
plan=R/'docs/superpowers/plans/2026-09-06-candidate-a-no-flatten-diagnostic.md'
failed=M/'tiny-intake.json'
fresh=M/'tiny-retained-type-application-intake.json'
def require(ok,message):
    if not ok:raise RuntimeError(message)
require(sys.flags.optimize==0 and sys.dont_write_bytecode,'optimization zero and -B')
require(not fresh.exists(),'exclusive fresh retained-data intake')
pins={
    plan:'79325d985b5f58a62a5f490b0ac51f60c873afcb36775be3d95e372d144b2260',
    failed:'2c39b46364d588dbe78f1505a657f5df003051b8a59ad67c411193becd44a988',
    R/'.superpowers/sdd/a4-producer-receipts/a5-noflat-tiny-20260906/stdout.bin':'4638a8d77df74903912b7e023375116b5fdcbf62ea45cfd42246a8b9b1955ff2',
    R/'.superpowers/sdd/a5-factoring-receipts/alias-visibility-control/direct-compile/input.qnt.json':'fd8e96c2ced2081dd5635ae8a42916e831895ae40fb5adb49d18b9189d6173c5',
}
def check_pins():
    for p,h in pins.items():
        require(p.is_file() and not p.is_symlink(),'regular retained original')
        with p.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
        require(actual==h,'retained original changed: '+str(p))
check_pins()
prior=json.loads(failed.read_bytes())
require(prior['mode']=='tiny' and prior['capabilityOrFullSuccess'] is False and
        prior['validationErrors']==[{'message':'retained Concrete=Box[int]','type':'RuntimeError'}],
        'exact original failed predicate preserved')
text=plan.read_text()
section=text.split('## Task NF005: Strict data-only artifact intake after actual terminal and cleanup',1)[1].split('## Task NF006:',1)[0]
blocks=re.findall(r'^```python\n(.*?)^```$',section,re.S|re.M)
require(len(blocks)==1,'one exact original NF005 block')
body=blocks[0]
def record_type(fields):
    return {'kind':'rec','fields':{'kind':'row','fields':[{'fieldName':n,'fieldType':t} for n,t in fields],'other':{'kind':'empty'}}}
new_type=record_type([('key',{'kind':'const','name':'Key'}),('value',{'kind':'int'})])
old_type=record_type([('key',record_type([('id',{'kind':'int'})])),('value',{'kind':'int'})])
original="        require(strip_ids(names['Concrete'])=={'kind':'typedef','name':'Concrete','type':{'kind':'app','ctor':{'kind':'const','name':'Box'},'args':[{'kind':'int'}]}},'retained Concrete=Box[int]')"
corrected="        require(strip_ids(names['Concrete'])=="+repr({'kind':'typedef','name':'Concrete','type':new_type})+",'typecheck-resolved Concrete retains Key constant')"
old_comparison="        require(all(x['kind']!='import' for x in flat) and flat_names['Concrete']['type']['kind']=='rec','admitted flattened representation differs')"
tighter=old_comparison+"\n        require(strip_ids(flat_names['Concrete'])=="+repr({'kind':'typedef','name':'Concrete','type':old_type})+",'exact old flattened Concrete expands Key')"
tighter+="\n        require(strip_ids(flat_names['box'])=="+repr({'kind':'var','name':'box','typeAnnotation':old_type})+",'exact old flattened variable annotation')"
old_output="path=M/(mode+'-intake.json')"
new_output="result['retainedDataCorrection']="+repr({'originalFailedIntake':{'path':str(failed),'sha256':pins[failed]},'originalPlanSha256':pins[plan],
    'scope':'type-application expectation corrected from pinned source; original failed intake unchanged',
    'nativeRerun':False,'fullDispatchAuthorized':False})+"\npath=M/'tiny-retained-type-application-intake.json'"
for old,new in [(original,corrected),(old_comparison,tighter),(old_output,new_output)]:
    require(body.count(old)==1,'exact unique correction target')
    body=body.replace(old,new,1)
ast.parse(body,filename='<reviewed-retained-tiny-NF005-correction>')
try:
    exec(compile(body,'<reviewed-retained-tiny-NF005-correction>','exec'),{'__name__':'__main__'})
finally:
    check_pins()
PY
```

Root must preserve this command's actual arguments and responses under fresh root-owned transport outside the existing hash-finalized directories, and independently review its output before any new admission. The candidate's capabilityOrFullSuccess may become true only if all retained original checks pass under the corrected predicate. That is a new scoped interpretation, not retrospective success of original NF005.

Original NF003 directly reads `tiny-intake.json` capability=false and original tiny admission is absent. This correction does not change either gate or authorize full. A later full decision would need an explicit separately reviewed supplement binding the fresh corrected intake, preserved failed intake, independent review, actual originals, source/runtime/slot evidence and any adjusted full dispatch/intake contract. No automatic promotion, native rerun or silent change of original plan paths is proposed.

Source lookup note: an initial read command also tried two nonexisting alias-inliner filenames; the actual dependency named by fullFlattener is `types/aliasInliner.js`, which was then read and pinned above. This was read-only path discovery, not an original/native failure.
