# A5 full compiler phase diagnostic: independent original intake

Spec verdict: PASS for the reviewed once-only diagnostic and its stated limits.
Evidence-preservation verdict: PASS. Compiler acceptance: false. H1: unresolved.
Root's final preservation admission and intake remain separate. The full slot
is closed; this report authorizes no retry, compiler, factored run or solver.

Original evidence root:
`.superpowers/sdd/a5-compiler-phase-diagnostic-20260906/`.
Reviewed original `full/` and `transport/full/`, preparation freeze, actual
dispatch and control-adoption records. No original was rewritten.

## Actual outcome and bounded interpretation

The original time-wrapped child exited -15 after the 900-second timeout.
Its owned group was 3430331. Cleanup is explicitly forced and complete:
SIGTERM sent=true, subsequent SIGKILL sent=false, errors empty. The original
monitorError is null and receivedSignals is empty. Finalization is not blocked.
Process-terminal elapsedSeconds is 900.1825834919873, including cleanup.

The recorder exited 0 with finalized=true and error=null. The actual outer
response also exited 0. Those zero exits mean evidence preservation succeeded;
they do not turn the timeout or time-wrapped child signal into compiler success.
The -15 is the recorded GNU-time-wrapped process returncode; a separate Node
exit receipt is not invented.

Original stdout.bin, stderr.bin and resources.txt are each empty. No generated
JSON or complete GNU-time measurements exist. result.json preserves resource
null and `ResourceError: incomplete resource field inventory`. No CPU, RSS,
GNU wall time, alias-resolution success or serialization result is inferred
from those empty files.

The raw trace is 595 bytes with exactly seven records:

| Sequence | Phase | Event | Outcome |
| --- | --- | --- | --- |
| 1 | load | enter | stage |
| 2 | load | resolve | Right |
| 3 | parse | enter | stage |
| 4 | parse | resolve | Right |
| 5 | typecheck | enter | stage |
| 6 | typecheck | resolve | Right |
| 7 | compile | enter | stage |

Independently checked raw JSONL schema with duplicate-key rejection, exact
consecutive sequence, nonnegative decimal monotonic clocks, final newline,
and the 32-record/16-KiB bounds. The raw rows match trace-validation.json and
checks.json. No compile completion, outputCompilationTarget or outputResult
marker exists. There is no observation-failure exit 74 in this invocation.

The supported finding is an incomplete observed public compile interval in
this new invocation. That interval includes observer I/O and promise-reaction
scheduling margins. It does not prove that the original function was executing
at the timeout instant, locate an internal hot spot, identify the historical
timeout's phase, establish arbitrary observer equivalence or resolve H1.
Earlier load/parse/typecheck Right markers are observations of this invocation;
they do not supply an unobserved compiler completion.

## Exact dispatch, argv and predecessor bindings

The actual dispatch, stage and child start HEAD is
`07c3a5462154d45e733d01d8a8bae856cb0f63c4`, also current at this audit.
The freeze's historical view dispatch43f3372 and runtime bootstrap900bb20 remain
separate historical fields. Checked the exact reviewed four executable source
blocks against the unchanged adopted plan SHA256
`b1df377b077cb7189f945ac493039e1f8d941f5076f61c1be6aaf8559de7bff9`.
Freeze SHA256 is
`59a2ce768c0e26683ebec421d7ef091b9c3a8f5894b844ad6f8c57e599d9e405`.

The immutable full invocation restores the exact archived original compile
argv: pinned Node and CLI, original compilation-view funding-pilot entry,
`--main=candidate_a_funding_pilot`, `--target=json`, `--invariant=pilotSafety`,
and `--verbosity=0`. No extra init or step selection is introduced. Its actual
launcher argv, argv.json, execPath, empty execArgv, cwd and measured GNU-time
argv all agree. Parent orig_argv matches the exact admitted Python -B full
recorder invocation. The complete fixed/removed environment entries match the
plan, including Node and JVM 4096-MiB settings. These are heap settings, not a
claim about total RSS.

The separate root dispatch binds one invocation, 900 seconds, the exact inputs,
freeze, both root control adoptions, review and A4 original terminal/outer
receipt. A4 terminal time precedes dispatch, which precedes full stage start.
Both control adoptions retain their original finalized stage pins, authentic
outer response sets, PASS reviews and preparation freeze; these bindings were
independently rechecked. The prior seven mock and four alias lifecycle records
are terminal and clean. Their controls were not rerun here.

Read-only group-existence checks found all 14 referenced groups absent: seven
mock, four alias, two A4 collection/pytest and the full diagnostic group. No
signal was delivered by this reviewer. The current absence observation does
not invent earlier process history; original cleanup records remain primary.

## Complete source, archive, runtime and transport verification

All 16 finalized files inside full/ match their original terminal ownedFiles
pins; the exact file inventory excludes only that terminal itself. No artifact
symlink occurs. The stage has 109 source pins; its original source archive adds
the one immutable invocation for exactly 110 unique regular members. Checked
every archive member name/path, byte length and SHA256 against sourceBytes,
the frozen stage source set and current source pins. Archive SHA256 is
`9261d81d99b2df90c6ebd0465078c940d64301965f791ce405a3f03ace70c947`.

The 24 view copies and all 30 original pins match. Exactly two single import
additions reverse to their original bytes; the remaining copies are identical.
Runtime-before and runtime-after equal the full preparation snapshot. Both
files have SHA256
`6279005c6766ae5780841c03039f71f83790175a88363be2e79e207ac27024ca`.
Checked all 8,083 unique runtime pins against the manifest's 4,758 runtime and
3,329 Python entries, all four tree memberships, and four external reference
pins including the original shared/Python runtime archives. No replacement
runtime was created. Endpoint hashes do not prove continuous historical
immutability.

transport/full retains exactly 91 returned responses from session 86357. Each
response file equals its entry in the original outer terminal's toolResponses
array. The initial command/cwd/exec arguments match the plan. The final actual
response is chunk77d8d8 with exit0 and the original full preservation summary.
Every preceding retained response is nonterminal for the same session. The
outer terminal SHA256 is
`3938090a70a53149dd1c437ee939e05a439f7e1053fcd6aea391f47015b44cc8`.
This full transport is distinct from the earlier alias prelaunch save failure
and the A4 polling-metadata gap; neither is overwritten or relabelled here.

## Audit activity and limits

The standard-library read/hash/archive audit completed in actual tool chunk
1d521a, exit0, with preservation PASS. It checked 8,332 distinct current pin
paths and hashed 1,301,726,880 bytes, with per-file and final cached-stat
stability checks. Those counts precede the separate complete original-file
digest listing below. The complete full-stage and transport file index in
this report is a new audit observation, not a replacement original receipt.

An initial functions.exec orchestration attempt had a JavaScript parse error:
`SyntaxError: Unexpected token '?'`. This happened before any nested audit
exec_command call; no child audit or native invocation was launched by that
failed tool attempt. The later successful audit used a corrected orchestration
string. No audit failure is attributed to an original compiler receipt.

No project recorder/helper was imported or executed, and no compiler, mock,
test, model or solver command ran during this intake. Only this new review
file was written. Root owns the final preservation PASS record and final
intake/index command. Compiler acceptance remains false and H1 unresolved.

## Complete original full/ and transport/full/ file digests

Paths are relative to the diagnostic evidence root. Every original file under
those two directories is listed; this review file is external and excluded.

<!-- original-file-digests -->

| Original file | Bytes | SHA256 |
| --- | ---: | --- |
| full/checks.json | 1578 | `154875625b4c722174736ec4b90c2238656eb10c4fd687549cb462536cad8327` |
| full/full-observed/argv.json | 982 | `9ce51a0e4572a58b6b3cfefddd78d30233fb24431a1575e66841e3d35621ed7a` |
| full/full-observed/process-terminal.json | 477 | `8d00cbc294996d789c7815e5c8590e159f3224a5a27775bcf2283719582f4e35` |
| full/full-observed/process.json | 201 | `0c5f06e8533c1d9060fe65dac7e485f3b107156ec79ef5cd3e599e419aa3dcdf` |
| full/full-observed/resources.txt | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| full/full-observed/result.json | 1006 | `37800eacf975025e10b80d10d7c3ee126838d1fd377f48cc14ff75339e781556` |
| full/full-observed/source.tar.gz | 1111080 | `9261d81d99b2df90c6ebd0465078c940d64301965f791ce405a3f03ace70c947` |
| full/full-observed/start.json | 48065 | `8f8f557c8562af181f90e1946e457cf22bdae1162c717204be5cf2fa8891ccc6` |
| full/full-observed/stderr.bin | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| full/full-observed/stdout.bin | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| full/full-observed/trace-validation.json | 1243 | `cbfde52fa59d5f3290cb635720992bc5107384b42bb935b7aa8dea693d2ca447` |
| full/full-observed/trace.jsonl | 595 | `d3b05f37c9976dfa99a2f34897aced0289060c7278c36517dc06f15f9adee536` |
| full/full-observed-invocation.json | 816 | `64603f0b1fccbcb024f19fab34c62e577eb21fe6e7f546fc1856742dfb69f2d9` |
| full/runtime-after.json | 1910330 | `6279005c6766ae5780841c03039f71f83790175a88363be2e79e207ac27024ca` |
| full/runtime-before.json | 1910330 | `6279005c6766ae5780841c03039f71f83790175a88363be2e79e207ac27024ca` |
| full/start.json | 29092 | `49fb632bc2c8a747cb5da7e2026d9244f8c79c594fd71442e3be28e6b904395b` |
| full/terminal.json | 4982 | `831cfb143987611d83aa2f86fc3959053fc115d9fdac00411ad3859403dd9563` |
| transport/full/command.json | 585 | `74a84cdf579c13a9318b79b1eda9c8d29b76b2200c720af0d03370a188fc4684` |
| transport/full/response-000.json | 131 | `00e0c76096d765bbfe0568a5326ba851800c654743711482e80a70b6dcee5fef` |
| transport/full/response-001.json | 132 | `71f30fd4807d5d732ef0d141454671c331e3c311cd7333a18e4251f4c9373b56` |
| transport/full/response-002.json | 132 | `1f4f3a61d511b6299b63f2e0ff928cb7169dd2b379d9b88cff8f6f836d667b98` |
| transport/full/response-003.json | 131 | `1dc693920b8851015226acc38ec3e5d31cfe52d054384a4c4fa14d0d6bed02fb` |
| transport/full/response-004.json | 132 | `628bbe60be2a71e7f4ba6ae978ea2912ef34bc20f6fff50ee9373ceb64edc957` |
| transport/full/response-005.json | 132 | `414c0ee97865bce1ca2167e79509d072052e91f00557797c001ddc58f6f73de4` |
| transport/full/response-006.json | 132 | `441e09d53953098a9b37ae64fad0cfdf73a6fe338a9cd4905d62e7d46802c7ab` |
| transport/full/response-007.json | 132 | `e3bcde39cb83b50b8ae1e0e0ca2d212688e7229f3c0a350b3d9b0b8d36fc49ff` |
| transport/full/response-008.json | 132 | `568eae7858ebd7539238d4e84a15d9e505a60594525b35ce336154f133431fa1` |
| transport/full/response-009.json | 132 | `dd4b3250c643946c3353e8248c3903c4a6a000d5fafd7cd248968cbd7fc438ab` |
| transport/full/response-010.json | 132 | `5b2e3ea9208b38ffab758ab2f976b6c41cd5175278b8666fdbdf44875c7ebdc9` |
| transport/full/response-011.json | 132 | `40547823e120ed9a3018a0c81c3ff823c5059337dc7e8360b7638caea9f9c6e1` |
| transport/full/response-012.json | 132 | `768af058e84a1b1621b5dfad35b9ad68d6554bb708d3ed049eb72675a3887dd7` |
| transport/full/response-013.json | 132 | `dced831f55458ade2b0ecf42114995c82c8e3466979b09f313fd29f2b3c40914` |
| transport/full/response-014.json | 132 | `a2cab3a5cd93360631d8711923330bd7cc2b35e02ff7b4019961caa3cca090ae` |
| transport/full/response-015.json | 132 | `2a4fb45f3157f2cb3389bd59f4e995a66466846350638e928f85e6558be710da` |
| transport/full/response-016.json | 132 | `4e8f945b7a27383df302d71eb14be8cbccb89496c24073f31dd7329ff9ed1d88` |
| transport/full/response-017.json | 132 | `92ab73ce86fcca778513cb931c2085db0b1b43b355df05bb5759e589451911c8` |
| transport/full/response-018.json | 132 | `368c15aff2234ef43bbbf4890d655d6c5fd8066700403b9b86643e00e3e58125` |
| transport/full/response-019.json | 132 | `37fbe5e174937c98711cc4905fe78e5153ae04219eb256b9407e0649cd960429` |
| transport/full/response-020.json | 132 | `e6ad96df562588f3c2272eec8fbf7571cbe0b1dbd0346e459ba28451f3ff1918` |
| transport/full/response-021.json | 132 | `dacbf4e867e4340781a3f14e307fa1b3d201f4212fd568f13290317801a01a2f` |
| transport/full/response-022.json | 132 | `7ff84a111350c071fbf778f78744c63596bf8e87a35a2042f7c3ba90c8734ddf` |
| transport/full/response-023.json | 132 | `1f85925ce7ae869e648ea19d20c0d6b9c49d042d836972766c6b8830ebcd1578` |
| transport/full/response-024.json | 132 | `0b64c479ba31cc51019c8ef431fe2ecd10e7c67e3ae0ce0a78a927e436cfe38d` |
| transport/full/response-025.json | 132 | `3a9ef4e7d2c29934454dd6284fbf5bee0e9d4ee5cb5bbb039f9d4f7197cd64d6` |
| transport/full/response-026.json | 132 | `54aa953eea5f476f6cc66babf132504947944e941784e2f6b61413f5a48d7eac` |
| transport/full/response-027.json | 132 | `81984aeee257631c799e4de29801a6250f6f2ca9d1d947bf633a8b43a5d4c288` |
| transport/full/response-028.json | 132 | `be33885e186370713f742935182cada4ee8fff7b4da67ed05b217f5fa4746604` |
| transport/full/response-029.json | 132 | `09ae469d9133c351f0bb48580d56c56b1288b2a679cde11ce95c8a83f3a1621e` |
| transport/full/response-030.json | 132 | `c392f72c63df57e4da42c8699cf17bef0404e0d9e605334fa885238f041bca18` |
| transport/full/response-031.json | 132 | `6aac0af157a77df8bd3aed4000ee6ea028c62a9e86318970f90b607bb9ea7935` |
| transport/full/response-032.json | 132 | `a7d8ad3df5e909f944c42ff5dfdccb4c9039ed5e4e7e499df5bb485fd5abb687` |
| transport/full/response-033.json | 132 | `adfc296dc9cc02d6b186fb6c66e0fc13308da3c0569c8616598d3c01194b40c0` |
| transport/full/response-034.json | 132 | `1bfd387ab49782f5d8054c3aa5cdce9b56c380360424f4449030f4fc1a2bbd25` |
| transport/full/response-035.json | 132 | `9cbe109fd279e25f77a3a8a01973bb7064843d2a1aee87fda75767a2b481f5d1` |
| transport/full/response-036.json | 132 | `1aacfed50e17fbd5b4d2cacb0ce004d637b6891fdf64623744ffb94f4e9f7ec1` |
| transport/full/response-037.json | 132 | `8e2854a3c1bcacb7d2712f14c5c541fc3915e15f415f92f12d09f010d3b398c8` |
| transport/full/response-038.json | 132 | `3631b251e17c38d2433643906a902831f27062c87e44bd93d1de22e521a5015e` |
| transport/full/response-039.json | 132 | `c48c11e1355df66090608ff9e0cd3c0fb90fe0daeb13bdbc47b482baf2c9ca3f` |
| transport/full/response-040.json | 132 | `88e371ab32fbf6040da94f479768e6c1f656a350a1ef19eaf12995001bece203` |
| transport/full/response-041.json | 132 | `dc4a8d941ae6e950e652b26ea32d1badbd3aee51ef474d1e45528489fb752035` |
| transport/full/response-042.json | 132 | `8fb946ee6ea420ba5d4dec5979a4cb989799ed1667d595cafcccc79c784cfeac` |
| transport/full/response-043.json | 132 | `daa86c4a557ea5a5c3d17760c6c5314d56c0a47761f9a7061c4348ac1f1fecf6` |
| transport/full/response-044.json | 132 | `e70e903a87f0b8460144d6a3e8c4bb42efa1b06f40e64bf759cb11d4222e8dd0` |
| transport/full/response-045.json | 132 | `54c5c037124b82357bb58bae9ce19562ab29a39554bfb96e1cd5bc2cf2b685ee` |
| transport/full/response-046.json | 132 | `7ee023f00f54c8cf1b2312f02ec218f58b652c713c3ef00f767c48ce07a30cb4` |
| transport/full/response-047.json | 131 | `f0ef6d20a38ead2fa29526eb2601d64b14b9eb6b561c704bea01f98d5c2c06a4` |
| transport/full/response-048.json | 132 | `06cc1017cef64ca2388855c1cbb8c95f3b88ddca1c8d789bef0a7ad4a24788a1` |
| transport/full/response-049.json | 132 | `876bd964d2cb5936a941646e9b254048885ea6f3aa1564cc2ae0ca8e1f19bb35` |
| transport/full/response-050.json | 132 | `af3e90fed52fccd821a9fd4a5006f46dc78ba770a023829d6ebd29d4eb37b273` |
| transport/full/response-051.json | 132 | `20b7ae7f6410d928cb98d36fac149f6407e62d7020a16e2e499bd176524d126b` |
| transport/full/response-052.json | 132 | `b279265f52d124c970906533499121838d24447c68dcb62e9e39ea0f09344c53` |
| transport/full/response-053.json | 132 | `d0facddc2f2b74ac119319b59cfdc24e9754c3401b670522927d8f19ccde06ed` |
| transport/full/response-054.json | 132 | `346a4e0fcde13f7f42f121eb6e2c0149993b0ff46e1e9ebc6470c59050499156` |
| transport/full/response-055.json | 132 | `6c4241d644c513e67cec0f0eebf0cd9f3a42403b89fbcb3e7e9a0b0ee665ffa6` |
| transport/full/response-056.json | 132 | `50264c3eb8d06d1a56795550559a17f3986fa028ca0c6013f260b966e87139be` |
| transport/full/response-057.json | 132 | `3d1dc147c8b90b78c89d6fd5d2c6850e51e3e6372d4b3341b9a91ab0a1432ab3` |
| transport/full/response-058.json | 132 | `389055764b30549c67cf84423d2f1370a5ece999657e357d5dbb59a63600ecaa` |
| transport/full/response-059.json | 132 | `e90c77c8f5d1a6d139908b9904245d2bb6f90ad46a7749a8917150b88bf26de5` |
| transport/full/response-060.json | 132 | `2edb302b2ae738b1a9f69a0c277688554e32c4e56e26f1759f1c14855a50d694` |
| transport/full/response-061.json | 132 | `73a80da4f54a055999ce84601d00a066cf55017a86de7ae43265ed0c9ac4fda9` |
| transport/full/response-062.json | 132 | `7ca3b1abe75951e5690241736c15c52025ade6047fecfd8eea345990ab102be9` |
| transport/full/response-063.json | 132 | `4d19bb26249e5374920ab801c41c061ffab1e370fc11c42e38b17d889c8e741e` |
| transport/full/response-064.json | 131 | `ddedd9078bd6832478923ad40eebe3e2490cdc16ead50cdf2b4241e203b130da` |
| transport/full/response-065.json | 132 | `bfecc362ae7b2e5baef353e127842999f82db4912726e166195f48d94ca159e9` |
| transport/full/response-066.json | 132 | `8b95f83ccb005a70d6e5807f970b07b9bdf1a851e25fe6920b0651f501723924` |
| transport/full/response-067.json | 132 | `db5ba8321d8891af27b15c32841b15845c73cc3c68dde94991a367fc04996be9` |
| transport/full/response-068.json | 132 | `ffa945bdfbb51d0173be49053b568e14a6b697c060ed7b619fb7fdee7b5bd8da` |
| transport/full/response-069.json | 132 | `b42e65a375aa111f321659291175e593e7721b355a61f7074812f5750301cca2` |
| transport/full/response-070.json | 132 | `e65a82ac2305c2e2a6aefb2278c70631f090a58a840e50e75c5bbe5fd82fd424` |
| transport/full/response-071.json | 132 | `899fe8eb1ea7c6b21056c4c68c402dae6a5fc1337662c4080e41412b026f9921` |
| transport/full/response-072.json | 132 | `db82b5634f9736782c44e94c9c4b34d2636a56e9666e9a0c48d3b08176adb44f` |
| transport/full/response-073.json | 132 | `56ccd23a910a1dc321fcd633ec136df0ca2b7cb456b856fc62d4dfb224e42b32` |
| transport/full/response-074.json | 132 | `afc5d2a2f413269451a3e100a4fbfd8b88bde17223d1a63c905412d9aed9bc5f` |
| transport/full/response-075.json | 132 | `0582c3e201720077080530348cf15cb5e1f9d67a2fa6c126e730a60624e239a5` |
| transport/full/response-076.json | 132 | `c910f66f72fe446d670ae399aee063e1cc5023775d7bcbccef1d123403c19ca2` |
| transport/full/response-077.json | 132 | `727e1d14e35781f2ce4d2957b09fc8dc09d5dbac94e72da12aaac6f7fa7bea7c` |
| transport/full/response-078.json | 131 | `b34ca4a916e23fccb954c9bb3d949bdb5757bd37435f89497b3b8a936336b1d6` |
| transport/full/response-079.json | 132 | `39011fd750fc4c9f53dcda8fe6709ca6d08e1eb87aeffdc1343ade7f8eed1239` |
| transport/full/response-080.json | 132 | `d47edf73ed04c88e241a22a0ab11c210112b4471e5084b31eaa261f0ab8d785d` |
| transport/full/response-081.json | 132 | `b1695731998f8f55fd514293bc13024ab466b97577f8fdadc4afb28c5f813ae0` |
| transport/full/response-082.json | 132 | `3caaaa0ef52c64f559c937f558039fe9a58a042cbbd8faa3288aaf51527c43c1` |
| transport/full/response-083.json | 132 | `698e5d19986d8f76b0ab7b0b6b4c109490fdd1176c9c10b435f216c668d6e53e` |
| transport/full/response-084.json | 132 | `cf8972ed3a13f5e8d18050b0366310cf815381d7b00b97a20f9a79d74968a99b` |
| transport/full/response-085.json | 131 | `7e2fbe52febf35f17b844da8ced26abcb0e4aaad0abe070bef84e7a0e8453e68` |
| transport/full/response-086.json | 132 | `285e56b1657b38d56b808aa6723f63a573c20688767c28c6cbdc0b981ebef295` |
| transport/full/response-087.json | 132 | `2dffa6ced016d00f2365c47544d3f48940f9363c9b72e44a00e325a73af28735` |
| transport/full/response-088.json | 132 | `72abd2cc7fc6caab278d7847a3e3f55fa390433c788bf21dbd6e0ad53e746637` |
| transport/full/response-089.json | 132 | `448dc629aa03ffeb64fac3f6bbc3b8e86a3e97b6a4ac47c011067417e73a60bc` |
| transport/full/response-090.json | 208 | `9dfa8f55c21d377f8f82412ca99d36864065bb7dbdbec3931ebe9d0fc9fc0955` |
| transport/full/terminal.json | 15025 | `3938090a70a53149dd1c437ee939e05a439f7e1053fcd6aea391f47015b44cc8` |
