# A2 Task3: adversarial controls and action harness

Prepared brief only. Wait for root's explicit Task2 acceptance/dispatch.
Worktree: /home/charl/Moriarty/.worktrees/s01-audit-start.
Record the actual Task2-admitted pre-dispatch HEAD.

Read Task3 and global constraints in:
docs/superpowers/plans/2026-09-05-moriarty-s02-candidate-a-authority-installment.md
and the adopted verification-command addendum:
docs/superpowers/plans/2026-09-05-candidate-a-verification-command-addendum.md
(commit a314549). Original plan hashes remain unchanged.

Implement only Task3: extend test module, create harness, and make only the
lifecycle additions explicitly required by Task3. Fixtures and common/A/Python
remain read-only. The other lifecycle has a separate owner. Do not edit plans,
main docs, DB, progress, root evidence or earlier receipts. No commits until root.
Own unique .superpowers/sdd/a2-task3-report.md and a2-task3-receipts/.

Use required Quint/TDD skills. Temporarily substitute canVerify for canVerifyAuthorityA only in VerifyI. changedUnusedNodeTest must produce an actual compiling assertion failure; preserve it, then restore the exact A guard.
Type errors and an ineffective control are not RED; report and investigate.
Capture full source/recorder/tool closure and raw terminal output before edits.
A2 lifecycle final guard must return to accepted Task2 behavior.
A3 staleScenarioS/staleRouteS live in lifecycle, as the harness imports them;
test-only mutants and run definitions remain in tests.

Then typecheck the test entry recursively with a verified full four-module
closure. Run all current tests with --backend=rust --seed=42 --match '.*Test'.
Require 17 tests;23 action witnesses plus2 profile witnesses; maxsteps20. Use the exact complete --witnesses list in the original
plan command; no comma-joined list or omitted names.

Run the original100-sample command only after GREEN. Inspect terminal invariant
result and every witness count. If any is zero, inspect its deterministic path
and retain that diagnostic; only then escalate to1000samples, preserving both.
No unbounded sampling or unsupported proof claim. Don't alter bounds/guards/
invariants/cases to obtain success. Financial terminal excludes mere cancellation,
refusal or empty-effect envelope rejection.

Root will run ONE shared boundary/adapter/Python regression set after BOTH final
lifecycle source closures freeze, and bind it to both units. Do not duplicate
these shared regressions. Your task may report source/tests/samples complete
pending that shared root gate; do not claim full A2 acceptance.

Capture exact command/cwd/seed/profile/scenario scope, full source hashes and
bytes before/after each command, CLI/Rust identity and provenance, raw stdout/
stderr or explicitly combined chunks, terminal exits, and all sample counts.
Preserve original RED and corrected GREEN as distinct immutable directories.
No environment dumps, hidden fabricated traces or rewritten old receipts.

After self-review, freeze final source and report exact test inventory, sample
counts, traces and evidence paths. Stay available for independent source/spec/
runtime/evidence review. Root owns admission, final unit manifest and commit.
A4 integrated exports, A5 explicit bounded checking, A6 Council and A7 integration
remain open even if these finite harness tests pass.
