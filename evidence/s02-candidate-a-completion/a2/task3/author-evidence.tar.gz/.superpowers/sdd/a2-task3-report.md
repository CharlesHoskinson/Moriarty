# Candidate A A2 Task3 report

Status: dispatched source, deterministic tests and samples complete; root admission and shared regression gate pending. Evidence is repository and experiment observation, not model checking.

Before-dispatch base: `955f56bc72666fde42ac55408d6bfbe95d47bc0d`. Scope follows `.superpowers/sdd/a2-task3-brief.md`, adopted installment plan SHA256 `b0dfcb4d8c2522d160cd84eac265fb188a26f307c05bcb840754728590075b67`, and verification-command addendum adopted at `a314549`.

## Frozen source

| File under `specs/quint/s02/` | SHA256 |
|---|---|
| `candidate_a_authority_installment_fixtures.qnt` | `22d975d6d615e1f8e80c453115ded79fa68f783880a036f73470814221bf1a92` |
| `candidate_a_authority_installment.qnt` | `f12d91938098d48a313baf7cb5218f84b6bd840da8c518d54f195e0f7fa1e4cd` |
| `candidate_a_authority_installment_harness.qnt` | `9a49b2a76d0c9e27a0d06b942b4f6a3338bf54a1e005cbba6d6388e91dcf82ca` |
| `candidate_a_authority_installment_test.qnt` | `b1d9c21c5285105b382525df8df2ebaa41dbf10979f400d975b40500c3f7c3d1` |

Fixture and final lifecycle are byte-identical to accepted Task2. Task3 adds 100 test lines and the action harness. No common/A, other-lane, plan, Python, DB, root evidence or earlier receipt edits; no commit.

## Compiling RED and corrected GREEN

All commands ran in `/home/charl/Moriarty/.worktrees/s01-audit-start`. The immutable stage directories under `.superpowers/sdd/a2-task3-receipts/` contain exact input.json/result.json, recorder.py, raw stdout/stderr, CLI version streams and the full sixteen-file recursive source closure. All four installment modules are included. Each stage reports `sourceUnchanged: true` and `toolsUnchanged: true`.

| Stage | Command | Terminal result |
|---|---|---|
| red-typecheck | `quint typecheck specs/quint/s02/candidate_a_authority_installment_test.qnt` | exit 0; 429.1631561559916 s |
| red-test | `quint test specs/quint/s02/candidate_a_authority_installment_test.qnt --backend=rust --seed=42 --match changedUnusedNodeTest` | exit 1; QNT508 assertion failure; 427.56472082099936 s |
| green-typecheck | `quint typecheck specs/quint/s02/candidate_a_authority_installment_test.qnt` | exit 0; 496.42057173700596 s |
| green-tests | `quint test specs/quint/s02/candidate_a_authority_installment_test.qnt --backend=rust --seed=42 --match '.*Test'` | exit 0; 17 passing (96844 ms runtime); 588.7582195040013 s wall time |
| samples-100 | Exact command below | exit 0; no violation; 100 traces; 263.1680294669932 s wall time |

Tests were extended before the deliberate RED guard change. Original RED lifecycle SHA256 was `61ead36dd124c838a08c6a9d1d2982802d8adfc89d89028594e3e7cf81c7f3af`: only VerifyI used common `canVerify` instead of `canVerifyAuthorityA`. The unused N15 successor-node mutation retained fully rebound symbolic evidence; common verification admitted it, so the explicit negative assertion failed. The full compiling RED closure and original failure were captured before restoring exactly the accepted A guard. Test and harness bytes did not change between RED and GREEN. No syntax/type failure is counted as RED. Frozen GREEN typecheck and runtime ran concurrently, without duplicate jobs or source edits.

Seventeen passing tests: fourOperationParentTest, literalFidelityTest, registrationTest, bothRaceOrdersTest, twoFillsTest, freshCancellationTest, recoveryMatrixTest, negativeAuthorityTest, duplicateTest, changedUnusedNodeTest, freshDuplicateCancellationTest, initialWitnessesFalseTest, residualRecoveryActionTest, beforeRecoveryActionTest, timeout101ActionTest, refused100ActionTest, routeBoundsTest.

## Exact sampling command and counts

```sh
quint run specs/quint/s02/candidate_a_authority_installment_harness.qnt --backend=rust --seed=42 --max-samples=100 --max-steps=20 --invariant=installmentSafetyI --witnesses parentPreparedI parentSignedI firstProposedI cancelProposedI firstVerifiedI cancelVerifiedI firstCommittedI cancelCommittedI firstRejectedI cancelRejectedI secondProposedI secondVerifiedI secondCommittedI freshProposedI freshVerifiedI freshCommittedI clockAdvancedI recoveryPreparedI recoverySignedI recoveryProposedI recoveryVerifiedI recoveryCommittedI recoveryRejectedI afterProfileCompletedI beforeProfileCompletedI --verbosity=1
```

Raw output: `[ok] No violation found (41628ms at 2 traces/second).` All counts are out of 100 explored traces:

| Witness | Count |
|---|---:|
| parentPreparedI | 100 |
| parentSignedI | 100 |
| firstProposedI | 100 |
| cancelProposedI | 100 |
| firstVerifiedI | 100 |
| cancelVerifiedI | 100 |
| firstCommittedI | 52 |
| cancelCommittedI | 48 |
| firstRejectedI | 48 |
| cancelRejectedI | 52 |
| secondProposedI | 12 |
| secondVerifiedI | 12 |
| secondCommittedI | 12 |
| freshProposedI | 40 |
| freshVerifiedI | 40 |
| freshCommittedI | 40 |
| clockAdvancedI | 76 |
| recoveryPreparedI | 88 |
| recoverySignedI | 88 |
| recoveryProposedI | 88 |
| recoveryVerifiedI | 51 |
| recoveryCommittedI | 51 |
| recoveryRejectedI | 37 |
| afterProfileCompletedI | 50 |
| beforeProfileCompletedI | 50 |

No witness is absent, so no 1000-sample escalation was run. Raw output also supplies reproduction seed `0xe0`; the original command seed was decimal 42 as preserved in input.json. No ITF trace export was requested or claimed. This is scheduled finite-route sampling, not unrestricted interleaving verification. The longest route has 17 actions; bound 20 adds three steps of margin. Deterministic tests cover the eleven scenarios under both signing profiles and assert exact guarded transitions. Financial completion excludes cancellation and deliberate refusal: refusal resolves the sole recovery attempt while escrow and active agreement may remain.

## Tool and raw-output identities

All five stages pin and recheck CLI `/home/charl/.npm-global/lib/node_modules/@informalsystems/quint/dist/src/cli.js`, SHA256 `ac12595b1cb7253feec93c79417615c6eb20fc3b6a3df35c5e3530b24e90a501`, raw version `0.32.0`; and Rust evaluator `/home/charl/.quint/rust-evaluator-v0.6.0/quint_evaluator`, SHA256 `b2efdeac5713d153e41bf2143b94ed75d888fdd5637f4a5d61a04c695313510a`. The Rust version label comes from the installation path; unsupported `--version` behavior is disclosed in recorder metadata and Task1's retained identity diagnostic. No historical receipt was rewritten.

RED stdout SHA256 `09bc687bdc1ab0735d5d72793f24cd210e1fbbb4227d87b90f2229a0f0c977e1`; RED stderr `7880f94b001f34e172927175c742d4d8f3b7fafcfeb74def8d48056c0e134ba2`. GREEN test stdout `9a8fd01b9e3aa78d871a9d86bcbb6579f799a6b0186361b9af302ce10b7c861f`. Sample stdout `1f56546f0b030ebc4656c1752e6379d0174c9236b330bd83e5f301129ae7589b`. GREEN/sample stderr and typecheck streams are empty.

Root owns independent review, exact archive admission, the shared final boundary/adapter/Python regressions, unit manifest and commit. A4 exports/replay, A5 bounded checking, A6 Council and A7 integration remain open. No broader completion or cryptographic claim is made.
