#!/usr/bin/env python3
"""Capture exact A2 Task3 sources/tools before and after one command."""
import datetime
import hashlib
import json
import pathlib
import re
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[3]
BASE = pathlib.Path(__file__).resolve().parent
stage = BASE / sys.argv[1]
stage.mkdir(exist_ok=False)
argv = sys.argv[2:]
assert argv and argv[0] == "quint", argv
entries = []
seen = set()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot(path):
    path = path.resolve()
    if path in seen:
        return
    seen.add(path)
    relative = path.relative_to(ROOT)
    destination = stage / "source" / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, destination)
    entries.append({"path": str(relative), "sha256": digest(path)})
    for imported in re.findall(r'from\s+"([^"]+)"', path.read_text()):
        snapshot((path.parent / imported).with_suffix(".qnt"))

snapshot(ROOT / "specs/quint/s02/candidate_a_authority_installment_test.qnt")
required = {"candidate_a_authority_installment_fixtures.qnt", "candidate_a_authority_installment.qnt",
    "candidate_a_authority_installment_harness.qnt", "candidate_a_authority_installment_test.qnt"}
assert required.issubset({path.name for path in seen}), "Incomplete four-module closure"
tool = pathlib.Path(shutil.which(argv[0])).resolve()
backend = pathlib.Path("/home/charl/.quint/rust-evaluator-v0.6.0/quint_evaluator")
version = subprocess.run([str(tool), "--version"], cwd=ROOT, capture_output=True)
(stage / "tool-version.stdout").write_bytes(version.stdout)
(stage / "tool-version.stderr").write_bytes(version.stderr)
metadata = {"observedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "argv": argv, "cwd": str(ROOT), "sourceClosure": sorted(entries, key=lambda e: e["path"]),
    "sourceCommit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "beforeDispatchCommit": "955f56bc72666fde42ac55408d6bfbe95d47bc0d",
    "tool": {"path": str(tool), "sha256": digest(tool), "versionExit": version.returncode},
    "backend": {"path": str(backend), "sha256": digest(backend), "versionLabel": "v0.6.0",
        "versionProvenance": "Installation directory label; binary --version unsupported, exact diagnostic retained in a2-task1-receipts/rust-tool-identity-before-green."},
    "recorder": {"path": str(pathlib.Path(__file__).relative_to(ROOT)), "sha256": digest(pathlib.Path(__file__))}}
shutil.copy2(__file__, stage / "recorder.py")
(stage / "input.json").write_text(json.dumps(metadata, indent=2) + "\n")
start = time.monotonic()
with (stage / "stdout.txt").open("wb") as out, (stage / "stderr.txt").open("wb") as err:
    completed = subprocess.run(argv, cwd=ROOT, stdout=out, stderr=err)
after = [{"path": entry["path"], "sha256": digest(ROOT / entry["path"])} for entry in metadata["sourceClosure"]]
unchanged = after == metadata["sourceClosure"]
tools_unchanged = digest(tool) == metadata["tool"]["sha256"] and digest(backend) == metadata["backend"]["sha256"]
result = {"exitCode": completed.returncode, "durationSeconds": time.monotonic() - start,
    "sourceAfter": after, "sourceUnchanged": unchanged, "toolsUnchanged": tools_unchanged,
    "stdoutSha256": digest(stage / "stdout.txt"), "stderrSha256": digest(stage / "stderr.txt")}
(stage / "result.json").write_text(json.dumps(result, indent=2) + "\n")
sys.stdout.buffer.write((stage / "stdout.txt").read_bytes())
sys.stderr.buffer.write((stage / "stderr.txt").read_bytes())
print(json.dumps({"stage": str(stage), **{k: v for k, v in result.items() if k != "sourceAfter"}}), flush=True)
sys.exit(completed.returncode if unchanged and tools_unchanged else 2)
