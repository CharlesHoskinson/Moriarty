# Candidate A A2 Task2 lifecycle helper report

Status: DONE for dispatched Task2; root acceptance and commit pending.
Evidence kind: repository observation and experiment observation.
Scope: pure guarded authority routes and seven deterministic tests. Task3 negatives, stateful harness, sampling and final regressions remain open.

## Authority, source and ownership

Before-dispatch base: `35959ae64e157e7c2253fdce786976237532d13b`.
Dispatch brief: `.superpowers/sdd/a2-task2-brief.md`.
Task2 design came from the adopted installment plan at SHA256 `b0dfcb4d8c2522d160cd84eac265fb188a26f307c05bcb840754728590075b67`. Root subsequently adopted a Task3 verification addendum; Task2 source was not changed for that documentation update.
Frozen common/A anchor: `d14cfea98a1c9213e5ef5f12c1a088f4e966083d`.

| Source | Final SHA256 |
|---|---|
| `specs/quint/s02/candidate_a_authority_installment.qnt` | `f12d91938098d48a313baf7cb5218f84b6bd840da8c518d54f195e0f7fa1e4cd` |
| `specs/quint/s02/candidate_a_authority_installment_test.qnt` | `db14aecad8485e88a0f3cf849cc90ccfe8e4c451a857d12ea9f177f76a9cecdc` |
| Accepted, unchanged fixture | `22d975d6d615e1f8e80c453115ded79fa68f783880a036f73470814221bf1a92` |

The test extension was written before the new lifecycle module. The only RED-to-GREEN edit removed the extra `AuthorityUnused` guard on `FreshCancelAttempt` in `canCommandI`'s proposal branch. Tests and the accepted fixture did not change between RED and GREEN. No plan, common/A, Python, harness, other-lane, DB, root evidence or OpenSpec changes were made. No commit was made.

## Original RED and fresh GREEN

All commands used cwd `/home/charl/Moriarty/.worktrees/s01-audit-start`. Each directory below is immutable under `.superpowers/sdd/a2-task2-receipts/`, with input.json, result.json, exact fifteen-file transitive source closure, a copy of the original recorder, raw stdout/stderr, CLI version output, tool/backend hashes and source/tool checks after the command.

| Stage | Exact command | Observed terminal result |
|---|---|---|
| `red-typecheck` | `quint typecheck specs/quint/s02/candidate_a_authority_installment_test.qnt` | exit0; 291.717496352 seconds |
| `red-test` | `quint test specs/quint/s02/candidate_a_authority_installment_test.qnt --backend=rust --seed=42 --match freshCancellationTest` | exit1; 287.880175243 seconds; one test failed with QNT508 Assertion failed |
| `green-typecheck` | `quint typecheck specs/quint/s02/candidate_a_authority_installment_test.qnt` | exit0; 390.190015921 seconds |
| `green-tests` | `quint test specs/quint/s02/candidate_a_authority_installment_test.qnt --backend=rust --seed=42 --match '.*Test'` | exit0; 367.408096999 seconds; seven tests passing |

All four stages report `sourceUnchanged: true` and `toolsUnchanged: true`. Root explicitly authorized the two GREEN commands to run concurrently on the frozen corrected source. Neither job was duplicated, and no source was edited while either ran. Per-stage sourceCommit records any concurrent root documentation commit separately from the fixed beforeDispatchCommit.

The original RED lifecycle SHA256 is `194551809e8642cfc017e6357228d6aabc29b501e701e7845d71463a0478b373`; its bytes remain at `red-test/source/specs/quint/s02/candidate_a_authority_installment.qnt`. That source typechecked before runtime failure. The test compares valid prefix8 (parent registration, both race contenders verified, first fill committed and initial cancellation loser rejected) with prefix11, which requires a new cancellation attempt. The extra guard applies only at the fresh cancellation proposal and excludes the consumed parent key. The corrected source removes that one guard and passes the same unchanged test. Original raw output identifies the failed `freshCancellationTest`; no parse/type diagnostic is counted as RED.

GREEN names, each passed once:

- `fourOperationParentTest`
- `literalFidelityTest`
- `registrationTest`
- `bothRaceOrdersTest`
- `twoFillsTest`
- `freshCancellationTest`
- `recoveryMatrixTest`

Raw runtime output reports `7 passing (40595ms)` within the larger command wall time. RED stdout SHA256: `9e4a45c03d8473baefc680ae3cb302ffe02912cf955e5d13988fda8d90881ccd`; RED stderr: `7880f94b001f34e172927175c742d4d8f3b7fafcfeb74def8d48056c0e134ba2`. GREEN stdout: `1ca62d8c53c4f89563f1d60963bed11fda1ef24c796c59ce95f02d85e9341013`. GREEN stderr and typecheck streams are empty.

## Tool provenance

Every stage pins CLI `/home/charl/.npm-global/lib/node_modules/@informalsystems/quint/dist/src/cli.js`, SHA256 `ac12595b1cb7253feec93c79417615c6eb20fc3b6a3df35c5e3530b24e90a501`, successful raw version output `0.32.0`.

Every stage also pins Rust evaluator `/home/charl/.quint/rust-evaluator-v0.6.0/quint_evaluator` before execution, SHA256 `b2efdeac5713d153e41bf2143b94ed75d888fdd5637f4a5d61a04c695313510a`, and checks the same bytes after execution. The `v0.6.0` version label is sourced from the installation directory. Binary `--version` is unsupported, with exact diagnostic preserved in Task1's separate identity receipt; Task2 metadata states this provenance rather than inventing a self-reported version. Task1 historical recorder/receipts were not rewritten.

## Checked behavior and limits

The deterministic tests quantify both signing profiles and the finite scenario matrix. Actual A adapters/boundaries and unchanged common updates execute the routed operations. Prefix success requires every guard, state safety and transition check to hold; failed guards cannot count as successful prefixes.

Observed passing assertions include: no money movement during registration; full retained verified loser records in both initial race orders; first fill at N2/escrow5/Bob5; two fills at N0/escrow0/Bob10 with revision2; fresh cancellation under the existing parent signature at revision2 without money/candidate changes or re-signing nonce0; initial/residual nonce1 recoveries; NoInput recovery at100/101; exact supplied-deadline rollback and retained rejection with nonce1 registration/signing intact. Cancelled parent and nonce0 records are preserved after recovery. Historical allowance remains10/5 when recovered escrow is0. Refusal requires resolved records but is not financial terminal.

This is deterministic evidence for scheduled finite routes, not unrestricted interleavings, arbitrary-program correspondence, cryptographic verification or model checking. Task3's adversarial controls, action harness, samples/witness counts and shared final regression gate were not run or implemented. Root owns independent source/spec/receipt acceptance and subsequent commit. Await explicit Task3 dispatch.
