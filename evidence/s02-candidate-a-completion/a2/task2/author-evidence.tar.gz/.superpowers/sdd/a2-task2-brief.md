# A2 Task2: actual installment authority routes

Status: prepared brief; do not start until root accepts/commits Task1 and
explicitly dispatches this task. Record that exact pre-dispatch HEAD.
Worktree: /home/charl/Moriarty/.worktrees/s01-audit-start.

Read Task2 and global constraints in the adopted plan:
docs/superpowers/plans/2026-09-05-moriarty-s02-candidate-a-authority-installment.md
SHA256 b0dfcb4d8c2522d160cd84eac265fb188a26f307c05bcb840754728590075b67. Implement the complete Task2 code/tests only.
Main XML/OpenSpec contracts are in /home/charl/Moriarty, not copied to this branch.

Own:
- specs/quint/s02/candidate_a_authority_installment.qnt (new lifecycle)
- specs/quint/s02/candidate_a_authority_installment_test.qnt (extend accepted Task1)
- .superpowers/sdd/a2-task2-report.md
- .superpowers/sdd/a2-task2-receipts/ (new immutable directories)

Accepted Task1 fixtures are read-only. No common/A/Python/plan/harness/other-lane
edits; no root-owned evidence, wiki, DB or ledger edits. Do not commit or begin
Task3 without root's acceptance. Preserve the other lane's changes.

Use the required Quint/TDD skills. Write focused test first, then compiling RED
lifecycle scaffold per adopted plan. Add the Task2 ProposeI FreshCancelAttempt guard requiring AuthorityUnused. Capture freshCancellationTest assertion failure after valid fill/stale-loser rejection, then remove only that extra guard.
Do not count parse/type failures as behavioral RED. Capture original exact
transitive source bytes and raw terminal output BEFORE restoring the guard/update.
Use one recursive test-module typecheck per necessary stage; avoid redundant
standalone import checks. Let each active command finish, no duplicate jobs.

After correction, run the complete current test module with Rust/seed42 and
--match '.*Test'. Expected inventory at this task is exactly:
fourOperationParentTest, literalFidelityTest, registrationTest, bothRaceOrdersTest, twoFillsTest, freshCancellationTest, recoveryMatrixTest.
A missing named test blocks acceptance. Do not change expected outcomes for GREEN.
Focus during diagnostics; reserve full boundary/Python regressions for Task3.
No sampling or harness implementation yet.

Keep source/policy facts independent and exact. Both profiles must execute the
same mandatory cases via actual guards and common updates. Pure prefixes count
only when their ok flag is true. Cancellation/refusal are not automatically
financial termination. Frozen source remains d14cfea.

Preserve per-stage command/cwd/base/staged-source closure, CLI and Rust evaluator
paths/version provenance/hashes, exact stdout/stderr and terminal exit. Record
source hashes before and after execution. Retain immutable original recorder
source if one is used; do not alter Task1 receipts. No secret/environment dumps.
No fixed sleep abandonment while a CPU-active check is progressing.

Self-review, report exact results and limits, then stay available for independent
nonauthor source/spec/receipt review. Root owns acceptance, archive and commit.
This task does not complete the whole lifecycle's negative/harness/regression gate.
