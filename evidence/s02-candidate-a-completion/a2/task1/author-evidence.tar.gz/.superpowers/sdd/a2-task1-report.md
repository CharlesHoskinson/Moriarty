# Candidate A A2 Task1 fixture report

Status: DONE for the dispatched fixture task; root acceptance/commit pending.
Evidence kind: repository observation and experiment observation.
Scope: literal authority fixtures and two focused tests, not an integrated lifecycle.

## Authority and files

Before-dispatch HEAD: `82d2c0b1d35ecf2f954603e4b8d54b248bda2663`.
Adopted installment plan SHA256: `b0dfcb4d8c2522d160cd84eac265fb188a26f307c05bcb840754728590075b67`.
Brief: `.superpowers/sdd/a2-task1-brief.md`.
Frozen common/A source anchor: `d14cfea98a1c9213e5ef5f12c1a088f4e966083d`.

Created source:

| File | SHA256 |
|---|---|
| `specs/quint/s02/candidate_a_authority_installment_fixtures.qnt` | `22d975d6d615e1f8e80c453115ded79fa68f783880a036f73470814221bf1a92` |
| `specs/quint/s02/candidate_a_authority_installment_test.qnt` | `71b83ae2b2eaf36e35d62f3f64c89aa41af44d584806b28dd053ed304b4db311` |

The test file was written first. The fixture followed with the dispatched RED defect: `parentPlanI.operations` contained fill1, fill2 and initial cancellation, but omitted residual cancellation. The only subsequent source edit added `cancel1PlannedI` to that list. Tests, literal observations and all common/A imports remained unchanged. No lifecycle/harness files, plans, common modules, Python, OpenSpec, DB or root evidence were changed. No commit was made.

## Executed checks

All commands ran in `/home/charl/Moriarty/.worktrees/s01-audit-start` through the owned immutable receipt runner. Each stage stores exact argv/cwd/source commit, the complete fourteen-file source/import closure with bytes and SHA256, tool identity, raw stdout/stderr and terminal exit/duration. Typechecking the test module checked the imported fixture and transitive closure.

| Receipt directory under `.superpowers/sdd/a2-task1-receipts/` | Command | Terminal result |
|---|---|---|
| `red-typecheck` | `quint typecheck specs/quint/s02/candidate_a_authority_installment_test.qnt` | exit0, 141.425211191 seconds |
| `red-test` | `quint test specs/quint/s02/candidate_a_authority_installment_test.qnt --backend=rust --seed=42 --match fourOperationParentTest` | exit1, 156.181159915 seconds; one failed test, QNT508 Assertion failed |
| `green-typecheck` | `quint typecheck specs/quint/s02/candidate_a_authority_installment_test.qnt` | exit0, 157.756754977 seconds |
| `green-tests` | `quint test specs/quint/s02/candidate_a_authority_installment_test.qnt --backend=rust --seed=42 --match 'fourOperationParentTest\|literalFidelityTest'` | exit0, 134.956509797 seconds; two passing tests |

The displayed backslash before the pipe in this Markdown table is table escaping. The actual argv argument in `green-tests/input.json` is `fourOperationParentTest|literalFidelityTest`, with no backslash.

Original RED fixture SHA256: `33de9158668a315820c83fcceea5166e1cb865e0184f6c8fe252291185ca3157`.
Original RED source bytes were copied before the test and checked before correction. The terminal failure explicitly identifies `fourOperationParentTest` and its expected four-operation list. This is behavioral RED after successful typecheck, not a parse/type diagnostic. The GREEN run passed `fourOperationParentTest` and `literalFidelityTest`, one test each; raw runner output reports `2 passing (4321ms)` for test execution within the larger command wall time.

Raw output digests:

- RED stdout: `4ef81a69c3745ea3f934b1f5862142464a9201211a991ab0ad967a1ada72bc68`.
- RED stderr: `7880f94b001f34e172927175c742d4d8f3b7fafcfeb74def8d48056c0e134ba2`.
- GREEN stdout: `47a6a474efc7fd4eb9b6fbc521582d25670f809e51f53cd8088e41f814136eff`.
- GREEN stderr and both typecheck streams are empty; digest `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

## Tool identity and timing limitation

All four command receipts pin Quint CLI path `/home/charl/.npm-global/lib/node_modules/@informalsystems/quint/dist/src/cli.js`, SHA256 `ac12595b1cb7253feec93c79417615c6eb20fc3b6a3df35c5e3530b24e90a501`, and raw successful `--version` output `0.32.0`.

The initial recorder did not pin the Rust evaluator separately. At root's review request, a new immutable receipt was captured after RED and before GREEN runtime at `rust-tool-identity-before-green/identity.json`; existing RED metadata/recorder were preserved. It pins `/home/charl/.quint/rust-evaluator-v0.6.0/quint_evaluator`, SHA256 `b2efdeac5713d153e41bf2143b94ed75d888fdd5637f4a5d61a04c695313510a`, observed at `2026-09-05T17:22:43.461748+00:00`. Its `--version` attempt returned exit1 with an unsupported-argument diagnostic, retained verbatim. `v0.6.0` is the installed directory label, not a successful binary self-report. Root can cross-reference its earlier A0/A3 pin of the same digest; this later receipt alone does not retrospectively establish the evaluator bytes used during RED. No redundant RED rerun or historical metadata rewrite was performed.

## Self-review and limits

The literal fixture includes the complete sixteen-node installment program, six account entries, five optional choices, original request/time, result/error/payments/warnings/reductions, ordered effects, and complete policy facts. The first fill expects N2/escrow5/Bob5, and the second expects N0/escrow0/Bob10. Initial/residual cancellation preserves the candidate with NoInput/NoCoreProjection/empty effects. Recovery literals distinguish ten/five refunds, supplied time2 recovery, NoInput100/101 and supplied deadline rollback to minimumTime2. Expected constructors do not call the adapter or projector; only `actualI` produces the observed adapter result for equality comparison.

The parent plan contains exactly four operations and is checked under both signing profiles. Runtime literal fidelity checks the defined finite scenario/operation matrix and recovery plan fidelity. This does not execute parent registration, fresh cancellation, races, nonce1 recovery or their accounting transitions; those belong to Task2/Task3. No sampled simulation, model checking, Python correspondence, Council review or full unit regression was run for Task1. Root requested focused checks only. Ready for exact-source independent intake; await explicit next-task dispatch.
