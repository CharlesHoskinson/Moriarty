# A2 Task 1: independent installment fixtures

Status: dispatch brief; do not start until root explicitly sends adoption.
Worktree: /home/charl/Moriarty/.worktrees/s01-audit-start.
Base before dispatch: record current git HEAD when root sends adoption.
Frozen common/A source: d14cfea98a1c9213e5ef5f12c1a088f4e966083d.

Read the complete adopted plan:
docs/superpowers/plans/2026-09-05-moriarty-s02-candidate-a-authority-installment.md
SHA256 b0dfcb4d8c2522d160cd84eac265fb188a26f307c05bcb840754728590075b67.
Implement Task1 only (plan lines71–242, exact current heading boundaries).
The plan's global constraints, imports, fixture block and two initial tests are
the full task text. All later tasks remain read-only context.

## Ownership

Create only:
- specs/quint/s02/candidate_a_authority_installment_fixtures.qnt
- specs/quint/s02/candidate_a_authority_installment_test.qnt
- .superpowers/sdd/a2-task1-report.md
- .superpowers/sdd/a2-task1-receipts/ (unique immutable stage directories)

Do not edit either plan, common/A modules, Python, the lifecycle/harness files,
OpenSpec, wiki, session DB, root-owned evidence or progress ledger.
Do not commit: root must perform independent acceptance first.
Use apply_patch for local edits. Existing B drafts belong to other work.

## Required sequence

1. Read applicable Quint-language/modeling, TDD and repository instructions.
2. Write fourOperationParentTest first against the independently literal fixture.
   The compiling RED fixture deliberately lists only fill1, fill2 and initial
   cancellation, omitting the fourth residual cancellation operation.
3. Typecheck the RED fixture/test. A parse/type failure is a diagnostic, not RED.
4. Run only fourOperationParentTest with Rust/seed42. Require an actual assertion
   failure caused by the absent fourth operation. Preserve raw terminal output
   and the exact full transitive source closure BEFORE fixing the defect.
5. Restore the reviewed fourth operation; run both fourOperationParentTest and
   literalFidelityTest GREEN. Expected records must stay literal, not computed
   from adapter/projector outputs.
6. Preserve exact GREEN closure, tools and raw terminal receipts. Self-review
   every literal state/map/node/fact/effect and both signing profiles.
7. Report DONE or a precise blocker. Stay available for independent review
   corrections. Do not continue Task2 without root's next message.

The test module at this stage imports fixtures and the required common/A
preamble, NOT nonexistent lifecycle/harness modules. Root's temporary full-plan
typecheck is syntax evidence only, not your behavioral RED/GREEN.

## Evidence

For each command retain exact argv, cwd, source stage, tool path/version/hash,
every stdout/stderr chunk, terminal exit and duration if supplied.
No invented success counts or reconstructed raw output. Raw inputs are immutable.
Source closure includes the two new modules and all recursively imported .qnt
files. Snapshot source bytes as well as SHA256. Use distinct red and green
directories; never overwrite RED. Do not include secrets or environment dumps.

Wait for each active command's terminal result rather than launching duplicates.
Focused tests only during iteration. No 40-test boundary/Python regression rerun
for Task1; full unit regressions belong to the final lifecycle gate.
If typecheck/compile is slow but alive, poll the same process and report progress.
Do not alter bounds, profiles, common semantics or expected outcomes for speed.

Report exact files, checks, original RED cause, GREEN selected test names/counts,
source hashes, terminal receipts and limitations. The task is a fixture unit,
not an executed cancellation/recovery lifecycle, model check or Council gate.
