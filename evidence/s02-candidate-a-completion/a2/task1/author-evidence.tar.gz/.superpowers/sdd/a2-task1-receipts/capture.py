#!/usr/bin/env python3
"""Capture an immutable A2 Task1 source closure and one command's raw output."""
import hashlib
import json
import pathlib
import re
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[3]
BASE = pathlib.Path(__file__).resolve().parent
stage = BASE / sys.argv[1]
stage.mkdir(exist_ok=False)
argv = sys.argv[2:]
assert argv and argv[0] == "quint", argv
entries = []
seen = set()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot(path):
    path = path.resolve()
    if path in seen:
        return
    seen.add(path)
    relative = path.relative_to(ROOT)
    destination = stage / "source" / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, destination)
    entries.append({"path": str(relative), "sha256": digest(path)})
    for imported in re.findall(r'from\s+"([^"]+)"', path.read_text()):
        child = (path.parent / imported).with_suffix(".qnt")
        snapshot(child)

for name in ("candidate_a_authority_installment_fixtures", "candidate_a_authority_installment_test"):
    snapshot(ROOT / "specs/quint/s02" / (name + ".qnt"))
tool = pathlib.Path(shutil.which(argv[0])).resolve()
version = subprocess.run([str(tool), "--version"], cwd=ROOT, capture_output=True)
(stage / "tool-version.stdout").write_bytes(version.stdout)
(stage / "tool-version.stderr").write_bytes(version.stderr)
metadata = {"argv": argv, "cwd": str(ROOT), "sourceClosure": sorted(entries, key=lambda e: e["path"]),
    "sourceCommit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "tool": {"path": str(tool), "sha256": digest(tool), "versionExit": version.returncode},
    "recorder": {"path": str(pathlib.Path(__file__).relative_to(ROOT)), "sha256": digest(pathlib.Path(__file__))}}
(stage / "input.json").write_text(json.dumps(metadata, indent=2) + "\n")
start = time.monotonic()
with (stage / "stdout.txt").open("wb") as out, (stage / "stderr.txt").open("wb") as err:
    completed = subprocess.run(argv, cwd=ROOT, stdout=out, stderr=err)
result = {"exitCode": completed.returncode, "durationSeconds": time.monotonic() - start,
    "stdoutSha256": digest(stage / "stdout.txt"), "stderrSha256": digest(stage / "stderr.txt")}
(stage / "result.json").write_text(json.dumps(result, indent=2) + "\n")
sys.stdout.buffer.write((stage / "stdout.txt").read_bytes())
sys.stderr.buffer.write((stage / "stderr.txt").read_bytes())
print(json.dumps({"stage": str(stage), **result}), flush=True)
sys.exit(completed.returncode)
