#!/usr/bin/env python3
"""Record the Rust evaluator identity without altering existing command receipts."""
import datetime
import hashlib
import json
import pathlib
import subprocess

stage = pathlib.Path(__file__).resolve().parent / "rust-tool-identity-before-green"
stage.mkdir(exist_ok=False)
tool = pathlib.Path("/home/charl/.quint/rust-evaluator-v0.6.0/quint_evaluator")
argv = [str(tool), "--version"]
result = subprocess.run(argv, capture_output=True)
(stage / "stdout.txt").write_bytes(result.stdout)
(stage / "stderr.txt").write_bytes(result.stderr)
record = {"observedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "path": str(tool), "sha256": hashlib.sha256(tool.read_bytes()).hexdigest(),
    "argv": argv, "exitCode": result.returncode,
    "stdoutSha256": hashlib.sha256(result.stdout).hexdigest(),
    "stderrSha256": hashlib.sha256(result.stderr).hexdigest(),
    "scope": "Observed after original RED and before GREEN runtime; RED receipt remains unchanged."}
(stage / "identity.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
print(result.stdout.decode(), end="")
print(result.stderr.decode(), end="")
