# Luna V12 source-attributed semantic delta

Status: complete bounded navigation delta. It is source attribution, not security, formal, product, ledger, or target certification.

## Predicate and input verification

Falsifiable predicate: every new node and edge cites one exact staged record from the frozen 28-record input, with the frozen byte length and SHA256, a precise source location, and wording that attributes the record without upgrading its evidence scope.

The input freeze is `11402fda8a5df207542386e8be8e77f84cff766dd530692251e812948538c087` (28 records; 121478 bytes). Every staged record’s length and SHA256 matched the freeze. The frozen public branch publication commit is `19246bff2112ca0bcff45ddab344b947e71146d4`. The parent graph pin is `79861b3988b68b30d8319ac8ad93b0fbeea793623f285d5d4390d8d52a60eb2c`. Only listed parent anchors were used for ID linking; the full parent graph was not read. Narrative Markdown records were read through EOF. JSON records were parsed fully with Python’s standard library. One captured stdout record received hash/size verification only.

## Result

The delta contains 22 nodes, 12 source-cited edges, an identical `links` alias, and zero hyperedges. Frozen R0 outputs and manifest are preserved unchanged under `revision-0/`; the preserved R0 manifest SHA256 is `a8e72de5eaaacf06ef7229ce9926d2a002229dd6751224dc166fc22acaf3c214`. Each citation endpoint was checked against the frozen staged-path/hash map; every edge endpoint resolves to a new node or exact V11 anchor ID.

The mapped topics are scoped P3 placement and publication, the separate 160/196/35 requirement partition and full planning guard record, separately attributed PR63 Rust and PR64 Quint normal cohorts and reviews, source-profile inventory, Preprod public configuration/genesis observations, Cardano CLI DATA-ONLY metadata, reference HEAD provenance limits, and the Graphify version observation.

## Identity and usage

Requested author identity/effort: `gpt-6-luna`, high. Actual provider identity, actual model identity, effort, token usage, and cost were not independently observed and are recorded as null. No external model or nested agent was invoked for this bounded task.

## Limits

The graph attributes existing Opus review language and adds no security or cryptographic judgment. Root-recorded placement and guard outcomes remain attributed observations; this task did not rerun them. Normal host recursion is described only as a finite program trace and supplies no PCD or K execution claim. The frozen Sherlock cohorts remain distinct. Presence or byte equality is not compilation or correspondence. Preprod fields are publisher observations and do not establish authentication, deployed identity, or finality; the Byron hash-algorithm owner question remains open. The Cardano CLI archives remain compressed and unexecuted. The original42 catalogue provenance gap remains open. The staged Graphify record is dated Scrapling registry metadata reporting 0.9.91; it does not contain or verify the local installed version, and this task did not recheck that tool. Version metadata is not source/safety certification.

The coverage file distinguishes full narrative reads, complete structural JSON parsing, and metadata-only capture treatment. It also lists underlying source trees, compressed captures/archives, raw ledger material, old graphs, and other artifacts that were not read.
