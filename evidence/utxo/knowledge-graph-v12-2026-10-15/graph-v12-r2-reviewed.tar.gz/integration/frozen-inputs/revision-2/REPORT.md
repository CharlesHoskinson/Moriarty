# Luna V12 revision 2: reviewer identity attribution patch

This new revision applies only the three requested `attributes.reviewer` replacements. It does not change review verdicts, evidence scope, source citations, graph topology, aliases, model metadata, or inherited coverage.

R1 is preserved at the parent directory. Its manifest SHA256 is `5c729adc66362e16ff2e3e5459669257d5a4a6118e359a7eba2693fb97c275b2`; its semantic JSON SHA256 is `f968c3bfa42d9a69e6d5a23ce8b7737824a4940d2e4c9347e984ef78722208d3`. Revision 0 remains preserved under `../revision-0/`.

I re-read the three cited staged records through EOF: record 17 (`05be10b40be7a33bb43ef7ce77d7fa9af6ac25df6f9a974028d71edc8cddcbb3`), record 18 (`979cec855d45f4a1cb1685171081d060419aab49a57f9d0af012955f6d58edff`), and record 21 (`ca3633c457d1c3fe54c6ca1a2579b59cf24ae952e291891aff5a0d54f933e1be`). The first record names Opus without stating a version; records 18 and 21 do not state the returned Muse model/provider identity. The revised reviewer strings therefore state only the identity information supported by each cited record.

The semantic JSON differs from R1 at exactly these three leaves: `attributes.reviewer` on `luna_v12_pr63_opus_review_attribution`, `luna_v12_pr63_muse_review_attribution`, and `luna_v12_pr64_muse_review_attribution`. `CHANGES.json` records old and new values and the source pins. The inherited coverage file is byte-identical to R1 and still covers 28 records / 121,478 bytes; all 28 frozen source hashes and byte lengths were checked unchanged.

The patched delta has 22 nodes, 12 edges, 0 hyperedges, and `links` equal to `edges`. No source, candidate, model, or execution artifact was changed or run. This patch makes no security judgment.
