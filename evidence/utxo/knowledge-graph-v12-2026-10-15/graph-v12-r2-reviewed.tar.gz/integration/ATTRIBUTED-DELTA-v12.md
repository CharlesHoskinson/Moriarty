# Exact attributed Luna V12 delta

Exact overlay item JSON follows. Statements, declared metadata and source attributions are retained without integration endorsement.

## nodes

```json
[
  {
    "id": "luna_v12_p3_package_preparation",
    "label": "P3 placement source packet records a reviewed helper candidate and historical UNRUN preparation",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": true,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/01-REPORT.md",
    "source_sha256": "5cce6285d9691132c0d9b7940451fcc444c712ca53d3db3f504ed758daf054b4",
    "source_location": "L1-L61 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The source report describes a standard-library helper prepared for a fixed 15-member Aiken package, with source placement explicitly UNRUN when that report was written; it says the underlying Aiken/native/ledger sources were not interpreted.",
    "context": "The report is an author/source-preparation account. Later actual placement is separately recorded in V12-SRC-05; the historical UNRUN label remains accurate for preparation time.",
    "attributes": {
      "package_members": 15,
      "placement_at_report_time": "UNRUN",
      "underlying_source_interpreted": false
    }
  },
  {
    "id": "luna_v12_p3_original_expectations",
    "label": "P3 expected placement membership was transcribed before helper execution",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": false,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/03-EXPECTATIONS.json",
    "source_sha256": "e2f452deaeab04e9b06e0e7bd452806d8f88ea484304b7cb1db50028799e970f",
    "source_location": "$/frozenBeforeHelperExecution; $/sourceManifestSha256; $/files",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The expectations JSON says it was frozen before helper execution and lists 15 relative destination files tied to source manifest SHA256 5c5dc86d04e0ed0ba93e35d5fa45fd0a256f8f2492f5667f7d3883e8a7055d7f.",
    "context": "This attributes the record’s expectation and pin. It does not itself establish that placement occurred or that any Aiken code builds.",
    "attributes": {
      "expected_files": 15,
      "manifest_sha256": "5c5dc86d04e0ed0ba93e35d5fa45fd0a256f8f2492f5667f7d3883e8a7055d7f"
    }
  },
  {
    "id": "luna_v12_p3_root_observed_placement",
    "label": "Root result records one ordinary placement of 15 files",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": false,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/05-RESULT.json",
    "source_sha256": "2422c56b0dd398399839bf006bca9fe723f80b2987d3f2c03f9fa0c8ea69ef0e",
    "source_location": "$/status; $/actualToolResult; $/attempts; $/checks; $/actualPackageBytes; $/scope",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The result JSON records ROOT_OBSERVED_ORDINARY_PLACEMENT_PASS: one attempt, exit code 0, 15 package files totaling 898891 bytes, all listed output/input/receipt consistency checks true, and no mismatches or changed inputs.",
    "context": "This is a root-recorded ordinary filesystem result in the exact packet. Its own scope excludes build, proof, ledger and acceptance; the exit is attributed as a tool-result observation, not independently reproduced here.",
    "attributes": {
      "attempts": 1,
      "retries": 0,
      "files": 15,
      "package_bytes": 898891,
      "mismatches": 0,
      "aiken_build": false
    }
  },
  {
    "id": "luna_v12_p3_result_review",
    "label": "Result review adopts only the attributed placement record with stated trust limits",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": true,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/07-REPORT.md",
    "source_sha256": "1feb7dc9153dc1cb2e43e6443d60ef5e36f523bf03c50b96e596fa4a936aa88a",
    "source_location": "L1-L46 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The reviewer reports no blocking finding in the limited nonsecurity scope and conditions its verdict on root-recorded filesystem and hash observations; it says it did not rerun the helper or independently inspect the filesystem.",
    "context": "Attributed review verdict only. No Aiken, security, cryptographic, native, ledger, proof or target-qualification approval is represented.",
    "attributes": {
      "review_scope": "nonsecurity source-and-result",
      "independent_execution": false,
      "blocking_findings": 0
    }
  },
  {
    "id": "luna_v12_p3_scoped_adoption",
    "label": "Placement packet describes scoped preparation and preserves omitted-source and build limits",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": true,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/08-README.md",
    "source_sha256": "fa87e5b95ac8c14deecb33781d4aafcb3a89f0671ab637c7c1af0c79fc49e53c",
    "source_location": "L1-L11 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The README describes the packet as reviewed file-placement preparation; the 15 Aiken source files are omitted, no Aiken/Rust compile or proof/ledger/Preprod settlement is recorded, and settlement acceptance remains open.",
    "context": "The staging freeze separately pins publication commit 19246bff2112ca0bcff45ddab344b947e71146d4 as context for this packet. The publication reference does not expand the README’s stated evidence scope.",
    "attributes": {
      "omitted_aiken_sources": true,
      "build_or_settlement": false,
      "scope": "placement preparation only"
    }
  },
  {
    "id": "luna_v12_p3_publication_review",
    "label": "Publication review calls the packet publishable within placement scope",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": true,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/09-REPORT.md",
    "source_sha256": "e41510c832aa8089e2bab1500e47b28ac9c2e631d2b97661fa3bc2c92f14ebd1",
    "source_location": "L1-L29 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The review calls the exact packet publishable as ordinary nonsecurity build preparation, while recording trust in root’s manifest/hash observations and limitations in receipt binding, local-path disclosure, and brittle absolute links.",
    "context": "The review explicitly excludes security, cryptographic, Aiken, native, ledger, compatibility, and Preprod judgment. Those are attributed exclusions, not new conclusions.",
    "attributes": {
      "verdict": "publishable within stated scope",
      "trusts_root_observations": true,
      "identified_editorial_or_binding_notes": 5
    }
  },
  {
    "id": "luna_v12_sherlock_consumer_repair",
    "label": "Requirement consumer repair keeps 160 canonical, 196 held, and 35 separate clauses",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": true,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/10-REPORT.md",
    "source_sha256": "9db7905354d9889b53c1b1982f26ecd978f9c71abea677c7b745ce9d8d9ae802",
    "source_location": "L1-L41 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The report describes a separate validated Sherlock registry in the existing planning guard: 160 canonical rows, 196 held headings, and 35 mandatory separate functional clauses; all 35 remain open, specified-unexecuted, and implementation-unassessed.",
    "context": "These counts describe discovery/planning membership and guard partitioning, never a completion fraction or acceptance denominator. The report preserves versions and states newer source versions remain observed-upstream-pending-integration.",
    "attributes": {
      "canonical": 160,
      "held": 196,
      "separate": 35,
      "all_separate_open": true,
      "acceptance_fraction": false
    }
  },
  {
    "id": "luna_v12_sherlock_full_guard_record",
    "label": "Full planning guard result records exit zero for metadata verification",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": false,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/12-FULL-GUARD-RESULT.json",
    "source_sha256": "a092601a3df2a98e00c717edc937e88249d88921ba7c73d461064cd8aeb0d1c4",
    "source_location": "$/actualCommand; $/exitCode; $/stdoutSha256; $/scope",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The result JSON records one full read-only planning metadata verifier run with exit code 0 and a captured stdout hash; its scope says all new functional clauses remain OPEN/PENDING_OPUS and no financial, security, native, ABI2, proof, ledger, target or implementation acceptance follows.",
    "context": "The stdout itself is a separate 929-byte metadata-only record (V12-SRC-13); this node attributes only the parsed receipt fields and does not claim a fresh rerun.",
    "attributes": {
      "exit_code": 0,
      "attempts": 1,
      "scope": "planning metadata verifier only",
      "new_clauses": "OPEN/PENDING_OPUS"
    }
  },
  {
    "id": "luna_v12_sherlock_guard_review",
    "label": "Muse review attributes scoped PASS to the actual full planning-guard result",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": true,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/14-REPORT.md",
    "source_sha256": "a7c84e86bfcd7b9f43e9e9f2f29427b7151333df74ea6e3714a876dc639bceab",
    "source_location": "L1-L10 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The review records PASS_SCOPED for the later actual whole-guard run: it says the run is internally consistent with the unchanged, previously reviewed candidate within the stated runner-trust limit, and accepts root’s faithful transcription from tool chunk 7c7952.",
    "context": "This is the later actual-result review, distinct from the earlier pre-integration source review in record 11. The reviewer says it did not recompute hashes, rerun the guard, or independently observe an OS-level stdout file or process trace; no security or product acceptance is attributed.",
    "attributes": {
      "verdict": "PASS_SCOPED",
      "subject": "actual whole-guard result",
      "trust_limit": "root-recorded faithful transcription/tool chunk 7c7952",
      "independent_rerun": false
    }
  },
  {
    "id": "luna_v12_pr63_rust_normal_cohort",
    "label": "PR63 record attributes finite host Rust comparison for N07 and N08",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": false,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/16-RESULT.json",
    "source_sha256": "23eae3899f6d31c423b4aea2a4ad1fae551adfcc1489dd7a54a81d7266b6d194",
    "source_location": "$/status; $/profile; $/actual_result; $/rust_test_functions; $/normal_programs; $/literal_fuel_prefixes; $/new_cases; $/limitations",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The result projects a captured-local sherlock-k-a/1 normal cohort: N07 and N08, 31 Rust test functions, eight normal programs and 216 literal fuel prefixes; N07 records 321 after 38 charged steps and N08 records 2 after 82 charged steps.",
    "context": "Old six-program evidence is a separate cohort, not a combined invocation. The result explicitly leaves K execution, the expanded Quint instance, formal correspondence, constraints, B semantics, native proof and stagenet acceptance open.",
    "attributes": {
      "profile": "sherlock-k-a/1",
      "new_cases": [
        "N07",
        "N08"
      ],
      "tests": 31,
      "normal_programs": 8,
      "literal_prefixes": 216,
      "cohort": "PR63 normal Rust"
    }
  },
  {
    "id": "luna_v12_pr63_opus_review_attribution",
    "label": "Opus review record attributes its scoped verdict on N07 and N08",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": true,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/17-OPUS-REVIEW.md",
    "source_sha256": "05be10b40be7a33bb43ef7ce77d7fa9af6ac25df6f9a974028d71edc8cddcbb3",
    "source_location": "L1-L110 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The Opus-authored review records APPROVE_SCOPED_NORMAL_SOURCE_AND_RESULTS and explicitly limits itself to static review; it grants no native authority or Candidate B acceptance and makes no formal-refinement, constraint, circuit, Quint-extension, ledger or stagenet claim.",
    "context": "This node reports the named reviewer’s written verdict only and performs no new security interpretation.",
    "attributes": {
      "reviewer": "Opus (version not stated in cited record)",
      "verdict": "APPROVE_SCOPED_NORMAL_SOURCE_AND_RESULTS",
      "static_only": true
    }
  },
  {
    "id": "luna_v12_pr63_muse_review_attribution",
    "label": "Muse review record attributes nonsecurity approval for exact normal Rust cohort",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": true,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/18-MUSE-REVIEW.md",
    "source_sha256": "979cec855d45f4a1cb1685171081d060419aab49a57f9d0af012955f6d58edff",
    "source_location": "L1-L40 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The Muse-authored review records a nonsecurity APPROVE for the exact N07/N08 typed programs, literal tables and supplied host result; it expressly excludes circuit, constraint, formal-refinement, native, stagenet and parent roadmap acceptance.",
    "context": "This is attribution of the review record; hashes and execution were not independently rechecked in this V12 task.",
    "attributes": {
      "reviewer": "Muse (returned model/provider identity not stated in cited record)",
      "verdict": "APPROVE",
      "scope": "nonsecurity exact cohort"
    }
  },
  {
    "id": "luna_v12_pr63_recursive_factorial_scope",
    "label": "N08 self-recursive host trace does not evidence recursive PCD or K execution",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": true,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/15-README.md",
    "source_sha256": "148ea5ccad362278c5fd720655bf42515393a9b5452ffcfbafe1eb5806177871",
    "source_location": "L1-L22 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The README describes N08 as named self-recursive factorial two in finite normal host evidence and explicitly leaves K execution, Lean correspondence, full B semantics, native proof and stagenet acceptance open.",
    "context": "The word recursive here describes the recorded host program case only; no recursive proof construction or correspondence theorem is attributed.",
    "attributes": {
      "case": "N08",
      "host_program": "self-recursive factorial",
      "k_execution": false,
      "recursive_pcd_evidence": false
    }
  },
  {
    "id": "luna_v12_pr64_quint_normal_cohort",
    "label": "PR64 record attributes separate deterministic TypeScript Quint cohort",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": false,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/20-RESULT.json",
    "source_sha256": "c6f571828ae79d8e9e7e52d16885ce8e310a1203a3bf1a716b4299dda83ca994",
    "source_location": "$/status; $/profile; $/observations; $/new_tests_passed; $/literal_source_counts; $/limitations",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The result projects a separate PR64 normal cohort: Quint typecheck exit 0, 126 passing deterministic TypeScript tests for N07/N08, 122 state rows, 120 charged edges, 124 published fuel prefixes and 250 static literal comparisons.",
    "context": "The six-program 98-test receipt remains separate and was not rerun; the 126 tests are not a combined 224-test invocation. K execution, formal theorem, B, native proof and stagenet remain open.",
    "attributes": {
      "profile": "sherlock-k-a/1",
      "new_cases": [
        "N07",
        "N08"
      ],
      "tests": 126,
      "state_rows": 122,
      "charged_edges": 120,
      "fuel_prefixes": 124,
      "static_comparisons": 250,
      "cohort": "PR64 Quint"
    }
  },
  {
    "id": "luna_v12_pr64_muse_review_attribution",
    "label": "Muse review attributes scoped normal Quint approval",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": true,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/21-RESULT-MUSE-REVIEW.md",
    "source_sha256": "ca3633c457d1c3fe54c6ca1a2579b59cf24ae952e291891aff5a0d54f933e1be",
    "source_location": "L1-L11 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The Muse review records APPROVE_SCOPED_NORMAL_QUINT_SOURCE_AND_RESULTS and says the publication supersedes the earlier source-only UNRUN status for these exact test bytes; it preserves separate cohort scope and excludes K execution, correspondence, security, B, native and parent milestone judgment.",
    "context": "The review explicitly says it did not read the retained 1.8 MB readback and relies on its stated digest and root replay.",
    "attributes": {
      "reviewer": "Muse (returned model/provider identity not stated in cited record)",
      "verdict": "APPROVE_SCOPED_NORMAL_QUINT_SOURCE_AND_RESULTS",
      "readback_independently_read": false
    }
  },
  {
    "id": "luna_v12_sherlock_source_inventory",
    "label": "Full-integration inventory finds six baseline Sherlock files present and six newer paths separate",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": false,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/23-full-integration-sherlock-source-inventory-20261015.json",
    "source_sha256": "f303a42eb880aedc0e22d04e411cd6cbcd01d706ca933856425dc91294720149",
    "source_location": "$/baselineModuleRows; $/newerUpstreamCommit; $/additionalNewerNamespacePaths; $/qualification",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The inventory reports all six baseline Sherlock module paths present and byte-equal to the pinned merge source in full-integration; it lists six additional paths at newer upstream commit 85d825ea6b04fd5713ebf23b72526532f67c4925 as a separate namespace requiring review/integration.",
    "context": "The record says presence and byte equality are not compilation or constraint/ledger correspondence. The Core70 frozen comparison is a distinct profile recorded separately in V12-SRC-22.",
    "attributes": {
      "baseline_files": 6,
      "baseline_all_present_and_equal": true,
      "newer_paths": 6,
      "newer_commit": "85d825ea6b04fd5713ebf23b72526532f67c4925",
      "compilation_established": false
    }
  },
  {
    "id": "luna_v12_frozen_core70_profile",
    "label": "Root verification preserves the frozen Core70 comparison scope separately",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": false,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/22-ROOT-DATA-VERIFICATION.json",
    "source_sha256": "96c3232da42c424fa90b253453fd0bcd38e5f9b94b3644baf82e832fef246146",
    "source_location": "$/frozenCoreByteComparisons; $/scope",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The root data-verification JSON records a frozen Core byte-comparison collection and limits its scope to public-file parsing, decompression, hashing and Git show; it states that no supplied model/native code ran and supplies no proof, ABI2 or settlement acceptance.",
    "context": "The frozen Core comparison profile is not the six-file full-integration inventory or the newer six-path namespace. This node reports metadata scope only.",
    "attributes": {
      "comparison_rows": 70
    }
  },
  {
    "id": "luna_v12_preprod_public_sources",
    "label": "Preprod retrieval record captures public configuration and genesis responses",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": false,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/24-RETRIEVAL-RECEIPTS.json",
    "source_sha256": "8a59f56e0c588d5728d00b02b1cf8bdd301fd5736168af990ddcd27dc73ef087",
    "source_location": "$/tool; $/scope; $/rows",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The retrieval receipt lists public static HTTPS responses for Preprod configuration and genesis data, including successful config and genesis retrieval statuses; the stated scope treats fields as publisher reports and claims no network authentication or deployed-software qualification.",
    "context": "A raw public response is a source observation, not authenticated chain state or finality.",
    "attributes": {
      "tool": "Scrapling Fetcher 0.4.15",
      "successful_config_and_genesis_rows": 5,
      "network_authentication": false
    }
  },
  {
    "id": "luna_v12_preprod_projection_limits",
    "label": "Source projection reports config fields while preserving the Byron owner question",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": false,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/25-SOURCE-PROJECTION.json",
    "source_sha256": "1cbac2a476f77a637e8d187107ae81c11e1fd1753dfe6e91a6c4eadf714428be",
    "source_location": "$/publisherConfigFields; $/publisherShelleyFields; $/rawByteComparisons; $/scope",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The projection records publisher-stated Preprod configuration/genesis fields, says the newer raw genesis bytes match earlier captures, and preserves the earlier Byron raw-hash/config discrepancy as an owner question.",
    "context": "The record explicitly does not qualify a hash algorithm, authenticate live network state, identify deployed software, establish finality, or authorize ledger action.",
    "attributes": {
      "manifest_files_checked": 8,
      "mismatches": 0,
      "raw_genesis_matches_prior": true,
      "byron_owner_question": "preserved",
      "authenticated": false
    }
  },
  {
    "id": "luna_v12_cardano_cli_archive_metadata",
    "label": "Cardano CLI release packet remains compressed and unexecuted",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": false,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/26-DATA-ONLY-MANIFEST.json",
    "source_sha256": "d377357aef11ca775082e8fa06849d16b6cf4a0e5646e91ce0da622f2fdfd50c",
    "source_location": "$/tag; $/files; $/limitations",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The DATA-ONLY manifest records Cardano CLI release/archive metadata, including a 24,057,685-byte binary archive, and says no installation, extraction, execution, SDK, signing, key, proof, ledger query or transaction occurred.",
    "context": "Metadata inventory does not imply archive contents or source interpretation; signature/build provenance and target compatibility remain unassessed in that record.",
    "attributes": {
      "tag": "cardano-cli-11.3.1.0",
      "binary_archive_bytes": 24057685,
      "extracted": false,
      "executed": false,
      "installed": false
    }
  },
  {
    "id": "luna_v12_reference_head_observation",
    "label": "Reference HEAD observation does not close original42 provenance gap",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": false,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/27-OBSERVATION.json",
    "source_sha256": "5988c9d941bb7c1ea65575e590cdbf96bcf3bcc809fc3f59dd98d327a20b4452",
    "source_location": "$/repositories; $/qualification",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The observation records public HEAD/main references for two repositories and states that HEAD/main cannot prove absence across all history, branches or supplementary sources; the original42 catalogue provenance gap remains open and no rows are invented.",
    "context": "This is a source-reference observation only, not semantic, security, absence, coverage or acceptance evidence.",
    "attributes": {
      "repositories": 2,
      "original42_gap": "open",
      "source_execution": false
    }
  },
  {
    "id": "luna_v12_graphify_version_observation",
    "label": "Public package registry reports Graphify version 0.9.91",
    "file_type": "semantic",
    "_origin": "semantic_delta",
    "semantic_review_performed": false,
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/28-GRAPHIFY-VERSION-OBSERVATION.json",
    "source_sha256": "57008000a176eed797ad63efe4d14c2ac65b2006631811f7af2ba1b1961dee96",
    "source_location": "$/tool; $/status; $/reportedLatestVersion; $/retrievedAt; $/scope",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The staged registry observation records HTTP 200 for the public Graphify package metadata and reports latest version 0.9.91.",
    "context": "Record 28 is registry metadata only; it does not contain or verify a local installed-version observation. Version metadata alone supplies no source, safety or toolchain certification.",
    "attributes": {
      "reported_registry_version": "0.9.91",
      "status": 200,
      "local_version_verified": false,
      "certifies_source_or_safety": false
    }
  }
]
```

## edges

```json
[
  {
    "id": "luna_v12_placement_expected_by",
    "source": "luna_v12_p3_original_expectations",
    "target": "luna_v12_p3_package_preparation",
    "relation": "documents_expected_layout",
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/03-EXPECTATIONS.json",
    "source_sha256": "e2f452deaeab04e9b06e0e7bd452806d8f88ea484304b7cb1db50028799e970f",
    "source_location": "$/files; $/ordinaryExpectedBehavior",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The expectations record lists the exact 15-file layout that the source report says the helper targets.",
    "context": "Source-attributed relationship; not runtime acceptance."
  },
  {
    "id": "luna_v12_placement_result_follows_packet",
    "source": "luna_v12_p3_root_observed_placement",
    "target": "luna_v12_p3_package_preparation",
    "relation": "later_result_for",
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/05-RESULT.json",
    "source_sha256": "2422c56b0dd398399839bf006bca9fe723f80b2987d3f2c03f9fa0c8ea69ef0e",
    "source_location": "$/at; $/status; $/scope",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The result record describes a later placement attempt for the same helper packet and preserves the earlier UNRUN preparation status as historical.",
    "context": "The two records have distinct time and evidence scope."
  },
  {
    "id": "luna_v12_result_review_bounds",
    "source": "luna_v12_p3_result_review",
    "target": "luna_v12_p3_root_observed_placement",
    "relation": "reviews_as_recorded",
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/07-REPORT.md",
    "source_sha256": "1feb7dc9153dc1cb2e43e6443d60ef5e36f523bf03c50b96e596fa4a936aa88a",
    "source_location": "L1-L46 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The review states its conclusions rely on root-recorded observations and do not independently reproduce them.",
    "context": "Review attribution, not independent execution."
  },
  {
    "id": "luna_v12_consumer_scope_resolves_v11_question",
    "source": "luna_v12_sherlock_consumer_repair",
    "target": "luna_v11_sherlock_registration_question_unresolved",
    "relation": "scoped_metadata_resolution_of",
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/10-REPORT.md",
    "source_sha256": "9db7905354d9889b53c1b1982f26ecd978f9c71abea677c7b745ce9d8d9ae802",
    "source_location": "L1-L41 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The repair report describes a separate 35-clause registry and a changed guard partition, providing a scoped metadata resolution to the earlier registration question.",
    "context": "This edge resolves only the discovery/planning membership question; all 35 remain OPEN/PENDING_OPUS and no acceptance is implied."
  },
  {
    "id": "luna_v12_guard_receipt_for_repair",
    "source": "luna_v12_sherlock_full_guard_record",
    "target": "luna_v12_sherlock_consumer_repair",
    "relation": "records_guard_result_for",
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/12-FULL-GUARD-RESULT.json",
    "source_sha256": "a092601a3df2a98e00c717edc937e88249d88921ba7c73d461064cd8aeb0d1c4",
    "source_location": "$/exitCode; $/scope",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The guard receipt records a successful metadata verification result for the integrated planning metadata and preserves the open status.",
    "context": "The result review remains a separate source record."
  },
  {
    "id": "luna_v12_muse_reviews_guard_receipt",
    "source": "luna_v12_sherlock_guard_review",
    "target": "luna_v12_sherlock_full_guard_record",
    "relation": "reviews_actual_result_of",
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/14-REPORT.md",
    "source_sha256": "a7c84e86bfcd7b9f43e9e9f2f29427b7151333df74ea6e3714a876dc639bceab",
    "source_location": "L1-L10 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The Muse report attributes PASS_SCOPED to the later actual whole-guard run as internally consistent within its runner/transcription trust limit.",
    "context": "This review does not say the run remains outstanding; it does not supply product or security acceptance."
  },
  {
    "id": "luna_v12_opus_review_of_rust_cohort",
    "source": "luna_v12_pr63_opus_review_attribution",
    "target": "luna_v12_pr63_rust_normal_cohort",
    "relation": "attributes_review_of",
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/17-OPUS-REVIEW.md",
    "source_sha256": "05be10b40be7a33bb43ef7ce77d7fa9af6ac25df6f9a974028d71edc8cddcbb3",
    "source_location": "L1-L110 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The Opus review identifies the same N07/N08 normal source and result scope.",
    "context": "Verdict remains attributed to Opus’s document."
  },
  {
    "id": "luna_v12_muse_review_of_rust_cohort",
    "source": "luna_v12_pr63_muse_review_attribution",
    "target": "luna_v12_pr63_rust_normal_cohort",
    "relation": "attributes_nonsecurity_review_of",
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/18-MUSE-REVIEW.md",
    "source_sha256": "979cec855d45f4a1cb1685171081d060419aab49a57f9d0af012955f6d58edff",
    "source_location": "L1-L40 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The Muse report reviews the exact N07/N08 normal cohort and its supplied host result.",
    "context": "Does not replace the separate Opus-owned review record."
  },
  {
    "id": "luna_v12_rust_recursion_limit",
    "source": "luna_v12_pr63_recursive_factorial_scope",
    "target": "luna_v12_pr63_rust_normal_cohort",
    "relation": "qualifies_scope_of",
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/15-README.md",
    "source_sha256": "148ea5ccad362278c5fd720655bf42515393a9b5452ffcfbafe1eb5806177871",
    "source_location": "L1-L22 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The README states that the finite host trace does not close K, correspondence, native proof or target acceptance.",
    "context": "No PCD conclusion."
  },
  {
    "id": "luna_v12_quint_muse_review",
    "source": "luna_v12_pr64_muse_review_attribution",
    "target": "luna_v12_pr64_quint_normal_cohort",
    "relation": "attributes_nonsecurity_review_of",
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/21-RESULT-MUSE-REVIEW.md",
    "source_sha256": "ca3633c457d1c3fe54c6ca1a2579b59cf24ae952e291891aff5a0d54f933e1be",
    "source_location": "L1-L11 (complete narrative read through EOF)",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The review describes the exact N07/N08 Quint tests and result record.",
    "context": "Separate from PR63 Rust cohort and the old six-program receipt."
  },
  {
    "id": "luna_v12_inventory_profiles_distinct",
    "source": "luna_v12_sherlock_source_inventory",
    "target": "luna_v12_frozen_core70_profile",
    "relation": "distinguishes_source_profiles",
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/23-full-integration-sherlock-source-inventory-20261015.json",
    "source_sha256": "f303a42eb880aedc0e22d04e411cd6cbcd01d706ca933856425dc91294720149",
    "source_location": "$/qualification",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The inventory states that the full-integration baseline and newer upstream paths are different from the earlier frozen Core scope.",
    "context": "This is a source-inventory distinction, not a compatibility claim."
  },
  {
    "id": "luna_v12_preprod_projection_of_sources",
    "source": "luna_v12_preprod_projection_limits",
    "target": "luna_v12_preprod_public_sources",
    "relation": "projects_metadata_from",
    "source_file": "/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v12-input-staging-20261015/records/25-SOURCE-PROJECTION.json",
    "source_sha256": "1cbac2a476f77a637e8d187107ae81c11e1fd1753dfe6e91a6c4eadf714428be",
    "source_location": "$/manifestFilesChecked; $/rawByteComparisons",
    "evidence_label": "EXTRACTED",
    "attributed_statement": "The projection reports mechanical parsing and byte comparisons for the retrieved public source set.",
    "context": "The projection explicitly limits the fields to publisher statements."
  }
]
```

## hyperedges

```json
[]
```
