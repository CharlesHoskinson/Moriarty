"""Exact attributed V11 + frozen Luna V12 metadata integration; no source execution.

Requires root-supplied READY.json pins. Uses only stdlib and installed Graphify /
NetworkX. All writes remain in this task directory. Never invokes a provider,
shell, network, source/native toolchain, SDK, model checker, or repository action.
"""
from __future__ import annotations

import copy
import hashlib
import json
import resource
import signal
from collections import Counter
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path

BASE = Path('/home/charl/moriarty-eutxo-validation-2026-10-12')
OUT = Path(__file__).resolve().parent
PARENT = BASE / 'luna-graph-v11-integration-20261015'
LUNA_R1 = BASE / 'luna-semantic-pass-v12-20261015'
LUNA = LUNA_R1 / 'revision-2'
INTEGRATION_R1 = BASE / 'luna-graph-v12-integration-20261015'
MUSE_R1_REVIEW = BASE / 'luna-graph-v12-muse-review-20261015/REPORT.md'
ROOT_REPRODUCTION = BASE / 'luna-v12-identity-attribution-reproduction-20261015.json'
FREEZE = BASE / 'luna-graph-v12-input-staging-20261015/FREEZE.json'
PYTHON = '/home/charl/.local/share/uv/tools/graphifyy/bin/python'
PINS = {
    PARENT / 'graphify-out/graph-v11.json': '79861b3988b68b30d8319ac8ad93b0fbeea793623f285d5d4390d8d52a60eb2c',
    PARENT / 'MANIFEST-v11.json': 'b95d8644fc0c500f44d4fd44066564ec5a4e9790cfa4a0ecc29fee5d1b65c475',
    PARENT / 'build_v11_integration.py': '30d73248d187595be2c12876b87620423db587a882c61262aff726f735a51d6c',
    FREEZE: '11402fda8a5df207542386e8be8e77f84cff766dd530692251e812948538c087',
    INTEGRATION_R1 / 'MANIFEST-v12.json': 'afdc4c4f8607d4194f5788fde4ac8ea0c65b5e359e574c38ebc61fdb3ecf911f',
    LUNA_R1 / 'semantic-v12-luna.json': 'f968c3bfa42d9a69e6d5a23ce8b7737824a4940d2e4c9347e984ef78722208d3',
    LUNA_R1 / 'source-coverage-v12.json': '1fc47fce05383d6e674853428f430996bf2968f07db64cf0db318cd9d1674ef4',
    LUNA_R1 / 'REPORT.md': 'e46d559d78fa171de917b43c74ed466e498be0da60d5e2142077540d1b094745',
    LUNA_R1 / 'MANIFEST.json': '5c729adc66362e16ff2e3e5459669257d5a4a6118e359a7eba2693fb97c275b2',
    MUSE_R1_REVIEW: '2ed7f9696ca97875d73068958a0d2074eb38648cabc31f3baef1b4a850bc904d',
    ROOT_REPRODUCTION: 'a8ca1e3a9c3d71b5c90b9405a3a611ec00f3b7a29ffdaecf12d3ca8edf8e0e7f',
}
EXPECTED_LUNA = {'semantic-v12-luna.json', 'source-coverage-v12.json', 'REPORT.md', 'CHANGES.json', 'MANIFEST.json'}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def pin(path):
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def canon(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def noncommunity(node):
    return {key: value for key, value in node.items() if key not in ('community', 'community_name')}


def target(name):
    path = OUT / name
    assert path.resolve().is_relative_to(OUT), 'output escapes assigned directory'
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def write(name, value):
    path = target(name)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    return path


def structure(nodes, edges, hyperedges):
    assert all(isinstance(n, dict) and isinstance(n.get('id'), str) and n['id']
               and isinstance(n.get('label'), str) for n in nodes), 'invalid node'
    ids = {n['id'] for n in nodes}
    assert len(ids) == len(nodes), 'duplicate node ID'
    assert all(isinstance(e, dict) and e.get('source') in ids and e.get('target') in ids
               for e in edges), 'missing edge endpoint'
    eids = [e['id'] for e in edges if 'id' in e]
    assert len(eids) == len(set(eids)), 'duplicate explicit edge ID'
    assert all(isinstance(h, dict) and isinstance(h.get('nodes'), list)
               and all(n in ids for n in h['nodes']) for h in hyperedges), 'missing hyperedge member'
    hids = [h.get('id') for h in hyperedges]
    assert len(hids) == len(set(hids)), 'duplicate hyperedge ID'
    return ids


def main():
    assert OUT == BASE / 'luna-graph-v12-integration-r2-20261015'
    assert datetime.now(timezone.utc) < datetime(2026, 10, 15, 17, 48, tzinfo=timezone.utc), 'deadline passed'
    resource.setrlimit(resource.RLIMIT_CPU, (120, 120))
    resource.setrlimit(resource.RLIMIT_AS, (2147483648, 2147483648))
    signal.alarm(300)
    assert version('graphifyy') == '0.9.91'
    ready = load(OUT / 'READY.json')
    assert ready['status'] == 'READY' and ready['authority'] == 'root explicit frozen Luna hashes'
    assert set(ready['luna_sha256']) == EXPECTED_LUNA
    verified = {}

    def check(path, expected_sha, size=None):
        record = pin(path)
        assert record['sha256'] == expected_sha, f'hash mismatch: {path}'
        if size is not None:
            assert record['bytes'] == size, f'byte count mismatch: {path}'
        if record['path'] in verified:
            assert verified[record['path']] == record
        verified[record['path']] = record

    for path, expected_sha in PINS.items():
        check(path, expected_sha)
    for name, expected_sha in ready['luna_sha256'].items():
        check(LUNA / name, expected_sha)
    r1_manifest = load(INTEGRATION_R1 / 'MANIFEST-v12.json')
    for record in r1_manifest['files']:
        path = Path(record['path'])
        assert path.resolve().is_relative_to(INTEGRATION_R1), 'unexpected R1 preservation path'
        check(path, record['sha256'], record['bytes'])
    r1_checksum = INTEGRATION_R1 / 'MANIFEST-v12.sha256'
    assert r1_checksum.read_text() == PINS[INTEGRATION_R1 / 'MANIFEST-v12.json'] + '  MANIFEST-v12.json\n'
    check(r1_checksum, sha(r1_checksum))
    parent_manifest = load(PARENT / 'MANIFEST-v11.json')
    for record in parent_manifest['files']:
        path = Path(record['path'])
        assert path.resolve().is_relative_to(PARENT), 'unexpected parent manifest path'
        assert not any(s in path.name.lower() for s in ('prompt', 'provider', 'stderr')), 'excluded private/provider output'
        check(path, record['sha256'], record['bytes'])
    luna_manifest = load(LUNA / 'MANIFEST.json')
    manifest_outputs = luna_manifest.get('outputs', luna_manifest.get('files'))
    assert isinstance(manifest_outputs, list), 'missing Luna manifest outputs'
    expected_manifest_names = EXPECTED_LUNA - {'MANIFEST.json'}
    assert {Path(r['path']).name for r in manifest_outputs} == expected_manifest_names
    for record in manifest_outputs:
        path = Path(record['path'])
        if not path.is_absolute():
            path = LUNA / path
        assert path.parent == LUNA and path.name in expected_manifest_names
        check(path, record['sha256'], record['bytes'])

    freeze = load(FREEZE)
    coverage = load(LUNA / 'source-coverage-v12.json')
    sem = load(LUNA / 'semantic-v12-luna.json')
    r1_sem = load(LUNA_R1 / 'semantic-v12-luna.json')
    expected_corrected = copy.deepcopy(r1_sem)
    correction_ids = {
        'luna_v12_pr63_opus_review_attribution',
        'luna_v12_pr63_muse_review_attribution',
        'luna_v12_pr64_muse_review_attribution',
    }
    corrected_by_id = {node['id']: node for node in sem['nodes']}
    changes = []
    for node in expected_corrected['nodes']:
        if node['id'] in correction_ids:
            old = node['attributes']['reviewer']
            new = corrected_by_id[node['id']]['attributes']['reviewer']
            assert old != new, 'required reviewer field was not corrected'
            changes.append({'node_id': node['id'], 'field': 'attributes.reviewer', 'before': old, 'after': new})
            node['attributes']['reviewer'] = copy.deepcopy(new)
    assert len(changes) == 3 and expected_corrected == sem, 'R2 must change exactly the three closed reviewer fields'
    assert (LUNA / 'source-coverage-v12.json').read_bytes() == (LUNA_R1 / 'source-coverage-v12.json').read_bytes(), 'coverage changed in R2'
    luna_changes = load(LUNA / 'CHANGES.json')
    assert [{'node_id': r['node_id'], 'field': r['field'], 'before': r['old_value'], 'after': r['new_value']}
            for r in luna_changes['changed_fields']] == changes, 'Luna CHANGES differs from actual closed patch'
    write('CHANGES.json', {
        'schema': 'closed-three-field-attribution-correction/1', 'changes': changes,
        'all_other_semantic_payloads_exact_r1': True, 'all_28_frozen_source_records_unchanged': True,
        'r1_directory_preservation': 'All 19 manifest-covered outputs and original R1 manifest remain byte-identical; verified before/after build.',
        'r1_graph_manifest': pin(INTEGRATION_R1 / 'MANIFEST-v12.json'),
        'r1_luna_manifest': pin(LUNA_R1 / 'MANIFEST.json'),
        'muse_r1_review': pin(MUSE_R1_REVIEW), 'root_defect_reproduction': pin(ROOT_REPRODUCTION),
        'luna_revision2_changes_pin': pin(LUNA / 'CHANGES.json'), 'luna_revision2_changes': luna_changes,
        'correction_provenance': ready['correction_provenance'],
        'scope': 'Literal identity attribution only; no review-verdict, source, security, native or product judgment.'})
    assert len(freeze['files']) == freeze['fileCount'] == coverage['file_count'] == 28
    assert sum(r['bytes'] for r in freeze['files']) == freeze['totalBytes'] == coverage['total_bytes'] == 121478
    assert coverage['input_freeze_sha256'] == PINS[FREEZE]
    source_pins = {}
    frozen_sources = {}
    for record in freeze['files']:
        path = Path(record['stagedPath'])
        assert path.parent == FREEZE.parent / 'records', 'source not from frozen public staging'
        check(path, record['sha256'], record['bytes'])
        assert str(path) not in source_pins
        source_pins[str(path)] = verified[str(path)]
        frozen_sources[str(path)] = record
    assert len(coverage['files']) == 28
    assert {r['staged_path'] for r in coverage['files']} == set(source_pins), 'coverage source cardinality mismatch'
    assert len({r['staged_path'] for r in coverage['files']}) == 28
    for record in coverage['files']:
        expected = frozen_sources[record['staged_path']]
        assert record['sha256'] == expected['sha256'] and record['bytes'] == expected['bytes']
        assert record['original_path'] == expected['sourceOriginalPath']
        assert isinstance(record['read_mode'], str) and record['read_mode']
        assert isinstance(record['semantic_review_performed'], bool)
    assert sem['edges'] == sem['links'], 'edges and links must be identical aliases, counted once'
    assert sem['input_freeze']['sha256'] == PINS[FREEZE]
    assert sem['parent_graph']['sha256'] == PINS[PARENT / 'graphify-out/graph-v11.json']
    for item in sem['nodes'] + sem['edges'] + sem['hyperedges']:
        assert item['source_file'] in source_pins, 'unfrozen overlay citation'
        assert item['source_sha256'] == source_pins[item['source_file']]['sha256'], 'citation digest mismatch'
    before = [verified[path] for path in sorted(verified)]

    parent = load(PARENT / 'graphify-out/graph-v11.json')
    parent_ids = structure(parent['nodes'], parent['links'], parent['hyperedges'])
    assert (len(parent['nodes']), len(parent['links']), len(parent['hyperedges'])) == (6079, 16805, 1)
    nodes = copy.deepcopy(parent['nodes'] + sem['nodes'])
    edges = copy.deepcopy(parent['links'] + sem['edges'])
    hyperedges = copy.deepcopy(parent['hyperedges'] + sem['hyperedges'])
    ids = structure(nodes, edges, hyperedges)
    extraction = {'schema': 'exact-graphify-merge-input/1',
                  'scope': 'exact V11 plus frozen Luna V12 concatenation; edges/links alias counted once',
                  'parent': pin(PARENT / 'graphify-out/graph-v11.json'),
                  'overlay': pin(LUNA / 'semantic-v12-luna.json'),
                  'nodes': nodes, 'edges': edges, 'hyperedges': hyperedges,
                  'input_tokens': None, 'output_tokens': None}
    write('exact-merge-input-v12.json', extraction)
    for path in [LUNA / name for name in sorted(EXPECTED_LUNA)] + [FREEZE, MUSE_R1_REVIEW, ROOT_REPRODUCTION,
                                                               LUNA_R1 / 'REPORT.md', INTEGRATION_R1 / 'REPORT.md']:
        target('frozen-inputs/' + path.parent.name + '/' + path.name).write_bytes(path.read_bytes())

    import networkx as nx
    from graphify.cluster import score_all
    from graphify.analyze import god_nodes
    from graphify.export import to_html

    topology = nx.DiGraph()
    topology.graph.update(copy.deepcopy(parent.get('graph', {})))
    for node in nodes:
        topology.add_node(node['id'], **{k: copy.deepcopy(v) for k, v in node.items() if k != 'id'})
    for edge in edges:
        topology.add_edge(edge['source'], edge['target'],
                          **{k: copy.deepcopy(v) for k, v in edge.items() if k not in ('source', 'target')})
    topology.graph['hyperedges'] = copy.deepcopy(hyperedges)
    groups = nx.community.louvain_communities(topology.to_undirected(), seed=42, weight='weight')
    communities = dict(enumerate(sorted((sorted(g) for g in groups), key=lambda group: (-len(group), group))))
    labels = {cid: f'Community {cid}' for cid in communities}
    membership = {node: cid for cid, members in communities.items() for node in members}
    assert set(membership) == ids
    cohesion = score_all(topology, communities)
    gods = god_nodes(topology)
    write('graphify-analysis-v12.json', {
        'method': 'pure-Python NetworkX Louvain seed 42, default resolution 1.0; Graphify score_all/god_nodes/to_html',
        'scope': 'derived navigation only; numerical labels are not semantic labels or approval',
        'communities': communities, 'labels': labels, 'cohesion': cohesion, 'god_nodes': gods})
    graph = copy.deepcopy(parent)
    graph['nodes'] = copy.deepcopy(nodes)
    graph['links'] = copy.deepcopy(edges)
    graph['hyperedges'] = copy.deepcopy(hyperedges)
    if 'edges' in graph:
        assert parent['edges'] == parent['links']
        graph['edges'] = copy.deepcopy(edges)
    for node in graph['nodes']:
        node['community'] = membership[node['id']]
        node['community_name'] = labels[membership[node['id']]]
    if 'hyperedges' in graph.get('graph', {}):
        graph['graph']['hyperedges'] = copy.deepcopy(hyperedges)
    graph_path = write('graphify-out/graph-v12.json', graph)
    html_path = target('graph-v12.html')
    assert to_html(topology, communities, str(html_path), community_labels=labels, node_limit=5000, learning_overlay={})

    final = load(graph_path)
    assert structure(final['nodes'], final['links'], final['hyperedges']) == ids
    assert [noncommunity(n) for n in final['nodes']] == [noncommunity(n) for n in nodes]
    assert final['links'] == edges and final['hyperedges'] == hyperedges
    assert final['links'][:16805] == parent['links'] and final['hyperedges'][:1] == parent['hyperedges']
    assert parent_ids <= ids
    old_ui = [n for n in parent['nodes'] if n['id'].startswith('luna_v8_sherlock_uireq_')]
    ui_versions = [n for n in parent['nodes'] if n['id'] in ('luna_v9_9eff_uireq_023', 'luna_v9_9eff_uireq_026')]
    assert len(old_ui) == 35 and len(ui_versions) == 2
    final_by_id = {n['id']: n for n in final['nodes']}
    assert all(noncommunity(final_by_id[n['id']]) == noncommunity(n) for n in old_ui + ui_versions)
    after = [pin(record['path']) for record in before]
    assert before == after, 'frozen input or parent output changed during build'
    modes = dict(Counter(r['read_mode'] for r in coverage['files']))
    semantic_flags = dict(Counter(str(r['semantic_review_performed']).lower() for r in coverage['files']))
    counts = {
        'parent_nodes': 6079, 'parent_links': 16805, 'parent_hyperedges': 1,
        'luna_added_nodes': len(sem['nodes']), 'luna_added_edges': len(sem['edges']),
        'luna_added_hyperedges': len(sem['hyperedges']), 'nodes': len(nodes), 'links': len(edges),
        'hyperedges': len(hyperedges), 'communities': len(communities), 'god_nodes_returned': len(gods),
        'duplicate_node_ids': 0, 'duplicate_explicit_edge_ids': 0, 'duplicate_hyperedge_ids': 0,
        'missing_edge_endpoints': 0, 'missing_hyperedge_members': 0,
        'identical_duplicate_link_records': len(edges) - len(set(map(canon, edges))),
        'self_loop_links': sum(e['source'] == e['target'] for e in edges),
        'directed_pair_records_collapsed_only_in_analysis_topology': len(edges) - topology.number_of_edges(),
        'analysis_topology_edges': topology.number_of_edges(), 'selected_v12_sources': 28,
        'selected_v12_bytes': 121478, 'immutable_files_verified': len(before),
        'historical_uireq_nodes_preserved': 35, 'historical_uireq_source_versions_preserved': 2,
        'new_ast_files': 0, 'new_ast_nodes': 0,
        'inherited_node_source_file_strings': len({n['source_file'] for n in parent['nodes'] if n.get('source_file')}),
        'new_overlay_node_source_file_strings': len({n['source_file'] for n in sem['nodes'] if n.get('source_file')}),
        'all_node_source_file_strings': len({n['source_file'] for n in nodes if n.get('source_file')})}
    checks = {'schema': 'mechanical-graph-v12-check/1', 'all_checks_passed': True,
              'scope': 'structural and hash conservation only; no source-semantic, security or product acceptance',
              'counts': counts, 'parent_node_order_ids_noncommunity_payloads_exact': True,
              'new_luna_node_order_ids_noncommunity_payloads_exact': True,
              'all_link_payloads_multiplicity_order_exact': True, 'all_hyperedges_exact': True,
              'overlay_edges_links_alias_counted_once': True, 'all_citation_pins_match': True,
              'source_coverage_cardinality_exact': True, 'all_immutable_inputs_unchanged': True,
              'historical_uireq_payloads_and_versions_unchanged': True,
              'r2_changes_exactly_three_reviewer_fields': True,
              'all_r1_candidate_outputs_unchanged': True,
              'canonical160_held196_inherited_payloads_unchanged_by_exact_parent_conservation': True,
              'immutable_pins': after, 'graph': pin(graph_path), 'html': pin(html_path)}
    write('MECHANICAL-CHECK-v12.json', checks)
    provenance = {
        'schema': 'graph-v12-model-provenance/1',
        'integration_author_configured_model': 'gpt-6.1-sol', 'integration_author_configured_effort': 'high',
        'integration_actual_returned_identity': None, 'luna_requested_configured_model': 'gpt-6-luna',
        'luna_requested_effort': 'high', 'luna_actual_returned_identity': None,
        'identity_limit': 'Requested/configured identities are distinct from returned runtime identity, unavailable to this task.',
        'input_tokens': None, 'output_tokens': None, 'monetary_cost': None,
        'usage_limit': 'No exposed token/cost receipt; unknown values remain null, not zero.',
        'independent_audit': {'status': 'pending root-owned fresh actual MetaMuse high audit',
                              'requested_model': 'muse-wonder-1.0', 'requested_effort': 'high',
                              'actual_returned_identity': None, 'verdict': None},
        'installed_graphify': version('graphifyy'), 'interpreter': PYTHON,
        'no_provider_or_network_invocation_by_builder': True}
    write('model-provenance-v12.json', provenance)
    receipt = {'schema': 'luna-graph-v12-source-coverage/1',
               'scope': 'bounded public record navigation; source-attributed statements remain unchanged',
               'inherited_v11_coverage_receipt_pin': pin(PARENT / 'source-coverage-receipt-v11.json'),
               'inherited_v11_coverage_receipt': load(PARENT / 'source-coverage-receipt-v11.json'),
               'new_luna_v12_coverage': coverage, 'new_v12_read_modes': modes,
               'new_v12_semantic_review_flags': semantic_flags,
               'integration_read_scope': 'Full structural frozen parent/overlay/control JSON; staged source bodies byte-hashed only. No new source-semantic read or execution.',
               'correction_provenance': ready['correction_provenance'],
               'r2_patch_read_provenance': luna_changes,
               'limitations': ['Selected report/receipt coverage does not imply full underlying source, archive, code or raw-result inspection.',
                              'Metadata-only and partial structural reads retain their exact declared scope; no coverage promotion.',
                              'All inherited source paths, attribution, versions, dissent and limitations remain historical records.',
                              'No source adoption, financial/proof/formal/native/target/security/product/release acceptance.'],
               'counts': counts, 'immutable_pins': after, 'model_provenance': provenance,
               'html': {'aggregated': True, 'node_limit': 5000, 'community_nodes': len(communities),
                        'hyperedges_exact_in_json': True,
                        'limitation': 'Community view omits intra-community hyperedges and collapses topology multiplicity.'}}
    write('source-coverage-receipt-v12.json', receipt)
    delta = ['# Exact attributed Luna V12 delta', '',
             'Exact overlay item JSON follows. Statements, declared metadata and source attributions are retained without integration endorsement.', '']
    for key in ('nodes', 'edges', 'hyperedges'):
        delta += [f'## {key}', '', '```json', json.dumps(sem[key], indent=2, ensure_ascii=False), '```', '']
    target('ATTRIBUTED-DELTA-v12.md').write_text('\n'.join(delta), encoding='utf-8')
    lines = ['# Graphify V12 frozen mechanical integration', '',
             'Candidate for root-owned independent MetaMuse high audit. Implementation, observed checks and acceptance remain separate.', '',
             f"Exact union: {len(nodes)} nodes = 6079 + {len(sem['nodes'])}; {len(edges)} link records = 16805 + {len(sem['edges'])}; {len(hyperedges)} hyperedges = 1 + {len(sem['hyperedges'])}.", '',
             '## Coverage and attribution', '',
             'V12 selects 28 public records / 121,478 bytes. Frozen Luna coverage is retained exactly; inherited V11 coverage and earlier limitations remain embedded unchanged.',
             f'Read modes: `{json.dumps(modes, sort_keys=True)}`. Semantic-review flags: `{json.dumps(semantic_flags, sort_keys=True)}`.',
             'The integrator structurally read whole frozen graph/overlay/control JSON and byte-hashed selected staged bodies. Structural reads do not constitute full code/archive/source-semantic inspection. No metadata-only record is promoted.',
             'ATTRIBUTED-DELTA-v12.md preserves every new node, edge and hyperedge payload. Dates, source proposals, captured ordinary results, review/adoption claims and their limitations remain attributed; this integration supplies no new judgment about their validity.',
             'Only frozen Luna revision-2 is integrated. It changes exactly three reviewer attribute values from R1, with every other semantic payload and the coverage bytes unchanged. CHANGES.json pins the precise values, root reproduction and fresh Muse attribution block. All original R1 graph-candidate outputs remain byte-identical. R0 chronology/citation corrections remain preserved in R1 history; no preserved R0 payload is integrated.',
             'The Luna R2 report and CHANGES record attribute a fresh through-EOF reread of staged records 17, 18 and 21 to Luna for this narrow identity patch. The integrator only hashes those staged bodies and compares structural payloads; this does not create a new integrator semantic read or a new security/review-verdict judgment.',
             f"Node source_file strings: {counts['inherited_node_source_file_strings']} inherited, {counts['new_overlay_node_source_file_strings']} new overlay, {counts['all_node_source_file_strings']} combined. These are path-string counts, not semantic coverage.", '',
             '## Observed mechanical integrity', '',
             'All parent node IDs, order and non-community attributes remain exact; all new Luna node attributes remain exact except community fields. All parent and new links retain payloads, order and multiplicity. Edges/links aliases are counted once. The exact inherited hyperedge and actual new hyperedges are preserved.',
             'All 35 historical UIREQ nodes and both later UIREQ source-version nodes remain exact. Exact inherited-payload conservation also preserves canonical160/held196 history; no requirement is rewritten or closed.',
             f"Unique node/explicit-edge/hyperedge ID and endpoint/member checks pass. Raw identical duplicate links: {counts['identical_duplicate_link_records']}; self-loops: {counts['self_loop_links']}. These records remain preserved.",
             f"Analysis-only directed topology has {topology.number_of_edges()} edges, collapsing {counts['directed_pair_records_collapsed_only_in_analysis_topology']} same-pair records. The raw JSON retains all {len(edges)} link records.",
             f"All {len(before)} frozen public/control/parent-output pins matched before and after build.", '',
             '## Visualization and derived metadata', '',
             f'WARNING: {len(nodes)} nodes exceed 5,000. HTML renders {len(communities)} community nodes. The full raw JSON retains individual records and exact hyperedges. Community display may omit intra-community hyperedges.',
             'Pure-Python NetworkX Louvain uses seed 42 and default resolution 1.0; installed Graphify 0.9.91 supplies cohesion, god-node ranking and HTML export. Numerical community labels describe navigation, not semantics or approval.', '',
             '## Models, cost and acceptance', '',
             'Configured author: gpt-6.1-sol/high. Requested Luna: gpt-6-luna/high. Actual returned identities, input/output token use and monetary cost are unavailable/null. They are not fabricated zeros.',
             'Fresh actual non-author MetaMuse/high audit is pending and owned by root. Opus owns security/cryptographic judgments. This integration changes no financial/formal/proof/native/target/product/release acceptance, U0–U7/M1–M17/MC/SP/G exit, resource counter or native authority.',
             'No source/native/SDK/K/Quint/proof/ledger execution, installation, web/provider/model call, private material access, Git mutation, publication or canonical vault change occurred in this task.', '',
             '## God Nodes', '', '| ID | Label | Degree |', '|---|---|---:|']
    for god in gods:
        lines.append(f"| `{god['id']}` | {god['label'].replace('|', '/')} | {god['degree']} |")
    lines += ['', 'Ranking measures topology, not evidence quality or acceptance.', '',
              '## Community cohesion', '', '| Community | Nodes | Raw cohesion |', '|---|---:|---:|']
    for cid, members in communities.items():
        lines.append(f'| {cid} | {len(members)} | {cohesion[cid]} |')
    lines += ['', '## Reproduction', '',
              'RUN.md records the bounded command. MANIFEST-v12.json covers every task file present at freeze except the manifest itself and its checksum (the checksum pins the manifest); prompt/provider files are excluded. Full raw JSON is mechanically compared, without a claim of model full-semantic inspection.']
    target('GRAPH_REPORT-v12.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    report = [
        '# V12 integration report', '', 'Status: BUILT_AWAITING_ROOT_METAMUSE_AUDIT', '',
        f"Counts: {len(nodes)} nodes; {len(edges)} raw link records; {len(hyperedges)} hyperedges; {len(communities)} communities.", '',
        'Implementation: exact frozen V11 plus exact frozen Luna V12 R2, edges/links alias counted once, only node community metadata recalculated. R2 changes exactly three reviewer fields from R1. All original R1 outputs are preserved; all own writes stay in this new directory.', '',
        'Actual ordinary checks: all mechanical conservation, citation, ID, endpoint, coverage-cardinality and before/after immutable-pin assertions passed in the bounded metadata builder. No source/native toolchain test was executed.', '',
        'Acceptance: fresh actual non-author MetaMuse/high review remains root-owned and pending. No security, source-adoption, native, financial, formal, target, product or release acceptance is made.', '',
        f"Graph SHA256: {sha(graph_path)}", f"HTML SHA256: {sha(html_path)}", '',
        'See MECHANICAL-CHECK-v12.json, source-coverage-receipt-v12.json, model-provenance-v12.json, GRAPH_REPORT-v12.md and ATTRIBUTED-DELTA-v12.md for complete checks and scope. MANIFEST-v12.json pins the report and all own outputs; MANIFEST-v12.sha256 pins the manifest.', '',
        'Falsifiable predicate met mechanically: graph equals the 6079/16805/1 parent plus frozen Luna payloads with only community metadata recalculated. Historical canonical 160/held 196 and UIREQ payloads remain exact. Source coverage is preserved without promotion.', '',
        'Blockers: independent audit/publication are owned by root; no further builder action required.']
    target('REPORT.md').write_text('\n'.join(report) + '\n', encoding='utf-8')
    paths = sorted(path for path in OUT.rglob('*') if path.is_file()
                   and path.name not in ('MANIFEST-v12.json', 'MANIFEST-v12.sha256')
                   and not any(word in path.name.lower() for word in ('prompt', 'provider', 'stderr')))
    manifest = write('MANIFEST-v12.json', {
        'schema': 'frozen-graph-v12-candidate/1', 'scope': 'nonsecurity mechanical integration only',
        'candidate_status': 'awaiting root-owned fresh actual non-author MetaMuse high audit',
        'parent': extraction['parent'], 'overlay': extraction['overlay'], 'counts': counts,
        'manifest_self_exclusion': 'manifest covered by MANIFEST-v12.sha256; checksum cannot self-hash',
        'files': [pin(path) for path in paths]})
    target('MANIFEST-v12.sha256').write_text(sha(manifest) + '  MANIFEST-v12.json\n', encoding='utf-8')
    print(json.dumps({'status': 'BUILT_AWAITING_ROOT_METAMUSE_AUDIT', 'all_checks_passed': True,
                      'counts': counts, 'manifest': pin(manifest), 'graph': pin(graph_path),
                      'html': pin(html_path), 'report': pin(OUT / 'REPORT.md')}, indent=2))


if __name__ == '__main__':
    main()
