# Bounded V12 metadata builder

Run only after root supplies explicit frozen Luna R2 READY hashes in READY.json.
This new directory preserves the entire original R1 directory unchanged.
The builder compares R2 with R1 and permits exactly three reviewer attributes
to change. CHANGES.json retains the actual patch, source reread provenance,
fresh Muse finding and root reproduction. No verdict or source scope changes.

```sh
timeout 300s /home/charl/.local/share/uv/tools/graphifyy/bin/python build_v12_integration.py
```

The builder applies CPU 120 seconds, address space 2 GiB and wall 300 seconds limits.
It reads frozen public JSON and hashes public staged bytes. It writes only this
task directory. Installed Graphify 0.9.91 and NetworkX operate on metadata only.
There are no model/provider, web, source/native, SDK, proof, K/Quint, ledger,
private material, installation, Git or canonical-vault actions.

Effects inspection: Graphify score_all computes topology cohesion; god_nodes
ranks graph degree; to_html aggregates above 5000 nodes and writes local HTML.
Louvain runs in pure Python with seed 42. Raw graph output is written directly
from exact concatenated payloads; analysis topology never replaces raw links.

Falsifiable predicate: 6079 parent nodes/16805 links/one hyperedge plus the exact
frozen Luna overlay, preserving order, multiplicity, attribution and every
non-community attribute. Recalculated communities provide navigation only.

This is a historical bounded build record with deadline 2026-10-15T17:48:00Z;
the builder's deadline assertion requires a separately reviewed revision for
later execution. The original R1 builder and artifacts are not changed.

Root refreshed guarded Moriarty status before delegation. Read-only context is
the full-integration checkout named by TASK.md. No separate native admission
or execution is inferred. Root owns fresh actual MetaMuse audit and publication.
