#!/usr/bin/env python3
"""Own-path stdlib metadata checks; never imports or runs the existing full guard."""
import ast
import copy
import hashlib
import json
import re
import resource
import time
from pathlib import Path

resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
START = time.monotonic()
OUT = Path(__file__).resolve().parent
EXPECT = json.loads((OUT / 'EXPECTATIONS.json').read_bytes())
MANIFEST = json.loads((OUT / 'INPUT-MANIFEST.json').read_bytes())
GUARD = 'openspec/sprints/verify.py'
REGISTRY = 'openspec/sherlock-requirement-crosswalk.json'
SPEC = 'openspec/changes/sherlock-universal-interpreter-design/specs/universal-interpreter/spec.md'
TRACE = 'openspec/changes/sherlock-universal-interpreter-design/traceability.md'
RESULTS = []

def sha(blob):
    return hashlib.sha256(blob).hexdigest()

def require(condition, message):
    if not condition:
        raise SystemExit(message)

def record(name, **fields):
    RESULTS.append({'check': name, 'status': 'pass', **fields})

def load(relative):
    return json.loads((OUT / relative).read_bytes())

for source in MANIFEST['inputs']:
    assert sha((OUT / source['packetPath']).read_bytes()) == source['sha256'], source['packetPath']
record('frozen-packet-input-bytes', inputs=len(MANIFEST['inputs']))
for path, digest in EXPECT['retainedInputDigests'].items():
    assert sha((OUT / path).read_bytes()) == digest, path
record('retained-historical-canonical-held-bytes', files=len(EXPECT['retainedInputDigests']))

canonical_data = load('inputs/baseline/openspec/current-requirement-crosswalk.json')
held_data = load('inputs/baseline/openspec/lineage-held-requirements.json')
canonical = {(row['spec'], row['requirement']): row for row in canonical_data['requirements']}
held = {(row['spec'], row['requirement']): row for row in held_data['requirements']}
assert len(canonical) == EXPECT['canonicalRows'] == 160
assert len(held) == EXPECT['heldRows'] == 196
assert set(canonical).isdisjoint(held)
record('distinct-original-inventories', canonical=160, lineageHeld=196)

registry_blob = (OUT / 'candidate' / REGISTRY).read_bytes()
registry = json.loads(registry_blob)
versions = registry['versions']
base_rows = versions[0]['requirements']
assert [row['id'] for row in base_rows] == EXPECT['requiredIds']
assert versions[0]['sourceSpecSha256'] == EXPECT['baseSourceSpecSha256']
for row, parent in zip(base_rows, EXPECT['baseRowsFromParentInventory']):
    assert row['id'] == parent['id']
    assert row['fullBlockSha256'] == parent['fullBlockSha256']
    assert row['fullBlockBytes'] == parent['fullBlockBytes']
    assert row['requirement'] == parent['heading']
    assert [scenario['heading'] for scenario in row['scenarios']] == parent['scenarioHeadings']
record('independent-parent-inventory-oracle', exactBlocks=35, scenarioMemberships=35)

delta = load('inputs/UIREQ-REQUIREMENT-BLOCK-DELTA.json')
for old, new, source in zip(base_rows, versions[1]['requirements'], delta['rows']):
    assert old['id'] == new['id'] == source['id']
    assert old['fullBlockSha256'] == source['baseBlockSha256']
    assert new['fullBlockSha256'] == source['newBlockSha256']
assert [a['id'] for a, b in zip(base_rows, versions[1]['requirements']) if a['fullBlockSha256'] != b['fullBlockSha256']] == EXPECT['changedLatestIds']
assert versions[1]['sourceSpecSha256'] == versions[2]['sourceSpecSha256']
assert versions[1]['requirements'] == versions[2]['requirements']
record('independent-upstream-delta-oracle', changedIds=EXPECT['changedLatestIds'], latestSpecsIdentical=True)

candidate = (OUT / 'candidate' / GUARD).read_text()
original = (OUT / 'inputs/baseline' / GUARD).read_text()
tree = ast.parse(candidate)
nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'verify_separate_functional_requirements']
assert len(nodes) == 1
function_text = ast.get_source_segment(candidate, nodes[0])
before_injection = candidate.replace(function_text + '\n\nseparate_keys, separate_report = verify_separate_functional_requirements(ROOT, actual_clauses, current_rows, held)\ncurrent_actual = actual - set(held) - separate_keys', 'current_actual = actual - set(held)')
before_injection = before_injection.replace("'requirements': len(actual), 'requirementCountQualification': 'Raw heading cardinalities only; no atomic acceptance denominator or completion fraction', 'canonicalRequirements': len(current_rows), 'lineageHeldRequirements': len(held), 'separateFunctionalRequirements': separate_report,", "'requirements': len(actual),")
assert before_injection == original, 'Existing guard source changed outside additive metadata integration'
record('existing-guard-preserved', originalSha256=sha(original.encode()), candidateSha256=sha(candidate.encode()))
module = ast.Module(body=nodes, type_ignores=[])
namespace = {'require': require, 'json': json, 're': re, 'hashlib': hashlib}
exec(compile(module, '<AST-isolated-candidate-metadata-function>', 'exec'), namespace)
validate = namespace['verify_separate_functional_requirements']

def parsed(blob):
    # Independent line-based parser; the candidate uses regex byte ranges.
    blocks = []
    current = None
    for line in blob.splitlines(keepends=True):
        if line.startswith(b'### Requirement: '):
            if current is not None:
                blocks.append(current)
            current = [line[len(b'### Requirement: '):].rstrip(b'\r\n').decode(), bytearray()]
        if current is not None:
            current[1].extend(line)
    if current is not None:
        blocks.append(current)
    return {(SPEC, name): sha(bytes(block)) for name, block in blocks}

base_blob = (OUT / 'inputs/versions' / registry['integratedVersion'] / 'spec.md').read_bytes()
combined = {(row['spec'], row['requirement']): row['clauseSha256'] for row in list(canonical.values()) + list(held.values())}
combined.update(parsed(base_blob))
old_partition = set(combined) - set(held)
assert set(canonical) != old_partition
assert old_partition - set(canonical) == set(parsed(base_blob))
record('original-partition-defect-reproduced-with-metadata', wronglyAbsorbedSeparateHeadings=35)

def fixture(name, data=None, blob=None):
    root = OUT / 'test-fixtures' / name
    for path, payload in [(REGISTRY, json.dumps(data if data is not None else registry, ensure_ascii=False, indent=2).encode() + b'\n'),
                          (SPEC, base_blob if blob is None else blob),
                          (TRACE, (OUT / 'inputs/baseline' / TRACE).read_bytes())]:
        dest = root / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(payload)
    return root

good = fixture('positive')
keys, summary = validate(good, combined, canonical, held)
assert set(combined) - set(held) - keys == set(canonical)
assert summary['requirements'] == summary['scenarios'] == 35
assert summary['mandatory'] is True and summary['acceptance'] == 'open'
assert summary['securityDecision'] == 'PENDING_OPUS'
record('candidate-exact-partition', canonical=160, lineageHeld=196, separate=summary)

def refuses(name, mutate=None, blob=None, wanted=None, overlap=None, change_actual=None):
    data = copy.deepcopy(registry)
    if mutate:
        mutate(data)
    root = fixture(name, data, blob)
    actual = dict(combined)
    if blob is not None:
        actual = {key: value for key, value in actual.items() if key[0] != SPEC}
        actual.update(parsed(blob))
    if change_actual:
        change_actual(actual)
    current, retained = dict(canonical), dict(held)
    if overlap == 'canonical':
        current[next(iter(keys))] = {}
    if overlap == 'held':
        retained[next(iter(keys))] = {}
    try:
        validate(root, actual, current, retained)
    except SystemExit as error:
        diagnostic = str(error)
        assert wanted is None or wanted in diagnostic, (name, diagnostic)
        record(name, diagnostic=diagnostic)
    else:
        raise AssertionError('Candidate accepted counterexample: ' + name)

refuses('missing-row', lambda d: d['versions'][0]['requirements'].pop(), wanted='identities differ')
refuses('duplicate-row', lambda d: d['versions'][0]['requirements'].append(d['versions'][0]['requirements'][0]), wanted='identities differ')
refuses('changed-registry-scenario', lambda d: d['versions'][0]['requirements'][0]['scenarios'][0].update(fullBlockSha256='0'*64), wanted='Separate scenario differs')
refuses('changed-source-scenario', blob=base_blob.replace(b'only program/declaration/input data differ.', b'only a changed scenario applies.'), wanted='clause differs')
refuses('unregistered-heading', blob=base_blob + b'\n### Requirement: UIREQ-036 Extra\nSHALL be accounted for.\n', wanted='headings differ')
refuses('duplicate-source-heading', blob=base_blob + base_blob[base_blob.index(b'### Requirement: UIREQ-035'):], wanted='heading count differs')
last_start = base_blob.index(b'### Requirement: UIREQ-035')
refuses('removed-source-and-row', lambda d: d['versions'][0]['requirements'].pop(), blob=base_blob[:last_start], wanted='identities differ')
refuses('unknown-version', lambda d: d.update(integratedVersion='unknown'), wanted='Unknown separate')
refuses('overlap-canonical', overlap='canonical', wanted='overlaps')
refuses('overlap-held', overlap='held', wanted='overlaps')
refuses('wrong-current-clause', change_actual=lambda actual: actual.update({(SPEC, base_rows[0]['requirement']): '0'*64}), wanted='clause differs')
refuses('missing-scenario', lambda d: d['versions'][0]['requirements'][0].update(scenarios=[]), wanted='Missing or duplicate')
refuses('duplicate-scenario', lambda d: d['versions'][0]['requirements'][0]['scenarios'].append(d['versions'][0]['requirements'][0]['scenarios'][0]), wanted='Missing or duplicate')
refuses('historical-block-digest-change', lambda d: d['versions'][1]['requirements'][0].update(fullBlockSha256='0'*64), wanted='history or metadata changed')
refuses('invented-owner', lambda d: d['versions'][0]['requirements'][0]['uOwners'].append('U6'), wanted='lacks exact source')
refuses('final-trailing-LF-change', blob=base_blob[:-1], wanted='clause differs')
newer_blob = (OUT / 'inputs/versions' / versions[2]['sourceRevision'] / 'spec.md').read_bytes()
refuses('unadopted-newer-source', blob=newer_blob, wanted='source line differs')
assert set(EXPECT['expectedCounterexamples']) <= {row['check'] for row in RESULTS}

# Verify exact retained input copies again after all fixture mutations.
for path, digest in EXPECT['retainedInputDigests'].items():
    assert sha((OUT / path).read_bytes()) == digest
record('retained-records-preserved-after-counterexamples', files=len(EXPECT['retainedInputDigests']))
elapsed = time.monotonic() - START
assert elapsed < EXPECT['limits']['wallSeconds']
result = {'status': 'pass', 'scope': EXPECT['evidenceScope'],
          'executed': 'Only AST-isolated added metadata function and own stdlib fixtures',
          'fullExistingGuardExecuted': False, 'checks': RESULTS, 'count': len(RESULTS),
          'elapsedSeconds': elapsed, 'limits': EXPECT['limits'],
          'expectationsSha256': sha((OUT / 'EXPECTATIONS.json').read_bytes()),
          'candidateRegistrySha256': sha(registry_blob), 'candidateGuardSha256': sha(candidate.encode())}
(OUT / 'CHECK-RESULT.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
print(json.dumps(result, indent=2, ensure_ascii=False))
