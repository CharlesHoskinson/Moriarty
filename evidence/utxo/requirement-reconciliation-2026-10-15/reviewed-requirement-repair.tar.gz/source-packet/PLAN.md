# Separate functional requirement retention

Author: requested GPT-6.1 Sol high; executing delegated GPT-6.1 Sol high per parent assignment. This artifact is source-only nonsecurity metadata, pending fresh Muse Wonder high review. No provider identity attestation is available inside this process.

Predicate: the existing openspec/sprints/verify.py consumes all 35 Sherlock headings and every scenario as a distinct mandatory registry, while its canonical 160 and held 196 records and their integrity checks remain unchanged. No heading silently disappears and no count becomes an acceptance percentage.

The actual guard currently computes current_actual = actual - held. That erroneously absorbs the deliberately separate Sherlock package. Appending 35 canonical rows contradicts the package; excluding its directory without a validated registry drops obligations. The selected repair validates a separate, pinned companion registry, then subtracts only its verified exact keys before the existing canonical equality check.

- [x] Inspect actual guard, regression consumer, canonical and held registries, Sherlock source and traceability, and supplied version snapshots.
- [x] Freeze independent metadata expectations from the parent inventory, exact pinned input bytes, and explicit source-declared U routes before running candidate checks.
- [x] Add the companion registry and an inline validator function to a private copy of the existing guard; add one navigation paragraph. Keep all historical/canonical/held records byte exact.
- [x] Run only an AST-isolated callable of the added metadata function against own-path fixtures, including removal, duplicates, extra headings, scenario edits and version selection. Do not execute the rest of the guard or security/native tests.
- [x] Produce minimal unified diff, exact input/output manifests, actual logs and report with limits; hand to root for fresh Muse audit and integration.

Edits exist only under this packet. No checkout/index/ref changes, application semantics, owner reassignment, security decisions, full guard claims or native/target acceptance are authorized here. The active ba12 source remains the selected integrated version. Observed 9eff and 30b65 clauses remain separately pinned pending integration; exact source edits/adoption belong to the integrator.
