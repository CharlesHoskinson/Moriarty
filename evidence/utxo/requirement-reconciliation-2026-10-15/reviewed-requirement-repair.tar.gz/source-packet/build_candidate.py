#!/usr/bin/env python3
"""Construct this packet from its explicit public source allowlist; no execution."""
import difflib
import hashlib
import json
import re
import resource
import subprocess
from pathlib import Path

resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
OUT = Path(__file__).resolve().parent
REPO = Path('/home/charl/Moriarty/.worktrees/utxo-pr54-full-integration-20261015')
BASE = OUT.parent
SPEC = 'openspec/changes/sherlock-universal-interpreter-design/specs/universal-interpreter/spec.md'
TRACE = 'openspec/changes/sherlock-universal-interpreter-design/traceability.md'
REGISTRY = 'openspec/sherlock-requirement-crosswalk.json'
GUARD = 'openspec/sprints/verify.py'
README = 'openspec/sprints/README.md'
PINS = [
    ('ba12e4731b0d28dcdf87dc7f11c852511abbab64', REPO),
    ('9effcd8e6f786dbea9d735da8b5f11cbcce88169', BASE / 'upstream-sherlock-9eff-20261015/source'),
    ('30b65d925d1fc8210cb3521e7091aba787a69141', BASE / 'upstream-sherlock-30b65-20261015/source'),
]

def sha(blob):
    return hashlib.sha256(blob).hexdigest()

def save(path, blob):
    path = OUT / path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(blob)

def jbytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()

inputs = []
def capture(source, destination):
    blob = source.read_bytes()
    save('inputs/' + destination, blob)
    inputs.append({'source': str(source), 'packetPath': 'inputs/' + destination,
                   'bytes': len(blob), 'sha256': sha(blob)})
    return blob

retained = [
    'openspec/current-requirement-crosswalk.json',
    'openspec/lineage-held-requirements.json',
    'openspec/lineage-requirement-routing-2026-10-15.json',
    'openspec/sprints/coverage.json',
    'openspec/sprints/legacy-release-gates.json',
    'openspec/sprints/pcd-integration.json',
]
for path in [GUARD, README, TRACE] + retained:
    capture(REPO / path, 'baseline/' + path)
capture(BASE / 'current-language-requirement-index-gap-20261015/INVENTORY.json', 'INVENTORY.json')
capture(BASE / 'current-language-requirement-index-gap-20261015/RECONCILIATION-QUESTION.json', 'RECONCILIATION-QUESTION.json')
capture(BASE / 'upstream-sherlock-9eff-20261015/UIREQ-REQUIREMENT-BLOCK-DELTA.json', 'UIREQ-REQUIREMENT-BLOCK-DELTA.json')

trace_blob = (OUT / 'inputs/baseline' / TRACE).read_bytes()
routes = {}
for line in trace_blob.decode().splitlines():
    if not re.match(r'^\| U[0-7] \|', line):
        continue
    cells = [cell.strip() for cell in line.strip('|').split('|')]
    ids = set()
    for start, end in re.findall(r'(?<!\d)(\d{3})(?:[–-](\d{3}))?', cells[2]):
        ids.update(range(int(start), int(end or start) + 1))
    for number in ids:
        routes.setdefault(number, []).append({'uOwner': cells[0], 'sourceLine': line})

versions = []
for pin, root in PINS:
    if pin == '30b65d925d1fc8210cb3521e7091aba787a69141':
        # The 30b65 local snapshot is a delta and omits this unchanged file.
        # Read this exact public object from the existing local Git object store.
        blob = subprocess.run(['git', 'show', pin + ':' + SPEC], cwd=REPO,
                              check=True, capture_output=True, timeout=30).stdout
        destination = 'inputs/versions/' + pin + '/spec.md'
        save(destination, blob)
        inputs.append({'source': 'git:' + pin + ':' + SPEC, 'packetPath': destination,
                       'bytes': len(blob), 'sha256': sha(blob)})
    else:
        blob = capture(root / SPEC, 'versions/' + pin + '/spec.md')
    headings = list(re.finditer(rb'^### Requirement: ([^\r\n]+)$', blob, re.MULTILINE))
    rows = []
    for n, match in enumerate(headings):
        end = headings[n + 1].start() if n + 1 < len(headings) else len(blob)
        block = blob[match.start():end]
        name = match[1].decode()
        number = int(name[6:9])
        scenarios = list(re.finditer(rb'^#### Scenario: ([^\r\n]+)$', block, re.MULTILINE))
        rows.append({
            'id': name[:9], 'spec': SPEC, 'requirement': name,
            'line': blob[:match.start()].count(b'\n') + 1,
            'fullBlockSha256': sha(block), 'fullBlockBytes': len(block),
            'scenarios': [
                {'heading': scenario[1].decode(),
                 'fullBlockSha256': sha(block[scenario.start():scenarios[i+1].start() if i+1 < len(scenarios) else len(block)]),
                 'fullBlockBytes': len(block[scenario.start():scenarios[i+1].start() if i+1 < len(scenarios) else len(block)])}
                for i, scenario in enumerate(scenarios)
            ],
            'acceptance': 'open', 'scenarioEvidence': 'specified-unexecuted',
            'implementation': 'not-assessed-by-this-registry',
            'disposition': 'mandatory-separate-functional-clause',
            'uOwners': [route['uOwner'] for route in routes.get(number, [])],
            'uOwnerDisposition': 'source-declared' if number in routes else 'unresolved',
        })
    versions.append({'sourceRevision': pin, 'sourceSpecSha256': sha(blob),
                     'disposition': 'integrated-source' if pin == PINS[0][0] else 'observed-upstream-pending-integration',
                     'requirements': rows})

registry = {
    'schema': 'moriarty.separate-functional-requirements/1',
    'spec': SPEC, 'integratedVersion': PINS[0][0],
    'qualification': 'Mandatory distinct functional inventory; canonical160 and held196 remain unchanged. Counts are heading inventories, never atomic acceptance denominators or percentages.',
    'acceptance': 'open', 'adoption': 'pending-fresh-Muse-and-applicable-Opus-review',
    'securityDecision': 'PENDING_OPUS',
    'securityScope': 'Source-attributed metadata only; no security clause interpretation, replacement or owner assignment.',
    'uRoutingSource': {'path': TRACE, 'sha256': sha(trace_blob),
                       'section': 'Existing U owners',
                       'declarations': [line for line in trace_blob.decode().splitlines() if re.match(r'^\| U[0-7] \|', line)],
                       'qualification': 'Exact explicit draft-clause routes only; U6 retains full conformance without assigning numbered UIREQ owners.'},
    'retainedScopeSource': {'path': TRACE, 'sha256': sha(trace_blob),
                           'sections': ['M1–M17 retained capability crosswalk', 'MC, SP and release lineage',
                                        'ZR/MNR lineage, referenced without new security judgments',
                                        'Retained acceptance denominator and open decisions']},
    'versions': versions,
}
registry_blob = jbytes(registry)
save('candidate/' + REGISTRY, registry_blob)

# Expectations are frozen before candidate execution. The supplied parent inventory
# is a separately produced source, not output from the validator under test.
parent = json.loads((OUT / 'inputs/INVENTORY.json').read_bytes())
expectations = {
    'schema': 'moriarty.metadata-expectations/1',
    'frozenBeforeCandidateChecks': True,
    'canonicalRows': 160, 'heldRows': 196,
    'requiredIds': ['UIREQ-%03d' % i for i in range(1, 36)],
    'baseSourceSpecSha256': parent['sourceSpecSha256'],
    'baseRowsFromParentInventory': parent['rows'],
    'changedLatestIds': ['UIREQ-023', 'UIREQ-026'],
    'latestTwoSpecsIdentical': True,
    'retainedInputDigests': {row['packetPath']: row['sha256'] for row in inputs if row['packetPath'].startswith('inputs/baseline/openspec/') and row['packetPath'] not in ['inputs/baseline/' + GUARD, 'inputs/baseline/' + README, 'inputs/baseline/' + TRACE]},
    'expectedCounterexamples': ['missing-row', 'duplicate-row', 'changed-registry-scenario',
                                'changed-source-scenario', 'unregistered-heading',
                                'duplicate-source-heading', 'removed-source-and-row',
                                'unknown-version', 'overlap-canonical', 'overlap-held',
                                'wrong-current-clause', 'missing-scenario', 'duplicate-scenario'],
    'limits': {'cpuSeconds': 60, 'addressSpaceBytes': 1024**3, 'wallSeconds': 120},
    'evidenceScope': 'Only metadata and source-retention behavior; no language/security/finance/native/target acceptance.',
}
save('EXPECTATIONS.json', jbytes(expectations))
save('INPUT-MANIFEST.json', jbytes({'parentHead': '243a8f47325dd26548b6c8bdd793452e3867398a',
                                     'mergeHead': PINS[0][0], 'inputs': inputs}))

function = (OUT / 'validator_function.txt').read_text()
function = function.replace('__REGISTRY_SHA256__', sha(registry_blob))
old = (OUT / 'inputs/baseline' / GUARD).read_text()
needle = "current_actual = actual - set(held)"
replacement = function + "\nseparate_keys, separate_report = verify_separate_functional_requirements(ROOT, actual_clauses, current_rows, held)\ncurrent_actual = actual - set(held) - separate_keys"
assert old.count(needle) == 1
new = old.replace(needle, replacement)
output_needle = "'requirements': len(actual),"
assert new.count(output_needle) == 1
new = new.replace(output_needle, "'requirements': len(actual), 'requirementCountQualification': 'Raw heading cardinalities only; no atomic acceptance denominator or completion fraction', 'canonicalRequirements': len(current_rows), 'lineageHeldRequirements': len(held), 'separateFunctionalRequirements': separate_report,")
save('candidate/' + GUARD, new.encode())
readme_old = (OUT / 'inputs/baseline' / README).read_text()
paragraph = '\nThe mandatory [Sherlock functional registry](../sherlock-requirement-crosswalk.json) is validated separately: all 35 UIREQ clauses, their full-block and scenario digests, version pins and explicit source U routes remain tracked alongside the canonical 160 and held 196 inventories. The guard reports the selected integrated source version and observed upstream versions separately. Missing, changed, duplicate or unregistered Sherlock headings fail validation. These heading counts are not an atomic acceptance denominator; all acceptance remains open and existing U/M/MC/SP/G/ZR/MNR and ACTUS/DeFi obligations retain their source scope.\n'
readme_new = readme_old.replace('## Plan checks\n', paragraph + '\n## Plan checks\n')
save('candidate/' + README, readme_new.encode())
patch = []
for path, before, after in [(GUARD, old, new), (README, readme_old, readme_new), (REGISTRY, '', registry_blob.decode())]:
    patch.extend(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                                      fromfile='a/' + path if before else '/dev/null', tofile='b/' + path))
save('CANDIDATE.diff', ''.join(patch).encode())
print(json.dumps({'status': 'constructed-not-executed', 'candidatePaths': [GUARD, README, REGISTRY],
                  'registrySha256': sha(registry_blob), 'frozenExpectationsSha256': sha(jbytes(expectations))}, indent=2))
