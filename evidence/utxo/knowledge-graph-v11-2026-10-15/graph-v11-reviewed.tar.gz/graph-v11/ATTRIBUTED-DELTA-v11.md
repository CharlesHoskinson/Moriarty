# Exact attributed Luna V11 delta

Frozen source statements and attributes only; no new integration judgments. The raw overlay and exact merge input retain all edges and data.

## luna_v11_abi1_local_unit_adoption

Fresh ABI1 review adopts only scoped local UNIT evidence

The root adoption record adopts the combined legacy ABI1 R/G and A runs only as scoped local UNIT evidence, based on the pinned Opus result review; it excludes generic current compiler, ABI2, proof, authority, physical settlement, ledger, and product acceptance.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/claim-utxo-abi-v1-root-unit-adoption-20261015/ADOPTION.json` / `$/decision; $/scope; $/basis` / SHA-256 `5bb1791d5671dcb6139ab08c3fc0447a23b9cc585853e92c8603344b1f8fc66e`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "decision": "ADOPT_AS_SCOPED_LOCAL_UNIT_EVIDENCE",
  "adoption_scope": "legacy ABI1 local UNIT only",
  "root_byte_checks": 170,
  "verified_rows": 170
}
```

## luna_v11_abi1_actual_result_review_qualifications

ABI1 actual result review with RF1–RF9 qualifications

The Opus report records the actual R/G and A result observations and a scoped UNIT conclusion, while listing nine qualifications including comparator truncation, unexercised liability execution, incomplete notBuilt coverage, coarse pairing proxy, CPU deviation, temporary-directory scope limitation, absent ABI1 proof, unobserved C1 issue acceptance, v0 hazard, and unobserved deployment identity.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/claim-utxo-abi-v1-combined-independent-result-review-20261015/REPORT.md` / `L1-L225` / SHA-256 `5d7331f3396685481172f8ccee58e032468a1d200f44d81311795467b67301af`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "reviewer": "Opus 5.5",
  "scope": "actual ABI1 result review; local UNIT only",
  "qualifications": "RF1–RF9"
}
```

## luna_v11_v0_c0_settle0_funding_exclusion

Opus report excludes v0 C0 and settle0 from funding

The Opus report identifies the compiled v0 C0 hazard and states that C0 and settle0 blueprint entries must never be funded or adopted; this remains an attributed report conclusion.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/claim-utxo-abi-v1-combined-independent-result-review-20261015/REPORT.md` / `L150-L190` / SHA-256 `5d7331f3396685481172f8ccee58e032468a1d200f44d81311795467b67301af`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "reviewer": "Opus 5.5",
  "attribution": "report conclusion; not a new Luna judgment"
}
```

## luna_v11_aiken_c2_actual_abi1_unit_run

Aiken C2 actual ABI1 run reported as passing

The Aiken execution report records one actual run with 15 exit files at zero and 150 passing tests, scoped to the legacy ABI1 Aiken UNIT path; it excludes product or ledger acceptance and states that independent audit was pending at report time.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/claim-utxo-abi-v1-aiken-c2-execution-r2-20261015/REPORT.md` / `L1-L133` / SHA-256 `8681c8ef8f3b42c48f7e0a0341c52e75481f4cae8f6b152b088c2ca9a53f549c`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "result": "reported pass",
  "exit_files": 15,
  "tests": 150,
  "scope": "legacy ABI1 local UNIT"
}
```

## luna_v11_p3_proposed_81_file_source_snapshot

P3 source proposal is an unexecuted 81-file snapshot

The Opus-authored P3 source report describes a proposed 81-file source snapshot and authored/predicted 106 Aiken plus 18 Rust tests; it records no execution or adoption and no Cardano Preprod transaction.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/current-cardano-p3-settlement-authority-source-20261015/REPORT.md` / `L1-L208` / SHA-256 `6bee167ec219ff589228e7b9aa16c2b7bb6dbeb1bfc112534ab6a4be73ece6c4`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "reviewer": "Opus 5.5",
  "source_files": 81,
  "authored_or_predicted_tests": {
    "aiken": 106,
    "rust": 18
  },
  "execution": "not observed"
}
```

## luna_v11_p3s1_votes_one_each_and_deviation

P3S1 proposal votes remain one per mechanism with recorded deviation

The proposal vote record shows each of the nine newly listed mechanisms has one vote only, preserves P3-3 deviation and dissent, and leaves TA1/TA2 proposals unresolved; it records no execution or adoption.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/current-cardano-p3-settlement-authority-source-20261015/candidate/docs/VOTES-P3S1.md` / `L1-L57` / SHA-256 `05d376a0328f2015c396bc3b8a63f22fa20b49b4e525aa900591b2a2fbc8992c`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "new_mechanisms": 9,
  "votes_each": 1,
  "adopted": false
}
```

## luna_v11_p3_open_execution_and_design_items

P3 execution and design items remain listed open

The candidate open-items document leaves execution and design obligations open, including staged /2, Emit, duty, multiparent, recursion/PCD, private handoff, and broad all-20/general requirements.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/current-cardano-p3-settlement-authority-source-20261015/candidate/docs/OPEN-ITEMS.md` / `L1-L43` / SHA-256 `a246c46a64bbea77723679ac164319e5476c35d961b82aa9b4ab8a1ba17180a8`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "execution_items": "O-EX-1..O-EX-8",
  "design_items": "O-D-1..O-D-16"
}
```

## luna_v11_p3_execution_request_is_not_authority

P3S1 execution request is explicitly request-only

The P3S1 execution-request document labels itself request-only rather than authority and leaves requested tests pending; no execution or adoption is recorded.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/current-cardano-p3-settlement-authority-source-20261015/candidate/docs/EXECUTION-REQUEST-P3S1.md` / `L1-L28` / SHA-256 `85ad16262e3f1d9734f3b809377a3436c713bc6d8594a5679e3878d99b3afa93`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "request_only": true,
  "execution": "pending"
}
```

## luna_v11_p3_independent_expectation_freeze_partial_nonblind

P3 expectation freeze declares partial non-blind limits

The independent-expectation freeze declares limits: some outcomes were inferred from notes, H45 was not blind, body/shape conventions came from candidate plan.rs, and synthetic author constants were used for predicates/VK and some structurally compared values.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/current-cardano-p3-independent-source-review-20261015/INDEPENDENT-EXPECTATION-FREEZE.md` / `L1-L114` / SHA-256 `9627edb232050cac9374919fae06a4ed975d0f701adb15478bb1edcb1c9e24bf`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "review_type": "expected-results freeze",
  "blindness": "self-declared non-blind limits",
  "synthetic_author_constants": true
}
```

## luna_v11_p3_postfreeze_comparison_not_final_verdict

Post-freeze comparison contains structural comparisons, not a final verdict

The post-freeze comparison records structural comparisons, including use of synthetic author constants; it is not a final review verdict or adoption record.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/current-cardano-p3-independent-source-review-20261015/POST-FREEZE-COMPARISON.json` / `$/` / SHA-256 `f38df692d23002623dfda5f7e22245642877bf2581989f8b7d3109ae8d319360`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "coverage": "structural comparison",
  "final_verdict": false
}
```

## luna_v11_p3_review_worker_terminal_provider_error

P3 review worker ended with provider session-limit error and no report

The process receipt records a terminal provider session-limit error, exit code 1, and no report; the matching final response is a session-limit message. This is a historical failed worker event, not a vote or current live task.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/current-cardano-p3-independent-source-review-20261015/PROCESS.json` / `$/status; $/exitCode; $/report` / SHA-256 `ad56170cf957239b12f441b7250c2ba87a75c7d84a5ece5ef82d12bedb5c8da1`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "status": "TERMINAL_PROVIDER_SESSION_LIMIT_NO_REPORT_NO_VERDICT",
  "exit_code": 1,
  "report": null
}
```

## luna_v11_generic_repair_delta_partial_source_only

Generic Groth16 repair DELTA is a partial source diff

The DELTA JSON records a partial source diff with 122 unchanged, 4 changed, and 0 added rows among 126; it is not a completed repair, final manifest, harness run, or actual Rust check and cannot close R01/R04.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/current-core-groth16-evidence-repair-source-20261015/DELTA.json` / `$/counts; $/files` / SHA-256 `e2d8dd470f6bd4990f08dc6d318431f442ccb0ad93d2c95b1ca9ce8055ae3987`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "unchanged": 122,
  "changed": 4,
  "added": 0,
  "rows": 126,
  "completion": "partial source only"
}
```

## luna_v11_generic_repair_worker_terminal_provider_error

Generic repair worker ended with provider session-limit error and no verdict

The process receipt records a terminal provider session-limit error, exit code 1, and no report; the matching final response is a session-limit message. This is historical and supplies no verdict.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/current-core-groth16-evidence-repair-source-20261015/PROCESS.json` / `$/status; $/exitCode; $/report` / SHA-256 `6b8eccdc3f859dfd767623ac443dbd435818fb43c9d7ffbedfe3341fea482108`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "status": "TERMINAL_PROVIDER_SESSION_LIMIT_NO_REPORT_NO_VERDICT",
  "exit_code": 1,
  "report": null
}
```

## luna_v11_catalogue_manifest_check_partial

Catalogue v12 manifest check is partial

The verification JSON reports 104 source-manifest entries with one mismatch in logs/COMMANDS.jsonl and 446 result-manifest entries with zero mismatches; this partial hash check is not a complete audit.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/cardano-catalogue-v12-independent-source-result-review-20261015/out_verify_manifests.json` / `$/source_manifest; $/result_manifest` / SHA-256 `2a6088a54b3cb829fea24bb2bd83ffdeb52da16da1ee54128adc42f4f4a90d98`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "source_entries": 104,
  "source_mismatches": 1,
  "result_entries": 446,
  "result_mismatches": 0,
  "complete_audit": false
}
```

## luna_v11_catalogue_review_worker_terminal_provider_error

Catalogue review worker ended with provider session-limit error and no verdict

The process receipt records a terminal provider session-limit error, exit code 1, and no report; the matching final response is a session-limit message. This is a historical failed worker event, not a vote.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/cardano-catalogue-v12-independent-source-result-review-20261015/PROCESS.json` / `$/status; $/exitCode; $/report` / SHA-256 `c8a0f67d8a8c23fc6b3581e0803d3851ee96eae641a3ec7594016ce562ed5f77`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "status": "TERMINAL_PROVIDER_SESSION_LIMIT_NO_REPORT_NO_VERDICT",
  "exit_code": 1,
  "report": null
}
```

## luna_v11_preprod_provider_capture_untrusted_scope

Preprod retrieval receipts are provider-only observations

The retrieval receipts describe public Koios/Scrapling response captures and transport metadata. Their scope is provider-only and does not authenticate consensus, finality, deployment, transaction, or target cost qualification.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/preprod-public-observation-refresh-20261015/RETRIEVAL-RECEIPTS.json` / `$/` / SHA-256 `c4a40d8e52b6a2500771778b50a4a2475b304304ace37610a3df07fbb128e8ed`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "provider_only": true,
  "authenticated": false,
  "finality_established": false,
  "transaction_observed": false
}
```

## luna_v11_preprod_projection_provider_reported_fields

Preprod projection contains provider-reported fields only

The projection contains provider-reported tip/protocol fields and does not establish acceptance or authenticated ledger state.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/preprod-public-observation-refresh-20261015/PROJECTION.json` / `$/` / SHA-256 `4e431bd6a47d620b753d5076d486f278745a88bb4a0957dd8b0746ea779d469a`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "provider_reported_only": true,
  "acceptance": false
}
```

## luna_v11_ledger_primary_source_packet_byte_copies

Ledger phase packet is pinned public-source byte copies only

The manifest lists 25 pinned public primary-source blobs totaling 282,843 bytes. The files are byte copies without semantic review, conformance conclusion, or deployed Preprod version claim.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/cardano-ledger-phase-source-packet-20261015/MANIFEST.json` / `$/files; $/totalBytes; $/capturedAt` / SHA-256 `e47802c8ad123c7293457f383b17344fffff0f42b6335f529a1a8ad8b6025918`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "files": 25,
  "bytes": 282843,
  "semantic_review": "not performed",
  "conformance_acceptance": false
}
```

## luna_v11_sherlock_35_clause_inventory

Sherlock inventory records 35 distinct clauses and 160 existing rows

The read-only inventory reports 35 separate requirement identifiers and 160 existing canonical rows; this is an inventory observation, not a confirmation that the 35 clauses are registered in the index.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/current-language-requirement-index-gap-20261015/INVENTORY.json` / `$/` / SHA-256 `e4519a6d324ba93cbfa776910ca16e9a9fe7ab087910ceb8427ce12b7078ab2c`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "requirement_ids": 35,
  "existing_rows": 160,
  "read_only": true
}
```

## luna_v11_sherlock_registration_question_unresolved

Sherlock registration question remains unresolved

The reconciliation question records that 35 clauses are absent by exact heading comparison while a prior root claim says 35 canonical registrations exist; it records no indexed edits and says not to use 160 as the denominator.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/current-language-requirement-index-gap-20261015/RECONCILIATION-QUESTION.json` / `$/` / SHA-256 `291439de28c7f126a0221efcc80185e88a56e8eacc663e3682da716763096af8`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "heading_comparison": "35 absent",
  "prior_claim": "35 canonical registrations",
  "status": "unresolved",
  "index_edits": false
}
```

## luna_v11_v10_muse_scoped_nonsecurity_disposition

Muse disposition is a scoped nonsecurity integration PASS

The V10 disposition records Muse PASS for a scoped nonsecurity graph integration audit; it does not establish product/source/security adoption and states it did not independently hash/run or fully review the parent graph, raw HTML, or topology. Usage is unknown.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/luna-graph-v10-root-disposition-20261015/DISPOSITION.json` / `$/` / SHA-256 `e2cf25bf12ba6864c2eb9bbbb519bf96ae81a190bcd5278b1aceb194487c250d`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "reviewer": "muse-wonder-1.0-contributor / meta",
  "scope": "scoped nonsecurity integration audit",
  "security_adoption": false,
  "usage": null
}
```

## luna_v11_v10_graph_publication_navigation_only

V10 graph publication receipt scopes publication to navigation

The publication receipt records a remote-verified V10 graph commit on the utxo branch for navigation publication only; it is not prototype acceptance.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v11-input-staging-20261015/sources/GRAPH-V10-PUBLICATION-RECEIPT.json` / `$/commit; $/branch; $/remoteVerified; $/scope` / SHA-256 `7e4764e32449a09de29f63f12ae5a5e43cfb5f5207b3b33ac7ea109468bff83f`.

```json
{
  "attribution_role": "SOURCE_ATTRIBUTION",
  "remote_verified": true,
  "scope": "graph navigation publication only",
  "prototype_acceptance": false
}
```
