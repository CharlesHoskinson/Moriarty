Run from this owned V11 integration directory with the existing interpreter:

```bash
timeout --kill-after=5s 180s prlimit --cpu=120 --as=2147483648 -- /home/charl/.local/share/uv/tools/graphifyy/bin/python build_v11_integration.py
```

The builder verifies exact frozen V10/Luna V11 controls and all 26 selected staged sources, then writes only here. CPU 120 seconds and address space 2 GiB are also limited internally. Pure-Python fixed-seed NetworkX communities and installed Graphify 0.9.91 analysis/HTML require no model, network, installation, native binary or project execution.

Exact JSON preserves every input link record, node attribute except community fields, and hyperedge. The overlay `edges`/`links` alias is checked and counted once. Analysis topology and HTML may collapse node-pair records; JSON retains their full multiplicity and attributions. HTML aggregates communities because the graph exceeds 5,000 nodes.

MANIFEST-v11.json hashes all candidate output files except itself and its detached checksum. MANIFEST-v11.sha256 pins the manifest. Original staged sources and prior outputs are pinned separately in the mechanical and coverage receipts. Re-running writes only this owned directory; compare exact resulting hashes before relying on any previous exact-candidate audit.
