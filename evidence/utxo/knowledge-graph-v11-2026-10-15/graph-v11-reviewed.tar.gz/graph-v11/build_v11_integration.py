"""Mechanical exact V10 + frozen Luna V11 integration. No source execution."""
from __future__ import annotations
import copy
import hashlib
import json
import resource
from collections import Counter
from importlib.metadata import version
from pathlib import Path

BASE=Path('/home/charl/moriarty-eutxo-validation-2026-10-12')
OUT=Path(__file__).resolve().parent
PARENT=BASE/'luna-graph-v10-integration-20261015'
LUNA=BASE/'luna-semantic-pass-v11-20261015'
FREEZE=BASE/'luna-graph-v11-input-staging-20261015/FREEZE.json'
PYTHON='/home/charl/.local/share/uv/tools/graphifyy/bin/python'
PINS={
 PARENT/'graphify-out/graph-v10.json':'3dfa4305cb3ecbe20645c5e34e2b6217bf1026f6dad78ef6507958317c7bf0f8',
 PARENT/'MANIFEST-v10.json':'d5e597b719568eeb5a84d7c9947ad2b8a22151c1e3f96bc5d56a38e26a096420',
 PARENT/'build_v10_integration.py':'11b0769b8917dce23a131736053f2e80a9bb76b56d85a0066be263dec4169ebc',
 LUNA/'semantic-v11-luna.json':'24df2f6b695aa496211b226715c8963565e4e7ea721e6e5129ec20301f6286ce',
 LUNA/'source-coverage-v11.json':'313c6d16d4c22f2c8dbbd69fde3d8d98ed9625880fe87b58a6192392aecd591f',
 LUNA/'REPORT.md':'de3edd19dbde1f502fc7d03a9401fd7823cbb605e22a991375b9dcbd36008131',
 LUNA/'MANIFEST.json':'f4b810ff2f44e126e05be20b6a2369f3d561fb97ea31b6b3d99f83d607c18d1f',
 FREEZE:'432fce0867b71d67f2f9ca41b8ad9812fbcd5daa40a289e1dfce2e77de7a7765',
}

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()

def pin(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def load(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def canon(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def strip(n):return {k:v for k,v in n.items() if k not in ('community','community_name')}
def write(name,x):
 p=OUT/name;assert p.resolve().is_relative_to(OUT)
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');return p

def structure(nodes,edges,hypers):
 assert all(isinstance(n,dict) and isinstance(n.get('id'),str) and n['id'] and isinstance(n.get('label'),str) for n in nodes)
 ids={n['id'] for n in nodes};assert len(ids)==len(nodes),'duplicate node ID'
 assert all(isinstance(e,dict) and e.get('source') in ids and e.get('target') in ids for e in edges),'missing edge endpoint'
 eids=[e['id'] for e in edges if 'id' in e];assert len(eids)==len(set(eids)),'duplicate explicit edge ID'
 hids=[h.get('id') for h in hypers];assert len(hids)==len(set(hids)),'duplicate hyperedge ID'
 assert all(isinstance(h,dict) and isinstance(h.get('nodes'),list) and all(n in ids for n in h['nodes']) for h in hypers),'missing hyperedge member'
 return ids

def main():
 assert OUT==BASE/'luna-graph-v11-integration-20261015'
 resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(2147483648,2147483648))
 assert version('graphifyy')=='0.9.91'
 verified={}
 def check(p,h,size=None):
  r=pin(p);assert r['sha256']==h,f'hash mismatch: {p}'
  if size is not None:assert r['bytes']==size,f'size mismatch: {p}'
  if r['path'] in verified:assert verified[r['path']]==r
  verified[r['path']]=r
 for p,h in PINS.items():check(p,h)
 pm=load(PARENT/'MANIFEST-v10.json')
 for r in pm['files']:check(r['path'],r['sha256'],r['bytes'])
 lm=load(LUNA/'MANIFEST.json')
 for r in lm['outputs']:check(r['path'],r['sha256'],r['bytes'])
 freeze=load(FREEZE);coverage=load(LUNA/'source-coverage-v11.json');sem=load(LUNA/'semantic-v11-luna.json')
 assert len(freeze['files'])==freeze['fileCount']==coverage['file_count']==26
 assert sum(r['bytes'] for r in freeze['files'])==freeze['totalBytes']==coverage['total_bytes']==212724
 assert coverage['input_freeze_sha256']==PINS[FREEZE]
 source_pins={}
 for r in freeze['files']:
  check(r['path'],r['sha256'],r['bytes']);source_pins[r['path']]=verified[r['path']]
 assert len(coverage['files'])==26
 for r in coverage['files']:
  assert source_pins[r['staged_path']]['sha256']==r['sha256'] and source_pins[r['staged_path']]['bytes']==r['bytes']
 assert sem['edges']==sem['links'],'Luna links is an alias of edges, not a second edge collection'
 assert tuple(len(sem[k]) for k in ('nodes','edges','hyperedges'))==(22,15,0)
 assert sem['input_freeze']['sha256']==PINS[FREEZE] and sem['parent_graph']['sha256']==PINS[PARENT/'graphify-out/graph-v10.json']
 for item in sem['nodes']+sem['edges']+sem['hyperedges']:
  assert item['source_file'] in source_pins
  assert source_pins[item['source_file']]['sha256']==item['source_sha256']
 before=[verified[p] for p in sorted(verified)]
 parent=load(PARENT/'graphify-out/graph-v10.json');parent_ids=structure(parent['nodes'],parent['links'],parent['hyperedges'])
 assert len(parent_ids)==6057 and len(parent['links'])==16790
 nodes=copy.deepcopy(parent['nodes']+sem['nodes']);edges=copy.deepcopy(parent['links']+sem['edges']);hypers=copy.deepcopy(parent['hyperedges']+sem['hyperedges'])
 ids=structure(nodes,edges,hypers);assert (len(nodes),len(edges),len(hypers))==(6079,16805,1)
 oldui=[n for n in parent['nodes'] if n['id'].startswith('luna_v8_sherlock_uireq_')];assert len(oldui)==35
 versions=[n for n in parent['nodes'] if n['id'] in ('luna_v9_9eff_uireq_023','luna_v9_9eff_uireq_026')];assert len(versions)==2
 extraction={'schema':'exact-graphify-merge-input/1','scope':'exact frozen V10 + Luna V11 concatenation; edges/links alias counted once',
             'parent':pin(PARENT/'graphify-out/graph-v10.json'),'overlay':pin(LUNA/'semantic-v11-luna.json'),
             'nodes':nodes,'edges':edges,'hyperedges':hypers,'input_tokens':None,'output_tokens':None}
 write('exact-merge-input-v11.json',extraction)
 for p in [LUNA/'semantic-v11-luna.json',LUNA/'source-coverage-v11.json',LUNA/'REPORT.md',LUNA/'MANIFEST.json',FREEZE]:
  target=OUT/'frozen-inputs'/p.parent.name/p.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
 import networkx as nx
 from graphify.cluster import score_all
 from graphify.analyze import god_nodes
 from graphify.export import to_html
 G=nx.DiGraph();G.graph.update(copy.deepcopy(parent.get('graph',{})))
 for n in nodes:G.add_node(n['id'],**{k:copy.deepcopy(v) for k,v in n.items() if k!='id'})
 for e in edges:G.add_edge(e['source'],e['target'],**{k:copy.deepcopy(v) for k,v in e.items() if k not in ('source','target')})
 G.graph['hyperedges']=copy.deepcopy(hypers)
 groups=nx.community.louvain_communities(G.to_undirected(),seed=42,weight='weight')
 communities=dict(enumerate(sorted((sorted(g) for g in groups),key=lambda g:(-len(g),g))))
 labels={cid:f'Community {cid}' for cid in communities};membership={n:cid for cid,group in communities.items() for n in group};assert set(membership)==ids
 cohesion=score_all(G,communities);gods=god_nodes(G)
 write('graphify-analysis-v11.json',{'method':'pure-Python NetworkX Louvain seed 42, default resolution 1.0; Graphify score_all/god_nodes/to_html',
                                  'communities':communities,'cohesion':cohesion,'god_nodes':gods,'labels':labels,
                                  'scope':'derived navigation only; no new semantic relationships or judgments'})
 graph=copy.deepcopy(parent);graph['nodes']=copy.deepcopy(nodes);graph['links']=copy.deepcopy(edges);graph['hyperedges']=copy.deepcopy(hypers)
 for n in graph['nodes']:n['community']=membership[n['id']];n['community_name']=labels[membership[n['id']]]
 if 'hyperedges' in graph.get('graph',{}):graph['graph']['hyperedges']=copy.deepcopy(hypers)
 gp=write('graphify-out/graph-v11.json',graph);hp=OUT/'graph-v11.html'
 assert to_html(G,communities,str(hp),community_labels=labels,node_limit=5000,learning_overlay={})
 final=load(gp);final_ids=structure(final['nodes'],final['links'],final['hyperedges']);byid={n['id']:n for n in final['nodes']}
 assert parent_ids<=final_ids and all(strip(n)==strip(byid[n['id']]) for n in nodes)
 assert final['links']==edges and final['hyperedges']==hypers
 assert all(byid[n['id']]['attributes']==n['attributes'] for n in oldui+versions)
 after=[pin(r['path']) for r in before];assert before==after,'immutable input/output changed'
 modes=dict(Counter(r['read_mode'] for r in coverage['files']))
 assert modes=={'FULL_TEXT_TO_EOF_IN_INDIVIDUAL_BOUNDED_CHUNKS':10,'FULL_STRUCTURAL_JSON_READ':10,'PARTIAL_STRUCTURAL_METADATA_ONLY':6}
 counts={'parent_nodes':6057,'parent_links':16790,'parent_hyperedges':1,'luna_added_nodes':22,'luna_added_edges':15,'luna_added_hyperedges':0,
         'nodes':len(nodes),'links':len(edges),'hyperedges':len(hypers),'communities':len(communities),'god_nodes_returned':len(gods),
         'inherited_uireq_nodes_preserved':35,'inherited_uireq_source_versions_preserved':2,
         'duplicate_node_ids':0,'duplicate_explicit_edge_ids':0,'duplicate_hyperedge_ids':0,'missing_edge_endpoints':0,'missing_hyperedge_members':0,
         'identical_duplicate_link_records':len(edges)-len(set(map(canon,edges))),'self_loop_links':sum(e['source']==e['target'] for e in edges),
         'directed_pair_records_collapsed_only_in_analysis_topology':len(edges)-G.number_of_edges(),'analysis_topology_edges':G.number_of_edges(),
         'new_ast_files':0,'new_ast_nodes':0,'selected_v11_sources':26,'selected_v11_bytes':212724,'immutable_files_verified':len(before),
         'inherited_node_source_file_strings':len({n['source_file'] for n in parent['nodes'] if n.get('source_file')}),
         'new_overlay_node_source_file_strings':len({n['source_file'] for n in sem['nodes'] if n.get('source_file')}),
         'all_node_source_file_strings':len({n['source_file'] for n in nodes if n.get('source_file')})}
 assert counts['identical_duplicate_link_records']==20 and counts['self_loop_links']==5
 checks={'schema':'mechanical-graph-v11-check/1','scope':'mechanical preservation only; no security/formal/acceptance judgment',
         'all_checks_passed':True,'counts':counts,'all_6057_v10_ids_and_noncommunity_attrs_preserved':True,
         'all_22_new_luna_node_noncommunity_attrs_preserved':True,'all_link_records_and_hyperedges_exact':True,
         'all_35_historical_uireq_nodes_declared_digests_and_2_newer_source_versions_unchanged':True,
         'all_new_overlay_source_file_hash_references_match_frozen_inputs':True,
         'luna_edges_and_links_alias_verified_and_counted_once':True,
         'all_frozen_inputs_and_parent_manifest_outputs_unchanged':True,'immutable_pins':after,'graph':pin(gp),'html':pin(hp)}
 write('MECHANICAL-CHECK-v11.json',checks)
 receipt={'schema':'luna-graph-v11-source-coverage/1','scope':'bounded exact source-attributed graph integration candidate',
          'graphify_version':version('graphifyy'),'interpreter':PYTHON,'integration_author_configured_model':'gpt-6.1-sol','integration_author_configured_effort':'high',
          'luna_requested_configured_model':'gpt-6-luna','luna_requested_effort':'high','luna_actual_returned_identity':None,
          'identity_limit':'Explicit requested/configured identities are distinct from unobservable returned runtime identity.',
          'inherited_v10_coverage_receipt_pin':pin(PARENT/'source-coverage-receipt-v10.json'),
          'inherited_v10_coverage_receipt':load(PARENT/'source-coverage-receipt-v10.json'),
          'new_luna_v11_coverage':coverage,'new_v11_read_modes':modes,
          'integration_read_scope':'Whole frozen V10/overlay JSON structural reads and coverage/manifests/builder. The 26 staged source bodies were byte-hashed only. No new semantic extraction or candidate/raw-source audit; no pinned ledger blob or provider/private body read.',
          'counts':counts,'immutable_pins':after,'input_tokens':None,'output_tokens':None,'token_cost':None,
          'token_cost_limit':'Token usage and monetary cost were not exposed; no zero-cost assertion.',
          'html':{'aggregated':True,'node_limit':5000,'community_nodes':len(communities),'full_json_retains_exact_hyperedge':True},
          'acceptance':'unreviewed candidate awaiting fresh actual Muse Wonder high full inline builder/delta/coverage audit; no product acceptance',
          'limits':['No model call, network, installation, AST extraction, source execution, test run, native binary, key/cache/SDK/VM/proof/ledger action or Git mutation.',
                    'Frozen records only; no later live source/review status or requirement guard finding incorporated.',
                    'Luna claims/results remain source-attributed; historical source versions and dissent remain unchanged.',
                    'No canonical vault/repository change, source adoption, target qualification or release.']}
 write('source-coverage-receipt-v11.json',receipt)
 delta=['# Exact attributed Luna V11 delta','', 'Frozen source statements and attributes only; no new integration judgments. The raw overlay and exact merge input retain all edges and data.','']
 for n in sem['nodes']:
  delta += [f"## {n['id']}",'',n['label'],'',n['attributed_statement'],'',f"Source: `{n['source_file']}` / `{n['source_location']}` / SHA-256 `{n['source_sha256']}`.",'','```json',json.dumps(n.get('attributes',{}),indent=2,ensure_ascii=False),'```','']
 (OUT/'ATTRIBUTED-DELTA-v11.md').write_text('\n'.join(delta),encoding='utf-8')
 lines=['# Graphify V11 frozen mechanical integration','',
        'Exact union: frozen V10 plus frozen Luna V11. This candidate awaits a fresh actual Muse Wonder high nonsecurity audit. No security, cryptographic, formal, source-adoption, product or release judgment is made.','',
        f"{len(nodes)} nodes, {len(edges)} exact link records, {len(hypers)} exact hyperedge; {len(communities)} communities and {len(gods)} returned god nodes.",'',
        '## Sources and coverage','',
        'V11 has 26 frozen records / 212,724 bytes. Luna records 10 text records individually read through EOF, 10 full structural JSON reads and six partial structural/metadata reads. This is selected public report/receipt coverage, not whole-project or full candidate source/raw-result coverage.',
        f'Exact read modes: `{json.dumps(modes,sort_keys=True)}`.',
        'The integrator structurally read frozen graph/overlay JSON and byte-verified staged sources. It performed no fresh semantic extraction. PROCESS records remain metadata-only; provider bodies/private content and the 25 ledger-packet source blobs were not read or normatively accepted.',
        'Prior coverage is embedded unchanged and separate in source-coverage-receipt-v11.json: V7 partial/byte-only coverage, V8 Luna 23 full plus 10 partial/safe reads over 33 sources, V9 r1 coverage over 39 files / 419,946 bytes, and V10 coverage over 21 files / 184,796 bytes. New source reads do not relabel inherited coverage.',
        'Luna was requested/configured as gpt-6-luna high; actual returned identity is unavailable/null. Integration configured model: gpt-6.1-sol high. Input/output tokens and monetary cost are unavailable/null, not zero.',
        f"Node source_file strings: {counts['inherited_node_source_file_strings']} inherited, {counts['new_overlay_node_source_file_strings']} in V11, {counts['all_node_source_file_strings']} combined; these are path-string counts rather than semantic read coverage.",'',
        '## Mechanical integrity and visualization','',
        'All 6,057 V10 node IDs/non-community attributes and all 22 new Luna payloads are exact. All inherited links, 15 new links, multiplicities, source attributes and the hyperedge are retained. The overlay edges/links fields are identical aliases and are counted once. No new semantic relation was added.',
        'All 35 historical UIREQ clauses, statuses, routes and declared full-block digests remain unchanged, as do the two later UIREQ-023/026 source-version nodes. Old source paths/hashes retain their historical scope.',
        f"Duplicate node/explicit-edge/hyperedge IDs and missing endpoints/members: zero. Preserved identical duplicate links: 20; preserved self-loops: five. Analysis topology collapses {counts['directed_pair_records_collapsed_only_in_analysis_topology']} same-pair records; JSON retains every one of the {len(edges)} raw link records.",
        f"All {len(before)} bounded frozen input/control/parent-output pins were verified before and after build. Parent files remain byte-identical.",
        f"WARNING: {len(nodes)} nodes exceed the 5,000-node HTML limit. HTML aggregates {len(communities)} community nodes; complete JSON retains individual nodes and the exact hyperedge. Intra-community hyperedges can be omitted from the aggregate display.",
        'Communities use fixed-seed pure-Python NetworkX Louvain; installed Graphify 0.9.91 provides cohesion, god-node ranking and HTML. Community labels are mechanical navigation, not claim acceptance or new semantic relationships.','',
        '## Attributed scope and chronology','',
        'ATTRIBUTED-DELTA-v11.md reproduces every new Luna source statement and its exact attributes. P3 source proposals and 106+18 test counts remain prediction-only; nine new-mechanism first votes do not establish implemented authority, ABI2 compilation, current proof or physical Preprod settlement.',
        'The frozen ABI1 review/adoption statements retain local legacy UNIT-only scope, RF1..RF9 v0 never-fund restrictions, C1 no-issue-proof and open SD1. No broader source/runtime/target approval is inferred.',
        'The three quota-stopped Opus jobs are terminal without REPORT or verdict. Their partial source/review work remains unaccepted; DELTA alone does not close R01/R04. No substitute reviewer or judgment is supplied.',
        'Public provider observations remain unauthenticated/unqualified target metadata. The 25 ledger files are copy-only at this freeze. Canonical registration of the 35 requirements remains unresolved at the freeze; later live Sol findings/candidates are excluded. Published graph V10 e092 is navigation evidence, not prototype acceptance.',
        'All 20 pattern families, general compiler and U/M/MC/SP/G, PCD/private/multiparent and actual physical/Preprod gaps remain open as attributed.','',
        '## God Nodes','', '| ID | Label | Degree |','|---|---|---:|']
 for g in gods:lines.append(f"| `{g['id']}` | {g['label'].replace('|','/')} | {g['degree']} |")
 lines += ['', 'God-node ranking measures topology, not evidence quality or approval.','', '## Community cohesion','', '| Community | Nodes | Raw cohesion |','|---|---:|---:|']
 for cid,members in communities.items():lines.append(f'| {cid} | {len(members)} | {cohesion[cid]} |')
 lines += ['', '## Frozen candidate and reproduction','',
           'MANIFEST-v11.json pins the repeatable builder, RUN.md, copied frozen input controls, exact merge input, graph, HTML, report, attributed delta, source/coverage receipt, analysis and mechanical check. MANIFEST-v11.sha256 pins that manifest. The receipts separately pin all 26 original staged sources and parent manifest outputs.',
           'No canonical wiki/repository write, source adoption, publication, merge, native action or release occurred. Fresh actual Muse nonsecurity audit remains pending.']
 (OUT/'GRAPH_REPORT-v11.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 paths=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name not in ('MANIFEST-v11.json','MANIFEST-v11.sha256','BUILD-LOG.txt'))
 mp=write('MANIFEST-v11.json',{'schema':'frozen-graph-v11-candidate/1','scope':'nonsecurity mechanical integration only',
          'candidate_status':'awaiting fresh actual Muse Wonder high full inline builder/delta/coverage audit',
          'parent':extraction['parent'],'overlay':extraction['overlay'],'counts':counts,'files':[pin(p) for p in paths]})
 (OUT/'MANIFEST-v11.sha256').write_text(sha(mp)+'  MANIFEST-v11.json\n',encoding='utf-8')
 print(json.dumps({'counts':counts,'new_v11_read_modes':modes,'manifest':pin(mp),'graph':pin(gp),'html':pin(hp),
                   'report':pin(OUT/'GRAPH_REPORT-v11.md'),'receipt':pin(OUT/'source-coverage-receipt-v11.json'),'all_checks_passed':True},indent=2))

if __name__=='__main__':main()
