# Vote on independent review B and the first-prototype ABI

Voter: `claude-opus-5-5` (high effort), the Opus security author of this source candidate, working in a fresh context. I did not write the original candidate or review B. I evaluated both independently against the inspected primary captures:

- Babbage `Utxo.hs` lines 190–429 (`disjointRefInputs`, `validateBadInputsUTxO` over `allInputs`, collateral, `maxTxExUnits`);
- CIP-0031 text, lines 50–219;
- the prior experiment's actual source: `g16/src/*.rs`, `gen_aiken.py`, `make_bundle.py`, the generated `mrg16.ak` generator, `CATALOGUE.v0.json`, `BUNDLE.v0.json`, the catalogue entries and `out/x0/moriref.json`;
- `mori-core` `ir.rs` and `runtime.rs` (value types and liability reads).

Nothing was executed. This vote is a design decision, not an approval of any implementation, including mine.

Labels: **[SF]** source fact, **[INF]** inference, **[PROP]** proposal.

## 1. Votes

| Item | Vote | Consequence |
|---|---|---|
| Approach C: claim-certificate UTxO for run claims, issued by a family-shared Groth16 verifier, with A kept as a control | **AGREE** | With B's vote, this has two agreeing substantive votes and governs this prototype |
| Reference reuse only for universal certificates | **AGREE** (principle) | — |
| Universal certificates minted by C0's Groth16 branch (B §5.1 `claim_kind = 1`, B §5.3 `R_univ_*`) | **DISSENT** (D2) | Unsupported in v0 |
| A mandatory token-authenticated VK registry | **AGREE with B's dissent**: the registry is optional | Per-consumer pinning only; no maintainer admission |
| R1 (circular effects digest) | **AGREE** | Implemented through D1 |
| R2 (no circular context) | **AGREE** | Implemented |
| R3 (spend/reference overlap) | **AGREE** | Implemented; [SF] `disjointRefInputs` is off at protocol version ≥ 11 |
| R4 (consumer-enforced reuse) | **AGREE** | Implemented |
| R5 (holding-script release) | **AGREE + refinement** (D9) | Implemented |
| R6 (one multi-purpose C0 script) | **AGREE + extension** (D7) | Implemented for C0 and S_settle0 |
| R7 (VK in the redeemer, digest pinned by consumers) | **AGREE + clarification** (D11) | Implemented |
| R8 (statement domain separation, verifier-derived scalars) | **AGREE in substance; DISSENT on encoding** (D5) | Flat statement encoding |
| R9 (no withdraw-zero) | **AGREE** | — |
| R10 (three claim classes) | **AGREE** | Labelled everywhere |
| R11 (liability presence) | **AGREE** | Encoded; not exercised by `payment.mori` (D12) |
| R12 (AND with k ∈ {1,2}; not PCD) | **AGREE** | Implemented |
| B §5 ABI as written | **CHANGES_REQUIRED** | D1 is blocking |
| B §6 EARS: PVC-02′, 07′, 08′, 16, 17, 18, 21, 22 | **AGREE** | — |
| B §6 EARS: PVC-19 | **AGREE + clarification** (D11) | — |
| B §6 EARS: PVC-20 | **AGREE**; exercised only at encoding level | — |
| The replacement ABI in `ABI-v0.md` | **PROPOSED**: my vote only | Needs one more substantive agreeing vote before adoption. It is implemented here so that it can be audited, not because it has been adopted |

## 2. Changes and dissent, resolved before code

Each item carries the minimal normative text that the code implements.

### D1. Blocking: the envelope effects and predecessor fields are not proof-bound

B's `EnvV0.pre_datum_hash` and `EnvV0.effects_digest` are absent from B's `StmtV0`. A C0 token therefore attests to "π verified for the payload". It says nothing about the settlement's effects. Anyone can mint a certificate with a real proof and an arbitrary `effects_digest`, and S_settle0 would then accept effects the proof never covered.

**Normative fix:**
- `pre_datum_hash` and `effects_digest` are removed.
- They are replaced by `transition: Option<TransitionV0{pre_state, post_state, effects}>`. It appears in both the envelope and the statement, so the proof covers it. For row P-M1, the circuit constrains every byte of it.
- S_settle0 requires:
  - `pre_state` equals its own datum's `state`;
  - `post_state` equals the continuation datum's `state`;
  - `continuation.last_effects = blake2b_256(effects)`.

This also settles R1 without any digest over mint, fee or change: the thread's value must be carried unchanged.

### D2. Universal certificates are not Groth16 run proofs

A proof of one execution is not a for-all certificate. This is the prior catalogue's own `claimKinds` text [SF `CATALOGUE.v0.json`].

**Normative:** in v0, C0 rejects `claim_kind ≠ 0` at mint and at release. S_settle0 never counts a referenced claim. Universal certificates require a separate issuance class with its own trust model, which is not specified here. The run/universal distinction is kept as a field and a refusal.

### D3. The `predicate_id` and `predicate_version` labels are unauthenticated

Nothing binds these strings. **Normative:** identity is `predicate_digest` alone, the BLAKE2b-256 of the exact catalogue entry bytes. The entry contains the id and version. Slots match on the digest. Both fields are dropped from the envelope and from the slot.

### D4. Context mode must be explicit

B says the catalogue row "decides" the context mode. **Normative:** `EnvV0.context_bound: Bool` decides whether the statement contains `settle_outref`. The circuit fixes the statement's context tag byte as a constant, so a proof verifies only under the row's own mode. A slot's `require_context` checks the flag. `settle_outref` is mandatory for every run claim.

### D5. Statement encoding

B's `blake2b_256(serialiseData(StmtV0))` forces minimal-length CBOR integers and 64-byte chunking into the circuit, which makes the circuit shape depend on the data. **Normative:** `MRG16-PVC-STMT-0` is a flat, injective byte layout (`ABI-v0.md` §3). Its fields are fixed-width or u16-length-prefixed. It adds `claim_kind`, the context tag and the transition tag. The asset name stays `blake2b_256(serialiseData(EnvV0))`, which only scripts and off-chain code compute.

### D6. Composition rule

`Rule{kind, slot_indices}` is reduced to `rule_kind = 0`: AND over all slots, with 1 ≤ |slots| ≤ 2. Exactly one slot has `require_transition`, and that slot must also have `require_context`. OR, k-of-n and DAG remain specified only, as in B §5.4.

### D7. Thread token without a parameter cycle

S_settle0 is itself multi-purpose. Its mint branch is the one-shot thread genesis: the asset name is `blake2b_256(serialiseData(seed))` and the policy is the settle script's own hash. `c0_hash` is a datum field pinned by the thread creator. This is per-consumer policy: anyone relying on a thread must check `c0_hash` and the slots. Thread termination is unsupported in v0.

### D8. Mint redeemer

The mint redeemer is `Issue{vk, proof} | Burn`. The envelope is read from the single C0 output's inline datum, not repeated in the redeemer.

### D9. Release refinement

The spend branch also requires that the input holds exactly one token named `H(datum)`. A refund requires a finite lower validity bound strictly after `expiry`.

### D10. No issuance-time thread reference

B §5.2's `R_thread` check is omitted. Adding it would make C0 depend on S_settle0's datum format. Settlement re-checks `pre_state` against the ledger-held thread datum anyway. This is a dissent from B §5.2 and leaves it to the second vote.

### D11. `setup_class` is an unauthenticated label

No circuit or script can prove how a VK was generated. **Normative:** v0 C0 requires `setup_class = 0`, and the circuit fixes it to 0. PVC-19 can be enforced only through consumer-pinned `vk_digest` values and their admission records. It cannot be enforced through this field.

### D12. Liability presence

The `mori-snapshot-bytes/v0` encoding carries one (present, amount) slot per declared liability: absent = (0, 0), present-zero = (1, 0), following [SF `runtime.rs:425-435`]. `payment.mori` declares no liability, so for P-M1 the slot table is empty. R11 and PVC-20 are therefore exercised only by an encoding self-test, not by an execution.

## 3. Identity and circularity check

| Identity | Defined over | Cycle? |
|---|---|---|
| `predicate_digest` | Catalogue entry bytes; a circuit constant | None: the entry contains no VK, digest or script hash |
| `family_id` | A fixed descriptor string | None |
| `vk_digest` | Compressed VK bytes; free witness bytes in the circuit, supplied by the verifier | None: the circuit never fixes it |
| Admission record | Predicate digest ↦ VK digest | Written after setup; a separate file |
| C0 script hash | C0 code only; the VK arrives in the redeemer | None |
| S_settle0 script hash | Settle code only; `c0_hash` is in its datum | None |
| Context | A pre-existing thread outref | No settlement TxId, redeemer or script-integrity hash appears anywhere in a statement |
| Asset name | `H(EnvV0)` | The envelope does not contain the asset name |

The two statement-digest halves are equality-constrained in the circuit: regions `public-input binding hi/lo`. A prover-side refusal test exercises them. The prior X2/X4 proofs do not cover these statements. Fresh setup and proofs are required.

## 4. What this vote does not decide

It grants no execution, transaction, key, faucet or mainnet authority. It does not claim that the source compiles or is correct. A fresh Opus source audit decides that. `ABI-v0.md` remains PROPOSED until a second substantive agreeing vote.
