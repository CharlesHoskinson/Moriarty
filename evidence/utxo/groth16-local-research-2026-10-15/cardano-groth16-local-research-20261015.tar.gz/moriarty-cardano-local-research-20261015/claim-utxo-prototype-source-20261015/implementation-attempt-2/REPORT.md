# REPORT: claim-UTxO prototype source, implementation attempt 2

Author: `claude-opus-5-5`. The requested effort was high; I cannot observe the effort setting. Date: 2026-10-15.

**Status: SOURCE CANDIDATE FOR REVIEW. Not adopted, not compiled, not tested, not deployed.**

- **ABI.** ABI v0 is PROPOSED. D1–D12 have one vote (the predecessor's `VOTE.md`), and the new details N1–N10 (ABI-v0 §9) have none. Both need a fresh second agreeing vote.
- **Scope.** Class 0 research only. This makes no mainnet, funds, security or ceremony claim.
- **Execution.** I ran nothing: no shell, build, test, proof, setup, key, ledger, network or other-model action. I computed no hashes. Every number in EXPECTED-OUTCOMES is a prediction made by reading the source.

---

## 1. What code exists

Unlike the predecessor attempt, this attempt contains real source:

| Component | Files | Callable entry points |
|---|---|---|
| Aiken ABI library | `source/aiken/lib/pvc/abi.ak` | `statement`, `well_formed`, `envelope_name`, `scalars`, `groth16_verify`, `holds_policy`, `slots_well_formed`, `slot_accepts`, `match_slots`, `u16be`, `len` |
| C0 logic and validator | `lib/pvc/c0.ak`, `validators/c0.ak` | `issue`, `burn_only`, `refund_ok`, `release`; validator `c0` (mint, spend, else) |
| S_settle0 logic and validator | `lib/pvc/settle.ak`, `validators/settle0.ak` | `genesis`, `claim_envelopes`, `settle`; validator `settle0` (mint, spend, else) |
| Aiken tests | `lib/pvc/abi_test.ak` (22 tests), `lib/pvc/context_test.ak` (30 tests) | Fixtures F0/F1; X2 parser regression; UNIT-context positives and refusals |
| Rust X7 | `source/x7/src/{main.rs, abi.rs, relations.rs}` | `x7 abi`, `x7 run`, `x7 setup`, `x7 prove`; relations P-L1 and P-M1; R1CS digest; admission record; claim emission (datum CBOR, asset name, Issue redeemer CBOR); 9 unit tests |
| Catalogue | `source/catalogue/P-L1.v0.json`, `P-M1.v0.json` | Predicate digest = BLAKE2b-256 of the file bytes |
| Scripts | `source/scripts/abi_ref.py`, `gen_x7_aiken.py` | An independent encoder with a comparator; a generator of Aiken vector tests from `x7 run` outputs |

**No placeholders in the claimed parts:**
- There is no always-true verifier, dummy cryptographic check or TODO.
- `groth16_verify` performs the full pairing equation over CIP-0381 builtins on VK and proof bytes from the redeemer.
- The relations use the frozen audited gadgets, unmodified.

**Explicitly not implemented** (refused, or blocked as specified):
- universal certificates
- OR, k-of-n and cross-slot link rules
- thread termination
- ledger asset execution of Moriarty effects
- Preprod transaction building

---

## 2. Implementation of VOTE.md D1–D12

| Item | Where it is implemented |
|---|---|
| **D1** | `transition` is in both the envelope and the statement. P-M1 builds pre, post and effects in-circuit. Every structural byte is a constant, the values are witness bits, and post and effects are computed from them. S_settle0 checks `pre_state = state`, `post_state = continuation.state` and `last_effects = blake2b_256(effects)`. |
| **D2** | `well_formed` requires `claim_kind = 0`, and S_settle0's `claim_envelopes` also checks it. Reference inputs are never read. |
| **D3** | Slots match on (`predicate_digest`, `vk_digest`). There are no id or version label fields. |
| **D4** | `context_bound` selects the statement's context part. The circuit fixes the context tag per row. `settle_outref` is mandatory. |
| **D5** | Flat `MRG16-PVC-STMT-0`. The asset name is `blake2b_256(serialise_data(EnvV0))`. |
| **D6** | AND over 1–2 slots, with exactly one transition slot, and that slot requires context. `well_formed` additionally refuses a transition without context (N4). |
| **D7** | S_settle0 has a one-shot genesis mint branch. `c0_hash` is in the datum. Thread termination is refused. |
| **D8** | The mint redeemer is `Issue{vk, proof} \| Burn`. The envelope is read from the single output's inline datum. |
| **D9** | Release requires exactly one own token named `H(datum)`. A refund needs a finite lower bound strictly after expiry, plus the `refund_vkh` signature (N1). |
| **D10** | There is no issuance-time thread check. Settlement re-checks pre-state. |
| **D11** | `setup_class = 0` is a fixed circuit constant and is required by `well_formed`. Exclusion is enforced only by consumer-pinned VK digests. |
| **D12** | MSB0 has one (present, amount) slot per declared liability. `payment.mori` declares none, so presence is checked only by the Rust encoding self-test `liability_presence_encoding`. |

---

## 3. The prior independent audit: fixes and dissent

| Finding | Handling in this candidate |
|---|---|
| **F1** (script check keyed on `entryName`) | No user label selects any check. The mandatory computation slot is the consumer's `require_transition` slot, pinned in the thread datum by (`predicate_digest`, `vk_digest`). The program digest is a circuit constant of the relation the VK encodes. There are no bundle-chosen links: cross-slot links are unsupported. |
| **F2** (unbound control reuses identity; unpinned catalogue) | Identity is the consumer-pinned VK digest. The predicate digest is the hash of the exact entry bytes and appears in the statement as domain separation. The admission record binds (`predicateDigest`, `r1csDigest`, `vkDigest`). x7 has no control row. Any future control needs its own catalogue entry. |
| **F2: in-circuit relation digest** | **Dissent recorded (ABI-v0 §1).** A digest of the whole R1CS inside that R1CS is a fixed point, and a skeleton digest does not bind the constants. The relation digest is therefore kept out of circuit, in the admission record. No hash fixed point is introduced. |
| **F3** (evidence chain) | EXECUTION-REQUEST records source, input and lockfile hashes before the build and the binary hash before any run. Every generator and assembler step is logged. It uses pipefail, never masks exits, and preserves failures. |
| **F4** (wording) | EXPECTED-OUTCOMES separates what is predicted from what would be observed. Nothing is called "frozen in advance" except this file set, which the root freezes. |
| **F5** (`amount > 0` unexercised) | P-M1 has no ledger adapter, so the R5 vector (amount 0, a labelled DERIVED NEGATIVE) is expected to fail first at `requires amount>0`, predicted at #658. |

---

## 4. New reference: proof-zk-recovery (commit `7f54c35f…`, Apache-2.0)

I read only the selected sources and executed nothing. The details are in ABI-v0 §10.

**Transferred as patterns:**
- The verifier reconstructs the public input from authenticated context (`reconstructPub`).
- A script UTxO without an inline datum fails closed (`scriptDatums`).
- One own-script input per transaction, against double satisfaction (`custodyInputCount == 1`).
- Consume-and-burn spent-state (`ticketBurnedFor`), mapped to C0's burn-on-release rule.
- The payout is bound to a canonical committed encoding (`validateClaim`, `encodeEntitlement`). This is the model for the ledger-integration boundary in §6.

**Different proof shape; not reused:**
- Their verifier is gnark **commitment** Groth16 (BSB22). It uses a 672-byte VK, a 336-byte proof, a Pedersen proof-of-knowledge pairing and an `expand_message_xmd` challenge. Their single public scalar is LE(BLAKE2b-256) mod r.
- Our proofs are arkworks vanilla Groth16. We use two 128-bit big-endian halves, which avoids the mod-r reduction of a 256-bit digest.
- Their VK is a fixed validator parameter. Ours arrives in the redeemer and is pinned by digest per consumer, so one C0 serves a family.
- Commitment support would only matter for a future gnark backend.

**Their deployment claims** (Preview transactions, a CEK cost of about 3.9·10⁹ to 5.5·10⁹ CPU, and the "MPC ceremony") are **author records I did not check**. Their own document states that the setup was single-operator with a fixed beacon. None of it is Preprod qualification for this work.

---

## 5. Owned assumptions

- **A1.** The arkworks 0.4 compressed VK is α ‖ β ‖ γ ‖ δ ‖ u64-LE count ‖ IC points, 488 bytes for two public inputs. The prior audit decoded it this way (§5 of that audit). The test `x2_regression_verifies` checks the parser against it.
- **A2.** Aiken `builtin.serialise_data` equals the Plutus `serialiseData` encoding I implemented in Rust and Python: indefinite-length non-empty lists and 64-byte chunking. E-ABI-3 and E-ABI-R4 test this. On a real ledger, an inline datum given in non-canonical CBOR is re-encoded canonically by `serialise_data`, so off-chain builders must compute asset names from the canonical form.
- **A3.** Groth16 knowledge soundness holds under an honest setup. The research setup is single-party, and the trapdoor is dropped in-process without zeroisation. A third party gains nothing beyond trust in whoever ran the setup.
- **A4.** The hand lowering of `pay` matches moriarty-core/1 on all inputs. Only finite vectors are checked, through E-X7-1 and E-X7-5 against the frozen oracle. This is not a general backend. The generic Moriarty compiler and P2 path is a separate lane.
- **A5.** BLAKE2b-256 collision resistance holds, for asset names, statement digests, the txid link (P-L1) and `last_effects`.
- **A6.** The Aiken stdlib v2.2.0 and compiler v1.1.21 APIs behave as I recalled them. This is the least certain assumption; EXPECTED-OUTCOMES §1 lists the syntax most at risk.
- **A7.** The frozen inputs are byte-identical to the audited snapshot. The root attests this in S1.

---

## 6. Ledger integration needed for real Moriarty settlement

What v0 certifies is that a thread datum moved from snapshot bytes S to S′, recording H(effects), and that a Groth16 proof attests this is `pay(S) = (S′, effects)` under the hand lowering. The thread's **ledger value is unchanged**. This is at most a **unit-control data-transition certificate**, and it must not be reported as Moriarty financial settlement.

Real settlement needs a physical integration that v0 does not have:
1. **Asset identity map.** Each Moriarty `AssetId` (network, issuer, reference, scale) must map to a Cardano (policy, asset name), or to lovelace, with scale handling, inside the relation or a consumer-pinned table.
2. **Custody.** Each Moriarty balance must correspond to value held in script-controlled UTxOs, with conservation checked by the settle script. The upstream analogue is `valueConserved` and the canonical entitlement encoding.
3. **Effect execution.** For every Transfer and Fee effect, the settle script must check that the corresponding ledger value moves between the custody outputs or credentials of `from` and `to`. Liability effects need a ledger representation too.
4. **Authority.** Signatures or intents for debits (Core `intent.rs` limits). None of this is in `pay`'s current statement.
5. **Emit.** A ledger-visible event encoding.

Until (1)–(4) exist and are proved and checked, success may only be stated as "datum transition certified", never as "payment settled".

---

## 7. First blocked boundary

| Boundary | What is blocked |
|---|---|
| **B0 (immediate)** | Nothing has been compiled. The first falsifiable gates are EXECUTION-REQUEST S4 (`cargo build --offline --locked`) and S8 (`aiken check`). S8 additionally needs root authorization for one GitHub fetch of stdlib v2.2.0. Without it, S8, S9, S12 and S13 are BLOCKED, while S0–S7 and S10–S11 can still run. |
| **B1 (after green gates)** | Preprod. There is no transaction builder, collateral or fee handling, wallet, or authorization for fresh Preprod funds. The request deliberately reuses no existing wallets and nothing from the old Midnight campaign. Deploying C0 and S_settle0 (preferably as reference scripts, because of the 16 KiB transaction limit), then genesis, issue, settle and refund, needs a separately authorized transaction-assembly lane. |
| **B2** | A P-M1 claim must be proved after genesis, because it binds the thread outref, while the thread's slots must pin the VK digest before genesis. That forces either a persisted proving key (`x7 setup` / `x7 prove`, which needs private-key authorization) or setup and prove in one process after genesis with a pre-pinned VK. That is impossible without persistence. B2 blocks real context-bound use and is a key-management decision for the root. |
| **B3** | The §6 ledger integration, needed for any financial claim |

---

## 8. Limitations and open items

- **Not addressed** (all stay open, as instructed): all 20 patterns, recursive PCD, private handoff, general obligations, liability execution, ZKIRv3/Midnight correspondence, and the unmerged full language.
- **Composition.** AND over two slots carries no cross-slot binding. P-L1 and P-M1 together prove two independent facts, and nothing ties the amount to the coin.
- **Execution units.** Costs will only come from Aiken's built-in cost model (S8 and S13). A C0 Issue does one pairing check: roughly 2.1·10⁹ CPU in the prior X5 Aiken model, plus statement building and hashing. This is not a ledger measurement.
- **Upstream defences not carried over.** The upstream code rejects identity points explicitly. v0 relies on the uncompress builtins only. Identity points do not break Groth16 soundness, but the upstream rejection could be added after review.
- **Settlement-time verification.** Settlement does not re-verify proofs; it trusts C0 tokens. That is sound only if no token of `c0_hash`'s policy can exist except through Issue, and C0 enforces this. A consumer who pins a wrong `c0_hash` gets no protection.
- **Refund griefing.** Anyone may release a claim by spending its `settle_outref`. For a thread outref, that can only happen inside a full S_settle0 settlement.
- **Unverified baseline.** I did not verify the Moriarty baseline commit or tree. I relied on the root receipt; see SOURCE-SELECTION §E.
