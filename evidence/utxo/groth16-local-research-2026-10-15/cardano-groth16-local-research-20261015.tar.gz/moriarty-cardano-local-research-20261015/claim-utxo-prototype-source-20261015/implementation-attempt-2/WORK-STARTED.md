# WORK-STARTED: claim-UTxO prototype source, implementation attempt 2

Author: `claude-opus-5-5` (requested effort: high; the effort setting is not observable from inside the session).
Date: 2026-10-15.

## Status of inputs

- The predecessor's `VOTE.md` (digest prefix `0456825a…`, as stated by the root) is treated as a **PROPOSED ABI/design only**. Its "implemented" wording described code that was never written, because both of the predecessor's Write calls were denied.
- No Aiken or Rust source existed before this attempt.
- The ABI that this attempt implements (D1–D12) is **PROPOSED**. It has one vote and needs a fresh second agreeing vote before adoption.

## Scope of this attempt (source only)

1. `source/aiken/`: the C0 multi-purpose claim-certificate script (mint `Issue{vk,proof}` / `Burn`, spend release) and the S_settle0 multi-purpose thread script (genesis mint, settle spend). Groth16 verification is done in-script over CIP-0381 builtins, with the scalars derived by the script from the flat statement.
2. `source/x7/`: a Rust X7 crate. It reuses the frozen prior `gadgets.rs` by `#[path]` and adds the rows P-L1 (context-free bytes predicate) and P-M1 (`pay` plus the full transition in the statement), the flat statement encoder, and the envelope CBOR encoder.
3. `ABI-v0.md`: the explicit flat statement and envelope ABI.
4. `EXPECTED-OUTCOMES.md`: spec-only expectations. Nothing is executed.
5. `EXECUTION-REQUEST.json`: exact commands and resource caps, with hash-before-build and `pipefail`.
6. `SOURCE-SELECTION.md`: the manifest. Exact hashes are pending from the root.
7. `REPORT.md`.

## Not done here

No Bash, build, test, proof, setup, key, ledger or network action. No compiled artefacts, hashes or results are claimed.

Class 0 research only. This makes no mainnet, funds or security claim.
