# Expected outcomes (spec-only; nothing has been executed)

Every number below comes from reading the source by hand. None of it is observed. A run falsifies it if the output differs. Any `UNEXPECTED` line, any non-zero exit, or any compile error is a recorded failure, and it is not to be retried silently (see EXECUTION-REQUEST).

**What "pass" can mean.** A pass establishes only what the row says. It is not a ledger, Preprod, security or adoption result.

**Data labels:**

| Label | Meaning |
|---|---|
| UNIT context | A hand-built Transaction in Aiken |
| DECLARED | A settle outref, expiry, refund key or pre-state chosen by the run. Not a ledger observation. |
| DERIVED NEGATIVE | A labelled mutation of frozen bytes or vectors. Not positive ledger data. |

The only ledger-derived bytes are the frozen Preprod body used by P-L1 (E0 provenance, prior audit §6).

---

## 1. Compile gates

| ID | Command (EXECUTION-REQUEST step) | Expected |
|---|---|---|
| G-1 | `cargo build --release --offline --locked` (S4) | Exit 0, using the copied frozen `Cargo.lock` unchanged. Warnings for unused items of the reused `circuit.rs` are expected. |
| G-2 | `cargo test --release --offline --locked` (S5) | Exit 0. 9 tests in `abi::tests` pass. |
| G-3 | `aiken check` (S8) | Exit 0. All tests in `abi_test.ak` and `context_test.ak` pass (§3, §4). |
| G-4 | `aiken build` (S9) | Exit 0, producing `plutus.json` with validators `c0.c0.{mint,spend,else}` and `settle0.settle0.{mint,spend,else}`. The script hashes are recorded, not predicted. |

**Owned uncertainty.** The Aiken source targets compiler v1.1.21 and stdlib v2.2.0. I wrote it without a compiler. These usages are the most likely to need a syntactic fix:
- qualified constructor patterns (`c0_logic.Issue { vk, proof }`);
- `expect` with a bare boolean;
- record update syntax on a function call result (`EnvV0 { ..f0_env(), … }`);
- the `Interval` and `IntervalBound` field names.

A compile failure must be recorded as a failure, then fixed by a new source revision with new hashes. It must not be patched in place.

---

## 2. Rust unit tests (`source/x7/src/abi.rs`, G-2)

| ID | Expectation |
|---|---|
| E-ABI-R1 | `f0_statement`: 120 bytes equal the §7 layout. vk offset 80, payload offset 118, no outref. |
| E-ABI-R2 | `f1_statement`: 161 bytes. Offsets: outref 115, pre 152, post 155, effects 158, payload 161. |
| E-ABI-R3 | `family_and_tag_hex`: ASCII hex as in ABI-v0 §7 |
| E-ABI-R4 | `f0_f1_envelope_cbor`: bytes equal the hand-written CBOR |
| E-ABI-R5 | `long_bytes_are_chunked`: 65 bytes become `5f 5840 … 41 xx ff`; 64 bytes stay definite |
| E-ABI-R6 | `well_formed_refusals`: claim_kind 1, setup_class 1 and transition-without-context are refused |
| E-ABI-R7 | `pay_layout_sizes_and_offsets`: MSB0 is 171 bytes with offsets [13, 59, 107, 153]; MEB0 is 184 bytes with offsets [46, 100, 124, 141, 168]; the P-M1-shaped statement is 733 bytes |
| E-ABI-R8 | `liability_presence_encoding`: absent ≠ present-zero. This exercises R11/PVC-20 **at encoding level only**. |
| E-ABI-R9 | `pay_native_vectors`: the positive post-state is (1,000,000; 999,999,998,999,998; 1,000,000; 2). The refusals report `balance`, `overflow`, `requires` and `requires`. |

---

## 3. Aiken ABI tests (`lib/pvc/abi_test.ak`, G-3)

| ID | Tests | Expected |
|---|---|---|
| E-ABI-1 | `family_and_tag_ascii` | pass |
| E-ABI-2 | `f0_statement_layout`, `f1_statement_layout`, `statement_lengths` (120 and 161) | pass |
| E-ABI-3 | `f0_envelope_cbor`, `f1_envelope_cbor`, `envelope_name_is_hash_of_cbor` | pass. `builtin.serialise_data` matches the hand-written CBOR, which is the same expectation as E-ABI-R4. |
| E-ABI-4 | `f0_f1_well_formed`; refusals `universal_claim_kind_refused`, `setup_class_nonzero_refused`, `transition_without_context_refused`, `foreign_family_refused`, `outref_index_out_of_range_refused`; `u16_overflow_fails` (a `fail` test) | pass |
| E-ABI-5 | `slots_rules`, `slot_matching_on_pinned_pair` | pass |
| E-ABI-6 | `x2_scalars_match_prior_decimals` (74723471684511297101991506385831720568 and 221741901904538666570306144655846571354), `x2_vk_layout_lengths`, **`x2_regression_verifies`**, `x2_regression_statement_bit_flip_rejected`, `x2_regression_ic_count_tampered_fails` (fail), `x2_regression_truncated_proof_fails` (fail) | pass |

**About E-ABI-6.** It reuses the frozen X2 VK, proof and statement. That statement uses the old layout `MRG16-STMT-L-v0`.
- It checks only that the byte-level VK parser (offsets 0/48/144/240, count at 336, IC at 344/392/440) and the scalar derivation reproduce the previously observed X2 verification.
- It is not a P-L1 or P-M1 result.
- If `x2_regression_verifies` fails, the parser offsets or the arkworks VK layout assumption are wrong, and every C0 Issue result is void.

---

## 4. Aiken UNIT-context tests (`lib/pvc/context_test.ak`, G-3)

| ID | Tests | Expected |
|---|---|---|
| E-CTX-1 | `settle_single_transition_ok`, `settle_and_two_slots_ok_either_order` | pass (True) |
| E-CTX-2 | `settle_wrong_post_state_refused`, `settle_wrong_effects_digest_refused`, `settle_pre_state_mismatch_refused`, `settle_claim_for_other_thread_refused`, `settle_referenced_claim_not_counted`, `settle_extra_claim_refused`, `settle_wrong_vk_digest_refused`, `settle_value_changed_refused`, `settle_slots_changed_refused`, `settle_claim_token_mismatch_refused`, `settle_c0_input_without_datum_refused`, `settle_two_thread_inputs_refused` | Each is a `fail` test and passes because evaluation errors |
| E-CTX-3 | `genesis_ok`; `genesis_seed_not_spent_refused`, `genesis_two_transition_slots_refused`, `genesis_no_transition_slot_refused` (fail) | pass |
| E-CTX-4 | `release_with_settle_outref_spent_ok`, `release_refund_after_expiry_ok`; `release_refund_at_expiry_refused`, `release_refund_unbounded_refused`, `release_refund_without_signer_refused`, `release_token_kept_in_output_refused` (each returns False) | pass |
| E-CTX-5 | `issue_universal_claim_kind_refused`, `issue_vk_digest_mismatch_refused`, `issue_name_not_envelope_hash_refused`, `issue_claim_held_elsewhere_refused`, `issue_junk_vk_fails_at_point_decoding` (fail tests); `burn_only_negative` | pass |

These tests do **not** show anything about the ledger: script context translation, ExUnits, fees, collateral, minimum UTxO or the real `serialiseData` of ledger-supplied datums. There is no positive Issue test until §6.

---

## 5. `x7 abi` (S6), no setup; exit 0 iff every line is `AS-EXPECTED`

| ID | Expected |
|---|---|
| E-X7-1 | MSB0 pre/post and MEB0 effects re-encoded from `out/x0/moriref.json` case 0 equal the native pay model. Lengths are [171, 171, 184]. **This is the Core-oracle correspondence check for the new transition bytes.** |
| E-X7-2 | L1 and M1, with a DECLARED vk digest `33³²` and outref `(44³², 1)`: satisfied, and the circuit statement equals the native statement. **Predicted constraints: L1 = 361,339, M1 = 307,482** (see the derivation below). Statement lengths are 236 and 733. |
| E-X7-3 | Public inputs of a statement with one flipped vk-digest bit: unsatisfied in `public-input binding` (hi with overwhelming probability). Predicted index: L1 #361,337, M1 #307,480. |
| E-X7-4 | The R1CS digest is unchanged when the vk digest and outref witness values change. Setup therefore cannot depend on the VK digest, so there is no cycle. |
| E-X7-5 | DECLARED P-M1 vectors (see the table below). Each native-model line reports an error. |
| E-X7-6 | DERIVED NEGATIVES on the frozen body: header byte → `template-const` #4,920; threshold = coin + 1 → `coin>=threshold` #259,960; body[400] flipped under the honest digest → `public-input binding` #361,337. The statement txid equals the provider txid `9e6dfe33…8541`. That equality is E0, not authentication. |

**Constraint derivation:**

| Row | Regions | Total |
|---|---|---|
| L1 | vk-digest 256 + body booleanity 4,656 + template-const 328 + body hash 254,592 + threshold 64 + coin ≥ threshold 65 + statement hash 2 blocks 101,376 + binding 2 | **361,339**. This is the prior X2 total of 361,083 plus 256. |
| M1 | vk-digest 256 + outref 272 + accepted 2 + amount 128 + amount > 0 1 + pre 512 + 5 × 129 + statement hash 6 blocks (50,304 + 5 × 51,072 = 305,664) + binding 2 | **307,482** |

**E-X7-5 refusal vectors.** All are DECLARED P-M1 vectors. The first-unsatisfied indices are predicted from source, and the oracle columns are the R1–R5 results recorded in `moriref.json`.

| Vector | Witness | First unsatisfied | Oracle |
|---|---|---|---|
| R1 | payer = amount + 1 | `fee debit payer` #1,557 | case 1 |
| R2 | recipient = u128::MAX | `transfer credit recipient` #1,428 | case 2 |
| R3 | accepted = false | `requires accepted` #529 | case 3 |
| R4 | paid = MAX − amount + 1 | `next paid` #1,815 | case 4 |
| R5 | amount = 0 (DERIVED NEGATIVE) | `requires amount>0` #658. **This isolates the boundary the prior audit (F5) found unexercised.** | case 5 |

---

## 6. `x7 run --row L1` and `--row M1` (S10, S11): fresh research setup

**E-X7-7.**
- The statement is satisfied and equals the native one.
- The proof verifies natively.
- The envelope is well-formed, with the vk digest equal to BLAKE2b-256 of the 488-byte VK.

**E-X7-8.** Each statement mutation is rejected by verification:
- vk-digest byte;
- claim_kind byte set to 1;
- setup_class byte set to 1;
- context tag;
- last payload byte;
- for M1 also: outref txid byte, outref index, last byte of pre, post and effects.

**E-X7-9.** Forced proofs do not verify. For M1 these are R1 (wrapped post) and R5 (amount zero). For L1 it is threshold = coin + 1.

**Outputs:**
- `out/{L1,M1}/{vk.bin, proof.bin, statement.bin, claim.json, admission.json, results.json}`
- VK size 488 bytes; proof size 192 bytes.

**No proving key or trapdoor is persisted.**

## 7. Generated Aiken tests (S12–S13)

After `gen_x7_aiken.py`, a second `aiken check` runs `x7_vectors_test.ak`:

| Test | Expected |
|---|---|
| `{l1,m1}_statement_matches_x7` | pass |
| `_asset_name_matches_x7` | pass |
| `_vk_digest_matches_envelope` | pass |
| **`_groth16_positive`** | pass |
| `_payload_bit_flip_rejected` | pass |
| **`_c0_issue_unit_context`** (the full Issue logic, including the pairing check, over a UNIT context) | pass |
| `cross_vk_rejected` | pass |

Execution units are reported by Aiken's built-in cost model. That is not a Preprod measurement, and live cost models are not applied.

**Remaining gap.** A positive end-to-end S_settle0 test combining a *real* P-M1 proof with a thread whose `state` equals that claim's `pre_state` is not generated. Settlement does not re-verify proofs; it relies on the token. E-CTX-1 already covers the settle logic.

---

## 8. Blocked: not requested and not to be run

| Item | Reason |
|---|---|
| Preprod transactions (C0 deploy, genesis, issue, settle, refund) | No transaction builder, wallet or authority. REPORT §7 explains. |
| `x7 setup` / `x7 prove` with a persisted proving key | That is private key material. It needs separate root authorization and a private path outside the task tree. |
