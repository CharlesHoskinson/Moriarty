# MRG16-PVC ABI v0: claim-certificate UTxO prototype

**Status: PROPOSED.** The predecessor's `VOTE.md` (D1–D12) is one vote. This document fixes the concrete bytes, and the details that `VOTE.md` did not fix (listed in §9) need a fresh second agreeing vote before adoption.

The implementation under `source/` is a **candidate built for review**. It is not adopted, compiled, tested or deployed.

**Scope.** Class 0 research only. This makes no mainnet, funds, production or ceremony security claim.

---

## 0. Roles

| Role | Script / artefact | Purpose |
|---|---|---|
| Issuer and holder | **C0**, one multi-purpose Aiken script (`validators/c0.ak`) | Its mint handler issues a claim token after verifying a Groth16 proof. Its spend handler releases a claim UTxO. The policy id equals the script hash. |
| Consumer | **S_settle0**, one multi-purpose Aiken script (`validators/settle0.ak`) | Its mint handler is one-shot thread genesis. Its spend handler settles a thread against claims spent in the same transaction. |
| Prover | **x7**, a Rust binary (`source/x7`) | Implements the relations P-L1 and P-M1, setup and prove, and emits the exact datum and redeemer bytes. |
| Admission | Admission record | (`predicateDigest`, `r1csDigest`, `vkDigest`), written after setup. A consumer adopts it by pinning `vkDigest` in a slot. |

Compiling, proving and deploying are **permissionless**:
- Anyone can build C0 and S_settle0, run a setup for a catalogue row, and create threads.
- No maintainer registry is consulted.
- Trust in a relation is per-consumer: it is the (`predicate_digest`, `vk_digest`) pair the thread creator pinned.

---

## 1. Identities and the circularity check

| Identity | Defined as | Where it is checked | Cycle? |
|---|---|---|---|
| Statement tag | ASCII `MRG16-PVC-STMT-0` (16 bytes) | Circuit constant; Aiken `stmt_tag` | None |
| `family_id` | ASCII `MRG16-PVC-FAM0-G16-BLS-ARK04-HL2` (32 bytes) | Circuit constant; C0 `well_formed` | None. It is a fixed descriptor, not a hash, so no hash computation is needed in source. |
| `predicate_digest` | BLAKE2b-256 of the exact catalogue entry file bytes (`source/catalogue/P-*.v0.json`) | Circuit constant; slot match | None. The entry contains no VK, R1CS digest or script hash. |
| `vk_digest` | BLAKE2b-256 of the arkworks-0.4 compressed VK (488 bytes) | C0 recomputes it from the redeemer VK; slot match | None. In the circuit it is free witness bytes, and the statement carries it as domain separation. |
| `r1cs_digest` | BLAKE2b-256 over `MRG16-PVC-R1CS-0` ‖ counts ‖ the A, B, C matrices after inlining (`x7 main.rs: r1cs_digest`) | Admission record only | None. It is never placed in a circuit (see the dissent below). |
| C0 script hash | Hash of the C0 code | Policy id equals the holder address | None. The VK arrives in the redeemer. |
| S_settle0 script hash | Hash of the S_settle0 code | Thread policy and address | None. `c0_hash` is a datum field. |
| Claim asset name | `blake2b_256(serialiseData(EnvV0))` | C0 Issue and Release; S_settle0 claim check | None. The envelope does not contain its own asset name. |
| `thread_id` | `blake2b_256(serialiseData(seed OutputReference))` | S_settle0 genesis | None |
| Context | `settle_outref`, a **pre-existing** thread UTxO (txid ‖ u16 index) | Statement, if `context_bound`; S_settle0 checks it equals `own_ref` | None. No settlement TxId, redeemer, script-integrity hash or envelope digest appears in any statement. |

**Dissent on the audit's in-circuit relation-digest suggestion (F2 amendment 2).**
- Putting a digest of the whole R1CS inside that same R1CS as a constant is a fixed point. The digest changes the constraints that it digests.
- Hashing a constant-free skeleton would avoid the cycle, but it would no longer bind the constants (predicate digest, program digest, template). Those are exactly what distinguishes a production row from a control.

v0 therefore does the following:
1. The in-circuit predicate digest is **domain separation only**. It is not a relation identifier.
2. The relation trust root is the admission record (`predicateDigest`, `r1csDigest`, `vkDigest`) **as adopted by a consumer pinning `vkDigest`**. A third party can recompute `r1csDigest` by re-running synthesis. A VK's provenance from that R1CS still rests on the setup, and nothing in v0 proves it.
3. Control circuits must have their own catalogue entries, so they get distinct predicate digests. x7 contains **no** unbound-control row.

---

## 2. EnvV0 (inline datum of a C0 claim UTxO)

`Constr 0` with fields in this order (Plutus Data; Aiken `pvc/abi.EnvV0`):

| # | Field | Type | v0 rule |
|---|---|---|---|
| 0 | `version` | Int | `= 0` |
| 1 | `claim_kind` | Int | `= 0` (run). `1` (universal) is refused at mint (D2). |
| 2 | `family_id` | Bytes(32) | `= family_id_v0` |
| 3 | `predicate_digest` | Bytes(32) | — |
| 4 | `vk_digest` | Bytes(32) | `= blake2b_256(redeemer vk)` at Issue |
| 5 | `setup_class` | Int | `= 0` (D11). This is a label, not evidence. |
| 6 | `context_bound` | Bool (`Constr 0 []` = False, `Constr 1 []` = True) | Decides whether the statement carries `settle_outref` (D4) |
| 7 | `settle_outref` | OutputReference `Constr 0 [Bytes(32), Int]` | Mandatory for every claim. Index in [0, 65535]. |
| 8 | `transition` | Option\<TransitionV0\>, where `Some = Constr 0 [x]` and `None = Constr 1 []` | `Some` requires `context_bound` (D6) |
| 9 | `payload` | Bytes | < 65536 bytes; layout defined by the catalogue row |
| 10 | `expiry` | Int (POSIX ms) | Gates refund only |
| 11 | `refund_vkh` | Bytes(28) | Must sign a refund |

TransitionV0 is `Constr 0 [pre_state: Bytes, post_state: Bytes, effects: Bytes]`, each under 65536 bytes.

**CBOR follows Plutus `serialiseData` exactly:**
- tags 121–127 for constructors 0–6;
- non-empty lists (including constructor fields) indefinite-length (`9f … ff`), empty lists `80`;
- byte strings longer than 64 bytes chunked into 64-byte pieces inside `5f … ff`;
- minimal-length integers.

Implementations: Aiken `builtin.serialise_data`, x7 `abi::cbor` and `abi_ref.py`. They must agree byte for byte (§7).

---

## 3. Statement `MRG16-PVC-STMT-0` (flat and injective)

| Field | Bytes | Source in-circuit |
|---|---|---|
| tag | 16 | constant |
| family_id | 32 | constant |
| predicate_digest | 32 | constant (row) |
| vk_digest | 32 | free witness |
| claim_kind | 1 | constant `00` |
| setup_class | 1 | constant `00` |
| context tag | 1 | constant (row): `00` context-free, `01` context-bound |
| *if context tag = 01:* settle txid ‖ index | 32 ‖ 2 (u16 BE) | free witness |
| transition tag | 1 | constant (row): `00` none, `01` present |
| *if transition tag = 01:* u16 len ‖ pre ‖ u16 len ‖ post ‖ u16 len ‖ effects | variable | lengths and structure constant; values from witness or computed |
| u16 len ‖ payload | variable | row-defined |

**Public inputs.** There are two BLS12-381 scalars:
- `x1 = BE(blake2b_256(stmt)[0..16))`
- `x2 = BE(blake2b_256(stmt)[16..32))`

Each is below 2¹²⁸ < r, so no reduction is applied and no alias is possible. The circuit constrains them in the regions `public-input binding hi` and `public-input binding lo`. Verifiers (C0, x7, generated tests) always derive them from the statement bytes and never accept supplied scalars.

**Upstream comparison.** proof-zk-recovery uses one scalar, `LE(blake2b_256(DOM)) mod r`. That reduces a 256-bit digest modulo a 255-bit r. Two halves avoid the reduction.

**Row sizes.** These are computed by hand from source and confirmed by unit-test expectations (not run):

| Row | Statement bytes | Breakdown |
|---|---|---|
| P-L1 | 236 | payload 118 |
| P-M1 | 733 | pre 171, post 171, effects 184, payload 49 |

---

## 4. C0 rules (`lib/pvc/c0.ak`)

**Mint `Issue{vk, proof}`** (Constr 0). All of the following must hold, in this order:
1. The mint of this policy is exactly one `(name, 1)`.
2. Exactly one output carries any token of this policy. Its payment credential is `Script(policy_id)`, it holds exactly that one token, and its datum is inline. The datum is decoded as EnvV0 (`expect`).
3. `name = blake2b_256(serialise_data(datum))`.
4. `well_formed(env)` holds (§2 rules).
5. `env.vk_digest = blake2b_256(vk)`.
6. `groth16_verify(vk, proof, statement(env))` holds, and it is evaluated last:
   - `len(vk) = 488` and `vk[336..344) = 03 00 00 00 00 00 00 00`;
   - points at offsets α 0, β 48, γ 144, δ 240, ic0 344, ic1 392, ic2 440;
   - `len(proof) = 192` with A 0, B 48, C 144;
   - every point passes through `bls12_381_*_uncompress`, which fails on off-curve or non-subgroup encodings;
   - `e(A,B) = e(α,β)·e(ic0 + x1·ic1 + x2·ic2, γ)·e(C,δ)`.

**Mint `Burn`** (Constr 1). Every quantity of this policy in the mint is negative.

**Spend (release).** The datum is decoded as EnvV0 (`expect`). Then:
1. The spent input holds exactly one token of the C0 policy, named `H(datum)`, and no other token of that policy (D9).
2. **No output carries any token of this policy**, so every released token is burned.
3. Then **either** `settle_outref` is spent in the same transaction, **or** a refund applies: the validity lower bound is `Finite(t)` with `t > expiry`, and `refund_vkh` is among the signatories.

---

## 5. S_settle0 rules (`lib/pvc/settle.ak`)

**ThreadDatum** is `Constr 0 [version: Int = 0, thread_id: Bytes(32), c0_hash: Bytes(28), slots: List<SlotV0>, state: Bytes, last_effects: Bytes(32), seq: Int]`.

**SlotV0** is `Constr 0 [predicate_digest: Bytes(32), vk_digest: Bytes(32), require_context: Bool, require_transition: Bool]`.

**Slot rules (D6).** There are 1–2 slots, with exactly one `require_transition`, and that slot also has `require_context`. `rule_kind 0` is AND over all slots.

**Mint `Genesis{seed}`** (Constr 0, one-shot, D7):
- The seed is spent.
- The mint of this policy is exactly `(blake2b_256(serialise_data(seed)), 1)`.
- Exactly one output carries the token. It sits at `Script(policy_id)`, carries only lovelace plus the token, has no reference script, and has an inline ThreadDatum with:
  - `version 0`
  - `thread_id = name`
  - a 28-byte `c0_hash` that differs from the thread policy
  - well-formed slots
  - `last_effects = 0³²`
  - `seq 0`
- The initial `state` is the **creator's declaration**. It is not proved.

**Spend (settle).** Any redeemer is accepted. Then:
1. Exactly **one** input sits at this script's payment credential (the upstream S3-F3 double-satisfaction pattern). It holds the thread token.
2. There is no mint of this policy, so the thread cannot be terminated in v0.
3. Exactly one output sits at this payment credential. It has:
   - the same full address;
   - the **same value**;
   - no reference script;
   - an inline ThreadDatum with `version`, `thread_id`, `c0_hash` and `slots` unchanged and `seq + 1`.
4. The claims are the envelopes of every **spent** input at `Script(c0_hash)`, in input order.
   - Reference inputs are never read (D2, R3).
   - It fails closed if such an input has no inline EnvV0, does not hold exactly one token named `H(datum)`, or has `claim_kind ≠ 0`. This is the upstream `scriptDatums` fail-closed pattern.
5. The claims match the slots one to one (`match_slots`). Matching is on (`predicate_digest`, `vk_digest`), the context requirement, and transition presence. Because of the bijection, an extra claim fails settlement.
6. Every claim's `settle_outref` equals `own_ref`.
7. For the claim matched to the transition slot:
   - `pre_state = datum.state`
   - `post_state = continuation.state`
   - `continuation.last_effects = blake2b_256(effects)` (D1)

**Burn, refund, overlap and dedup:**
- Settlement spends the claims. C0's spend handler then forces them to be burned.
- An unused claim can be refunded only after expiry, by its refund key.
- Spend/reference overlap is irrelevant, because only spent inputs count.
- Duplicate envelopes cannot fill two slots, because exactly one slot is the transition slot and the other requires `transition = None`.

---

## 6. `mori-snapshot-bytes/v0` (MSB0) and `mori-effects-bytes/v0` (MEB0)

The building blocks are:
- `str` = u16 BE length ‖ UTF-8 bytes
- `uint` = 16-byte BE u128
- `val` = `00` ‖ uint (UInt), or `01` ‖ byte (Bool)
- `asset` = str network ‖ str issuer ‖ str reference ‖ u8 scale

**MSB0** is `"MSB0"` ‖ u16 nState ‖ (str name ‖ val)* ‖ u16 nBal ‖ (str account ‖ asset ‖ uint)* ‖ u16 nLiab ‖ (str name ‖ u8 present ‖ uint)*.
- State names are strictly ascending, balances strictly ascending by (account, asset), and liability slots strictly ascending.
- There is one liability slot per **declared** liability name: absent = (0, 0), present-zero = (1, 0) (D12, R11).

**MEB0** is `"MEB0"` ‖ u16 n ‖ effects in execution order, where each effect is:

| Effect | Encoding |
|---|---|
| State | `00` ‖ str ‖ val before ‖ val after |
| Transfer | `01` ‖ asset ‖ str from ‖ str to ‖ uint |
| Fee | `02` ‖ asset ‖ str from ‖ str to ‖ uint |
| Liability | `03` ‖ str name ‖ asset ‖ str debtor ‖ str creditor ‖ uint before ‖ uint after |
| Emit | `04` ‖ str ‖ val |

**For `pay`:**
- MSB0 is 171 bytes, with u128 offsets [13, 59, 107, 153] for (paid, payer, recipient, sponsor).
- MEB0 is 184 bytes, with u128 offsets [46, 100, 124, 141, 168] for (transfer amount, fee amount 2, state before, state after, emit value).
- The effect order (Transfer, Fee, State, Emit) and the emitted value, `paid` *after* `next`, follow `runtime.rs` statement order (lines 744–790). `x7 abi` cross-checks them against `out/x0/moriref.json`.

---

## 7. Fixtures (hand-written; asserted in Aiken, Rust and Python; not yet run)

**Fixture inputs:**

| Fixture | Fields |
|---|---|
| F0 | `predicate = 22³²`, `vk = 33³²`, context-free, `settle_outref = (44³², 1)`, no transition, `payload = cafe`, `expiry = 1000`, `refund_vkh = 55²⁸` |
| F1 | F0 with `context_bound = True`, `transition = (aa, bb, cc)`, `payload = ""` |

**F0 statement (120 bytes):** `TAG ‖ FAMILY ‖ 22³² ‖ 33³² ‖ 00 00 00 ‖ 00 ‖ 0002 cafe`

**F1 statement (161 bytes):** `TAG ‖ FAMILY ‖ 22³² ‖ 33³² ‖ 00 00 01 ‖ 44³² 0001 ‖ 01 ‖ 0001aa 0001bb 0001cc ‖ 0000`

**F0 envelope CBOR:**
```
d8799f 00 00 5820 FAMILY 5820 22³² 5820 33³² 00 d87980 d8799f 5820 44³² 01 ff d87a80 42cafe 1903e8 581c 55²⁸ ff
```

**F1 envelope CBOR:** as F0, except:
- `context_bound` is `d87a80`;
- the transition is `d8799fd8799f41aa41bb41ccffff`;
- the payload is `40`.

**Hex values:**
- `TAG` = `4d524731362d5056432d53544d542d30`
- `FAMILY` = `4d524731362d5056432d46414d302d4731362d424c532d41524b30342d484c32`

**T0** (thread fixture, emitted by x7 and abi_ref and compared byte for byte):
- `seed = (10³², 0)`
- slot = (P-M1 digest, `33³²`, true, true)
- `c0_hash = c0²⁸`
- `state = MSB0(pre)`

---

## 8. Unsupported in v0: explicit refusals, still required future tracks

| Item | v0 behaviour |
|---|---|
| Universal certificates (`claim_kind = 1`) | Refused at mint, and never counted (D2). They need their own issuance class and trust model. They remain a **required** future track. |
| OR, k-of-n, DAG composition, and cross-slot field links | Not supported. AND over 1–2 slots carries **no** equality between slot payloads. Any link (for example amount = coin) must be a single relation, or a future link rule. |
| Recursive PCD, private handoff, aggregation | None |
| Thread termination; thread value change; Moriarty effects on ledger assets | Unsupported. See REPORT §6 for the ledger integration boundary. |
| Proving-key distribution or ceremonies | None. `setup_class` is a label only. |
| Maintainer registry | Not used. Admission is per consumer. |

---

## 9. Details beyond VOTE.md (need the fresh second vote)

**N1.** `refund_vkh` (28 bytes) and the refund rule: a signer is required, and the lower bound must be strictly after `expiry`. Settlement release is allowed at any time.

**N2.** `family_id` is a 32-byte ASCII literal, not a digest.

**N3.** `vk_digest` is included in the statement as free witness bytes. The statement field order is tag, family, predicate, vk, kind, setup, context, transition, payload.

**N4.** `well_formed` refuses a transition without context. This is stronger than D6, which constrained slots only.

**N5.** S_settle0 requires:
- exactly one own-script input;
- the continuation keeps the same full address and value and has no reference script;
- `seq + 1`;
- `slots` and `c0_hash` are immutable.

**N6.** A C0 input in a settlement fails closed if it is malformed.

**N7.** The admission record adds `r1csDigest`, and the in-circuit relation-digest suggestion is declined (§1).

**N8.** The constraint `genesis c0_hash ≠ own policy`.

**N9.** C0 Release forbids **any** output carrying the policy, not only the released name. A claim issue and a claim release therefore cannot share one transaction.

**N10.** P-M1 has no ledger adapter. The amount is a free u128 disclosed in the payload. This makes `requires amount > 0` isolatable, which addresses audit F5.

---

## 10. Reuse from `proof-zk-recovery` (Apache-2.0, commit `7f54c35f…`; selected sources read, nothing executed)

**Transferred as patterns. No code was copied.**

| Upstream | Pattern |
|---|---|
| `Recovery/Logic.reconstructPub` | The verifier reconstructs the public input from authenticated context. It is never prover-supplied. |
| `RedemptionValidator.scriptDatums` | Fail-closed handling of a script UTxO without an inline datum. |
| `custodyInputCount == 1` | One own-script input per transaction, against double satisfaction. |
| `ticketBurnedFor` | Consume-and-burn spent-state. Here it maps to the C0 burn-on-release rule. |
| `validateClaim` | Bind the payout to a committed encoding. This informs the ledger-integration boundary in REPORT §6. |

**Not transferable as-is:**
- `groth16VerifyCommitted` (gnark BSB22 commitment: 672-byte VK, 336-byte proof, PoK pairing, `expand_message_xmd` challenge). It does not match arkworks vanilla Groth16. It would only matter if a future backend used gnark commitments.
- The 432-byte gnark VK layout, which has one IC point and one LE-mod-r scalar.
- The fixed-parameter VK baked into the validator. v0 instead puts the VK in the redeemer and pins it by digest in consumer slots, so one C0 serves a family.
- Their Preview deployment and costs. Their own `CANONICAL-MPC-CLAIM.md` says the setup was single-operator. Those are **author records** and were not checked here. They are not Preprod qualification.
