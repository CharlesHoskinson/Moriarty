All the approved Rust steps ran and passed, and every result matches what the audit predicted. That covers S0, S0b, S1, the namespace probe, S2, S3, S4, S5, S6, S7, S10, S11, S12 (written to `out/generated`) and a read-only final check (S14). Aiken steps S8, S9 and S13 were not run because they are outside this job. The next open boundary is the Aiken source revision (fix F-B, preferably also F-A and F-N) and its separate review, then running `aiken check` with no network.

All work ran between 08:23:23 and 08:25:38 UTC on 2026-10-15. No setup or prove command was run, no network was used, and nothing was published or sent anywhere.

## How it was run
- **Control script:** `control/x7_run_control.py`, Python stdlib only, with no shell and an explicit argument list and environment for every child process.
  - Every log and receipt is created only if it doesn't already exist and is then made read-only, so no step can be rerun inside this attempt.
  - The run was split into four phases (`pre`, `build`, `run`, `final`). Each phase starts only if every earlier step passed.
  - The script's own hash stayed `c640647d…` across all four phases.
- **Network isolation:** I checked the exact `unshare --user --map-root-user --net` setup first, before running anything else. Inside it, only the loopback interface existed, user 0 mapped to 1000, and the network namespace was new. Every later child process ran inside it.
- **Limits:** observed in each child process, not just requested: nice 10, 32 GiB address space, core dumps 0, 8 threads.
- **Paths:** source is read from `implementation-attempt-2/source`, unchanged except for the lockfile copy. Every output went to `rust-research-execution-1/{logs,receipts,out,build}`. The full mapping is in `receipts/variables.json`.
- **x7 binary:** only the `abi` and `run` subcommands were allowed. The binary's hash was checked against the build receipt before and after each use.

## Hashes
| Item | SHA-256 |
|---|---|
| SOURCE-FREEZE.json (54/54 members OK before and after) | `78beca9c…8b70` |
| Cargo.lock (frozen original and copy are identical; unchanged after build) | `f439fa5f…04b6` |
| rustc 1.98.1, commit `48a229ce…` | `85925497…1e74` |
| cargo 1.98.1 | `da77c8b3…7e14` |
| x7 binary | `d235ad33…39f5` |

All tool and output hashes are under `receipts/`.

## Results compared with the audit's expectations
| Step | Result |
|---|---|
| S5 tests | 9 passed |
| S6 `x7 abi` | 21 of 21 as expected. L1 has 361,339 constraints and M1 has 307,482. Every failure index matches the audit's derivation. |
| S7 compare | `mismatches []` (this only shows two implementations by the same author agree) |
| S10 L1 run | 8 of 8: the proof verifies, 5 tampered statements are rejected, 1 forced proof is rejected. VK 488 bytes, proof 192 bytes. |
| S11 M1 run | 14 of 14: 10 tampered statements and 2 forced proofs are rejected. The payload is `f1f4807b…e786 ‖ 01 ‖ 00…0f4240`, as predicted. |
| S12 | 13 Aiken tests generated in `out/generated/` only; the original Aiken source was not touched |
| S14 | The only source change is the added `source/x7/Cargo.lock`. No core files, no large files and no proving key on disk. CARGO_HOME was not changed. |

I also checked the published outputs with Python's own hashing rather than x7's code. For both runs, the VK digest, statement digest, public inputs, the VK point count at offset 336, and the placeholder context values all agree.

## Security notes
- **Proving keys:** both runs exited normally, not by a signal, so no VK is marked compromised. The proving keys and trapdoors were held only in memory and dropped.
- **Core dumps:** `core_pattern` is the plain file `core`, not a pipe handler, so the core-dump limit of 0 actually applies.
- **Swap residual:** swap was active (8 GiB, about 3.7 GiB in use). Proving-key or trapdoor pages may have been swapped to disk. This is recorded as a residual risk for this research class.
- **Scope of the VKs:** they come from a single-party research setup, not a ceremony. No consumer should pin them beyond this research.

## Labels on what this shows
- **Placeholder context:** the outref `44…44#1`, the refund key and the expiry are made-up placeholders for unit testing, not real Preprod claims.
- **Real Preprod body:** the L1 body is a real captured Preprod transaction. Its txid matching the provider's txid is a byte match, not authentication. Nothing here shows the transaction was included, is unspent or is final.
- **Derived negative tests:** the refusal and tampering cases are derived from the real data, not captured.
- **Expectations are the author's:** the "as expected" marks compare against the author's own predictions, so they are not independent. These actual results still need an independent review.
- **No broader claims:** this run supports no claim about compiler correctness, financial settlement, the ledger, or cryptographic approval.

The full write-up is in `rust-research-execution-1/EXECUTION-REPORT.md`, and the per-step records are in `receipts/steps/` and `logs/`.