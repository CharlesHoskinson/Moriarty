# X7 Rust research execution: rust-research-execution-1 / attempt-1

**Status: all approved Rust steps GREEN** (S0, S0b, S1, NS-probe, S2, S3, S4, S5, S6, S7, S10, S11, S12 redirected, S14-verify).

- **Not run in this job:** S8, S9 and S13 (Aiken). They are out of scope, so they are not "blocked by failure".
- **First open boundary:** the Aiken revision (F-B, plus F-A/F-N recommended) and its separate review. The offline stdlib placement and the no-network `aiken check` (S8c/S8d) come after that.
- **Window:** executed 2026-10-15, 08:23:23 to 08:25:38 UTC.

## Scope and labels

| Item | Statement |
|---|---|
| **Class** | Class 0 local research only. No network action, Preprod transaction, wallet, existing key, SDK, Midnight, ledger or native command. No `x7 setup` or `x7 prove`. |
| **Approved inputs** | Only the approved source revision, unchanged, plus the S2 byte-copy of the frozen `Cargo.lock`. |
| **Context fields** | `settle_outref 4444…44#1`, `expiry 1000` and `refund_vkh 55…55` are **DECLARED synthetic ABI UNIT context placeholders**. They are not ledger observations and not real Preprod claims. |
| **P-L1 body** | The body bytes are the frozen, actually captured Preprod transaction body (`selected-body.bin` `37bbdf92…`). Its txid equals the frozen provider txid; that is E0 equality, not authentication. No inclusion, unspentness or finality is claimed. |
| **Negative vectors** | E-X7-5 R5 and the E-X7-6/8/9 mutations and forced proofs are **derived negative controls**. |
| **AS-EXPECTED marks** | These are x7's self-checks against **author-written, correlated expectations**. S7 (`abi_ref.py`) is agreement with a same-author re-implementation, not an independent oracle. An independent review of these actual results is still required. |
| **VKs** | The VKs come from single-party `circuit_specific_setup`, with the trapdoor and PK dropped in-process. That is not a ceremony. They are research artefacts and must not be pinned by any consumer beyond Class 0 research. |
| **Excluded claims** | No compiler-correctness, financial-settlement, ledger or cryptographic-approval claim. |
| **Aiken serialise function** | The prior Aiken `serialise_data` key function was not executed. |

## Variables (receipts/variables.json)

- **Source side:** `TASK` = implementation-attempt-2. This is the original source, read-only apart from `source/x7/Cargo.lock`.
- **Output side:** `EXEC` = rust-research-execution-1. All logs, receipts, out, build and control files are here.
- **Other paths:**
  - `FROZEN` = groth16-preprod-experiments-20261015
  - `X7` = `EXEC/build/x7-target/release/x7`
- **Path mapping:** `$TASK/{logs,receipts,out,build}` maps to `EXEC/...`, and the `/tmp` cwd maps to `EXEC/build/cwd-empty`.

## Controls actually applied (observed in /proc of each child)

- **Limits:** nice 10, RLIMIT_AS 34359738368, RLIMIT_CORE 0, and `RAYON_NUM_THREADS=8`. Cargo also had `CARGO_BUILD_JOBS=8` and `RUST_TEST_THREADS=8`.
- **Process control:** each child got its own session and its process group was drained. Per-step wall budgets were 60 to 7200 s.
- **Namespace:** every child ran inside `unshare --user --map-root-user --net`. The probe was the first child and recorded:
  - only `lo` present;
  - uid_map `0 1000 1`;
  - new net namespace (`4026532238`) and user namespace;
  - limits as above.
- **Environment:** built from scratch; the parent had no RUST\*/CARGO\* variables.
- **Toolchain pin:** `RUSTUP_TOOLCHAIN=stable-x86_64-unknown-linux-gnu` and `RUSTUP_AUTO_INSTALL=0`. Cargo and rustc were invoked by absolute toolchain path with `RUSTC` set, and their hashes were taken before first invocation.
- **x7 allowlist:** `abi` and `run` only. The x7 hash was rechecked against the S4 receipt before and after each invocation.
- **Crash residuals:**
  - `core_pattern` = `core`, not a pipe, so RLIMIT_CORE=0 is effective.
  - No child exited by signal, so no VK-COMPROMISED marker was written.
  - **Residual:** swap is active (8 GiB, ~3.7 GiB used at start). In-process PK and trapdoor pages may have been swapped. This is recorded as a Class 0 residual.
- **CARGO_HOME:** unchanged. There were no new registry extractions and the `.package-cache` mtime was the same.

## SHA chain

| Item | SHA-256 |
|---|---|
| SOURCE-FREEZE.json (54 members, 25 candidate + 29 context; all OK before and after) | `78beca9c3ce9dba84794febe729ac82b5548e95899c4cc5ec9bf577544638b70` |
| Cargo.lock (frozen g16 and the S2 copy; unchanged after build) | `f439fa5fe9691e9e4c0cf3a3aa14eb76e90101398ed6f2ad5e3b31c0881804b6` |
| rustc 1.98.1 (commit `48a229ceaefd4985c50990b14116b6d856af0985`) | `859254978c0a0402c32f949f6de0d99aee73be8d15f45aac00ae1448aac51e74` |
| cargo 1.98.1 | `da77c8b33849312255ccde3179198ada4c8deb370488d050286146b1d1b27e14` |
| librustc_driver | `96218b68a4a569c06c6fea5ee95b9052ce61c7316ac265a7963e7fea90e985d2` |
| rustup (and the cargo/rustc shims) | `dda7234360b7f578ca8b0ddcb80145646fa61a67c1720a5abc7051b35c9fcb71` |
| aiken v1.1.21+42babe5 (version recorded only; not used) | `07f3f927f1a8c71fc61273fdff850d9b98edb28dde207c8a32585991f2c88e79` |
| python3.14 (3.14.4) | `52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41` |
| x7 binary (2,428,808 bytes) | `d235ad334d543e16d3928abed38536c961226ae4d67456940de2e296000b39f5` |
| control script | `c640647d2abb615a1f3537fffc33f301de1d91354a1f180adfd0e85eb61d83f1` |

Output digests are in `receipts/out-sha256.txt` (15 files).

## Results

| Step | Exit | Observation | Audit §7 expectation |
|---|---|---|---|
| S4 build | 0 (28.2 s) | One dead-code warning (`Effect::Liability`) | G-1 |
| S5 test | 0 | 9 passed, 0 failed | 9 passed |
| S6 x7 abi | 0 (14.6 s) | 21 of 21 AS-EXPECTED | Match: 21 lines, all AS-EXPECTED, as derived in §4.3 |
| S7 abi_ref | 0 | `mismatches []` | Match |
| S10 L1 run | 0 (30.8 s) | 8 of 8 AS-EXPECTED | Match |
| S11 M1 run | 0 (29.2 s) | 14 of 14 AS-EXPECTED | Match |
| S12 generate | 0 | 13 tests written to `out/generated/x7_vectors_test.ak` (`c90b97c9…`), not copied into any Aiken source | 13 generated tests |
| S14 verify | — | Freeze 54/54 OK. Source diff = only `+source/x7/Cargo.lock`. No core files, no large files, no key material on disk. | — |

**S6 detail:**

| Row | Constraints | Binding-hi index | Statement length | R1CS digest |
|---|---|---|---|---|
| L1 | 361,339 | #361337 | 236 | `c883e972…0296` |
| M1 | 307,482 | #307480 | 733 | `73bc13ea…64b9` |

- **First-unsatisfied indices:** R1 #1557, R2 #1428, R3 #529, R4 #1815, R5 #658, L1 template-const #4920, threshold #259960.
- **MSB0/MEB0 lengths:** [171, 171, 184].
- **Oracle agreement:** `mori_core::simulate` output equals the native model on pre, post and effects.

**S10 and S11 detail:**

| Row | Setup | Prove | Positive verify | Mutations rejected | Forced proofs rejected | vkDigest | Asset name |
|---|---|---|---|---|---|---|---|
| L1 | 15.6 s | 6.3 s | verified | 5/5 | 1/1 | `7b014d8e…2198` | `58618d25…bc8e` |
| M1 | 10.8 s | 4.9 s | verified | 10/10 | 2/2 | `8e1ae703…fc55` | `3e795634…58a6` |

The M1 payload is `f1f4807b…e786 ‖ 01 ‖ 00…0f4240`.

**Independent checks** (Python hashlib over the public outputs, not x7 code):
- BLAKE2b(vk) equals the admission and envelope vkDigest.
- BLAKE2b(statement) equals the claim's statementDigest.
- The public inputs equal the integers of the two 16-byte digest halves.
- The VK IC count at offset 336 is 3.
- The context fields equal the DECLARED values.

All hold for both rows.

Both runs exited normally, so the trapdoors and PKs were dropped in-process. Only `vk.bin`, `proof.bin`, `statement.bin`, `claim.json`, `admission.json` and `results.json` were written, which are public outputs within the approved scope.

## Open items carried forward (unchanged by this run)

- **Aiken path:** F-B compile fix, F-A deposit capture (blocks Preprod), and F-N chunked-CBOR fixture. After those, S8c/S8d offline placement and S13 run on a new Aiken revision with its own review.
- **Not yet run:** the non-author checks that only S13 provides: Plutus `serialise_data` asset names for >64-byte fields, CIP-0381 `blst` against the arkworks proof, and `cross_vk_rejected`.
- **Other findings:** F-E, F-F (the admission record is still self-asserted and does not bind the source manifest), F-G, F-H, F-I, F-K, F-L, F-P and F-Q.
- **Explicit blockers:** B2 (the Preprod PK decision) and B3 (physical asset integration).
