#!/usr/bin/env python3
"""X7 bounded local research execution control: rust-research-execution-1, attempt-1.

Inspected transcription of the approved, amended steps from EXECUTION-REQUEST.json and the independent
audit section 13: S0, S0b, S1, NS-probe, S2, S3, S4, S5, S6, S7, S10, S11, S12 (redirected to out/generated)
plus a read-only S14-verify. S8, S9 and S13 (Aiken) are out of scope for this job and are never run.

Rules implemented here:
- Python stdlib only; no shell; every child gets an explicit argv list and an explicit environment built
  from scratch (nothing inherited except HOME/USER/LOGNAME values).
- Every child: nice +10, RLIMIT_AS 32 GiB, RLIMIT_CORE 0, own session/process group, per-step wall budget,
  SIGTERM then SIGKILL after 60 s on timeout, and the group is drained before the step is recorded.
- S3..S12 children run inside `unshare --user --map-root-user --net` (probed first; no fallback).
- x7 may only be invoked with the subcommands `abi` and `run`.
- Logs, receipts and step records are created exclusively (O_EXCL) and made read-only; a step that already
  has a record is never rerun. Stop at the first non-GREEN step.
- Hashes are checked before use: the 54-member SOURCE-FREEZE, the lockfile, toolchain binaries, x7 binary
  and every output consumed by a later step.

Usage: python3 -I x7_run_control.py --phase pre|build|run|final
"""
import datetime
import glob
import hashlib
import json
import os
import re
import resource
import shutil
import signal
import subprocess
import sys
import time
import traceback
from pathlib import Path

ATTEMPT = "attempt-1"
TASK = Path("/home/charl/moriarty-eutxo-validation-2026-10-12/claim-utxo-prototype-source-20261015/implementation-attempt-2")
EXEC = TASK / "rust-research-execution-1"
SRC = TASK / "source"
FROZEN = Path("/home/charl/moriarty-eutxo-validation-2026-10-12/groth16-preprod-experiments-20261015")
FREEZE = TASK / "independent-opus-review" / "SOURCE-FREEZE.json"
CONTROL = EXEC / "control" / "x7_run_control.py"
LOGS = EXEC / "logs"
RECEIPTS = EXEC / "receipts"
STEPS = RECEIPTS / "steps"
OUT = EXEC / "out"
BUILD = EXEC / "build"
TARGET = BUILD / "x7-target"
X7 = TARGET / "release" / "x7"
TMP = BUILD / "tmp"
EMPTY_CWD = BUILD / "cwd-empty"
LOCK_SRC = FROZEN / "g16" / "Cargo.lock"
LOCK_DST = SRC / "x7" / "Cargo.lock"
GENERATED = OUT / "generated" / "x7_vectors_test.ak"
AIKEN_TARGET_NEVER = SRC / "aiken" / "lib" / "pvc" / "x7_vectors_test.ak"

DECLARED = {
    "DECLARED_OUTREF": "44" * 32 + "#1",
    "DECLARED_REFUND_VKH": "55" * 28,
    "DECLARED_EXPIRY_MS": "1000",
}
AS_LIMIT = 34359738368  # 32 GiB
NICE = 10
THREADS = "8"
NS_FLAGS = ["--user", "--map-root-user", "--net"]
FREEZE_MEMBERS = 54

# Audit section 14 digest prefixes; ties SOURCE-FREEZE.json to the audit text.
AUDIT_PREFIXES = {
    str(FROZEN / "g16/src/gadgets.rs"): "a7cf1c0a",
    str(FROZEN / "g16/src/circuit.rs"): "624dadc2",
    str(FROZEN / "g16/Cargo.lock"): "f439fa5f",
    str(FROZEN / "data/selected/template.json"): "a983ebf4",
    str(FROZEN / "data/selected/selected-body.bin"): "37bbdf92",
    str(FROZEN / "data/selected/selection.json"): "3b83bbb9",
    str(FROZEN / "data/moriarty/payment.mori"): "f1f4807b",
    str(FROZEN / "out/x0/moriref.json"): "37067d0e",
}
DOCS = ["ABI-v0.md", "EXPECTED-OUTCOMES.md", "EXECUTION-REQUEST.json", "SOURCE-SELECTION.md", "REPORT.md", "WORK-STARTED.md"]
FROZEN_INPUTS = ["g16/src/gadgets.rs", "g16/src/circuit.rs", "g16/Cargo.lock", "data/selected/template.json",
                 "data/selected/selected-body.bin", "data/selected/selection.json", "data/moriarty/payment.mori",
                 "out/x0/moriref.json"]
RUN_OUT_FILES = {"vk.bin", "proof.bin", "statement.bin", "claim.json", "admission.json", "results.json"}
WALL = {"S3": 60, "S4": 1800, "S5": 1800, "S6": 3600, "S7": 120, "S10": 7200, "S11": 7200, "S12": 120, "NS-probe": 60}

PHASES = {
    "pre": ["S-meta", "S0-manifest-before", "S0b-freeze-check", "S1-frozen-inputs", "NS-probe", "S2-lockfile", "S3-toolchain"],
    "build": ["S4-cargo-build", "S5-cargo-test", "S6-x7-abi", "S7-abi-ref-compare"],
    "run": ["S10-x7-run-L1", "S11-x7-run-M1", "S12-gen-aiken-vectors"],
    "final": ["S14-verify"],
}
ORDER = [s for p in ("pre", "build", "run") for s in PHASES[p]]

PROBE_CODE = r"""
import json, os
def r(p):
    try:
        with open(p) as f:
            return f.read()
    except Exception as e:
        return "ERR " + type(e).__name__
lim = {}
for line in r("/proc/self/limits").splitlines():
    if line.startswith("Max address space") or line.startswith("Max core file size"):
        lim[line[:26].strip()] = line[26:].split()[:2]
st = r("/proc/self/stat")
print(json.dumps({"uid": os.getuid(), "euid": os.geteuid(), "gid": os.getgid(),
    "uid_map": r("/proc/self/uid_map"), "gid_map": r("/proc/self/gid_map"), "setgroups": r("/proc/self/setgroups"),
    "netns": os.readlink("/proc/self/ns/net"), "userns": os.readlink("/proc/self/ns/user"),
    "net_dev": r("/proc/self/net/dev"), "route": r("/proc/self/net/route"), "ipv6_route": r("/proc/self/net/ipv6_route"),
    "limits": lim, "nice": int(st.rsplit(")", 1)[1].split()[16]) if ")" in st else None}))
"""


class Stop(Exception):
    """A gate or expectation failed; the step is FAILED (or BLOCKED when status is given)."""

    def __init__(self, msg, status="FAILED"):
        super().__init__(msg)
        self.status = status


# ---------------------------------------------------------------- primitives

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def write_new(path, data, mode=0o444):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, str):
        data = data.encode()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    with os.fdopen(fd, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(path, mode)


def write_json(path, obj):
    write_new(path, json.dumps(obj, indent=2) + "\n")


def journal(obj):
    RECEIPTS.mkdir(parents=True, exist_ok=True)
    with open(RECEIPTS / "journal.jsonl", "a") as f:
        f.write(json.dumps({"at": utc(), **obj}) + "\n")


def sumline(digest, name):
    return f"{digest}  {name}\n"


def read_receipt_digest(path, name=None):
    """First digest in a sha256sum-format receipt, or the digest for `name`."""
    for line in Path(path).read_text().splitlines():
        d, _, n = line.partition("  ")
        if name is None or n == name:
            return d
    raise Stop(f"receipt {path} has no entry for {name}")


def mkdir_new(p):
    p = Path(p)
    if p.exists():
        raise Stop(f"{p} already exists; outputs are never overwritten")
    p.mkdir(parents=True)


# ---------------------------------------------------------------- freeze / source checks

def load_freeze():
    raw = FREEZE.read_bytes()
    h = hashlib.sha256(raw).hexdigest()
    pin = RECEIPTS / "source-freeze-json.sha256"
    if pin.exists() and read_receipt_digest(pin) != h:
        raise Stop(f"SOURCE-FREEZE.json changed during the attempt: {h}")
    files = json.loads(raw)["files"]
    if len(files) != FREEZE_MEMBERS:
        raise Stop(f"SOURCE-FREEZE has {len(files)} members, expected {FREEZE_MEMBERS}")
    return files, h


def verify_freeze():
    files, h = load_freeze()
    rows, bad = [], []
    for e in files:
        p = Path(e["path"])
        try:
            got_b, got_s = p.stat().st_size, sha(p)
        except OSError as ex:
            got_b, got_s = None, f"ERR {type(ex).__name__}"
        ok = got_s == e["sha256"] and got_b == e["bytes"]
        rows.append({"path": e["path"], "role": e["role"], "ok": ok, "sha256": got_s, "bytes": got_b})
        if not ok:
            bad.append(e["path"])
    return rows, bad, h


def require_freeze():
    _, bad, _ = verify_freeze()
    if bad:
        raise Stop(f"SOURCE-FREEZE mismatch before use: {bad}")


def require_lock():
    want = read_receipt_digest(RECEIPTS / "cargo-lock-sha256.txt", str(LOCK_DST))
    if not LOCK_DST.is_file() or sha(LOCK_DST) != want:
        raise Stop("source/x7/Cargo.lock differs from the S2 receipt")


def walk_files(root):
    files, links = [], []
    for dp, dns, fns in os.walk(root, followlinks=False):
        for n in list(dns) + fns:
            if os.path.islink(os.path.join(dp, n)):
                links.append(os.path.join(dp, n))
        files += [Path(dp) / f for f in fns]
    return sorted(files), links


def candidate_source_paths():
    files, _ = load_freeze()
    pre = str(SRC) + "/"
    return {e["path"]: e for e in files if e["path"].startswith(pre)}


# ---------------------------------------------------------------- tools / env

def toolchain():
    p = RECEIPTS / "toolchain.json"
    if not p.exists():
        raise Stop("toolchain.json missing (S3 not GREEN)")
    return json.loads(p.read_text())


def require_tool_hashes():
    t = toolchain()
    for path, want in t["pinnedBinaries"].items():
        if sha(path) != want:
            raise Stop(f"toolchain binary changed since S3: {path}")
    return t


def require_x7():
    want = read_receipt_digest(RECEIPTS / "x7-binary-sha256.txt", str(X7))
    got = sha(X7)
    if got != want:
        raise Stop(f"x7 binary digest {got} differs from S4 receipt {want}")
    return got


def child_env(extra=None, rust=False):
    home = os.environ["HOME"]
    path = [str(Path(home) / ".cargo" / "bin"), "/usr/local/bin", "/usr/bin", "/bin"]
    env = {
        "HOME": home,
        "USER": os.environ.get("USER", ""),
        "LOGNAME": os.environ.get("LOGNAME", os.environ.get("USER", "")),
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "TZ": "UTC",
        "TMPDIR": str(TMP),
        "TASK": str(TASK),
        "TASK_SOURCE": str(SRC),
        "EXEC": str(EXEC),
        "FROZEN": str(FROZEN),
        "X7": str(X7),
        "RAYON_NUM_THREADS": THREADS,
        **DECLARED,
    }
    if rust:
        t = toolchain()
        path.insert(0, t["toolchainBin"])
        env.update({
            "RUSTUP_HOME": t["rustupHome"],
            "CARGO_HOME": t["cargoHome"],
            "RUSTUP_AUTO_INSTALL": "0",
            "CARGO_NET_OFFLINE": "true",
            "CARGO_TERM_COLOR": "never",
            "CARGO_BUILD_JOBS": THREADS,
            "RUST_TEST_THREADS": THREADS,
            "RUSTC": t["rustc"],
        })
        if t.get("toolchain"):
            env["RUSTUP_TOOLCHAIN"] = t["toolchain"]
    env["PATH"] = ":".join(path)
    if extra:
        env.update(extra)
    return env


def _limits():
    os.nice(NICE)
    resource.setrlimit(resource.RLIMIT_AS, (AS_LIMIT, AS_LIMIT))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def _observe(pid):
    obs = {}
    try:
        for line in Path(f"/proc/{pid}/limits").read_text().splitlines():
            if line.startswith("Max address space") or line.startswith("Max core file size"):
                obs[line[:26].strip()] = line[26:].split()[:2]
        st = Path(f"/proc/{pid}/stat").read_text()
        obs["nice"] = int(st.rsplit(")", 1)[1].split()[16])
    except Exception as e:  # child may already be gone
        obs["error"] = type(e).__name__
    return obs


def _drain_group(pgid):
    deadline = time.monotonic() + 60
    killed = False
    while True:
        try:
            os.killpg(pgid, 0)
        except ProcessLookupError:
            return {"groupEmpty": True, "sigkillSent": killed}
        except PermissionError:
            return {"groupEmpty": "EPERM", "sigkillSent": killed}
        if time.monotonic() > deadline and not killed:
            os.killpg(pgid, signal.SIGKILL)
            killed = True
            deadline = time.monotonic() + 30
        elif time.monotonic() > deadline:
            return {"groupEmpty": False, "sigkillSent": killed}
        time.sleep(0.25)


def run_child(cid, argv, *, cwd, env, deadline, ns=True, stdout_path=None):
    """Run one child; return its record. Never raises for a non-zero exit."""
    tools = json.loads((RECEIPTS / "probe-tools.json").read_text())
    if sha(tools["unshare"]) != tools["unshareSha256"] or sha(tools["python3"]) != tools["python3Sha256"]:
        raise Stop("unshare or python3 binary changed since NS-probe")
    if ns:
        full = [tools["unshare"], *NS_FLAGS, "--", *argv]
    else:
        full = list(argv)
    wall = max(1, int(deadline - time.monotonic()))
    out_p = Path(stdout_path) if stdout_path else LOGS / f"{cid}.stdout.log"
    err_p = LOGS / f"{cid}.stderr.log"
    LOGS.mkdir(parents=True, exist_ok=True)
    fo = os.fdopen(os.open(out_p, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644), "wb")
    fe = os.fdopen(os.open(err_p, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644), "wb")
    rec = {"id": cid, "argv": full, "cwd": str(cwd), "env": env, "namespace": NS_FLAGS if ns else None,
           "wallSeconds": wall, "limitsRequested": {"nice": f"+{NICE}", "RLIMIT_AS": AS_LIMIT, "RLIMIT_CORE": 0},
           "startedAt": utc()}
    print(f"\n=== {cid} :: {full}", flush=True)
    t0 = time.monotonic()
    timed_out = False
    with fo, fe:
        p = subprocess.Popen(full, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=fo, stderr=fe,
                             start_new_session=True, preexec_fn=_limits, close_fds=True)
        rec["pid"] = p.pid
        rec["limitsObserved"] = _observe(p.pid)
        try:
            rc = p.wait(timeout=wall)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(p.pid, signal.SIGTERM)
            try:
                rc = p.wait(timeout=60)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)
                rc = p.wait()
        rec["group"] = _drain_group(p.pid)
        fo.flush()
        fe.flush()
    rec.update({"endedAt": utc(), "durationSeconds": round(time.monotonic() - t0, 3), "returncode": rc,
                "signal": signal.Signals(-rc).name if rc < 0 else None, "timedOut": timed_out,
                "stdout": {"path": str(out_p), "bytes": out_p.stat().st_size, "sha256": sha(out_p)},
                "stderr": {"path": str(err_p), "bytes": err_p.stat().st_size, "sha256": sha(err_p)}})
    os.chmod(out_p, 0o444)
    os.chmod(err_p, 0o444)
    write_new(LOGS / f"{cid}.exit", f"{rc}\n")
    write_json(LOGS / f"{cid}.record.json", rec)
    for label, pth in (("stdout", out_p), ("stderr", err_p)):
        lines = pth.read_text(errors="replace").splitlines()
        tail = lines[-60:]
        print(f"--- {cid} {label} ({len(lines)} lines{', last 60' if len(lines) > 60 else ''})")
        for line in tail:
            print(line)
    print(f"--- {cid} exit {rc} signal {rec['signal']} timedOut {timed_out} in {rec['durationSeconds']}s "
          f"limits {rec['limitsObserved']} group {rec['group']}", flush=True)
    return rec


def ok_or_stop(rec, what):
    if rec["returncode"] != 0 or rec["timedOut"]:
        raise Stop(f"{what}: exit {rec['returncode']} signal {rec['signal']} timedOut {rec['timedOut']}")


def x7_argv(sub, *args):
    if sub not in ("abi", "run"):
        raise Stop(f"x7 subcommand {sub!r} is not authorized")
    return [str(X7), sub, *args]


# ---------------------------------------------------------------- steps

def s_meta(ctx):
    def r(p):
        try:
            return Path(p).read_text()
        except Exception as e:
            return f"ERR {type(e).__name__}"
    mem = {k: v.strip() for k, _, v in (l.partition(":") for l in r("/proc/meminfo").splitlines()) if k in ("MemTotal", "SwapTotal", "SwapFree")}
    core_pattern = r("/proc/sys/kernel/core_pattern").strip()
    meta = {
        "attempt": ATTEMPT, "at": utc(),
        "controlScript": {"path": str(CONTROL), "sha256": sha(CONTROL)},
        "python": {"executable": sys.executable, "realpath": os.path.realpath(sys.executable), "version": sys.version,
                   "flags_isolated": sys.flags.isolated},
        "uname": list(os.uname()), "procVersion": r("/proc/version").strip(),
        "cpuCount": os.cpu_count(), "affinity": sorted(os.sched_getaffinity(0)), "mem": mem,
        "corePattern": core_pattern, "corePatternIsPipe": core_pattern.startswith("|"),
        "corePipeLimit": r("/proc/sys/kernel/core_pipe_limit").strip(),
        "suidDumpable": r("/proc/sys/fs/suid_dumpable").strip(),
        "procSwaps": r("/proc/swaps"),
        "maxUserNamespaces": r("/proc/sys/user/max_user_namespaces").strip(),
        "unprivilegedUsernsClone": r("/proc/sys/kernel/unprivileged_userns_clone").strip(),
        "parentNetns": os.readlink("/proc/self/ns/net"), "parentUserns": os.readlink("/proc/self/ns/user"),
        "parentUid": os.getuid(), "parentNice": os.nice(0),
        "parentRlimits": {"AS": resource.getrlimit(resource.RLIMIT_AS), "CORE": resource.getrlimit(resource.RLIMIT_CORE)},
        "parentEnvRustCargoVarNames": sorted(k for k in os.environ if k.startswith(("RUST", "CARGO"))),
        "residuals": [
            "RLIMIT_CORE=0 does not suppress a pipe core_pattern handler; any signal exit of S10/S11 marks that run's VK compromised",
            "swap residue of in-process PK/trapdoor pages is a recorded Class 0 residual when swap is active",
        ],
    }
    write_json(RECEIPTS / "host-metadata.json", meta)
    variables = {
        "TASK": str(TASK), "TASK_meaning": "original candidate root (source read-only except the S2 Cargo.lock copy)",
        "TASK_SOURCE": str(SRC), "EXEC": str(EXEC), "EXEC_meaning": "isolated new execution root: control, logs, receipts, out, build",
        "FROZEN": str(FROZEN), "X7": str(X7),
        "pathMapping": {"$TASK/logs": str(LOGS), "$TASK/receipts": str(RECEIPTS), "$TASK/out": str(OUT),
                        "$TASK/build": str(BUILD), "$TASK/out/generated": str(OUT / "generated"),
                        "/tmp (cwd of S7/S12)": str(EMPTY_CWD)},
        **DECLARED,
        "DECLARED_note": "synthetic ABI UNIT context placeholders chosen by the request, not ledger observations or real Preprod claims",
        "RAYON_NUM_THREADS": THREADS, "nice": NICE, "RLIMIT_AS": AS_LIMIT, "RLIMIT_CORE": 0,
        "namespace": ["unshare", *NS_FLAGS], "wallSeconds": WALL,
    }
    write_json(RECEIPTS / "variables.json", variables)
    for d in (TMP, EMPTY_CWD):
        mkdir_new(d)
    return {"corePatternIsPipe": meta["corePatternIsPipe"], "swapActive": len(meta["procSwaps"].splitlines()) > 1}


def s0(ctx):
    files, links = walk_files(SRC)
    if links:
        raise Stop(f"symlinks in source tree: {links}")
    rel = [f.relative_to(TASK) for f in files]
    excluded = [str(r) for r in rel if str(r).startswith("source/aiken/build/") or r.name in ("aiken.lock", "Cargo.lock")]
    if excluded:
        raise Stop(f"files that S2/S8 must create already exist: {excluded}")
    write_new(RECEIPTS / "source-sha256.before.txt", "".join(sumline(sha(f), str(r)) for f, r in zip(files, rel)))
    cand = candidate_source_paths()
    got = {str(f) for f in files}
    if got != set(cand):
        raise Stop(f"source tree set differs from SOURCE-FREEZE candidates: extra {sorted(got - set(cand))} missing {sorted(set(cand) - got)}")
    bad = [str(f) for f in files if sha(f) != cand[str(f)]["sha256"]]
    if bad:
        raise Stop(f"source digest mismatch: {bad}")
    docs = "".join(sumline(sha(TASK / d), d) for d in DOCS)
    write_new(RECEIPTS / "docs-sha256.txt", docs)
    frz = {e["path"]: e["sha256"] for e in load_freeze()[0]}
    bad_docs = [d for d in DOCS if frz.get(str(TASK / d)) != sha(TASK / d)]
    if bad_docs:
        raise Stop(f"doc digest mismatch: {bad_docs}")
    return {"sourceFiles": len(files), "matchesFreeze": True}


def s0b(ctx):
    rows, bad, h = verify_freeze()
    write_new(RECEIPTS / "source-freeze-json.sha256", sumline(h, str(FREEZE)))
    write_new(RECEIPTS / "source-freeze-check.txt",
              "".join(f"{r['path']}: {'OK' if r['ok'] else 'FAILED ' + str(r['sha256'])}\n" for r in rows))
    files = {e["path"]: e["sha256"] for e in load_freeze()[0]}
    pref_bad = [p for p, pre in AUDIT_PREFIXES.items() if not files.get(p, "").startswith(pre)]
    if bad or pref_bad:
        raise Stop(f"freeze check failed: mismatched {bad}; audit-prefix mismatch {pref_bad}")
    roles = {}
    for r in rows:
        roles[r["role"]] = roles.get(r["role"], 0) + 1
    return {"members": len(rows), "allOk": True, "roles": roles, "sourceFreezeSha256": h}


def s1(ctx):
    frz = {e["path"]: e["sha256"] for e in load_freeze()[0]}
    lines, bad = [], []
    for rel in FROZEN_INPUTS:
        d = sha(FROZEN / rel)
        lines.append(sumline(d, rel))
        if frz.get(str(FROZEN / rel)) != d:
            bad.append(rel)
    write_new(RECEIPTS / "frozen-inputs-sha256.txt", "".join(lines))
    if bad:
        raise Stop(f"frozen input mismatch: {bad}")
    return {"frozenInputs": len(FROZEN_INPUTS), "matchFreeze": True}


def ns_probe(ctx):
    unshare = shutil.which("unshare", path="/usr/bin:/bin")
    py = os.path.realpath("/usr/bin/python3")
    if not unshare:
        raise Stop("unshare not found in /usr/bin:/bin", "BLOCKED")
    unshare = os.path.realpath(unshare)
    tools = {"unshare": unshare, "unshareSha256": sha(unshare), "python3": py, "python3Sha256": sha(py)}
    write_json(RECEIPTS / "probe-tools.json", tools)
    deadline = time.monotonic() + WALL["NS-probe"]
    rec = run_child("NS-probe", [py, "-I", "-c", PROBE_CODE], cwd=EMPTY_CWD, env=child_env(), deadline=deadline)
    if rec["returncode"] != 0:
        raise Stop(f"no-network namespace unavailable: exit {rec['returncode']}; see {rec['stderr']['path']}", "BLOCKED")
    probe = json.loads(Path(rec["stdout"]["path"]).read_text())
    ifaces = sorted(l.split(":")[0].strip() for l in probe["net_dev"].splitlines()[2:] if ":" in l)
    route_ifaces = {l.split()[0] for l in probe["route"].splitlines()[1:] if l.strip()}
    route6_ifaces = set() if probe["ipv6_route"].startswith("ERR") else {l.split()[-1] for l in probe["ipv6_route"].splitlines() if l.strip()}
    uid_map = probe["uid_map"].split()
    exp_nice = min(os.nice(0) + NICE, 19)
    checks = {
        "uid0InNamespace": probe["uid"] == 0 and probe["euid"] == 0,
        "uidMapsToCaller": uid_map[:3] == ["0", str(os.getuid()), "1"],
        "netnsDiffers": probe["netns"] != os.readlink("/proc/self/ns/net"),
        "usernsDiffers": probe["userns"] != os.readlink("/proc/self/ns/user"),
        "onlyLoopback": ifaces == ["lo"],
        "ipv4RoutesLoopbackOnly": route_ifaces <= {"lo"},
        "ipv6RoutesLoopbackOnly": route6_ifaces <= {"lo"},
        "rlimitAs": probe["limits"].get("Max address space") == [str(AS_LIMIT), str(AS_LIMIT)],
        "rlimitCore": probe["limits"].get("Max core file size") == ["0", "0"],
        "nice": probe["nice"] == exp_nice,
    }
    write_json(RECEIPTS / "ns-probe.json", {"probe": probe, "interfaces": ifaces, "checks": checks})
    if not all(checks.values()):
        raise Stop(f"namespace/limits probe not as required: {[k for k, v in checks.items() if not v]}", "BLOCKED")
    return {"checks": checks, "interfaces": ifaces}


def s2(ctx):
    require_freeze()
    if LOCK_DST.exists():
        raise Stop("source/x7/Cargo.lock already exists; refusing to overwrite")
    data = LOCK_SRC.read_bytes()
    want = {e["path"]: e["sha256"] for e in load_freeze()[0]}[str(LOCK_SRC)]
    if hashlib.sha256(data).hexdigest() != want:
        raise Stop("frozen g16/Cargo.lock digest differs from freeze")
    fd = os.open(LOCK_DST, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    with os.fdopen(fd, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    a, b = sha(LOCK_SRC), sha(LOCK_DST)
    write_new(RECEIPTS / "cargo-lock-sha256.txt", sumline(a, str(LOCK_SRC)) + sumline(b, str(LOCK_DST)))
    if a != b or a != want:
        raise Stop(f"lockfile copy mismatch {a} {b}")
    return {"lockSha256": a, "bytes": len(data)}


def _toml_keys(p):
    try:
        import tomllib
    except ImportError:
        return "tomllib unavailable"
    try:
        d = tomllib.loads(Path(p).read_text())
    except Exception as e:
        return f"parse error {type(e).__name__}"
    out = {}

    def walk(prefix, v):
        if isinstance(v, dict):
            for k, x in v.items():
                walk(f"{prefix}.{k}" if prefix else k, x)
        else:
            out[prefix] = "<redacted>" if re.search(r"token|secret|password|auth", prefix, re.I) else repr(v)
    walk("", d)
    return out


def s3(ctx):
    deadline = time.monotonic() + WALL["S3"]
    home = Path(os.environ["HOME"])
    cargo_home = os.environ.get("CARGO_HOME") or str(home / ".cargo")
    rustup_home = os.environ.get("RUSTUP_HOME") or str(home / ".rustup")
    pin = {}
    lines = []

    def h(path):
        rp = os.path.realpath(path)
        d = sha(rp)
        pin[rp] = d
        lines.append(sumline(d, rp if rp == str(path) else f"{path} -> {rp}"))
        return rp

    search = f"{cargo_home}/bin:/usr/local/bin:/usr/bin:/bin"
    rustup = shutil.which("rustup", path=search)
    shims = {n: shutil.which(n, path=search) for n in ("cargo", "rustc")}
    for n, pth in shims.items():
        if pth:
            h(pth)  # sha256sum $(command -v cargo) $(command -v rustc), as requested
    env0 = child_env(extra={"RUSTUP_HOME": rustup_home, "CARGO_HOME": cargo_home, "RUSTUP_AUTO_INSTALL": "0"})
    tc = None
    if rustup:
        h(rustup)
        r = run_child("S3.01-rustup-show-active-toolchain", [rustup, "show", "active-toolchain"], cwd=SRC / "x7", env=env0, deadline=deadline)
        ok_or_stop(r, "rustup show active-toolchain")
        first = Path(r["stdout"]["path"]).read_text().split()
        tc = first[0] if first else ""
        if not re.fullmatch(r"[A-Za-z0-9._-]+", tc):
            raise Stop(f"cannot parse active toolchain from {first!r}")
        env1 = dict(env0, RUSTUP_TOOLCHAIN=tc)
        paths = {}
        for i, n in ((2, "cargo"), (3, "rustc")):
            r = run_child(f"S3.0{i}-rustup-which-{n}", [rustup, "which", n], cwd=SRC / "x7", env=env1, deadline=deadline)
            ok_or_stop(r, f"rustup which {n}")
            paths[n] = Path(r["stdout"]["path"]).read_text().strip()
        cargo, rustc = paths["cargo"], paths["rustc"]
    else:
        if not (shims["cargo"] and shims["rustc"]):
            raise Stop("no rustup and no cargo/rustc on PATH")
        cargo, rustc = os.path.realpath(shims["cargo"]), os.path.realpath(shims["rustc"])
    # Pin the real toolchain binaries before their first invocation.
    cargo, rustc = h(cargo), h(rustc)
    tc_root = Path(rustc).parent.parent
    for lib in sorted(glob.glob(str(tc_root / "lib" / "librustc_driver-*.so"))) + sorted(glob.glob(str(tc_root / "lib" / "libstd-*.so"))):
        h(lib)
    for n in ("cc", "ld"):
        p = shutil.which(n, path="/usr/local/bin:/usr/bin:/bin")
        if p:
            h(p)
    aiken = shutil.which("aiken", path=f"{home}/.aiken/bin:{cargo_home}/bin:{home}/.local/bin:/usr/local/bin:/usr/bin")
    if aiken:
        aiken = h(aiken)
    py = h("/usr/bin/python3")
    write_new(RECEIPTS / "tool-binaries-sha256.txt", "".join(lines))
    t = {"toolchain": tc, "rustup": rustup and os.path.realpath(rustup), "cargo": cargo, "rustc": rustc,
         "toolchainBin": str(Path(cargo).parent), "cargoHome": cargo_home, "rustupHome": rustup_home,
         "aiken": aiken, "python3": py, "pinnedBinaries": pin}
    # Write toolchain.json now so child_env(rust=True) can use the pinned paths.
    write_json(RECEIPTS / "toolchain.json", t)
    envr = child_env(rust=True)
    vers = {}
    for cid, argv in (("S3.04-cargo-version", [cargo, "--version", "--verbose"]),
                      ("S3.05-rustc-version", [rustc, "--version", "--verbose"]),
                      ("S3.06-rustc-sysroot", [rustc, "--print", "sysroot"]),
                      ("S3.08-python3-version", [py, "-I", "--version"])):
        r = run_child(cid, argv, cwd=SRC / "x7", env=envr, deadline=deadline)
        ok_or_stop(r, cid)
        vers[cid] = Path(r["stdout"]["path"]).read_text().strip()
    if aiken:
        r = run_child("S3.07-aiken-version", [aiken, "--version"], cwd=EMPTY_CWD, env=child_env(), deadline=deadline)
        ok_or_stop(r, "aiken --version")
        vers["S3.07-aiken-version"] = Path(r["stdout"]["path"]).read_text().strip()
    sysroot = vers["S3.06-rustc-sysroot"]
    if os.path.realpath(sysroot) != str(tc_root):
        raise Stop(f"rustc sysroot {sysroot} is not the pinned toolchain root {tc_root}")
    commit = re.search(r"^commit-hash: (\S+)$", vers["S3.05-rustc-version"], re.M)
    configs = []
    cands = [Path(cargo_home) / "config.toml", Path(cargo_home) / "config"]
    for anc in [SRC / "x7", *(SRC / "x7").parents]:
        cands += [anc / ".cargo" / "config.toml", anc / ".cargo" / "config"]
    for c in cands:
        if c.is_file():
            configs.append({"path": str(c), "sha256": sha(c), "keys": _toml_keys(c)})
    aiken_v = vers.get("S3.07-aiken-version")
    meta = {"versions": vers, "rustcCommit": commit.group(1) if commit else None, "cargoConfigs": configs,
            "aikenVersionMatchesToml": bool(aiken_v and "1.1.21" in aiken_v),
            "aikenNote": "Aiken steps S8/S9/S13 are out of scope for this job; the aiken version is recorded, not a gate for Rust steps"}
    write_json(RECEIPTS / "toolchain-versions.json", meta)
    return {"toolchain": tc, "rustcCommit": meta["rustcCommit"], "aiken": aiken_v, "cargoConfigs": [c["path"] for c in configs]}


def _cargo_home_state():
    ch = Path(toolchain()["cargoHome"])
    src = ch / "registry" / "src"
    dirs = sorted(f"{i.name}/{c}" for i in src.iterdir() if i.is_dir() for c in os.listdir(i)) if src.is_dir() else []
    pc = ch / ".package-cache"
    return {"registrySrcDirs": dirs, "packageCacheMtime": pc.stat().st_mtime if pc.exists() else None}


def s4(ctx):
    require_freeze()
    require_lock()
    t = require_tool_hashes()
    if TARGET.exists():
        raise Stop("build target dir already exists")
    before = _cargo_home_state()
    r = run_child("S4-cargo-build", [t["cargo"], "build", "--release", "--offline", "--locked"], cwd=SRC / "x7",
                  env=child_env(rust=True, extra={"CARGO_TARGET_DIR": str(TARGET)}), deadline=time.monotonic() + WALL["S4"])
    after = _cargo_home_state()
    write_json(RECEIPTS / "cargo-home-side-effects-S4.json", {
        "before": {"packageCacheMtime": before["packageCacheMtime"], "registrySrcCount": len(before["registrySrcDirs"])},
        "after": {"packageCacheMtime": after["packageCacheMtime"], "registrySrcCount": len(after["registrySrcDirs"])},
        "newlyExtracted": sorted(set(after["registrySrcDirs"]) - set(before["registrySrcDirs"]))})
    ok_or_stop(r, "cargo build")
    if not X7.is_file():
        raise Stop("x7 binary missing after build")
    xd, ld = sha(X7), sha(LOCK_DST)
    write_new(RECEIPTS / "x7-binary-sha256.txt", sumline(xd, str(X7)) + sumline(ld, str(LOCK_DST)))
    require_lock()
    return {"x7Sha256": xd, "x7Bytes": X7.stat().st_size, "lockUnchanged": True}


def s5(ctx):
    require_freeze()
    require_lock()
    t = require_tool_hashes()
    require_x7()
    r = run_child("S5-cargo-test", [t["cargo"], "test", "--release", "--offline", "--locked"], cwd=SRC / "x7",
                  env=child_env(rust=True, extra={"CARGO_TARGET_DIR": str(TARGET)}), deadline=time.monotonic() + WALL["S5"])
    ok_or_stop(r, "cargo test")
    text = Path(r["stdout"]["path"]).read_text()
    res = re.findall(r"^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored", text, re.M)
    passed = sum(int(x[1]) for x in res)
    failed = sum(int(x[2]) for x in res)
    names = re.findall(r"^test (\S+) \.\.\. (\w+)$", text, re.M)
    require_lock()
    require_x7()
    if passed != 9 or failed != 0:
        raise Stop(f"expected 9 passed / 0 failed, observed {passed} passed / {failed} failed")
    return {"passed": passed, "failed": failed, "tests": names}


def s6(ctx):
    require_freeze()
    xd = require_x7()
    if (OUT / "abi").exists():
        raise Stop("out/abi already exists")
    OUT.mkdir(exist_ok=True)
    r = run_child("S6-x7-abi", x7_argv("abi", "--frozen", str(FROZEN), "--catalogue", str(SRC / "catalogue"), "--out", str(OUT)),
                  cwd=EXEC, env=child_env(), deadline=time.monotonic() + WALL["S6"])
    res_p = OUT / "abi" / "results.json"
    if res_p.is_file():
        write_new(RECEIPTS / "out-abi-sha256.txt", sumline(sha(res_p), str(res_p)))
    ok_or_stop(r, "x7 abi")
    require_x7()
    d = json.loads(res_p.read_text())
    lines = Path(r["stdout"]["path"]).read_text().splitlines()
    tags = [l.split("]")[0] + "]" for l in lines if l.startswith("[")]
    return {"x7Sha256": xd, "resultCount": len(d["results"]), "allAsExpected": d["allAsExpected"],
            "stdoutAsExpected": tags.count("[AS-EXPECTED]"), "stdoutUnexpected": tags.count("[UNEXPECTED]"),
            "rows": {k: {"constraints": v["constraints"], "r1csConstraints": v["r1csConstraints"], "r1csDigest": v["r1csDigest"],
                         "statementLen": len(v["statementHex"]) // 2} for k, v in d["rows"].items()},
            "auditExpectation": "21 result lines, all AS-EXPECTED; L1 361339 / M1 307482 constraints; statements 236 / 733"}


def s7(ctx):
    require_freeze()
    res_p = OUT / "abi" / "results.json"
    if sha(res_p) != read_receipt_digest(RECEIPTS / "out-abi-sha256.txt", str(res_p)):
        raise Stop("out/abi/results.json differs from S6 receipt")
    script = SRC / "scripts" / "abi_ref.py"
    ref_p = OUT / "abi" / "abi_ref.json"
    py = require_tool_hashes()["python3"]
    r = run_child("S7-abi-ref-compare", [py, "-I", str(script), "--catalogue", str(SRC / "catalogue"), "--compare", str(res_p)],
                  cwd=EMPTY_CWD, env=child_env(), deadline=time.monotonic() + WALL["S7"], stdout_path=ref_p)
    write_new(RECEIPTS / "out-abi-ref-sha256.txt", sumline(sha(res_p), str(res_p)) + sumline(sha(ref_p), str(ref_p)))
    ok_or_stop(r, "abi_ref compare")
    err = Path(r["stderr"]["path"]).read_text().strip().splitlines()
    cmp = json.loads(err[-1]) if err else None
    if not cmp or cmp.get("mismatches") != []:
        raise Stop(f"abi_ref compare did not report mismatches []: {cmp}")
    return {"mismatches": cmp["mismatches"], "note": "same-author re-implementation agreement only; not an independent oracle"}


def _blake2b(b):
    return hashlib.blake2b(b, digest_size=32).digest()


def s_run(ctx, row, sid, extra_prior):
    require_freeze()
    xd = require_x7()
    for p in extra_prior:
        f = OUT / p / "claim.json"
        if sha(f) != read_receipt_digest(RECEIPTS / f"out-{p}-sha256.txt", str(f)):
            raise Stop(f"{f} differs from its receipt")
    d = OUT / row
    if d.exists():
        raise Stop(f"{d} already exists")
    tmp_before = sorted(os.listdir(TMP))
    r = run_child(sid, x7_argv("run", "--row", row, "--frozen", str(FROZEN), "--catalogue", str(SRC / "catalogue"), "--out", str(OUT),
                               "--outref", DECLARED["DECLARED_OUTREF"], "--expiry", DECLARED["DECLARED_EXPIRY_MS"],
                               "--refund-vkh", DECLARED["DECLARED_REFUND_VKH"]),
                  cwd=EXEC, env=child_env(), deadline=time.monotonic() + WALL[sid.split("-")[0]])
    if r["returncode"] < 0 or r["timedOut"]:
        write_json(RECEIPTS / f"{row}-VK-COMPROMISED.json", {
            "row": row, "returncode": r["returncode"], "signal": r["signal"], "timedOut": r["timedOut"],
            "verdict": "abnormal signal exit during a run holding PK/trapdoor in memory: this run's VK (if any) is COMPROMISED and must never be pinned"})
    files = sorted(os.listdir(d)) if d.is_dir() else []
    if files:
        write_new(RECEIPTS / f"out-{row}-sha256.txt", "".join(sumline(sha(d / f), str(d / f)) for f in files))
    ok_or_stop(r, f"x7 run {row}")
    require_x7()
    if set(files) != RUN_OUT_FILES:
        raise Stop(f"unexpected output set in {d}: {files}")
    sizes = {f: (d / f).stat().st_size for f in files}
    if sizes["vk.bin"] != 488 or sizes["proof.bin"] != 192:
        raise Stop(f"vk/proof sizes {sizes['vk.bin']}/{sizes['proof.bin']} differ from 488/192")
    if sorted(os.listdir(TMP)) != tmp_before:
        raise Stop(f"TMPDIR changed during run: {sorted(os.listdir(TMP))}")
    big = [str(p) for p in EXEC.rglob("*") if p.is_file() and not str(p).startswith(str(TARGET)) and p.stat().st_size > 8 * 1024 * 1024]
    if big:
        raise Stop(f"unexpected large files (possible key material) outside the build target: {big}")
    claim = json.loads((d / "claim.json").read_text())
    adm = json.loads((d / "admission.json").read_text())
    res = json.loads((d / "results.json").read_text())
    vk, st = (d / "vk.bin").read_bytes(), (d / "statement.bin").read_bytes()
    dig = _blake2b(st)
    o = claim["envelope"]["settleOutref"]
    indep = {
        "vkDigest_eq_admission": _blake2b(vk).hex() == adm["vkDigest"],
        "vkDigest_eq_envelope": _blake2b(vk).hex() == claim["envelope"]["vkDigest"],
        "statementDigest_eq_claim": dig.hex() == claim["statementDigest"],
        "statement_eq_claim_hex": st.hex() == claim["statementHex"],
        "publicInputs_eq_digest_halves": claim["publicInputsDecimal"] == [str(int.from_bytes(dig[:16], "big")), str(int.from_bytes(dig[16:], "big"))],
        "proof_eq_claim_hex": (d / "proof.bin").read_bytes().hex() == claim["proofHex"],
        "settleOutref_is_DECLARED": f"{o['txid']}#{o['index']}" == DECLARED["DECLARED_OUTREF"],
        "refundVkh_is_DECLARED": claim["envelope"]["refundVkh"] == DECLARED["DECLARED_REFUND_VKH"],
        "expiry_is_DECLARED": str(claim["envelope"]["expiry"]) == DECLARED["DECLARED_EXPIRY_MS"],
        "vkIcCountAt336_is_3": vk[336:344] == (3).to_bytes(8, "little"),
    }
    write_json(RECEIPTS / f"{row}-independent-output-checks.json", {"row": row, "checks": indep,
               "method": "Python hashlib BLAKE2b-256 and integer conversion over x7's public outputs; independent of x7 code",
               "gating": "recorded findings only; the approved S10/S11 gates are exit 0, output set, vk 488 / proof 192, no key on disk"})
    return {"x7Sha256": xd, "independentChecks": indep, "files": sizes, "resultCount": len(res["results"]), "allAsExpected": res["allAsExpected"],
            "vkDigest": adm["vkDigest"], "r1csDigest": adm["r1csDigest"], "r1csConstraints": adm["r1csConstraints"],
            "assetName": claim["assetNameHex"], "statementLen": len(st), "payloadHex": claim["envelope"]["payload"],
            "timing": next((x["observed"] for x in res["results"] if x["id"] == "E-X7-7.positive"), None)}


def s12(ctx):
    require_freeze()
    script = SRC / "scripts" / "gen_x7_aiken.py"
    for row in ("L1", "M1"):
        f = OUT / row / "claim.json"
        if sha(f) != read_receipt_digest(RECEIPTS / f"out-{row}-sha256.txt", str(f)):
            raise Stop(f"{f} differs from its receipt")
    if AIKEN_TARGET_NEVER.exists():
        raise Stop(f"{AIKEN_TARGET_NEVER} exists; original Aiken source must not be mutated")
    mkdir_new(GENERATED.parent)
    py = require_tool_hashes()["python3"]
    r = run_child("S12-gen-aiken-vectors", [py, "-I", str(script), str(OUT), str(GENERATED)], cwd=EMPTY_CWD, env=child_env(),
                  deadline=time.monotonic() + WALL["S12"])
    if GENERATED.is_file():
        write_new(RECEIPTS / "generated-aiken-sha256.txt", sumline(sha(script), str(script)) + sumline(sha(GENERATED), str(GENERATED)))
    ok_or_stop(r, "gen_x7_aiken")
    if AIKEN_TARGET_NEVER.exists():
        raise Stop("generator wrote into the original Aiken tree")
    text = GENERATED.read_text()
    return {"generatedSha256": sha(GENERATED), "tests": re.findall(r"^test (\w+)\(", text, re.M),
            "note": "not copied into any Aiken source; S13 is out of scope for this job"}


def s14(ctx):
    rows, bad, h = verify_freeze()
    files, links = walk_files(SRC)
    rel = [str(f.relative_to(TASK)) for f in files]
    after = "".join(sumline(sha(f), r) for f, r in zip(files, rel))
    write_new(RECEIPTS / "source-sha256.after.txt", after)
    before = {l.split("  ", 1)[1]: l.split("  ", 1)[0] for l in (RECEIPTS / "source-sha256.before.txt").read_text().splitlines()}
    aft = {l.split("  ", 1)[1]: l.split("  ", 1)[0] for l in after.splitlines()}
    added = sorted(set(aft) - set(before))
    removed = sorted(set(before) - set(aft))
    changed = sorted(k for k in set(before) & set(aft) if before[k] != aft[k])
    lock_ok = aft.get("source/x7/Cargo.lock") == read_receipt_digest(RECEIPTS / "cargo-lock-sha256.txt", str(LOCK_SRC)) if (RECEIPTS / "cargo-lock-sha256.txt").exists() else None
    diff = {"added": added, "removed": removed, "changed": changed, "symlinks": links, "lockMatchesFrozen": lock_ok}
    write_json(RECEIPTS / "source-diff.json", diff)
    outs = sorted(p for p in OUT.rglob("*") if p.is_file()) if OUT.exists() else []
    write_new(RECEIPTS / "out-sha256.txt", "".join(sumline(sha(p), str(p.relative_to(EXEC))) for p in outs))
    cores = [str(p) for p in EXEC.rglob("core*") if p.is_file() and not str(p).startswith(str(TARGET))
             and re.fullmatch(r"core(\.\d+)?", p.name)]
    big = [str(p) for p in EXEC.rglob("*") if p.is_file() and not str(p).startswith(str(TARGET)) and p.stat().st_size > 8 * 1024 * 1024]
    allowed_added = [] if not LOCK_DST.exists() else ["source/x7/Cargo.lock"]
    status_ok = not bad and not removed and not changed and not links and added == allowed_added and (lock_ok in (True, None))
    write_json(RECEIPTS / "final-verify.json", {"freezeMismatches": bad, "sourceFreezeSha256": h, "sourceDiff": diff,
               "coreFiles": cores, "largeFilesOutsideTarget": big, "aikenSourceUntouched": not AIKEN_TARGET_NEVER.exists(),
               "outFiles": len(outs)})
    if not status_ok or cores or big or AIKEN_TARGET_NEVER.exists():
        raise Stop(f"final verification failed: freeze {bad}, diff {diff}, cores {cores}, big {big}")
    return {"freezeAllOk": True, "sourceAdded": added, "outFiles": len(outs)}


STEP_FN = {
    "S-meta": s_meta, "S0-manifest-before": s0, "S0b-freeze-check": s0b, "S1-frozen-inputs": s1, "NS-probe": ns_probe,
    "S2-lockfile": s2, "S3-toolchain": s3, "S4-cargo-build": s4, "S5-cargo-test": s5, "S6-x7-abi": s6,
    "S7-abi-ref-compare": s7,
    "S10-x7-run-L1": lambda c: s_run(c, "L1", "S10-x7-run-L1", []),
    "S11-x7-run-M1": lambda c: s_run(c, "M1", "S11-x7-run-M1", ["L1"]),
    "S12-gen-aiken-vectors": s12, "S14-verify": s14,
}


def status(sid):
    p = STEPS / f"{sid}.json"
    return json.loads(p.read_text())["status"] if p.exists() else None


def run_step(sid):
    rec_p = STEPS / f"{sid}.json"
    if rec_p.exists():
        raise SystemExit(f"{sid} already has a record ({status(sid)}); steps are never rerun")
    started = utc()
    journal({"event": "step-start", "step": sid, "controlSha256": sha(CONTROL)})
    print(f"\n##### {sid} start {started}", flush=True)
    try:
        detail = STEP_FN[sid]({})
        st, err = "GREEN", None
    except Stop as e:
        st, err, detail = e.status, str(e), None
    except Exception as e:
        st, err, detail = "CONTROL-ERROR", f"{type(e).__name__}: {e}\n{traceback.format_exc()}", None
    rec = {"step": sid, "attempt": ATTEMPT, "status": st, "startedAt": started, "endedAt": utc(), "detail": detail, "error": err}
    write_json(rec_p, rec)
    journal({"event": "step-end", "step": sid, "status": st})
    print(f"##### {sid} {st}" + (f" :: {err}" if err else ""), flush=True)
    if detail:
        print(json.dumps(detail, indent=1)[:4000], flush=True)
    return st


def main():
    if len(sys.argv) != 3 or sys.argv[1] != "--phase" or sys.argv[2] not in PHASES:
        raise SystemExit(__doc__)
    if Path(__file__).resolve() != CONTROL:
        raise SystemExit(f"control script must run from {CONTROL}")
    phase = sys.argv[2]
    for d in (LOGS, RECEIPTS, STEPS):
        d.mkdir(parents=True, exist_ok=True)
    journal({"event": "phase-start", "phase": phase, "controlSha256": sha(CONTROL), "pid": os.getpid()})
    if phase != "final":
        prior = ORDER[:ORDER.index(PHASES[phase][0])]
        not_green = [(s, status(s)) for s in prior if status(s) != "GREEN"]
        if not_green:
            journal({"event": "phase-refused", "phase": phase, "notGreen": not_green})
            raise SystemExit(f"phase {phase} refused: earlier steps not GREEN: {not_green}")
    for sid in PHASES[phase]:
        st = run_step(sid)
        if st != "GREEN":
            stop = {"attempt": ATTEMPT, "firstNonGreen": sid, "status": st, "at": utc(),
                    "notRun": [s for s in ORDER if status(s) is None]}
            if not (RECEIPTS / "STOP.json").exists():
                write_json(RECEIPTS / "STOP.json", stop)
            journal({"event": "phase-stopped", "phase": phase, "step": sid, "status": st})
            print(f"\nSTOPPED at {sid} ({st})", flush=True)
            sys.exit(2)
    journal({"event": "phase-end", "phase": phase})
    print(f"\nphase {phase} complete", flush=True)


if __name__ == "__main__":
    main()
