I've written the full source candidate for review into `implementation-attempt-2/`. Nothing was compiled, tested, proved or hashed, because my tools don't allow it. Every Write succeeded. ABI v0 stays **PROPOSED**: D1–D12 have one vote, and the ten new details I had to fix (N1–N10, listed in `ABI-v0.md` §9) need a fresh second vote.

## What code exists

| Part | Contents |
|---|---|
| **C0** (`source/aiken/lib/pvc/c0.ak`, `validators/c0.ak`) | `Issue{vk, proof}` mints exactly one token named after the envelope, held in one output at C0. Before the pairing check it checks the envelope, the VK digest and the C0 address. The pairing check runs last on the 488-byte arkworks VK from the redeemer, with both public scalars derived from the statement. `Burn` allows only negative quantities. Release requires the token to be burned and either the `settle_outref` input spent, or a refund after expiry signed by `refund_vkh`. |
| **S_settle0** (`lib/pvc/settle.ak`, `validators/settle0.ak`) | One-shot genesis; a thread datum with 1–2 slots pinned by (predicate digest, VK digest). Settlement requires exactly one thread input, the same address and value on the continuation, and claims only from spent inputs (reference inputs are never read). Each claim must name this thread input and match the slots one to one. The transition must match: pre against the current state, post against the continuation, and the continuation must record the effects hash. |
| **ABI library** (`lib/pvc/abi.ak`) | Flat statement, envelope well-formedness, asset-name rule, Groth16 verifier, slot rules |
| **Aiken tests** | 22 ABI tests, including a parser regression against the frozen X2 VK and proof, and 30 synthetic-context tests for settle, genesis, release and pre-pairing Issue refusals |
| **Rust X7** (`source/x7/src/{main,abi,relations}.rs`) | Relations P-L1 (context-free Preprod-output predicate) and P-M1 (`pay` with the thread outref and the full pre/post/effects in the statement). Reuses the frozen audited gadgets unmodified. Commands `abi`, `run`, `setup`, `prove`; R1CS digest; admission record; envelope and redeemer CBOR; 9 unit tests. |
| **Catalogue** | `P-L1.v0.json`, `P-M1.v0.json` |
| **Scripts** | `abi_ref.py`, an independent standard-library-only reference encoder and comparator; `gen_x7_aiken.py`, which generates Aiken tests from fresh proofs |

The documents are `ABI-v0.md`, `EXPECTED-OUTCOMES.md`, `EXECUTION-REQUEST.json`, `SOURCE-SELECTION.md` and `REPORT.md`. There are no dummy checks or always-true verifiers anywhere, and nothing in the claimed parts is left as a TODO.

## How the audit findings are handled

- **F1 and F2:** no user label selects any check. The only trust root is each thread's pinned (predicate digest, VK digest) pair. The admission record ties together the predicate digest, an R1CS digest and the VK digest. X7 has no unbound control row.
- **Dissent on the in-circuit relation digest:** hashing the whole R1CS into itself is a fixed point, and hashing a skeleton without constants doesn't bind them. I kept the relation digest out of the circuit.
- **F5:** P-M1 has no coin adapter, so the amount-zero vector, labelled as a derived negative, should isolate `requires amount > 0`. Predicted first failure: constraint #658.
- **F3:** the execution request hashes source and inputs before the build and the binary before any run, uses pipefail, never masks exits, and keeps every failure.

## The upstream reference (`proof-zk-recovery` @ `7f54c35f`, Apache-2.0)

I read only the selected files and ran nothing.
- **Patterns reused (no code copied):** the validator rebuilds the public input itself; script UTxOs without an inline datum fail closed; exactly one own-script input per transaction; consume-and-burn spent state; payouts tied to a committed encoding.
- **Not reusable:** their verifier is gnark's commitment variant of Groth16, with a 672-byte VK, a 336-byte proof, an extra proof-of-knowledge pairing and a single scalar reduced mod r. Our proofs are arkworks vanilla Groth16 with two 128-bit halves.
- **Their Preview deployment and cost figures are their own records, not checked by me.** Their document says the setup was single-operator, so none of it qualifies anything on Preprod.

## Scope and what blocks progress

- **Not settlement:** the thread's ledger value never changes. This certifies a data transition only; it is not Moriarty financial settlement.
- **Real settlement still needs:** a map from Moriarty assets to Cardano assets, custody of balances, ledger movements that match the effects, and authority. REPORT §6 has the detail.
- **First blocker:** nothing has been compiled. Steps S4 (`cargo build --offline --locked`) and S8 (`aiken check`) are the first real tests.
  - S8 needs your approval for one GitHub fetch of Aiken stdlib v2.2.0.
  - The Aiken code is the least certain part, since I wrote it against compiler v1.1.21 without running it. EXPECTED-OUTCOMES §1 lists the syntax most likely to need a fix.
- **After that:** Preprod transactions need a separately authorized transaction builder and wallet.
- **Decision for you:** a context-bound P-M1 claim can only be proved after genesis, but the thread must pin the VK digest before genesis. Using it for real therefore requires either keeping the proving key between setup and prove (`x7 setup`/`prove`) or another approach. Keeping it is private key material, so I didn't request it.

All digests are pending from you. I didn't verify the Moriarty baseline commit.