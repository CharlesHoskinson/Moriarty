# Source selection and manifest (hashes pending from the root)

I had no hashing or shell tool, so **no digest in this candidate was computed by me**. The root computes the ordinary file-hash manifest after freezing (EXECUTION-REQUEST S0 and S1).

## A. Authored in this attempt (the candidate)

All paths are relative to `implementation-attempt-2/`.

| Path | Role |
|---|---|
| `WORK-STARTED.md` | Scope and status declaration |
| `ABI-v0.md` | Explicit ABI: statement, envelope, C0, S_settle0, encodings, fixtures, new details N1–N10 |
| `EXPECTED-OUTCOMES.md` | Spec-only expectations and predicted constraint indices |
| `EXECUTION-REQUEST.json` | Exact commands, caps and receipts |
| `SOURCE-SELECTION.md` | This file |
| `REPORT.md` | Public report |
| `source/aiken/aiken.toml` | Aiken package; compiler v1.1.21, stdlib v2.2.0 |
| `source/aiken/lib/pvc/abi.ak` | Types, statement, `well_formed`, `envelope_name`, `scalars`, `groth16_verify`, slot rules |
| `source/aiken/lib/pvc/c0.ak` | `issue`, `burn_only`, `refund_ok`, `release` |
| `source/aiken/lib/pvc/settle.ak` | `genesis`, `claim_envelopes`, `settle` |
| `source/aiken/validators/c0.ak` | C0 validator wrapper |
| `source/aiken/validators/settle0.ak` | S_settle0 validator wrapper |
| `source/aiken/lib/pvc/abi_test.ak` | ABI fixtures and the X2 parser regression |
| `source/aiken/lib/pvc/context_test.ak` | UNIT-context tests |
| `source/x7/Cargo.toml` | Crate. Same name, version and dependency pins as frozen `g16/Cargo.toml`. Binary `x7`. |
| `source/x7/src/main.rs` | CLI: `abi`, `run`, `setup`, `prove`; R1CS digest; admission record; oracle cross-check |
| `source/x7/src/abi.rs` | Native encoders, `pay` model, unit tests |
| `source/x7/src/relations.rs` | P-L1 and P-M1 circuits |
| `source/catalogue/P-L1.v0.json` | Catalogue entry. Its BLAKE2b-256 is the P-L1 predicate digest. |
| `source/catalogue/P-M1.v0.json` | Catalogue entry. Its BLAKE2b-256 is the P-M1 predicate digest. |
| `source/scripts/abi_ref.py` | Independent stdlib-only reference encoder and comparator |
| `source/scripts/gen_x7_aiken.py` | Generator of Aiken vector tests from `x7 run` outputs |

**Generated later (not authored):**
- `source/x7/Cargo.lock`: a byte copy of the frozen lock (S2)
- `source/aiken/aiken.lock` and `build/` (S8)
- `plutus.json` (S9)
- `source/aiken/lib/pvc/x7_vectors_test.ak` (S12)

## B. Frozen inputs (read-only; x7 uses them at build or run time)

All paths are under `/home/charl/moriarty-eutxo-validation-2026-10-12/groth16-preprod-experiments-20261015/`.

| Path | Use |
|---|---|
| `g16/src/gadgets.rs` | Compiled into x7 by `#[path]`, unmodified (BLAKE2b-256 and bit gadgets; prior audit §3.1) |
| `g16/src/circuit.rs` | Compiled into x7 by `#[path]`, unmodified. Only `Template`, `Segment`, `public_inputs` and `fr_to_dec` are used; the P-L0/P-M0 `Circuit` is dead code here. |
| `g16/Cargo.lock` | Copied verbatim (S2) |
| `data/selected/template.json` | P-L1 template; its BLAKE2b-256 is the template digest |
| `data/selected/selected-body.bin` | P-L1 witness body (Preprod tx `9e6dfe33…`, E0 provenance) |
| `data/selected/selection.json` | Provider txid for the E0 equality line |
| `data/moriarty/payment.mori` | Program SHA-256 (P-M1 constant). The catalogue entry records `f1f4807b…e786` from the prior P-M0 entry; x7 recomputes it. |
| `out/x0/moriref.json` | Core oracle output (`mori_core::simulate`) for the E-X7-1 cross-check and the R1–R5 codes |

## C. Read for design only (not compiled; no execution)

- **Prior experiment:**
  - `g16/src/{main.rs, circuit.rs, gadgets.rs}`
  - `aiken/lib/mrg16.ak` (X2 constants reused as test vectors in `abi_test.ak`)
  - `aiken/aiken.toml`
  - `catalogue/P-M0.v0.json`
- **Moriarty worktree** (source-only runtime-read closure): `crates/mori-core/src/ir.rs` (lines 180–279) and `runtime.rs` (lines 420–459, plus effect pushes around 744–860). I read these for effect order and liability reads. They are not adopted, and nothing was changed.
- **proof-zk-recovery** at commit `7f54c35fce466039bc0c2adfe9c86693ef7bc4ac` (Apache-2.0), selected sources only:
  - `proto/onchain/redemption/src/Recovery/{Verify,Logic,Types,Entitlement}.hs`
  - `proto/onchain/redemption/src/RedemptionValidator.hs`
  - `proto/onchain/commitment-verifier/src/CommitmentVerifier.hs`
  - `docs/commitment-groth16-protocol.md`
  - `proto/onchain/redemption/{CANONICAL-MPC-CLAIM,SP2-PREVIEW}.md`

  No upstream code was copied. The patterns reused are listed in ABI-v0 §10, and the Aiken header comment cites the source.
- **Predecessor:** `VOTE.md` (as quoted in the task prompt). The root's review of independent audit attempt 2 was also quoted in the prompt.

## D. Not read

- private provider results, stderr, `.foreman`, `target/`, keys, witnesses, SRS, PK, caches;
- gitdirs outside the allowed roots;
- unselected upstream material.

## E. Baseline statement

The root reports these, and I could not verify them: Moriarty feature commit `af8cc9fb55f1befed20050c09f57d7a1adffb766`, tree `eb295f2d143d6f2074b2a2c076816f458d6d948d`, with Core behaviour unchanged from `91fd`. The worktree I read is the older source-only closure the root named. I ran no startup CLI or git status, because my tools exclude shell access.
