# Independent security source audit: X7 / C0 / S_settle0 claim-UTxO prototype (implementation attempt 2)

**Status: `CHANGES_REQUIRED`.** The verdict is split by layer in §1.

---

## 0. Reviewer identity, method and limits

| Item | Value |
|---|---|
| Requested reviewer | `claude-opus-5-5` at high effort |
| Actual reviewer | Claude Opus 5.5, model ID `claude-opus-5-5`, as stated by my runtime environment. I cannot observe the effort setting; "high" is only the requested value. |
| Independence | I did not write this source, the ABI, VOTE.md or review B. All security judgments here are mine. I consulted no other model, agent or reviewer. The author is the same model family, so my independence is at the level of context, not model. |
| Tools used | None. I made no Read, Bash, Write, build, test, hash, network, SDK, key, proof or ledger action. The report exists only as this text. |
| Evidence base | The exact file texts supplied in the prompt. I take the SHA-256 values in the root manifest as root attestations and did not recompute them. |
| Not supplied, so not reviewed | Aiken stdlib v2.2.0 source. The arkworks crate sources (`ark-groth16`, `ark-relations`, `ark-snark`). The predecessor's `FINAL-RESPONSE.md` (`712bfd…`) and `SOURCE-PIN.json` (`60e1fd…`), which are listed in INPUT-PINS. The current Moriarty main branch and PR54. |
| Basis for library behaviour | My statements about arkworks 0.4 behaviour (setup and prove synthesis mode, `which_is_unsatisfied` returning an index without `std`, `debug_assert` in the prover) and about stdlib v2 APIs come from memory. They are marked **[UNVERIFIED-LIB]**. |
| Labels | **[SRC]** fact from the supplied source. **[INF]** inference. **[PROP]** proposal. **[UNVERIFIED-LIB]** library behaviour recalled, not inspected. |

**Scope of this review:**

- This is project-internal review that gates maintainer-operated execution only. It creates no public compile, prove or deploy permission, and no Moriarty program needs it.
- Current Midnight, SDK, native and old-campaign authority stays at zero.
- No wallet, Preprod action or use of any existing key is authorized here.
- The candidate is a **hand-lowered `moriarty/1` `pay` data transition only**. The root says the author's "unmerged full language" wording (REPORT §8) is stale after PR54. I did not inspect PR54 or `/2`, and nothing here is a `/2` result.
- The 20 retained patterns, recursion, private PCD, private handoff, liability execution and physical asset integration all remain open required tracks. This candidate closes none of them.

---

## 1. Verdicts, kept separate

| Layer | Verdict |
|---|---|
| **Overall** | **`CHANGES_REQUIRED`** |
| Source: Rust x7 subtree (`abi.rs`, `relations.rs`, `main.rs`, `Cargo.toml`), catalogue rows, `abi_ref.py`, `gen_x7_aiken.py` | No blocking defect found by inspection. Adoptable as-is for the bounded local run (§13). Non-blocking items: F-E, F-F, F-G, F-P. |
| Source: Aiken subtree | **CHANGES_REQUIRED.** One small, robust compile fix should go in before S8 (F-B). One release-rule change is recommended in the same revision, and is required before any Preprod issuance (F-A). |
| ABI votes D1–D12, N1–N10 | §12. I agree with most items. I amend D3, dissent on value-direction for D9/N1, and add conditions on D7 and D12. |
| Execution and resources | **Approved with amendments:** S0–S7 and S10–S11 on the current revision, plus S12 redirected to `out/`. **Blocked:** S8, S9 and S13, until a Scrapling-acquired stdlib route under a no-network sandbox exists and the Aiken revision is in place (§13). |
| Live or ledger acceptance | **None.** No Preprod, ledger, financial-settlement, ceremony or cryptographic approval. No approval is derived from the 9 Rust and 52 Aiken predicted-but-unrun tests. |

---

## 2. Reviewed closure

**Candidate files, read in full:**

- `catalogue/P-M1.v0.json`, `catalogue/P-L1.v0.json`
- `scripts/gen_x7_aiken.py`, `scripts/abi_ref.py`
- `aiken/aiken.toml`
- `x7/Cargo.toml`, `x7/src/{abi.rs, relations.rs, main.rs}`
- `aiken/validators/{settle0.ak, c0.ak}`
- `aiken/lib/pvc/{abi.ak, settle.ak, c0.ak, context_test.ak, abi_test.ak}`
- `WORK-STARTED.md`, `ABI-v0.md`, `EXPECTED-OUTCOMES.md`, `EXECUTION-REQUEST.json`, `SOURCE-SELECTION.md`, `REPORT.md`, `FINAL-RESPONSE.md`, `INPUT-PINS.json`, `PROCESS.json`

**Compiled gadget closure, read in full:**

- Frozen `g16/src/gadgets.rs` (BLAKE2b-256, XOR, modular add, bit packing). Compiled into x7 by `#[path]`. I checked that the relative path resolves from `source/x7/src/` to `…/groth16-preprod-experiments-20261015/g16/src/gadgets.rs`. It does.
- Frozen `g16/src/circuit.rs`. Only `Template`, `Segment`, `public_inputs` and `fr_to_dec` are used. Its P-L0/P-M0 `Circuit` is compiled but never instantiated.
- `g16/Cargo.lock` and `g16/Cargo.toml`. The x7 manifest has the same package name, version and dependency set, so `--locked` is consistent **[INF]**.

**Frozen inputs, read:** `template.json`, the `selected-body.bin` rendering, `selection.json`, `payment.mori`, `moriref.json`, `mrg16.ak`, the prior `aiken.toml`, and `P-M0.v0.json`.

**Context, read:** VOTE.md, review B, the prior independent X0–X6 review, Moriarty `AGENTS.md`, the product contract, `ir.rs`, `runtime.rs`, and the proof-zk-recovery selection (`Verify.hs`, `Logic.hs`, `Types.hs`, `Entitlement.hs`, `RedemptionValidator.hs`, `CommitmentVerifier.hs`, the protocol doc, `CANONICAL-MPC-CLAIM.md`, `SP2-PREVIEW.md`, `LICENSE`).

---

## 3. Binding analysis: proof, statement, envelope, VK, schema, serialization

### 3.1 Statement `MRG16-PVC-STMT-0` [SRC + INF]

**Layout.** The Rust `abi::statement`, the Aiken `abi.statement` and Python `abi_ref.statement` all emit the same layout:

> tag ‖ family ‖ predicate ‖ vk ‖ kind ‖ setup ‖ (00 | 01 ‖ txid ‖ u16 index) ‖ (00 | 01 ‖ lp(pre) ‖ lp(post) ‖ lp(effects)) ‖ lp(payload)

**Independent recomputation of offsets:**

| Statement | Total bytes | Offsets |
|---|---|---|
| F0 | 120 | vk 80, payload 118 |
| F1 | 161 | outref 115, pre 152, post 155, effects 158, payload 161 |
| P-L1 | 236 | payload length 118 |
| P-M1 | 733 | 150 + (2+171) + (2+171) + (2+184) + (2+49) |

All match the author.

**Injectivity.** The layout is injective, but only for envelopes that pass `well_formed`. The Aiken `statement` itself assumes fixed-width fields (family, predicate and vk at 32 bytes each). The only on-chain caller, C0 `issue`, runs `well_formed` first inside a short-circuiting `and`. That is sufficient. **Rule:** any future caller must keep this order.

**Agreement between implementations.** The Rust encoder ignores the flags in `env` for structure; the row fixes them. Aiken reads them from the datum, and `well_formed` restricts them to `claim_kind = 0`, `setup_class = 0` and transition ⇒ context. The circuit fixes kind, setup, context tag and transition tag as constants. So a proof verifies only under its row's mode.

### 3.2 Public inputs and canonical scalars [SRC]

- **Circuit:** `x_hi = be_lc(digest[0..16])` and `x_lo = be_lc(digest[16..32])`. These are the last two constraints. The digest bytes are booleanity-constrained, so each value is below 2¹²⁸.
- **Aiken:** `scalars` uses `bytearray_to_integer(True, …)` on the same halves.
- **Rust:** `public_inputs` uses `fr_from_be` on the same halves.
- Both values are below 2¹²⁸ < r, so there is no mod-r alias.
- No verifier path accepts supplied scalars: C0, x7 `verify` and the generated tests all derive them. This closes the X5 raw-scalar hazard for this ABI.

### 3.3 VK and proof bytes; malformed points [SRC]

**VK.** Length 488, IC count `03 00…00` at offset 336, offsets α 0, β 48, γ 144, δ 240, ic0 344, ic1 392, ic2 440. That is arkworks 0.4 compressed, as decoded in the prior audit. The prior review's byte decoding of the X2 VK supports the count-at-336 assumption. The `x2_regression_verifies` test checks the parser only against a reconstructed buffer; the real check is S13 on fresh `vk.bin`.

**Proof.** 192 bytes, A 0, B 48, C 144.

**Point validation.** Every point passes through CIP-0381 `uncompress`, which rejects off-curve, non-subgroup and non-canonical encodings.

**Identity points are not rejected** (F-I). For the proof points this does not weaken Groth16 soundness. For the VK it matters only to a consumer who pins a degenerate VK: with γ = O the public inputs drop out entirely.

**Correction to the author.** REPORT §8 says "the upstream code rejects identity points explicitly". The supplied `Verify.hs` does not do that. Only the protocol document (§6 rule 4, REQ-B-02) requires it.

### 3.4 No proof-shape interchange with gnark BSB22 [SRC + INF]

- Family `…-ARK04-HL2`, VK 488 and proof 192 cannot carry the commitment D, the PoK π, K2 semantics or the e_cmt derivation.
- A BSB22 VK also has three IC points (K0, K1, K2). Re-encoded into the 488-byte layout, it would be "verified" with x₂ standing in for e_cmt and with D omitted. That is a different, unsound relation.
- The bytes are therefore not interchangeable, and the verifier cannot tell such a VK apart by shape.

**Required rule [PROP, documentation]:** no consumer may pin, under FAM0, a VK derived from a gnark commitment circuit. Admission records must say "vanilla Groth16; no commitment extensions".

### 3.5 Envelope Plutus Data CBOR and the asset name [SRC]

- **Field order.** EnvV0 has 12 fields in the same order in Rust `pd_env`, Python `penv` and the Aiken type. Bool is `Constr 0/1 []`. Option is `Some = Constr 0 [x]` and `None = Constr 1 []`. OutputReference is `Constr 0 [Bytes, Int]`, the V3 shape.
- **Hand-checked fixtures.** I checked the F0 and F1 hand-written CBOR in `abi_test.ak` and in the Rust unit test byte by byte against Plutus `serialiseData` rules. They are consistent.
- **Chunking.** Byte strings over 64 bytes are encoded as `5f` + 64-byte chunks + `ff`. Rust and Python implement this identically.

**Oracle gap (F-N).** F0 and F1 contain no byte string over 64 bytes. Before S13, chunking is checked only by the two same-author encoders. The first non-author check is `{l1,m1}_asset_name_matches_x7` in S13 (P-L1's payload is 118 bytes; P-M1's fields are 171/171/184/49).

**Asset name.** The asset name is `blake2b_256(serialise_data(raw datum))`. C0 `issue`, C0 `release` and S_settle0 `claim_envelopes` all compute it from the ledger-supplied Data value, so non-canonical inline-datum CBOR cannot split identities on-chain. Off-chain builders must use the canonical form (A2, agreed).

---

## 4. Circuit review: P-L1 and P-M1 (`relations.rs`)

### 4.1 Template and overlay [SRC]

- `template_env` zeroes every witness position:
  - vk_digest and outref;
  - for P-M1, all u128 slots, the accepted flag and the amount;
  - for P-L1, the txid, header, credential and threshold.
- Every other statement byte is a circuit constant: tag, family, predicate digest, kind, setup, both tags, every length prefix, every MSB0/MEB0 structural byte (including the Fee amount 2), the program SHA-256, and the template digest, label and output index.
- `put` asserts that overlay regions are disjoint.
- The template does not depend on the witness. So the R1CS depends only on (row, predicate_digest, frozen constants).
- That justifies the trick in `cmd_run`: run setup with vk_digest = 0, then put in the real digest. E-X7-4 tests exactly the two fields that change, vk_digest and outref.

### 4.2 P-M1 arithmetic against `runtime.rs` [SRC]

- `requires accepted`: booleanity, then `accepted = 1`.
- `requires amount > 0`: the inverse gadget over a 128-bit-decomposed amount.
- Every pre value is range-checked to 128 bits.
- Checked subtraction and addition by 128-bit re-decomposition, in Core statement order:
  - transfer debit, then transfer credit (the `move_funds` order);
  - fee debit, then fee credit;
  - next paid.
- Accounts are distinct literals, so the `f == t` branch of `move_funds` is unreachable.
- Effects order (Transfer, Fee, State(paid0→paid1), Emit(paid1)) matches `simulate`. Emit is evaluated after `Next` updates the environment.
- Field-wrap argument: every sum is below 2¹²⁹ < r, and an underflow yields a value at least r − 2¹²⁸. I agree with this, as an argument and not a proof.

### 4.3 Independent constraint layout (derived, not executed)

| Item | My derivation | Author |
|---|---|---|
| M1 regions | vk 0–255, outref 256–527, accepted 528/**529**, amount 530–657, amount>0 **658**, pre 659–1170, payer1 pack 1299, recip1 **1428**, payer2 **1557**, spons1 1686, paid1 **1815** | matches |
| M1 statement hash | 6 blocks: 50,304 + 5×51,072. Message constness does not affect the count; only chaining-value constness does. | matches |
| M1 total, binding-hi index | 307,482; **307,480** | matches |
| L1 total and indices | 361,339; header **4,920**; threshold **259,960**; binding-hi **361,337** | matches |

**Labelling defect (F-P).** "E-X7-6.L1-header-byte" flips `body[1]`, a const map-key byte. It does not flip the address header at offset 314. The index prediction is still right; the name is wrong.

### 4.4 What the circuit does not do (scope, agreed)

- No authority or signed intent: `accepted` is a prover witness, and anyone with the PK can prove any `pay` from the current thread state.
- No ledger asset identity.
- Incomplete MSB0 (F-L):
  - external, undeclared Core liabilities and extra balance rows are valid Core inputs but cannot be represented;
  - these states are refused, which is incomplete but sound for the encoded subset.

---

## 5. C0 review (`lib/pvc/c0.ak`, `validators/c0.ak`)

**Issue [SRC].** The checks:

- exactly one mint entry for the policy, with quantity 1;
- exactly one output holding the policy, at `Script(policy)`, with an inline datum that decodes as EnvV0;
- that output holds exactly one token of the policy, named `H(raw)`;
- `well_formed`;
- `vk_digest = H(vk)`;
- the pairing check, last.

Issue cannot share a transaction with Release (N9) or with a second issue. Proof re-randomization does not matter, because the name excludes the proof.

**Burn.** Burn allows only negative quantities. Tokens exist only at C0 and leave only through Release, so a burn always comes with a Release.

**Release.** Requires its own token `H(raw)` and no other token of the policy; forbids any output carrying the policy (value conservation then forces the burn); and requires either that `settle_outref` is spent, or a refund (finite lower bound strictly after expiry, plus a `refund_vkh` signature). This is correct as an access rule.

**F-A: claim deposit capture (Medium; design; blocks Preprod).**

- The settlement path of `release` does not limit where the claim UTxO's lovelace goes.
- S_settle0's spend handler needs no authorization, so anyone holding a matching claim can build the settlement.
- Concretely: Alice issues a claim. Mallory submits the settlement that uses Alice's claim, which yields the same proved transition Alice wanted, and routes Alice's min-ADA (or any other value in the claim UTxO) to Mallory.
- The bijection in `match_slots` means Alice's claim is only released in a settlement that actually uses it. That limits what is captured; it does not prevent the capture.

**Smallest fix [PROP]:** require the `refund_vkh` signature on **both** branches.

```aiken
and {
  assets.quantity_of(own.output.value, own_hash, name) == 1,
  dict.size(assets.tokens(own.output.value, own_hash)) == 1,
  !list.any(self.outputs, fn(o) { abi.holds_policy(o, own_hash) }),
  list.has(self.extra_signatories, env.refund_vkh),
  or {
    list.any(self.inputs, fn(i) { i.output_reference == env.settle_outref }),
    after_expiry(env, self),   // refund_ok without its signer clause
  },
}
```

- I prefer this over a "pay back ≥ lovelace" rule, because a single payback output could satisfy several claims at once (double satisfaction).
- It makes the claimant a co-authorizer of any settlement that consumes their claim.
- It changes N1, so it needs a second agreeing vote.
- Tests to update: `release_with_settle_outref_spent_ok` gains a signer, and a new negative `release_settle_path_without_signer_refused` is added.

**Other C0 observations:**

- F-H: expiry does not limit use in settlement. A claim stays usable after expiry and can race a refund. Review B §5.3 had `upper ≤ expiry`; v0 dropped it. Record this, or add a finite-upper-bound check in settle.
- F-J: Release does not check `claim_kind`. VOTE D2 says "at mint and at release". The case cannot occur because kind ≠ 0 tokens cannot be minted. Record the deviation.

---

## 6. S_settle0 review (`lib/pvc/settle.ak`, `validators/settle0.ak`)

**Genesis [SRC].**

- One-shot: the seed is spent, and the name is `H(serialise_data(seed))`.
- Exactly one output holds the token. Value excluding lovelace equals exactly the token. No reference script.
- Datum fields are checked: version 0, `thread_id = name`, a 28-byte `c0_hash` different from the thread policy, well-formed slots, `last_effects = 0³²`, seq 0.
- The initial `state` is a declaration and is not checked (agreed).
- Genesis and settle cannot combine: settle forbids any mint of the policy, and genesis requires exactly one output holding it.

**Settle [SRC].**

| Check | Effect |
|---|---|
| Exactly one input at its own payment credential | Double satisfaction across threads closed. One script means one thread per transaction. |
| Thread token present | Fake threads (UTxOs without the token) are unspendable, though they lock their funds forever. |
| No own mint | Thread cannot be terminated or forked here. |
| Exactly one continuation with the same full address and value, no reference script, immutable fields, `seq + 1` | State machine continuity. |
| Claims only from spent inputs at `Script(c0_hash)`, failing closed on a malformed one | Mirrors upstream `scriptDatums`. Reference inputs are never read, so the protocol-version-11 spend/reference overlap is irrelevant. |
| Bijective `match_slots` | Duplicates cannot fill two slots: the transition-ness of a claim decides which slot it can fill. |
| All claims' `settle_outref = own_ref` | Bookkeeping for context-free claims; binding for context-bound claims. |
| pre/post/effects-hash equalities | D1. |

**Replay.** A context-bound claim is bound to the thread outref through the statement, and that outref is consumed. Replay is closed. Context-free P-L1 claims can be re-wrapped by anyone (their P-L1 non-claim, agreed).

**Residual design facts (agreed, must stay labelled):**

- Consumers must check `c0_hash` against the audited C0 hash off-chain.
- Threads are immortal, and their min-ADA is locked (F-K).
- `last_effects` is not a hash chain, so there is no history commitment (F-Q).
  - **[PROP, v1]:** `last_effects' = H(last_effects ‖ effects)`.

---

## 7. Tests: what they can and cannot establish

**Rust (9 tests).** These are owner-predicted fixtures. Their value is that they assert hand-written bytes the author derived from the spec.

**Aiken `abi_test` (22 tests).**

- E-ABI-3 (F0/F1 against Aiken `serialise_data`) is a **non-author oracle** for CBOR without chunking.
- E-ABI-6 is a parser regression over frozen X2 bytes with an injected count.

**Aiken `context_test` (30 tests).**

- These are synthetic UNIT contexts written by the author.
- I traced every test by hand against the source, and each evaluates as the author expects.
- `fail` tests pass on *any* error, so several are weak:
  - `issue_vk_digest_mismatch_refused` and `issue_junk_vk_fails_at_point_decoding` cannot tell their intended reason from any other failure.
- `settle_referenced_claim_not_counted` does discriminate: the settlement would succeed if reference inputs were counted.

**Coverage gaps.** None blocks a run; all are worth adding:

- a C0 claim with `claim_kind = 1` breaking settle;
- settle when the thread token is missing;
- an own-policy mint during settle;
- a continuation whose stake credential changes;
- genesis with an extra token, a reference script, a wrong `thread_id` or name, quantity 2, or `c0_hash` equal to the policy;
- issue with an extra token in the claim output, or two outputs holding the policy;
- a transition-without-context envelope at issue;
- a P-L1 envelope against a transition slot;
- **a >64-byte envelope CBOR fixture** (F-N);
- a positive end-to-end settle with a real P-M1 claim.

**Distinguishing oracles:**

| Kind | Instances |
|---|---|
| **Non-author oracles** | `mori_core::simulate` frozen output (E-X7-1, R1–R5 codes; values only). RustCrypto `blake2` against the in-circuit gadget (statementEqual, binding). Aiken/Plutus `serialise_data` (E-ABI-3, S13 asset names). CIP-0381 `blst` against the arkworks verifier (S13 `_groth16_positive`, `cross_vk_rejected`). |
| **Owner-predicted only** | Constraint indices, MSB0/MEB0 bytes (definitional, with no external oracle), F0/F1/T0 hex, and all UNIT contexts. `abi_ref.py` is a reimplementation by the same author, so it is not an independent oracle. |

**My independent expectations, recorded before any run (by hand from source; unexecuted):**

| Gate | Expected |
|---|---|
| S5 | 9 passed |
| S6 | 21 result lines, all AS-EXPECTED: E-X7-1 (1); E-X7-2, E-X7-3 and E-X7-4 for each of 2 rows (6); E-X7-5 with 5 refusals and 5 native-model lines (10); E-X7-6 (4). Constraints and indices as in §4.3. Statement lengths 236 and 733. MSB0/MEB0 lengths [171, 171, 184]. |
| S7 | `mismatches []` (same-author agreement only) |
| S10 (L1) | 8 lines: 2 for E-X7-7, 5 mutations, 1 forced. `vk.bin` 488 bytes, `proof.bin` 192 bytes. |
| S11 (M1) | 14 lines: 2, 10 mutations, 2 forced. P-M1 payload is `f1f4807b…e786 ‖ 01 ‖ 00…0f4240`. |
| S8, current revision | 52 tests if F-B is a false alarm; otherwise a compile failure in `context_test.ak:after` |
| S13 | 52 + 13 = 65 tests |

---

## 8. Compile-risk register (unexecuted)

| Risk | Where | Likelihood | Minimal correction |
|---|---|---|---|
| **F-B:** `fn after(t: Int) -> Interval<Int>`. My recollection is that stdlib v2 made `Interval` non-generic (`Interval` over `Int`). If so, this is a type-arity error and fails the whole `aiken check`. **[UNVERIFIED-LIB]** | `lib/pvc/context_test.ak: after` | Medium–high | Delete the return annotation: `fn after(t: Int) { Interval { … } }`. This compiles under either definition. |
| Qualified constructor patterns `c0_logic.Issue { vk, proof }` | `validators/c0.ak` | Low–medium | Unqualified import: `use pvc/c0.{Burn, C0Mint, Issue} as c0_logic` (or equivalent) |
| `expect <Bool>` sugar | `abi.ak`, `settle.ak` | Low | `expect True = <expr>` |
| Record update on a call result (`EnvV0 { ..f0_env(), … }`) | tests | Low | Bind to a `let` first |
| `assets.zero`, `list.count`, `placeholder` names in stdlib v2.2.0 **[UNVERIFIED-LIB]** | tests, `abi.ak` | Low | Per the observed compiler error |
| Rust type inference in `j_snapshot` (`.into()` and `.parse()` inside a collected tuple) | `main.rs` | Low | Turbofish annotations |
| Rust overall | — | Low | — |

**On the Rust side** I checked:

- `#[path]` resolution;
- the trait methods in scope (`SNARK::circuit_specific_setup`, `Field::inverse`, `PrimeField::into_bigint`, `BigInteger::to_bytes_le`);
- the `Lc` operator impls already used by the frozen code;
- `const` thread-local initialization;
- `&&Env` deref coercion;
- the array and slice comparisons in tests.

---

## 9. Findings

| ID | Severity | Finding | Fix or disposition |
|---|---|---|---|
| **F-A** | Medium (design; blocks Preprod) | Settlement-path release lets any settler capture claim deposits | Signer on both branches (§5); needs a vote on the N1 amendment |
| **F-B** | Medium (compile; blocks S8) | Likely invalid `Interval<Int>` | Delete the annotation (§8) |
| **F-C** | Medium (process) | S8 and S13 rely on an unrecorded aiken-CLI GitHub fetch, which violates the user's always-Scrapling rule | Amended route (§13) |
| **F-D** | Low–Medium (private material) | S10 and S11 have no control over core dumps or swap. `prlimit --as` allocation failure aborts the process (SIGABRT), which can dump PK and trapdoor-bearing memory. The WSL default `core_pattern` can pipe crashes outside the task tree. | §13 amendment. Any abnormal-signal exit marks that run's VK compromised. |
| **F-E** | Low (capability) | `x7 run` and `x7 prove` hard-code the pre-state `[0, 10¹⁵, 0, 0]` and amount 10⁶ (`row_of`), so later thread steps cannot be proved. Also, B2 applies to **every** settlement step, not only genesis: each step's outref is new. | Record. **[PROP]** `--pre/--amount`. **[PROP]** an alternative context of (thread policy, thread_id, seq), known before the transaction exists and replay-safe through the seq check. This lets setup → prove → genesis happen in one process for step 0. It needs a vote. |
| **F-F** | Low (identity) | The admission record is self-asserted and unauthenticated. It does not bind the source manifest, lockfile, binary, catalogue or input digests. `r1csDigest` does not link the VK to the R1CS. | §11 |
| **F-G** | Low | The P-L1 catalogue does not record the template digest value (`55186627…0402`). x7 does not assert that SHA-256(`payment.mori`) equals the `program.sha256` in the P-M1 catalogue. | Non-blocking for this run: S1 covers it. Fix in catalogue v1, which changes predicate digests, so not now. |
| **F-H** | Low | Expiry does not limit settlement use | Record, or add a finite upper bound (§5) |
| **F-I** | Low (defence in depth) | No identity-point rejection. REPORT §8's claim about upstream is inaccurate. | **[PROP]** reject O for γ, δ, ic1 and ic2 |
| F-J | Info | Release does not check `claim_kind`, against the D2 text (case cannot occur) | Record |
| F-K | Info | Immortal threads; locked min-ADA | Tracked blocker for financial use |
| F-L | Info | MSB0 cannot represent external liabilities or extra balances | Record (completeness, not soundness) |
| F-M | Info | Test gaps (§7) | Add in the next revision |
| F-N | Info | Chunked CBOR has a non-author oracle only at S13 | **[PROP]** add a >64-byte fixture to `abi_test` |
| F-O | Info | Request hygiene: rustup shims hashed; manifest compare is not mechanical; S6 output not hashed before S7 uses it; stdlib hashed after use | §13 |
| F-P | Info | E-X7-6 "header-byte" mislabelled | Rename in the next revision |
| F-Q | Info | `last_effects` is not a history chain | v1 **[PROP]** |

I found **no soundness defect** in the P-L1 or P-M1 relations, the statement, the scalar derivation, C0 Issue's verification order, or S_settle0's replay and double-satisfaction handling.

---

## 10. Prior X6 findings F1 and F2

**F1 (bundle `entryName` selects checks): resolved in source; pending in tests.**

- No user label selects any check.
- The transition slot pins (predicate_digest, vk_digest).
- The program digest is a circuit constant of the pinned VK.
- No bundle chooses links.

Test evidence so far is synthetic (`slot_matching_on_pinned_pair`, `settle_wrong_vk_digest_refused`) plus an unrun real-proof `cross_vk_rejected`. F1 is **not closed** until S8 and S13 run green on the corrected revision.

**F2 (relation identity; unpinned catalogue): partially resolved.**

Resolved:
- The catalogue is pinned by the hash of its exact bytes in slot and statement.
- Consumers pin the VK digest.
- x7 has no control row.

Residual (inherent to circuit-specific Groth16):
- The mapping vk_digest → relation rests on trust in whoever ran setup.
- The admission record is unauthenticated (F-F).
- The old X3 unbound VK still exists under the old layout; its PK is reported discarded. It must never be pinned.

---

## 11. Identity scheme: adopted and disputed

**Adopted:**

1. **On-chain trust root:** the slot pair (predicate_digest, vk_digest), pinned per consumer.
   - `vk_digest = BLAKE2b-256(488-byte arkworks-compressed VK)` is the **only** binding of proofs to a relation.
   - `predicate_digest` is domain separation, plus a pointer to the semantics in the catalogue.
2. **In-circuit constants:** tag, family, predicate_digest, program and template digests. These are not relation identifiers, because any circuit author can embed them.
3. **Off-chain relation descriptor:** `r1cs_digest` (`MRG16-PVC-R1CS-0` over A, B, C after inlining, under `OptimizationGoal::Constraints`). Anyone can recompute it by re-synthesizing from the frozen source and inputs.
4. **Admission record** [PROP amendment]. Add:
   - sourceManifestDigest (x7 source, gadgets.rs, circuit.rs, Cargo.toml, Cargo.lock);
   - x7 binary SHA-256;
   - rustc version;
   - catalogue file digests;
   - template and program digests;
   - the r1cs-digest definition version;
   - the setup method;
   - `setupTranscript: none`;
   - `vanillaGroth16NoCommitment: true`.

   Mark the record "self-asserted, Class 0". Consumers record its digest off-chain.

**In-circuit relation digest: disputed, and I agree with the author's dissent, for a stronger reason.**

- The author's reason holds: a full-R1CS digest held as a circuit constant is a fixed point, because statement constants change the XOR folding and therefore the matrices.
- The more important reason: even a skeleton digest gives **no assurance against the party who runs setup**. That party chooses the circuit and can embed any constant.
- Against everyone else, the pinned vk_digest already separates relations.
- The real gap is VK provenance. Only a **verifiable setup transcript** closes it: phase-2 contributions checkable against the QAP derived from this R1CS. That is a future track.

---

## 12. Votes

My vote counts as one substantive vote. Together with VOTE.md, every item marked **AGREE** below now has two agreeing votes. N1–N10 previously had none; mine is the first, and each needs one more.

| Item | Vote | Exact disagreement or condition |
|---|---|---|
| D1 | **AGREE** | Effects are bytes only (unit-control data transition). Physical effects require replacing the "value unchanged" rule. |
| D2 | **AGREE** | The implementation refuses kind ≠ 0 at mint and in settle, not at release (F-J). Acceptable. |
| D3 | **AGREE, amended** | Dissent from "identity is predicate_digest alone". Identity is the (predicate_digest, vk_digest) pair, which is what the code implements. |
| D4 | **AGREE** | A context-free claim's `settle_outref` is an unbound label. |
| D5 | **AGREE** | The rule that `statement` runs only after `well_formed` is normative. |
| D6 | **AGREE** | — |
| D7 | **AGREE, conditional** | Class 0 only. No termination is a tracked financial blocker. Consumers must check `c0_hash`. |
| D8 | **AGREE** | — |
| D9 | **AGREE on checks; DISSENT on value direction** | F-A |
| D10 | **AGREE** | Settle's pre-state check against ledger data, plus the outref binding, makes `R_thread` unnecessary. |
| D11 | **AGREE** | — |
| D12 | **AGREE, limited** | Encoding-level only. External Core liabilities cannot be represented (F-L). |
| N1 | **SPLIT** | Agree on the refund branch. Dissent on "settlement release at any time with no signer" (F-A). |
| N2 | **AGREE** | — |
| N3 | **AGREE** | Redundant with Issue's `vk_digest = H(vk)` check, but harmless and useful off-chain. |
| N4 | **AGREE** | — |
| N5 | **AGREE** | — |
| N6 | **AGREE** | — |
| N7 | **AGREE** | With the §11 admission-record amendments and reasoning |
| N8 | **AGREE (weak)** | Harmless, little value |
| N9 | **AGREE** | — |
| N10 | **AGREE** | The R5 vector isolates F5 as predicted. The amount is a disclosed free witness. |

---

## 13. Execution request: review and amendments

**Side effects of the requested commands:**

- Rust and Python steps: no SDK, wallet, Midnight, key or network action (`--offline`). They write to `$TASK`, take CARGO_HOME lock files, and run locked crates' build scripts and proc-macros locally.
- `x7 run` reads `/dev/urandom` and persists no PK.
- `x7 setup` and `x7 prove` are present in the binary and are **not authorized**.
- Aiken S8 and S13 write to the user cache and **fetch from the network outside Scrapling**, which is unauthorized.

**Global amendments, applying to every step:**

1. **Wrapper.**
   ```
   nice -n 10 timeout --kill-after=60 <wall> prlimit --as=34359738368 --core=0 -- bash -o pipefail -c '<cmd> 2>&1 | tee $TASK/logs/<id>.log'; echo $? > $TASK/logs/<id>.exit
   ```
   Export `TASK`, `FROZEN`, `X7`, `DECLARED_*` and `RAYON_NUM_THREADS=8` explicitly.
2. **No-network enforcement.** Run S4–S7 and S10–S12 inside a no-network namespace (for example `unshare --user --map-root-user --net`). If that is unavailable on this WSL kernel, record it.
3. **Subcommand allowlist.** Only `x7 abi` and `x7 run` may be invoked.
4. **S0b, new.** `sha256sum -c <root-frozen-manifest>`. A non-zero exit is a stop. This replaces "the root compares".
5. **S3.**
   - Record `rustup show active-toolchain` and `rustc --print sysroot`.
   - Hash `$(rustup which cargo)`, `$(rustup which rustc)`, the aiken binary and python3.
   - Record `/proc/sys/kernel/core_pattern` and `swapon --show`.
   - Set `RUSTUP_TOOLCHAIN` explicitly so no auto-install can occur.
6. **S6 and S7.** Append the SHA-256 of `out/abi/results.json` (before S7 reads it) and of `abi_ref.json`.
7. **S10 and S11, private material.**
   - If `core_pattern` is a pipe handler (the WSL `wsl-capture-crash` default), RLIMIT_CORE may not suppress it.
   - Any exit by signal (not a normal exit 0/1/101) means: mark that run's VK compromised, never pin it, and report it.
   - Swap residue is a recorded residual for Class 0.
8. **S12.** Write to `$TASK/out/generated/x7_vectors_test.ak` and hash it. Copy it into the **new** Aiken revision only when that revision runs S13.
9. **S8, S9 and S13: replace the fetch with this route:**
   - **S8a** (separately authorized network step, **Scrapling only**):
     - Fetch the GitHub archive of `aiken-lang/stdlib` tag `v2.2.0`.
     - Resolve tag → full commit via the GitHub REST API, also through Scrapling, and respect robots.
     - Store it in a **new empty directory** `$TASK/acquired/stdlib-v2.2.0/`.
     - Receipt: requested and final URL, status, ETag, bytes, SHA-256, UTC time, commit hash.
   - **S8b:** extract with `python3 -I` into another new empty directory. Hash and list every file. Confirm `.ak/.toml/.md` content only. Nothing is executed.
   - **S8c:** place the extracted package where aiken resolves packages offline, and record the exact path.
   - **S8d:** run `aiken check` inside the no-network namespace.
     - If the CLI still attempts a fetch, record S8 as **BLOCKED**, not failed.
     - The fallback, vendoring the stdlib modules into the project as a new source revision, then needs its own audit.
10. **Stop rule unchanged:** stop at the first failure. Preserve all logs, exit files and outputs. A new revision means a new manifest and a new attempt directory.

**Resource judgment.**

- Requested caps are adequate by inspection:
  - L1: 361k constraints, domain 2¹⁹;
  - M1: 307k;
  - estimated PK in memory a few hundred MB;
  - setup and prove well under 7200 s on prior evidence (author records).
- S6 runs 16 syntheses, under 3600 s.

**Authorization recommendation:**

| Steps | Recommendation |
|---|---|
| S0, S0b, S1–S7, S10, S11, S12 (redirected) | May run now on the current revision, with amendments 1–8 |
| S8, S9, S13 | Run only after (a) the Aiken revision with F-B (and preferably F-A and F-N) and its new manifest, and (b) the S8a–S8d route |
| `x7 setup`/`prove`, persistent PK, any Preprod or wallet step, any existing key | Not authorized here. The Preprod PK decision (B2) and physical asset integration (B3) remain **explicit blockers, not waivers**. |

---

## 14. Source-freeze root, as it should be recorded

- **Candidate files:** all 25 listed under `role: candidate`.
- **Compiled gadget closure:** `gadgets.rs` `a7cf1c0a…` and `circuit.rs` `624dadc2…`.
- **Lock:** `Cargo.lock` `f439fa5f…`.
- **Named frozen inputs:**
  - `template.json` `a983ebf4…`
  - `selected-body.bin` `37bbdf92…`
  - `selection.json` `3b83bbb9…`
  - `payment.mori` `f1f4807b…`
  - `moriref.json` `37067d0e…`
- **Selected reference closure:** as manifested.
- **Add at run time:** toolchain binary digests (S3), the x7 binary digest (S4), the stdlib archive and file digests (S8a/S8b), `aiken.lock`, `plutus.json`, and the generated test digest.
- **Gap to close:** the predecessor `FINAL-RESPONSE.md` (`712bfd…`) and `SOURCE-PIN.json` (`60e1fd…`) appear in INPUT-PINS but were not supplied to this review.

---

## 15. What this review does and does not mean

**It provides:**

- an independent source-level judgment that the x7 relations, the statement, the scalar binding, C0 issuance and S_settle0 replay and double-satisfaction handling are sound **by inspection** for the stated v0 scope;
- the votes in §12;
- a bounded local execution recommendation (§13).

**It does not provide:**

- cryptographic approval, compiled or tested status, Preprod or ledger acceptance;
- financial settlement (effects are bytes, and ledger value is unchanged: "datum transition certified", never "payment settled");
- ceremony security; compiler correctness; ZKIRv3 or Midnight correspondence;
- closure of the 20 patterns, recursion, PCD or private handoff;
- any public permission requirement.

**Terminal verdict: `CHANGES_REQUIRED`.**
- Rust subtree: adoptable for bounded local research.
- Aiken subtree: one robust compile fix (F-B), with F-A recommended in the same revision.
- Execution request: amendments in §13 (Scrapling stdlib route, no-network sandbox, crash and core handling).
- Live acceptance: none.