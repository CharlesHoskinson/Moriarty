//! X7 relations over the flat statement MRG16-PVC-STMT-0 (ABI v0, PROPOSED).
//!
//! P-L1: context-free bound-bytes predicate over the frozen Preprod body template
//!       (the P-L0 relation re-expressed in the new statement; no transition).
//! P-M1: IndependentPayment.pay (hand-lowered, one action) with the settle outref in
//!       the statement and the full transition (pre, post, effects) produced in-circuit.
//!
//! Gadgets come from the frozen, audited `gadgets.rs` of the prior experiment (unmodified).
//! Every statement byte is a circuit constant unless a region below overlays it with
//! witness-derived bytes, so the row fixes claim_kind = 0, setup_class = 0, the context
//! tag, the transition tag, every length prefix and every structural snapshot/effects byte.

use crate::abi::{self, Env, Layout, Transition};
use crate::circuit::Template;
use crate::gadgets::*;
use ark_bls12_381::Fr;
use ark_ff::Field;
use ark_relations::lc;
use ark_relations::r1cs::{ConstraintSynthesizer, ConstraintSystemRef, SynthesisError, Variable};
use std::cell::RefCell;

#[derive(Clone, Debug)]
pub struct L1 {
    pub tpl: Template,
    pub template_digest: [u8; 32],
    pub network_label: [u8; 16],
    pub body: Vec<u8>,
    pub threshold: u64,
}

#[derive(Clone, Debug)]
pub struct M1 {
    pub program_sha256: [u8; 32],
    pub accepted: bool,
    pub amount: u128,
    /// [paid, payer, recipient, sponsor]
    pub pre: [u128; 4],
}

#[derive(Clone, Debug)]
pub enum Row {
    L1(L1),
    M1(M1),
}

#[derive(Clone, Debug)]
pub struct Inst {
    pub row: Row,
    /// Supplies predicate_digest (constant), vk_digest and settle_outref (witness bytes).
    /// Its flags, transition and payload are ignored by synthesis: the row fixes them.
    pub env: Env,
    pub public: (Fr, Fr),
}

impl L1 {
    /// Payload: template digest ‖ network label ‖ txid ‖ output index ‖ header ‖ pay cred ‖ threshold.
    pub fn payload(&self, honest: bool) -> Vec<u8> {
        let pc = self.tpl.seg("pay_cred").offset;
        let mut p = self.template_digest.to_vec();
        p.extend(self.network_label);
        if honest {
            p.extend(abi::b2b(&self.body));
            p.push(self.tpl.output_index);
            p.push(self.body[pc - 1]);
            p.extend(&self.body[pc..pc + 28]);
            p.extend(self.threshold.to_be_bytes());
        } else {
            p.extend([0u8; 32]);
            p.push(self.tpl.output_index);
            p.extend([0u8; 1 + 28 + 8]);
        }
        p
    }

    pub fn coin(&self) -> u64 {
        let s = self.tpl.seg("coin_be");
        self.body[s.offset..s.offset + s.len].iter().fold(0u64, |a, &b| (a << 8) | b as u64)
    }
}

impl M1 {
    /// The post-state a cheating prover would claim: u128 wrapping, never checked.
    pub fn post_wrapping(&self) -> [u128; 4] {
        let [paid, payer, recip, spons] = self.pre;
        [
            paid.wrapping_add(self.amount),
            payer.wrapping_sub(self.amount).wrapping_sub(2),
            recip.wrapping_add(self.amount),
            spons.wrapping_add(2),
        ]
    }

    pub fn transition(&self, post: [u128; 4]) -> Transition {
        Transition {
            pre: abi::encode_snapshot(&abi::pay_snapshot(self.pre)).0,
            post: abi::encode_snapshot(&abi::pay_snapshot(post)).0,
            effects: abi::encode_effects(&abi::pay_effects(self.amount, self.pre[0], post[0])).0,
        }
    }

    pub fn payload(&self) -> Vec<u8> {
        abi::pay_payload(&self.program_sha256, self.accepted, self.amount)
    }
}

/// The envelope a verifier would hold for this row: row-fixed flags plus the claimed
/// transition and payload. For P-M1 the claimed post-state is the u128-wrapping one, which
/// equals the honest post-state whenever Core accepts.
pub fn native_env(inst: &Inst) -> Env {
    let mut e = inst.env.clone();
    e.claim_kind = 0;
    e.setup_class = 0;
    match &inst.row {
        Row::L1(r) => {
            e.context_bound = false;
            e.transition = None;
            e.payload = r.payload(true);
        }
        Row::M1(r) => {
            e.context_bound = true;
            e.transition = Some(r.transition(r.post_wrapping()));
            e.payload = r.payload();
        }
    }
    e
}

/// Constant template: witness positions zeroed; structure identical to every honest statement.
fn template_env(inst: &Inst) -> Env {
    let mut e = native_env(inst);
    e.vk_digest = [0; 32];
    e.settle_outref = abi::OutRef { txid: [0; 32], index: 0 };
    match &inst.row {
        Row::L1(r) => e.payload = r.payload(false),
        Row::M1(r) => {
            let z = M1 { accepted: false, amount: 0, pre: [0; 4], ..r.clone() };
            e.transition = Some(z.transition([0; 4]));
            e.payload = z.payload();
        }
    }
    e
}

pub struct Circuit {
    pub inst: Inst,
    pub labels: Labels,
}

thread_local! {
    /// Statement bytes as assigned in the last synthesis (for native-vs-circuit comparison).
    pub static OBSERVED_STMT: RefCell<Vec<u8>> = const { RefCell::new(Vec::new()) };
}

fn alloc_bytes(ctx: &Ctx, bytes: &[u8]) -> R<Vec<Byte>> {
    bytes.iter().map(|&b| alloc_byte(ctx, b)).collect()
}

fn alloc_u128(ctx: &Ctx, v: u128) -> R<Vec<Bit>> {
    (0..128).map(|i| Bit::alloc(ctx, (v >> i) & 1 == 1)).collect()
}

fn put(over: &mut [Option<Byte>], off: usize, bytes: Vec<Byte>) {
    for (k, b) in bytes.into_iter().enumerate() {
        assert!(over[off + k].is_none(), "statement regions overlap at {}", off + k);
        over[off + k] = Some(b);
    }
}

impl ConstraintSynthesizer<Fr> for Circuit {
    fn generate_constraints(self, cs: ConstraintSystemRef<Fr>) -> Result<(), SynthesisError> {
        let ctx = Ctx { cs, labels: self.labels.clone() };
        let inst = &self.inst;

        ctx.label("public-inputs");
        let x_hi = ctx.input(inst.public.0)?;
        let x_lo = ctx.input(inst.public.1)?;

        let (tpl, lay) = abi::statement(&template_env(inst));
        let mut over: Vec<Option<Byte>> = vec![None; tpl.len()];

        ctx.label("vk-digest bytes (free witness)");
        put(&mut over, lay.vk_digest, alloc_bytes(&ctx, &inst.env.vk_digest)?);
        if let Some(o) = lay.outref {
            ctx.label("settle-outref bytes (free witness)");
            let mut b = inst.env.settle_outref.txid.to_vec();
            b.extend(inst.env.settle_outref.index.to_be_bytes());
            put(&mut over, o, alloc_bytes(&ctx, &b)?);
        }
        match &inst.row {
            Row::L1(r) => l1(&ctx, r, &lay, &mut over)?,
            Row::M1(r) => m1(&ctx, r, &lay, &mut over)?,
        }
        let stmt: Vec<Byte> = over.into_iter().zip(tpl.iter()).map(|(o, &c)| o.unwrap_or_else(|| byte_const(c))).collect();

        ctx.label("blake2b256(statement)");
        let digest = blake2b256(&ctx, &stmt)?;
        OBSERVED_STMT.with(|o| *o.borrow_mut() = stmt.iter().map(byte_val).collect());

        ctx.label("public-input binding hi");
        ctx.enforce_eq(lc!() + x_hi, be_lc(&digest[0..16]))?;
        ctx.label("public-input binding lo");
        ctx.enforce_eq(lc!() + x_lo, be_lc(&digest[16..32]))?;
        ctx.label("end");
        Ok(())
    }
}

fn l1(ctx: &Ctx, r: &L1, lay: &Layout, over: &mut [Option<Byte>]) -> R<()> {
    let tpl = &r.tpl;
    assert_eq!(r.body.len(), tpl.body_len, "body length is a circuit constant");

    ctx.label("body-bytes-booleanity");
    let body = alloc_bytes(ctx, &r.body)?;
    ctx.label("template-const");
    for s in tpl.segments.iter().filter(|s| s.kind == "const") {
        let want = s.hex.as_ref().expect("const segment bytes");
        for (k, &w) in want.iter().enumerate() {
            for (i, bit) in body[s.offset + k].iter().enumerate() {
                let c = if (w >> i) & 1 == 1 { lc!() + Variable::One } else { lc!() };
                ctx.enforce_eq(bit.lc.clone(), c)?;
            }
        }
    }

    ctx.label("blake2b256(body)=txid");
    let txid = blake2b256(ctx, &body)?;
    let pc = tpl.seg("pay_cred").offset;
    let cs_ = tpl.seg("coin_be");
    let coin_bytes: Vec<Byte> = body[cs_.offset..cs_.offset + cs_.len].to_vec();

    ctx.label("threshold-bytes");
    let t_bytes = alloc_bytes(ctx, &r.threshold.to_be_bytes())?;
    ctx.label("coin>=threshold");
    let diff = Fr::from(be_val(&coin_bytes) as u64) - Fr::from(r.threshold);
    alloc_bits_of(ctx, diff, 64, be_lc(&coin_bytes) - &be_lc(&t_bytes))?;

    // Payload offsets: 0 template digest, 32 label, 48 txid, 80 index, 81 header, 82 cred, 110 threshold.
    let p = lay.payload;
    put(over, p + 48, txid);
    put(over, p + 81, vec![body[pc - 1].clone()]);
    put(over, p + 82, body[pc..pc + 28].to_vec());
    put(over, p + 110, t_bytes);
    Ok(())
}

fn m1(ctx: &Ctx, r: &M1, lay: &Layout, over: &mut [Option<Byte>]) -> R<()> {
    ctx.label("requires accepted");
    let accepted = Bit::alloc(ctx, r.accepted)?;
    ctx.enforce_eq(accepted.lc.clone(), lc!() + Variable::One)?;

    ctx.label("amount range (u128)");
    let amount = alloc_u128(ctx, r.amount)?;
    let amount_lc = pack(&amount);

    ctx.label("requires amount>0");
    let inv = Fr::from(r.amount).inverse().unwrap_or(Fr::from(0u64));
    let inv_v = ctx.witness(inv)?;
    ctx.enforce(amount_lc.clone(), lc!() + inv_v, lc!() + Variable::One)?;

    ctx.label("pre-snapshot range");
    let pre: Vec<Vec<Bit>> = r.pre.iter().map(|&v| alloc_u128(ctx, v)).collect::<R<_>>()?;
    let [paid0, payer0, recip0, spons0] = [&pre[0], &pre[1], &pre[2], &pre[3]].map(|b| pack(b));
    let a = Fr::from(r.amount);
    let two = Fr::from(2u64);
    let f = r.pre.map(Fr::from);
    let payer1_fr = f[1] - a;

    // Field arithmetic for the honest assignment: an underflow or overflow yields a value
    // outside [0, 2^128), whose 128 honest bits cannot satisfy the packing constraint.
    ctx.label("transfer debit payer (checked sub)");
    let payer1 = alloc_bits_of(ctx, payer1_fr, 128, payer0 - &amount_lc)?;
    ctx.label("transfer credit recipient (checked add)");
    let recip1 = alloc_bits_of(ctx, f[2] + a, 128, recip0 + &amount_lc)?;
    ctx.label("fee debit payer (checked sub)");
    let payer2 = alloc_bits_of(ctx, payer1_fr - two, 128, pack(&payer1) - (two, Variable::One))?;
    ctx.label("fee credit sponsor (checked add)");
    let spons1 = alloc_bits_of(ctx, f[3] + two, 128, spons0 + (two, Variable::One))?;
    ctx.label("next paid = paid + amount (checked add)");
    let paid1 = alloc_bits_of(ctx, f[0] + a, 128, paid0 + &amount_lc)?;

    // Snapshot u128 slots: [paid, payer, recipient, sponsor].
    let snap = abi::encode_snapshot(&abi::pay_snapshot([0; 4])).1;
    // Effects u128 slots: [transfer amount, fee amount (constant 2), state before, state after, emit].
    let eff = abi::encode_effects(&abi::pay_effects(0, 0, 0)).1;
    let (pre_off, post_off, eff_off) = (lay.pre.unwrap(), lay.post.unwrap(), lay.effects.unwrap());
    for (k, bits) in pre.iter().enumerate() {
        put(over, pre_off + snap[k], u128_be_bytes(bits));
    }
    for (k, bits) in [&paid1, &payer2, &recip1, &spons1].into_iter().enumerate() {
        put(over, post_off + snap[k], u128_be_bytes(bits));
    }
    put(over, eff_off + eff[0], u128_be_bytes(&amount));
    put(over, eff_off + eff[2], u128_be_bytes(&pre[0]));
    put(over, eff_off + eff[3], u128_be_bytes(&paid1));
    put(over, eff_off + eff[4], u128_be_bytes(&paid1));

    // Payload: program digest (constant) ‖ accepted ‖ amount.
    let mut acc = vec![accepted];
    acc.extend((1..8).map(|_| Bit::constant(false)));
    put(over, lay.payload + 32, vec![acc]);
    put(over, lay.payload + 33, u128_be_bytes(&amount));
    Ok(())
}
