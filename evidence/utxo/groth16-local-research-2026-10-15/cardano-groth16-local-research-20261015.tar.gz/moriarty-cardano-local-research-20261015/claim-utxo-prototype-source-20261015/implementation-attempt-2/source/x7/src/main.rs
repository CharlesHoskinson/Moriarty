//! X7: research-only claim-certificate relations P-L1 and P-M1 for ABI v0 (PROPOSED, not adopted).
//!
//! Usage: x7 <abi|run|setup|prove> --frozen DIR --catalogue DIR --out DIR [options]
//!   abi                       encodings, oracle cross-check, constraint-level checks; no setup
//!   run   --row L1|M1         one process: setup, prove, verify, refusals; no proving key written
//!   setup --row L1|M1 --pk-out FILE   setup; writes VK, admission record and the PRIVATE proving key
//!   prove --row L1|M1 --pk FILE       proof for the given context with a stored proving key
//! Context options (run/prove): --outref TXIDHEX#INDEX --expiry MS --refund-vkh HEX56
//! Setup randomness comes from /dev/urandom and is never written. Class 0 research; no funds.

#[path = "../../../../../groth16-preprod-experiments-20261015/g16/src/gadgets.rs"]
mod gadgets;
#[allow(dead_code)]
#[path = "../../../../../groth16-preprod-experiments-20261015/g16/src/circuit.rs"]
mod circuit;
mod abi;
mod relations;

use abi::{Env, OutRef};
use ark_bls12_381::{Bls12_381, Fr};
use ark_ff::{BigInteger, PrimeField};
use ark_groth16::{Groth16, PreparedVerifyingKey, Proof, ProvingKey, VerifyingKey};
use ark_relations::r1cs::{ConstraintSynthesizer, ConstraintSystem, OptimizationGoal, SynthesisMode};
use ark_serialize::{CanonicalDeserialize, CanonicalSerialize};
use ark_snark::SNARK;
use blake2::{Blake2b, Digest, digest::consts::U32};
use circuit::{Segment, Template, fr_to_dec, public_inputs};
use gadgets::{Labels, label_of};
use rand_chacha::ChaCha20Rng;
use rand_chacha::rand_core::SeedableRng;
use relations::{Circuit, Inst, L1, M1, OBSERVED_STMT, Row, native_env};
use serde_json::{Value as J, json};
use sha2::Sha256;
use std::path::{Path, PathBuf};
use std::time::Instant;

type G16 = Groth16<Bls12_381>;

const PAYER0: u128 = 1_000_000_000_000_000;
const AMOUNT: u128 = 1_000_000;
const NETWORK_LABEL: &str = "cardano-preprod";

fn rng() -> ChaCha20Rng {
    use std::io::Read;
    let mut seed = [0u8; 32];
    std::fs::File::open("/dev/urandom").unwrap().read_exact(&mut seed).unwrap();
    ChaCha20Rng::from_seed(seed)
}

fn ser<T: CanonicalSerialize>(x: &T) -> Vec<u8> {
    let mut v = Vec::new();
    x.serialize_compressed(&mut v).unwrap();
    v
}

fn arr<const N: usize>(h: &str) -> [u8; N] {
    hex::decode(h).expect("hex").try_into().unwrap_or_else(|_| panic!("expected {} bytes", N))
}

// ---------------------------------------------------------------- inputs

struct Args {
    cmd: String,
    frozen: PathBuf,
    catalogue: PathBuf,
    out: PathBuf,
    row: Option<String>,
    outref: Option<OutRef>,
    expiry: u64,
    refund_vkh: Option<[u8; 28]>,
    pk: Option<PathBuf>,
    pk_out: Option<PathBuf>,
}

fn parse_args() -> Args {
    let v: Vec<String> = std::env::args().collect();
    let mut a = Args {
        cmd: v.get(1).cloned().unwrap_or_default(),
        frozen: PathBuf::new(),
        catalogue: PathBuf::new(),
        out: PathBuf::new(),
        row: None,
        outref: None,
        expiry: 0,
        refund_vkh: None,
        pk: None,
        pk_out: None,
    };
    let mut i = 2;
    while i < v.len() {
        let val = v.get(i + 1).unwrap_or_else(|| panic!("missing value for {}", v[i])).clone();
        match v[i].as_str() {
            "--frozen" => a.frozen = val.into(),
            "--catalogue" => a.catalogue = val.into(),
            "--out" => a.out = val.into(),
            "--row" => a.row = Some(val),
            "--outref" => {
                let (t, ix) = val.split_once('#').expect("--outref TXIDHEX#INDEX");
                a.outref = Some(OutRef { txid: arr::<32>(t), index: ix.parse().expect("u16 index") });
            }
            "--expiry" => a.expiry = val.parse().expect("u64 expiry"),
            "--refund-vkh" => a.refund_vkh = Some(arr::<28>(&val)),
            "--pk" => a.pk = Some(val.into()),
            "--pk-out" => a.pk_out = Some(val.into()),
            other => panic!("unknown option {other}"),
        }
        i += 2;
    }
    assert!(!a.frozen.as_os_str().is_empty() && !a.catalogue.as_os_str().is_empty() && !a.out.as_os_str().is_empty(),
        "--frozen, --catalogue and --out are required");
    a
}

struct Data {
    tpl: Template,
    tpl_digest: [u8; 32],
    body: Vec<u8>,
    txid_provider: String,
    program_sha256: [u8; 32],
    pl1_digest: [u8; 32],
    pm1_digest: [u8; 32],
    oracle: J,
}

fn load(a: &Args) -> Data {
    let root = &a.frozen;
    let tpl_bytes = std::fs::read(root.join("data/selected/template.json")).unwrap();
    let t: J = serde_json::from_slice(&tpl_bytes).unwrap();
    let segments = t["segments"]
        .as_array()
        .unwrap()
        .iter()
        .map(|s| Segment {
            kind: s["kind"].as_str().unwrap().into(),
            offset: s["offset"].as_u64().unwrap() as usize,
            len: s["len"].as_u64().unwrap() as usize,
            hex: s.get("hex").map(|h| hex::decode(h.as_str().unwrap()).unwrap()),
        })
        .collect();
    let tpl = Template {
        body_len: t["bodyLen"].as_u64().unwrap() as usize,
        output_index: t["targetOutputIndex"].as_u64().unwrap() as u8,
        address_header: t["targetAddressHeader"].as_u64().unwrap() as u8,
        segments,
    };
    let sel: J = serde_json::from_slice(&std::fs::read(root.join("data/selected/selection.json")).unwrap()).unwrap();
    let program = std::fs::read(root.join("data/moriarty/payment.mori")).unwrap();
    Data {
        tpl,
        tpl_digest: abi::b2b(&tpl_bytes),
        body: std::fs::read(root.join("data/selected/selected-body.bin")).unwrap(),
        txid_provider: sel["selected"]["txHash"].as_str().unwrap().into(),
        program_sha256: Sha256::digest(&program).into(),
        pl1_digest: abi::b2b(&std::fs::read(a.catalogue.join("P-L1.v0.json")).unwrap()),
        pm1_digest: abi::b2b(&std::fs::read(a.catalogue.join("P-M1.v0.json")).unwrap()),
        oracle: serde_json::from_slice(&std::fs::read(root.join("out/x0/moriref.json")).unwrap()).unwrap(),
    }
}

fn label16() -> [u8; 16] {
    let mut l = [0u8; 16];
    l[..NETWORK_LABEL.len()].copy_from_slice(NETWORK_LABEL.as_bytes());
    l
}

fn l1_row(d: &Data, body: &[u8], threshold: u64) -> L1 {
    L1 { tpl: d.tpl.clone(), template_digest: d.tpl_digest, network_label: label16(), body: body.to_vec(), threshold }
}

fn m1_row(d: &Data, accepted: bool, amount: u128, pre: [u128; 4]) -> M1 {
    M1 { program_sha256: d.program_sha256, accepted, amount, pre }
}

fn base_env(predicate_digest: [u8; 32], vk_digest: [u8; 32], outref: OutRef, expiry: u64, refund_vkh: [u8; 28]) -> Env {
    Env {
        claim_kind: 0,
        predicate_digest,
        vk_digest,
        setup_class: 0,
        context_bound: false,
        settle_outref: outref,
        transition: None,
        payload: vec![],
        expiry,
        refund_vkh,
    }
}

/// Instance whose public inputs are the digest of its own native statement.
fn honest(row: Row, env: Env) -> Inst {
    let mut inst = Inst { row, env, public: (Fr::from(0u64), Fr::from(0u64)) };
    let stmt = abi::statement(&native_env(&inst)).0;
    inst.public = public_inputs(&abi::b2b(&stmt));
    inst
}

fn row_of(d: &Data, name: &str, coin_threshold: bool) -> (Row, [u8; 32]) {
    match name {
        "L1" => {
            let l = l1_row(d, &d.body, 0);
            let coin = l.coin();
            (Row::L1(L1 { threshold: if coin_threshold { coin } else { 0 }, ..l }), d.pl1_digest)
        }
        "M1" => (Row::M1(m1_row(d, true, AMOUNT, [0, PAYER0, 0, 0])), d.pm1_digest),
        other => panic!("unknown row {other}"),
    }
}

// ---------------------------------------------------------------- checks

struct Check {
    satisfied: bool,
    first: Option<String>,
    constraints: usize,
    labels: Vec<(usize, String)>,
    statement: Vec<u8>,
}

fn labelled_check(inst: &Inst) -> Check {
    let cs = ConstraintSystem::<Fr>::new_ref();
    cs.set_optimization_goal(OptimizationGoal::Constraints);
    let labels: Labels = Default::default();
    Circuit { inst: inst.clone(), labels: labels.clone() }.generate_constraints(cs.clone()).unwrap();
    let unsat = cs.which_is_unsatisfied().unwrap();
    let l = labels.borrow().clone();
    let first = unsat.map(|idx| {
        let i: usize = idx.parse().unwrap_or(usize::MAX);
        format!("constraint #{} in region '{}'", i, label_of(&l, i))
    });
    Check {
        satisfied: first.is_none(),
        first,
        constraints: cs.num_constraints(),
        labels: l,
        statement: OBSERVED_STMT.with(|o| o.borrow().clone()),
    }
}

fn region_counts(labels: &[(usize, String)], total: usize) -> J {
    let mut out = serde_json::Map::new();
    for (i, (s, name)) in labels.iter().enumerate() {
        let e = labels.get(i + 1).map(|x| x.0).unwrap_or(total);
        let v = out.entry(name.clone()).or_insert(json!(0));
        *v = json!(v.as_u64().unwrap() + (e - s) as u64);
    }
    J::Object(out)
}

/// Digest of the R1CS matrices after inlining. Recorded in the admission record next to
/// the VK digest; never fed back into any circuit, so it has no fixed point.
fn r1cs_digest(inst: &Inst) -> (String, usize) {
    let cs = ConstraintSystem::<Fr>::new_ref();
    cs.set_optimization_goal(OptimizationGoal::Constraints);
    cs.set_mode(SynthesisMode::Setup);
    Circuit { inst: inst.clone(), labels: Default::default() }.generate_constraints(cs.clone()).unwrap();
    cs.finalize();
    let m = cs.to_matrices().expect("matrices");
    let mut h = Blake2b::<U32>::new();
    h.update(b"MRG16-PVC-R1CS-0");
    for n in [m.num_instance_variables, m.num_witness_variables, m.num_constraints] {
        h.update((n as u64).to_le_bytes());
    }
    for mat in [&m.a, &m.b, &m.c] {
        for row in mat.iter() {
            h.update((row.len() as u64).to_le_bytes());
            for (coeff, idx) in row {
                h.update(coeff.into_bigint().to_bytes_le());
                h.update((*idx as u64).to_le_bytes());
            }
        }
    }
    (hex::encode(h.finalize()), m.num_constraints)
}

struct Run {
    results: Vec<J>,
}

impl Run {
    fn rec(&mut self, id: &str, expectation: &str, observed: J, pass: bool) {
        println!("[{}] {} -> {} :: {}", if pass { "AS-EXPECTED" } else { "UNEXPECTED" }, id, expectation, observed);
        self.results.push(json!({"id": id, "expectation": expectation, "observed": observed, "asExpected": pass}));
    }
    fn all_pass(&self) -> bool {
        self.results.iter().all(|r| r["asExpected"] == true)
    }
}

fn write(dir: &Path, name: &str, v: &J) {
    std::fs::create_dir_all(dir).unwrap();
    std::fs::write(dir.join(name), serde_json::to_string_pretty(v).unwrap()).unwrap();
}

fn refusal(run: &mut Run, id: &str, inst: &Inst, region: &str, oracle: Option<&J>) {
    let c = labelled_check(inst);
    run.rec(id, &format!("unsatisfied, first in region '{region}'"),
        json!({"satisfied": c.satisfied, "firstUnsatisfied": c.first,
               "oracleResult": oracle.map(|o| o["result"].clone()), "oracleCode": oracle.map(|o| o["error"]["code"].clone())}),
        !c.satisfied && c.first.as_deref().unwrap_or("").contains(region));
}

// ---------------------------------------------------------------- oracle conversion

fn j_val(v: &J) -> abi::Val {
    match v["type"].as_str().unwrap() {
        "UInt" => abi::Val::UInt(v["value"].as_str().unwrap().parse().unwrap()),
        "Bool" => abi::Val::Bool(v["value"].as_bool().unwrap()),
        t => panic!("unknown value type {t}"),
    }
}

fn j_asset(a: &J) -> abi::AssetId {
    abi::AssetId {
        network: a["network"].as_str().unwrap().into(),
        issuer: a["issuer"].as_str().unwrap().into(),
        reference: a["reference"].as_str().unwrap().into(),
        scale: a["scale"].as_u64().unwrap() as u8,
    }
}

fn j_snapshot(s: &J) -> abi::Snapshot {
    let mut state: Vec<(String, abi::Val)> = s["state"].as_object().unwrap().iter().map(|(k, v)| (k.clone(), j_val(v))).collect();
    state.sort_by(|a, b| a.0.cmp(&b.0));
    let balances = s["balances"]
        .as_array()
        .unwrap()
        .iter()
        .map(|b| (b["account"].as_str().unwrap().into(), j_asset(&b["asset"]), b["amount"].as_str().unwrap().parse().unwrap()))
        .collect();
    assert!(s["liabilities"].as_array().unwrap().is_empty(), "payment.mori declares no liabilities");
    abi::Snapshot { state, balances, liabilities: vec![] }
}

fn j_effects(es: &J) -> Vec<abi::Effect> {
    es.as_array()
        .unwrap()
        .iter()
        .map(|e| {
            let s = |k: &str| e[k].as_str().unwrap().to_string();
            match e["kind"].as_str().unwrap() {
                "Transfer" => abi::Effect::Transfer { asset: j_asset(&e["asset"]), from: s("from"), to: s("to"), amount: s("amount").parse().unwrap() },
                "Fee" => abi::Effect::Fee { asset: j_asset(&e["asset"]), from: s("from"), to: s("to"), amount: s("amount").parse().unwrap() },
                "State" => abi::Effect::State { name: s("name"), before: j_val(&e["before"]), after: j_val(&e["after"]) },
                "Emit" => abi::Effect::Emit { name: s("name"), value: j_val(&e["value"]) },
                k => panic!("effect kind {k} is outside the pay action"),
            }
        })
        .collect()
}

// ---------------------------------------------------------------- abi (no setup)

fn cmd_abi(a: &Args, d: &Data) -> bool {
    let mut run = Run { results: vec![] };
    let declared = OutRef { txid: [0x44; 32], index: 1 };

    // Fixtures F0/F1 (ABI-v0.md §7); unit tests assert the hand-written bytes.
    let f0 = Env { payload: vec![0xca, 0xfe], expiry: 1000, ..base_env([0x22; 32], [0x33; 32], declared.clone(), 1000, [0x55; 28]) };
    let f1 = Env {
        context_bound: true,
        transition: Some(abi::Transition { pre: vec![0xaa], post: vec![0xbb], effects: vec![0xcc] }),
        payload: vec![],
        ..f0.clone()
    };
    let mut fixtures: Vec<J> = [("F0", &f0), ("F1", &f1)]
        .iter()
        .map(|(n, e)| json!({"fixture": n, "statementHex": hex::encode(abi::statement(e).0),
            "envelopeCborHex": hex::encode(abi::cbor(&abi::pd_env(e))), "assetNameHex": hex::encode(abi::asset_name(e))}))
        .collect();

    // Oracle cross-check: Core's own pay execution, re-encoded, against the native pay model.
    let case0 = &d.oracle["cases"][0]["execution"];
    let post_native = abi::pay_native([0, PAYER0, 0, 0], AMOUNT, true).expect("positive vector");
    let snap_native = abi::encode_snapshot(&abi::pay_snapshot(post_native)).0;
    let snap_oracle = abi::encode_snapshot(&j_snapshot(&case0["post"])).0;
    let pre_native = abi::encode_snapshot(&abi::pay_snapshot([0, PAYER0, 0, 0])).0;

    // Thread fixture T0: declared seed, declared c0_hash, placeholder VK digest.
    let seed = OutRef { txid: [0x10; 32], index: 0 };
    let tid = abi::thread_id(&seed);
    let slots = [abi::Slot { predicate_digest: d.pm1_digest, vk_digest: [0x33; 32], require_context: true, require_transition: true }];
    fixtures.push(json!({"fixture": "T0", "threadIdHex": hex::encode(tid),
        "genesisRedeemerCborHex": hex::encode(abi::cbor(&abi::pd_genesis(&seed))),
        "threadDatumCborHex": hex::encode(abi::cbor(&abi::pd_thread(&tid, &[0xc0; 28], &slots, &pre_native, &[0; 32], 0))),
        "burnRedeemerCborHex": hex::encode(abi::cbor(&abi::pd_burn()))}));
    let pre_oracle = abi::encode_snapshot(&j_snapshot(&case0["pre"])).0;
    let eff_native = abi::encode_effects(&abi::pay_effects(AMOUNT, 0, post_native[0])).0;
    let eff_oracle = abi::encode_effects(&j_effects(&case0["effects"])).0;
    run.rec("E-X7-1.oracle-encodings", "MSB0/MEB0 of mori_core::simulate output equal the native pay model",
        json!({"preEqual": pre_native == pre_oracle, "postEqual": snap_native == snap_oracle, "effectsEqual": eff_native == eff_oracle,
               "preHex": hex::encode(&pre_native), "postHex": hex::encode(&snap_native), "effectsHex": hex::encode(&eff_native),
               "lens": [pre_native.len(), snap_native.len(), eff_native.len()]}),
        pre_native == pre_oracle && snap_native == snap_oracle && eff_native == eff_oracle);

    let mut rows = serde_json::Map::new();
    for name in ["L1", "M1"] {
        let (row, pd) = row_of(d, name, true);
        let inst = honest(row, base_env(pd, [0x33; 32], declared.clone(), 1000, [0x55; 28]));
        let native = abi::statement(&native_env(&inst)).0;
        let c = labelled_check(&inst);
        let (rd, rn) = r1cs_digest(&inst);
        run.rec(&format!("E-X7-2.{name}.native-vs-circuit"), "satisfied; circuit statement equals native statement",
            json!({"satisfied": c.satisfied, "firstUnsatisfied": c.first, "constraints": c.constraints,
                   "statementLen": native.len(), "statementEqual": c.statement == native}),
            c.satisfied && c.statement == native);
        rows.insert(name.into(), json!({"predicateDigest": hex::encode(pd), "r1csDigest": rd, "r1csConstraints": rn,
            "constraints": c.constraints, "regions": region_counts(&c.labels, c.constraints), "statementHex": hex::encode(&native)}));

        // Public-input binding: honest witness, public inputs of another statement.
        let mut other = native.clone();
        other[abi::statement(&native_env(&inst)).1.vk_digest] ^= 1;
        let bad = Inst { public: public_inputs(&abi::b2b(&other)), ..inst.clone() };
        refusal(&mut run, &format!("E-X7-3.{name}.public-binding"), &bad, "public-input binding", None);

        // The R1CS does not depend on witness values.
        let mut w = inst.clone();
        w.env.vk_digest = [0x99; 32];
        w.env.settle_outref = OutRef { txid: [0x11; 32], index: 7 };
        let (rd2, _) = r1cs_digest(&w);
        run.rec(&format!("E-X7-4.{name}.r1cs-witness-independent"), "R1CS digest unchanged by witness values",
            json!({"a": rd, "b": rd2}), rd == rd2);
    }

    // P-M1 refusal vectors mirror oracle cases R1..R5; R5 isolates `requires amount > 0`.
    let max = u128::MAX;
    let v = AMOUNT;
    let cases: [(&str, bool, u128, [u128; 4], &str); 5] = [
        ("E-X7-5.R1-fee-underflow", true, v, [0, v + 1, 0, 0], "fee debit payer"),
        ("E-X7-5.R2-credit-overflow", true, v, [0, PAYER0, max, 0], "transfer credit recipient"),
        ("E-X7-5.R3-accepted-false", false, v, [0, PAYER0, 0, 0], "requires accepted"),
        ("E-X7-5.R4-paid-overflow", true, v, [max - v + 1, PAYER0, 0, 0], "next paid"),
        ("E-X7-5.R5-amount-zero (derived negative)", true, 0, [0, PAYER0, 0, 0], "requires amount>0"),
    ];
    for (i, (id, acc, amount, pre, region)) in cases.into_iter().enumerate() {
        let inst = honest(Row::M1(m1_row(d, acc, amount, pre)), base_env(d.pm1_digest, [0x33; 32], declared.clone(), 1000, [0x55; 28]));
        let native = abi::pay_native(pre, amount, acc);
        refusal(&mut run, id, &inst, region, Some(&d.oracle["cases"][i + 1]));
        run.rec(&format!("{id}.native-model"), "native pay model refuses too", json!({"native": format!("{native:?}")}), native.is_err());
    }

    // P-L1 witness refusals (derived mutations of the frozen Preprod body).
    let mk = |body: &[u8], t: u64| honest(Row::L1(l1_row(d, body, t)), base_env(d.pl1_digest, [0x33; 32], declared.clone(), 1000, [0x55; 28]));
    let coin = l1_row(d, &d.body, 0).coin();
    let mut hdr = d.body.clone();
    hdr[1] ^= 1;
    refusal(&mut run, "E-X7-6.L1-header-byte", &mk(&hdr, coin), "template-const", None);
    refusal(&mut run, "E-X7-6.L1-threshold-above-coin", &mk(&d.body, coin + 1), "coin>=threshold", None);
    let honest_l1 = mk(&d.body, coin);
    let mut suffix = d.body.clone();
    suffix[400] ^= 1;
    let s_inst = Inst { row: Row::L1(l1_row(d, &suffix, coin)), ..honest_l1.clone() };
    refusal(&mut run, "E-X7-6.L1-body-suffix-under-honest-digest", &s_inst, "public-input binding", None);
    let txid_ok = hex::encode(&abi::statement(&native_env(&honest_l1)).0[118 + 48..118 + 80]) == d.txid_provider;
    run.rec("E-X7-6.L1-txid-equals-provider", "statement txid equals the frozen provider txid (E0 equality, not authentication)",
        json!({"equal": txid_ok}), txid_ok);

    let pass = run.all_pass();
    write(&a.out.join("abi"), "results.json", &json!({"experiment": "X7-abi", "abi": "MRG16-PVC ABI v0 (PROPOSED)",
        "fixtures": fixtures, "rows": rows, "results": run.results, "allAsExpected": pass}));
    pass
}

// ---------------------------------------------------------------- setup / prove

fn setup(inst: &Inst) -> (ProvingKey<Bls12_381>, f64) {
    let t = Instant::now();
    let mut r = rng();
    let (pk, _vk) = G16::circuit_specific_setup(Circuit { inst: inst.clone(), labels: Default::default() }, &mut r).unwrap();
    (pk, t.elapsed().as_secs_f64())
}

fn prove(pk: &ProvingKey<Bls12_381>, inst: &Inst) -> (Proof<Bls12_381>, f64) {
    let t = Instant::now();
    let mut r = rng();
    let p = G16::prove(pk, Circuit { inst: inst.clone(), labels: Default::default() }, &mut r).unwrap();
    (p, t.elapsed().as_secs_f64())
}

fn verify(pvk: &PreparedVerifyingKey<Bls12_381>, stmt: &[u8], p: &Proof<Bls12_381>) -> bool {
    let x = public_inputs(&abi::b2b(stmt));
    G16::verify_with_processed_vk(pvk, &[x.0, x.1], p).unwrap_or(false)
}

fn context(a: &Args) -> (OutRef, u64, [u8; 28]) {
    (
        a.outref.clone().expect("--outref is required"),
        a.expiry,
        a.refund_vkh.expect("--refund-vkh is required"),
    )
}

fn admission(name: &str, pd: &[u8; 32], vk: &VerifyingKey<Bls12_381>, inst: &Inst) -> J {
    let (rd, rn) = r1cs_digest(inst);
    json!({
        "schema": "moriarty-research-pvc/admission-record/v0",
        "row": name, "predicateDigest": hex::encode(pd), "r1csDigest": rd, "r1csConstraints": rn,
        "vkDigest": hex::encode(abi::b2b(&ser(vk))), "family": String::from_utf8_lossy(abi::FAMILY_ID),
        "setupClass": 0,
        "setup": "research circuit_specific_setup, single party, trapdoor dropped in-process; NOT a ceremony; Class 0 only",
        "trust": "a consumer that pins vkDigest in a thread slot adopts this record as its relation trust root",
    })
}

/// Proof plus the exact bytes a C0 Issue transaction needs; also the generator input
/// for scripts/gen_x7_aiken.py.
fn emit_claim(dir: &Path, name: &str, env: &Env, vk: &VerifyingKey<Bls12_381>, proof: &Proof<Bls12_381>) -> J {
    let vk_bytes = ser(vk);
    let proof_bytes = ser(proof);
    let stmt = abi::statement(env).0;
    std::fs::create_dir_all(dir).unwrap();
    std::fs::write(dir.join("vk.bin"), &vk_bytes).unwrap();
    std::fs::write(dir.join("proof.bin"), &proof_bytes).unwrap();
    std::fs::write(dir.join("statement.bin"), &stmt).unwrap();
    let x = public_inputs(&abi::b2b(&stmt));
    let t = env.transition.as_ref();
    let claim = json!({
        "row": name,
        "envelope": {
            "claimKind": env.claim_kind, "predicateDigest": hex::encode(env.predicate_digest), "vkDigest": hex::encode(env.vk_digest),
            "setupClass": env.setup_class, "contextBound": env.context_bound,
            "settleOutref": {"txid": hex::encode(env.settle_outref.txid), "index": env.settle_outref.index},
            "transition": t.map(|t| json!({"pre": hex::encode(&t.pre), "post": hex::encode(&t.post), "effects": hex::encode(&t.effects)})),
            "payload": hex::encode(&env.payload), "expiry": env.expiry, "refundVkh": hex::encode(env.refund_vkh),
        },
        "envelopeCborHex": hex::encode(abi::cbor(&abi::pd_env(env))),
        "assetNameHex": hex::encode(abi::asset_name(env)),
        "issueRedeemerCborHex": hex::encode(abi::cbor(&abi::pd_issue(&vk_bytes, &proof_bytes))),
        "vkHex": hex::encode(&vk_bytes), "proofHex": hex::encode(&proof_bytes),
        "statementHex": hex::encode(&stmt), "statementDigest": hex::encode(abi::b2b(&stmt)),
        "publicInputsDecimal": [fr_to_dec(&x.0), fr_to_dec(&x.1)],
    });
    write(dir, "claim.json", &claim);
    claim
}

fn flipped(stmt: &[u8], off: usize, mask: u8) -> Vec<u8> {
    let mut s = stmt.to_vec();
    s[off] ^= mask;
    s
}

fn cmd_run(a: &Args, d: &Data) -> bool {
    let mut run = Run { results: vec![] };
    let name = a.row.clone().expect("--row L1|M1");
    let (outref, expiry, refund) = context(a);
    let (row, pd) = row_of(d, &name, true);
    // Setup does not depend on witness values (E-X7-4), so the VK digest can enter afterwards.
    let pre_inst = honest(row.clone(), base_env(pd, [0; 32], outref.clone(), expiry, refund));
    let (pk, t_setup) = setup(&pre_inst);
    let vk = pk.vk.clone();
    let pvk = G16::process_vk(&vk).unwrap();
    let inst = honest(row, base_env(pd, abi::b2b(&ser(&vk)), outref, expiry, refund));
    let env = native_env(&inst);
    abi::well_formed(&env).expect("envelope well-formed");
    let (stmt, lay) = abi::statement(&env);

    let c = labelled_check(&inst);
    run.rec("E-X7-7.native-vs-circuit", "satisfied; circuit statement equals native",
        json!({"satisfied": c.satisfied, "firstUnsatisfied": c.first, "constraints": c.constraints, "statementEqual": c.statement == stmt}),
        c.satisfied && c.statement == stmt);
    let (proof, t_prove) = prove(&pk, &inst);
    let ok = verify(&pvk, &stmt, &proof);
    run.rec("E-X7-7.positive", "proof verifies for the envelope statement",
        json!({"verified": ok, "setupSeconds": t_setup, "proveSeconds": t_prove}), ok);

    // Verifier-side statement mutations: each must be rejected by the pairing check.
    let mut muts: Vec<(&str, usize, u8)> = vec![
        ("vk-digest byte", lay.vk_digest, 1),
        ("claim_kind 0 -> 1", lay.vk_digest + 32, 1),
        ("setup_class 0 -> 1", lay.vk_digest + 33, 1),
        ("context tag flipped", lay.vk_digest + 34, 1),
        ("payload last byte", lay.payload + env.payload.len() - 1, 1),
    ];
    if let Some(o) = lay.outref {
        muts.push(("settle outref txid byte", o, 1));
        muts.push(("settle outref index", o + 33, 1));
    }
    if let (Some(p), Some(q), Some(e)) = (lay.pre, lay.post, lay.effects) {
        muts.push(("pre-state last byte", p + 170, 1));
        muts.push(("post-state last byte", q + 170, 1));
        muts.push(("effects last byte", e + 183, 1));
    }
    for (what, off, mask) in muts {
        let okm = verify(&pvk, &flipped(&stmt, off, mask), &proof);
        run.rec(&format!("E-X7-8.{name}.M-{what}"), "verify rejects", json!({"verified": okm}), !okm);
    }

    // Forced proofs over unsatisfied witnesses claim a wrapped or Core-refused result.
    let forced: Vec<(&str, Inst)> = match &inst.row {
        Row::M1(m) => vec![
            ("R1-fee-underflow wrapped post", Inst { row: Row::M1(M1 { pre: [0, AMOUNT + 1, 0, 0], ..m.clone() }), ..inst.clone() }),
            ("R5-amount-zero (derived negative)", Inst { row: Row::M1(M1 { amount: 0, ..m.clone() }), ..inst.clone() }),
        ],
        Row::L1(l) => vec![("threshold above coin", Inst { row: Row::L1(L1 { threshold: l.coin() + 1, ..l.clone() }), ..inst.clone() })],
    };
    for (what, f) in forced {
        let f = honest(f.row, f.env);
        let fs = abi::statement(&native_env(&f)).0;
        let (pf, _) = prove(&pk, &f);
        let okf = verify(&pvk, &fs, &pf);
        run.rec(&format!("E-X7-9.{name}.forced-{what}"), "forced proof does not verify", json!({"verified": okf}), !okf);
    }

    let dir = a.out.join(&name);
    let claim = emit_claim(&dir, &name, &env, &vk, &proof);
    write(&dir, "admission.json", &admission(&name, &pd, &vk, &inst));
    let pass = run.all_pass();
    write(&dir, "results.json", &json!({"experiment": format!("X7-run-{name}"), "abi": "MRG16-PVC ABI v0 (PROPOSED)",
        "context": "settle outref, expiry and refund key are DECLARED inputs of this run, not ledger observations",
        "assetName": claim["assetNameHex"], "results": run.results, "allAsExpected": pass,
        "privateMaterial": "trapdoor and proving key dropped in-process; nothing persisted"}));
    pass
}

fn cmd_setup(a: &Args, d: &Data) -> bool {
    let name = a.row.clone().expect("--row L1|M1");
    let pk_out = a.pk_out.clone().expect("--pk-out FILE (private; never share)");
    let (row, pd) = row_of(d, &name, true);
    let inst = honest(row, base_env(pd, [0; 32], OutRef { txid: [0; 32], index: 0 }, 0, [0; 28]));
    let (pk, t) = setup(&inst);
    let mut bytes = Vec::new();
    pk.serialize_uncompressed(&mut bytes).unwrap();
    std::fs::write(&pk_out, &bytes).unwrap();
    let dir = a.out.join(format!("{name}-setup"));
    std::fs::create_dir_all(&dir).unwrap();
    std::fs::write(dir.join("vk.bin"), ser(&pk.vk)).unwrap();
    let mut adm = admission(&name, &pd, &pk.vk, &inst);
    adm["setupSeconds"] = json!(t);
    adm["provingKey"] = json!("written to the private --pk-out path; its contents are not a public artefact");
    write(&dir, "admission.json", &adm);
    true
}

fn cmd_prove(a: &Args, d: &Data) -> bool {
    let name = a.row.clone().expect("--row L1|M1");
    let pk_bytes = std::fs::read(a.pk.clone().expect("--pk FILE")).unwrap();
    let pk = ProvingKey::<Bls12_381>::deserialize_uncompressed(&pk_bytes[..]).unwrap();
    let (outref, expiry, refund) = context(a);
    let (row, pd) = row_of(d, &name, true);
    let inst = honest(row, base_env(pd, abi::b2b(&ser(&pk.vk)), outref, expiry, refund));
    let env = native_env(&inst);
    abi::well_formed(&env).expect("envelope well-formed");
    let c = labelled_check(&inst);
    assert!(c.satisfied, "witness does not satisfy the relation: {:?}", c.first);
    let (proof, _) = prove(&pk, &inst);
    let ok = verify(&G16::process_vk(&pk.vk).unwrap(), &abi::statement(&env).0, &proof);
    emit_claim(&a.out.join(format!("{name}-claim")), &name, &env, &pk.vk, &proof);
    println!("[{}] prove {name}: native verification {ok}", if ok { "AS-EXPECTED" } else { "UNEXPECTED" });
    ok
}

fn main() {
    let a = parse_args();
    let d = load(&a);
    let pass = match a.cmd.as_str() {
        "abi" => cmd_abi(&a, &d),
        "run" => cmd_run(&a, &d),
        "setup" => cmd_setup(&a, &d),
        "prove" => cmd_prove(&a, &d),
        other => panic!("unknown subcommand {other}"),
    };
    // Exit status reflects the expectations: a run with any UNEXPECTED result exits 1.
    std::process::exit(if pass { 0 } else { 1 });
}
