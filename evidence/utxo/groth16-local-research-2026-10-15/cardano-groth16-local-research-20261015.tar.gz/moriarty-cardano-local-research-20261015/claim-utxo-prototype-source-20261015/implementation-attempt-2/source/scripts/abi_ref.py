#!/usr/bin/env python3
"""Independent stdlib-only reference for MRG16-PVC ABI v0 (PROPOSED).

Re-implements, without sharing code with x7 or Aiken: the flat statement
MRG16-PVC-STMT-0, the Plutus Data CBOR of EnvV0/OutputReference/ThreadDatum,
mori-snapshot-bytes/v0 and mori-effects-bytes/v0, and the native `pay` model.

Usage: python3 -I abi_ref.py --catalogue DIR [--compare X7_ABI_RESULTS_JSON]
Prints a JSON document; with --compare, exits 1 on any byte mismatch.
"""
import argparse
import hashlib
import json
import sys

TAG = b"MRG16-PVC-STMT-0"
FAMILY = b"MRG16-PVC-FAM0-G16-BLS-ARK04-HL2"
PAYER0 = 10**15
AMOUNT = 10**6
U128 = 2**128


def b2b(data):
    return hashlib.blake2b(data, digest_size=32).digest()


def u16(n):
    if not 0 <= n <= 0xFFFF:
        raise ValueError("u16 out of range")
    return n.to_bytes(2, "big")


def lp(b):
    return u16(len(b)) + b


def statement(env):
    s = TAG + FAMILY + env["predicate"] + env["vk"] + bytes([env["kind"], env["setup"]])
    if env["context"]:
        txid, ix = env["outref"]
        s += b"\x01" + txid + u16(ix)
    else:
        s += b"\x00"
    t = env["transition"]
    s += b"\x00" if t is None else b"\x01" + lp(t[0]) + lp(t[1]) + lp(t[2])
    return s + lp(env["payload"])


# ---- Plutus Data CBOR: ("c", i, fields) | int | bytes | ("l", items)

def head(major, n):
    m = major << 5
    if n < 24:
        return bytes([m | n])
    for extra, width in ((24, 1), (25, 2), (26, 4), (27, 8)):
        if n < 256 ** width:
            return bytes([m | extra]) + n.to_bytes(width, "big")
    raise ValueError("bignum outside ABI v0")


def enc_list(xs):
    if not xs:
        return b"\x80"
    return b"\x9f" + b"".join(enc(x) for x in xs) + b"\xff"


def enc(d):
    if isinstance(d, bool):
        raise TypeError("encode Bool as a constructor")
    if isinstance(d, int):
        return head(0, d) if d >= 0 else head(1, -1 - d)
    if isinstance(d, (bytes, bytearray)):
        d = bytes(d)
        if len(d) <= 64:
            return head(2, len(d)) + d
        return b"\x5f" + b"".join(head(2, len(d[i:i + 64])) + d[i:i + 64] for i in range(0, len(d), 64)) + b"\xff"
    if d[0] == "l":
        return enc_list(d[1])
    _, i, fields = d
    if i < 7:
        return head(6, 121 + i) + enc_list(fields)
    if i < 128:
        return head(6, 1280 + i - 7) + enc_list(fields)
    return head(6, 102) + b"\x82" + head(0, i) + enc_list(fields)


def pbool(b):
    return ("c", 1 if b else 0, [])


def poutref(o):
    return ("c", 0, [o[0], o[1]])


def penv(env):
    t = env["transition"]
    tr = ("c", 1, []) if t is None else ("c", 0, [("c", 0, list(t))])
    return ("c", 0, [0, env["kind"], FAMILY, env["predicate"], env["vk"], env["setup"], pbool(env["context"]),
                     poutref(env["outref"]), tr, env["payload"], env["expiry"], env["refund"]])


# ---- MSB0 / MEB0

def s16(s):
    b = s.encode()
    return u16(len(b)) + b


def asset(a):
    return s16(a[0]) + s16(a[1]) + s16(a[2]) + bytes([a[3]])


def uint(v):
    if not 0 <= v < U128:
        raise ValueError("u128 out of range")
    return v.to_bytes(16, "big")


def val(v):
    return b"\x00" + uint(v) if not isinstance(v, bool) else b"\x01" + bytes([int(v)])


USD = ("local", "issuer", "usd", 2)


def snapshot(state, balances, liabilities):
    assert [k for k, _ in state] == sorted(k for k, _ in state)
    out = b"MSB0" + u16(len(state)) + b"".join(s16(k) + val(v) for k, v in state)
    out += u16(len(balances)) + b"".join(s16(acct) + asset(a) + uint(n) for acct, a, n in balances)
    return out + u16(len(liabilities)) + b"".join(s16(k) + bytes([int(p)]) + uint(n) for k, p, n in liabilities)


def pay_snapshot(v):
    return snapshot([("paid", v[0])], [("payer", USD, v[1]), ("recipient", USD, v[2]), ("sponsor", USD, v[3])], [])


def effects(es):
    out = b"MEB0" + u16(len(es))
    for e in es:
        k = e[0]
        if k == "State":
            out += b"\x00" + s16(e[1]) + val(e[2]) + val(e[3])
        elif k in ("Transfer", "Fee"):
            out += (b"\x01" if k == "Transfer" else b"\x02") + asset(e[1]) + s16(e[2]) + s16(e[3]) + uint(e[4])
        elif k == "Emit":
            out += b"\x04" + s16(e[1]) + val(e[2])
        else:
            raise ValueError(k)
    return out


def pay_effects(amount, paid0, paid1):
    return effects([("Transfer", USD, "payer", "recipient", amount), ("Fee", USD, "payer", "sponsor", 2),
                    ("State", "paid", paid0, paid1), ("Emit", "receipt", paid1)])


def pay_native(pre, amount, accepted):
    paid, payer, recip, spons = pre
    if not accepted or amount == 0:
        raise ValueError("mori::core::requires")
    out = [paid + amount, payer - amount - 2, recip + amount, spons + 2]
    if payer - amount < 0 or payer - amount - 2 < 0:
        raise ValueError("mori::core::balance")
    if any(x >= U128 for x in out):
        raise ValueError("mori::core::overflow")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--catalogue", required=True)
    ap.add_argument("--compare")
    a = ap.parse_args()
    with open(f"{a.catalogue}/P-M1.v0.json", "rb") as f:
        pm1 = b2b(f.read())

    outref = (b"\x44" * 32, 1)
    f0 = dict(kind=0, setup=0, predicate=b"\x22" * 32, vk=b"\x33" * 32, context=False, outref=outref,
              transition=None, payload=bytes.fromhex("cafe"), expiry=1000, refund=b"\x55" * 28)
    f1 = dict(f0, context=True, transition=(b"\xaa", b"\xbb", b"\xcc"), payload=b"")
    fixtures = []
    for name, env in (("F0", f0), ("F1", f1)):
        cb = enc(penv(env))
        fixtures.append({"fixture": name, "statementHex": statement(env).hex(), "envelopeCborHex": cb.hex(),
                         "assetNameHex": b2b(cb).hex()})

    pre = [0, PAYER0, 0, 0]
    post = pay_native(pre, AMOUNT, True)
    pre_b, post_b, eff_b = pay_snapshot(pre), pay_snapshot(post), pay_effects(AMOUNT, 0, post[0])
    seed = (b"\x10" * 32, 0)
    tid = b2b(enc(poutref(seed)))
    slot = ("c", 0, [pm1, b"\x33" * 32, pbool(True), pbool(True)])
    thread = ("c", 0, [0, tid, b"\xc0" * 28, ("l", [slot]), pre_b, b"\x00" * 32, 0])
    fixtures.append({"fixture": "T0", "threadIdHex": tid.hex(), "genesisRedeemerCborHex": enc(("c", 0, [poutref(seed)])).hex(),
                     "threadDatumCborHex": enc(thread).hex(), "burnRedeemerCborHex": enc(("c", 1, [])).hex()})
    m1 = dict(f0, predicate=pm1, context=True, transition=(pre_b, post_b, eff_b),
              payload=bytes.fromhex("f1f4807bc53b62e6ad8f816c44aebb92011925935a63479f4e3afa025a29e786") + b"\x01" + uint(AMOUNT))
    doc = {"fixtures": fixtures, "pay": {"preHex": pre_b.hex(), "postHex": post_b.hex(), "effectsHex": eff_b.hex(),
                                          "lens": [len(pre_b), len(post_b), len(eff_b)], "m1StatementLen": len(statement(m1))}}
    print(json.dumps(doc, indent=2))

    if a.compare:
        with open(a.compare) as f:
            x7 = json.load(f)
        bad = []
        theirs = {fx["fixture"]: fx for fx in x7["fixtures"]}
        for fx in fixtures:
            for k, v in fx.items():
                if theirs.get(fx["fixture"], {}).get(k) != v:
                    bad.append(f"{fx['fixture']}.{k}")
        enc_obs = next(r["observed"] for r in x7["results"] if r["id"] == "E-X7-1.oracle-encodings")
        for k in ("preHex", "postHex", "effectsHex"):
            if enc_obs[k] != doc["pay"][k]:
                bad.append(f"pay.{k}")
        if x7["rows"]["M1"]["statementHex"] and len(bytes.fromhex(x7["rows"]["M1"]["statementHex"])) != doc["pay"]["m1StatementLen"]:
            bad.append("M1 statement length")
        print(json.dumps({"compare": a.compare, "mismatches": bad}), file=sys.stderr)
        sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
