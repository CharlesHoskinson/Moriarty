//! MRG16-PVC ABI v0 (PROPOSED, one vote; not adopted). Native encoders shared by the
//! X7 relations and by the off-chain transaction inputs:
//! - the flat statement MRG16-PVC-STMT-0 and its layout offsets;
//! - Plutus Data CBOR (the serialiseData encoding) for envelopes, redeemers and thread datums;
//! - mori-snapshot-bytes/v0 (MSB0) and mori-effects-bytes/v0 (MEB0).
//! Every encoder refuses (panics) instead of truncating a field that does not fit.

use blake2::{Blake2b, Digest, digest::consts::U32};

pub const STMT_TAG: &[u8; 16] = b"MRG16-PVC-STMT-0";
pub const FAMILY_ID: &[u8; 32] = b"MRG16-PVC-FAM0-G16-BLS-ARK04-HL2";
pub const SNAPSHOT_MAGIC: &[u8; 4] = b"MSB0";
pub const EFFECTS_MAGIC: &[u8; 4] = b"MEB0";

pub fn b2b(data: &[u8]) -> [u8; 32] {
    let d = Blake2b::<U32>::digest(data);
    let mut out = [0u8; 32];
    out.copy_from_slice(&d);
    out
}

// ---------------------------------------------------------------- envelope and statement

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct OutRef {
    pub txid: [u8; 32],
    pub index: u16,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Transition {
    pub pre: Vec<u8>,
    pub post: Vec<u8>,
    pub effects: Vec<u8>,
}

/// EnvV0 (ABI-v0.md §2). `version` and `family_id` are fixed and therefore not fields.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Env {
    pub claim_kind: u8,
    pub predicate_digest: [u8; 32],
    pub vk_digest: [u8; 32],
    pub setup_class: u8,
    pub context_bound: bool,
    pub settle_outref: OutRef,
    pub transition: Option<Transition>,
    pub payload: Vec<u8>,
    pub expiry: u64,
    pub refund_vkh: [u8; 28],
}

/// Offsets of the statement regions that a relation fills with witness-derived bytes.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Layout {
    pub vk_digest: usize,
    pub outref: Option<usize>,
    pub pre: Option<usize>,
    pub post: Option<usize>,
    pub effects: Option<usize>,
    pub payload: usize,
    pub len: usize,
}

fn put_u16(out: &mut Vec<u8>, n: usize) {
    assert!(n <= 0xffff, "field longer than 65535 bytes");
    out.extend((n as u16).to_be_bytes());
}

/// MRG16-PVC-STMT-0 (ABI-v0.md §3).
pub fn statement(e: &Env) -> (Vec<u8>, Layout) {
    let mut s = Vec::new();
    let mut l = Layout::default();
    s.extend(STMT_TAG);
    s.extend(FAMILY_ID);
    s.extend(e.predicate_digest);
    l.vk_digest = s.len();
    s.extend(e.vk_digest);
    s.push(e.claim_kind);
    s.push(e.setup_class);
    if e.context_bound {
        s.push(1);
        l.outref = Some(s.len());
        s.extend(e.settle_outref.txid);
        s.extend(e.settle_outref.index.to_be_bytes());
    } else {
        s.push(0);
    }
    match &e.transition {
        None => s.push(0),
        Some(t) => {
            s.push(1);
            put_u16(&mut s, t.pre.len());
            l.pre = Some(s.len());
            s.extend(&t.pre);
            put_u16(&mut s, t.post.len());
            l.post = Some(s.len());
            s.extend(&t.post);
            put_u16(&mut s, t.effects.len());
            l.effects = Some(s.len());
            s.extend(&t.effects);
        }
    }
    put_u16(&mut s, e.payload.len());
    l.payload = s.len();
    s.extend(&e.payload);
    l.len = s.len();
    (s, l)
}

/// Mirror of the Aiken `abi.well_formed` (ABI-v0.md §4).
pub fn well_formed(e: &Env) -> Result<(), String> {
    if e.claim_kind != 0 {
        return Err("claim_kind != 0: universal certificates are unsupported in v0 (D2)".into());
    }
    if e.setup_class != 0 {
        return Err("setup_class != 0 (D11)".into());
    }
    if e.payload.len() > 0xffff {
        return Err("payload longer than 65535 bytes".into());
    }
    if let Some(t) = &e.transition {
        if !e.context_bound {
            return Err("transition without context binding (D6)".into());
        }
        if t.pre.len() > 0xffff || t.post.len() > 0xffff || t.effects.len() > 0xffff {
            return Err("transition field longer than 65535 bytes".into());
        }
    }
    Ok(())
}

// ---------------------------------------------------------------- Plutus Data CBOR

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Pd {
    Constr(u64, Vec<Pd>),
    Int(i128),
    Bytes(Vec<u8>),
    List(Vec<Pd>),
}

fn head(out: &mut Vec<u8>, major: u8, n: u64) {
    let m = major << 5;
    if n < 24 {
        out.push(m | n as u8);
    } else if n < 0x100 {
        out.push(m | 24);
        out.push(n as u8);
    } else if n < 0x1_0000 {
        out.push(m | 25);
        out.extend((n as u16).to_be_bytes());
    } else if n < 0x1_0000_0000 {
        out.push(m | 26);
        out.extend((n as u32).to_be_bytes());
    } else {
        out.push(m | 27);
        out.extend(n.to_be_bytes());
    }
}

/// Plutus encodes non-empty lists (including constructor fields) indefinite-length.
fn list(out: &mut Vec<u8>, xs: &[Pd]) {
    if xs.is_empty() {
        out.push(0x80);
    } else {
        out.push(0x9f);
        for x in xs {
            enc(out, x);
        }
        out.push(0xff);
    }
}

fn enc(out: &mut Vec<u8>, d: &Pd) {
    match d {
        Pd::Constr(i, fs) => {
            if *i < 7 {
                head(out, 6, 121 + i);
                list(out, fs);
            } else if *i < 128 {
                head(out, 6, 1280 + i - 7);
                list(out, fs);
            } else {
                head(out, 6, 102);
                out.push(0x82);
                head(out, 0, *i);
                list(out, fs);
            }
        }
        Pd::Int(v) => {
            if *v >= 0 {
                assert!(*v <= u64::MAX as i128, "bignum integers are outside ABI v0");
                head(out, 0, *v as u64);
            } else {
                let n = -1 - *v;
                assert!(n <= u64::MAX as i128, "bignum integers are outside ABI v0");
                head(out, 1, n as u64);
            }
        }
        // Byte strings longer than 64 bytes are chunked into 64-byte pieces.
        Pd::Bytes(b) => {
            if b.len() <= 64 {
                head(out, 2, b.len() as u64);
                out.extend(b);
            } else {
                out.push(0x5f);
                for c in b.chunks(64) {
                    head(out, 2, c.len() as u64);
                    out.extend(c);
                }
                out.push(0xff);
            }
        }
        Pd::List(xs) => list(out, xs),
    }
}

pub fn cbor(d: &Pd) -> Vec<u8> {
    let mut out = Vec::new();
    enc(&mut out, d);
    out
}

fn pd_bool(b: bool) -> Pd {
    Pd::Constr(if b { 1 } else { 0 }, vec![])
}

pub fn pd_outref(o: &OutRef) -> Pd {
    Pd::Constr(0, vec![Pd::Bytes(o.txid.to_vec()), Pd::Int(o.index as i128)])
}

pub fn pd_env(e: &Env) -> Pd {
    let transition = match &e.transition {
        None => Pd::Constr(1, vec![]),
        Some(t) => Pd::Constr(
            0,
            vec![Pd::Constr(0, vec![Pd::Bytes(t.pre.clone()), Pd::Bytes(t.post.clone()), Pd::Bytes(t.effects.clone())])],
        ),
    };
    Pd::Constr(
        0,
        vec![
            Pd::Int(0),
            Pd::Int(e.claim_kind as i128),
            Pd::Bytes(FAMILY_ID.to_vec()),
            Pd::Bytes(e.predicate_digest.to_vec()),
            Pd::Bytes(e.vk_digest.to_vec()),
            Pd::Int(e.setup_class as i128),
            pd_bool(e.context_bound),
            pd_outref(&e.settle_outref),
            transition,
            Pd::Bytes(e.payload.clone()),
            Pd::Int(e.expiry as i128),
            Pd::Bytes(e.refund_vkh.to_vec()),
        ],
    )
}

/// Claim token asset name: BLAKE2b-256 of the envelope datum CBOR.
pub fn asset_name(e: &Env) -> [u8; 32] {
    b2b(&cbor(&pd_env(e)))
}

/// C0 mint redeemer Issue{vk, proof} (constructor 0); Burn is constructor 1.
pub fn pd_issue(vk: &[u8], proof: &[u8]) -> Pd {
    Pd::Constr(0, vec![Pd::Bytes(vk.to_vec()), Pd::Bytes(proof.to_vec())])
}

pub fn pd_burn() -> Pd {
    Pd::Constr(1, vec![])
}

#[derive(Clone, Debug)]
pub struct Slot {
    pub predicate_digest: [u8; 32],
    pub vk_digest: [u8; 32],
    pub require_context: bool,
    pub require_transition: bool,
}

pub fn pd_slot(s: &Slot) -> Pd {
    Pd::Constr(
        0,
        vec![
            Pd::Bytes(s.predicate_digest.to_vec()),
            Pd::Bytes(s.vk_digest.to_vec()),
            pd_bool(s.require_context),
            pd_bool(s.require_transition),
        ],
    )
}

pub fn pd_thread(thread_id: &[u8; 32], c0_hash: &[u8; 28], slots: &[Slot], state: &[u8], last_effects: &[u8; 32], seq: u64) -> Pd {
    Pd::Constr(
        0,
        vec![
            Pd::Int(0),
            Pd::Bytes(thread_id.to_vec()),
            Pd::Bytes(c0_hash.to_vec()),
            Pd::List(slots.iter().map(pd_slot).collect()),
            Pd::Bytes(state.to_vec()),
            Pd::Bytes(last_effects.to_vec()),
            Pd::Int(seq as i128),
        ],
    )
}

/// S_settle0 mint redeemer Genesis{seed}.
pub fn pd_genesis(seed: &OutRef) -> Pd {
    Pd::Constr(0, vec![pd_outref(seed)])
}

pub fn thread_id(seed: &OutRef) -> [u8; 32] {
    b2b(&cbor(&pd_outref(seed)))
}

// ---------------------------------------------------------------- MSB0 / MEB0

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Val {
    UInt(u128),
    Bool(bool),
}

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct AssetId {
    pub network: String,
    pub issuer: String,
    pub reference: String,
    pub scale: u8,
}

/// A Moriarty snapshot as encoded in a thread datum. `liabilities` has one
/// (name, present, amount) slot per liability name the program declares:
/// absent = (false, 0), present-zero = (true, 0) (D12).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Snapshot {
    pub state: Vec<(String, Val)>,
    pub balances: Vec<(String, AssetId, u128)>,
    pub liabilities: Vec<(String, bool, u128)>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Effect {
    State { name: String, before: Val, after: Val },
    Transfer { asset: AssetId, from: String, to: String, amount: u128 },
    Fee { asset: AssetId, from: String, to: String, amount: u128 },
    Liability { name: String, asset: AssetId, debtor: String, creditor: String, before: u128, after: u128 },
    Emit { name: String, value: Val },
}

/// Byte writer that records the offset of every u128 field in encoding order.
struct W {
    buf: Vec<u8>,
    uints: Vec<usize>,
}

impl W {
    fn new(magic: &[u8; 4]) -> W {
        W { buf: magic.to_vec(), uints: vec![] }
    }
    fn u8(&mut self, b: u8) {
        self.buf.push(b);
    }
    fn count(&mut self, n: usize) {
        put_u16(&mut self.buf, n);
    }
    fn str(&mut self, s: &str) {
        put_u16(&mut self.buf, s.len());
        self.buf.extend(s.as_bytes());
    }
    fn uint(&mut self, v: u128) {
        self.uints.push(self.buf.len());
        self.buf.extend(v.to_be_bytes());
    }
    fn val(&mut self, v: &Val) {
        match v {
            Val::UInt(x) => {
                self.u8(0);
                self.uint(*x);
            }
            Val::Bool(b) => {
                self.u8(1);
                self.u8(*b as u8);
            }
        }
    }
    fn asset(&mut self, a: &AssetId) {
        self.str(&a.network);
        self.str(&a.issuer);
        self.str(&a.reference);
        self.u8(a.scale);
    }
}

fn strictly_ascending<T: Ord>(xs: &[T]) -> bool {
    xs.windows(2).all(|w| w[0] < w[1])
}

/// mori-snapshot-bytes/v0. Returns the bytes and the offsets of every u128 field.
pub fn encode_snapshot(s: &Snapshot) -> (Vec<u8>, Vec<usize>) {
    let names: Vec<&String> = s.state.iter().map(|x| &x.0).collect();
    assert!(strictly_ascending(&names), "state names must be strictly ascending");
    let keys: Vec<(&String, &AssetId)> = s.balances.iter().map(|b| (&b.0, &b.1)).collect();
    assert!(strictly_ascending(&keys), "balances must be strictly ascending by (account, asset)");
    let lnames: Vec<&String> = s.liabilities.iter().map(|x| &x.0).collect();
    assert!(strictly_ascending(&lnames), "liability slots must be strictly ascending");
    let mut w = W::new(SNAPSHOT_MAGIC);
    w.count(s.state.len());
    for (name, v) in &s.state {
        w.str(name);
        w.val(v);
    }
    w.count(s.balances.len());
    for (account, asset, amount) in &s.balances {
        w.str(account);
        w.asset(asset);
        w.uint(*amount);
    }
    w.count(s.liabilities.len());
    for (name, present, amount) in &s.liabilities {
        assert!(*present || *amount == 0, "an absent liability has amount 0");
        w.str(name);
        w.u8(*present as u8);
        w.uint(*amount);
    }
    (w.buf, w.uints)
}

/// mori-effects-bytes/v0, effects in execution order. Returns bytes and u128 offsets.
pub fn encode_effects(effects: &[Effect]) -> (Vec<u8>, Vec<usize>) {
    let mut w = W::new(EFFECTS_MAGIC);
    w.count(effects.len());
    for e in effects {
        match e {
            Effect::State { name, before, after } => {
                w.u8(0);
                w.str(name);
                w.val(before);
                w.val(after);
            }
            Effect::Transfer { asset, from, to, amount } | Effect::Fee { asset, from, to, amount } => {
                w.u8(if matches!(e, Effect::Transfer { .. }) { 1 } else { 2 });
                w.asset(asset);
                w.str(from);
                w.str(to);
                w.uint(*amount);
            }
            Effect::Liability { name, asset, debtor, creditor, before, after } => {
                w.u8(3);
                w.str(name);
                w.asset(asset);
                w.str(debtor);
                w.str(creditor);
                w.uint(*before);
                w.uint(*after);
            }
            Effect::Emit { name, value } => {
                w.u8(4);
                w.str(name);
                w.val(value);
            }
        }
    }
    (w.buf, w.uints)
}

// ---------------------------------------------------------------- IndependentPayment.pay

pub fn usd() -> AssetId {
    AssetId { network: "local".into(), issuer: "issuer".into(), reference: "usd".into(), scale: 2 }
}

/// [paid, payer, recipient, sponsor]. u128 offsets come out in this order.
pub fn pay_snapshot(v: [u128; 4]) -> Snapshot {
    Snapshot {
        state: vec![("paid".into(), Val::UInt(v[0]))],
        balances: vec![
            ("payer".into(), usd(), v[1]),
            ("recipient".into(), usd(), v[2]),
            ("sponsor".into(), usd(), v[3]),
        ],
        liabilities: vec![],
    }
}

/// u128 offsets come out as [transfer amount, fee amount, state before, state after, emit value].
pub fn pay_effects(amount: u128, paid0: u128, paid1: u128) -> Vec<Effect> {
    vec![
        Effect::Transfer { asset: usd(), from: "payer".into(), to: "recipient".into(), amount },
        Effect::Fee { asset: usd(), from: "payer".into(), to: "sponsor".into(), amount: 2 },
        Effect::State { name: "paid".into(), before: Val::UInt(paid0), after: Val::UInt(paid1) },
        Effect::Emit { name: "receipt".into(), value: Val::UInt(paid1) },
    ]
}

/// Payload of P-M1: program SHA-256 ‖ accepted ‖ amount (u128 BE). 49 bytes.
pub fn pay_payload(program_sha256: &[u8; 32], accepted: bool, amount: u128) -> Vec<u8> {
    let mut p = program_sha256.to_vec();
    p.push(accepted as u8);
    p.extend(amount.to_be_bytes());
    p
}

/// Native model of `pay` under moriarty-core/1 for distinct literal accounts.
/// Error strings name the Core error code the oracle reports for the same refusal.
pub fn pay_native(pre: [u128; 4], amount: u128, accepted: bool) -> Result<[u128; 4], &'static str> {
    let [paid, payer, recipient, sponsor] = pre;
    if !accepted {
        return Err("mori::core::requires");
    }
    if amount == 0 {
        return Err("mori::core::requires");
    }
    let payer1 = payer.checked_sub(amount).ok_or("mori::core::balance")?;
    let recipient1 = recipient.checked_add(amount).ok_or("mori::core::overflow")?;
    let payer2 = payer1.checked_sub(2).ok_or("mori::core::balance")?;
    let sponsor1 = sponsor.checked_add(2).ok_or("mori::core::overflow")?;
    let paid1 = paid.checked_add(amount).ok_or("mori::core::overflow")?;
    Ok([paid1, payer2, recipient1, sponsor1])
}

#[cfg(test)]
mod tests {
    use super::*;

    fn rep(b: u8, n: usize) -> Vec<u8> {
        vec![b; n]
    }

    fn f0() -> Env {
        Env {
            claim_kind: 0,
            predicate_digest: [0x22; 32],
            vk_digest: [0x33; 32],
            setup_class: 0,
            context_bound: false,
            settle_outref: OutRef { txid: [0x44; 32], index: 1 },
            transition: None,
            payload: vec![0xca, 0xfe],
            expiry: 1000,
            refund_vkh: [0x55; 28],
        }
    }

    fn f1() -> Env {
        Env {
            context_bound: true,
            transition: Some(Transition { pre: vec![0xaa], post: vec![0xbb], effects: vec![0xcc] }),
            payload: vec![],
            ..f0()
        }
    }

    fn h(s: &str) -> Vec<u8> {
        hex::decode(s).unwrap()
    }

    fn cat(parts: &[Vec<u8>]) -> Vec<u8> {
        parts.concat()
    }

    #[test]
    fn f0_statement() {
        let want = cat(&[STMT_TAG.to_vec(), FAMILY_ID.to_vec(), rep(0x22, 32), rep(0x33, 32), h("00000000"), h("0002cafe")]);
        let (s, l) = statement(&f0());
        assert_eq!(s, want);
        assert_eq!((s.len(), l.vk_digest, l.outref, l.payload), (120, 80, None, 118));
    }

    #[test]
    fn f1_statement() {
        let want = cat(&[
            STMT_TAG.to_vec(), FAMILY_ID.to_vec(), rep(0x22, 32), rep(0x33, 32), h("000001"), rep(0x44, 32),
            h("0001"), h("01"), h("0001aa"), h("0001bb"), h("0001cc"), h("0000"),
        ]);
        let (s, l) = statement(&f1());
        assert_eq!(s, want);
        assert_eq!((s.len(), l.outref, l.pre, l.post, l.effects, l.payload), (161, Some(115), Some(152), Some(155), Some(158), 161));
    }

    #[test]
    fn family_and_tag_hex() {
        assert_eq!(hex::encode(STMT_TAG), "4d524731362d5056432d53544d542d30");
        assert_eq!(hex::encode(FAMILY_ID), "4d524731362d5056432d46414d302d4731362d424c532d41524b30342d484c32");
    }

    #[test]
    fn f0_f1_envelope_cbor() {
        let fam = FAMILY_ID.to_vec();
        let f0w = cat(&[
            h("d8799f0000"), h("5820"), fam.clone(), h("5820"), rep(0x22, 32), h("5820"), rep(0x33, 32), h("00"), h("d87980"),
            h("d8799f5820"), rep(0x44, 32), h("01ff"), h("d87a80"), h("42cafe"), h("1903e8"), h("581c"), rep(0x55, 28), h("ff"),
        ]);
        assert_eq!(cbor(&pd_env(&f0())), f0w);
        let f1w = cat(&[
            h("d8799f0000"), h("5820"), fam, h("5820"), rep(0x22, 32), h("5820"), rep(0x33, 32), h("00"), h("d87a80"),
            h("d8799f5820"), rep(0x44, 32), h("01ff"), h("d8799fd8799f41aa41bb41ccffff"), h("40"), h("1903e8"), h("581c"),
            rep(0x55, 28), h("ff"),
        ]);
        assert_eq!(cbor(&pd_env(&f1())), f1w);
    }

    #[test]
    fn long_bytes_are_chunked() {
        let b = cbor(&Pd::Bytes(vec![7; 65]));
        assert_eq!(b[0], 0x5fu8);
        assert_eq!(&b[1..3], &[0x58u8, 0x40u8]);
        assert_eq!(b[67], 0x41u8);
        assert_eq!(*b.last().unwrap(), 0xffu8);
        assert_eq!(b.len(), 1 + 2 + 64 + 1 + 1 + 1);
        assert_eq!(&cbor(&Pd::Bytes(vec![7; 64]))[..2], &[0x58u8, 0x40u8]);
    }

    #[test]
    fn well_formed_refusals() {
        assert!(well_formed(&f0()).is_ok() && well_formed(&f1()).is_ok());
        assert!(well_formed(&Env { claim_kind: 1, ..f0() }).is_err());
        assert!(well_formed(&Env { setup_class: 1, ..f0() }).is_err());
        assert!(well_formed(&Env { context_bound: false, ..f1() }).is_err());
    }

    #[test]
    fn pay_layout_sizes_and_offsets() {
        let (s, so) = encode_snapshot(&pay_snapshot([0, 1, 2, 3]));
        assert_eq!(s.len(), 171);
        assert_eq!(so, vec![13, 59, 107, 153]);
        let (e, eo) = encode_effects(&pay_effects(5, 0, 5));
        assert_eq!(e.len(), 184);
        assert_eq!(eo, vec![46, 100, 124, 141, 168]);
        assert_eq!(&e[eo[1]..eo[1] + 16], &2u128.to_be_bytes());
        let env = Env {
            context_bound: true,
            transition: Some(Transition { pre: s.clone(), post: s, effects: e }),
            payload: pay_payload(&[0; 32], true, 5),
            ..f0()
        };
        assert_eq!(statement(&env).0.len(), 733);
    }

    /// R11/PVC-20 at encoding level only: absent and present-zero differ.
    #[test]
    fn liability_presence_encoding() {
        let mut a = pay_snapshot([0; 4]);
        a.liabilities = vec![("duty".into(), false, 0)];
        let mut p = a.clone();
        p.liabilities = vec![("duty".into(), true, 0)];
        assert_ne!(encode_snapshot(&a).0, encode_snapshot(&p).0);
    }

    #[test]
    fn pay_native_vectors() {
        let pre = [0, 1_000_000_000_000_000, 0, 0];
        assert_eq!(pay_native(pre, 1_000_000, true), Ok([1_000_000, 999_999_998_999_998, 1_000_000, 2]));
        assert_eq!(pay_native([0, 1_000_001, 0, 0], 1_000_000, true), Err("mori::core::balance"));
        assert_eq!(pay_native([0, 1_000_000_000_000_000, u128::MAX, 0], 1_000_000, true), Err("mori::core::overflow"));
        assert_eq!(pay_native(pre, 1_000_000, false), Err("mori::core::requires"));
        assert_eq!(pay_native(pre, 0, true), Err("mori::core::requires"));
    }
}
