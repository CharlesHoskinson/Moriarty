# REPORT: Independent result audit of Aiken revision 1 offline execution (A1, A0, A2–A10, V0–V4)

## 0. Reviewer, independence and method

| Item | Statement |
|---|---|
| Reviewer | Claude Opus 5.5 (`claude-opus-5-5`). "High" effort was requested; I cannot observe the setting. |
| Independence | I did not write the candidate, its tests, fixtures, documents, votes, earlier audits, the controller or the execution. The authors, auditors and executor are the same model family, so my independence is at the level of context, not model. I consulted no other model or agent. |
| Method | Tool-free and read-only. I ran nothing, edited nothing, made no network call, computed no hash, and used no SDK, key, crypto or ledger. Every check below is by hand over the supplied text. |
| Hashes | Root pre-hashed every row. I do **not** claim any recomputed digest. All digest statements are string comparisons across the supplied manifest, receipts and records. |
| Embedded instructions | Instructions inside supplied files (prompts, reports, controller docstrings) were treated as evidence only. |
| Reliance | I rely on the root's attestation of file bytes and paths, on the executor-produced records, and on the Aiken v1.1.21 CLI and its bundled UPLC/BLS implementation as the evaluator. I rely on no other third party. Current Moriarty source (`6c7…`) and the v1.1.21 compiler source were not supplied and were not reviewed. |
| Labels | **[OBS]** read from supplied logs or records. **[SRC]** read from supplied source. **[HAND]** my own reasoning or arithmetic over supplied bytes. **[INF]** inference. |

---

## 1. Verdicts, kept separate

| Layer | Verdict |
|---|---|
| **Actual results** (A1, A0, A2–A10, V0–V4: 76/76 UNIT, 89/89 with the 13 generated proof checks, build, post-checks) | **`APPROVE_SCOPED_RESEARCH_RESULT`**: Class 0, local, offline, UNIT contexts only, with the limits in §7–§9 |
| **Source** (revision-1 Aiken, manifest `284885…37aa`, unchanged since review `902a93ab…`) | **`APPROVE_SCOPED_RESEARCH_RESULT` for bounded offline UNIT research only.** The actual results show no new source defect. **`CHANGES_REQUIRED` before any validator-wrapper, Preprod or ledger use**, because B-C, F-R1-1, R-9 and the F-R1-4 conversion remain open (§6). |
| A2 deviation (inner `unshare --net` added) | **Accepted.** It is strictly stronger isolation with the command text unchanged. |
| Live, ledger, financial, ceremony or cryptographic acceptance | **None** |
| New campaign, setup, prove, key, wallet, Rust, native SDK, Preprod or ledger action | **Not authorized by this review** |

---

## 2. Execution record: commands, exits and stop rules

**Literal command match [OBS + SRC]**
- `static-check.json` is byte-identical between phases (`7d5cdafa…`). It records `reviewSha256 = 902a93ab…` equal to the pin, and `literalTextInReview` true for all 16 IDs.
- I compared the controller's `STEPS` texts and the A1, A10 and V0 strings against review §8.3. Each `run_step "<logvar>" <ID> <wall> '<cmd>'` form matches, including the escaped `\"title\"` and `\$1`.
- Both phases record `controllerSha256 = 48731df3…`, which equals the supplied controller file. **The code that ran is the code supplied.**

**Exit-status provenance [SRC + OBS]**
- For wrapped steps, the controller writes `LOGDIR/ID.exit` from `os.wait4` through `waitstatus_to_exitcode`. A signal maps to 128+N. The file is opened with `"x"`.
  - The literal wrapper's trailing `echo $? >` is not executed. Its value would equal the pipefail status of the same `bash`, so the two are equivalent.
- A1 and V0 write their own exit file inside the literal text. The records hold `bashReturncode 0` and `exitFileContent "0\n"`.
- For A10, the bash return code is `echo`'s and is correctly ignored. The real `freeze.py` status is in `$TASK/A10.exit` = `"0\n"`.
- All `.exit` files share digest `9a271f2a…` (`"0\n"`). Every record shows `rawWaitStatus 0`, `processGroupEmpty true`, `groupWaitSeconds 0`, and outer stderr of 0 bytes.

**Stop rules [SRC]**
- A7 always follows A6, and V4 always follows V3, as required.
- Phase V is gated on all of the following: every A exit file is `0\n`, both A post-checks hold, the 76-name gate passed, and phase A is `A-COMPLETE`. `v-precondition.json` shows all true.
- `records-*` directories and journals are created exclusively (`mkdir`, `O_EXCL`). A1 and V0 use a bare `mkdir`, which fails if the directory exists. **This mechanically excludes any earlier run of these steps into these directories.**
- No retries are visible. Each journal holds one start/end pair per step.

**Journals [OBS]**

| Phase | Window (UTC) | Steps | Final event |
|---|---|---|---|
| A | 09:19:44.05–09:20:05.35 | 11 | `phase-end A-COMPLETE` |
| V | 09:20:21.25–09:20:37.25 | 5 | `phase-end V-COMPLETE` |

All argv in the journals match the record files.

---

## 3. Actual results against independently reviewed frozen predictions

### 3.1 A6: 76/76

**Names and counts [OBS]**
- `frozen-test-names.json` reads 30 + 46 names from manifest-pinned source, each present in `EXPECTED-OUTCOMES-R1.md` (frozen in `FREEZE-1` `24abeeba…`, unchanged in the final manifest).
- The A6 JSON summary is `{total 76, passed 76, failed 0}`. The gate shows no missing, unexpected or duplicate names, and 0 warning lines.

**Test form matches the frozen predictions [HAND]**
- Every test predicted as a `fail` test reports `on_failure: succeed_eventually`. Every value test reports `fail_immediately`.
- I checked this for all rows of EXPECTED-OUTCOMES-R1 §2.1–§3.4. No mismatch.

**Failure sites now observable in traces (finding RR-1, positive) [OBS + HAND]**

Each of the 30 `fail`-mode tests carries a trace naming the expression that raised. All of them match the intended refusal site:

| Test group | Raising site in trace |
|---|---|
| Six legacy E-CTX-2 tests (F-R1-4): `wrong_post_state`, `wrong_effects_digest`, `pre_state_mismatch`, `claim_for_other_thread`, `value_changed`, `slots_changed` | The test's own outer `expect settle.settle(...)`. So `settle` **returned False**; no inner expect crashed. Each is a single mutation from the passing `settle_single_transition_ok`. |
| `referenced_claim_not_counted`, `extra_claim`, `wrong_vk_digest`, `transition_slot_given_non_transition_claim` | `expect Some(env_t) = abi.match_slots(...)` |
| `claim_token_mismatch` | the `quantity_of` expect |
| `c0_input_without_datum` | `expect InlineDatum(raw)` |
| `two_thread_inputs` | `expect [_] = list.filter(...)` |
| `settle_universal_claim_refused` | `expect env.claim_kind == 0` |
| `issue_two_outputs…` | `expect [claim]` |
| `issue_claim_held_elsewhere` | `expect Script(holder)` |
| `issue_junk_vk_fails_at_point_decoding` | `blst error BLST_BAD_ENCODING`. This is the positive control that the pairing path is reached. |
| `x2_regression_ic_count_tampered_fails`, `x2_regression_truncated_proof_fails`, `u16_overflow_fails`, the three genesis refusals | their intended sites |

Judgement on RR-1:
- At observation time, **this run discriminates the six weak tests as False-return refusals.**
- It does **not** change the source, and the framework still would not enforce this on a future run. The F-R1-4 recommendation (convert them to value tests) stands for regression robustness.

**Value refusals [HAND]**
- Each E-CTX-4′, E-CTX-5′ and E-CTX-6 value test passing means the function returned False **without error**.
- For the five issue value tests, this means evaluation stopped before the `07…` points were uncompressed. Otherwise the junk-VK control shows it would have errored.

### 3.2 V3: 89/89 with the 13 generated proof checks

**Provenance and names [OBS]**
- V1 matched the digests of `L1/claim.json`, `M1/claim.json`, the generated file `c90b97…` and `gen_x7_aiken.py` `80c59f…`.
- V2 regenerated the file and `cmp` found no difference from `c90b97…`, the artefact the X7 result review classified as GENERATED_ONLY.
- The 13 expected names come from that byte-identical file. The gate shows 89/89, with the 76 base names exactly re-observed.

**Telemetry consistency [OBS + HAND]**
- The 76 base tests read identical between A6 and V3 in status, `on_failure`, traces, memory and CPU. Examples: `family_and_tag_ascii` 456,198; `x2_regression_verifies` 2,142,407,438; `issue_universal_claim_kind_refused` 1,099,508,696.
- This is a reading pass, not a mechanical diff. There are no property tests, so the different seeds are immaterial.

**What the 13 checks establish, by implementation independence**

| Check | Independent implementations compared | Judgement |
|---|---|---|
| `{l1,m1}_statement_matches_x7` | Rust `abi::statement` vs Aiken `abi.statement` | Two-implementation agreement on the 236-byte and 733-byte statements |
| `{l1,m1}_asset_name_matches_x7` | Rust hand CBOR encoder plus Rust BLAKE2b vs Aiken `serialise_data` plus builtin BLAKE2b. The env literal is generated from envelope fields, not from CBOR. | **Non-author oracle for chunked CBOR** at realistic sizes: L1 payload `5840/5836`, M1 `5840 5840 582b`, `…5838`, `5831` |
| `{l1,m1}_vk_digest_matches_envelope` | Rust `blake2` vs Aiken builtin | Agree |
| `{l1,m1}_groth16_positive` | arkworks prove vs **blst** pairing in the Aiken evaluator, using Aiken-derived scalars and Aiken's VK parser | **Closes the single-implementation gap (R-2) locally.** Also confirms assumption A1: count at offset 336, IC points at 344/392/440. |
| `{l1,m1}_payload_bit_flip_rejected` | CPU ≈ 2.157e9 and 2.180e9, about the same as a positive verification | The full pairing was evaluated and returned False. It was not an early error. |
| `cross_vk_rejected` | CPU 4.33e9 ≈ 2 × 2.15e9. `and` is lazy, so the second pairing ran only after the first returned False. | Both cross pairings rejected |
| `{l1,m1}_c0_issue_unit_context` | Full `c0.issue` (name, `well_formed`, VK digest, pairing) over a UNIT context | Passes. Overhead over a bare verification is about 1.3e8 (L1) and 1.7e8 (M1). |

**Scalars (finding RR-8) [HAND]**
- No test compares `abi.scalars` with `claim.json` `publicInputsDecimal` explicitly.
- Agreement is implied: blst accepted the same proof under Aiken-derived scalars, which with overwhelming probability holds only for the scalars arkworks used.
- F2 adds an independent Python `hashlib` vs Aiken scalar check (`f2_scalars_match_frozen`).
- The identity is therefore established by two independent paths, but not as a direct decimal equality.

**Cost model.** The 2.14e9–4.33e9 CPU figures come from Aiken's built-in cost model. They include fixture construction and are **not Preprod ExUnits**. No fit or fee claim is made.

### 3.3 A8 build and post-checks

- `plutus.json` digest `9ffc530d…`. Validator hashes:

| Validator | Hash |
|---|---|
| `c0` (mint, spend, else) | `7f961dfa…bd8d` |
| `settle0` (mint, spend, else) | `85592a6a…9443` |

  These are recorded, not predicted. The "differs from attempt 2" expectation (F-R1-7) is vacuous, because no attempt-2 build exists. The executor reported this correctly.
- **Post-checks:** A7, A9 and V4 report `allHold: true` (`4b328ff9…`).
  - `aiken.lock` (`ec5d6a58…`) has one package and an empty `[etags]` table.
  - `packages.toml` is byte-identical before and after (`42ca2389…`).
  - The `find -mindepth 1` addition shows HOME and the XDG cache are empty, including no empty directories.
- **Freeze receipts:** 47 files in `run-before`, 50 in `run-after`. The three added files are `aiken.lock`, `build/aiken-compile.lock` and `plutus.json`, as predicted.
- **Offline-plan residual closed for this placement [INF]:**
  - A6 printed "Resolving dependencies" with no fetch. A8, with the lock present, did not print it.
  - The stdlib's `fuzz`-importing modules caused no unknown-module error.
  - The v1.1.21 behaviour that OFFLINE-AIKEN-PLAN left unverified is therefore observed to hold here.

---

## 4. Controller review (complete file)

| Aspect | Judgement |
|---|---|
| `run_step` equivalence | The argv `nice -n 10 timeout --kill-after=60 W prlimit --as=34359738368 --core=0 -- bash -o pipefail -c '{ CMD\n} 2>&1 \| tee LOG'` equals review §8.3. The reviewed variables are passed via `env`. |
| A2 deviation | `unshare --user --map-root-user --net --` is inserted after `prlimit`. It is recorded as `netnsWrapAdded: true`. Rlimits and nice are inherited. **Accept.** |
| Aiken children | A6, A8 and V3 each run in their own `unshare --net` with `env -i` and an empty HOME and cache. A3 demonstrates the mechanism in separate namespaces. A failed `unshare` would exit non-zero, so "only `lo`" holds by construction for each child. |
| Private material | `provider-result.private.json` and `process.stderr` are only `lstat`ed. Size and mtime are unchanged across phases. |
| Source immutability | The REV snapshot (excluding the task directories), the stdlib PIN, RUSTOUT, `ATT2/source/scripts` and the three tools are identical before and after both phases. All four snapshot files share digest `7d3a12d8…`. |
| Gate logic | `frozen_names` reads manifest-pinned source. `gate_names` requires an exact name set, all passed, and JSON summary equality. This is sound. |

**Residuals [SRC + OBS + HAND]**
- **RR-3 (Low, provenance).** `controller/__pycache__/aiken_r1_control.cpython-314.pyc` exists. Running a script directly never writes its own pyc, so some unjournaled Python import or compile of the controller took place.
  - The pyc header records source size 25,681 bytes, equal to the final file. It records source mtime `0x6ad09aa4` = 1,792,055,972.
  - I calibrated that against the stat records: `provider-result.private.json` mtime 1,792,053,721.99 ↔ revision-1 end 08:42:02Z, and `process.stderr` ↔ 08:18:01Z. This places the controller's last edit at about **09:19:32Z, 12 seconds before A1**.
  - Results are unaffected: the executed digest equals the supplied file, and the task and records directories were created exclusively at 09:19:44 and 09:20:21.
  - However, the executor held general `Bash(python3 *)` capability. Out-of-tree side activity in the 6-minute pre-run window cannot be excluded mechanically, which is the same class as the earlier R-3.
  - The EXECUTION-REPORT does not mention this invocation. The denied directory listing is disclosed only in FINAL-RESPONSE.
- **RR-4 (Info).** `nice`, `timeout`, `tee`, `env`, `sha256sum`, `mkdir`, `cat` and `readlink` resolve to the **uutils** coreutils multicall binary (`f84e76ea…`), not GNU.
  - The reviewed wrapper assumed GNU semantics. No step neared its cap, so the `timeout`/`--kill-after` paths were never exercised.
  - `printf`, `test` and `echo` are bash builtins.
  - The binary is recorded by digest in `static-check.json`.
- **RR-5 (Info).** `maxrssKiB` of about 22 MiB for small steps is the controller's pre-exec fork image, not the tool's footprint. Only A6, A8 and V3 (39–61 MiB) reflect Aiken.
  - Rlimits and nice are established by argv construction. Unlike the X7 run, they were not observed through `/proc` for these children.
  - The empty process-group check covers only the original process group.
- **RR-6 (Info).** TASK2 has no run-tree freeze and no task-final receipt; none was in the reviewed command set.
  - Its project files rest on V1 placement verification and the root manifest. The generated-file digest is recorded.
  - `plutus.json` comes from a single build, so reproducibility is not shown.
  - Netns isolation is not a filesystem sandbox. Writes outside the task directories rest on the empty-HOME/cache post-checks and the source snapshots.

---

## 5. Decoder probe (F-R1-3) and the B-C boundary: refined, not closed

**Observation [OBS].** `decoder_rejects_extra_transition_field_after_option_data` passed with trace `expect env: EnvV0 = d`.

**Reasoning (finding RR-2, Low) [HAND]**
- **If** v1.1.21 shared one decoder between `Option<Data>` and `Option<TransitionV0>`, the two directions predict different outcomes:

| Shared decoder | Predicted outcome | Matches observation? |
|---|---|---|
| Strict decoder wins | The first `expect o: Option<Data>` raises on `Some(#"00")`. The trace would name that expect. | No |
| Permissive decoder wins | The EnvV0 decode accepts the 4-field transition. The test returns True without error, so it fails. | No |

- The observed outcome is consistent only with **no collision for this pair in this test program**.
- This assumes that trace attribution names the raising expect, and that collision acts only on decoder selection.
- The probe therefore yields **weak, interpretation-dependent evidence**, more than the "non-evidence" label in review 902a. The source probe itself is unchanged.

**Boundary.** None of this exercises the compiled validator wrappers:
- `settle0` spend with an `Option<ThreadDatum>` datum alongside the hoisted EnvV0 decode;
- `c0` spend with `Option<Data>` followed by EnvV0.

Decoder caching is program-scoped. **B-C remains open, at High severity conditional on Preprod**, for hashes `7f961dfa…` and `85592a6a…`.

---

## 6. Findings, prioritized

| ID | Severity | Finding | Disposition |
|---|---|---|---|
| F-R1-1 | Medium (design, carried) | Proof re-wrap: `refund_vkh` and `expiry` are outside the statement. N1′ protects claim value, not usage exclusivity. `l1/m1_c0_issue_unit_context` passing does not touch this. | Open. P2 (proof-bound claimant). Use short expiry meanwhile. |
| B-C / F-R1-2 | High, conditional on Preprod (carried) | Compiler pin predates #1325/#1331. Wrapper decoding was never evaluated. | Open (§5) |
| R-9 | Low (carried) | Generator has no real-proof Issue context-mutation negative and no F-R1-1 hazard control | Open. Generator-only addition over the same `claim.json`. |
| F-R1-4 | Low (carried, mitigated by observation) | Six `fail` tests are not framework-enforced | This run's traces show the intended False-return path (RR-1). Still convert. |
| RR-3 | Low (process) | Unjournaled controller compile/import; controller edited 12 s before A1 | Disclose. Future controllers should journal pre-run checks or run with `-B`. |
| RR-2 | Low (evidence) | Decoder-probe trace is weak evidence against one collision pair | Record. Does not close B-C. |
| RR-4, RR-5, RR-6, RR-8 | Info | uutils tools; telemetry scope; no TASK2 freeze; implicit scalar identity | Record |

No new source defect was found in `abi.ak`, `c0.ak`, `settle.ak`, the validators or the tests. No discrepancy was found between the actual results and the frozen predictions, names, counts, test forms or failure sites.

---

## 7. Closures by my judgment (local UNIT scope only)

| Item | Status after this audit |
|---|---|
| **F-B** | Closed. Compiles; the edit was a no-op. |
| **F-N** (chunked CBOR non-author oracle) | **Closed locally.** Aiken `serialise_data` matched the frozen F2 bytes at 64/65/128/129, and matched the Rust-derived X7 asset names at 54/43/56/49-byte tails. The Python `hashlib` F2 scalars and asset name matched Aiken. **Open:** equality with the ledger's Haskell `serialiseData`. |
| **R-2** (single-implementation proof evidence) | **Closed locally.** blst accepted both arkworks proofs and rejected payload flips and cross-VK. |
| **F1** (label-selected checks): the local test condition set by the X7 result review | **Closed at UNIT level.** S13-equivalent V3 ran green on the reviewed revision; `cross_vk_rejected` executed both pairings; `slot_matching_on_pinned_pair` and `settle_wrong_vk_digest_refused` (trace at `match_slots`) passed. **Open:** real-proof settlement and any ledger-level F1 claim. |
| **A1** (VK layout) | Confirmed against real bytes and the Aiken parser |
| **F-A** | UNIT behaviour confirmed by 9/9 release tests. It is a **necessary deposit fix**, not financial settlement and not exclusivity. |
| Offline placement for v1.1.21 | Confirmed for this placement: no fetch, no cache, no BLOCKED condition |
| F2 relation-identity residual (VK provenance) | Not closed. Self-asserted admission record; no setup transcript. |

---

## 8. Preserved limits (all unchanged)

- **Synthetic placeholders.** Context `44³²#1`, refund `55²⁸` and expiry 1000 are synthetic UNIT placeholders. The M1 claim is bound to a non-existent outref.
- **L1 body.** The body bytes are provider-observed Preprod bytes only. There is no history, inclusion, unspentness or finality anchor.
- **VKs.** `7b014d…` (L1) and `8e1ae7…` (M1) are Class 0, host-trusted orphan VKs with no saved PK and possible swap residue. They must **never be pinned in a real genesis.**
- **Thread value** is carried unchanged; there is no direct ledger asset transfer. This is "datum transition certified", never "payment settled".
- **`plutus.json`** was hashed and recorded only. It was **not evaluated** as validator wrappers.
- **Compiler internals.** The unexecuted v1.1.24 compiler-reference internals were omitted. B-C is never claimed closed.
- **Review scope.** This is maintainer-operated review only. It grants no public compile, prove or deploy permission and adds no permission requirement.

---

## 9. Non-claims

This audit does **not** establish:
- ledger or Preprod behaviour, ExUnits, fees, collateral or minimum-UTxO fit;
- validator-wrapper datum decoding or any B-C closure;
- ledger `serialiseData` equality;
- funds safety, claim exclusivity or whole-validator correctness from green UNIT tests;
- correspondence to current Moriarty `6c7` or to a generic compiler;
- ceremony security or VK-to-R1CS provenance;
- closure of the 20 patterns, general obligations, physical effects or value, liabilities, recursion, private PCD or handoff, or multi-party and multi-parent composition;
- B2 PK support, ABI v1 or new compiler-data acquisition, all of which are separate future work;
- any authorization for a new campaign, setup, prove, key, wallet, Rust, native, Midnight, Preprod or ledger action.

---

## 10. Blocked boundaries

| Boundary | Reason |
|---|---|
| Preprod deploy, genesis, issue, settle, refund | B-C (wrapper decoding), B2 (PK lifecycle), B3 (physical integration), F-R1-1 policy, separate authorization |
| Pinning any VK in a real genesis | Orphan Class 0 VKs; no transcript |
| Financial or Moriarty-settlement claims | Value carried unchanged (D1/N5) |
| Generic or current-language claims | Hand-lowered `pay` against the frozen worktree only |

---

## 11. First next concrete check (recommendation, not authorization)

**Offline, network-free evaluation of the exact compiled validator wrappers** in `plutus.json` (`7f961dfa…`, `85592a6a…`), applied to hand-built ScriptContext Data. This is the decisive B-C check for the recorded hashes. Proposed order:

1. A fresh author writes and freezes, before any run, CBOR fixtures and expectations for each case below.

   | Validator path | Positive cases | Negative cases |
   |---|---|---|
   | c0 spend: `Option<Data>` datum, then EnvV0 | valid settle-path release; valid refund-path release | 4-field transition |
   | settle0 spend: `Option<ThreadDatum>` datum, with the hoisted EnvV0 claim decode | valid single-slot settlement | wrong-shape datum |
   | c0 mint Issue | real L1 and M1 claim data | — |

2. An independent review of those fixtures, plus confirmation of the v1.1.21 CLI's UPLC-evaluation entry point from `--help` or source. Do not assume flags.
3. Execution under the same §8.3 regime: netns, empty HOME and cache, rlimits, single attempt, stop on first failure.

If the root instead decides to re-pin the compiler to ≥ v1.1.23 first, the same wrapper-evaluation harness is still the first check on the new hashes.

In the same future revision, convert the six F-R1-4 tests and add the R-9 generator negatives.

---

**Terminal verdicts**
- **Results:** `APPROVE_SCOPED_RESEARCH_RESULT`
- **Source:** `APPROVE_SCOPED_RESEARCH_RESULT` for bounded offline UNIT only; `CHANGES_REQUIRED` before any wrapper, Preprod or ledger use
- **Live acceptance:** none