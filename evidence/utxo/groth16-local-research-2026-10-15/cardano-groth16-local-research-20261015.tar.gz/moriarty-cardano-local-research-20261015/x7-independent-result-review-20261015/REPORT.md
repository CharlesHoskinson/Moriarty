# Independent result review: X7 Rust execution `rust-research-execution-1` / attempt-1

**Terminal verdicts (kept separate):**

| Layer | Verdict |
|---|---|
| Actual results: S0, S0b, S1, NS-probe, S2, S3, S4, S5, S6, S7, S10, S11, S12 (redirected), S14-verify | **`APPROVE_SCOPED_RESEARCH_RESULT`**: Class 0, local, bytes plus arithmetic only, with the caveats in §6–§9 |
| Source: Rust x7 subtree, catalogue, `abi_ref.py`, `gen_x7_aiken.py` (freeze `78beca9c…`, unchanged) | **`ACCEPT_SCOPED_LOCAL_RESEARCH`**. No new Rust defect found. |
| Source: Aiken subtree | **`CHANGES_REQUIRED`**: F-B before S8/S13. F-A before any Preprod. New design finding R-1 must be dispositioned before F-A is treated as sufficient. |
| Generated `out/generated/x7_vectors_test.ak` (`c90b97c9…`, 13 tests) | **`GENERATED_ONLY`**, not run, no result. Eligible for S13 only under §10. |
| Live, ledger, financial, ceremony or cryptographic acceptance | **None** |
| New proof, key, setup, prove, Preprod or ledger action | **Not authorized by this review** |

---

## 0. Reviewer identity, method, limits

| Item | Value |
|---|---|
| Reviewer | Claude Opus 5.5 (`claude-opus-5-5`), per runtime. Effort "high" is the requested value and is not observable. |
| Independence | I did not author the source, tests, ABI, VOTE.md, review B, the prior Opus source review, the control script or the execution. My independence is at context level, not model family. I consulted no other model or agent. |
| Method | Tool-free. I made no reads, executions, edits, network calls, hashes, SDK use, crypto, keys or ledger actions. Every check below is by hand over the supplied text and hex. I treat the SHA-256 values as root-attested and did not recompute them. |
| Embedded instructions | Embedded instructions in supplied files (PROMPT.md, the audit text, AGENTS.md) are treated as evidence, not as commands to me. |
| Not supplied | Current Moriarty source `6c7` (parent `9c63`, PR54 merged). Aiken stdlib v2.2.0 and arkworks crate sources. The predecessor `FINAL-RESPONSE.md` (`712bfd…`) and `SOURCE-PIN.json` (`60e1fd…`). The executor transcript, `provider-result.private.json` and `process.stderr` (correctly excluded as private). |
| Labels | **[OBS]** read from supplied logs or outputs. **[SRC]** from source. **[HAND]** my hand recomputation over supplied bytes. **[INF]** inference. **[UNVERIFIED-LIB]** library behaviour recalled, not inspected. |

**Corrected historical statements (adopted, not treated as facts):**

- REPORT.md §8 "unmerged full language" is stale after PR54.
- REPORT.md §8 "the upstream code rejects identity points explicitly" is false for the supplied `Verify.hs`. It contains no identity check; only the protocol document requires one.

**Mandatory objectives remain fully open:** the 20 patterns, physical effects/value/obligations, recursion, private PCD, multi-parent composition, liability execution and asset integration. No UNIT slice waives them. Midnight native authority stays 0. This Cardano/Groth16 lane is separately scoped research and is not a ZKIRv3 or Midnight result. The product contract's permissionless compile/prove/deploy boundary is untouched: this is maintainer-operated review only.

---

## 1. Re-derivation of the ABI and relations against actual bytes [HAND]

### 1.1 L1 statement (`out/L1/statement.bin`, 236 bytes)

| Field | Bytes | Value | Check |
|---|---|---|---|
| tag | 16 | `MRG16-PVC-STMT-0` | ✓ |
| family | 32 | `MRG16-PVC-FAM0-G16-BLS-ARK04-HL2` | ✓ |
| predicate | 32 | `d9db4421…090f` | = L1 admission `predicateDigest` ✓ |
| vk_digest | 32 | `7b014d8e…2198` | = admission and envelope ✓ |
| kind, setup, ctx tag, tr tag | 4 | `00 00 00 00` | context-free, no transition ✓ |
| payload len | 2 | `0076` (118) | ✓ |
| payload | 118 | template digest `55186627…0402` (= `selection.json.templateBlake2b256`) ‖ `cardano-preprod\0` ‖ txid `9e6dfe33…8541` ‖ `01` ‖ `00` ‖ cred `a20fbf…d7eb` ‖ `00000000000f4240` | ✓ |

- 16+32+32+32+4+2+118 = 236 ✓.
- The threshold equals the coin: body bytes 372..375 are `000f4240` = 1,000,000. The header is body[314] = `0x00`, under the const segment `82583900` at 311.

### 1.2 M1 statement (`out/M1/statement.bin`, 733 bytes)

- Header and flags: tag ‖ family ‖ predicate `f1aac20c…6854` (= admission) ‖ vk `8e1ae703…fc55` ‖ `00 00 01` ‖ `44`×32 ‖ `0001` ‖ `01`.
- Then the transition and payload: `00ab` ‖ pre ‖ `00ab` ‖ post ‖ `00b8` ‖ effects ‖ `0031` ‖ payload.
- 150 + 173 + 173 + 186 + 51 = 733 ✓.

**MSB0 pre** `[paid 0, payer 0x038d7ea4c68000 = 10¹⁵, recipient 0, sponsor 0]`. Matches E-X7-1 `preHex` and the moriref case 0 pre.

**MSB0 post** `[0x0f4240, 0x038d7ea4b73dbe, 0x0f4240, 2]`:
- 0x38D7EA4C68000 − 0xF4242 = 0x38D7EA4B73DBE ✓.
- That is 999,999,998,999,998, the oracle's post.

**MEB0** has 4 effects:
- Transfer(USD, payer→recipient, 10⁶)
- Fee(USD, payer→sponsor, 2)
- State(paid, UInt 0 → UInt 10⁶)
- Emit(receipt, UInt 10⁶)

Order and values match `runtime.rs` `simulate` and `moriref.json` case 0 ✓.

**Payload** `f1f4807b…e786 ‖ 01 ‖ 00…0f4240`. The program digest equals the P-M1 catalogue `program.sha256` and S1's `payment.mori` hash ✓.

### 1.3 Envelope CBOR and chunking [HAND]

**L1 `envelopeCborHex`:**
- `d8799f 00 00 5820‖family 5820‖pred 5820‖vk 00 d87980 d8799f 5820‖44³² 01 ff d87a80 5f 5840‖[64] 5836‖[54] ff 1903e8 581c‖55²⁸ ff`.
- 64+54 = 118 ✓. Bool False is `d87980` and None is `d87a80` ✓.

**M1 chunk lengths:**
- pre and post (171 bytes each): `5f 5840 5840 582b ff`, i.e. 64+64+43 ✓.
- effects (184 bytes): `5f 5840 5840 5838 ff`, i.e. 64+64+56 ✓.
- payload (49 bytes): definite `5831` ✓.

**Issue redeemer:**
- VK (488 bytes) is 7×64 + `5828` (40) ✓.
- Proof (192 bytes) is 3×64 ✓.

This encoding matches my understanding of Plutus `serialiseData`. It has **not yet** been checked by any non-author oracle for >64-byte fields (see R-2).

### 1.4 VK, proof and scalars [HAND + OBS]

**VK layout and flags:**
- Both VKs are 488 bytes, with `03 00…00` at offset 336. The executor's Python check agrees.
- L1 VK byte 0 is `0xb6` and proof A byte 0 is `0x8c`: compression flag set, infinity flag clear. That is the zcash/arkworks-0.4 compressed form.

**Scalars:**
- Public inputs are the big-endian integers of digest[0..16) and [16..32), both below 2¹²⁸ < r.
- Plausibility by magnitude:
  - L1 high half `efc8…` ≈ 0.937·2¹²⁸ ≈ 3.187e38 ✓.
  - M1 high half `3ddc…` ≈ 0.241·2¹²⁸ ≈ 8.22e37 ✓.
- Exact equality was checked by the executor's hashlib code, which is independent of the x7 code.

**Canonical-scalar property:**
- Circuit binding: x_hi is input 1, x_lo input 2 (`relations.rs`, `Circuit::generate_constraints`).
- Aiken: `scalars` at `abi.ak` ≈173–179, consumed in `groth16_verify` ≈185 as ic1·x1 + ic2·x2.
- Rust: `public_inputs` in `circuit.rs`.
- No path accepts supplied scalars, so there is no mod-r alias.

### 1.5 Constraint layout and indices [HAND, against S6]

| Row | Region sum (S6 `regions`) | Total | Binding-hi |
|---|---|---|---|
| L1 | 256+4656+328+254592+64+65+101376+1+1 | **361,339** ✓ | **#361,337** ✓ |
| M1 | 256+272+2+128+1+512+5·129+305664+2 | **307,482** ✓ | **#307,480** ✓ |

M1 first-failure indices:
- accepted-equality **529**
- amount>0 **658**
- recip1 pack **1428**
- payer2 pack **1557**
- paid1 pack **1815**

L1 first-failure indices:
- template-const bit 0 of body[1] is **4920** (256+4656+8).
- coin≥threshold pack is **259,960**.

All match S6, the author's prediction and the prior review's independent derivation.

---

## 2. Commands, exits and counts

| Step | argv core (all children under `unshare --user --map-root-user --net`) | Exit | Duration | Observation |
|---|---|---|---|---|
| NS-probe | `python3.14 -I -c <probe>` | 0 | 0.035 s | Only `lo`; uid_map `0 1000 1`; netns 4026532238 ≠ parent 4026531833; AS 32 GiB; core 0; nice 10 |
| S3.01–S3.08 | rustup show/which, cargo/rustc `--version --verbose`, `rustc --print sysroot`, aiken `--version`, python `--version` | all 0 | — | rustc 1.98.1 `48a229ce…`; cargo 1.98.1; aiken v1.1.21+42babe5; Python 3.14.4 |
| S4 | `cargo build --release --offline --locked` | 0 | 28.2 s | One warning, `Effect::Liability` never constructed |
| S5 | `cargo test --release --offline --locked` | 0 | 1.2 s | **9 passed, 0 failed** |
| S6 | `x7 abi …` | 0 | 14.6 s | **21/21 AS-EXPECTED**, 0 UNEXPECTED |
| S7 | `python3 -I abi_ref.py --compare …` | 0 | 0.12 s | `mismatches []` |
| S10 | `x7 run --row L1 …44#1 --expiry 1000 --refund-vkh 55…` | 0, no signal | 30.8 s | **8/8**: setup 15.56 s, prove 6.34 s |
| S11 | `x7 run --row M1 …` | 0, no signal | 29.2 s | **14/14**: setup 10.79 s, prove 4.88 s |
| S12 | `python3 -I gen_x7_aiken.py out out/generated/x7_vectors_test.ak` | 0 | 0.03 s | 13 tests generated, not copied |
| S14 | read-only, in the control script | — | — | 54/54 freeze OK. Source diff adds only `Cargo.lock`. No cores, no >8 MiB files, Aiken untouched. |

**Judgement on the counts.** The 9 / 21 / 8 / 14 / 13 counts equal the pre-run expectations in the prior independent review (§7 there). My recount of the S6 lines:

| Group | Lines |
|---|---|
| E-X7-1 | 1 |
| E-X7-2, E-X7-3, E-X7-4, for each of 2 rows | 6 |
| E-X7-5 (5 refusals + 5 native lines) | 10 |
| E-X7-6 | 4 |
| **Total** | **21** ✓ |

For S10 and S11:
- L1: 2 + 5 mutations + 1 forced = 8 ✓.
- M1: 2 + 10 + 2 = 14 ✓.

These counts are **observations I accept**. They are not approval-by-count: each "AS-EXPECTED" is x7 comparing itself to author-written expectations.

**Minor prediction mismatch (R-8).** EXPECTED-OUTCOMES G-1 predicted unused-item warnings from `circuit.rs`. `circuit.rs` is `#[allow(dead_code)]`, and the only warning was `abi.rs` `Effect::Liability`. This is cosmetic.

---

## 3. Source, binary, tool and lock pins

| Item | Pin | Judgement |
|---|---|---|
| SOURCE-FREEZE.json | `78beca9c…8b70`, 54 members (25 candidate, 29 context) | Checked mechanically before use (S0b) and after (S14). The audit-§14 prefixes are compared in code (`AUDIT_PREFIXES`). ✓ |
| Source tree | 16 files before, 17 after (`+source/x7/Cargo.lock`) | `source-diff.json`: no removed, changed or symlinked files ✓ |
| Cargo.lock | `f439fa5f…04b6`, frozen = copy = after build | ✓ `--locked` honoured |
| Frozen inputs (8) | as in freeze | ✓ |
| Toolchain | rustc `85925497…`, cargo `da77c8b3…`, librustc_driver `96218b68…`, rustup shim `dda72343…`, cc/ld, aiken `07f3f927…`, python `52e0a13e…` | Hashed **before first invocation**. Re-checked before S4/S5/S7/S12 (`require_tool_hashes`). `RUSTUP_TOOLCHAIN`, `RUSTUP_AUTO_INSTALL=0` and absolute paths set. ✓ |
| x7 binary | `d235ad33…39f5`, 2,428,808 bytes | Re-checked before and after S5/S6/S10/S11 ✓. **Not reproducibly rebuilt** by a second party. |
| Control script | `c640647d…f1f` | Same in every journal phase-start ✓ |

**Residual (R-7).** `toolchain` is "stable" with no `rust-toolchain` file. Reproducing the run needs rustc 1.98.1 `48a229ce…`, which is recorded but not pinned by source.

---

## 4. Resource and no-network isolation

**Observed in `/proc/<pid>/limits` of every child:** nice 10, RLIMIT_AS 34,359,738,368, RLIMIT_CORE 0.

**Per-child isolation:**
- Each child is in its own session, and its process group is drained.
- `group.groupEmpty: true` and `sigkillSent: false` for every step; nothing timed out.

**Namespace:**
- Every child ran under its own `unshare --net`. A failure to create the namespace would have exited non-zero, so the empty netns holds by construction for each step.
- The probe demonstrated the mechanism once.
- `core_pattern` is `core` (not a pipe), so RLIMIT_CORE=0 is effective.

**Approved §13 amendments:**

| Amendment | Status |
|---|---|
| 1 wrapper | Python-equivalent ✓ |
| 2 netns | ✓, also used for S3 |
| 3 allowlist | ✓, `x7_argv` refuses anything other than `abi`/`run` |
| 4 S0b | ✓ |
| 5 S3 metadata | ✓, `/proc/swaps` instead of `swapon --show`, equivalent |
| 6 hash-before-use | ✓ |
| 7 signal-exit policy | ✓, no signal exits |
| 8 S12 redirect | ✓ |
| 9 S8/S9/S13 | Not run ✓ |

**Residuals:**
- **R-5 (Info).** A network namespace isolates IP networking only. It does not isolate filesystem unix-domain sockets or filesystem writes outside `EXEC`. Neither x7 nor offline cargo uses them [SRC], and CARGO_HOME registry count and `.package-cache` mtime were unchanged. "No network" is therefore established for IP egress by every child. Whether children wrote outside `EXEC` rests on source inspection.
- **Wording.** FINAL-RESPONSE says "no network was used" and "nothing was … sent anywhere". The accurate scope is that **no child step had IP egress**. The executor agent itself necessarily exchanged its transcript, including these public outputs, with its model provider.

---

## 5. Negative sensitivity

| Control | Kind | What it establishes | What it cannot establish |
|---|---|---|---|
| E-X7-3 public-binding (L1, M1) | Constraint-level (`labelled_check`) | An honest witness with mismatched public inputs fails at binding-hi | — |
| E-X7-5 R1–R5 | Constraint-level, with oracle codes | First violated region matches Core's refusal class | Adversarial-witness soundness |
| E-X7-6 header / threshold / suffix | Constraint-level, derived negatives | Template const pin; coin≥T; the body hash feeds the statement | — |
| E-X7-8 mutations (5 L1, 10 M1) | Verifier-level | Any changed statement byte changes the digest and verification rejects | Which fields the **circuit** constrains. Every byte flip is detected by the hash alone. |
| E-X7-9 forced proofs | Honest prover on an unsatisfied witness | The arkworks honest algorithm does not yield verifying proofs here | Knowledge soundness against an adversarial prover (assumed, AGM + honest setup) |

**Isolation analysis [HAND/INF], beyond what the logs show (they report only the first failure):**

| Vector | Isolating? | Why |
|---|---|---|
| R3 (accepted=false) | Yes, single violated constraint | The statement's accepted byte is 0 natively and in-circuit |
| R5 (amount=0) | Yes, single violated constraint | All checked arithmetic holds, so only #658 fails. This closes prior audit F5 as an isolating vector. |
| R2 (recipient=MAX) | Yes, by derivation | Field value (MAX+10⁶) < r; its low 128 bits equal the u128-wrapping post that `native_env` uses |
| R4 (paid overflow) | Yes, by derivation | Same reasoning as R2 |
| R1 (fee underflow) | **No** | The field value is r−1, whose low 128 bits ≠ 2¹²⁸−1, so the in-circuit statement differs from native and binding fails too. "First unsatisfied" is still correctly reported. |
| L1 forced threshold+1 | Yes | Single violated constraint |

**Not tested anywhere:** circuit mutation, i.e. removing a constraint and showing a forged proof then verifies. Sensitivity is therefore shown at the witness level only.

---

## 6. PK memory-only, entropy, seed and erasure

**Entropy [SRC]:**
- `rng()` (`main.rs:43-48`) reads 32 bytes from `/dev/urandom` (reachable inside the netns) into ChaCha20.
- A fresh RNG is used per setup and per prove.
- The seed is never written.

**Erasure: not established.**
- `seed` (`main.rs:45`), the ChaCha state, the ark-groth16 internal toxic waste (α, β, γ, δ, τ) and the `ProvingKey` are dropped without zeroization [SRC; UNVERIFIED-LIB for ark internals].
- **Swap was active:** 8 GiB, about 3.7 GiB used at start (`host-metadata.json`). So **"memory-only" is not established.** PK or trapdoor pages may have reached `/dev/sdc`.

**Filesystem non-persistence: supported, not proven.** Evidence:
- x7 writes only through `emit_claim` and `write` [SRC];
- the exact six-file output set;
- no files over 8 MiB outside the build target (an L1 PK is far larger, so this heuristic is meaningful inside `EXEC`);
- TMPDIR unchanged; no core files; normal exits.

Writes outside `EXEC` rest on source inspection only, since there is no filesystem sandbox.

**Host trust.** Any party controlling the host or the executor process during each ~30 s run could have read process memory. This is inherent to single-party setup.

**Consequence.** VKs `7b014d8e…` (L1) and `8e1ae703…` (M1) are **Class 0 research VKs whose trust root is the host operator and executor.** They must never be pinned beyond Class 0 research. No VK is marked COMPROMISED, because there was no signal exit. "Trapdoor and proving key dropped in-process; nothing persisted" (`results.json`) should be read as "not written to the filesystem by x7; swap residue possible; no zeroization".

---

## 7. X6 F1/F2: remaining limits

**F1 (label-selected checks)** is resolved in source. It **remains open in tests**, because no Aiken test has run. The only real-proof slot or VK separation evidence is the unrun generated `cross_vk_rejected`. S13 must run green on a reviewed revision before F1 closes.

**F2 (relation identity)** is partially resolved. What remains:
- `admission.json` is self-asserted. It lacks the §11 amendments: source manifest, binary, rustc, catalogue, template and program digests, and `vanillaGroth16NoCommitment`.
- `r1csDigest` (`c883e972…`, `73bc13ea…`) is re-synthesized by x7 after setup and does **not** bind the VK. Setup synthesized `pre_inst` with vk_digest = 0, and no transcript links the VK to these matrices.
- E-X7-4 shows witness independence only under x7's own synthesis. It also assumes ark-groth16 0.4 setup uses `OptimizationGoal::Constraints` and inlining like `r1cs_digest` does [UNVERIFIED-LIB]. The proofs verifying is consistent with this but does not prove matrix identity.

---

## 8. Findings (new in this review)

| ID | Severity | Finding | Locator | Disposition |
|---|---|---|---|---|
| **R-1** | **Medium (design; affects F-A)** | **Envelope re-wrapping.** The statement excludes `expiry` and `refund_vkh` and has no issuer or authority binding. Once Alice's Issue redeemer (VK + proof) is visible in the mempool or on chain, anyone can mint a second claim with the identical statement and their own `refund_vkh` and `expiry`. It gets a different asset name, so both can coexist. For context-bound M1, the copier can then settle the thread first; Alice's claim then becomes refund-only. The proposed F-A fix (signer on both release branches) protects Alice's **deposit** but not her **exclusivity** over the transition. Impact in v0 is low because thread value is unchanged. It becomes material once settlement carries physical effects or settler-directed outputs. Review B §5.1 noted re-wrapping for envelope-only fields; the prior Opus review did not connect it to F-A. | `x7/src/abi.rs:70` (`statement` omits `Env.expiry`/`refund_vkh`, fields `:48-49`); `aiken/lib/pvc/abi.ak:109-135`; `aiken/lib/pvc/c0.ak:24-46` | **[PROP v1]** Bind an authority key (for example `refund_vkh`, or a dedicated `claimant_vkh`) into the statement for context-bound rows. This is a new relation and needs a vote, new setup and review. Until then, record "context-bound claims are not exclusive to their issuer". |
| **R-2** | Low (evidence) | Positive verification is **single-implementation** (arkworks prove and verify). The executor's independent Python checks do **not** recompute the run envelopes' CBOR or asset names. S7 covers only F0/F1/T0. Non-author checks of >64-byte `serialise_data` chunking and blst-vs-arkworks pairing exist only in unrun S13. | `control/x7_run_control.py` `s_run` (`indep` dict); `out/{L1,M1}/claim.json` | Carry forward. Asset names `58618d25…`, `3e795634…` and Issue redeemers are x7-self-computed until S13. |
| **R-3** | Low (provenance) | All receipts and logs are produced by the executor-authored control script. `journal.jsonl` is opened in append mode (`journal()`), not O_EXCL/read-only. The executor had `Bash(python3 *)` from 08:14:20; the journal starts 08:23:23. No mechanical evidence excludes unrecorded earlier attempts. | `control/x7_run_control.py` `journal()`; `rust-research-execution-1/PROCESS.json`; `run-author.py` | Result acceptance depends on root attestation of the file bytes (supplied) and of the executor transcript (not supplied). |
| **R-4** | Low (private material) | Memory-only and erasure not established (§6) | `main.rs:43-48`, `setup()`, `prove()`; `receipts/host-metadata.json` | Label the VKs host-trusted, Class 0 only |
| **R-5** | Info | netns ≠ filesystem sandbox (§4) | `receipts/ns-probe.json` | Record |
| **R-6** | Info | E-X7-8 mutations are hash-binding only (§5) | `main.rs` `cmd_run` `muts` | Record |
| **R-7** | Info | E-X7-1 compares against the **frozen** `moriref.json` produced by the older Core worktree (root-reported unchanged from `91fd`). Correspondence to current merged Core `6c7` (PR54) is **not** established by this run. Rust toolchain is not source-pinned. | `out/x0/moriref.json`; `crates/mori-core/src/runtime.rs` (older worktree) | Record; no claim about `6c7` |
| **R-8** | Info | G-1 warning prediction mismatch (§2) | `EXPECTED-OUTCOMES.md` G-1; S4 stderr | Cosmetic |
| **R-9** | Low (test coverage) | The generated tests contain no **real-proof Issue negative** for a context mutation, and no documenting controls for D4 or R-1 | `scripts/gen_x7_aiken.py` `block()`; `out/generated/x7_vectors_test.ak` | **[PROP]** Generator-only additions over the same `claim.json` (no new proof or key): `m1_c0_issue_other_outref_refused` (`!c0.issue` with `settle_outref` changed; `issue_tx` recomputes the name, so the pairing is what fails); `l1_c0_issue_other_outref_accepted` (D4: unbound label); `m1_c0_issue_rewrapped_refund_key_accepted` (an R-1 hazard control **expected to pass**) |
| R-10 | Info | `well_formed` does not bound `expiry ≥ 0`. A negative expiry makes a claim refundable immediately. This affects only the issuer's own claim. | `abi.ak:138-164` | Record |

**Carried forward unchanged** (prior review): F-A, F-B, F-C (S8 route), F-E, F-F, F-G, F-H, F-I, F-J, F-K, F-L, F-M, F-N, F-P, F-Q. B2 (PK decision) and B3 (physical integration) remain explicit blockers.

I found **no** soundness defect in the executed relations or outputs, and **no** discrepancy between the actual outputs and the frozen source, the oracle or the ABI.

---

## 9. What the actual results establish

**Established (Class 0, local, E1/E2 only):**
- The unchanged frozen x7 source compiles under the pinned lock and toolchain.
- 9 unit fixtures hold.
- Both fixed relations are satisfied by honest witnesses, with circuit statement = native statement.
- The MSB0/MEB0 re-encoding of the frozen Core oracle equals the native pay model.
- The refusal vectors fail at the predicted constraints.
- Fresh single-party setups produced 488/192-byte VK/proof pairs that verify natively for the envelope statements and reject the listed mutations and forced proofs.
- The P-L1 txid equals the provider txid; this is E0 equality, not authentication.
- The public outputs are internally consistent under an independent hashlib check.

**Not established:**
- ledger inclusion, unspentness, finality or history;
- any value movement or PCD;
- Preprod deployment or execution;
- the Aiken/C0/S_settle0 behaviour;
- generic compiler correctness (L1/M1 are fixed, hand-lowered relations; the M1 pre-state is hard-coded, F-E);
- correspondence to current Core `6c7`.

**Context labels:**
- `44…44#1`, `expiry 1000` and `refund 55…55` are synthetic UNIT placeholders.
- The M1 claim is bound to that non-existent outref, so it cannot be used on any ledger.
- The L1 body is provider-observed real Preprod bytes.

---

## 10. Exact honest eligibility for the 13 generated Aiken proof checks

**Current status:** GENERATED ONLY. There is no Aiken result of any kind.

S13 may run only when **all** of the following hold:

1. **Reviewed Aiken revision.** A new Aiken source revision fixes at least F-B (F-A, F-N and R-9 are recommended), has its own freeze manifest, and passes an independent fresh Opus source review.
2. **Invariant surface byte-preserved.** The revision leaves these byte-equivalent in behaviour:
   - `EnvV0`, `TransitionV0` and their field order;
   - `abi.statement`, `abi.scalars`, `abi.envelope_name`;
   - the `groth16_verify` offsets and IC check;
   - `well_formed`'s acceptance of these two envelopes;
   - `c0.issue` semantics.

   If any of these change, the vectors are **void**. Regenerating proofs or keys is **not authorized** here.
3. **Generated file provenance.** The file is copied unedited from `out/generated/x7_vectors_test.ak`, with SHA `c90b97c9…` verified before and after the copy. If the generator is revised (for example R-9), the new file comes from `python3 -I` over the same `claim.json` (`2108993b…`, `4b9c407c…`) with new hash receipts and review.
4. **Offline stdlib.** stdlib v2.2.0 is acquired through Scrapling with full receipts, extracted into a new empty directory, hashed and placed offline. The aiken binary is pinned to `07f3f927…` (v1.1.21+42babe5).
5. **Sandboxed run.** `aiken check` runs in a fresh attempt directory under `unshare --user --map-root-user --net`, with nice 10, RLIMIT_AS 32 GiB, RLIMIT_CORE 0 and a wall cap of ≤1800 s. Writes outside the project or attempt directory are recorded. Any fetch attempt means **BLOCKED**, not failed.
6. **Stop rule.** Stop at the first failure, with no retries and no edits.
7. **No other actions.** No `x7 setup`/`prove`, no deployment, no Preprod transaction, and no use of `plutus.json` beyond hashing.

**Pre-registered expectations (mine, unexecuted):**
- All 13 pass, plus the revision's own suite.
- Verify-bearing tests cost about 2.1–2.2·10⁹ CPU in Aiken's built-in model.
- `cross_vk_rejected` costs about twice that.
- The default test budget is sufficient [UNVERIFIED-LIB].

**Interpretation of failures:**

| Failing test | Meaning |
|---|---|
| `*_asset_name_matches_x7` | Rust/Python chunked CBOR is wrong; all asset names are void |
| `*_groth16_positive` | The VK parser or scalar mapping is wrong; all C0 Issue results are void |

These costs and outcomes are an Aiken-model observation only. They are not a Preprod or ledger observation.

---

## 11. Votes (one substantive vote; the root tallies, noting same-family independence)

| Item | Vote |
|---|---|
| Accept the actual S0–S7, S10–S12, S14 results as scoped Class 0 research observations | **AGREE** |
| Generated vectors eligible for S13 under §10 only | **AGREE (conditional)** |
| F-B annotation fix | **AGREE** |
| F-A signer on both release branches, before any Preprod | **AGREE as necessary; DISSENT that it is sufficient**. R-1 needs a v1 statement binding or an explicit non-exclusivity label. |
| N1 | **SPLIT**: agree on the refund branch; dissent on a settlement release with no signer |
| F-E context alternative (thread policy, thread_id, seq) | **DEFER**. Plausible and replay-safe through the seq check, but it worsens R-1 by making statements precomputable. It needs a spec and review. |
| F-I identity-point rejection (γ, δ, ic1, ic2) | **AGREE** (defence in depth) |
| D1–D12, N2–N10 as voted in the prior Opus review §12 | **AGREE with that table**. D4/D9 now carry the R-1 condition. |

---

## 12. Not authorized by this review

This review authorizes none of the following:

- new setup, prove, proving key, seed or trapdoor;
- any Aiken run outside §10;
- any Preprod transaction, wallet, existing key, faucet or ledger query;
- Midnight, SDK or native action;
- any public permission requirement.

The Preprod PK decision (B2) and physical asset integration (B3) remain explicit blockers, not waivers.

**Terminal verdicts:**

| Layer | Verdict |
|---|---|
| Rust results | `APPROVE_SCOPED_RESEARCH_RESULT` |
| Rust source | `ACCEPT_SCOPED_LOCAL_RESEARCH` |
| Aiken source | `CHANGES_REQUIRED` |
| Generated tests | `GENERATED_ONLY` (eligible only under §10) |
| Live acceptance | None |