The Write to `root-owned-attempt-2/REPORT.md` was denied, so the file does not exist. As the prompt instructs, the full public report is below for the dispatcher to keep. I did not try any other way to write it.

---

# Independent security review: Groth16 experiments over Cardano Preprod data

Reviewed candidate: author `REPORT.md` SHA-256 `27365cc444109b0d69df322cead1923bf12f6352adcd913b9c3cca83a229984b`, together with the full public selection frozen under `groth16-preprod-independent-opus-review-20261015/public-selection` (`SELECTION.json`, `PUBLIC-BINARY-ENCODINGS.json`).
Review date: 2026-10-15. Root-owned attempt 2. The earlier attempt ended with no exit status, no report and 0 bytes of output, so it contributes no vote.

The report could not be saved because Write was denied. This text is the complete report.

**Terminal verdict: `APPROVE_SCOPED_RESEARCH_RESULT`.** The approval is narrowed by the exclusions and dissents in §9 and §12.

---

## 0. Reviewer identity, effort and method

| Item | Value |
|---|---|
| Requested reviewer | `claude-opus-5-5`, high effort (dispatcher request) |
| Actual reviewer | Claude Opus 5.5, model ID `claude-opus-5-5`, as stated by my runtime environment. I cannot observe the effort setting from inside the session; "high" is the requested value only. |
| Independence | I did not author the candidate. I did not use or consult any other model, agent or reviewer. All security judgments here are my own. |
| Tools used | Read, Grep and Glob over the frozen snapshot and its two manifests. One Write was attempted and denied. |
| Tools not used | Bash or any shell, builds, tests, proof/VK/SRS/PK/witness actions, Aiken/UPLC evaluation, ledger or provider queries, WebSearch/WebFetch, auxiliary agents, source edits. |
| Not read | The original task directory (only its frozen copies were read), excluded private files (`provider-result.private.json`, `process.stderr`, `private/`, any target directory or binary), the bridge repository, the brainstorm and shared-source captures, the CIP-0381 text, and the two approved Core oracle packets. Those packets were used by identity only: the SELECTION freeze digests `54d58aef…` and `288f2cfe…` are unchanged and not adopted here. |
| Snapshot integrity | I had no hashing tool. I did **not** recompute the SHA-256 values in `SELECTION.json`; the snapshot's equality with the originals is attested by the root. I did check internal byte consistency wherever the selection supplies hex (see §5). |

Every claim below is my inspection of the supplied source and logs. Where a statement comes from code reading and no execution was observed, it is marked **[inspection]**. Where it comes from the author's logged runs, it is marked **[log]**.

---

## 1. Candidate and evidentiary scope

**Source closure that I read in full:**

- `g16/src/{circuit.rs, gadgets.rs, main.rs}`, `g16/Cargo.toml`, `g16/Cargo.lock` (targeted), `out/logs/g16-Cargo.lock.attempt1` (targeted)
- `scripts/{run_all.sh, logrun.sh, fetch.py, select_tx.py, select_tx_v0_frozen_rule.py, cbor_spans.py, gen_aiken.py, make_bundle.py, assemble.py}`
- `aiken/lib/mrg16.ak`, `aiken/aiken.toml`, `aiken-probe/lib/probe.ak`
- `moriref/src/main.rs`, `moriref/Cargo.toml`
- `data/moriarty/payment.mori`, `catalogue/P-L0.v0.json`, `catalogue/P-M0.v0.json`, `CATALOGUE.v0.json`, `BUNDLE.v0.json`
- `PLAN.md`, `PROMPT.md`, `REPORT.md`, `FINAL-RESPONSE.md`, `PROCESS.json`, `RESULTS.json`, `COMMANDS.json`

**Merged Core, read to the depth needed for `pay`:**

- `crates/mori-core/src/runtime.rs`: expression evaluation (lines 420–479), scenario validation (523–662), `move_funds` (663–695), `simulate` (697–891)
- `rust-toolchain.toml`, `AGENTS.md`, the `develop` skill
- `Cargo.lock` (targeted pins)

The Core parser, lexer, IR, intent, policy and other modules were not reviewed line by line. My correspondence argument rests on `runtime.rs` and on the oracle outputs. It is not a Core-wide audit.

**Results, logs and data:**

- All `out/logs/*` files that bear on X0–X6, including every failed build and the stale-binary run
- `out/commands.jsonl` (via `COMMANDS.json`), `out/x{0,1,2,3,4,6}/results.json` (targeted), and all of `out/run1-pre-final-source/` (targeted)
- `data/selected/{template.json, selection.json (targeted), selected-body.bin and selected-tx.cbor (via hex)}`
- `data/RECEIPTS.json`, `data/raw/tx-info-9e6dfe33.body`, `data/raw/tx-cbor-5292012-5292041.body` (the 413 failure), and `data/raw/cli-protocol-params.body` (targeted)

**Evidence classes.** I keep the author's E0–E4 distinction:

| Class | Meaning |
|---|---|
| E0 | Provider observation |
| E1 | Bound bytes |
| E2 | In-circuit arithmetic |
| E3 | Inclusion or state |
| E4 | Consensus or finality |

Nothing here reaches E3 or E4.

---

## 2. Summary

1. **The circuits are sound for the stated relation [inspection].** I found no soundness defect in the R1CS for the BLAKE2b-256 gadget, the template pinning, the coin ≥ threshold check, the binding of the statement digest to the public inputs, or the hand-lowered `pay` arithmetic. I derived the constraint-region layout independently from source. It reproduces every constraint index and total in the logs exactly (§3.6), which gives strong structural agreement between the final source and the logged runs.
2. **The X0–X5 results are as reported [log], and the author scopes them correctly** as bound bytes plus arithmetic. Inclusion, phase-2 validity, network, unspentness and finality are disclaimed throughout.
3. **The X6 consumer has two binding gaps the author did not identify** (findings F1 and F2):
   - Script binding (C6) is keyed on a bundle-controlled `entryName`.
   - The circuit's predicate-digest constant does not identify the relation: the experiment's own X3 "unbound" VK carries the same predicate and template digests as P-L0.

   The admission record is therefore the sole trust root, and the bundle does not pin the catalogue. The seven tamper refusals are real, but they do not show that the proposal binds scripts or relations against an adversarial bundle or catalogue.
4. **The evidence chain has disclosed and undisclosed gaps** (F3):
   - No source or binary digest was recorded at build time; binary digests were computed later by an unlogged `assemble.py`.
   - The run-1 Aiken generation and the `run_all.sh` invocation itself were not logged.
   - A third grep-masked build exit was not annotated.
   - The run-1 X6 result was produced by the post-fix binary.
5. **Wording overclaims** (F4): "43/43 … as frozen in advance" is broader than what `PLAN.md` actually froze.
6. **The `requires amount > 0` boundary is unexercised** (F5). By inspection the constraint is correct. A labelled derived-mutation vector that would isolate it was feasible but not run.

---

## 3. Circuit and lowering review (mandatory item 2)

### 3.1 BLAKE2b-256 gadget (`gadgets.rs:206–298`) [inspection]

**Parameters and padding:**

- The parameter block is `IV[0] ^ 0x01010020`: digest length 32, no key, fanout 1, depth 1 (`gadgets.rs:280`).
- The `IV` constants, `SIGMA`, 12 rounds and the G rotations 32/24/16/63 are correct.
- The counter is `t = (i+1)·128` for non-final blocks and `t = len` for the final block. The final-block flag sets `v[14]` to all ones. The empty message is one zero block.
- Message words and output words are little-endian bytes with little-endian bits.

**Gadget soundness:**

- XOR uses `(2a)·b = a + b − c`. When `a` and `b` are boolean this determines `c` uniquely (`gadgets.rs:84–96`).
- Modular addition packs 64 result bits plus 2 carry bits, all booleanity-constrained. Both sides are below 2⁶⁶, far below r, so field equality is integer equality and the decomposition is unique (`gadgets.rs:146–167`).
- Constant folding (`is_const`) applies only to linear combinations over `Variable::One`. That is sound.

**Cost.** The first compression costs 50,304 constraints. Each later compression costs 51,072; the extra 768 come from XORs that can be constant-folded only while the chaining value is still constant. This accounts exactly for:

- 254,592 constraints for the 582-byte body (5 blocks)
- 101,376 for the 166-byte statement (2 blocks)
- 152,448 for the 343-byte statement (3 blocks)

**Conclusion.** The X1 vector equalities [log] for `""`, `"abc"` and the 582-byte body, together with the inspection, support correctness for fixed-length unkeyed inputs. This is not a proof of the gadget.

### 3.2 CBOR template and extraction (`select_tx.py`, `cbor_spans.py`, `template.json`, `circuit.rs:106–130`) [inspection]

I parsed the 582-byte body by hand from its hex in `PUBLIC-BINARY-ENCODINGS.json`:

| Part | Encoding |
|---|---|
| Body | Map of 4 keys |
| Key 0 | Tag-258 set of 2 inputs (`bstr32`, small uint) |
| Key 1 | 3 outputs |
| Output 0 | `a3` map: 29-byte script address `0x70…`; value `[coin, {policy: {"USDr": n}}]`; inline datum `[1, 24(bstr 142)]` |
| Output 1 | Legacy `[bstr57 0x00‖pay‖stake, 1a 000f4240]` |
| Output 2 | Ends in the free suffix, followed by key 2 (fee) and key 7 (auxiliary-data hash) |

**Template coverage.** Output 1's coin ends at offset 376, so the suffix is 206 bytes. The const segments total 41 bytes and include the address header `0x00` at offset 314. The free bytes are only:

- definite-length string contents
- the explicit-width arguments of `1a` integers

Tag numbers, small immediates and container headers are all pinned, and `select_tx.py:46–66` is conservative about this.

**Assessment.** I agree with the author's prefix-determinism argument for this one shape: with every header pinned, the decoder's path to output 1's coin cannot depend on free bytes.

The relation proves only that some B exists with that prefix shape, that hash, and those fields. It ties to the real ledger body only under BLAKE2b collision resistance, and only if the txid is in fact a ledger transaction, which is E0.

The suffix, including whether keys 2 and 7 are really the remaining keys, is constrained only by the hash. The duplicate-key assumption the author names is needed for the "output 1 of the transaction" reading.

**Unread template field.** `Template.address_header` is never read (`circuit.rs:21`, compiler warning in `build-g16-4.log`). It is harmless here, because the header byte is pinned by a const segment and also carried in the statement.

### 3.3 Statement and public inputs (`circuit.rs:141–151, 204–220`; `main.rs:103–124`) [inspection]

**P-L0 statement (166 bytes):** tag(16) ‖ predicate digest(32) ‖ template digest(32) ‖ network label(16) ‖ in-circuit txid(32) ‖ output index(1) ‖ address header(1, from the body) ‖ pay credential(28, from the body) ‖ threshold(8, witness bytes).

**P-M0 statement (343 bytes):** the P-L0 layout followed by program SHA-256(32), accepted(1), amount(16), pre-state(64) and post-state(64). All UInt fields come from in-circuit bit decompositions.

I decoded the frozen `stmt2` and `stmt4` hex field by field:

- txid `9e6dfe33…8541`
- credential `a20fbf…d7eb`
- threshold and amount 1,000,000
- pre-state (0, 10¹⁵, 0, 0)
- post-state (1,000,000; 999,999,998,999,998; 1,000,000; 2)
- program digest `f1f4807b…e786`

Each matches its source.

**Public inputs.** The two public inputs are the big-endian integers of digest[0..16) and digest[16..32). Each is below 2¹²⁸, which is below r. They are bound by two linear equalities, the last two constraints.

**Constants.** The predicate digest, template digest, tag, network label, output index and program digest are circuit constants. That makes them part of the VK, not proved facts. The network label in particular is only a label, as the author states.

### 3.4 Hand lowering of `pay` versus `moriarty-core/1` (`circuit.rs:153–202`; `runtime.rs:450–459, 663–891`; `payment.mori`) [inspection]

Each source statement maps to a Core behaviour and a circuit constraint:

| Source | Core (`runtime.rs`) | Circuit | Verdict |
|---|---|---|---|
| `requires accepted` (step 0) | `Requires` must equal `Bool(true)` | Booleanity, then `accepted = 1` | Equivalent |
| `requires amount > 0` (step 1) | `Gt` on `u128` | `amount · inv = 1`, with `amount` range-checked to 128 bits | Equivalent on [0, 2¹²⁸): nonzero is the same as > 0 |
| `transfer(USD, payer, recipient, amount)` (step 2) | `move_funds`: `checked_sub` on the source, then `checked_add` on the recipient if `f ≠ t` | 128-bit decomposition of `payer0 − amount`, then of `recipient0 + amount` | Equivalent for distinct accounts. The account literals are distinct, so the `f = t` branch is unreachable for this program. |
| `fee(USD, payer, sponsor, 2)` (step 3) | Same `move_funds` | Decompositions of `payer1 − 2` and `sponsor0 + 2` | Equivalent |
| `next paid = paid + amount` (step 4) | `checked_add` | Decomposition of `paid0 + amount` | Equivalent |
| `emit "receipt"(paid)` | Effect with the post-state `paid` (the oracle shows 1,000,000) | Not represented; no effects digest | Not covered |

**Range reasoning.** I agree with the author:

- Every checked addition has an integer sum below 2¹²⁹, which is below r.
- Every checked subtraction that underflows produces a field value at least r − 2¹²⁸, which no 128-bit sum can equal.
- So field-wrap witnesses cannot satisfy the constraints. This is an argument, not a mechanised proof.

**Core behaviour the lowering does not model:**

- explicit-balance and asset-identity validation of the scenario
- trace and balance bounds
- metering (`simulate` passes `meter = None`, so it does not apply to the oracle)
- effects
- the self-transfer branch

**Adapter.** The adapter (`amount = coin`) lies outside Core semantics. Asset identity is not bound: the program's asset is USD on a local network, while the coin is lovelace.

**Scope.** This is one hand-lowered action of one program. It is not compiler-emitted, it is not ZKIRv3, and it shows no general correspondence.

### 3.5 The unexercised `requires amount > 0` boundary

The constraint (`circuit.rs:165–168`) is the standard nonzero-inverse gadget. It is sound (amount = 0 makes the left side 0, not 1) and complete (an inverse exists whenever amount ≠ 0) [inspection].

In every vector the adapter (`circuit.rs:161–163`, constraint #259835) comes first, so this constraint (#259836) was never the first failure [log]. In R5 it is also violated, but that is never observed.

A labelled derived mutation would have isolated it: set the coin bytes to 0, set threshold = 0 and amount = 0, and recompute the public inputs from the mutated statement. Every other constraint would then be satisfied. The vector was feasible without real data and was not run. If the constraint were removed, such a proof would verify for a non-ledger "txid" with amount 0, which Core refuses.

Real Cardano outputs cannot have coin 0 because of the minimum-UTxO rule, but the circuit does not encode that rule. The author discloses that this constraint is unexercised. I add that isolating it was feasible and recommend doing so before any reuse.

### 3.6 Independent check of constraint indices (source against logs)

From the source I derived the region layout:

| Region | Constraints | Running position |
|---|---|---|
| Body booleanity | 4,656 | — |
| Template const | 328 | ends at 4,984 |
| Body hash | 254,592 | ends at 259,576 |
| Threshold bytes | 64 | ends at 259,640 |
| coin ≥ threshold | 65 | packing at #259,704 |
| (X4) requires accepted | 2 | equality at #259,706 |
| (X4) adapter | 129 | packing at #259,835 |
| (X4) amount > 0 | 1 | #259,836 |
| (X4) pre-state range | 512 | — |
| (X4) transfer debit / credit / fee debit / fee credit / next paid | 129 each | packings at #260,606 (credit), #260,735 (fee debit), #260,993 (next paid) |
| Statement hash | 101,376 (X2) or 152,448 (X4) | — |
| Public-input binding | 2 | — |

Totals: X2 = 361,083, X3 = 361,081 (no binding constraints), X4 = 413,444.

Every first-unsatisfied index in `final-x2-ledger.log` and `final-x4-combined.log` matches this derivation exactly: #4664, #259704, #361081, #259706, #259835, #260606, #260735 and #260993. So do the run-1 results.

This is strong structural evidence that the binaries that produced the logs implemented the current `circuit.rs` and `gadgets.rs`. It is not evidence of byte identity (§4).

---

## 4. Source → binary → run trace (mandatory item 1)

Chronology from `COMMANDS.json` and the logs:

| Time (UTC) | Command | Exit as logged | What actually happened |
|---|---|---|---|
| 06:21:06 | build-moriref | 0 | Built against the worktree path. A **fresh** lockfile resolved 61 packages; `serde_json` 1.0.154 and `sha2` 0.11.1 versus the Core `Cargo.lock` pins 1.0.151 and 0.11.0 (F6). |
| 06:23:16 | build-g16 | **0 (masked)** | FAILED: `tracing-subscriber` not cached (`build-g16.log:10`). Annotated by the author. |
| 06:23:37 | build-g16-2 | **0 (also grep-masked; not annotated)** | Lockfile regenerated after `rm -f Cargo.lock`. Success is shown only by `Finished` (`build-g16-2.log:14`). The attempt-1 lockfile with `tracing-subscriber 0.2.25` is preserved; the final lockfile has none. |
| 06:24–06:25 | x1, x2, x3, x4 (run 1) | 0 | Produced by the build-g16-2 binary, which had no `bundle` subcommand. |
| before 06:27 | **gen_aiken.py (run 1)** | **not logged** | `out/run1-pre-final-source/mrg16.ak` exists, but no logged command produced it, and it is not listed in `unloggedCommands` (F3). |
| 06:27:01 | x5-aiken-check (run 1) | 0 | argv is `aiken check`; the working directory is not recorded. |
| 06:28:55 | build-g16-3 | **0 (masked)** | FAILED: E0277 (`build-g16-3.log`). Annotated. |
| 06:28:56 | x6-make-bundle | 0 | Built from the **run-1** x2/x4 artefacts. |
| 06:28:56 | x6-bundle-verify | 101 | Stale binary: `panicked at src/main.rs:536:18: unknown subcommand bundle`. In final source the panic is at `main.rs:704`, column 18. The 168-line offset is consistent with the bundle section (`main.rs:526–691`) having been added and nothing else moving. |
| 06:29:03 | build-g16-4 (`pipefail`) | 0 | Success (`build-g16-4.log`). This is the last logged build. |
| 06:29:08 | x6-bundle-verify-2 | 0 | **Post-fix binary on run-1 artefacts.** `out/run1-pre-final-source/x6/results.json` is byte-identical to the final `out/x6/results.json` (`07b0d6d7…`) and was produced by the new binary, not by the "pre-final-source" binary (F3). |
| 06:29:25–06:30:41 | final-x0 … final-x6 | all 0 | Labels, order and timeouts match `scripts/run_all.sh:7–15`. The `run_all.sh` invocation itself is not logged and its exit status is not recorded. |
| after 06:30:41 | **assemble.py** | **not logged** | Writes COMMANDS, RESULTS and RECEIPTS, and computes the binary digests `mrg16 cf9b3324…` and `moriref a3a5c7c7…` **after** the run. It is not in `unloggedCommands`. |

**Evidentiary scope:**

- No source digest and no binary digest was recorded at build time. The binaries are not in the selection.
- The link from the final source to the final binary rests on three things:
  - no logged build after 06:29:03
  - the exact constraint-index match in §3.6
  - the panic-line offset
- That is good consistency evidence, not a reproducible binding.
- The source snapshot digests were taken by the root at 06:48, after the run.
- The argv `scripts/select_tx.py` in `x0-select` and `x0-select-2` names a path whose contents were later replaced by the A1 version. The claim that `select_tx_v0_frozen_rule.py` preserves the original verbatim has no run-time digest behind it.
- The author's statement "The final evidence comes from a single run of `scripts/run_all.sh` on the final source" (`REPORT.md:43`) is consistent with the logs but only partly bound.
- The author's run-1 note, "same outcomes, different fresh setups" (`RESULTS.json:447`), is correct for X1–X5. It is mislabelled for X6.

---

## 5. Aiken / CIP-0381 artefacts (mandatory item 5)

**Byte identity [inspection].** I compared the constants in `aiken/lib/mrg16.ak` byte for byte with `PUBLIC-BINARY-ENCODINGS.json` and with `out/x3/results.json`. For X2 and X4, each `vk.bin` decodes as α‖β‖γ‖δ, then the length `03 00…00`, then ic0‖ic1‖ic2, in arkworks compressed form. These match the Aiken constants exactly. Also identical:

- the X2 and X4 proofs (A‖B‖C)
- `stmt2`, `stmt4` and the X3 forged statement
- the X3 VK, proof and statement
- the re-randomized X2 proof

**Verification equation [inspection].** `mrg16.ak:7–39` computes e(A,B) = e(α,β)·e(L,γ)·e(C,δ) with L = ic0 + x₁·ic1 + x₂·ic2. Here x₁ is the high half, allocated first (`circuit.rs:103–104`), and x₂ the low half. `scalars` derives both from `blake2b_256(stmt)` using big-endian `bytearray_to_integer(True, …)`. This matches arkworks.

**Logged results [log].**

- 15/15 tests passed, with costs as reported.
- The bit-flip test is a `fail` test. Aiken would also pass it if the check returned False. The trace `BLST_POINT_NOT_ON_CURVE` and the 55.7 M CPU cost do show that it aborted at decoding.

**Limits:**

- **Cost model.** The costs come from Aiken v1.1.21's built-in cost model. `cli-protocol-params.body` contains a provider-reported PlutusV3 cost model and `maxTxExecutionUnits` of 10¹⁰ steps and 1.75·10⁷ memory, but these were not applied. "≈21% of the step limit" is therefore an Aiken-model number divided by an E0 limit. It is not a Preprod validator or transaction observation.
- **No validator.** No validator, `ScriptContext`, script hash or transaction exists. The `check_*` functions receive constant statement bytes, so the claim that a validator "rebuilds" the statement is not demonstrated.
- **CIP-0381.** I did not inspect the CIP-0381 text. Statements about its encoding and subgroup behaviour rest on the observed agreement: arkworks zcash-format compressed points are accepted by `bls12_381_*_uncompress`.
- **Invalid points.** Only one invalid-point case was tested (the low bit of A's last byte). The point at infinity, non-subgroup points and flag-bit variants were not tested.

---

## 6. Data provenance, selection and controls (mandatory item 3)

### Provenance [E0]

- All retrievals went to one provider, Koios Preprod, through Scrapling `Fetcher` (`fetch.py`).
- Receipts cover 13 requests. One returned 404 (`robots.txt`); one returned 413, and its body is preserved (`tx-cbor-5292012-5292041.body`: "Payload too large … below 5120 bytes"). The batch counts of 45 and 148 hashes give the 193 candidates.
- `fetch.py:4–5` says "No … retries", but the code passes `retries: 1` (`fetch.py:22`). This is a documentation inconsistency (F8).
- Recomputing the txids and agreeing with the provider's `tx_info` (output 1: credential `a20fbf…`, 1,000,000 lovelace) are local consistency checks on one provider's bytes. The block, block-tx, tx-CBOR and tx-info endpoints are not independent sources.
- Two provider fields disagree with the CBOR. Neither affects the bound claim, but both show that provider-decoded fields are not authoritative (F7):
  - `tx_size` is 735, but `selected-tx.cbor` is 736 bytes.
  - Output 0 is reported with a `datum_hash` and a null `inline_datum`, but the CBOR carries an inline datum.
- `is_valid = 0xf5` lies outside the body, so it is not bound.

### Selection and Amendment A1

- The frozen rule matched 0 of 193 transactions (`x0-select*.log`, exit 3).
- A1 was written after an **unlogged-output** shape diagnostic of the data (listed in `unloggedCommands`) and before any build. It is a data-informed rule change. It is disclosed, and for an existence demonstration it raises no soundness concern.
- A1 selected the first of 16 eligible transactions, ordered by (height, slot) with stable provider order inside a block. Order within a block is a provider ordering, not authenticated block order.
- The planned "other-shape real tx" control became a header-byte mutation, as documented in A1.

### What each control establishes, and what it cannot

| Control | Establishes | Cannot establish |
|---|---|---|
| X2 statement-field mutations (txid, credential, network label, template, weaker threshold) | The verifier's public inputs are exactly the digest of the exact statement. | That the network label or any other constant is a proved fact. |
| X2 body-suffix, header and credential mutations | Honest-algorithm witnesses fail at the named constraint, and the forced proofs do not verify. | Knowledge soundness against adversarial provers, which is assumed. |
| X3 unbound control | With the two binding equalities removed, a holder of the witness produces a verifying proof for a statement claiming txid = 0³². Relabelling by an observer fails, because of LibsnarkReduction's input rows. Binding is a constraint, not a declaration. | Anything about other proof systems. Also note the X3 VK reuses the P-L0 identity constants (see F2). |
| x + r alias (`mrg16.ak:285–293`) | Aiken's `bls12_381_g1_scalar_mul` reduces scalars mod r, so a raw check that accepts redeemer scalars accepts aliases. | A Groth16 soundness break. It is a statement-encoding malleability hazard. `check_*` cannot alias. |
| Re-randomization | Proofs are malleable, so proof bytes are not an identity. | — |
| Forced R1 with a u128-wrapped post-state | The honest algorithm over an unsatisfied witness yields a non-verifying proof. | An adversarial-prover result. |
| Cross-VK (X2 ↔ X4) | The two circuit-specific VKs do not accept each other's proofs. | — |

**Bound versus unbound.** Bound (E1/E2): the body bytes, txid, credential, coin ≥ T, and the `pay` arithmetic over a declared pre-state. Not bound: inclusion, phase-2 validity, signatures, network, the pre-state's existence, unspentness and finality. Equality of txid and hash values with provider data is not authentication.

---

## 7. X6 catalogue, admission and bundle (mandatory item 4)

**What the bundle and catalogue bind [inspection]:**

- `BUNDLE.v0.json` binds the script's SHA-256, git blob, tree, language, semantics, agreement and action.
- It also binds the verifier profile, two entries (statement hex and digest, proof, VK digest and file), a link declaration, and `aggregation.present = false`.
- `CATALOGUE.v0.json` separates semantic entries (each identified by the BLAKE2b-256 of its file) from admission records (predicate, template and VK digests).
- Five rows are labelled proposed and not implemented.
- Both files use the research-only `moriarty-research-g16/` namespace and state that the bridge's missing 42 + 52 rows are not recovered. I did not reconstruct any of those rows.
- **Aggregation is explicitly absent, and I confirm that no aggregate or recursive artefact exists.**

**Consumer checks C1–C8 (`main.rs:529–612`):**

| Check | What the code does | Note |
|---|---|---|
| C1 | Unkeyed BLAKE2b over `serde_json` of the bundle without its digest field | Integrity only, not authenticity. Every tamper test simply recomputes it. "Sealed by a bundle digest" (`REPORT.md:196`) should not be read as authentication. |
| C2 | SHA-256 of the script file at a **fixed path**, `data/moriarty/payment.mori` (`main.rs:632`), compared with `bundle.script.sha256` | — |
| C3 | Catalogue entry looked up by `predicateDigest`; file digest re-checked | — |
| C4 | Admission record must match (predicate, template, VK) digests; VK file digest checked | — |
| C5 | Statement tag, predicate, template and digest checked. The tag is chosen by **`entryName`** (`main.rs:568`), and only bytes 0..15 are compared. | — |
| C6 | Program digest compared with the script **only when `entryName == "P-M0"`** (`main.rs:576`) | F1 |
| C7 | Byte equality over the ranges listed in the bundle's own `links` | — |
| C8 | Groth16 verification, with scalars derived from `statementDigest` | — |

**Logged outcomes [log].** All tamper outcomes are as stated:

| Tamper | Refused at |
|---|---|
| B1 | C1 |
| B2 | C2 |
| B3 | C3 |
| B4 | C4 |
| B5 | C8 |
| B6 | C7 |
| B6b | C8 |
| B7 | C8 |

The positive case passed C1–C8.

**Shared fields and links.** I agree with the author that C7 only checks consistency here, because P-M0 re-proves the P-L0 relation. The links are also chosen by the bundle, and the consumer has no policy requiring any link or any entry (F1).

**Design findings** are F1 and F2 in §8.

---

## 8. Findings

Severities are my judgment for a research artefact. None is a deployment-severity vulnerability, because nothing is deployed.

| ID | Severity | Finding | Locators | Evidence |
|---|---|---|---|---|
| **F1** | Medium (X6 proposal and consumer) | **Script binding is bypassable by the bundle author.** C5's tag selection and C6's program-digest check depend on the bundle-supplied `entryName`. The links are also supplied by the bundle, and no entry or link is required. A bundle that renames the P-M0 entry (for example to `"P-M0x"`), drops or retargets its link, and claims script S′ with `script.sha256 = SHA-256(S′)` would pass C1–C8 against a consumer whose script file is S′, while its only Moriarty proof attests `payment.mori`. A bundle with only a P-L0 entry likewise "binds" any script. | `main.rs:568, 576, 583–592, 632`; `make_bundle.py:126–131` | [inspection]; not executed |
| **F2** | Medium (X6 design) | **The predicate digest compiled into the circuit does not identify the relation, and the catalogue is not pinned.** `unbound()` uses `consts(d,false)`, the same tag, P-L0 predicate digest and template digest as X2 (`main.rs:390, 257`; `mrg16.ak:170`, where `stmt3_forged` carries `750e9ca9…`). Anyone who can add one admission record mapping P-L0 to the X3 VK could have the forged txid = 0³² statement accepted at C3, C4, C5 and C8. The bundle records only the catalogue's `file` and `version`, no digest (`make_bundle.py:120`), and the consumer never hashes the catalogue. B5 shows only that swapping VKs between two circuits with **different** predicate constants fails at C8. It must not be read as "pairing protects against admission tampering". | as listed | [inspection]; not executed |
| **F3** | Low–Medium (evidence chain) | **Gaps in the binding of source, binary and run** (details in §4): no build-time source or binary digests; `assemble.py` and the `run_all.sh` invocation unlogged; run-1 `gen_aiken.py` unlogged and missing from `unloggedCommands`; working directory unrecorded for the run-1 `aiken check`; build-g16-2's exit also grep-masked and not annotated; `select_tx.py` content replaced after its logged runs; the run-1 X6 result mislabelled as pre-final-source. The two disclosed masked failures (build-g16, build-g16-3) and the stale-binary exit 101 are correctly preserved and annotated. | `COMMANDS.json` build-g16, build-g16-2, x5-aiken-check, x6-*, `unloggedCommands`; `RESULTS.json:447`; `assemble.py:100–106` | [log] and [inspection] |
| **F4** | Low (claim accuracy) | **"43 of 43 … behaving as frozen in advance" is broader than the plan.** `PLAN.md` §6–7 froze the positive case, R1–R4, A1 ("amount ≠ coin") and the X2/X3/X4 mutation families. It did not freeze R5, the network-label and template-digest mutations, M-program-digest, M-pre-payer, X3.observer-reuse, the specific C1–C8 and B1–B7 tampers, or several of the Aiken refusals. Their expectations were written into source before their first run, but not into the frozen plan. There was also undocumented plan drift: P-M0's id changed from `…pay.exec/v0` to `…pay.exec-over-cardano-output/v0`, and the plan's "seed recorded" (`PLAN.md:117`) became an unrecorded `/dev/urandom` seed (`main.rs:31–36`). That second change is a security improvement, since a recorded seed would let anyone rederive the trapdoor, but it is unlabelled. No pre-execution digest of PLAN exists. | `REPORT.md:12`; `FINAL-RESPONSE.md:9`; `PLAN.md:96–132` | [inspection] |
| **F5** | Low (coverage) | `requires amount > 0` was never isolated, though a labelled derived-mutation vector was feasible (§3.5). By inspection the constraint is correct. | `circuit.rs:161–168`; `final-x4-combined.log:8` | [inspection], [log] |
| **F6** | Low (oracle provenance) | The `moriref` oracle was built against a freshly resolved lockfile, not the Core workspace's `Cargo.lock` (`serde_json` 1.0.154 vs 1.0.151; `sha2` 0.11.1 vs 0.11.0). "Matching worktree pin" holds for the toolchain only. The impact on pure `u128` semantics is negligible. | `build-moriref.log:1, 43, 57`; `merged-core/Cargo.lock:3459–3460, 3504–3505` | [log] and [inspection] |
| F7 | Info | Provider anomalies: `tx_size` 735 against a 736-byte CBOR, and output 0's datum fields. Neither affects bound claims; they confirm the E0 caveat. | `tx-info-9e6dfe33.body`; `PUBLIC-BINARY-ENCODINGS.json` | [inspection] |
| F8 | Info | `fetch.py` docstring "no … retries" against `retries: 1` in the code. | `fetch.py:4–5, 22` | [inspection] |
| F9 | Info | Consumer robustness: `unwrap()` panics instead of structured refusals; file paths are taken from the bundle and catalogue and resolved under root; the verifier profile, Aiken digest, git blob and tree are descriptive only and checked by nothing. The `main.rs` header comment omits `bundle`. | `main.rs:2, 529–612` | [inspection] |
| F10 | Info | Coverage of invalid encodings is limited to one bit flip (§5). | `main.rs:349–363`; `mrg16.ak:254–256` | [inspection] |

I found no Critical or High finding, and no soundness defect in X1–X4.

---

## 9. Agreement and dissent with author claims

| Author claim | My position |
|---|---|
| A Groth16 proof verified for bound bytes of `9e6dfe33…` with output 1 ≥ 1,000,000 to `a20fbf…` (X2) | **Agree** [log + inspection], as E1+E2 under an honest setup |
| A combined `pay` proof verified, with a post-state equal to the oracle and the frozen expectation (X4) | **Agree** for this vector. One hand-lowered action; vector-evidenced only. |
| "Bytes bound to a public txid, plus arithmetic." No chain, Preprod, phase-2, unspentness or finality claim. | **Agree** |
| 41 const and 541 free bytes; the prefix-determinism argument | **Agree** for this shape (independent parse, §3.2) |
| X3: a public input is bound only by a constraint | **Agree** |
| Field wrap cannot be exploited | **Agree** (argument, not proof) |
| `requires amount > 0` is unexercised | **Agree**. I add that isolating it was feasible (F5). |
| X5: 15/15; about 2.13·10⁹ CPU under Aiken's model; live costModels not applied | **Agree**. Byte identity with the Rust artefacts is confirmed. |
| "One verification ≈ 21% of the 10·10⁹ step limit" | **Agree only as labelled**: an Aiken-model number over an E0 limit, with no validator or ScriptContext overhead. |
| The scalar-alias test means a validator must derive scalars itself | **Agree** |
| X6: "Seven tampered bundles were each refused at the intended check" | **Agree** as an observation |
| X6: the bundle "binds the script", and C1–C8 "fail closed" as a design | **Dissent** (F1, F2). Fail-closed against the tested tampers only. Script and relation binding are not enforced against an adversarial bundle, and the catalogue is unpinned. |
| "The VK cannot appear inside the semantic entry …; admission must be separate" | **Agree**, with the addition from F2: the admission is then the sole relation binding and must itself be authenticated. The circuit's predicate constant is not a relation identifier. |
| "43 of 43 … as frozen in advance" | **Dissent in part** (F4) |
| "Single run of `scripts/run_all.sh` on the final source" | **Agree it is consistent; dissent that it is bound** (F3) |
| The run-1 directory is the "binary before the bundle subcommand" | **Dissent for X6** (F3) |
| Two failed builds logged as exit 0; one stale-binary run | **Agree**, and add a third grep-masked exit (build-g16-2, a success) (F3) |
| The research setup is untrustworthy by construction; trapdoor from `/dev/urandom`, discarded in-process | **Agree** with the limitations in §10 |
| The bridge's 42 + 52 rows are untouched; separate namespace | **Agree** |
| Worktree HEAD `e9558f90…` ≠ `fe01bc8…`, tree `223d3ad5…` matches | Noted. I cannot verify it independently; the SELECTION `source_tree` agrees. |

---

## 10. Setup, proof and security limitations (mandatory item 6)

**Setup [inspection].**

- Each setup and each proof draws a fresh 32-byte seed from `/dev/urandom` into ChaCha20 (`main.rs:31–36, 195–207`).
- `circuit_specific_setup` generates the trapdoor internally and never returns it. No proving key, trapdoor or witness is written by any code path I read.
- "Discarded" means dropped at scope end, without zeroization, in a process the author controlled.
- No receipt can attest non-retention. RESULTS' `privateMaterial: none persisted` is consistent with the source but not independently verifiable.
- The same party set up and proved. A third party therefore gains no assurance from the proofs beyond trusting the author, but the witnesses are fully public, so the relation can be re-checked natively without Groth16.

**Proof system.**

- Knowledge soundness is assumed (AGM/GGM, honest setup). The forced proofs exercise only the honest prover algorithm.
- Each VK is circuit-specific and shape-specific. A new transaction shape needs a new circuit and setup.
- Proofs are re-randomizable, so they are not identities.

**What remains unproven:** inclusion, phase-2 validity, signatures, network identity, existence of the pre-state, unspentness, finality, effects and emits, asset identity, compiler correctness, ZKIRv3/Midnight correspondence, and any universal property.

**Authority.** Current Midnight, SDK, native and old-campaign authority remains **zero**. Nothing here was or may be used as native evidence.

---

## 11. Blockers and required amendments

There is **no blocker** to preserving this as a scoped research result.

Before anyone reuses or cites the X6 design, the catalogue or bundle format, or the 43/43 figure, these amendments are **required**:

1. Key C5 and C6 on the catalogue semantic entry (its predicate digest and claim kind), never on `entryName`. Consumer policy must require that every bundle naming a script contains an admitted computation-execution entry whose statement program digest equals that script.
2. Pin the catalogue by digest in the bundle, and treat admission records as an authenticated trust root (signed or otherwise anchored). Make the circuit's predicate constant commit to the relation, for example to an R1CS/circuit digest. Control circuits such as X3 must never carry production predicate or template identities.
3. Add a negative X6 test for F1 (an entry renamed with a foreign script) and for F2 (an admitted unbound VK). Expect refusal.
4. Add the isolating `requires amount > 0` derived-mutation vector.
5. For any rerun, record source and binary digests at build time, log every generator and assembler run, and run builds with `pipefail`.
6. Correct the "frozen in advance" wording to distinguish what the PLAN froze from expectations fixed in source before the run.

---

## 12. What an approval here does and does not mean

`APPROVE_SCOPED_RESEARCH_RESULT` approves only what I restate in §9 with "Agree". That is:

- the X0–X5 observations and their E1/E2 interpretation for one transaction shape and one hand-lowered action
- the X3 and X5 hazard demonstrations
- the X6 tamper refusals as observations

It does **not** approve:

- the X6 binding design, the catalogue or bundle format, or C1–C8 as a security mechanism (F1, F2)
- any wording I dissent from (F3, F4)

It is not deployment, ledger acceptance, production or ceremony security, general compiler or circuit correctness, a Core semantics audit, bridge acceptance or catalogue reconstruction, or native, Midnight or SDK evidence. It closes no U0–U7, M1–M17, MC, SP or G exit; every one of them remains open.

The original Core oracle and conformance packets were not changed or adopted, and they are not security-test coverage of this experiment.

**Terminal verdict: `APPROVE_SCOPED_RESEARCH_RESULT`**