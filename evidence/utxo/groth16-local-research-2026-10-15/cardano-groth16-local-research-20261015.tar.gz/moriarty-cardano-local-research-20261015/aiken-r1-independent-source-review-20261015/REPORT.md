# REPORT: Independent security review of Aiken revision 1 (C0 / S_settle0), X7 public outputs, offline-execution request, and B2 lifecycle

## 0. Reviewer, method and evidence limits

| Item | Value |
|---|---|
| Reviewer | Claude Opus 5.5, model ID `claude-opus-5-5`. "High" effort was requested; I cannot observe the effort setting. |
| Independence | I did not write the revision-1 source, its tests, fixtures, documents, votes, the X7 audit, VOTE.md, or the X7 Rust code or results. The authors are the same model family, so my independence is at the level of context, not model. My votes are counted as **V4**. The other voters are V1 = VOTE.md, V2 = X7 audit, V3 = revision-1 author. |
| Method | Tool-free and read-only. I made no Read, Bash, build, test, hash, network, SDK, key, wallet or ledger action. Every statement below comes from the supplied text. |
| Hashes | I did not recompute any digest. I checked digests only by string comparison across the supplied documents. For example, the `SOURCE-MANIFEST-R1` entries match the input manifest. Changed files are `abi_test.ak` `643b56…`, `c0.ak` `465075…` and `context_test.ak` `7a082e…`. The five unchanged files equal the attempt-2 digests. |
| Not supplied, so not reviewed | Rust `abi.rs`/`relations.rs`, `abi_ref.py`, catalogue files, `Cargo.lock`, upstream `Verify.hs`, the attempt-2 `PROMPT.md`, the `aiken` CLI crate (`crates/aiken/src`), and aiken **v1.1.21** source. The compiler source supplied is v1.1.24+ (`Cargo.toml:8`). |
| Scope rules | I treat the historical "unmerged full language" wording and the upstream "Verify.hs rejects identity points" claim as **corrected, not facts**. Current Midnight/native authority stays at zero. Public compile, prove and deploy remain permissionless. This is operational review, not product admission. I make no live Preprod claim. The X7 relations target the frozen `moriarty/1` worktree, not current Moriarty `6c7…` (parent `9c63…`, PR54 merged). Correspondence to current source is **unverified**. |

Labels used below:

| Label | Meaning |
|---|---|
| **[SRC]** | Read from supplied source |
| **[OBS]** | Read from the supplied X7 outputs. These are observations by the Rust job, not re-run here. |
| **[INF]** | My inference |
| **[PROP]** | Proposal |
| **[UNVERIFIED]** | Not established from the supplied material |

---

## 1. Verdicts, kept separate

| Layer | Verdict |
|---|---|
| Aiken revision-1 source (`lib/pvc/c0.ak`, test deltas) | **ACCEPT for bounded offline UNIT execution.** I found no blocking defect by inspection. F-A is implemented correctly, F-B is a correct no-op, and F2 is consistent. There is one non-discriminating probe (F-R1-3) and six weak legacy refusals (F-R1-4). |
| ABI | **No blanket adoption.** Votes are per row (§9). |
| `EXECUTION-REQUEST-R1.json` as written | **CHANGES_REQUIRED (request hygiene, not source).** The wrapper drops logs for A0, A2, A8 and A9. A1 is self-defeating under the wrapper. Variable values contain prose. The SOURCE-MANIFEST/pin files are not hash-checked. Empty-directory cache creation is not detected. |
| Execution eligibility | **A0–A10 and V0–V4 are review-eligible under the exact commands in §8.3.** These keep the same semantics and the same resource boundary. Root authorization is still required. |
| Preprod, ledger, financial | **None.** Open blockers: B-C (raised in severity, §5), B2 (§10), B3 physical value, the proof re-wrap property (F-R1-1), and all general tracks (§12). |
| Rust X7 | **Not assessed for acceptance.** I used only byte-consistency facts from its public outputs (§6). |

---

## 2. F-A: signer on both release paths

**Implementation [SRC]**
- `lib/pvc/c0.ak:86` adds `list.has(self.extra_signatories, env.refund_vkh)` as an unconditional conjunct.
- `c0.ak:57-62` adds `after_expiry`, which applies `Finite(t) -> t > env.expiry` with no signer clause.
- `c0.ak:87-93` keeps the `or {settle_outref spent, after_expiry}` gate.
- This matches the N1′ text exactly.

**Coverage trace.** I traced all nine E-CTX-4′ tests (`context_test.ak:442` onward):

| Test | Reaches | Result | Discriminates? |
|---|---|---|---|
| `release_with_settle_outref_spent_ok` | all clauses true | True | positive base |
| `…without_signer_refused` / `…wrong_signer_refused` | `list.has` False | False | yes, value test |
| `release_signer_without_settle_or_expiry_refused` | `or`: no thread input; `placeholder` range is `everything` → `NegativeInfinity` → False | False | yes |
| `release_refund_after_expiry_ok` | Finite(1001) > 1000, signer present | True | positive |
| `…at_expiry`, `…unbounded`, `…without_signer` | single clause | False | yes |
| `release_token_kept_in_output_refused` | signer present; only `!list.any(holds_policy)` fails | False | yes; correctly isolated |

**Security judgment**
- **Deposit capture: closed.** The claimant's key signs the whole body, so it controls every output.

**F-R1-1: claim-usage exclusivity is not provided (Medium, design) [SRC+INF].**
- The statement contains neither `refund_vkh` nor `expiry` (`abi.ak` `statement`).
- The Issue redeemer publishes `(vk, proof)`, and the X7 claim files publish them too.
- So any party can **re-wrap** a proof into a new envelope with their own `refund_vkh` and `expiry`, and mint a second claim token. The asset name differs, but Issue accepts it.
- For a context-bound claim, the copy binds to the same thread outref. A front-runner can therefore settle the thread with the copy. The transition is identical (no soundness loss), but the original claimant's claim is stranded until its expiry, and refund is the only way out.
- Consequences:
  - `REVIEW.md` §4 consequence 1 ("A third party cannot use someone else's … P-L1 claim without them") is **false as stated**. The X7 audit itself noted that context-free claims "can be re-wrapped by anyone".
  - `REVIEW.md` §4.2 ("F-H resolved by F-A") holds only for the original token, not for copies.
  - Correct statement: **N1′ protects the claim UTxO's value. It does not make a proof or claim usable only by its issuer.**
  - Mitigations: use a short `expiry` now. Proposal P2 (§11) closes the gap.

**Minor (conservative, no action needed).** `after_expiry` ignores `is_inclusive` (`c0.ak:59`). An exclusive `(1000, ∞)` bound is refused even though every point in it is after 1000. This fails closed.

---

## 3. F-B: generic `Interval`

- **[SRC]** `lib/aiken/interval.ak:42` reads `pub type Interval<a>`. I recounted the lines.
- `IntervalBound<a>` and `IntervalBoundType<a>` follow it. `ValidityRange = Interval<Int>` (`cardano/transaction.ak`).
- The stale `// TODO: Replace 'Int' with a generic 'a'` at `interval.ak:15` likely explains the audit's mistaken recollection.

**Conclusion.**
- The attempt-2 annotation `-> Interval<Int>` was valid.
- The revision-1 `fn after(t: Int)` (`context_test.ak:428`) infers the same type, so the edit is a no-op.
- The local `after` does not collide with stdlib `interval.after`, because that function is not imported unqualified.
- **Agree with REVIEW §2: no defect; robustness edit only.**

---

## 4. F-N: long byte strings and the Aiken encoder oracle

**Fixture F2 bytes [SRC].** I recomputed every byte by hand.

| Item | Check | Result |
|---|---|---|
| Statement length | 112 + 2 + 35 + 1 + 66 + 67 + 130 + 131 | **544** ✓ |
| u16 prefixes | `0040 / 0041 / 0080 / 0081` | ✓ |
| CBOR length | 5 + 102 + 1 + 3 + 39 + 6 + 66 + 67 + 3 + 67 + 66 + 1 + 2 + 67 + 66 + 3 + 3 + 30 + 1 | **598** ✓ |
| Chunk encodings | 64 → definite `5840`; 65 → `5f 5840… 41… ff`; 128 → `5f 5840… 5840… ff` (no empty trailing chunk); 129 → `…41d4 ff` | ✓ |
| Remaining fields | `True` = `d87a80`, `Some` = Constr 0 `d8799f`, `expiry` = `1903e8` | ✓ |
| Agreement across copies | `F2-EXPECTED.json` hex = `abi_test.ak:245-261` concatenation = `gen_f2_fixture.py` assembly | identical byte sequence ✓ |

**Oracle classification**
- **Expected CBOR bytes:** same-author, derived from the same rule as Rust `abi::cbor` and `abi_ref.py`.
- **`builtin.serialise_data` at A6:** the first non-author check of chunking. It is Aiken's uplc/pallas implementation, **not** the ledger's Haskell `serialiseData`. Agreement with the ledger is a residual that only Preprod observes.
- **`f2_scalars_match_frozen` and `f2_asset_name_matches_frozen`:** Python `hashlib` BLAKE2b-256 against the Aiken builtin. This is a genuine two-implementation check. I cannot verify the digest values themselves.

**X7 evidence that strengthens F-N [OBS].** The X7 envelope CBOR already uses the chunked forms:
- **L1:** 118-byte payload encoded as `5f 5840<64> 5836<54> ff`.
- **M1:** pre and post `5840 5840 582b`, effects `… 5838`, payload `5831`.
- The generated tests `{l1,m1}_asset_name_matches_x7` therefore cross-check Rust chunking against Aiken at V2–V3.
- Together with F2, this covers the 64/65/128/129 boundaries and realistic sizes. Both remain UNIT-level, not ledger-level.

---

## 5. Compiler-pin decoder risk (B-C) and the E-ABI-8 probes

**Facts [SRC].**
- `CHANGELOG.md` places #1325 and #1331 in **v1.1.23**, after v1.1.21 (2025-12-11).
- Current naming is `expect_decoder_function_name` with `push_type_identity` (`gen_uplc.rs`).
- `get_generic_variant_name` collapses every custom type and `Data` to `"_data"` (`gen_uplc/builder.rs`).

**[INF, recalled, UNVERIFIED for v1.1.21]**
- Before #1331, the cache key was data-type name plus generic variant names.
- So `Option<TransitionV0>`, `Option<ThreadDatum>` and `Option<Data>` would all share one key: `__expect_Option…_data`.
- The first decoder generated is reused for the others.

**Build order matters [SRC].**
- `build_inner` builds the continuation (`then`) **before** calling `self.assignment(...)` for the current `expect`.
- Hoisted function bodies (for example `settle.claim_envelopes`) are built later, during hoisting.

**F-R1-3: probe `decoder_rejects_extra_transition_field_after_option_data` (`abi_test.ak:338-344`) is non-discriminating (Low; evidence quality) [INF].**
- Because of continuation-first build, the `EnvV0` decoder, including the strict `Option<TransitionV0>` decoder, is generated **before** the `Option<Data>` decoder.
- Under a collision, `expect o: Option<Data>` would reuse the strict `TransitionV0` decoder on `Some(#"00")` and error.
- Without a collision, the `EnvV0` decode errors on the 4-field transition.
- Either way the `fail` test passes. **Its pass is not evidence against #1331.** The `EXPECTED-OUTCOMES-R1` §2.3 interpretation is incorrect.
- `decoder_rejects_extra_transition_field` is a valid field-count probe, but it contains no second `Option` decoder, so it cannot test for collisions.

**B-C severity raised (High for Preprod, conditional) [INF].** Consider the real validators:
- **settle0:** spend datum `Option<ThreadDatum>` (`validators/settle0.ak:18`) plus the hoisted `claim_envelopes` with `expect env: EnvV0` (`settle.ak:67`), which contains `Option<TransitionV0>`.
  - Under a collision, a `ThreadDatum`-shaped decoder would validate a 3-field transition (or the reverse).
  - That would reject **every valid** settlement. Threads become unspendable and their min-ADA is locked.
- **c0:** spend `Option<Data>` (`validators/c0.ak:17`) plus `expect env: EnvV0` (`:23`).
  - A strict `TransitionV0` decoder reused on the datum would make every claim unreleasable.
  - Deposits would be locked on both the refund and settlement paths.
- These are liveness and fund-lock failures, not acceptance of forged data, because typed builtins fail closed.
- **No UNIT test can see this.** The tests call library functions with typed arguments, so validator-wrapper datum decoding is never evaluated.

**Smallest repair [PROP, new revision].** Add two **positive** probes that mirror validator decode order:
1. `let raw: Data = Some(td)`, then `expect Some(td2): Option<ThreadDatum> = raw`, then a positive `settle.settle(td2, …)`.
2. `let dd: Data = Some(env_as_data)`, then `expect Some(raw): Option<Data> = dd`, then `expect env: EnvV0 = raw`, then a positive `c0.release(…)`.

Under a collision, at least one of these errors on **valid** data, which makes it discriminating.

**Conclusive closure of B-C.** Either:
- (a) re-pin to ≥ v1.1.23 under a new pin and revision; or
- (b) Scrapling-acquire and audit the v1.1.21 `gen_uplc.rs` decoder naming, and also evaluate the built `plutus.json` validators offline against ScriptContext Data.

B-C does **not** block A6, which is UNIT-only.

---

## 6. X7 public outputs, predictions and chronology

**Byte-consistency checks [OBS].** Text comparison only; no hashing.
- `statement.bin`, `vk.bin` and `proof.bin` equal the claim JSON `statementHex`, `vkHex` and `proofHex`.
- The generated-test constants equal those, and their `vk_digest` and `predicate_digest` equal the admission records.
- **VK layout assumption A1 is confirmed from real bytes.** Issue-redeemer chunk 6 of L1 is `a319…3452 | 0300000000000000 | a60e…4a84`. That places the u64-LE IC count at bytes 336..344. M1 is the same.
- The proof is 192 bytes and the VK is 488 bytes.

**Predictions against observations [OBS].** These all match the attempt-2 `EXPECTED-OUTCOMES` and the X7 audit §4.3/§7:
- constraints 361,339 and 307,482;
- binding-hi #361,337 and #307,480;
- R1–R5 #1,557, #1,428, #529, #1,815, #658;
- L1 #4,920 and #259,960;
- S6 has 21 lines, S10 has 8, S11 has 14;
- the M1 payload;
- statement lengths 236 and 733.

**E-X7-4 and E-X7-7 [OBS].**
- R1CS digests are unchanged under vk_digest and outref changes for both rows.
- Setup with `vk_digest = 0`, then proving with the real digest, verified.

**Chronology**

| Item | Finding |
|---|---|
| Attempt-2 predictions | Frozen in `SOURCE-FREEZE.json` at 07:54:54Z |
| Rust result files | Carry **no timestamps** in the supplied set. "Predicted before observed" is consistent but **not provable** from these records. |
| R1 freeze | `FREEZE-1.json` is at 08:33:12Z, inside the author process window (08:18–08:42). It lists `source/aiken` still byte-identical to attempt 2. This is consistent with "expectations before assertions", but it is author-attested; there is no external timestamp authority. |
| Unchanged since freeze | `EXPECTED-OUTCOMES-R1` (`6ec065…`) and `F2-EXPECTED` (`029ba4…`) are unchanged in the final manifest ✓ |

**F-R1-6: L1 and M1 VKs are UNIT-only (Info).**
- `7b014d…` (L1) and `8e1ae7…` (M1) have **no proving key**: `x7 run` drops it.
- They are also bound to the DECLARED outref `44³²#1`.
- They must never be pinned in any thread slot.

---

## 7. Refusal discrimination (non-vacuity)

**Revision-1 value tests are discriminating. [SRC]**
- **Issue (E-CTX-5′).** If a targeted `and` clause were removed, evaluation would reach `bls12_381_g1_uncompress(07…)` and error. The value test would then fail. The control `issue_junk_vk_fails_at_point_decoding` confirms that path, and `and` is lazy (`BinOp::And → delayed_if_then_else`).
- **Settle and genesis (E-CTX-6).** I traced each one against a passing base: `settle_single_transition_ok` and `genesis_ok` with the same slots. Each is a single semantic mutation. `thread_token_missing` changes both the input and the continuation value, which is required to isolate the token clause.

**F-R1-4: weak legacy tests (Low).** Six E-CTX-2 `fail` tests target `and` clauses but pass on *any* error:
- `settle_wrong_post_state_refused`
- `settle_wrong_effects_digest_refused`
- `settle_pre_state_mismatch_refused`
- `settle_claim_for_other_thread_refused`
- `settle_value_changed_refused`
- `settle_slots_changed_refused`

My trace shows each fails for its intended reason, but the framework does not enforce that. **Repair (next revision):** convert them to `!settle.settle(...)`.

The remaining `fail` tests correctly target `expect` refusals.

**F-R1-7: vacuous expectation (Info).**
- `EXPECTED-OUTCOMES-R1` G-4′ and A8 say "the C0 hash differs from any attempt-2 build".
- No attempt-2 build exists (S9 was blocked), so this is unfalsifiable.
- Reword to "recorded; no prior hash exists".

---

## 8. Offline placement plan and execution request

### 8.1 Placement mechanism (v1.1.24 source) [SRC]

- `Manifest::load` (no `aiken.lock` present) → `resolve_versions`, with no network and `requirements: vec![]`.
- `remove_extra_packages` keeps the placed stdlib only if the `packages.toml` (name, version) exactly equals the manifest's. `"v2.2.0"` ✓.
  - **Note:** a mismatch would `remove_dir_all` the placement.
- `missing_local_packages` is empty because `is_git_sha_or_tag("v2.2.0")` is true. So `Downloader::new` and `Client::new` are never reached, and neither are `CacheKey` or `packages_cache()`.
- `LatestRelease` is reached only from `ProjectConfig::default`.

**[INF] Bounded risk for v1.1.21.**
- A normal network install produces the same on-disk tree: the zipball is extracted with the first path component stripped into `build/packages/aiken-lang-stdlib`.
- stdlib v2.2.0 is used routinely with v1.1.9–v1.1.21.
- So `fuzz`-importing modules being pruned or ignored on that path is strong evidence that placement behaves the same.
- **Residual:** the `aiken` CLI crate was not supplied, so its other code paths are [UNVERIFIED]. The no-network namespace contains this risk.

### 8.2 Request defects (`EXECUTION-REQUEST-R1.json`)

| ID | Defect | Effect |
|---|---|---|
| X-1 | `bash -c '<cmd> 2>&1 \| tee log'` with `&&` lists: the pipeline binds to the **last** command only | A2's version gate output, A8's `aiken build` output, and A0/A9 outputs are not logged. Exit codes are still correct. **Fix:** `{ <cmd>; } 2>&1 \| tee`. |
| X-2 | A1 under the wrapper: `tee $TASK/logs/…` opens before `mkdir` | tee exits 1 → pipefail → A1 deterministically "fails" |
| X-3 | Variable values contain prose (`TASK`: "…(must not exist…)") | Must be clean absolute paths |
| X-4 | A0 checks `SOURCE-MANIFEST-R1.sha256` but not its own digest mechanically, and never checks `PIN/SOURCE-MANIFEST.json` or `SOURCE-PIN.json` | A consistently tampered pin set would pass `place_stdlib.py` |
| X-5 | `post_check.py:19-20` `files_under` counts files only | Empty `aiken/packages` **directory** creation (EXPECTED-OUTCOMES-R1 §4) goes undetected |
| X-6 | The stop rule prevents A7 after a failing A6 | BLOCKED vs FAILED cannot be classified mechanically. A7 is read-only, so it should run as a diagnostic. |
| X-7 | V2 regenerates the vectors but does not compare them with the existing `out/generated/x7_vectors_test.ak` (`c90b97…`), and the Rust outputs are not digest-checked | Add `sha256sum -c` and `cmp` |
| X-8 | Python steps run with `cd /tmp` (world-writable) | `-I` already excludes cwd; `cd /` is free hardening |

### 8.3 Exact review-eligible commands

These are under the already-requested boundary: no network namespace, empty task-local HOME and cache, `--as` 32 GiB, `nice 10`, core 0, stop at first failure, and source and tool pins.

```bash
# Root-recorded, clean absolute paths:
export REV=/home/charl/moriarty-eutxo-validation-2026-10-12/claim-utxo-aiken-revision-1-20261015
export PIN=/home/charl/moriarty-eutxo-validation-2026-10-12/aiken-stdlib-v220-source-20261015
export ATT2=/home/charl/moriarty-eutxo-validation-2026-10-12/claim-utxo-prototype-source-20261015/implementation-attempt-2
export RUSTOUT=$ATT2/rust-research-execution-1/out
export TASK=$REV/aiken-offline-check-1  TASK2=$REV/aiken-offline-check-vectors-1
export AIKEN=<root-recorded absolute path>  PY=<root-recorded absolute python3 path>

run_step() {  # run_step LOGDIR ID WALL 'CMD'
  nice -n 10 timeout --kill-after=60 "$3" prlimit --as=34359738368 --core=0 -- \
    bash -o pipefail -c "{ $4
} 2>&1 | tee \"$1/$2.log\""
  echo $? > "$1/$2.exit"
}
```

**A-steps (offline Aiken check and build)**

```bash
# A1 (no wrapper; atomic; writes nothing if TASK exists)
mkdir "$TASK" && mkdir "$TASK/logs" "$TASK/receipts" "$TASK/empty-home" "$TASK/empty-xdg-cache" && echo 0 > "$TASK/logs/A1.exit"

# A0: manifest and pin digests
run_step "$TASK/logs" A0 60 'cd "$REV" && sha256sum -c SOURCE-MANIFEST-R1.sha256 && printf "%s  %s\n" 284885367cae95cba0233739bd13ab6b7025a2a5203aa179dbe169c9cd8437aa SOURCE-MANIFEST-R1.json ab499f47f36d54095929cb615c071bb66d30ea4f923fa445752427848b46b411 SOURCE-MANIFEST-R1.sha256 4a170a307fdc1db5b4ef91a7eee44d1951bf6fe9a6563983b69680717b2a1cf8 REVIEW-INPUT.json | sha256sum -c - && cd "$PIN" && printf "%s  %s\n" a26daa087fae05f9b35a06ed382d20e92e4d1ea8b76b59947134b7e4b2197266 SOURCE-PIN.json e44ed44783d17f4cb0b58c59f98a75bc09fc64c793dd25f3ab56b4097cdf1b1c SOURCE-MANIFEST.json 90c07de94ebf858f0d78292a9482cfa3b2b45767ed85fd381e74c0463cdf9b51 stdlib-source.tar.gz | sha256sum -c -'

# A2: toolchain (version gate is mechanical and logged)
run_step "$TASK/logs" A2 60 'v="$("$AIKEN" --version)" && printf "%s\n" "$v" && readlink -f "$AIKEN" "$(command -v unshare)" && sha256sum "$AIKEN" "$PY" "$(command -v unshare)" > "$TASK/receipts/tools-sha256.txt" && cat "$TASK/receipts/tools-sha256.txt" && "$PY" --version && case "$v" in *v1.1.21*) true;; *) false;; esac'

# A3: sandbox probe (must show only lo)
run_step "$TASK/logs" A3 30 'unshare --user --map-root-user --net -- cat /proc/net/dev && test "$(unshare --user --map-root-user --net -- awk "NR>2{print \$1}" /proc/net/dev)" = "lo:"'

# A4: placement
run_step "$TASK/logs" A4 120 'cd / && "$PY" -I "$REV/tools/place_stdlib.py" "$REV" "$PIN" "$TASK/run" "$TASK/receipts/placement.json"'

# A5: freeze run tree before check
run_step "$TASK/logs" A5 60 'cd / && "$PY" -I "$REV/tools/freeze.py" "$TASK/receipts/run-before.json" "run tree before aiken check" "$TASK" run'

# A6: offline aiken check
run_step "$TASK/logs" A6 1800 'cd "$TASK/run" && unshare --user --map-root-user --net -- env -i PATH=/usr/bin:/bin HOME="$TASK/empty-home" XDG_CACHE_HOME="$TASK/empty-xdg-cache" NO_COLOR=1 "$AIKEN" check'

# A7: ALWAYS runs after A6 (read-only diagnostic); then stop if A6 or A7 is non-zero
run_step "$TASK/logs" A7 60 'cd / && "$PY" -I "$REV/tools/post_check.py" "$TASK/receipts/placement.json" "$TASK/empty-home" "$TASK/empty-xdg-cache" "$TASK/receipts/post-check-A6.json" && test -z "$(find "$TASK/empty-home" "$TASK/empty-xdg-cache" -mindepth 1 -print -quit)"'

# A8: offline aiken build, blueprint digest, validator hashes
run_step "$TASK/logs" A8 900 'cd "$TASK/run" && unshare --user --map-root-user --net -- env -i PATH=/usr/bin:/bin HOME="$TASK/empty-home" XDG_CACHE_HOME="$TASK/empty-xdg-cache" NO_COLOR=1 "$AIKEN" build && sha256sum plutus.json > "$TASK/receipts/plutus-json-sha256.txt" && cat "$TASK/receipts/plutus-json-sha256.txt" && cd / && "$PY" -I -c "import json,sys; d=json.load(open(sys.argv[1])); [print(v[\"title\"], v.get(\"hash\")) for v in d[\"validators\"]]" "$TASK/run/plutus.json" > "$TASK/receipts/validator-hashes.txt" && cat "$TASK/receipts/validator-hashes.txt"'

# A9: post-check after build, then freeze run tree
run_step "$TASK/logs" A9 120 'cd / && "$PY" -I "$REV/tools/post_check.py" "$TASK/receipts/placement.json" "$TASK/empty-home" "$TASK/empty-xdg-cache" "$TASK/receipts/post-check-A8.json" && test -z "$(find "$TASK/empty-home" "$TASK/empty-xdg-cache" -mindepth 1 -print -quit)" && "$PY" -I "$REV/tools/freeze.py" "$TASK/receipts/run-after.json" "run tree after aiken build" "$TASK" run'

# A10 (after A9.exit exists; outside the wrapper so no log is open)
cd / && "$PY" -I "$REV/tools/freeze.py" "$TASK/receipts/task-final.json" "all task logs and receipts" "$TASK" logs receipts; echo $? > "$TASK/A10.exit"
```

**V-steps (generated proof verification)**

Run these only if A0–A10 all exited 0, `post-check-A6/A8` show `allHold: true`, and A6 reports 76/76 as listed in EXPECTED-OUTCOMES-R1.

```bash
# V0 (no wrapper; atomic)
mkdir "$TASK2" && mkdir "$TASK2/logs" "$TASK2/receipts" "$TASK2/empty-home" "$TASK2/empty-xdg-cache" && echo 0 > "$TASK2/logs/V0.exit"

# V1: digest checks, then placement
run_step "$TASK2/logs" V1 120 'cd "$REV" && sha256sum -c SOURCE-MANIFEST-R1.sha256 && cd "$RUSTOUT" && printf "%s  %s\n" 2108993b3210c4ff86cf2831e17352c99c764b9867a8e479ba6b0395cf25ec81 L1/claim.json 4b9c407c5d24df5184e6b67d471470fefd6bb623aa02dfaa14c01585fc874bd0 M1/claim.json c90b97c90adbd2f5c19adae86c134718e642b63212ab24a5776100f733b1e3fa generated/x7_vectors_test.ak | sha256sum -c - && cd "$ATT2/source/scripts" && printf "%s  %s\n" 80c59ff72bef7363f72204a08be82bf333fb781a721a78431ccedc7eab0f9ea7 gen_x7_aiken.py | sha256sum -c - && cd / && "$PY" -I "$REV/tools/place_stdlib.py" "$REV" "$PIN" "$TASK2/run" "$TASK2/receipts/placement.json"'

# V2: regenerate vectors and compare with the existing generated file
run_step "$TASK2/logs" V2 60 'cd / && "$PY" -I "$ATT2/source/scripts/gen_x7_aiken.py" "$RUSTOUT" "$TASK2/run/lib/pvc/x7_vectors_test.ak" && sha256sum "$TASK2/run/lib/pvc/x7_vectors_test.ak" > "$TASK2/receipts/generated-aiken-sha256.txt" && cat "$TASK2/receipts/generated-aiken-sha256.txt" && cmp "$TASK2/run/lib/pvc/x7_vectors_test.ak" "$RUSTOUT/generated/x7_vectors_test.ak"'

# V3: offline aiken check with vectors (expect 89 = 76 + 13)
run_step "$TASK2/logs" V3 1800 'cd "$TASK2/run" && unshare --user --map-root-user --net -- env -i PATH=/usr/bin:/bin HOME="$TASK2/empty-home" XDG_CACHE_HOME="$TASK2/empty-xdg-cache" NO_COLOR=1 "$AIKEN" check'

# V4: ALWAYS runs after V3 (diagnostic)
run_step "$TASK2/logs" V4 60 'cd / && "$PY" -I "$REV/tools/post_check.py" "$TASK2/receipts/placement.json" "$TASK2/empty-home" "$TASK2/empty-xdg-cache" "$TASK2/receipts/post-check-V3.json" && test -z "$(find "$TASK2/empty-home" "$TASK2/empty-xdg-cache" -mindepth 1 -print -quit)"'
```

**Conditions**
- Use no other commands, and do not retry.
- Any compile or test failure is FAILED, with everything preserved; a fix means a new revision and a new TASK directory.
- Any fetch or cache evidence is BLOCKED.
- Record the E-ABI-8 third probe's result as **non-evidence** (F-R1-3).
- No keygen, proof generation, wallet, network, ledger or Rust step is involved.
- Resources: about 10 pairing evaluations in V3, plus 2 in A6. The caps are ample.
  - Residual: glibc arena reservations under `RLIMIT_AS` on very high-core hosts. Low risk. If A6 fails with allocation errors, record it as FAILED-resource.

**What an A6 or V3 pass would and would not establish**

| Would establish (UNIT level only) | Would not establish |
|---|---|
| Compilability under v1.1.21 | ExUnits fit or fees |
| Aiken/pallas chunked CBOR | Ledger `serialiseData` equality |
| The CIP-0381 verifier accepts arkworks proofs for X7 statements | Validator-wrapper decoding (B-C) |
| UNIT logic of issue, release, genesis and settle | Any settlement semantics |

---

## 9. Votes on REVIEW.md rows (V4)

Counts are for the **exact text in the row**, not blanket approval.

| Row | V4 vote | Exact condition or dissent | Resulting count |
|---|---|---|---|
| D1 | AGREE | Effects are bytes; "value unchanged" (`settle.ak:110`) must be replaced before any physical claim | 4 |
| D2 literal ("at mint **and at release**") | DISSENT | Release has no kind check | 1 agree / 2 dissent (V3, V4); V2 "deviation accepted" |
| D2′ | AGREE | — | 3 (V2, V3, V4) |
| D3 literal | DISSENT | — | 1 agree / 3 dissent |
| D3′ (pinned pair) | AGREE | — | 3 |
| D4 | AGREE + **amendment D4-a** | "Envelope fields outside the statement (`expiry`, `refund_vkh`, and for context-free claims `settle_outref`) are issuer-chosen and not proof-bound; one proof may back many envelopes." | D4: 4; D4-a: 1 (first vote) |
| D5 + ordering rule | AGREE | — | 4 / 3 |
| D6, D8, D10, D11 | AGREE | — | 4 each |
| D7 + conditions | AGREE | — | 4 / 3 |
| D9 checks | AGREE | — | 4 |
| D9 implicit no-signer | DISSENT | — | rejected |
| D12 + limitation | AGREE | — | 4 / 3 |
| N1 refund branch | AGREE | — | 3 |
| N1 "settlement release, no signer" | DISSENT | — | 0 / 3: rejected |
| **N1′** | **AGREE on the exact text** | **DISSENT** on REVIEW §4 consequence 1 wording (F-R1-1). Correct wording: "protects claim value; not usage exclusivity" | **3** |
| N2, N3, N4, N6, N7, N10 | AGREE | — | 3 each |
| N5 | AGREE | Note: one own-script input structurally precludes multi-parent and merge (§12) | 3 |
| N8 | AGREE (weak) | — | 3 |
| N9 | AGREE | — | 3 |
| F-I (reject O for γ, δ, ic1, ic2) | AGREE | **Correct the REVIEW §5.1 rationale.** δ = O does **not** make `e(A,B)=e(α,β)` "satisfiable by anyone"; the `e(L,γ)` term remains. The real cases: γ = O makes the proof statement-independent; ic1 or ic2 = O unbinds one 128-bit half, leaving about 64-bit collision binding. All of this is defence-in-depth, since the pinned VK already trusts its setup operator. | 3 (rationale disputed) |
| F-E (alternative context) | AGREE "not in v0"; **DISSENT on V3's rationale** | (thread_id, seq) context lets a *pre-planned* sequence be proved immediately after setup and the PK discarded before genesis. It removes B2 for fixed-horizon threads, though not interactive ones. v1 candidate. | v0: 1 for / 2 against → not adopted |
| F-H "resolved by F-A" | DISSENT in part | Resolved for the original token only (F-R1-1) | 1 / 1 |
| F-Q | AGREE (v1) | — | 3 |
| gnark/BSB22 pin rule | AGREE | — | 3 |
| §11 admission fields | AGREE | Add `pkSha256` when a PK is persisted | 3 (not implemented) |
| B-C as Preprod blocker | AGREE + amendment | Probes as written cannot detect it (§5); closure route (a)/(b); severity High conditional | 2 |
| O-1 | Agree (observation) | — | — |
| R-5 | AGREE | Plus the PK file-permission issue (§10) | 2 |

---

## 10. B2-PROVING-KEY-LIFECYCLE: independent second vote

**Fixed circuit and public-variable future outrefs**
- **[SRC]** The R1CS is fixed per (row, predicate constants). `template_env` zeroes witness positions.
- `settle_outref`, `vk_digest`, pre-state and amount are **free witnesses reflected into statement bytes**. The Groth16 public inputs are only the two 128-bit halves of `BLAKE2b(statement)`.
- **[OBS]** E-X7-4 shows equal R1CS digests under outref and vk changes for both rows. E-X7-7 verified a proof whose `vk_digest` differed from setup time.
- So **one PK proves any future outref and any reachable pre-state.** This is observed, not just predicted.
- The blocker is **temporal**:
  - setup must precede genesis, because the slot pins the VK immutably (N5);
  - each step's outref exists only after its predecessor body is final.

**Material classes**

| Class | Content | V4 view |
|---|---|---|
| T | Trapdoor, plus the 32-byte ChaCha20 seed from `rng()`, which regenerates it deterministically. Includes all setup-process intermediates. | Soundness-critical |
| PK | Group encodings only | Not soundness-critical and not ZK-critical |
| R | Per-proof seed | ZK-critical in general; moot for the current rows, whose witness is public |

**Votes**

| B2 section | V4 | Exact text or condition |
|---|---|---|
| §0 rationale | AGREE + amend | Add: "Persistence is needed for steps whose context or pre-state is unknown at setup time. Under ABI v0 that is every context-bound step." No outref is assumed known before genesis ✓. |
| §1 T (incl. seed): never serialized; crash means VK compromised | **AGREE** | Separate-process persistence is *better* than a long-lived setup+prove daemon. Freed setup memory, which may hold T because arkworks does not zeroize, dies with the setup process. |
| §1 R, W | AGREE | — |
| §1 PK "private by policy" as the default normative rule | **DISSENT; amendment B2-A1** | "PK is public-safe. It MAY be published, in which case anyone can prove for threads pinned to its VK, and the setup operator is not a liveness gatekeeper. Consistent with permissionless proving. Keeping it private is an operational choice recorded with its liveness consequence, never a soundness control." |
| §2 key source | AGREE | — |
| §3 L0–L4 | AGREE + **B2-A2** | `cmd_setup` writes with `std::fs::write(&pk_out, …)` (attempt-2 `main.rs`, `cmd_setup`), which creates the file with umask default permissions (typically 0644). If kept private: `O_CREAT\|O_EXCL`, mode 0600 at creation. L3: verify `pkSha256` **before** deserialization and `H(ser(pk.vk))` against the expected digest; this is a liveness and integrity check, not soundness, since a wrong PK yields proofs rejected by the pinned digest. |
| §4 publication | AGREE, modified by B2-A1 | — |
| §5 sequence and rollback | AGREE | Issue may precede confirmation of the predecessor (D10). Only settlement needs the confirmed outref. |
| §6 wallet keys | AGREE | `refund_vkh` custody window = claim life (N1′) |
| §7 | AGREE | Add **B2-A3**: "x7 `run` VKs `7b014d…`/`8e1ae7…` have no PK; UNIT-only; never pin." |

**Result.** T/R/W classification and the never-persist-T rule: **2 agreeing votes** (V3, V4). PK-privacy-as-default: 1 for, 1 dissent.

**This design vote is not execution authority.**

---

## 11. Proposals (labelled [PROP]; nothing authorized)

**P1: reusable PK and future-step outref (x7, Rust; minimal)**
- `setup --pk-out`: exclusive create; mode 0600 if private; refuse paths under task or repository roots; write `pkSha256` and the §11 fields into the admission record.
- `prove`:
  - `--pk` with `--expect-pk-sha256` and `--expect-vk-digest`;
  - `--outref` (a confirmed UTxO);
  - `--pre-msb0-hex` and `--amount`, replacing the hard-coded `[0, PAYER0, 0, 0]` / `AMOUNT` in `row_of` (F-E capability gap). Decode MSB0 and require byte-identical re-encoding.
  - Keep the existing satisfied-before-prove assertion.
- Tests:
  - one setup, two outrefs, two sequential pre-states (post of step *k* = pre of step *k*+1), all verified by one VK;
  - refusal on PK or VK digest mismatch.

**P2: proof-bound claimant (ABI v1)**
- Add `refund_vkh` (and optionally `expiry`) to the statement as free-witness bytes, as `vk_digest` already is.
- Copies then carry the original claimant's key and cannot be settled without them. This closes F-R1-1.
- Requires a new R1CS and a new setup.

**P3: physical value and effects (ABI v1, settle)**
- Add `TransitionV1 { pre, post, effects, ledger_delta }`.
  - `ledger_delta` is computed **in-circuit** from effects and a constant account→(credential, asset→(policy, name, scale)) map pinned in the catalogue row.
  - It is a canonical list of payouts and custody totals, so the script never parses MSB0.
- Settle replaces `cont.value == own.value` (`settle.ak:110`) with:
  - continuation value = own value − Σ payouts;
  - per-asset custody equals the post totals;
  - each payout output is **tagged** (inline datum `(thread_id, seq, i)`) to defeat double satisfaction;
  - debit authority via `extra_signatories` for mapped debtor keys.
- Liabilities need their own representation.

**P4: current generic compiler correspondence**
- Replace hand lowering with lowering generated from current Moriarty IR (commit `6c7…`, PR54 merged; source not reviewed here).
- The catalogue digest binds the IR digest and compiler commit.
- Run a differential harness against `mori_core::simulate` over exhaustive small domains and boundary vectors, including Core error codes.
- Until this exists, no correspondence claim is made.

**P5: B-C closure**
- Re-pin to ≥ v1.1.23, or audit v1.1.21 decoder naming.
- Add the positive mirror probes from §5.
- Run offline UPLC evaluation of the built validators against ScriptContext Data.

---

## 12. Findings index

| ID | Severity | Location | Finding | Disposition |
|---|---|---|---|---|
| F-R1-1 | Medium (design) | `abi.ak` `statement`; REVIEW §4 c1, §4.2 | Proof re-wrap: N1′ protects value, not usage; front-run strands the original claim until expiry | P2; correct the wording; use a short expiry |
| F-R1-2 | High-conditional (Preprod) | `validators/settle0.ak:18`, `validators/c0.ak:17,23`, `settle.ak:67` | Pre-#1331 decoder collisions could brick both validators; invisible to UNIT tests | B-C blocker; P5 |
| F-R1-3 | Low (evidence) | `abi_test.ak:338-344`; EXPECTED-OUTCOMES-R1 §2.3 | Collision probe passes either way | Record as non-evidence; R2 probes |
| F-R1-4 | Low | `context_test.ak` E-CTX-2 (6 tests) | `and`-clause refusals as `fail` tests | Convert to value tests |
| F-R1-5 | Low | REVIEW §5.1 F-I | δ = O rationale incorrect | Corrected in §9 |
| F-R1-6 | Info | X7 `out/{L1,M1}` | Orphan VKs, no PK, DECLARED context | Never pin |
| F-R1-7 | Info | EXPECTED-OUTCOMES-R1 G-4′, A8 | Vacuous "differs from attempt-2 hash" | Reword |
| X-1 … X-8 | Low–Medium (process) | `EXECUTION-REQUEST-R1.json`, `post_check.py:19-20` | Logging, A1, variables, pin checks, empty directories, diagnostics | Fixed by §8.3 commands |
| B2-A2 | Low | attempt-2 `main.rs` `cmd_setup` | PK written with default permissions | P1 |

**Upstream claim.** The attempt-2 `REPORT.md` §8 statement is superseded by REVIEW §6, as instructed. `Verify.hs` was not in my inputs, so I neither confirm nor dispute its line citations. The immutable attempt-2 file needs an errata note, not an edit.

---

## 13. What remains open (no UNIT slice waives any of these)

- **Not delivered by revision 1 or by this review:**
  - genuine current-Moriarty EUTXO+Groth16/PCD;
  - physical effects and value (ledger value is still carried unchanged; "datum transition certified", never "payment settled");
  - general obligations and liability execution;
  - all 20 retained patterns;
  - recursion;
  - private PCD and private handoff;
  - multi-party and multi-parent composition. N5's single own-input rule structurally precludes merges, so any multi-parent design needs tagged continuations instead.
- **Thread lifecycle:** thread termination and universal certificates remain open.
- **Correspondence:** current-compiler correspondence (P4) is open.
- **Preprod:** remains blocked on B-C, B2, B3, F-R1-1 policy, and separate authorization.