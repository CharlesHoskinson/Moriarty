# Commitment-Groth16 (BSB22-equivalent) prover protocol

Normative for `recovery-circuit`. Supersedes nothing; extends `docs/SPEC.md`
and `docs/07-batch-ears.md`'s verifier-side description with the **prover-side**
construction needed to produce a valid instance.

This document is the single ground-truth artifact the cleanroom
`recovery-circuit` crate is built from. Every rule below is extracted from one
of these authoritative sources and is byte-exact:

- `proto/onchain/redemption/src/Recovery/Verify.hs` — `groth16VerifyCommitted`,
  the verifier actually run on-chain (the byte-exact acceptance oracle).
- `proto/vending/prover/serialize.go` — `SerializeProofCommitment` /
  `SerializeVKCommitment` / `CommitmentChallenge`, the wire encoder that
  produces the deployed artifacts.
- gnark `v0.15.0` `backend/groth16/bls12-381/{prove.go,verify.go}` and
  gnark-crypto `v0.20.1` `ecc/bls12-381/fr/pedersen/pedersen.go` — the BSB22
  Pedersen construction gnark implements (reached in the WSL module cache;
  see the extraction note at the end).

The curve is **BLS12-381**. Two field orders are used throughout:

```
r (scalar field Fr) = 52435875175126190479447740508185965837690552500527637822603658699938581184513
p (base field Fp)   = 4002409555221667393417789825735904156556882819939007885332058136124031650490837864442687629129015664037894272559787
```

Notation: `G1`/`G2` are the BLS12-381 groups; `D` is the single Pedersen
commitment point (G1); `π` is its knowledge-of-opening proof / PoK (G1); `σ` is
the Pedersen setup secret; `e_cmt` is the BSB22 commitment challenge (an `Fr`
scalar); `pub` is the single public input (an `Fr` scalar). `‖` is byte
concatenation; `·` is scalar multiplication on a group; `x·[G]` folds scalar `x`
onto point `G`.

---

## 1. Proof element order and encoding

The committed proof (`crProofC`) is **exactly 336 bytes**, five elements in
this fixed order. Source: `serialize.go:113-118` (layout comment) and
`serialize.go:176-204` (`SerializeProofCommitment`); decoder offsets in
`Verify.hs:112-113, 179-195`.

| Offset | Len | Element | Group | Encoding |
|-------:|----:|---------|-------|----------|
| `[0,48)`    | 48 | `A` = `proof.Ar`  | G1 | compressed |
| `[48,144)`  | 96 | `B` = `proof.Bs`  | G2 | compressed |
| `[144,192)` | 48 | `C` = `proof.Krs` | G1 | compressed |
| `[192,288)` | 96 | `D` = `proof.Commitments[0]` | G1 | **UNCOMPRESSED** `X‖Y` |
| `[288,336)` | 48 | `π` = `proof.CommitmentPok`  | G1 | compressed |

Constants (`serialize.go:36-41, 124-132`): `g1Len=48`, `g2Len=96`,
`CmtOff=192`, `PokOff=288`, `ProofCommitLen=336`.

### 1.1 Compressed encoding (A, B, C, π)

Every compressed point is the gnark-crypto `G1Affine.Bytes()` / `G2Affine.Bytes()`
output — the standard BLS12-381 ZCash/IETF form, byte-identical to
`blst_p1_compress` / `blst_p2_compress` and consumed verbatim by the Cardano
`bls12_381_G1_uncompress` / `bls12_381_G2_uncompress` builtins
(`serialize.go:12-17`). The flag bits are load-bearing and MUST be preserved:

- The three most-significant bits of **byte 0** are flags:
  - bit 7 (`0x80`) — compression flag, **always 1** for these elements.
  - bit 6 (`0x40`) — infinity flag, 1 iff the point is the identity.
  - bit 5 (`0x20`) — sort/sign flag, 1 iff `y` is the lexicographically-larger
    root, i.e. iff `y > p − y` (equivalently `y > (p−1)/2`). For G2 the
    "larger" test is the Fp2 lexicographic order on `y = (y.A0, y.A1)`
    (gnark-crypto `LexicographicallyLargest`).
- The remaining bits hold the `x`-coordinate big-endian:
  - **G1 (48 bytes):** 381-bit `x` — byte 0 masked to its low 5 bits, then
    bytes `1..47`, big-endian.
  - **G2 (96 bytes):** `x ∈ Fp2`, `x = x.A0 + x.A1·u`, serialized
    **`X.A1 ‖ X.A0`** — the `A1` (imaginary) limb first in bytes `[0,48)`
    (its byte 0 carrying the flag bits), the `A0` limb in bytes `[48,96)`, each
    a 48-byte big-endian Fp element (gnark-crypto `marshal.go:1138-1141`).
    (No G2 point is carried uncompressed in this wire format; only the G1
    commitment `D` is uncompressed — §1.2 — where `X`, `Y` are single Fp
    elements.)

### 1.2 Uncompressed commitment encoding (D)

`D` is carried **uncompressed** as `BE48(X) ‖ BE48(Y)` = 96 bytes, exactly
`proof.Commitments[0].Marshal()` (`serialize.go:190`, `Verify.hs:182-183`).
It is emitted uncompressed so the verifier hashes the *identical* 96 bytes gnark
hashes when deriving `e_cmt` (see §5). There are **no flag bits** in this
encoding: `X` and `Y` are raw big-endian base-field elements, each `< p`, so the
top 3 bits of `X`'s first byte are `000`. A cleanroom implementer MUST NOT
compressed-encode `D` (that would produce a 288-byte, chain-rejected proof — see
`docs/superpowers/cleanroom-clarification-log.md` CL-003).

---

## 2. VK element order and commitment-key semantics

The committed verifying key (`pVkC`) is **exactly 672 bytes**, nine elements in
this fixed order. Source: `serialize.go:106-111` (layout comment),
`serialize.go:134-171` (`SerializeVKCommitment`); decoder offsets in
`Verify.hs:110-111, 168-177`; cross-checked against `README.md:454-470`.

| Offset | Len | Element | Group | Role |
|-------:|----:|---------|-------|------|
| `[0,48)`    | 48 | `alpha` = `vk.G1.Alpha` | G1 | Groth16 |
| `[48,144)`  | 96 | `beta`  = `vk.G2.Beta`  | G2 | Groth16 |
| `[144,240)` | 96 | `gamma` = `vk.G2.Gamma` | G2 | Groth16 |
| `[240,336)` | 96 | `delta` = `vk.G2.Delta` | G2 | Groth16 |
| `[336,384)` | 48 | `IC0` = `K0` = `vk.G1.K[0]` | G1 | public-input fold, constant term |
| `[384,432)` | 48 | `IC1` = `K1` = `vk.G1.K[1]` | G1 | public-input fold, `pub` basis |
| `[432,480)` | 48 | `K2` = `vk.G1.K[2]` | G1 | commitment-hash fold, `e_cmt` basis |
| `[480,576)` | 96 | `CK.G` = `vk.CommitmentKeys[0].G` | G2 | Pedersen PoK base (`G`) |
| `[576,672)` | 96 | `CK.GSigmaNeg` = `vk.CommitmentKeys[0].GSigmaNeg` | G2 | Pedersen PoK base (`G^{−σ}`) |

All nine points are compressed (§1.1). Constants (`serialize.go:124-132`):
`VKLen=432`, `K2Off=432`, `CKGOff=480`, `CKGSNOff=576`, `VKCommitLen=672`. The
432-byte prefix is the vanilla VK (`SerializeVK`, `serialize.go:65-97`).

### 2.1 K0 / K1 / K2 semantics

`vk.G1.K` holds exactly **three** IC points for this circuit — one public input
plus one commitment (`serialize.go:146-148`). Their roles in the public-input
fold (§3) are:

- `K0` — the constant IC term (`ONE_WIRE`), added unconditionally.
- `K1` — the basis for the single public input `pub`.
- `K2` — the basis for the commitment-hash scalar `e_cmt`. In gnark this is the
  IC point of the "commitment wire" whose solved value is `e_cmt` (see §3, §5).

### 2.2 Commitment-key semantics

The Pedersen commitment key contributes two G2 points to the VK:

- `CK.G` = `G`, the Pedersen G2 generator.
- `CK.GSigmaNeg` = `G^{−σ}`, the generator raised to the negated setup secret.

These are the *only* two commitment-key points the verifier needs; the prover
side additionally holds the G1 `Basis[]` and `BasisExpSigma[]` vectors (§4)
which never appear in the VK or proof. Normative shape constraints, both
enforced at serialization (`serialize.go:146-151`) and required of any
cleanroom key:

- `len(vk.G1.K) == 3` (exactly IC0, IC1, K2).
- `len(vk.CommitmentKeys) == 1` (exactly one Pedersen commitment).
- `vk.PublicAndCommitmentCommitted == [[]]` — a single commitment whose list of
  committed *public* wire indices is **empty** (`serialize.go:137-140, 170`).
  This is what makes the §5 challenge message just the commitment point with
  nothing appended.

---

## 3. Committed wire(s) and public-input fold

### 3.1 What is committed

The production Recovery circuit's lookup-table hashing (gnark `std/math/uints`
range-checks in every Blake2b / SHA-512 / Ed25519 gadget, plus `logderivlookup`)
routes range checks through `api.Commit`. gnark aggregates **all** committed
wires across the whole circuit into **exactly one** Pedersen commitment
(`proto/circuit/FULL-CIRCUIT-K.md:64-66, 160`; confirmed by
`GetCommitments().CommitmentIndexes()` length `== 1`). So there is one
commitment `D`, one PoK `π`, and one extra IC point `K2`.

The committed values `values[]` fed to the Pedersen `Commit` are the circuit's
**private committed wires** (gnark `commitmentInfo[0].PrivateCommitted`), solved
from the full witness by the BSB22 hint (`prove.go:69-84`). A cleanroom prover
does not choose these; they are determined by the witness and the circuit's
committed-wire set. `D` is therefore deterministic given (setup, witness) — there
is no blinding randomness in `D` (`pedersen.go:117-131`, `Commit` is a plain MSM).

### 3.2 The public-input fold (vk_x)

The verifier folds the public input and the commitment into a single G1 point
`vk_x`. Source: `Verify.hs:206-210`, matching gnark `verify.go`'s
`kSum = K[0] + Σ_i publicWitness_i·K[i≥1] + Σ commitments` where, for this
circuit, `publicWitness = [pub, e_cmt]`, `K[1]=IC1`, `K[2]=K2`:

```
vk_x = K0 + pub·[K1] + e_cmt·[K2] + D
```

Exactly (`Verify.hs:207-210`):

```
vkX = ic0
       + (pub  · ic1)
       + (e_cmt · k2)
       + commitment
```

`Hash(D)` (the nonlinear hash-to-field of the commitment, §5) enters `vk_x`
**twice-linked**: as the scalar `e_cmt = Hash(D)` on basis `K2`, *and* the raw
commitment point `D` is added directly. Both terms are mandatory (this is
gnark's BSB22 folding; omitting either admits adaptive-commitment forgeries —
`docs/07-batch-ears.md` REQ-B-23a). The verifier MUST recompute `e_cmt` itself
from `D` and MUST NOT accept a prover-supplied `e_cmt` or committed-wire value.

### 3.3 The public input `pub`

`pub` is the single public scalar. The 32-byte value on the wire (`pub.hex`) is
the raw Blake2b-256 digest of the domain-separated preimage
(`README.md:109`: `Blake2b-256(domain_sep ‖ scriptHash ‖ snapshot_version ‖
root ‖ C ‖ entitlement ‖ D_addr ‖ role)`; full preimage layout is
`docs/SPEC.md` §3 / Task 2). It is interpreted **little-endian** and reduced
mod `r` (`Verify.hs:204-205`: `byteStringToInteger LittleEndian pubBytes
modInteger r`):

```
pub = OS2IP_LE(pub_bytes[0:32]) mod r
```

---

## 4. Commitment and PoK equations

Source: gnark-crypto `pedersen.go` (`Setup`, `Commit`, `ProveKnowledge`,
`Verify`, `BatchVerifyMultiVk`), gnark `prove.go:84,110-127`, and the on-chain
check in `Verify.hs:196-200`.

### 4.1 Setup (defines the key material)

`pedersen.go:63-100`. Given the commitment basis `Basis[] ⊂ G1` and a G2
generator `G`, sample secret `σ ∈ [1, r−1]` and set:

```
GSigmaNeg      = (−σ)·[G]                    (G2, published in VK)
BasisExpSigma[j] = σ·[Basis[j]]              (G1, prover-only)
```

`G` and `GSigmaNeg` go in the VK (§2.2); `Basis[]` and `BasisExpSigma[]` are the
prover's proving key. `σ` is the trusted-setup secret and MUST be discarded.

### 4.2 Commitment

`pedersen.go:117-131`. The commitment is the MSM of the committed values over
the basis:

```
D = Σ_j values_j · [Basis_j]                 (G1)
```

### 4.3 Proof of knowledge

`pedersen.go:104-115` (`ProveKnowledge`) and `prove.go:110-127`. The PoK is the
same MSM over the σ-shifted basis; for the single-commitment case the batch
`Fold` (`prove.go:127`) is the identity, so:

```
π = Σ_j values_j · [BasisExpSigma_j] = σ · D    (G1)
```

### 4.4 Verifier PoK check

`pedersen.go:187-201` (single-commitment `Verify`) and `Verify.hs:196-200`. The
check is:

```
e(D, GSigmaNeg) · e(π, G) == 1_GT
```

equivalently (the form `Verify.hs` evaluates):

```
e(π, G) == e(−D, GSigmaNeg)
```

This holds by construction: `e(D, G^{−σ}) · e(σ·D, G) = e(D,G)^{−σ} · e(D,G)^{σ}
= 1`. `σ`'s role is to bind `π` to `D` through the pairing so that a prover who
does not know an opening of `D` cannot forge `π`.

**Single-commitment degeneracy (why no batch challenge appears).** gnark's
general verifier folds multiple commitments with a Fiat-Shamir coefficient
`fr.Hash(commitmentsSerialized, "G16-BSB22", 1)` (`verify.go:102-108`). For
this circuit's single commitment that coefficient **drops out**:
`BatchVerifyMultiVk` never scales `commitments[0]` (only indices `i ≠ 0` are
scaled) and `Fold` of a one-element PoK vector is the identity
(`pedersen.go:253-266`). The on-chain verifier therefore correctly omits the
`G16-BSB22` challenge entirely (`Verify.hs:196-200`). A cleanroom implementer
with exactly one commitment MUST NOT introduce it. (The `G16-BSB22` DST is
distinct from, and unrelated to, the `bsb22-commitment` DST of §5.)

---

## 5. Hash-to-field challenge transcript (e_cmt)

`e_cmt` is the BSB22 commitment challenge. It is **derived by the verifier from
`D` alone**; the prover contributes nothing but `D`. Source: `prove.go:88`,
`verify.go:82-101`, `constraint.SerializeCommitment`
(`gnark/constraint/commitment.go:77`), `hash_to_field.go` + `fr.Hash`, mirrored
byte-for-byte in `Verify.hs:140-162, 201-203` and validated in `ecmt_test.go`.

### 5.1 Message

```
m = SerializeCommitment( D.Marshal()[96B uncompressed], publicCommitted = ∅, 32 )
  = D.Marshal()                                (exactly the 96 bytes X‖Y from §1.2)
```

Because `PublicAndCommitmentCommitted == [[]]` (§2.2) the `publicCommitted` list
is empty, so `SerializeCommitment` appends nothing: the message is **exactly the
96-byte uncompressed commitment**, `proof_c[192:288]`
(`serialize.go:206-234`, `Verify.hs:183, 202`).

### 5.2 Domain-separation tag

```
DST = "bsb22-commitment"                       (16 ASCII bytes = 0x62..0x74)
```

`constraint.CommitmentDst` (`gnark/constraint/commitment.go:7`),
`Verify.hs:136-138`.

### 5.3 Expansion and reduction

```
e_cmt = OS2IP_BE( expand_message_xmd(SHA-256, m, DST, len_in_bytes = 48) ) mod r
```

`len_in_bytes = 48` gives `ell = 2` (three SHA-256 calls). The expansion is
RFC 9380 exactly (`Verify.hs:140-162`, `ecmt_test.go:17-51`), with
`DST' = DST ‖ I2OSP(len(DST),1) = DST ‖ 0x10`:

```
Z_pad = 0x00 × 64                              (SHA-256 block size)
b0 = SHA256( Z_pad ‖ m ‖ I2OSP(48,2) ‖ 0x00 ‖ DST' )      where I2OSP(48,2) = 0x00 0x30
b1 = SHA256( b0 ‖ 0x01 ‖ DST' )
b2 = SHA256( (b0 XOR b1) ‖ 0x02 ‖ DST' )
uniform_48 = b1 ‖ b2[0:16]                     (32 + 16 = 48 bytes)
e_cmt = OS2IP_BE(uniform_48) mod r
```

The reduced scalar is used as the `K2` coefficient in `vk_x` (§3.2). Its
canonical 32-byte big-endian form is what gnark's `fr.Hash` returns and what the
`ecmt.hex` reference artifact records.

---

## 6. Rejection cases

A verifier MUST reject (fail closed) if any of the following holds. Sources:
`Verify.hs` (the `bls12_381_*_uncompress` builtins validate on-curve **and**
subgroup per CIP-0381), `prove.go:42-44` (`isValid` subgroup check),
`pedersen.go:189-190` (subgroup check), `docs/07-batch-ears.md` REQ-B-02, and
the reference JS verifier `proto/site/modules/verifier.mjs`.

1. **Wrong length.** Reject if the proof is not exactly 336 bytes or the VK is
   not exactly 672 bytes (`verifier.mjs` length guard;
   `serialize.go:167, 200`).
2. **Non-canonical / off-curve / non-subgroup compressed point.** Reject if any
   of the compressed points — VK `alpha, beta, gamma, delta, IC0, IC1, K2,
   CK.G, CK.GSigmaNeg` and proof `A, B, C, π` — fails to uncompress to a valid
   on-curve point in the correct prime-order subgroup. On Cardano the
   `bls12_381_G1_uncompress` / `bls12_381_G2_uncompress` builtins perform both
   checks; a cleanroom verifier MUST perform an explicit subgroup check and
   MUST NOT rely on an uncompress side-effect for any point it assembles itself
   (REQ-B-02).
3. **Malformed commitment encoding.** For the uncompressed commitment
   `D = X‖Y` (`proof_c[192:288]`): reject if `X`'s top bit (`0x80`) is set, or
   if `X ≥ p` or `Y ≥ p` (non-canonical), i.e. `X`/`Y` are not reduced
   base-field elements (`verifier.mjs` `commitmentPoint` throws on a set top
   bit; `Verify.hs:189-194` reconstructs the compressed form assuming
   `X < p`). Reject if the reconstructed `(X,Y)` is not on the curve
   `y² = x³ + 4 (mod p)` or not in the G1 subgroup.
4. **Identity / small-order points.** Reject if the reconstructed `D` or `π` (or
   any consumed VK/proof point) is the identity/infinity point (REQ-B-02:
   "reject identity and small-order").
5. **PoK failure.** Reject if `e(D, GSigmaNeg) · e(π, G) ≠ 1` (§4.4).
6. **Groth16 pairing failure.** Reject if
   `e(A,B) ≠ e(alpha,beta) · e(vk_x, gamma) · e(C, delta)` with `vk_x` per §3.2
   (`Verify.hs:211-216`).
7. **Prover-supplied challenge.** Reject any protocol variant that accepts an
   externally supplied `e_cmt`, `Hash(D)`, or committed-wire value instead of
   recomputing `e_cmt` from `D` per §5 (`docs/07-batch-ears.md`: the term is
   "load-bearing, not defense-in-depth").
8. **Compressed commitment.** Reject a proof that encodes `D` compressed (it
   would be 288 bytes, failing rule 1) — the commitment is uncompressed by
   construction (§1.2, CL-003).

Acceptance is iff the PoK check (rule 5) **and** the Groth16 pairing check
(rule 6) both pass on well-formed inputs (`Verify.hs:217`: `pokOk && mainOk`).

---

## Appendix A — Worked vectors (byte-derived, cross-checked against fixtures)

All vectors are derived **from the rules above** and checked against
`proto/onchain/redemption/testdata-recovery/{proof_c,vk_c,pub}.hex` (the
deployed committed triple). The authoritative oracle is a full
BLS12-381-pairing re-verification of that triple with the reference verifier
`proto/site/modules/verifier.mjs` (`@noble/curves`), which returned
`{ok: true}` — i.e. the current on-disk `{proof_c, vk_c, pub}` is a genuine,
mutually consistent, accepting instance. The vectors below are the load-bearing
intermediate values inside that accepting run.

**WV-1 — commitment challenge `e_cmt` (§5).** Take `m = proof_c[192:288]` (the
96-byte uncompressed `D`), run `expand_message_xmd(SHA-256, m, "bsb22-commitment",
48)`, interpret big-endian, reduce mod `r`:

```
e_cmt = 5a1d375f551dfcf539fda1928bc134ad20d74e243170e082d3a64edabb88324b   (32B BE)
```

This is the exact scalar that makes the full pairing check accept (it is the
`K2` coefficient in `vk_x`). The algorithm is independently confirmed against a
gnark-minted reference: the same derivation over the *previous* deployed proof
(`git 73b5d45`) reproduces that snapshot's `ecmt.hex`
(`25e8c07c1ffd3e629fee979b8bb04b13cf9dad94456e674a19fc983f9f89a562`) byte-for-byte.
**Note:** the on-disk `ecmt.hex` reference artifact is stale relative to the
current `proof_c.hex` (it was not re-minted when `proof_c` was regenerated in
`git c45a7ba`); see clarification-log **CL-007**. `ecmt.hex` is a non-normative
debugging reference — the on-chain verifier recomputes `e_cmt` from `D` and never
reads it.

**WV-2 — commitment point reconstruction (§1.2, §6 rule 3).** With
`X = proof_c[192:240]`, `Y = proof_c[240:288]`:

- `X`'s top 3 bits are `000` (`X < p`) — as required for the uncompressed form.
- `(X, Y)` satisfies `Y² ≡ X³ + 4 (mod p)` — on-curve. ✓
- `Y > p − Y`, so the ZCash sort bit is `0x20`; the reconstructed compressed
  first byte is `X[0] | 0x80 | 0x20`, which uncompresses to the same `(X, Y)`.

This confirms the uncompressed→compressed reconstruction rule the on-chain
verifier uses (`Verify.hs:186-194`).

**WV-3 — public-input reduction (§3.3).** `pub_bytes = pub.hex` (32 bytes).
Interpreted little-endian and reduced mod `r`, the value used as the `K1`
coefficient is:

```
pub = 2095d0e0d9e56fef47d45b0903c4b021edd9d44b7063b1f1d926b5e952b58c74   (32B BE of the Fr element)
```

(Little-endian is load-bearing: interpreting `pub.hex` big-endian yields a
different, wrong scalar and the pairing check fails.)

**WV-4 — structural decode (§1, §2, §6 rule 2).** Every compressed G1 point in
the on-disk triple — proof `A, C, π` and VK `alpha, IC0, IC1, K2` — decodes to a
valid on-curve point with the compression flag set and `X < p`. Combined with
the full-pairing `{ok: true}` result (which also validates the G2 points and
subgroup membership), this confirms the §1/§2 offsets and encodings are exact.

---

## Appendix B — gnark source reachability

gnark's own BSB22 source **was** reachable for this extraction: gnark
`v0.15.0` and gnark-crypto `v0.20.1` are present in the WSL Go module cache
(`/home/charles/go/pkg/mod/github.com/consensys/`). The prover-side construction
in §4/§5 is therefore extracted directly from
`backend/groth16/bls12-381/{prove.go,verify.go}` and
`ecc/bls12-381/fr/pedersen/pedersen.go`, not merely inferred from `Verify.hs`'s
verify-side requirements — and every rule is additionally cross-checked against
`Verify.hs` (the deployed acceptance oracle) and the passing full-pairing
re-verification of the deployed fixture triple (Appendix A).
