{-# LANGUAGE NoImplicitPrelude #-}
-- The PlutusTx plugin cannot unfold GHC-specialiser-generated bindings
-- (e.g. countMatching_$scountMatching from the 'Eq a =>' overload). Disable
-- the specialiser (and SpecConstr) so the INLINABLE polymorphic definitions
-- reach the plugin intact and compile to UPLC.
{-# OPTIONS_GHC -fno-specialise #-}
{-# OPTIONS_GHC -fno-spec-constr #-}

-- | Pure recovery validation logic. Uses only builtins with real off-chain
--   implementations (blake2b_256, bytestring ops), so every function here is
--   unit-testable in plain GHC and is the exact proposition Blaster verifies.
module Recovery.Logic
  ( roleBytes
  , reconstructPub
  , nullifier
  , payCredOf
  , validateClaim
  , valueConserved
  , countMatching
  , ticketNullifiers
  , ticketBurnedFor
  , custodyClaimPresent
  , custodyInputCount
  ) where

import PlutusTx.Prelude
import qualified PlutusTx.Builtins as B
import PlutusLedgerApi.V1.Value (Value)
import Recovery.Types
import Recovery.Entitlement (encodeEntitlement)

-- | Encode the role (0|1|2) as a single byte for the DOM.
{-# INLINABLE roleBytes #-}
roleBytes :: Integer -> BuiltinByteString
roleBytes r = B.consByteString r B.emptyByteString

-- | Reconstruct the single aggregated public input from authenticated context.
--   pub = blake2b_256( domainSep ‖ scriptHash ‖ snapshotVersion ‖ merkleRoot
--                      ‖ C ‖ entitlement ‖ D ‖ role )
{-# INLINABLE reconstructPub #-}
reconstructPub :: Params -> CustodyDatum -> ClaimRedeemer -> Scalar
reconstructPub p d r =
  Scalar $ B.blake2b_256 $
       pDomainSep p
    <> pScriptHash p
    <> pSnapshotVersion p
    <> pMerkleRoot p
    <> cdCredential d
    <> cdEntitlement d
    <> crDestination r
    <> roleBytes (crRole r)

-- | nullifier = blake2b_256( domainSep ‖ scriptHash ‖ C ). Version-STABLE (§8
--   option 1): a pure function of the credential + instance identity, with NO
--   snapshot_version, so a credential's spent-state is keyed identically across
--   snapshot versions at the same scriptHash. Eligibility stays version-scoped
--   because 'reconstructPub' still binds pSnapshotVersion into 'pub'. NO
--   dependence on the proof, the destination, or any witness.
{-# INLINABLE nullifier #-}
nullifier :: Params -> BuiltinByteString -> BuiltinByteString
nullifier p c =
  B.blake2b_256 $
       pDomainSep p
    <> pScriptHash p
    <> c

-- | S3-F1 (V-CONS, input side). The spent custody 'Value' must re-encode to the
--   committed entitlement, so the datum honestly describes the custody UTxO and
--   no surplus value can leave the script unbound. 'validateClaim' already binds
--   the PAYOUT to the entitlement; 'mkValidator' additionally asserts this on the
--   resolved custody INPUT, closing the conservation gap. Pure and unit-testable.
{-# INLINABLE valueConserved #-}
valueConserved :: CustodyDatum -> Value -> Bool
valueConserved d custodyVal = encodeEntitlement custodyVal == cdEntitlement d

-- | Count list elements equal to @x@. Used on-chain by 'mkValidator' to assert
--   exactly one input is spent from this script's own address (S3-F3: reject
--   double-satisfaction where two custody UTxOs share a single payout). Pure and
--   unit-testable in plain GHC.
{-# INLINABLE countMatching #-}
countMatching :: Eq a => a -> [a] -> Integer
countMatching _ [] = 0
countMatching x (y : ys) = (if y == x then 1 else 0) + countMatching x ys

-- | The 28-byte payment credential of a raw 57-byte Cardano (Shelley) base
--   address, header(1) ‖ payment_cred(28) ‖ staking_cred(28) — the key-hash that
--   gates SPENDING the payout UTxO. This is the same slice the recovery circuit
--   constrains (payCredOffset = 1). Used by 'validateClaim' to reject a payout
--   that returns funds to the claimed (compromised) credential.
{-# INLINABLE payCredOf #-}
payCredOf :: BuiltinByteString -> BuiltinByteString
payCredOf addr = B.sliceByteString 1 28 addr

-- | The claim decision. Pure over the three context-derived inputs so it is
--   fully unit-testable and is the exact proposition Blaster verifies.
--
--   verifierOk       : result of groth16Verify(vk, proof, reconstructPub …)
--   (payAddr,payVal) : the payout output the tx makes to the bound destination D.
--                      The on-chain 'mkValidator' locates it with 'findPayout',
--                      which only returns an output whose canonical 'encodeAddr'
--                      equals the 57-byte raw destination D (the M1 credential
--                      binding — raw address bytes, never serialiseData CBOR), so
--                      payAddr == crDestination here and the payout is bound to D.
--   selfAddr         : this validator's own (script) address bytes
--
--   The entitlement check re-encodes the paid 'Value' to the canonical 553-byte
--   entitlement ('encodeEntitlement') and compares it to the custody datum's
--   committed bytes. This is the SAME encoding the recovery circuit witnesses, so
--   the payout vends EXACTLY the entitlement the circuit committed (V-CONS),
--   closing the circuit↔validator encoding gap.
--
--   REQ-V-15 (defense-in-depth mirror of the in-circuit REQ-D1-15): the payment
--   credential of the bound destination D (its first 28 address bytes) must not
--   equal the claimed credential C, so a claim can never return the recovered
--   funds to the (compromised) claimed key. The circuit already makes such a
--   proof uncreatable; re-checking here keeps the two layers in agreement and
--   fails closed if a future circuit/VK regression ever drops the constraint.
{-# INLINABLE validateClaim #-}
validateClaim
  :: Params -> CustodyDatum -> ClaimRedeemer
  -> Bool                            -- verifierOk
  -> (BuiltinByteString, Value)      -- (payAddr, payValue)
  -> BuiltinByteString               -- selfAddr
  -> Bool
validateClaim _p d r verifierOk (payAddr, payVal) selfAddr =
       verifierOk                                  -- proof verified (V-PUB)
    && payAddr == crDestination r                  -- payout goes to the bound D (V-PUB)
    && encodeEntitlement payVal == cdEntitlement d -- exact canonical entitlement (V-CONS)
    && not (crDestination r == selfAddr)           -- bound D is not the script (no-self-pay)
    && not (payAddr == selfAddr)                   -- payout is not to the script (no-self-pay)
    && not (payCredOf (crDestination r) == cdCredential d) -- D's payment cred /= claimed C (REQ-V-15)

-- | The nullifiers of the Ticket datums in a list (Custody datums ignored).
{-# INLINABLE ticketNullifiers #-}
ticketNullifiers :: [RedemptionDatum] -> [BuiltinByteString]
ticketNullifiers [] = []
ticketNullifiers (Ticket t : rest) = tdNullifier t : ticketNullifiers rest
ticketNullifiers (_ : rest)        = ticketNullifiers rest

-- | Spent-state gate for a claim: exactly one INPUT ticket carries nullifier @n@
--   and NO OUTPUT ticket carries it (the ticket is consumed and burned, not
--   recreated). 'ins'/'outs' are the redemption-script datums of the tx's inputs
--   and outputs.
{-# INLINABLE ticketBurnedFor #-}
ticketBurnedFor :: BuiltinByteString -> [RedemptionDatum] -> [RedemptionDatum] -> Bool
ticketBurnedFor n ins outs =
     countMatching n (ticketNullifiers ins) == 1
  && countMatching n (ticketNullifiers outs) == 0

-- | True iff some input Custody datum's credential has nullifier @n@ — i.e. a
--   valid claim for this ticket's credential is present in the tx. Gates the
--   Ticket-spend branch so a ticket cannot be consumed without its claim.
{-# INLINABLE custodyClaimPresent #-}
custodyClaimPresent :: Params -> BuiltinByteString -> [RedemptionDatum] -> Bool
custodyClaimPresent _ _ [] = False
custodyClaimPresent p n (Custody d : rest) = nullifier p (cdCredential d) == n || custodyClaimPresent p n rest
custodyClaimPresent p n (_ : rest)         = custodyClaimPresent p n rest

-- | Number of Custody datums in a list (the ticket-aware double-satisfaction
--   guard counts custody inputs, since tickets are also script inputs).
{-# INLINABLE custodyInputCount #-}
custodyInputCount :: [RedemptionDatum] -> Integer
custodyInputCount [] = 0
custodyInputCount (Custody _ : rest) = 1 + custodyInputCount rest
custodyInputCount (_ : rest)         = custodyInputCount rest
