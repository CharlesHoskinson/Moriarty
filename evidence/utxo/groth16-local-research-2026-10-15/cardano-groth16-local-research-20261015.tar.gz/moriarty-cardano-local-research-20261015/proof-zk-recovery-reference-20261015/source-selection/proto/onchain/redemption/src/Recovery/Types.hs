{-# LANGUAGE NoImplicitPrelude #-}
{-# LANGUAGE TemplateHaskell   #-}
{-# LANGUAGE ViewPatterns      #-}

-- | Frozen interface types for the redemption contract (spec §"Frozen interfaces").
module Recovery.Types
  ( VerifyingKey (..)
  , Proof (..)
  , Scalar (..)
  , Params (..)
  , CustodyDatum (..)
  , TicketDatum (..)
  , RedemptionDatum (..)
  , ClaimRedeemer (..)
  ) where

import PlutusTx.Prelude (BuiltinByteString, Integer)
import qualified PlutusTx

-- | A Groth16 verifying key, opaque at the logic layer (real bytes from sub-project 2/3).
newtype VerifyingKey = VerifyingKey BuiltinByteString

-- | A 192-byte Groth16 proof: A(G1) ‖ B(G2) ‖ C(G1), compressed.
newtype Proof = Proof BuiltinByteString

-- | The single aggregated public input, as the Blake2b-256 digest bytes
--   (reduction into Fr happens inside groth16Verify).
newtype Scalar = Scalar BuiltinByteString

-- | Immutable validator parameters.
data Params = Params
  { pVk              :: VerifyingKey
  , pDomainSep       :: BuiltinByteString
  , pMerkleRoot      :: BuiltinByteString
  , pSnapshotVersion :: BuiltinByteString
  , pScriptHash      :: BuiltinByteString
  }

-- | Datum carried by each custody UTxO (authenticated on-chain state).
data CustodyDatum = CustodyDatum
  { cdCredential  :: BuiltinByteString  -- ^ C = Blake2b-224(leaf pubkey), 28 bytes
  , cdEntitlement :: BuiltinByteString  -- ^ canonical serialisation of the vended Value
  }

-- | A spent-state marker UTxO: a credential's claim ticket, consumed on claim.
data TicketDatum = TicketDatum
  { tdNullifier :: BuiltinByteString  -- ^ version-stable nullifier Blake2b(domainSep‖scriptHash‖C)
  }

-- | The datum carried by every UTxO at the redemption script: either custody
--   funds or a spent-state ticket.
data RedemptionDatum
  = Custody CustodyDatum
  | Ticket TicketDatum

-- | Redeemer the prover supplies.
data ClaimRedeemer = ClaimRedeemer
  { crProof       :: Proof
  , crRole        :: Integer              -- ^ 0|1|2
  , crDestination :: BuiltinByteString    -- ^ D: canonical serialisation of the payout Address
  }

-- Data (CBOR) encodings used by the validator decode and the eval harness.
PlutusTx.unstableMakeIsData ''VerifyingKey
PlutusTx.unstableMakeIsData ''Proof
PlutusTx.unstableMakeIsData ''Scalar
PlutusTx.unstableMakeIsData ''CustodyDatum
PlutusTx.unstableMakeIsData ''TicketDatum
PlutusTx.unstableMakeIsData ''RedemptionDatum
PlutusTx.unstableMakeIsData ''ClaimRedeemer
PlutusTx.unstableMakeIsData ''Params
