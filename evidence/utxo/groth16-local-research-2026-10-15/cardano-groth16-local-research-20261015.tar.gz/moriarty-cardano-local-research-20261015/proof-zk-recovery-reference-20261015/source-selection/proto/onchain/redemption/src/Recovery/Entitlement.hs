{-# LANGUAGE NoImplicitPrelude #-}
{-# LANGUAGE OverloadedStrings #-}

-- | Pure, on-chain canonical entitlement encoder. Encodes a Plutus 'Value' into
--   the 553-byte canonical entitlement that the recovery circuit witnesses and
--   the eligibility snapshot commits, byte-for-byte matching the Go reference
--   encoder (proto/vending/snapshot/snapshot.go : @EncodeEntitlement@) which is
--   the byte arbiter for the whole derivation domain. Layout:
--
--   > ada(8 LE) ‖ count(1) ‖ MaxAssets=8 × ( policy_id(28) ‖ name(32, right-zero-padded) ‖ qty(8 LE) )
--
--   The @ada@ field is the lovelace (@adaSymbol@/@adaToken@) entry pulled out of
--   the Value; only the NON-ada native assets fill the slots, sorted ASCENDING
--   by (policy_id, asset_name) on their raw bytes; slots with index >= count are
--   left zero. More than MaxAssets native assets is rejected ('traceError').
module Recovery.Entitlement
  ( encodeEntitlement
  , maxAssets
  , entLen
  ) where

import PlutusTx.Prelude
import qualified PlutusTx.Builtins as B
import PlutusLedgerApi.V1.Value
  ( Value, CurrencySymbol
  , adaSymbol, adaToken, flattenValue, valueOf
  , unCurrencySymbol, unTokenName )

-- | Maximum number of native assets a single entitlement may carry (drv.MaxAssets).
{-# INLINABLE maxAssets #-}
maxAssets :: Integer
maxAssets = 8

-- | Bytes per asset slot: policy_id(28) + asset_name(32) + qty(8) (drv.SlotLen).
{-# INLINABLE slotLen #-}
slotLen :: Integer
slotLen = 68

-- | Total entitlement length: HeaderLen(9) + MaxAssets(8) * SlotLen(68) (drv.EntLen).
{-# INLINABLE entLen #-}
entLen :: Integer
entLen = 553

-- | Encode @n@ (0 .. 2^64-1) as 8 little-endian bytes (least-significant first),
--   matching @binary.LittleEndian.PutUint64@.
{-# INLINABLE integerToLE8 #-}
integerToLE8 :: Integer -> BuiltinByteString
integerToLE8 n = go (8 :: Integer) n
  where
    go k m
      | k <= 0    = B.emptyByteString
      | otherwise = B.consByteString (m `modulo` 256) (go (k - 1) (m `divide` 256))

-- | @n@ zero bytes (@n <= 0@ yields empty).
{-# INLINABLE zeros #-}
zeros :: Integer -> BuiltinByteString
zeros n
  | n <= 0    = B.emptyByteString
  | otherwise = B.consByteString 0 (zeros (n - 1))

-- | Right-zero-pad a bytestring to exactly @n@ bytes (input length must be <= n).
{-# INLINABLE rpad #-}
rpad :: Integer -> BuiltinByteString -> BuiltinByteString
rpad n bs = bs <> zeros (n - B.lengthOfByteString bs)

-- | Compare two assets ascending by (policy_id, asset_name) on raw bytes.
{-# INLINABLE cmpAsset #-}
cmpAsset
  :: (BuiltinByteString, BuiltinByteString, Integer)
  -> (BuiltinByteString, BuiltinByteString, Integer)
  -> Ordering
cmpAsset (p1, n1, _) (p2, n2, _) =
  case compare p1 p2 of
    EQ -> compare n1 n2
    o  -> o

-- | The (policy 28-byte ‖ name raw bytes ‖ qty) of every NON-ada entry.
{-# INLINABLE nativeAssets #-}
nativeAssets :: Value -> [(BuiltinByteString, BuiltinByteString, Integer)]
nativeAssets v =
  map (\(cs, tn, q) -> (unCurrencySymbol cs, unTokenName tn, q))
      (filter (\(cs, _, _) -> not (isAda cs)) (flattenValue v))
  where
    isAda :: CurrencySymbol -> Bool
    isAda cs = cs == adaSymbol

-- | Concatenate the slot bytes for the sorted assets, then zero-fill the
--   remaining (MaxAssets - count) slots.
{-# INLINABLE slotBytes #-}
slotBytes :: [(BuiltinByteString, BuiltinByteString, Integer)] -> BuiltinByteString
slotBytes = go (maxAssets * slotLen)
  where
    go remaining []                = zeros remaining
    go remaining ((p, n, q) : rest) =
      (p <> rpad 32 n <> integerToLE8 q) <> go (remaining - slotLen) rest

-- | Canonical 553-byte entitlement of a Value. See module header for the layout
--   and the Go arbiter it matches.
{-# INLINABLE encodeEntitlement #-}
encodeEntitlement :: Value -> BuiltinByteString
encodeEntitlement v =
  let ada    = valueOf v adaSymbol adaToken
      sorted = sortBy cmpAsset (nativeAssets v)
      count  = length sorted
  in if count > maxAssets
       then traceError "entitlement: assets exceed MaxAssets"
       else integerToLE8 ada
              <> B.consByteString count B.emptyByteString
              <> slotBytes sorted
