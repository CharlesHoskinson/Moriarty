{-# LANGUAGE DataKinds         #-}
{-# LANGUAGE NoImplicitPrelude #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE TemplateHaskell   #-}
{-# OPTIONS_GHC -fplugin PlutusTx.Plugin #-}
{-# OPTIONS_GHC -fplugin-opt PlutusTx.Plugin:defer-errors #-}

-- | CommitmentVerifier: a Plutus V3 (Plinth) prototype that isolates and
--   measures the COMMITMENT-SPECIFIC delta of verifying a gnark
--   "commitment Groth16" proof on-chain (BSB22 / Pedersen commitment +
--   knowledge-of-opening PoK), per audit/12-commitment-batching-soundness.md §1.
--
--   It does NOT implement the full Groth16 verifier. It measures exactly the
--   operations the commitment path adds ON TOP of a vanilla 3-element Groth16
--   verify (vanilla baseline = docs/SPEC.md §6 ≈ 1.36–1.61e9):
--
--     (H)  hash-to-field of D  (Blake2b -> Fr scalar) — the NONLINEAR step.
--     (F)  fold Hash(D)·K_c (G1 scalarMul) + D (G1 add) into vk_x.
--     (P)  opening PoK pairing  e(D,[-sigma]G) · e(pi,G) = 1 :
--          2 millerLoop + mulMlResult + finalVerify.
--     plus the subgroup-checking uncompress of D, pi (G1) and the commitment
--     vk points K_c (G1), G, [-sigma]G (G2)  (REQ-B-02, audit/12 §4).
--
--   MEASUREMENT METHOD — single-occurrence differencing (the method that makes
--   the uncompress rungs reproduce docs/SPEC.md §6 to the exact digit). Each
--   primitive is measured as the CPU difference between two rungs that are
--   identical except for ONE extra occurrence of the target builtin, with every
--   point variable used so that the let is shared (one uncompress per point).
--   Points enter as DISTINCT function arguments (compressed bytestrings), so the
--   plugin cannot constant-fold them and CSE cannot collapse distinct points.
--
--     G1 uncompress = e2G1 - e1G1            (one extra G1 uncompress)
--     G2 uncompress = e2G2 - e1G2
--     G1 scalarMul  = rSM  - e1G1
--     G1 add        = rADD - e2G1
--     2*millerLoop + finalVerify = rML2 - 2*G1unc - 2*G2unc
--     1*millerLoop  = (rML2 - rML1) - G1unc - G2unc   (cross-check)
--     finalVerify   = rML1 - G1unc - G2unc - millerLoop  (cross-check)
--     hash-to-field = rHASH - e1G1
--   (mulMlResult is taken from the pinned cost model = 2,174,038; it is < 0.2%
--    of the delta and cannot be isolated without constructing an MlResult.)
module CommitmentVerifier
  ( e1G1, e2G1, e1G2, e2G2, rSM, rADD, rML1, rML2, rHASH
  , compiledE1G1, compiledE2G1, compiledE1G2, compiledE2G2
  , compiledRSM, compiledRADD, compiledRML1, compiledRML2, compiledRHASH
  , mkValidator, compiledValidator
  ) where

import PlutusTx
import PlutusTx.Prelude
import PlutusTx.Builtins
    ( BuiltinByteString
    , ByteOrder (BigEndian)
    , bls12_381_G1_uncompress
    , bls12_381_G1_compress
    , bls12_381_G1_add
    , bls12_381_G1_scalarMul
    , bls12_381_G1_equals
    , bls12_381_G1_compressed_generator
    , bls12_381_G2_uncompress
    , bls12_381_G2_equals
    , bls12_381_G2_compressed_generator
    , bls12_381_millerLoop
    , bls12_381_finalVerify
    , blake2b_256
    , byteStringToInteger
    , integerToByteString
    , appendByteString
    , modInteger
    , lengthOfByteString
    )
import PlutusTx.Builtins.Internal (BuiltinUnit)

{-# INLINABLE frModulus #-}
frModulus :: Integer
frModulus =
  52435875175126190479447740508185965837690552500527637822603658699938581184513

{-# INLINABLE committedPub #-}
committedPub :: BuiltinByteString
committedPub = integerToByteString BigEndian 32 7919

-- one / two G1 uncompresses (difference = one G1 uncompress + subgroup check)
{-# INLINABLE e1G1 #-}
e1G1 :: BuiltinByteString -> Bool
e1G1 dC = let d = bls12_381_G1_uncompress dC in bls12_381_G1_equals d d

{-# INLINABLE e2G1 #-}
e2G1 :: BuiltinByteString -> BuiltinByteString -> Bool
e2G1 dC piC =
  let d = bls12_381_G1_uncompress dC; e = bls12_381_G1_uncompress piC
  in  bls12_381_G1_equals d e

-- one / two G2 uncompresses
{-# INLINABLE e1G2 #-}
e1G2 :: BuiltinByteString -> Bool
e1G2 gC = let g = bls12_381_G2_uncompress gC in bls12_381_G2_equals g g

{-# INLINABLE e2G2 #-}
e2G2 :: BuiltinByteString -> BuiltinByteString -> Bool
e2G2 gC sgC =
  let g = bls12_381_G2_uncompress gC; s = bls12_381_G2_uncompress sgC
  in  bls12_381_G2_equals g s

-- G1 scalarMul: (rSM - e1G1) = one scalarMul. (same 1 G1 uncompress + 1 equals)
{-# INLINABLE rSM #-}
rSM :: BuiltinByteString -> Bool
rSM dC =
  let d = bls12_381_G1_uncompress dC
      e = bls12_381_G1_scalarMul 7919 d
  in  bls12_381_G1_equals e e

-- G1 add: (rADD - e2G1) = one G1 add. (same 2 G1 uncompress + 1 equals)
{-# INLINABLE rADD #-}
rADD :: BuiltinByteString -> BuiltinByteString -> Bool
rADD dC piC =
  let d = bls12_381_G1_uncompress dC; e = bls12_381_G1_uncompress piC
      s = bls12_381_G1_add d e
  in  bls12_381_G1_equals s s

-- one miller loop + finalVerify : 1 G1 uncompress + 1 G2 uncompress + 1 ml + fV
{-# INLINABLE rML1 #-}
rML1 :: BuiltinByteString -> BuiltinByteString -> Bool
rML1 dC gC =
  let d = bls12_381_G1_uncompress dC; g = bls12_381_G2_uncompress gC
      m = bls12_381_millerLoop d g
  in  bls12_381_finalVerify m m

-- the OPENING-PAIRING shape: finalVerify of two miller loops on distinct points
-- e(D,[-sigma]G) = e(pi,G)  <=>  finalVerify (millerLoop D sG) (millerLoop pi G)
-- (2 G1 uncompress + 2 G2 uncompress + 2 ml + fV). Each point used once.
{-# INLINABLE rML2 #-}
rML2 :: BuiltinByteString -> BuiltinByteString -> BuiltinByteString -> BuiltinByteString -> Bool
rML2 dC piC gC sgC =
  let d  = bls12_381_G1_uncompress dC
      e  = bls12_381_G1_uncompress piC
      g  = bls12_381_G2_uncompress gC
      s  = bls12_381_G2_uncompress sgC
  in  bls12_381_finalVerify
        (bls12_381_millerLoop d s)
        (bls12_381_millerLoop e g)

-- hash-to-field of D: (rHASH - e1G1) = compress + append + Blake2b + b2i + mod.
{-# INLINABLE rHASH #-}
rHASH :: BuiltinByteString -> Bool
rHASH dC =
  let d    = bls12_381_G1_uncompress dC
      dser = appendByteString (bls12_381_G1_compress d) committedPub
      hd   = modInteger (byteStringToInteger BigEndian (blake2b_256 dser)) frModulus
  in  hd >= 0    -- always true; forces the whole hash chain (and uncompress d)

compiledE1G1 :: CompiledCode (BuiltinByteString -> Bool)
compiledE1G1 = $$(compile [|| e1G1 ||])
compiledE2G1 :: CompiledCode (BuiltinByteString -> BuiltinByteString -> Bool)
compiledE2G1 = $$(compile [|| e2G1 ||])
compiledE1G2 :: CompiledCode (BuiltinByteString -> Bool)
compiledE1G2 = $$(compile [|| e1G2 ||])
compiledE2G2 :: CompiledCode (BuiltinByteString -> BuiltinByteString -> Bool)
compiledE2G2 = $$(compile [|| e2G2 ||])
compiledRSM :: CompiledCode (BuiltinByteString -> Bool)
compiledRSM = $$(compile [|| rSM ||])
compiledRADD :: CompiledCode (BuiltinByteString -> BuiltinByteString -> Bool)
compiledRADD = $$(compile [|| rADD ||])
compiledRML1 :: CompiledCode (BuiltinByteString -> BuiltinByteString -> Bool)
compiledRML1 = $$(compile [|| rML1 ||])
compiledRML2 :: CompiledCode (BuiltinByteString -> BuiltinByteString -> BuiltinByteString -> BuiltinByteString -> Bool)
compiledRML2 = $$(compile [|| rML2 ||])
compiledRHASH :: CompiledCode (BuiltinByteString -> Bool)
compiledRHASH = $$(compile [|| rHASH ||])

-- | Plutus V3 validator that performs the WHOLE commitment delta end-to-end on
--   the canonical generators (for the .plutus envelope / on-chain size). The
--   per-op CPU breakdown is measured by the rungs above; this exercises the
--   full path: uncompress D,pi,K_c,G,[-sigma]G; hash-to-field; fold; opening
--   pairing.
{-# INLINABLE mkValidator #-}
mkValidator :: BuiltinData -> BuiltinUnit
mkValidator _ctx = check go
 where
  go =
    let d   = bls12_381_G1_uncompress bls12_381_G1_compressed_generator
        e   = bls12_381_G1_uncompress bls12_381_G1_compressed_generator
        kc  = bls12_381_G1_uncompress bls12_381_G1_compressed_generator
        g   = bls12_381_G2_uncompress bls12_381_G2_compressed_generator
        s   = bls12_381_G2_uncompress bls12_381_G2_compressed_generator
        dser = appendByteString (bls12_381_G1_compress d) committedPub
        hd  = modInteger (byteStringToInteger BigEndian (blake2b_256 dser)) frModulus
        vkx = bls12_381_G1_add (bls12_381_G1_scalarMul hd kc) d
        okLen = lengthOfByteString (bls12_381_G1_compress vkx) > 0
    in  okLen && bls12_381_finalVerify
                   (bls12_381_millerLoop vkx s)
                   (bls12_381_millerLoop e g)

compiledValidator :: CompiledCode (BuiltinData -> BuiltinUnit)
compiledValidator = $$(compile [|| mkValidator ||])
