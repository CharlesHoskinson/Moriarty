# SP2 — Live Preview re-verification of the claim-ticket spent-state (closes S3-F4)

The hardened (ticket-aware) `RedemptionValidator` was deployed to the live Cardano **Preview**
node (testnet-magic 2) and exercised end-to-end: a custody balance plus a per-credential **claim
ticket** were locked, a real client ZK proof drove a claim that **spent + burned** the ticket and
released 5 tADA to the bound destination `D`, and a **second claim for the same credential `C`**
(its ticket already burned) was **rejected on-chain by the validator's spent-state gate**. This is
the live analogue of the `redemption-eval no-ticket` CEK negative — the on-chain proof that
double-claim (audit finding **S3-F4**) is structurally closed.

Date 2026-06-29. Network Preview (magic 2). Branch `feat/sp2-spent-tickets`. Validator pin
(cborHex sha256) `860134f9b6323232986396c0ab45566e67ae07ee793784487a6ae4aa0c3a4584`.

## What's new vs E2 (the ticketless full claim)
- The datum at the script is now a **sum** `RedemptionDatum = Custody | Ticket`. Custody locks
  carry `Custody (CustodyDatum C ent)` = `Constr 0 [Constr 0 [B C, B ent]]`; the ticket carries
  `Ticket (TicketDatum n)` = `Constr 1 [Constr 0 [B n]]`, where `n` is the **version-stable**
  nullifier `Blake2b(domainSep ‖ scriptHash ‖ C)`.
- A claim now spends **two** script inputs — the custody UTxO **and** the matching ticket — in one
  tx. The node runs the validator twice: the **Custody** branch (real `groth16VerifyCommitted`,
  payout==D, entitlement, no-self-pay, `custodyInputCount == 1`, **`ticketBurnedFor`**) and the
  **Ticket** branch (**`custodyClaimPresent`**, the anti-grief gate). The ticket is **burned** (no
  ticket output).

## Parameters
| Item | Value |
|------|-------|
| Claimant credential `C` | `19e07fbcc7577359d6c51f1e49cf1b0bf4c943b48ba4e4905a8702e4` |
| Version-stable nullifier `n` | `719bf915ae5cbf5fc2809fd5d40619615c405e8749d7ac96925a34514a2a51b6` |
| Entitlement | 5 tADA, ADA-only (`encodeEntitlement` = `404b4c00…`) |
| Destination `D` | `addr_test1qpyrmar0p6rh94dvv7vlx060j359mvrfmyey2ezw4zhdhev8l5948m6weh72g4h3df2zleuyqyp30e0mm0ky72t8zeqsm0yae5` |
| Ticket-aware script addr | `addr_test1wzw8cum0qterau2nn2lwsgjcktlgpgll6wqjclvmsvmd9vgkw6fel` |
| Funded wallet | `addr_test1vpw0dhd0k6rq0qrpeul0km0xtl5tguqk8f9q8v5p5rzghdq05nhzv` |

## Off-chain CEK gate (per-input ex-units, declared on-chain)
Each script input is a separate Plutus execution; both were measured with the real fixture proof
before going live (`redemption-eval real-claim` and the new `redemption-eval ticket-cost`):

| Input (branch) | CEK-measured ExCPU / ExMem | Declared on-chain |
|----------------|----------------------------|-------------------|
| custody (Custody: proof + ticketBurnedFor) | 5,504,101,369 / 9,206,533 | (6,500,000,000, 11,000,000) |
| ticket (Ticket: custodyClaimPresent) | 435,282,352 / 1,738,236 | (600,000,000, 2,600,000) |

Both well within the per-tx ceiling (10e9 steps / 16.5e6 mem). The synthetic CEK context slightly
under-measures the real context's memory (real inputs/collateral/redeemers); the first live attempt
declared 9.8e6/2.1e6 and the node reported a small budget overspend, so the declarations above carry
margin over the real cost.

## Transactions

| # | Tx hash | Action | Result |
|---|---------|--------|--------|
| 1 | `e73dfb3547579bdc264feb5e816f9c3bafb85641d6b601287ee58f3a2cb5b585` | Lock 2× custody (5 tADA each, same `C`) + 1 ticket | confirmed |
| 2 | `2969eb5f8284512422b848bfc539572a689c67129d0a965fedad62456ee648a9` | Lock the **correctly-encoded** ticket (2 tADA, `Constr 1 [Constr 0 [B n]]`) | confirmed |
| 3 | `d9f4bd9ea7efbb4f1fd72df70fb43fb5da08cbd6f6130261e113e413823a147c` | **Claim A** — custody + ticket → 5 tADA to `D`, ticket burned | **confirmed (validator ACCEPT)** |
| 4 | `ea9500ba152cd7b20fe2b9edf963abc85aeb737bd44e1d1aac9a5f1b387be669` | **Double-claim B** — 2nd custody for same `C`, no ticket | **REJECTED on-chain (spent-state gate)** |

Explorer:
- Claim A: https://preview.cexplorer.io/tx/d9f4bd9ea7efbb4f1fd72df70fb43fb5da08cbd6f6130261e113e413823a147c

## Results
- **Claim A accepted.** `D` received exactly **5,000,000 lovelace**; the custody UTxO and the
  ticket UTxO are both consumed; **no ticket output** (burned). The node ran the full validator on
  both script inputs.
- **Double-claim B rejected.** The second claim for the same `C` — identical proof, payout, and
  entitlement, differing **only** in that no ticket is available (the one ticket was burned by
  Claim A) — failed phase-2: `The PlutusV3 script failed … FailedUnexpectedly`, `Caused by: error`
  (the `check` on `ticketBurnedFor` returned False), **with no budget overspend**, i.e. a pure
  spent-state-logic rejection. Custody B remains unspent; `D` received no second payment.

This is the on-chain demonstration that an additional custody UTxO for an already-claimed credential
**cannot** be redeemed — double-claim is structurally closed by the one-ticket-per-credential
invariant.

## Finding the live test caught: the ticket-datum emitter encoding bug
The first claim attempt was **rejected** with `Caused by: unConstrData (B #719bf915…)`. Root cause:
`redemption-deploy ticket-datum` emitted the **flat** `Constr 1 [B n]`, but `Ticket (TicketDatum n)`
encodes as the **nested** `Constr 1 [Constr 0 [B n]]` (the single-field `TicketDatum` record wraps
the bytes in its own `Constr 0`). The `redemption-eval` CEK harness builds the ticket via Haskell's
real `toData`, so it **masked** the bug; only the hand-formatted operator JSON was wrong. Fixed in
`app-deploy/Main.hs` (the emitter now prints the nested form, verified byte-equal to the datum that
Claim A accepted). One 2 tADA ticket UTxO created with the pre-fix datum
(`e73dfb…#2`) is undecodable and remains locked — a deliberate test casualty, not a contract flaw.

## Reproduce
The validator, fixtures, and wallet are in-repo. The live sequence (lock → correct-ticket →
claim → double-claim-reject) was driven via `cardano-cli conway transaction build-raw` + Koios
`submittx`, declaring the per-input ex-units above. The off-chain gate (`redemption-eval real-claim`
+ `ticket-cost`) reproduces the accept and the per-input budgets without a node.
