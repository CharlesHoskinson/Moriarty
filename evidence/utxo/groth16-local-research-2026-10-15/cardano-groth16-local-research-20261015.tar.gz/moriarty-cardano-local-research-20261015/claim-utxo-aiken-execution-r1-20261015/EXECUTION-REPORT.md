# Execution report: Aiken revision 1, reviewer §8.3 A1, A0, A2–A10 and V0–V4

**Executor:** Claude Opus 5.5 (`claude-opus-5-5`); "high" effort requested, not observable. I did not write the candidate, its tests, or the review.

**Authority:** `ROOT-AUTHORIZATION.json`. The review it cites is `REPORT.md` `902a93ab…fc33b`, which I re-hashed before any step and which matched.

**This report makes no acceptance judgment.** A fresh, independent Opus audit of these actual results is still required.

## 1. Terminal status

| Phase | Status | Steps run, each once | Exits |
|---|---|---|---|
| A | `A-COMPLETE` | A1, A0, A2, A3, A4, A5, A6, A7, A8, A9, A10 | all 0 |
| V | `V-COMPLETE` | V0, V1, V2, V3, V4 | all 0 |

- No retries, no source edits, no stops.
- Every owned child exited and its process group was empty (`processGroupEmpty: true`). Nothing timed out and no signal was sent.

**Exit-code honesty**
- `.exit` files for wrapped steps were written by the controller from the real child wait status (`os.wait4`). They do not come from the wrapper's `echo`.
- A1 and V0 run without the wrapper. The real `bash` return code was 0, and each `.exit` file reads `0`.
- A10's `bash` return code is `echo`'s, so it is not used. The real `freeze.py` status is in `$TASK/A10.exit` and reads `0`.

## 2. Per-step actuals

`log sha256` is the digest of `$TASK{,2}/logs/<ID>.log`. Wall caps are as reviewed, plus `--kill-after=60`.

| Step | Exit | Elapsed (s) | Wall cap (s) | maxRSS (KiB) | log sha256 |
|---|---|---|---|---|---|
| A1 | 0 | 0.010 | — (no wrapper) | 22416 | — |
| A0 | 0 | 0.029 | 60 | 22416 | `63b27e18d5704779c167afda38511e41090169cf262201ce55cc6c0448de7255` |
| A2 | 0 | 0.057 | 60 | 22416 | `6b10120d040098026aad0db8b0c2dca1487b7d8fc57621b40dcfd9878eae70bc` |
| A3 | 0 | 0.019 | 30 | 22416 | `dcee31fcbec3e6c05cc28dd7f68c6ce4dd33ec6c92104c80ecac9d1aac3f79c0` |
| A4 | 0 | 0.056 | 120 | 22416 | `f957ed749ddf2d2c4d3e15510f81d0d804aba4a7735b025a0b1f2b5cd5902750` |
| A5 | 0 | 0.055 | 60 | 22416 | `0d386474a660e682e1ea908f51eb26a366ce417ea680da27abcec1095d30ace7` |
| A6 | 0 | 15.701 | 1800 | 59484 | `e65fd3092a56b4b09a5f370cd6555a9db007f151f25182f714c3a640b78f4168` |
| A7 | 0 | 0.056 | 60 | 22416 | `982952b81a2156b0d8cf0f4e233e454d51967f18a9229925baf45d166226676d` |
| A8 | 0 | 4.991 | 900 | 39692 | `12fe983ebacf303a0114ab9d4003843e3dc735852fae5e2e59a87055132b3b4a` |
| A9 | 0 | 0.121 | 120 | 22416 | `8bfb1dc6b3b51777ebeb02082cb188c1879b6eec7e4f84aa0a9bde31d05a0cb2` |
| A10 | 0 (`A10.exit`) | 0.050 | — (no wrapper) | 22416 | — |
| V0 | 0 | 0.009 | — (no wrapper) | 22632 | — |
| V1 | 0 | 0.069 | 120 | 22632 | `750257a4002d68a74e5c3d5b17ba4b2bba8318ef7a4f3918823769fdd90be660` |
| V2 | 0 | 0.044 | 60 | 22632 | `1f4bafa7ff8d3524f9ae31f5000896a2d4eebfc682833dd7b96ed808934f6ab0` |
| V3 | 0 | 15.726 | 1800 | 60868 | `69b49318d035d2b8b95ff7087ce8893ff4fedeaceefda2ec415a63427d8c57ce` |
| V4 | 0 | 0.044 | 60 | 22632 | `982952b81a2156b0d8cf0f4e233e454d51967f18a9229925baf45d166226676d` |

- The V4 log is byte-identical to the A7 log. Both are the same `allHold: true` JSON line, with the same `aiken.lock` digest.
- The outer stderr of every wrapped step was 0 bytes.

## 3. Observations

### A0 and V1: digest checks

- All 30 `SOURCE-MANIFEST-R1.sha256` entries returned `OK`.
- `SOURCE-MANIFEST-R1.json`, `SOURCE-MANIFEST-R1.sha256` and `REVIEW-INPUT.json` matched their pins.
- `SOURCE-PIN.json`, `SOURCE-MANIFEST.json` and `stdlib-source.tar.gz` matched their pins.
- V1 also matched `L1/claim.json`, `M1/claim.json`, `generated/x7_vectors_test.ak` and `gen_x7_aiken.py`.

### A2: toolchain

| Item | Observed |
|---|---|
| Aiken version | `aiken v1.1.21+42babe5` |
| `aiken` sha256 | `07f3f927…8e79` |
| `python3.14` sha256 | `52e0a13e…cb41` (Python 3.14.4) |
| `unshare` sha256 | `41c65e55…82ef` |

All three equal the root pins. The controller also checked them independently before each phase.

### A3: network namespace

Only `lo:` was present, with zero traffic.

### A4 and V1: placement

- 8 project files and 38 stdlib files.
- `placement.json` sha256 is `5f72bdfe…cdf4`.

### A6: offline `aiken check`

**Result: 76/76 passed, 0 failed, 0 warning lines.**
- JSON telemetry summary: `{total 76, passed 76, failed 0, unit 76, property 0}`, seed `2743329201`.
- The 76 observed test names equal the frozen-source names exactly: `pvc/abi_test` 30 and `pvc/context_test` 46. There are no missing, unexpected or duplicate names.
- Every frozen name also appears in `EXPECTED-OUTCOMES-R1.md`.
- No compiler-version warning appeared.

Per-test CPU and memory figures are in `records-A/gate-A6-76.json`. They come from Aiken's built-in cost model only and are not a ledger or ExUnits claim. Examples:

| Test | CPU |
|---|---|
| `x2_regression_verifies` | 2,142,407,438 |
| `x2_regression_statement_bit_flip_rejected` | 2,142,563,487 |
| `settle_and_two_slots_ok_either_order` | 2,042,441,234 |

### A7 and A9: post-checks

- Both `post-check-A6.json` and `post-check-A8.json` report `allHold: true`.
- The stdlib is unchanged (38 files) and `packages.toml` has a single entry.
- `aiken.lock` has one package, no etag, an empty `[etags]` table and sha256 `ec5d6a58…da83`.
- HOME and XDG cache were empty. The `find -mindepth 1` check also confirmed no empty directories were created.
- **No fetch or cache attempt was observed, so there is no BLOCKED condition.**

### A8: offline `aiken build`

- `plutus.json` sha256: `9ffc530d662880e7a196636223162523698d3d6f18e4ea793e129a33170696fd`.
- Validator hashes are recorded, not predicted:

| Validator | Hash |
|---|---|
| `c0.c0.{mint,spend,else}` | `7f961dfa78c89965e52f05dcc6ac34c8431a35f87faf70182deabd8d` |
| `settle0.settle0.{mint,spend,else}` | `85592a6ac1d67cffe628b93562f410e7e79f5a88be21a0e1edd69443` |

- No attempt-2 build exists to compare against (F-R1-7).

### A5, A9 and A10: freeze receipts

| Receipt | Files | sha256 |
|---|---|---|
| `run-before.json` | 47 | `466acad2…70a9` |
| `run-after.json` | 50 | `dd5d6311…1e17` |
| `task-final.json` | 27 | `1f174178b16109e6d7202aed4a5abeae5afbe000bfd8012d40c6ae3a400bca36` |

The 3 files added between `run-before` and `run-after` are `aiken.lock`, `build/aiken-compile.lock` and `plutus.json`.

### V2: regenerated vectors

- The regenerated file has sha256 `c90b97c9…e3fa`.
- `cmp` against `out/generated/x7_vectors_test.ak` reported no difference (exit 0).

### V3: offline `aiken check` with vectors

**Result: 89/89 passed, 0 failed.** That is the 76 frozen tests plus the 13 generated ones, with exact name match. Seed `760865730`.

CPU figures for the generated tests (Aiken's built-in model only):

| Test | CPU |
|---|---|
| `l1_groth16_positive` | 2,152,057,818 |
| `m1_groth16_positive` | 2,175,161,256 |
| `l1_payload_bit_flip_rejected` | 2,156,531,198 |
| `m1_payload_bit_flip_rejected` | 2,179,634,636 |
| `l1_c0_issue_unit_context` | 2,279,108,463 |
| `m1_c0_issue_unit_context` | 2,343,840,520 |
| `cross_vk_rejected` | 4,330,447,319 |

The `*_statement_matches_x7`, `*_asset_name_matches_x7` and `*_vk_digest_matches_envelope` tests also passed.

### V4: post-check

`post-check-V3.json` reports `allHold: true`, with HOME and cache empty.

## 4. Sources and immutability

- **The source trees are unchanged across both phases** (`sources-before.json` and `sources-after.json` in each `records-*` directory; comparison `unchanged: true`). The trees checked were:
  - REV, excluding the two new task directories;
  - the stdlib PIN tree;
  - `RUSTOUT`;
  - `ATT2/source/scripts`;
  - the three pinned tools.
- I did not read private provider results. `provider-result.private.json` and `process.stderr` were only `stat`ed for the before/after comparison.
- New writes were limited to three places:
  - `$REV/aiken-offline-check-1`;
  - `$REV/aiken-offline-check-vectors-1`;
  - this directory: `controller/`, `records-A/`, `records-V/` and this report.

## 5. Controller and its deviation

**Controller:** `controller/aiken_r1_control.py`, sha256 `48731df3600b51dca01ca847664c79a58e9798ccb42ec83958bb73c4ea8b4039`. It is a Python standard-library equivalent of `run_step`, under the same nice, timeout, prlimit and pipefail/tee settings.

- Before any step, it asserts that all 16 command texts occur **verbatim** in the pinned review.
- Journals (created exclusively):

| Journal | sha256 |
|---|---|
| `records-A/journal.jsonl` | `1c8306dd34454320de5d892d646201e0fcf51a295511c53c5bdc96343dbd83fc` |
| `records-V/journal.jsonl` | `820712975be8cc65f03b08427b2a9f6b42cca220d7468465c61e1bb669ce408e` |

- Each step also has `*.record.json`, which holds the argv, UTC start and end, wait status, rusage and digests. Its outer stdout and stderr are in `*.outer.{stdout,stderr}`.
- Host metadata is in `records-*/host-metadata.json`:
  - 6 CPUs;
  - swap active, 8 GiB `/dev/sdc`;
  - `core_pattern` is `core`;
  - the controller's own netns is the host netns.

**One declared deviation:** A2's inner `bash` additionally ran under `unshare --user --map-root-user --net`. This put `aiken --version` in a no-IP namespace, as the root prompt requires. The A2 command text itself is unchanged.

**Child environment** (non-Aiken steps): `PATH=/usr/bin:/bin`, `HOME`, and the reviewed variables only. The Aiken steps (A6, A8, V3) used the reviewed `env -i` empty HOME and cache, inside their own `unshare --net`.

## 6. Labels and limits (fixed scope)

**Non-evidence**
- `decoder_rejects_extra_transition_field_after_option_data` passed. Its pass is **non-evidence** (F-R1-3): it passes whether or not a decoder collision exists.
- B-C (the pre-#1331 decoder collision) is **not exercised**. UNIT tests do not evaluate the real validator wrapper's datum decoding.
- A6 and V3 are UNIT-level only. They show:
  - compilability under v1.1.21;
  - Aiken/pallas chunked CBOR;
  - that the Aiken CIP-0381 path accepts the two X7 arkworks proofs and rejects the bit-flip and cross-VK cases;
  - the UNIT logic of issue, release, genesis and settle.

  They do **not** show ledger `serialiseData` equality, ExUnits or fee fit, validator-wrapper decoding, or any settlement or financial semantics.

**Placeholders**
- L1/M1 outref `44…#1`, refund `55…` and expiry `1000` are synthetic UNIT placeholders.
- The L1 body consists of provider-observed Preprod bytes only.

**VK class**
- The L1 and M1 VKs (`7b014d…`, `8e1ae7…`) are orphan Class 0 research VKs.
- They are host-trusted, may have swap residue and have no proving key.
- They must never be pinned in a real genesis.

**F-A and F-R1-1**
- F-A protects the claim deposit.
- Proof re-wrapping (F-R1-1) remains possible, so this run supports no claim of usage exclusivity or funds safety.

**Network scope**
- No Aiken child had IP egress: A2, A6, A8 and V3 each ran in their own network namespace with only `lo`.
- Placement and the Python steps are offline file operations.
- The agent CLI that ran this controller necessarily exchanged its transcript with its model provider. **No claim is made that "nothing was sent anywhere".**
- A network namespace is not a filesystem sandbox. Writes outside the task directories rest on the post-checks and source review.

**Not done**
- No Preprod, wallet, existing key, setup, prove, SRS, Rust, Midnight or ledger action took place.
- No cost claim beyond Aiken's built-in model is made.

**Still open**

None of the user's tracks is closed by this stage:
- the 20 patterns;
- general obligations and liabilities;
- physical effects and value;
- recursion;
- private PCD and handoff;
- multi-party and multi-parent composition;
- current-language and source→target correspondence (Moriarty `6c7`).

Preprod remains blocked on B-C, B2, B3, the F-R1-1 policy and separate authorization.
