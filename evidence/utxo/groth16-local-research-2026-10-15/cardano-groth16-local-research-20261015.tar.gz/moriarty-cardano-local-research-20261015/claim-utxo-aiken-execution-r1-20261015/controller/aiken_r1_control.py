#!/usr/bin/env python3
"""Stdlib controller for reviewer report 902a93ab... section 8.3.

Phase A: A1, A0, A2-A10.  Phase V (separate invocation, gated on phase A): V0-V4.
Each step runs once. No retry. Stop at the first non-zero exit, except that A7 always
follows A6 and V4 always follows V3 (read-only diagnostics).

run_step is reproduced as an argv:
  nice -n 10 timeout --kill-after=60 WALL prlimit --as=34359738368 --core=0 -- \
    bash -o pipefail -c '{ CMD
} 2>&1 | tee "LOGDIR/ID.log"'
and LOGDIR/ID.exit is written from the real child status (the literal wrapper's
`echo $? > exit` records the same value; its own return is echo's and is not used).

Single declared change from the literal text: A2's inner bash also runs under
`unshare --user --map-root-user --net --` (after prlimit), so `aiken --version` has no
IP network either (root prompt: every Aiken child in a no-IP network namespace).
The command text itself is unchanged.

Every command text is asserted to occur verbatim in the hash-pinned review before any
step runs. Private provider results are never read (stat only).

Usage: python3 -I aiken_r1_control.py A|V
"""
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time

OUT = "/home/charl/moriarty-eutxo-validation-2026-10-12/claim-utxo-aiken-execution-r1-20261015"
ROOT_AUTH = OUT + "/ROOT-AUTHORIZATION.json"
REVIEW = "/home/charl/moriarty-eutxo-validation-2026-10-12/aiken-r1-independent-source-review-20261015/REPORT.md"
REVIEW_SHA = "902a93abb575f00bc83f2cb86be174ccae16f732fcac4fdd34734f3ed82fc33b"

REV = "/home/charl/moriarty-eutxo-validation-2026-10-12/claim-utxo-aiken-revision-1-20261015"
PIN = "/home/charl/moriarty-eutxo-validation-2026-10-12/aiken-stdlib-v220-source-20261015"
ATT2 = "/home/charl/moriarty-eutxo-validation-2026-10-12/claim-utxo-prototype-source-20261015/implementation-attempt-2"
RUSTOUT = ATT2 + "/rust-research-execution-1/out"
TASK = REV + "/aiken-offline-check-1"
TASK2 = REV + "/aiken-offline-check-vectors-1"
AIKEN = "/home/charl/.aiken/versions/v1.1.21/aiken-x86_64-unknown-linux-musl/aiken"
PY = "/usr/bin/python3.14"

PINS = {
    AIKEN: "07f3f927f1a8c71fc61273fdff850d9b98edb28dde207c8a32585991f2c88e79",
    PY: "52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41",
    "/usr/bin/unshare": "41c65e55107cbbb1a1f6994784a938dd7dbbe255d1fea6b7a58ec96eabe382ef",
}
AUX_TOOLS = ["nice", "timeout", "prlimit", "bash", "tee", "sha256sum", "find", "env", "cmp",
             "awk", "readlink", "cat", "mkdir", "printf", "test"]

ENV = {
    "PATH": "/usr/bin:/bin",
    "HOME": os.environ.get("HOME", "/home/charl"),
    "REV": REV, "PIN": PIN, "ATT2": ATT2, "RUSTOUT": RUSTOUT,
    "TASK": TASK, "TASK2": TASK2, "AIKEN": AIKEN, "PY": PY,
}

PRIVATE_NAMES = {"provider-result.private.json", "process.stderr"}

# ---- literal reviewed command texts (section 8.3) -------------------------------------
A1 = r'''mkdir "$TASK" && mkdir "$TASK/logs" "$TASK/receipts" "$TASK/empty-home" "$TASK/empty-xdg-cache" && echo 0 > "$TASK/logs/A1.exit"'''
A10 = r'''cd / && "$PY" -I "$REV/tools/freeze.py" "$TASK/receipts/task-final.json" "all task logs and receipts" "$TASK" logs receipts; echo $? > "$TASK/A10.exit"'''
V0 = r'''mkdir "$TASK2" && mkdir "$TASK2/logs" "$TASK2/receipts" "$TASK2/empty-home" "$TASK2/empty-xdg-cache" && echo 0 > "$TASK2/logs/V0.exit"'''

STEPS = {
    "A0": ("$TASK/logs", 60, r'''cd "$REV" && sha256sum -c SOURCE-MANIFEST-R1.sha256 && printf "%s  %s\n" 284885367cae95cba0233739bd13ab6b7025a2a5203aa179dbe169c9cd8437aa SOURCE-MANIFEST-R1.json ab499f47f36d54095929cb615c071bb66d30ea4f923fa445752427848b46b411 SOURCE-MANIFEST-R1.sha256 4a170a307fdc1db5b4ef91a7eee44d1951bf6fe9a6563983b69680717b2a1cf8 REVIEW-INPUT.json | sha256sum -c - && cd "$PIN" && printf "%s  %s\n" a26daa087fae05f9b35a06ed382d20e92e4d1ea8b76b59947134b7e4b2197266 SOURCE-PIN.json e44ed44783d17f4cb0b58c59f98a75bc09fc64c793dd25f3ab56b4097cdf1b1c SOURCE-MANIFEST.json 90c07de94ebf858f0d78292a9482cfa3b2b45767ed85fd381e74c0463cdf9b51 stdlib-source.tar.gz | sha256sum -c -'''),
    "A2": ("$TASK/logs", 60, r'''v="$("$AIKEN" --version)" && printf "%s\n" "$v" && readlink -f "$AIKEN" "$(command -v unshare)" && sha256sum "$AIKEN" "$PY" "$(command -v unshare)" > "$TASK/receipts/tools-sha256.txt" && cat "$TASK/receipts/tools-sha256.txt" && "$PY" --version && case "$v" in *v1.1.21*) true;; *) false;; esac'''),
    "A3": ("$TASK/logs", 30, r'''unshare --user --map-root-user --net -- cat /proc/net/dev && test "$(unshare --user --map-root-user --net -- awk "NR>2{print \$1}" /proc/net/dev)" = "lo:"'''),
    "A4": ("$TASK/logs", 120, r'''cd / && "$PY" -I "$REV/tools/place_stdlib.py" "$REV" "$PIN" "$TASK/run" "$TASK/receipts/placement.json"'''),
    "A5": ("$TASK/logs", 60, r'''cd / && "$PY" -I "$REV/tools/freeze.py" "$TASK/receipts/run-before.json" "run tree before aiken check" "$TASK" run'''),
    "A6": ("$TASK/logs", 1800, r'''cd "$TASK/run" && unshare --user --map-root-user --net -- env -i PATH=/usr/bin:/bin HOME="$TASK/empty-home" XDG_CACHE_HOME="$TASK/empty-xdg-cache" NO_COLOR=1 "$AIKEN" check'''),
    "A7": ("$TASK/logs", 60, r'''cd / && "$PY" -I "$REV/tools/post_check.py" "$TASK/receipts/placement.json" "$TASK/empty-home" "$TASK/empty-xdg-cache" "$TASK/receipts/post-check-A6.json" && test -z "$(find "$TASK/empty-home" "$TASK/empty-xdg-cache" -mindepth 1 -print -quit)"'''),
    "A8": ("$TASK/logs", 900, r'''cd "$TASK/run" && unshare --user --map-root-user --net -- env -i PATH=/usr/bin:/bin HOME="$TASK/empty-home" XDG_CACHE_HOME="$TASK/empty-xdg-cache" NO_COLOR=1 "$AIKEN" build && sha256sum plutus.json > "$TASK/receipts/plutus-json-sha256.txt" && cat "$TASK/receipts/plutus-json-sha256.txt" && cd / && "$PY" -I -c "import json,sys; d=json.load(open(sys.argv[1])); [print(v[\"title\"], v.get(\"hash\")) for v in d[\"validators\"]]" "$TASK/run/plutus.json" > "$TASK/receipts/validator-hashes.txt" && cat "$TASK/receipts/validator-hashes.txt"'''),
    "A9": ("$TASK/logs", 120, r'''cd / && "$PY" -I "$REV/tools/post_check.py" "$TASK/receipts/placement.json" "$TASK/empty-home" "$TASK/empty-xdg-cache" "$TASK/receipts/post-check-A8.json" && test -z "$(find "$TASK/empty-home" "$TASK/empty-xdg-cache" -mindepth 1 -print -quit)" && "$PY" -I "$REV/tools/freeze.py" "$TASK/receipts/run-after.json" "run tree after aiken build" "$TASK" run'''),
    "V1": ("$TASK2/logs", 120, r'''cd "$REV" && sha256sum -c SOURCE-MANIFEST-R1.sha256 && cd "$RUSTOUT" && printf "%s  %s\n" 2108993b3210c4ff86cf2831e17352c99c764b9867a8e479ba6b0395cf25ec81 L1/claim.json 4b9c407c5d24df5184e6b67d471470fefd6bb623aa02dfaa14c01585fc874bd0 M1/claim.json c90b97c90adbd2f5c19adae86c134718e642b63212ab24a5776100f733b1e3fa generated/x7_vectors_test.ak | sha256sum -c - && cd "$ATT2/source/scripts" && printf "%s  %s\n" 80c59ff72bef7363f72204a08be82bf333fb781a721a78431ccedc7eab0f9ea7 gen_x7_aiken.py | sha256sum -c - && cd / && "$PY" -I "$REV/tools/place_stdlib.py" "$REV" "$PIN" "$TASK2/run" "$TASK2/receipts/placement.json"'''),
    "V2": ("$TASK2/logs", 60, r'''cd / && "$PY" -I "$ATT2/source/scripts/gen_x7_aiken.py" "$RUSTOUT" "$TASK2/run/lib/pvc/x7_vectors_test.ak" && sha256sum "$TASK2/run/lib/pvc/x7_vectors_test.ak" > "$TASK2/receipts/generated-aiken-sha256.txt" && cat "$TASK2/receipts/generated-aiken-sha256.txt" && cmp "$TASK2/run/lib/pvc/x7_vectors_test.ak" "$RUSTOUT/generated/x7_vectors_test.ak"'''),
    "V3": ("$TASK2/logs", 1800, r'''cd "$TASK2/run" && unshare --user --map-root-user --net -- env -i PATH=/usr/bin:/bin HOME="$TASK2/empty-home" XDG_CACHE_HOME="$TASK2/empty-xdg-cache" NO_COLOR=1 "$AIKEN" check'''),
    "V4": ("$TASK2/logs", 60, r'''cd / && "$PY" -I "$REV/tools/post_check.py" "$TASK2/receipts/placement.json" "$TASK2/empty-home" "$TASK2/empty-xdg-cache" "$TASK2/receipts/post-check-V3.json" && test -z "$(find "$TASK2/empty-home" "$TASK2/empty-xdg-cache" -mindepth 1 -print -quit)"'''),
}
NETNS_WRAP = {"A2"}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha_bytes(b):
    return hashlib.sha256(b).hexdigest()


def sha_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def expand(logvar):
    return logvar.replace("$TASK2", TASK2).replace("$TASK", TASK)


class Phase:
    def __init__(self, name):
        self.name = name
        self.rec = os.path.join(OUT, "records-" + name)
        os.mkdir(self.rec)  # single-use; fails if the phase already ran
        self.jfd = os.open(os.path.join(self.rec, "journal.jsonl"), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        self.steps = []

    def journal(self, obj):
        obj = {"utc": now(), **obj}
        os.write(self.jfd, (json.dumps(obj, sort_keys=True) + "\n").encode())
        os.fsync(self.jfd)
        print(json.dumps(obj, sort_keys=True), flush=True)

    def write_json(self, name, obj):
        with open(os.path.join(self.rec, name), "x") as f:
            json.dump(obj, f, indent=2, sort_keys=True)
            f.write("\n")

    def launch(self, sid, argv, kind, wall=None, exit_path=None, log_path=None, literal=None):
        so = os.path.join(self.rec, sid + ".outer.stdout")
        se = os.path.join(self.rec, sid + ".outer.stderr")
        rec = {"id": sid, "kind": kind, "argv": argv, "cwd": "/", "wallCapSeconds": wall,
               "killAfterSeconds": 60 if wall else None, "netnsWrapAdded": sid in NETNS_WRAP,
               "literalCommand": literal, "start": now()}
        self.journal({"event": "start", "id": sid, "argv": argv})
        t0 = time.monotonic()
        with open(so, "xb") as fo, open(se, "xb") as fe:
            p = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=fo, stderr=fe, cwd="/",
                                 env=ENV, start_new_session=True)
            rec["pid"] = p.pid
            _, status, ru = os.wait4(p.pid, 0)
            p.returncode = os.waitstatus_to_exitcode(status)
        rec["elapsedSeconds"] = round(time.monotonic() - t0, 3)
        rec["end"] = now()
        rec["rawWaitStatus"] = status
        rec["childReturncode"] = p.returncode
        shell_rc = p.returncode if p.returncode >= 0 else 128 - p.returncode
        rec["shellEquivalentExit"] = shell_rc
        rec["rusage"] = {"utime": ru.ru_utime, "stime": ru.ru_stime, "maxrssKiB": ru.ru_maxrss,
                         "minflt": ru.ru_minflt, "majflt": ru.ru_majflt, "inblock": ru.ru_inblock,
                         "oublock": ru.ru_oublock, "nvcsw": ru.ru_nvcsw, "nivcsw": ru.ru_nivcsw}
        # Wait (no kill) for any straggler in the child's process group; bounded, recorded.
        empty, waited = False, 0
        while waited <= 120:
            try:
                os.killpg(p.pid, 0)
            except ProcessLookupError:
                empty = True
                break
            except PermissionError:
                break
            time.sleep(1)
            waited += 1
        rec["processGroupEmpty"] = empty
        rec["groupWaitSeconds"] = waited
        if exit_path is not None:
            with open(exit_path, "x") as f:
                f.write(f"{shell_rc}\n")
            rec["exitFileWrittenByController"] = exit_path
        for label, path in (("outerStdout", so), ("outerStderr", se), ("log", log_path)):
            if path and os.path.exists(path):
                rec[label] = {"path": path, "bytes": os.path.getsize(path), "sha256": sha_file(path)}
            elif path:
                rec[label] = {"path": path, "missing": True}
        self.journal({"event": "end", "id": sid, "exit": shell_rc, "elapsed": rec["elapsedSeconds"],
                      "groupEmpty": empty})
        self.steps.append(rec)
        self.write_json(sid + ".record.json", rec)
        return shell_rc, rec

    def run_step(self, sid):
        logvar, wall, cmd = STEPS[sid]
        logdir = expand(logvar)
        log = f"{logdir}/{sid}.log"
        inner = "{ " + cmd + "\n} 2>&1 | tee \"" + log + "\""
        argv = ["nice", "-n", "10", "timeout", "--kill-after=60", str(wall),
                "prlimit", "--as=34359738368", "--core=0", "--"]
        if sid in NETNS_WRAP:
            argv += ["unshare", "--user", "--map-root-user", "--net", "--"]
        argv += ["bash", "-o", "pipefail", "-c", inner]
        return self.launch(sid, argv, "run_step", wall=wall, exit_path=f"{logdir}/{sid}.exit",
                           log_path=log, literal=cmd)

    def run_literal(self, sid, text, exit_file):
        rc, rec = self.launch(sid, ["bash", "-c", text], "literal-no-wrapper", literal=text)
        rec2 = {"id": sid, "bashReturncode": rc, "exitFile": exit_file}
        if os.path.exists(exit_file):
            rec2["exitFileContent"] = open(exit_file).read()
        else:
            rec2["exitFileContent"] = None
        self.write_json(sid + ".exitfile.json", rec2)
        return rc, rec2


# ---- static checks, snapshots, parsing -----------------------------------------------
def verify_static(phase):
    review = open(REVIEW, "rb").read()
    out = {"reviewSha256": sha_bytes(review), "reviewPinned": REVIEW_SHA,
           "rootAuthorizationSha256": sha_file(ROOT_AUTH), "controllerSha256": sha_file(os.path.abspath(__file__))}
    ok = out["reviewSha256"] == REVIEW_SHA
    text = review.decode()
    lit = {}
    for sid, (logvar, wall, cmd) in STEPS.items():
        lit[sid] = f"run_step \"{logvar}\" {sid} {wall} '{cmd}'" in text
    for sid, t in (("A1", A1), ("A10", A10), ("V0", V0)):
        lit[sid] = t in text
    out["literalTextInReview"] = lit
    ok &= all(lit.values())
    pins = {}
    for p, want in PINS.items():
        got = sha_file(p)
        pins[p] = {"realpath": os.path.realpath(p), "sha256": got, "pinned": want, "ok": got == want}
        ok &= got == want
    out["rootPins"] = pins
    aux = {}
    for t in AUX_TOOLS:
        w = shutil.which(t, path=ENV["PATH"])
        aux[t] = {"which": w, "realpath": os.path.realpath(w), "sha256": sha_file(os.path.realpath(w))} if w else None
    out["auxTools"] = aux
    out["ok"] = ok
    return out


def host_metadata():
    def rd(p):
        try:
            return open(p).read()
        except OSError as e:
            return f"<{type(e).__name__}>"
    mem = {l.split(":")[0]: l.split(":")[1].strip() for l in rd("/proc/meminfo").splitlines()
           if l.split(":")[0] in ("MemTotal", "MemAvailable", "SwapTotal", "SwapFree")}
    return {"uname": list(os.uname()), "cpuCount": os.cpu_count(), "meminfo": mem, "swaps": rd("/proc/swaps"),
            "corePattern": rd("/proc/sys/kernel/core_pattern").strip(),
            "maxUserNamespaces": rd("/proc/sys/user/max_user_namespaces").strip(),
            "controllerNetns": os.readlink("/proc/self/ns/net"), "controllerUserns": os.readlink("/proc/self/ns/user"),
            "controllerPid": os.getpid(), "controllerPython": sys.executable, "controllerNice": os.nice(0),
            "env": ENV}


def snap_tree(root, skip=()):
    files, priv = {}, {}
    if not os.path.isdir(root):
        return {"root": root, "missing": True}
    for dp, ds, fs in os.walk(root):
        ds[:] = sorted(d for d in ds if os.path.join(dp, d) not in skip)
        for n in sorted(fs):
            p = os.path.join(dp, n)
            rel = os.path.relpath(p, root)
            st = os.lstat(p)
            if n in PRIVATE_NAMES or "private" in n:
                priv[rel] = {"bytes": st.st_size, "mtimeNs": st.st_mtime_ns, "read": False}
            elif os.path.islink(p):
                files[rel] = {"symlink": os.readlink(p)}
            else:
                files[rel] = {"bytes": st.st_size, "sha256": sha_file(p)}
    return {"root": root, "files": files, "statOnlyNotRead": priv}


def snapshot():
    return {
        "REV(excluding task dirs)": snap_tree(REV, skip=(TASK, TASK2)),
        "PIN": snap_tree(PIN),
        "RUSTOUT": snap_tree(RUSTOUT),
        "ATT2/source/scripts": snap_tree(ATT2 + "/source/scripts"),
        "tools": {p: sha_file(p) for p in PINS},
    }


def compare(a, b):
    diff = {}
    for k in a:
        if k == "tools":
            if a[k] != b[k]:
                diff[k] = {"before": a[k], "after": b[k]}
            continue
        fa, fb = a[k].get("files", {}), b[k].get("files", {})
        d = {"added": sorted(set(fb) - set(fa)), "removed": sorted(set(fa) - set(fb)),
             "changed": sorted(x for x in set(fa) & set(fb) if fa[x] != fb[x])}
        pa, pb = a[k].get("statOnlyNotRead", {}), b[k].get("statOnlyNotRead", {})
        if pa != pb:
            d["privateStatChanged"] = {"before": pa, "after": pb}
        if any(d.values()):
            diff[k] = d
    return {"unchanged": not diff, "diff": diff}


def frozen_names():
    doc = open(REV + "/EXPECTED-OUTCOMES-R1.md").read()
    out = {}
    for f, want in (("abi_test", 30), ("context_test", 46)):
        src = open(f"{REV}/source/aiken/lib/pvc/{f}.ak").read()
        names = [m[0] for m in re.findall(r"^test (\w+)\(\)( fail)?", src, re.M)]
        out[f] = {"names": names, "expected": want, "count": len(names),
                  "notInExpectedDoc": [n for n in names if f"`{n}`" not in doc]}
    return out


def parse_check(text):
    dec = json.JSONDecoder()
    for m in re.finditer(r"(?m)^\{", text):
        try:
            obj, _ = dec.raw_decode(text, m.start())
        except ValueError:
            continue
        if isinstance(obj, dict) and "modules" in obj and "summary" in obj:
            tests = [{"module": mod.get("name"), "title": t.get("title"), "status": t.get("status"),
                      "onFailure": t.get("on_failure"), "executionUnits": t.get("execution_units"),
                      "assertion": t.get("assertion"), "traces": t.get("traces")}
                     for mod in obj["modules"] for t in mod.get("tests", [])]
            return {"mode": "json", "summary": obj["summary"], "seed": obj.get("seed"), "tests": tests}
    tests = []
    for line in text.splitlines():
        m = re.search(r"\b(PASS|FAIL)\b[^\]]*\]\s+(\w+)", line)
        if m:
            tests.append({"module": None, "title": m.group(2), "status": m.group(1).lower(), "line": line})
    sums = re.findall(r"(\d+) tests? \| (\d+) passed \| (\d+) failed", text)
    return {"mode": "terminal", "summaryLines": sums, "tests": tests}


def gate_names(log_path, expected_sets):
    text = open(log_path, encoding="utf-8", errors="replace").read()
    parsed = parse_check(text)
    titles = [t["title"] for t in parsed["tests"]]
    passed = [t["title"] for t in parsed["tests"] if t["status"] == "pass"]
    failed = [t["title"] for t in parsed["tests"] if t["status"] != "pass"]
    expected = [n for s in expected_sets for n in s]
    res = {
        "parseMode": parsed["mode"], "observedTotal": len(titles), "observedPassed": len(passed),
        "observedFailed": failed, "expectedTotal": len(expected),
        "duplicatesObserved": sorted({n for n in titles if titles.count(n) > 1}),
        "missing": sorted(set(expected) - set(passed)), "unexpected": sorted(set(titles) - set(expected)),
        "warningLines": len(re.findall(r"(?mi)^\s*warning", text)),
        "parsed": parsed,
    }
    res["ok"] = (len(titles) == len(expected) == len(passed) and not failed and not res["missing"]
                 and not res["unexpected"] and not res["duplicatesObserved"]
                 and len(set(expected)) == len(expected))
    if parsed["mode"] == "json":
        s = parsed["summary"]
        res["ok"] &= s.get("total") == len(expected) and s.get("passed") == len(expected) and s.get("failed") == 0
    return res


def read_exit(p):
    try:
        return open(p).read()
    except OSError:
        return None


# ---- phases --------------------------------------------------------------------------
def phase_a():
    ph = Phase("A")
    st = verify_static(ph)
    ph.write_json("static-check.json", st)
    ph.write_json("host-metadata.json", host_metadata())
    if not st["ok"]:
        ph.journal({"event": "abort-before-any-step", "reason": "static check failed"})
        return finish(ph, "ABORTED-STATIC", None)
    snap0 = snapshot()
    ph.write_json("sources-before.json", snap0)
    fz = frozen_names()
    ph.write_json("frozen-test-names.json", fz)

    status = None
    rc, r = ph.run_literal("A1", A1, TASK + "/logs/A1.exit")
    if rc != 0 or r["exitFileContent"] != "0\n":
        return finish(ph, "STOPPED-A1", snap0)
    for sid in ("A0", "A2", "A3", "A4", "A5"):
        rc, _ = ph.run_step(sid)
        if rc != 0:
            return finish(ph, f"STOPPED-{sid}", snap0)
    rc6, _ = ph.run_step("A6")
    rc7, _ = ph.run_step("A7")  # always, read-only diagnostic
    if rc6 != 0 or rc7 != 0:
        return finish(ph, f"STOPPED-A6/A7 (A6={rc6}, A7={rc7})", snap0)
    names_ok = all(v["count"] == v["expected"] and not v["notInExpectedDoc"] for v in fz.values())
    gate = gate_names(TASK + "/logs/A6.log", [fz["abi_test"]["names"], fz["context_test"]["names"]])
    gate["frozenNameSourceOk"] = names_ok
    gate["ok"] &= names_ok
    ph.write_json("gate-A6-76.json", gate)
    ph.journal({"event": "gate-A6-76", "ok": gate["ok"], "observedTotal": gate["observedTotal"],
                "observedPassed": gate["observedPassed"], "mode": gate["parseMode"]})
    if not gate["ok"]:
        return finish(ph, "STOPPED-A6-NAME-GATE", snap0)
    for sid in ("A8", "A9"):
        rc, _ = ph.run_step(sid)
        if rc != 0:
            return finish(ph, f"STOPPED-{sid}", snap0)
    if read_exit(TASK + "/logs/A9.exit") != "0\n":
        return finish(ph, "STOPPED-A9-EXITFILE", snap0)
    rc, r = ph.run_literal("A10", A10, TASK + "/A10.exit")
    if r["exitFileContent"] != "0\n":
        return finish(ph, "STOPPED-A10", snap0)
    return finish(ph, "A-COMPLETE", snap0)


def phase_v():
    ph = Phase("V")
    st = verify_static(ph)
    ph.write_json("static-check.json", st)
    ph.write_json("host-metadata.json", host_metadata())
    exits = {s: read_exit(f"{TASK}/logs/{s}.exit") for s in ("A1", "A0", "A2", "A3", "A4", "A5", "A6", "A7", "A8", "A9")}
    exits["A10"] = read_exit(TASK + "/A10.exit")
    holds = {}
    for n in ("post-check-A6.json", "post-check-A8.json"):
        try:
            holds[n] = json.load(open(f"{TASK}/receipts/{n}")).get("allHold") is True
        except (OSError, ValueError):
            holds[n] = False
    try:
        g = json.load(open(OUT + "/records-A/gate-A6-76.json"))
        g76 = g.get("ok") is True and g.get("observedPassed") == 76
        asum = json.load(open(OUT + "/records-A/phase-summary.json")).get("status") == "A-COMPLETE"
    except (OSError, ValueError):
        g76, asum = False, False
    vgate = {"exitFiles": exits, "allExitZero": all(v == "0\n" for v in exits.values()),
             "allHold": holds, "gate76": g76, "phaseAComplete": asum}
    vgate["ok"] = st["ok"] and vgate["allExitZero"] and all(holds.values()) and g76 and asum
    ph.write_json("v-precondition.json", vgate)
    if not vgate["ok"]:
        ph.journal({"event": "v-not-eligible", "gate": vgate})
        return finish(ph, "V-NOT-ELIGIBLE", None)
    snap0 = snapshot()
    ph.write_json("sources-before.json", snap0)
    rc, r = ph.run_literal("V0", V0, TASK2 + "/logs/V0.exit")
    if rc != 0 or r["exitFileContent"] != "0\n":
        return finish(ph, "STOPPED-V0", snap0)
    for sid in ("V1", "V2"):
        rc, _ = ph.run_step(sid)
        if rc != 0:
            return finish(ph, f"STOPPED-{sid}", snap0)
    rc3, _ = ph.run_step("V3")
    rc4, _ = ph.run_step("V4")  # always, diagnostic
    fz = frozen_names()
    gen = open(TASK2 + "/run/lib/pvc/x7_vectors_test.ak").read()
    gen_names = [m[0] for m in re.findall(r"^test (\w+)\(\)( fail)?", gen, re.M)]
    gate = gate_names(TASK2 + "/logs/V3.log", [fz["abi_test"]["names"], fz["context_test"]["names"], gen_names])
    gate["generatedNames"] = gen_names
    ph.write_json("observe-V3-89.json", gate)
    ph.journal({"event": "observe-V3-89", "ok": gate["ok"], "observedTotal": gate["observedTotal"],
                "observedPassed": gate["observedPassed"], "mode": gate["parseMode"]})
    if rc3 != 0 or rc4 != 0:
        return finish(ph, f"STOPPED-V3/V4 (V3={rc3}, V4={rc4})", snap0)
    return finish(ph, "V-COMPLETE" if gate["ok"] else "V-COMPLETE-COUNT-MISMATCH", snap0)


def finish(ph, status, snap0):
    summary = {"phase": ph.name, "status": status, "end": now(),
               "steps": [{"id": s["id"], "exit": s["shellEquivalentExit"], "elapsed": s["elapsedSeconds"],
                          "groupEmpty": s["processGroupEmpty"],
                          "logSha256": (s.get("log") or {}).get("sha256")} for s in ph.steps]}
    if snap0 is not None:
        snap1 = snapshot()
        ph.write_json("sources-after.json", snap1)
        summary["sourcesComparison"] = compare(snap0, snap1)
    ph.write_json("phase-summary.json", summary)
    ph.journal({"event": "phase-end", "status": status})
    os.close(ph.jfd)
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] not in ("A", "V", "S"):
        sys.exit("usage: aiken_r1_control.py A|V|S")
    if sys.argv[1] == "S":  # static, read-only: review text, pins, aux tool hashes; runs no step
        r = verify_static(None)
        print(json.dumps({"ok": r["ok"], "literalTextInReview": r["literalTextInReview"],
                          "rootPins": {k: v["ok"] for k, v in r["rootPins"].items()},
                          "controllerSha256": r["controllerSha256"]}, indent=1))
        sys.exit(0 if r["ok"] else 1)
    os.umask(0o022)
    sys.exit(phase_a() if sys.argv[1] == "A" else phase_v())
