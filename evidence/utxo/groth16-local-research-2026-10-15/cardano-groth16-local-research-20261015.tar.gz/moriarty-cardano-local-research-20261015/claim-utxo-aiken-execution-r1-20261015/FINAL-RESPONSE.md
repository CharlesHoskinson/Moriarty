Every step ran once and exited 0: A1, A0, A2–A10, then V0–V4. A6 passed 76/76 and V3 passed 89/89, with no stops, retries or source edits. This is not an acceptance judgment; a fresh independent Opus audit of these results is still needed.

**Results**
- **A0 / V1 (digests):** all 30 entries in the revision's SHA-256 manifest matched, as did the manifest, stdlib, claim, generated-file and generator pins.
- **A2 (tools):** `aiken v1.1.21+42babe5`, Python 3.14.4 and `unshare` all match the root pins (aiken `07f3f927…`, python `52e0a13e…`, unshare `41c65e55…`).
- **A3 (sandbox):** the network namespace contained only `lo`, with zero traffic.
- **A6 (`aiken check`):** 76 tests, 76 passed, 0 failed, no warnings. The names match the frozen source exactly: 30 in `abi_test`, 46 in `context_test`, none missing, unexpected or duplicated.
- **A7 / A9 / V4 (post-checks):** all report `allHold: true`. The stdlib (38 files) and `packages.toml` are unchanged, `aiken.lock` has one package and no etag, and the task HOME and cache stayed empty with no directories created. Nothing tried to fetch or use a cache, so nothing is BLOCKED.
- **A8 (`aiken build`):** `plutus.json` sha256 is `9ffc530d…96fd`. The validator hashes are `c0` = `7f961dfa…bd8d` and `settle0` = `85592a6a…9443`. These are recorded, not predicted.
- **A10:** the real freeze status in `A10.exit` is 0. `task-final.json` covers 27 files, sha256 `1f174178…ca36`.
- **V2:** the regenerated vectors file is `c90b97c9…e3fa` and `cmp` found no difference from the existing generated file.
- **V3:** 89 tests, 89 passed: the 76 frozen tests plus the 13 generated ones. The Groth16 positive tests cost about 2.15–2.18e9 CPU and `cross_vk_rejected` about 4.33e9 CPU, in Aiken's built-in cost model only.
- **Sources:** before/after snapshots show no change to the revision tree (excluding the two new task directories), the stdlib pin, the Rust outputs, the generator scripts or the three tools. I did not read the private provider results; I only checked their file size and timestamp.

**How it was run**
- **Controller:** `controller/aiken_r1_control.py` (sha256 `48731df3…4039`) is a Python stdlib equivalent of the reviewed wrapper. Before running anything it confirmed that all 16 command texts appear verbatim in the pinned review (`902a93ab…`). The `.exit` files hold each child's real exit status, not the wrapper `echo`'s.
- **One deviation:** A2's command also ran inside its own network namespace, so `aiken --version` had no IP network either, as your prompt requires. The command text is unchanged.
- **Blocked command:** one early attempt to list the parent directory was denied by the session's permission rules. It had no effect.

**Limits**
- `decoder_rejects_extra_transition_field_after_option_data` passed, but that pass is not evidence (finding F-R1-3): it passes whether or not the compiler bug exists.
- The decoder-collision risk (B-C) is not exercised, because UNIT tests never decode datums through the real validator wrapper.
- These are UNIT-level results only. They say nothing about ledger `serialiseData` equality, ExUnits or fees, settlement, or funds safety. The deposit fix (F-A) protects the claim deposit, but proof re-wrapping (F-R1-1) is still possible.
- The L1/M1 outref, refund key and expiry are synthetic placeholders. The two verifying keys are host-trusted Class 0 research keys with no proving key, and must never be pinned in a real genesis.
- No Aiken child had IP network access. The agent CLI itself did exchange this transcript with its model provider, so I make no "nothing sent anywhere" claim.
- No Preprod, key, wallet, setup, proving or ledger action took place. This stage closes none of your open tracks.

Everything is in `/home/charl/moriarty-eutxo-validation-2026-10-12/claim-utxo-aiken-execution-r1-20261015`: the full report is `EXECUTION-REPORT.md`, and per-step records with the journals are in `records-A/` and `records-V/`. The step logs and receipts are in `REV/aiken-offline-check-1` and `REV/aiken-offline-check-vectors-1`.