//! P-L0 (ledger bound-bytes predicate) and P-M0 (combined Moriarty action) relations.

use crate::gadgets::*;
use ark_bls12_381::Fr;
use ark_ff::{Field, PrimeField};
use ark_relations::lc;
use ark_relations::r1cs::{ConstraintSynthesizer, ConstraintSystemRef, SynthesisError, Variable};

#[derive(Clone, Debug)]
pub struct Segment {
    pub kind: String,
    pub offset: usize,
    pub len: usize,
    pub hex: Option<Vec<u8>>,
}

#[derive(Clone, Debug)]
pub struct Template {
    pub body_len: usize,
    pub output_index: u8,
    pub address_header: u8,
    pub segments: Vec<Segment>,
}

impl Template {
    pub fn seg(&self, kind: &str) -> &Segment {
        self.segments.iter().find(|s| s.kind == kind).expect("segment")
    }
}

/// Statement constants fixed in the circuit (and therefore in the verifying key).
#[derive(Clone, Debug)]
pub struct StmtConsts {
    pub tag: [u8; 16],
    pub predicate_digest: [u8; 32],
    pub template_digest: [u8; 32],
    pub network_label: [u8; 16],
    pub program_sha256: Option<[u8; 32]>,
}

/// Moriarty `IndependentPayment.pay` witness. Values are field elements so that
/// refusal vectors can carry the field-wrapped results an adversarial prover would use.
#[derive(Clone, Debug)]
pub struct MoriWitness {
    pub accepted: bool,
    pub amount: Fr,
    pub pre: [u128; 4], // paid, payer, recipient, sponsor
}

impl MoriWitness {
    /// Honest field evaluation of the hand-lowered action (wraps in Fr; no checks).
    pub fn post_fr(&self) -> [Fr; 4] {
        let [paid, payer, recip, spons] = self.pre.map(Fr::from);
        let two = Fr::from(2u64);
        [paid + self.amount, payer - self.amount - two, recip + self.amount, spons + two]
    }
}

#[derive(Clone, Debug)]
pub struct Instance {
    pub tpl: Template,
    pub consts: StmtConsts,
    pub body: Vec<u8>,
    pub threshold: u64,
    pub mori: Option<MoriWitness>,
    /// When false (X3 control), the public inputs are allocated but not tied to the digest.
    pub bind_statement: bool,
    /// Public input values the prover assigns (honest runs use the native statement digest).
    pub public: (Fr, Fr),
}

pub struct Circuit {
    pub inst: Instance,
    pub labels: Labels,
}

pub fn fr_from_be(bytes: &[u8]) -> Fr {
    Fr::from_be_bytes_mod_order(bytes)
}

/// Outputs of synthesis that the host can compare with the native reference.
#[derive(Default, Clone, Debug)]
pub struct Observed {
    pub txid: Vec<u8>,
    pub statement: Vec<u8>,
    pub digest: Vec<u8>,
}

thread_local! {
    pub static OBSERVED: std::cell::RefCell<Observed> = std::cell::RefCell::new(Observed::default());
}

impl ConstraintSynthesizer<Fr> for Circuit {
    fn generate_constraints(self, cs: ConstraintSystemRef<Fr>) -> Result<(), SynthesisError> {
        let ctx = Ctx { cs, labels: self.labels.clone() };
        let inst = &self.inst;
        let tpl = &inst.tpl;
        assert_eq!(inst.body.len(), tpl.body_len, "body length is a circuit constant");

        // Public inputs first (instance variables).
        ctx.label("public-inputs");
        let (hi_v, lo_v) = inst.public;
        let x_hi = ctx.input(hi_v)?;
        let x_lo = ctx.input(lo_v)?;

        // Body bytes: every byte is a witness; const segments are pinned.
        ctx.label("body-bytes-booleanity");
        let body: Vec<Byte> = inst.body.iter().map(|&b| alloc_byte(&ctx, b)).collect::<R<_>>()?;
        ctx.label("template-const");
        for s in tpl.segments.iter().filter(|s| s.kind == "const") {
            let want = s.hex.as_ref().unwrap();
            for (k, &w) in want.iter().enumerate() {
                for (i, bit) in body[s.offset + k].iter().enumerate() {
                    let c = if (w >> i) & 1 == 1 { lc!() + Variable::One } else { lc!() };
                    ctx.enforce_eq(bit.lc.clone(), c)?;
                }
            }
        }

        ctx.label("blake2b256(body)=txid");
        let txid = blake2b256(&ctx, &body)?;

        // Target output fields (positions fixed by the template).
        let pc = tpl.seg("pay_cred");
        let pay_cred: Vec<Byte> = body[pc.offset..pc.offset + 28].to_vec();
        let addr_header: Byte = body[pc.offset - 1].clone();
        let cs_ = tpl.seg("coin_be");
        let coin_bytes: Vec<Byte> = body[cs_.offset..cs_.offset + cs_.len].to_vec();
        let coin_lc = be_lc(&coin_bytes);
        let coin_val = be_val(&coin_bytes);

        // Threshold (statement field) and coin >= threshold.
        ctx.label("threshold-bytes");
        let t_bytes: Vec<Byte> =
            inst.threshold.to_be_bytes().iter().map(|&b| alloc_byte(&ctx, b)).collect::<R<_>>()?;
        let t_lc = be_lc(&t_bytes);
        ctx.label("coin>=threshold");
        let diff = Fr::from(coin_val as u64) - Fr::from(inst.threshold);
        alloc_bits_of(&ctx, diff, 64, coin_lc.clone() - &t_lc)?;

        // Statement bytes.
        let mut stmt: Vec<Byte> = Vec::new();
        stmt.extend(inst.consts.tag.iter().map(|&b| byte_const(b)));
        stmt.extend(inst.consts.predicate_digest.iter().map(|&b| byte_const(b)));
        stmt.extend(inst.consts.template_digest.iter().map(|&b| byte_const(b)));
        stmt.extend(inst.consts.network_label.iter().map(|&b| byte_const(b)));
        stmt.extend(txid.iter().cloned());
        stmt.push(byte_const(tpl.output_index));
        stmt.push(addr_header);
        stmt.extend(pay_cred);
        stmt.extend(t_bytes);

        if let Some(m) = &inst.mori {
            let prog = inst.consts.program_sha256.expect("program digest");
            stmt.extend(prog.iter().map(|&b| byte_const(b)));

            ctx.label("requires accepted");
            let accepted = Bit::alloc(&ctx, m.accepted)?;
            ctx.enforce_eq(accepted.lc.clone(), lc!() + Variable::One)?;

            ctx.label("adapter amount=coin (u128)");
            let amount = alloc_bits_of(&ctx, m.amount, 128, coin_lc.clone())?;
            let amount_lc = pack(&amount);

            ctx.label("requires amount>0");
            let inv = m.amount.inverse().unwrap_or(Fr::from(0u64));
            let inv_v = ctx.witness(inv)?;
            ctx.enforce(amount_lc.clone(), lc!() + inv_v, lc!() + Variable::One)?;

            ctx.label("pre-snapshot range");
            let pre: Vec<Vec<Bit>> = m
                .pre
                .iter()
                .map(|&v| (0..128).map(|i| Bit::alloc(&ctx, (v >> i) & 1 == 1)).collect::<R<Vec<_>>>())
                .collect::<R<_>>()?;
            let [paid0, payer0, recip0, spons0] = [&pre[0], &pre[1], &pre[2], &pre[3]].map(|b| pack(b));
            let post = m.post_fr();
            let two = Fr::from(2u64);
            let payer1_fr = Fr::from(m.pre[1]) - m.amount;

            ctx.label("transfer debit payer (checked sub)");
            let payer1 = alloc_bits_of(&ctx, payer1_fr, 128, payer0.clone() - &amount_lc)?;
            ctx.label("transfer credit recipient (checked add)");
            let recip1 = alloc_bits_of(&ctx, post[2], 128, recip0 + &amount_lc)?;
            ctx.label("fee debit payer (checked sub)");
            let payer2 = alloc_bits_of(&ctx, post[1], 128, pack(&payer1) - (two, Variable::One))?;
            ctx.label("fee credit sponsor (checked add)");
            let spons1 = alloc_bits_of(&ctx, post[3], 128, spons0 + (two, Variable::One))?;
            ctx.label("next paid = paid + amount (checked add)");
            let paid1 = alloc_bits_of(&ctx, post[0], 128, paid0 + &amount_lc)?;

            let mut acc_byte = vec![accepted];
            acc_byte.extend((1..8).map(|_| Bit::constant(false)));
            stmt.push(acc_byte);
            stmt.extend(u128_be_bytes(&amount));
            for p in &pre {
                stmt.extend(u128_be_bytes(p));
            }
            for p in [&paid1, &payer2, &recip1, &spons1] {
                stmt.extend(u128_be_bytes(p));
            }
        }

        ctx.label("blake2b256(statement)");
        let digest = blake2b256(&ctx, &stmt)?;

        OBSERVED.with(|o| {
            *o.borrow_mut() = Observed {
                txid: txid.iter().map(byte_val).collect(),
                statement: stmt.iter().map(byte_val).collect(),
                digest: digest.iter().map(byte_val).collect(),
            }
        });

        if inst.bind_statement {
            ctx.label("public-input binding hi");
            ctx.enforce_eq(lc!() + x_hi, be_lc(&digest[0..16]))?;
            ctx.label("public-input binding lo");
            ctx.enforce_eq(lc!() + x_lo, be_lc(&digest[16..32]))?;
        }
        ctx.label("end");
        Ok(())
    }
}

/// Field encoding of a 32-byte digest as the two public inputs.
pub fn public_inputs(digest: &[u8]) -> (Fr, Fr) {
    (fr_from_be(&digest[0..16]), fr_from_be(&digest[16..32]))
}

pub fn fr_to_dec(x: &Fr) -> String {
    x.into_bigint().to_string()
}
