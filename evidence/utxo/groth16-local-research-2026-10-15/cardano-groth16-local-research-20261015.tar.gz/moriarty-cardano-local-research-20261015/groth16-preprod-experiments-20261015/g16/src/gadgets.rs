//! Hand-written R1CS gadgets over the BLS12-381 scalar field (research only).
//!
//! A `Bit` is a linear combination that is constrained (or constant) to {0,1},
//! carried with its honest value so witnesses can be built in one pass.
//! Every region of constraints is labelled so an unsatisfied index can be named.

use ark_bls12_381::Fr;
use ark_ff::{BigInteger, Field, PrimeField};
use ark_relations::lc;
use ark_relations::r1cs::{ConstraintSystemRef, LinearCombination, SynthesisError, Variable};
use std::cell::RefCell;
use std::rc::Rc;

pub type Lc = LinearCombination<Fr>;
pub type R<T> = Result<T, SynthesisError>;

/// Constraint index ranges: (first constraint index, label).
pub type Labels = Rc<RefCell<Vec<(usize, String)>>>;

pub struct Ctx {
    pub cs: ConstraintSystemRef<Fr>,
    pub labels: Labels,
}

impl Ctx {
    pub fn label(&self, name: &str) {
        self.labels.borrow_mut().push((self.cs.num_constraints(), name.to_string()));
    }
    pub fn enforce(&self, a: Lc, b: Lc, c: Lc) -> R<()> {
        self.cs.enforce_constraint(a, b, c)
    }
    /// a == b as linear combinations (one constraint).
    pub fn enforce_eq(&self, a: Lc, b: Lc) -> R<()> {
        self.enforce(a - b, lc!() + Variable::One, lc!())
    }
    pub fn witness(&self, v: Fr) -> R<Variable> {
        self.cs.new_witness_variable(|| Ok(v))
    }
    pub fn input(&self, v: Fr) -> R<Variable> {
        self.cs.new_input_variable(|| Ok(v))
    }
}

pub fn label_of(labels: &[(usize, String)], idx: usize) -> String {
    labels
        .iter()
        .rev()
        .find(|(s, _)| *s <= idx)
        .map(|(_, l)| l.clone())
        .unwrap_or_else(|| "unlabelled".into())
}

pub fn pow2(i: u32) -> Fr {
    Fr::from(2u64).pow([i as u64])
}

#[derive(Clone)]
pub struct Bit {
    pub lc: Lc,
    pub val: bool,
}

impl Bit {
    pub fn constant(v: bool) -> Bit {
        Bit { lc: if v { lc!() + Variable::One } else { lc!() }, val: v }
    }
    pub fn alloc(ctx: &Ctx, v: bool) -> R<Bit> {
        let var = ctx.witness(if v { Fr::from(1u64) } else { Fr::from(0u64) })?;
        // b * (1 - b) = 0
        ctx.enforce(lc!() + var, lc!() + Variable::One - var, lc!())?;
        Ok(Bit { lc: lc!() + var, val: v })
    }
    pub fn is_const(&self) -> Option<bool> {
        // A constant bit's lc only references Variable::One (or nothing).
        if self.lc.0.iter().all(|(_, v)| *v == Variable::One) {
            Some(self.val)
        } else {
            None
        }
    }
    pub fn not(&self) -> Bit {
        Bit { lc: lc!() + Variable::One - &self.lc, val: !self.val }
    }
    pub fn xor(ctx: &Ctx, a: &Bit, b: &Bit) -> R<Bit> {
        match (a.is_const(), b.is_const()) {
            (Some(x), _) => Ok(if x { b.not() } else { b.clone() }),
            (_, Some(y)) => Ok(if y { a.not() } else { a.clone() }),
            _ => {
                let v = a.val ^ b.val;
                let c = ctx.witness(Fr::from(v as u64))?;
                // (2a) * b = a + b - c
                ctx.enforce(&a.lc * Fr::from(2u64), b.lc.clone(), &a.lc + &b.lc - c)?;
                Ok(Bit { lc: lc!() + c, val: v })
            }
        }
    }
}

/// Little-endian bits of an unsigned integer value held in `n` allocated bits,
/// constrained so that `packed == sum bits_i 2^i`. Returns the bits.
/// If `value` (a field element) is >= 2^n the honest bits cannot satisfy the packing.
pub fn alloc_bits_of(ctx: &Ctx, value: Fr, n: u32, packed: Lc) -> R<Vec<Bit>> {
    let big = value.into_bigint().to_bits_le();
    let mut bits = Vec::with_capacity(n as usize);
    let mut sum = lc!();
    for i in 0..n {
        let b = Bit::alloc(ctx, big.get(i as usize).copied().unwrap_or(false))?;
        sum = sum + &(&b.lc * pow2(i));
        bits.push(b);
    }
    ctx.enforce_eq(packed, sum)?;
    Ok(bits)
}

pub fn pack(bits: &[Bit]) -> Lc {
    let mut s = lc!();
    for (i, b) in bits.iter().enumerate() {
        s = s + &(&b.lc * pow2(i as u32));
    }
    s
}

pub fn value_of(bits: &[Bit]) -> u128 {
    bits.iter().enumerate().fold(0u128, |a, (i, b)| a | ((b.val as u128) << i))
}

pub type Word = Vec<Bit>; // 64 bits, little-endian

pub fn word_const(v: u64) -> Word {
    (0..64).map(|i| Bit::constant((v >> i) & 1 == 1)).collect()
}

pub fn word_val(w: &Word) -> u64 {
    value_of(w) as u64
}

pub fn word_xor(ctx: &Ctx, a: &Word, b: &Word) -> R<Word> {
    a.iter().zip(b).map(|(x, y)| Bit::xor(ctx, x, y)).collect()
}

pub fn word_rotr(a: &Word, n: usize) -> Word {
    (0..64).map(|i| a[(i + n) % 64].clone()).collect()
}

/// Sum of 2 or 3 words modulo 2^64: one packing constraint plus booleanity of 64+2 bits.
pub fn word_add(ctx: &Ctx, ws: &[&Word]) -> R<Word> {
    let total: u128 = ws.iter().map(|w| word_val(w) as u128).sum();
    let res = (total & 0xFFFF_FFFF_FFFF_FFFF) as u64;
    let carry = (total >> 64) as u64;
    let mut lhs = lc!();
    for w in ws {
        lhs = lhs + &pack(w);
    }
    let mut out = Vec::with_capacity(64);
    let mut rhs = lc!();
    for i in 0..64 {
        let b = Bit::alloc(ctx, (res >> i) & 1 == 1)?;
        rhs = rhs + &(&b.lc * pow2(i));
        out.push(b);
    }
    for j in 0..2u32 {
        let c = Bit::alloc(ctx, (carry >> j) & 1 == 1)?;
        rhs = rhs + &(&c.lc * pow2(64 + j));
    }
    ctx.enforce_eq(lhs, rhs)?;
    Ok(out)
}

/// One byte as 8 little-endian bits.
pub type Byte = Vec<Bit>;

pub fn byte_const(v: u8) -> Byte {
    (0..8).map(|i| Bit::constant((v >> i) & 1 == 1)).collect()
}

pub fn alloc_byte(ctx: &Ctx, v: u8) -> R<Byte> {
    (0..8).map(|i| Bit::alloc(ctx, (v >> i) & 1 == 1)).collect()
}

pub fn byte_val(b: &Byte) -> u8 {
    value_of(b) as u8
}

/// Big-endian integer of bytes as a linear combination.
pub fn be_lc(bytes: &[Byte]) -> Lc {
    let n = bytes.len() as u32;
    let mut s = lc!();
    for (k, byte) in bytes.iter().enumerate() {
        let shift = 8 * (n - 1 - k as u32);
        for (i, b) in byte.iter().enumerate() {
            s = s + &(&b.lc * pow2(shift + i as u32));
        }
    }
    s
}

pub fn be_val(bytes: &[Byte]) -> u128 {
    bytes.iter().fold(0u128, |a, b| (a << 8) | byte_val(b) as u128)
}

/// Bytes of an allocated u128 bit vector (little-endian bits) in big-endian byte order.
pub fn u128_be_bytes(bits: &[Bit]) -> Vec<Byte> {
    (0..16).rev().map(|k| bits[8 * k..8 * k + 8].to_vec()).collect()
}

// ---------------- BLAKE2b (RFC 7693) ----------------

pub const IV: [u64; 8] = [
    0x6a09e667f3bcc908,
    0xbb67ae8584caa73b,
    0x3c6ef372fe94f82b,
    0xa54ff53a5f1d36f1,
    0x510e527fade682d1,
    0x9b05688c2b3e6c1f,
    0x1f83d9abfb41bd6b,
    0x5be0cd19137e2179,
];

pub const SIGMA: [[usize; 16]; 10] = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
    [14, 10, 4, 8, 9, 15, 13, 6, 1, 12, 0, 2, 11, 7, 5, 3],
    [11, 8, 12, 0, 5, 2, 15, 13, 10, 14, 3, 6, 7, 1, 9, 4],
    [7, 9, 3, 1, 13, 12, 11, 14, 2, 6, 5, 10, 4, 0, 15, 8],
    [9, 0, 5, 7, 2, 4, 10, 15, 14, 1, 11, 12, 6, 8, 3, 13],
    [2, 12, 6, 10, 0, 11, 8, 3, 4, 13, 7, 5, 15, 14, 1, 9],
    [12, 5, 1, 15, 14, 13, 4, 10, 0, 7, 6, 3, 9, 2, 8, 11],
    [13, 11, 7, 14, 12, 1, 3, 9, 5, 0, 15, 4, 8, 6, 2, 10],
    [6, 15, 14, 9, 11, 3, 0, 8, 12, 2, 13, 7, 1, 4, 10, 5],
    [10, 2, 8, 4, 7, 6, 1, 5, 15, 11, 9, 14, 3, 12, 13, 0],
];

#[allow(clippy::too_many_arguments)]
fn g(ctx: &Ctx, v: &mut [Word], a: usize, b: usize, c: usize, d: usize, x: &Word, y: &Word) -> R<()> {
    v[a] = word_add(ctx, &[&v[a], &v[b], x])?;
    v[d] = word_rotr(&word_xor(ctx, &v[d], &v[a])?, 32);
    v[c] = word_add(ctx, &[&v[c], &v[d]])?;
    v[b] = word_rotr(&word_xor(ctx, &v[b], &v[c])?, 24);
    v[a] = word_add(ctx, &[&v[a], &v[b], y])?;
    v[d] = word_rotr(&word_xor(ctx, &v[d], &v[a])?, 16);
    v[c] = word_add(ctx, &[&v[c], &v[d]])?;
    v[b] = word_rotr(&word_xor(ctx, &v[b], &v[c])?, 63);
    Ok(())
}

fn compress(ctx: &Ctx, h: &mut [Word], block: &[Byte], t: u128, last: bool) -> R<()> {
    assert_eq!(block.len(), 128);
    let m: Vec<Word> = (0..16)
        .map(|w| (0..8).flat_map(|j| block[8 * w + j].clone()).collect())
        .collect();
    let mut v: Vec<Word> = h.to_vec();
    v.extend(IV.iter().map(|&x| word_const(x)));
    v[12] = word_xor(ctx, &v[12], &word_const(t as u64))?;
    v[13] = word_xor(ctx, &v[13], &word_const((t >> 64) as u64))?;
    if last {
        v[14] = word_xor(ctx, &v[14], &word_const(u64::MAX))?;
    }
    for r in 0..12 {
        let s = SIGMA[r % 10];
        g(ctx, &mut v, 0, 4, 8, 12, &m[s[0]], &m[s[1]])?;
        g(ctx, &mut v, 1, 5, 9, 13, &m[s[2]], &m[s[3]])?;
        g(ctx, &mut v, 2, 6, 10, 14, &m[s[4]], &m[s[5]])?;
        g(ctx, &mut v, 3, 7, 11, 15, &m[s[6]], &m[s[7]])?;
        g(ctx, &mut v, 0, 5, 10, 15, &m[s[8]], &m[s[9]])?;
        g(ctx, &mut v, 1, 6, 11, 12, &m[s[10]], &m[s[11]])?;
        g(ctx, &mut v, 2, 7, 8, 13, &m[s[12]], &m[s[13]])?;
        g(ctx, &mut v, 3, 4, 9, 14, &m[s[14]], &m[s[15]])?;
    }
    for i in 0..8 {
        let t1 = word_xor(ctx, &h[i], &v[i])?;
        h[i] = word_xor(ctx, &t1, &v[i + 8])?;
    }
    Ok(())
}

/// BLAKE2b-256 (unkeyed) of a fixed-length message of in-circuit bytes.
/// The message length is a circuit constant. Returns 32 output bytes.
pub fn blake2b256(ctx: &Ctx, msg: &[Byte]) -> R<Vec<Byte>> {
    let len = msg.len();
    let mut h: Vec<Word> = IV.iter().map(|&x| word_const(x)).collect();
    h[0] = word_const(IV[0] ^ 0x0101_0020);
    let blocks = std::cmp::max(1, len.div_ceil(128));
    for i in 0..blocks {
        let mut block: Vec<Byte> = msg[i * 128..std::cmp::min(len, (i + 1) * 128)].to_vec();
        while block.len() < 128 {
            block.push(byte_const(0));
        }
        let last = i + 1 == blocks;
        let t = if last { len as u128 } else { ((i + 1) * 128) as u128 };
        compress(ctx, &mut h, &block, t, last)?;
    }
    let mut out = Vec::with_capacity(32);
    for w in h.iter().take(4) {
        for j in 0..8 {
            out.push(w[8 * j..8 * j + 8].to_vec());
        }
    }
    Ok(out)
}
