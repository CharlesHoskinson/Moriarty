#!/usr/bin/env python3
"""Text-only consistency check: test names in .ak files versus the frozen
expectations document. Does not parse or evaluate Aiken.

Usage: python3 -I check_names.py EXPECTED_MD AK_FILE:COUNT [AK_FILE:COUNT ...]
"""
import json
import re
import sys


def main():
    doc = open(sys.argv[1]).read()
    report, ok = [], True
    for arg in sys.argv[2:]:
        path, want = arg.rsplit(":", 1)
        tests = re.findall(r"^test (\w+)\(\)( fail)?", open(path).read(), re.M)
        names = [t[0] for t in tests]
        missing = [n for n in names if f"`{n}`" not in doc]
        dup = sorted({n for n in names if names.count(n) > 1})
        good = len(names) == int(want) and not missing and not dup
        ok &= good
        report.append({"file": path, "count": len(names), "expected": int(want), "notInDoc": missing,
                       "duplicates": dup, "failTests": [n for n, f in tests if f], "ok": good})
    print(json.dumps(report, indent=2))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
