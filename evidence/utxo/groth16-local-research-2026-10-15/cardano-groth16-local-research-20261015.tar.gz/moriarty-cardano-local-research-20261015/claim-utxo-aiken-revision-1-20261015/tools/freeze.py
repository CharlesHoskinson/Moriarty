#!/usr/bin/env python3
"""Write a SHA-256 freeze receipt. Plain stdlib; refuses to overwrite.

Usage: python3 -I freeze.py OUT_JSON LABEL ROOT FILE [FILE ...]
FILE paths are relative to ROOT; a directory argument is expanded recursively.
"""
import datetime
import hashlib
import json
import os
import sys


def main():
    out, label, root = sys.argv[1:4]
    rels = []
    for a in sys.argv[4:]:
        p = os.path.join(root, a)
        if os.path.isdir(p):
            rels += [os.path.relpath(os.path.join(dp, n), root)
                     for dp, _, ns in os.walk(p) for n in ns]
        else:
            rels.append(a)
    rows = []
    for rel in sorted(set(rels)):
        with open(os.path.join(root, rel), "rb") as f:
            b = f.read()
        rows.append({"path": rel, "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()})
    doc = {"schema": "moriarty-research/freeze-receipt/v0", "label": label, "root": os.path.abspath(root),
           "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "files": rows}
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    with open(out, "x") as f:
        json.dump(doc, f, indent=2)
        f.write("\n")
    print(json.dumps({"label": label, "files": len(rows)}))


if __name__ == "__main__":
    main()
