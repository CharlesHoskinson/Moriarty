#!/usr/bin/env python3
"""Copy the attempt-2 Aiken subtree into this revision, verifying every byte.

Usage: python3 -I copy_aiken.py SRC_AIKEN_DIR DST_AIKEN_DIR FREEZE_JSON RECEIPT_JSON
Plain stdlib file copy and SHA-256 only. Refuses to overwrite and refuses any
file whose digest differs from the review's SOURCE-FREEZE.json.
"""
import hashlib
import json
import os
import sys

FILES = [
    "aiken.toml",
    "validators/c0.ak",
    "validators/settle0.ak",
    "lib/pvc/abi.ak",
    "lib/pvc/c0.ak",
    "lib/pvc/settle.ak",
    "lib/pvc/abi_test.ak",
    "lib/pvc/context_test.ak",
]


def sha(b):
    return hashlib.sha256(b).hexdigest()


def main():
    src, dst, freeze_path, receipt_path = sys.argv[1:5]
    with open(freeze_path) as f:
        freeze = json.load(f)
    frozen = {}

    def walk(x):
        if isinstance(x, dict):
            if "path" in x and "sha256" in x:
                frozen[x["path"]] = x["sha256"]
            for v in x.values():
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)

    walk(freeze)
    found = sorted(
        os.path.relpath(os.path.join(dp, n), src)
        for dp, _, ns in os.walk(src) for n in ns
    )
    if found != sorted(FILES):
        sys.exit(f"source subtree differs from the expected 8 files: {found}")
    rows = []
    for rel in FILES:
        sp = os.path.join(src, rel)
        with open(sp, "rb") as f:
            data = f.read()
        want = frozen.get(os.path.abspath(sp))
        if want is None or want != sha(data):
            sys.exit(f"digest mismatch or unfrozen: {sp}")
        dp = os.path.join(dst, rel)
        mode = "copied"
        if os.path.exists(dp):
            # Never overwrite; an existing destination must already be identical.
            with open(dp, "rb") as f:
                if sha(f.read()) != want:
                    sys.exit(f"refusing to overwrite differing {dp}")
            mode = "already-identical"
        else:
            os.makedirs(os.path.dirname(dp), exist_ok=True)
            with open(dp, "xb") as f:
                f.write(data)
        with open(dp, "rb") as f:
            if sha(f.read()) != want:
                sys.exit(f"copy verification failed: {dp}")
        rows.append({"rel": rel, "bytes": len(data), "sha256": want,
                     "source": os.path.abspath(sp), "frozenMatch": True, "mode": mode})
    os.makedirs(os.path.dirname(receipt_path), exist_ok=True)
    with open(receipt_path, "x") as f:
        json.dump({"schema": "moriarty-research/copy-receipt/v0",
                   "freeze": os.path.abspath(freeze_path),
                   "freezeSha256": sha(open(freeze_path, "rb").read()),
                   "note": "first invocation copied all 8 files, then failed writing this receipt "
                           "(receipts/ missing); this invocation re-verified them byte for byte",
                   "files": rows}, f, indent=2)
        f.write("\n")
    print(json.dumps({"copied": len(rows)}))


if __name__ == "__main__":
    main()
