#!/usr/bin/env python3
"""Unified diff of two source trees (stdlib difflib). Usage: diff_tree.py OLD NEW OUT"""
import difflib
import os
import sys


def files(root):
    return sorted(os.path.relpath(os.path.join(dp, n), root) for dp, _, ns in os.walk(root) for n in ns)


def main():
    old, new, out = sys.argv[1:4]
    chunks = []
    for rel in sorted(set(files(old)) | set(files(new))):
        a = open(os.path.join(old, rel)).read().splitlines(True) if os.path.exists(os.path.join(old, rel)) else []
        b = open(os.path.join(new, rel)).read().splitlines(True) if os.path.exists(os.path.join(new, rel)) else []
        chunks += difflib.unified_diff(a, b, f"attempt-2/{rel}", f"revision-1/{rel}")
    with open(out, "x") as f:
        f.writelines(chunks)
    print(f"{out}: {sum(1 for c in chunks if c.startswith('+++'))} files changed")


if __name__ == "__main__":
    main()
