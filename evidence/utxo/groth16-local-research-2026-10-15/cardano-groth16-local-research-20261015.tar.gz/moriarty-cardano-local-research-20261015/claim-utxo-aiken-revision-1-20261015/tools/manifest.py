#!/usr/bin/env python3
"""Revision manifest and review-input list. Plain stdlib hashing; refuses to overwrite.

Usage: python3 -I manifest.py REVISION_DIR EXTERNAL_LIST_JSON

Writes REVISION_DIR/SOURCE-MANIFEST-R1.json, SOURCE-MANIFEST-R1.sha256 (sha256sum -c
format, paths relative to REVISION_DIR) and REVIEW-INPUT.json (revision files plus
the external read-only inputs listed in EXTERNAL_LIST_JSON: [{"path", "role"}]).
Runner-owned files are excluded: provider-result.private.json, process.stderr,
PROCESS.json, FINAL-RESPONSE.md; so are the outputs themselves.
"""
import hashlib
import json
import os
import sys

EXCLUDE = {"provider-result.private.json", "process.stderr", "PROCESS.json", "FINAL-RESPONSE.md",
           "SOURCE-MANIFEST-R1.json", "SOURCE-MANIFEST-R1.sha256", "REVIEW-INPUT.json"}


def digest(p):
    with open(p, "rb") as f:
        b = f.read()
    return len(b), hashlib.sha256(b).hexdigest()


def role(rel):
    if rel.startswith("source/aiken/"):
        return "candidate-source"
    if rel.startswith("tools/") or rel.startswith("fixtures/gen_"):
        return "author-tool (plain stdlib)"
    if rel.startswith("fixtures/"):
        return "frozen-expectation"
    if rel.startswith("receipts/"):
        return "receipt"
    if rel in ("PROMPT.md", "run-author.py"):
        return "runner-input (not authored here)"
    return "document"


def main():
    rev, ext_list = sys.argv[1:3]
    rows = []
    for dp, dns, ns in os.walk(rev):
        dns[:] = [d for d in dns if not d.startswith("aiken-offline-check")]
        for n in ns:
            rel = os.path.relpath(os.path.join(dp, n), rev)
            if rel in EXCLUDE:
                continue
            size, h = digest(os.path.join(rev, rel))
            rows.append({"path": rel, "bytes": size, "sha256": h, "role": role(rel)})
    rows.sort(key=lambda r: r["path"])
    man = {"schema": "moriarty-research/source-manifest/v0", "revision": "claim-utxo Aiken revision 1",
           "root": os.path.abspath(rev), "status": "CANDIDATE; not compiled, tested or run",
           "files": rows}
    for name, text in (("SOURCE-MANIFEST-R1.json", json.dumps(man, indent=2) + "\n"),
                       ("SOURCE-MANIFEST-R1.sha256", "".join(f"{r['sha256']}  {r['path']}\n" for r in rows))):
        with open(os.path.join(rev, name), "x") as f:
            f.write(text)
    ext = []
    for e in json.load(open(ext_list)):
        size, h = digest(e["path"])
        ext.append({"path": e["path"], "bytes": size, "sha256": h, "role": e["role"]})
    msize, mh = digest(os.path.join(rev, "SOURCE-MANIFEST-R1.json"))
    review = {"schema": "moriarty-research/review-input/v0",
              "subject": "claim-UTxO Aiken revision 1 (F-B, F-A, F-N, F-M, decoder probes) and its documents",
              "sourceManifest": {"path": "SOURCE-MANIFEST-R1.json", "bytes": msize, "sha256": mh},
              "revisionFiles": rows, "externalInputs": ext,
              "excludedPrivate": sorted(EXCLUDE - {"SOURCE-MANIFEST-R1.json", "SOURCE-MANIFEST-R1.sha256",
                                                   "REVIEW-INPUT.json"})}
    with open(os.path.join(rev, "REVIEW-INPUT.json"), "x") as f:
        json.dump(review, f, indent=2)
        f.write("\n")
    print(json.dumps({"revisionFiles": len(rows), "externalInputs": len(ext), "manifestSha256": mh}))


if __name__ == "__main__":
    main()
