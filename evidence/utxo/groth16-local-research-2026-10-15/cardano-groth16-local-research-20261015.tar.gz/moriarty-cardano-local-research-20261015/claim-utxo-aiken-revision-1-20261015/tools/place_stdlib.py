#!/usr/bin/env python3
"""S8c (EXECUTION-REQUEST-R1 step A4): build an offline Aiken run directory.

NOT RUN BY ITS AUTHOR. Requires root authorization of A4.

Usage:
  python3 -I place_stdlib.py REVISION_DIR STDLIB_PIN_DIR RUN_DIR RECEIPT_JSON

Effect (plain stdlib file copies; nothing executed, no network, no user cache):
  RUN_DIR/                                   new; must not exist
    <copy of REVISION_DIR/source/aiken>      verified against REVISION_DIR/SOURCE-MANIFEST-R1.json
    build/packages/aiken-lang-stdlib/<38 files>  verified against STDLIB_PIN_DIR/SOURCE-MANIFEST.json
    build/packages/packages.toml             one entry: aiken-lang/stdlib v2.2.0 github

Why this suffices (aiken repo pin 2a0475328be2, crates/aiken-project/src):
  deps.rs:105-120  a manifest package is "missing" unless packages.toml lists the
                   same name with an equal tag/sha version; v2.2.0 matches
                   paths.rs:175-179; with nothing missing, deps.rs:210 skips the
                   Downloader, so neither the network nor paths::packages_cache()
                   (the user cache) is touched.
  manifest.rs:127  versions are resolved from aiken.toml only (no transitive deps,
                   so the stdlib's own aiken-lang/fuzz requirement is not needed).
  lib.rs:715-724   only build/packages/aiken-lang-stdlib/lib is read.
These are v1.1.24-era sources; the installed v1.1.21 is confirmed only by A6's
observations (EXPECTED-OUTCOMES-R1.md §4).
"""
import hashlib
import json
import os
import sys

STDLIB_COMMIT = "779e9025356a85484475e06d5a14acb032bcdcc9"
STDLIB_ARCHIVE_SHA256 = "90c07de94ebf858f0d78292a9482cfa3b2b45767ed85fd381e74c0463cdf9b51"
PACKAGES_TOML = '[[packages]]\nname = "aiken-lang/stdlib"\nversion = "v2.2.0"\nsource = "github"\n'


def sha(b):
    return hashlib.sha256(b).hexdigest()


def read(p):
    with open(p, "rb") as f:
        return f.read()


def tree(root):
    return sorted(os.path.relpath(os.path.join(dp, n), root) for dp, _, ns in os.walk(root) for n in ns)


def copy_verified(src_root, dst_root, entries):
    """entries: {rel: sha256}. The source tree must hold exactly these files."""
    if tree(src_root) != sorted(entries):
        sys.exit(f"{src_root}: file set differs from its manifest")
    rows = []
    for rel in sorted(entries):
        data = read(os.path.join(src_root, rel))
        if sha(data) != entries[rel]:
            sys.exit(f"digest mismatch: {src_root}/{rel}")
        dp = os.path.join(dst_root, rel)
        os.makedirs(os.path.dirname(dp), exist_ok=True)
        with open(dp, "xb") as f:
            f.write(data)
        if sha(read(dp)) != entries[rel]:
            sys.exit(f"copy verification failed: {dp}")
        rows.append({"path": rel, "bytes": len(data), "sha256": entries[rel]})
    return rows


def main():
    revision, pin, run, receipt = sys.argv[1:5]
    if os.path.exists(run):
        sys.exit(f"{run} exists; a run directory is single-use")

    pin_doc = json.loads(read(os.path.join(pin, "SOURCE-PIN.json")))
    if pin_doc.get("commit") != STDLIB_COMMIT or pin_doc.get("archiveSha256") != STDLIB_ARCHIVE_SHA256:
        sys.exit("SOURCE-PIN.json does not name the reviewed stdlib commit/archive")
    if sha(read(os.path.join(pin, "stdlib-source.tar.gz"))) != STDLIB_ARCHIVE_SHA256:
        sys.exit("archive digest differs from the pin")
    std = {f["path"]: f["sha256"] for f in json.loads(read(os.path.join(pin, "SOURCE-MANIFEST.json")))["files"]}
    if len(std) != 38:
        sys.exit("stdlib manifest must list exactly 38 files")

    rev = json.loads(read(os.path.join(revision, "SOURCE-MANIFEST-R1.json")))
    prefix = "source/aiken/"
    proj = {f["path"][len(prefix):]: f["sha256"] for f in rev["files"] if f["path"].startswith(prefix)}
    if len(proj) != 8:
        sys.exit("revision manifest must list exactly 8 source/aiken files")

    os.makedirs(run)
    proj_rows = copy_verified(os.path.join(revision, "source", "aiken"), run, proj)
    pkg = os.path.join(run, "build", "packages", "aiken-lang-stdlib")
    std_rows = copy_verified(os.path.join(pin, "source"), pkg, std)
    toml_path = os.path.join(run, "build", "packages", "packages.toml")
    with open(toml_path, "x") as f:
        f.write(PACKAGES_TOML)

    os.makedirs(os.path.dirname(os.path.abspath(receipt)), exist_ok=True)
    with open(receipt, "x") as f:
        json.dump({
            "schema": "moriarty-research/aiken-offline-placement/v0",
            "run": os.path.abspath(run),
            "stdlib": {"commit": STDLIB_COMMIT, "archiveSha256": STDLIB_ARCHIVE_SHA256,
                       "placedAt": "build/packages/aiken-lang-stdlib", "files": std_rows},
            "project": {"from": os.path.abspath(os.path.join(revision, "source", "aiken")), "files": proj_rows},
            "packagesToml": {"path": "build/packages/packages.toml", "sha256": sha(PACKAGES_TOML.encode())},
            "notPlaced": ["aiken.lock (written by the CLI in A6, from aiken.toml alone)",
                          "anything under the user cache (dirs::cache_dir()/aiken)"],
        }, f, indent=2)
        f.write("\n")
    print(json.dumps({"run": run, "projectFiles": len(proj_rows), "stdlibFiles": len(std_rows)}))


if __name__ == "__main__":
    main()
