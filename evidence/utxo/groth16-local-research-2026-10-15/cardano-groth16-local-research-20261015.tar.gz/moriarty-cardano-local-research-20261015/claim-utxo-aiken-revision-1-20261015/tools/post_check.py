#!/usr/bin/env python3
"""A7: after an offline `aiken check`/`build`, verify the placement was not
altered and no cache or download path was used. NOT RUN BY ITS AUTHOR.

Usage: python3 -I post_check.py PLACEMENT_RECEIPT_JSON EMPTY_HOME EMPTY_XDG_CACHE OUT_JSON
Exit 0 only if every observation in EXPECTED-OUTCOMES-R1.md §4 holds.
"""
import hashlib
import json
import os
import sys


def sha_file(p):
    with open(p, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def files_under(root):
    return sorted(os.path.relpath(os.path.join(dp, n), root) for dp, _, ns in os.walk(root) for n in ns)


def main():
    receipt_path, home, xdg, out = sys.argv[1:5]
    rc = json.load(open(receipt_path))
    run = rc["run"]
    pkg = os.path.join(run, rc["stdlib"]["placedAt"])
    want = {f["path"]: f["sha256"] for f in rc["stdlib"]["files"]}
    got_files = files_under(pkg)
    stdlib_ok = got_files == sorted(want) and all(sha_file(os.path.join(pkg, p)) == h for p, h in want.items())

    toml = os.path.join(run, "build", "packages", "packages.toml")
    toml_text = open(toml).read() if os.path.exists(toml) else None
    lock = os.path.join(run, "aiken.lock")
    lock_text = open(lock).read() if os.path.exists(lock) else None
    lock_ok = lock_text is not None and lock_text.count("[[packages]]") == 1 \
        and 'name = "aiken-lang/stdlib"' in lock_text and 'version = "v2.2.0"' in lock_text \
        and "aiken-lang/stdlib@" not in lock_text  # no etag entry was recorded

    obs = {
        "stdlibUnchanged": stdlib_ok,
        "stdlibFileCount": len(got_files),
        "packagesTomlSingleStdlibEntry": toml_text is not None and toml_text.count("[[packages]]") == 1
        and "aiken-lang/stdlib" in toml_text and "v2.2.0" in toml_text,
        "aikenLockSinglePackageNoEtag": lock_ok,
        "aikenLockSha256": sha_file(lock) if lock_text is not None else None,
        "homeEmpty": files_under(home) == [],
        "xdgCacheEmpty": files_under(xdg) == [],
    }
    obs["allHold"] = all(v for k, v in obs.items() if isinstance(v, bool))
    with open(out, "x") as f:
        json.dump(obs, f, indent=2)
        f.write("\n")
    print(json.dumps(obs))
    sys.exit(0 if obs["allHold"] else 1)


if __name__ == "__main__":
    main()
