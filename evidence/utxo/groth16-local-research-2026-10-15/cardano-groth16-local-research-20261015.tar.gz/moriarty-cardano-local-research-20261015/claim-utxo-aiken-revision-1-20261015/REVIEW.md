# Aiken revision 1: author review, second votes and findings

**Author:** Claude Opus 5.5, model ID `claude-opus-5-5`, as stated by my runtime. The requested effort was "high"; I cannot observe it.

**Role, precisely:**
- I am the **author** of this revision's Aiken source changes. I did not write attempt 2, VOTE.md or the X7 audit.
- My votes on D1–D12 and N1–N10 are independent judgments from my own reading of the source. They are **not** an independent review of my own revision-1 code. A fresh review of revision 1 is still required before its source is accepted.
- I consulted no other model, agent or reviewer. The prior authors and auditor are the same model family, so independence is at the level of context, not model.

**Status:** CANDIDATE. Nothing compiled, tested, built or run. No Aiken, Cargo, Rust, network, cache, key, wallet or ledger action was taken. The Python stdlib actions were limited to file copy, hashing, byte assembly and text checks; they are listed in `receipts/`.

**Labels:**

| Label | Meaning |
|---|---|
| **[SRC]** | Fact read from pinned source, cited as `file:line` |
| **[INF]** | Inference |
| **[PROP]** | Proposal |
| **[UNVERIFIED]** | Not established from source available here |

---

## 1. Sources read for this revision

| Source | Pin | Use |
|---|---|---|
| Attempt-2 Aiken subtree (8 files) | Byte-identical to the review's `SOURCE-FREEZE.json` digests (`receipts/copy-receipt.json`) | Base of this revision |
| Aiken stdlib | `aiken-lang/stdlib` v2.2.0, commit `779e9025356a85484475e06d5a14acb032bcdcc9`, archive sha256 `90c07de9…9b51`, 38 files (`SOURCE-MANIFEST.json`). Scrapling receipts in `RECEIPTS.json`. | API facts; offline closure |
| Aiken compiler | Public repository at `2a0475328be2fc361251be864b825c936fefb63b`, which is **v1.1.24 plus unreleased changes** (`Cargo.toml:8`, `CHANGELOG.md:3,20`). **Not** v1.1.21. | Package resolution, parser and typing behaviour. Every claim about the installed v1.1.21 is an inference, checked only by the A6 observations. |
| Upstream proof-zk-recovery | Frozen copies embedded with sha256 headers in `implementation-attempt-2/independent-opus-review/PROMPT.md` | §6 citation |
| VOTE.md | sha256 `0456825a…8498` | D1–D12 text |
| ABI-v0.md | sha256 `14952b13…3e92` | N1–N10 text |
| X7 audit | Supplied in this task's prompt | F-A … F-Q, first votes on N1–N10 |

---

## 2. F-B: premise refuted, fix applied as instructed

- **[SRC]** At the pinned stdlib, `Interval` is generic: `pub type Interval<a>` (`lib/aiken/interval.ak:42`), `IntervalBound<a>` (`:48`) and `IntervalBoundType<a>` (`:56`). `ValidityRange = Interval<Int>` (`lib/cardano/transaction.ak:81-82`).
- **Conclusion:** `fn after(t: Int) -> Interval<Int>` in attempt 2 was **well-typed**. The audit's [UNVERIFIED-LIB] recollection that stdlib v2 made `Interval` non-generic is false at this pin.
- **Action:** the exact audit edit was applied anyway: the return annotation was deleted (`context_test.ak`, `fn after(t: Int) {`). Under either definition this is a no-op, and the inferred type is `Interval<Int>`. It is recorded as **"no defect; robustness edit"**, not as a fixed compile error.

---

## 3. Compile-risk register re-checked against source (audit §8)

| Audit row | Finding from source | Disposition |
|---|---|---|
| F-B `Interval<Int>` | False alarm (§2) | Edit applied; harmless |
| Qualified constructor pattern `c0_logic.Issue { vk, proof }` | **[SRC]** `parser/pattern/var.rs:12-40` parses `name.UpName{…}` as `Constructor { module: Namespace::Module(name) }`. `pattern/constructor.rs:11-69` covers `module.Type.Ctor` and `Type.Ctor`. | Parses at the repo pin. `validators/c0.ak` left byte-identical. |
| `expect <Bool>` sugar | **[SRC]** `parser/expr/assignment.rs:118-120` (`expect_bool_sugar`). As a block's **last** expression it is accepted and the block becomes `Void` (`tipo/expr.rs:2404-2419`, `2926-2941`). Tests may return `Void` (`tipo/infer.rs:436-448`). Since #1000, `CHANGELOG.md:509-511`, before v1.1.21. | The `fail` tests that end in `expect` compile. A `Void`-returning `fail` test passes only if evaluation errors. Risk: low. |
| Record update over a call (`EnvV0 { ..f0_env(), … }`) | **[SRC]** `parser/expr/record_update.rs:17-19`: the spread takes any expression | Low |
| `assets.zero`, `list.count`, `placeholder` | **[SRC]** `assets.ak:174`, `list.ak:173`, `transaction.ak:207-225`. Also confirmed: `list.has` `:240`, `dict.to_pairs` `:1164`, `dict.size` `:460`, `assets.without_lovelace` `:771`. | Present |
| `and {}` laziness, which the revision-1 value tests rely on | **[SRC]** `gen_uplc.rs:4558-4559` (`delayed_if_then_else`) | Relied on for E-CTX-5′/6 value tests |

### 3.4 New compiler-pin item (my finding): v1.1.21 predates two code-generation fixes

- **[SRC]** v1.1.23 fixed #1325, a typed `expect` dropped by unused-binding cleanup (`CHANGELOG.md:62`). It also fixed #1331, collisions between cached `expect` decoder names "across modules and generic type shapes" (`CHANGELOG.md:64`). The current naming uses the full canonical type identity (`gen_uplc.rs:91-129`). Custom types otherwise collapse to `_data` in `get_generic_variant_name` (`gen_uplc/builder.rs:177-198`).
- **[INF]** `settle0` decodes `Option<ThreadDatum>` (its datum) and `Option<TransitionV0>` (inside EnvV0). `c0`'s spend decodes `Option<Data>` and `Option<TransitionV0>`. These are exactly "generic type shapes" over different custom types. **[UNVERIFIED]** I could not read v1.1.21's decoder naming, so I cannot say whether these collide there.
- **#1325 exposure:** none found. Every typed `expect` in validator code paths binds a name that is used (`c0.ak` issue/spend, `settle.ak` genesis/settle/`claim_envelopes`).
- **Action:** decoder probes added (`abi_test.ak` E-ABI-8). A probe that fails to raise an error is a **compiler-pin blocker**, not a source defect.
- **[PROP] Preprod blocker B-C (compiler pin):** before Preprod, either audit v1.1.21's decoder naming source, or move to ≥ v1.1.23 under a new pin and revision. No re-pin is made here.

---

## 4. F-A: second vote, and the implemented change

**Vote: AGREE.** The audit's proposal is the first vote, and this is the second. N1′ (below) therefore has two agreeing votes. That is the count for **this one item only**.

**Why I agree, from my own reading:**
- `settle.settle` has no authorization requirement.
- On attempt 2's settlement path, `c0.release` checked only that `settle_outref` was spent (`attempt-2 lib/pvc/c0.ak:86-92`), and placed no limit on where the claim UTxO's value goes.
- Issue never limits the claim output's non-C0 value (`c0.ak:36-45`).
- So anyone who builds the settlement transaction captures the whole claim UTxO value (min-ADA, and anything else sent with it), while delivering exactly the transition the claimant proved.

**Alternatives I rejected:**
- "Pay back ≥ lovelace to `refund_vkh`": one output can satisfy several claims (double satisfaction), unless outputs are tagged per claim, which is more ABI surface.
- Restricting the settler to the thread owner: S_settle0 has no owner key, and adding one is a larger design change.

**Implemented** (`lib/pvc/c0.ak`):
- `list.has(self.extra_signatories, env.refund_vkh)` is now an unconditional clause of `release`.
- The old `refund_ok` is replaced by `after_expiry`, which applies the same finite-lower-bound rule `t > expiry` without the signer clause.
- The `or { settle_outref spent, after_expiry }` gate is kept unchanged.

**Consequences I accept and record:**
1. **Liveness.** Each settlement needs every consumed claim's refund key to sign. A third party cannot use someone else's context-free P-L1 claim without them. For a context-bound claim this binding already existed in substance.
2. **F-H (expiry does not limit settlement use).** After F-A, the "race" between settlement and refund is between two transactions that both need the same claimant's signature. It is no longer an adversarial race. **I assess F-H as resolved by F-A**; no upper-bound check was added.
3. **The expiry gate.** With the signer on both paths, the `or` gate now only stops the claimant from burning their own claim early, outside a settlement. It protects no one else. I keep it, because removing it would be an unvoted change. Noted as observation O-1.
4. **`refund_vkh` becomes a usage-authorization key.** Its key management falls under the wallet rules in `B2-PROVING-KEY-LIFECYCLE.md` §6: a fresh research key only, never an existing wallet.
5. **Hash change.** The C0 script hash changes, so any attempt-2 C0 hash or policy id is void for revision 1.
6. **N9 is unaffected.**

**Tests:** E-CTX-4′, nine tests (EXPECTED-OUTCOMES-R1 §3.2). `release_token_kept_in_output_refused` now carries the signer so it still isolates its own clause.

**What F-A does not do:** it does not settle any value under Moriarty semantics. The thread's value is still carried unchanged. Effects remain bytes (D1). Physical asset integration is still open.

---

## 5. Votes on D1–D12 and N1–N10

**Voters:**
- **V1** = VOTE.md (predecessor author).
- **V2** = the X7 audit.
- **V3** = me.

A count means agreeing votes **on the exact text named in that row**. Agreement on an amended text is not counted for the original, and the reverse. **No row is blanket approval of ABI v0.** ABI v0 as a whole is still PROPOSED.

| Item | V1 | V2 | V3 (mine) | Exact result |
|---|---|---|---|---|
| D1 (transition in envelope and statement; settle checks pre/post/H(effects)) | AGREE | AGREE (effects are bytes only) | **AGREE**, with V2's qualifier | 3 agree. "Value unchanged" must be replaced before any physical effect. |
| D2 as written ("C0 rejects kind ≠ 0 at mint **and at release**") | AGREE | AGREE, deviation accepted (F-J) | **AGREE in substance; text amended** | Text **D2′**: "refused at mint; never counted in settlement; release needs no kind check because no kind ≠ 0 token can exist" has 2 (V2, V3). D2 literal has V1. Code unchanged. |
| D3 as written ("identity is `predicate_digest` alone") | AGREE | DISSENT; amended to the pair | **DISSENT on the literal; AGREE with V2's amendment** | **D3′** "identity is the consumer-pinned (`predicate_digest`, `vk_digest`) pair" has 2 (V2, V3). D3 literal has 1 agree and 2 dissent. Code already implements D3′ (`abi.ak:249-259`). |
| D4 | AGREE | AGREE | **AGREE** | 3 |
| D5 | AGREE | AGREE + normative "`statement` only after `well_formed`" | **AGREE** with the same rule | 3 on D5. The ordering rule has 2 (V2, V3). |
| D6 | AGREE | AGREE | **AGREE** | 3 (N4 strengthens it) |
| D7 | AGREE | AGREE, conditional (Class 0; no termination is a financial blocker; consumers check `c0_hash`) | **AGREE with V2's conditions** | 3 on the mechanism. The conditions have 2. |
| D8 | AGREE | AGREE | **AGREE** | 3 |
| D9 checks (one own-named token; finite lower bound `> expiry`) | AGREE | AGREE | **AGREE** | 3 |
| D9 release authorization (implicit: settlement path with no signer) | (implicit) | DISSENT (F-A) | **DISSENT** | Superseded by N1′ |
| D10 | AGREE | AGREE | **AGREE** | 3 |
| D11 | AGREE | AGREE | **AGREE** | 3 |
| D12 | AGREE | AGREE, limited (encoding only; F-L) | **AGREE, same limit** | 3 on the encoding. 2 on the limitation statement. |
| N1 refund branch (signer + `t > expiry`) | — | AGREE | **AGREE** | 2 |
| N1 "settlement release at any time, **no signer**" | — | DISSENT | **DISSENT** | 0 agree, 2 dissent: rejected |
| **N1′** "the `refund_vkh` signature is required on every release; release then needs `settle_outref` spent **or** `t > expiry`" | — | PROPOSED (F-A) | **AGREE** | **2. Implemented in revision 1** as an attributed normative candidate (`ABI-v0-R1-DELTA.md`). |
| N2 | — | AGREE | **AGREE** | 2 |
| N3 | — | AGREE (redundant with Issue, harmless) | **AGREE** | 2 |
| N4 | — | AGREE | **AGREE** | 2 |
| N5 | — | AGREE | **AGREE**. "Same full address" also pins the stake credential (new test `settle_continuation_stake_changed_refused`). | 2 |
| N6 | — | AGREE | **AGREE** | 2 |
| N7 (admission adds `r1csDigest`; in-circuit relation digest declined) | — | AGREE with §11 amendments | **AGREE**, including V2's reasons | 2 on N7. The §11 admission-record field list also has 2 (V2 proposal, V3), but it is a **Rust/x7** change and is **not** made here. |
| N8 | — | AGREE (weak) | **AGREE (weak)** | 2 |
| N9 | — | AGREE | **AGREE**. Consequence recorded: no issue in the same transaction as any C0 release. | 2 |
| N10 | — | AGREE | **AGREE** | 2 |

### 5.1 Other audit proposals: my vote and disposition

| Proposal | V2 | V3 | Disposition |
|---|---|---|---|
| F-I: reject the identity point for VK γ, δ, ic1, ic2 | PROP | **AGREE** for the VK points. With δ = O, `e(A,B) = e(α,β)` is satisfiable by anyone. With γ = O the public inputs drop out. Proof points: no need. | 2 votes, but **not implemented**. It changes the verifier, and the task scope allows only F-B, F-A and F-N. Candidate for a later revision. |
| F-E: alternative context (thread policy, thread_id, seq) | PROP, "needs a vote" | **DISSENT for v0** | Not adopted (1 for, 1 against). Reason: it would not remove B2 (§7), because every later step still needs the PK at a later time. It also changes the statement layout. Reconsider in v1. |
| F-H: finite upper bound in settle | "record or add" | Resolved by F-A (§4.2) | No code |
| F-J | record | record | Recorded under D2′ |
| F-Q: hash-chained `last_effects` | PROP v1 | **AGREE for v1** | Not now |
| §3.4 rule: no gnark-commitment VK under FAM0; records say "vanilla Groth16; no commitment extensions" | PROP (documentation) | **AGREE** | 2. Documentation rule in the R1 delta |
| §13 execution amendments | PROP | **AGREE**, and made concrete for the Aiken steps in `EXECUTION-REQUEST-R1.json` | — |

**Observation O-1 (mine, no vote requested):** after N1′ the expiry gate protects only the claimant against themselves. Removing it would be a separate N-item.

---

## 6. The original report's upstream identity-point claim

**The claim.** `implementation-attempt-2/REPORT.md:137`: *"The upstream code rejects identity points explicitly."*

**What the frozen upstream sources show.** Line numbers are within each file. File line = PROMPT.md line − header line.

1. **`proto/onchain/redemption/src/Recovery/Verify.hs`**, sha256 `abecd9e0dca78ae96d2371f703af02dd1c2d4a43cc2cfb68cd9da024a073f1bd` (PROMPT.md header line 11576).
   - The builtin import list (`Verify.hs:36-55`) contains `bls12_381_G1_uncompress`, `G2_uncompress`, `G1_add`, `G1_neg`, `G1_scalarMul`, `millerLoop`, `mulMlResult`, `finalVerify` and bytestring/integer helpers.
   - It contains **no** `bls12_381_G1_equals`, `G2_equals`, `compress` or compressed-zero constant, so this module cannot compare a point with the identity.
   - `groth16Verify` (`Verify.hs:76-98`) and `groth16VerifyCommitted` (`Verify.hs:164-217`) uncompress and pair, nothing else.
2. **`proto/onchain/commitment-verifier/src/CommitmentVerifier.hs`**, sha256 `bcce3615…0beb` (header line 12313).
   - It imports `G1_equals`/`G2_equals` (`:51-71`), but uses them only as cost-measurement sinks (`equals d d`, `:86`, `:97`, `:111`, `:119`).
   - Its `mkValidator` runs on the canonical generators (`:176-192`).
   - Its REQ-B-02 reference (`:22`) refers to subgroup-checking uncompress.
3. **`docs/commitment-groth16-protocol.md`**, sha256 `96d2259d…9f9f` (header line 12510).
   - §6 "Rejection cases" (`:336`), **rule 4** (`:362-364`): *"Reject if the reconstructed `D` or `π` (or any consumed VK/proof point) is the identity/infinity point (REQ-B-02: 'reject identity and small-order')."*
   - REQ-B-02 itself lives in `docs/07-batch-ears.md`, which is **not** in the selection and was not read.

**Corrected statement.**
- The upstream **protocol document** requires identity rejection (§6 rule 4, citing REQ-B-02).
- The upstream **on-chain verifier `Verify.hs` does not implement it**, and no other selected upstream Haskell source does.
- MRG16 v0 / revision 1 matches upstream code in this respect: it relies on CIP-0381 uncompress only.
- Rejecting identity points is the separate F-I proposal (§5.1). It is not implemented, and this correction makes no cryptographic change.

---

## 7. Offline Aiken dependency closure (summary)

The full plan is in `OFFLINE-AIKEN-PLAN.md`.

- **Closure:** exactly the 38-file stdlib v2.2.0 tree.
  - The stdlib's own `aiken-lang/fuzz v2` requirement (`aiken.toml:12-15`) is **not** fetched for a consumer. Versions are resolved from the root `aiken.toml` only (`deps/manifest.rs:127-149`).
  - The two stdlib modules that import `aiken/fuzz` (`lib/aiken/cbor.test.ak:2`, `lib/aiken/math/rational.tests.ak:1`) are parsed, then pruned from the type-check graph, because no module of ours reaches them (`module.rs:289-314`). Dependency tests are stripped (`lib.rs:733-741`).
- **Placement:** project-local, in a single-use run copy:
  - `build/packages/aiken-lang-stdlib/` (`paths.rs:31-33`);
  - `build/packages/packages.toml` listing `aiken-lang/stdlib v2.2.0 github`.

  With that, `missing_local_packages` is empty (`deps.rs:105-120`), the Downloader is never built (`deps.rs:210-221`), and neither the network nor the user cache (`paths.rs:39-47`) is touched.
- **Repo pin versus installed CLI:** this is v1.1.24 source. The installed v1.1.21 is confirmed only by the A6 observations; any fetch attempt there is **BLOCKED**, not failed.

---

## 8. Findings of this revision (mine)

| ID | Severity | Finding | Disposition |
|---|---|---|---|
| R-1 | Info | F-B premise false at the stdlib pin | §2 |
| R-2 | Info | The stdlib has a transitive `fuzz` requirement. It is harmless for consumers by source. | §7 |
| R-3 | Medium (toolchain; Preprod blocker B-C) | v1.1.21 predates #1325/#1331 | Probes; re-pin decision before Preprod |
| R-4 | Info | Attempt 2's issue refusal tests were non-discriminating (audit §7). Three are now value tests behind a positive control. | E-CTX-5′ |
| R-5 | Low | `x7 prove` does not check the loaded PK's VK digest against an operator-supplied pin (`main.rs:634-650`). `x7 setup` writes the PK uncompressed to any `--pk-out` path (`:615-632`). | B2 condition L3 (Rust change, not made here) |
| R-6 | Info | Setup randomness is a 32-byte ChaCha20 seed from `/dev/urandom` (`main.rs:43-48`). That seed is trapdoor-equivalent. | B2 §1 |
| R-7 | Info | F-A makes `refund_vkh` a settlement co-signer | §4.4; B2 §6 |

---

## 9. What this document does not mean

It records author votes and source-cited findings. It does **not** mean any of the following:
- adoption of ABI v0, or of the R1 delta beyond the per-row counts in §5;
- compiled or tested status;
- correctness of the compiler;
- Preprod, ledger or financial-settlement acceptance;
- ceremony security;
- closure of the 20 retained patterns or the general obligations, or of private PCD, recursion or private handoff;
- physical asset integration (the unit data transition carries the ledger value unchanged; that track stays open);
- any public permission requirement.

The Rust x7 subtree is unchanged and is governed by its separately authorized run.
