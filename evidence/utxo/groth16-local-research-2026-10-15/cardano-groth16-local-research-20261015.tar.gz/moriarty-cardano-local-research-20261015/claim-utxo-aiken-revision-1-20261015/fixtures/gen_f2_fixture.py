#!/usr/bin/env python3
"""Freeze fixture F2 (audit F-N): an EnvV0 whose byte strings straddle the
Plutus 64-byte chunking boundary. Literal byte assembly only; no CBOR library,
no project code. The non-author oracle is Aiken builtin.serialise_data at S8.

Usage: python3 -I gen_f2_fixture.py OUT_JSON   (refuses to overwrite)

Rule under test (ABI-v0 §2, Plutus serialiseData): a byte string of length
<= 64 is one definite string; a longer one is 5f, then definite 64-byte
chunks (the last chunk holds the remainder, never empty), then ff.
"""
import hashlib
import json
import sys

TAG = b"MRG16-PVC-STMT-0"
FAMILY = b"MRG16-PVC-FAM0-G16-BLS-ARK04-HL2"

PRE = b"\xa1" * 64      # exactly 64: definite 5840
POST = b"\xb2" * 65     # 65: 5f 5840 <64> 41 <1> ff
EFFECTS = b"\xc3" * 128  # 128: 5f 5840 <64> 5840 <64> ff (no empty chunk)
PAYLOAD = b"\xd4" * 129  # 129: 5f 5840 <64> 5840 <64> 41 <1> ff


def u16(n):
    return n.to_bytes(2, "big")


def statement():
    return b"".join([
        TAG, FAMILY, b"\x22" * 32, b"\x33" * 32,
        b"\x00",                    # claim_kind
        b"\x00",                    # setup_class
        b"\x01", b"\x44" * 32, u16(1),  # context tag, settle txid, index
        b"\x01",                    # transition tag
        u16(64), PRE, u16(65), POST, u16(128), EFFECTS,
        u16(129), PAYLOAD,
    ])


def cbor():
    return b"".join([
        bytes.fromhex("d8799f"),                      # Constr 0 [ (indefinite)
        b"\x00", b"\x00",                             # version 0, claim_kind 0
        bytes.fromhex("5820"), FAMILY,
        bytes.fromhex("5820"), b"\x22" * 32,
        bytes.fromhex("5820"), b"\x33" * 32,
        b"\x00",                                      # setup_class 0
        bytes.fromhex("d87a80"),                      # context_bound True
        bytes.fromhex("d8799f5820"), b"\x44" * 32, bytes.fromhex("01ff"),
        bytes.fromhex("d8799f"),                      # Some(
        bytes.fromhex("d8799f"),                      #   TransitionV0 [
        bytes.fromhex("5840"), PRE,
        bytes.fromhex("5f5840"), POST[:64], bytes.fromhex("41"), POST[64:], b"\xff",
        bytes.fromhex("5f5840"), EFFECTS[:64], bytes.fromhex("5840"), EFFECTS[64:], b"\xff",
        bytes.fromhex("ffff"),                        #   ] )
        bytes.fromhex("5f5840"), PAYLOAD[:64], bytes.fromhex("5840"), PAYLOAD[64:128],
        bytes.fromhex("41"), PAYLOAD[128:], b"\xff",
        bytes.fromhex("1903e8"),                      # expiry 1000
        bytes.fromhex("581c"), b"\x55" * 28,          # refund_vkh
        b"\xff",
    ])


def main():
    out = sys.argv[1]
    s, c = statement(), cbor()
    d = hashlib.blake2b(s, digest_size=32).digest()
    doc = {
        "schema": "moriarty-research-pvc/fixture/v0",
        "fixture": "F2",
        "purpose": "audit F-N: byte strings of 64, 65, 128 and 129 bytes in EnvV0 Plutus Data CBOR",
        "derivation": "literal byte assembly from the Plutus serialiseData rule; same-author expectation, "
                      "checked by the non-author oracle Aiken builtin.serialise_data only when S8 runs",
        "fields": {"base": "F1", "pre": "a1 x 64", "post": "b2 x 65", "effects": "c3 x 128",
                   "payload": "d4 x 129"},
        "statementLen": len(s),
        "statementHex": s.hex(),
        "statementBlake2b256": d.hex(),
        "scalarsDecimal": [str(int.from_bytes(d[:16], "big")), str(int.from_bytes(d[16:], "big"))],
        "envelopeCborLen": len(c),
        "envelopeCborHex": c.hex(),
        "assetNameHex": hashlib.blake2b(c, digest_size=32).hexdigest(),
    }
    with open(out, "x") as f:
        json.dump(doc, f, indent=2)
        f.write("\n")
    print(json.dumps({k: doc[k] for k in ("statementLen", "envelopeCborLen", "assetNameHex", "scalarsDecimal")}))


if __name__ == "__main__":
    main()
