# Preprod blocker B2: proposed lifecycle for a fresh, scoped Groth16 proving key

**Status: DESIGN PROPOSAL, first vote (claude-opus-5-5, revision-1 author). It needs a second agreeing vote. It authorizes nothing.** No key was generated, used, loaded or persisted for this document. No existing wallet, key, SRS, PK or ceremony output is referenced as an input.

**Code facts used** (attempt-2 x7, unchanged):
- `rng()` seeds ChaCha20 from 32 bytes of `/dev/urandom` (`main.rs:43-48`).
- `setup()` calls `circuit_specific_setup` (`main.rs:465-470`).
- `cmd_run` sets up and proves in one process, and persists no PK (`main.rs:542-613`).
- `cmd_setup` writes the PK **uncompressed** to `--pk-out` (`main.rs:615-632`).
- `cmd_prove` loads it and derives `vk_digest` from the loaded PK itself (`main.rs:634-650`).

---

## 0. Why B2 exists (stated without pretending)

- A context-bound claim binds `settle_outref`, the thread UTxO it settles.
  - For step 0 that outref is the genesis output. Its txid is determined only when the genesis transaction body is final, and the UTxO exists only after genesis is confirmed.
  - For step k > 0 it is the continuation output of step k−1.
- The VK is fixed **before** genesis, because `vk_digest` sits in the immutable genesis slot.
- So every step's proof is produced **after** setup, and after an on-chain event:

  ```
  setup → genesis → prove(0) → issue → settle(0) → prove(1) → …
  ```

- The PK must therefore outlive the setup process for the lifetime of the thread. Running a fresh setup per step would change `vk_digest` and break the slot pin.
- This is why `x7 run`'s in-process discard is not usable for Preprod. F-E's alternative context would only shorten step 0; it does not remove the need for the PK across steps (REVIEW §5.1).
- **No outref is treated as known before genesis.** The `x7 run` outrefs (`44³²#1`) are DECLARED placeholders.

## 1. Material classes (the core distinction)

| Class | Contents | Soundness / ZK role | Rule |
|---|---|---|---|
| **T: toxic waste / setup secret** | The trapdoor scalars τ, α, β, γ, δ inside `circuit_specific_setup`, **and the 32-byte ChaCha20 seed** that deterministically regenerates them (`main.rs:45-47`) | Anyone holding T can forge proofs of false statements for that VK | **Never serialized, logged or persisted.** It exists only in the setup process's memory, and that process exits immediately after writing the outputs. The whole setup process memory is T-bearing (arkworks does not zeroize), so: no core dump, no debugger, no ptrace. Swap state is recorded. Any abnormal exit, or any crash artefact, means **the VK is compromised: never pin it**. |
| **PK: proving key** | `ProvingKey<Bls12_381>`: the VK plus the α/β/δ G1/G2 encodings and the a/b/h/l query vectors (`pk.bin`) | **Not** soundness-critical: it contains only group encodings, from which T is not recoverable under standard assumptions. Not ZK-critical. Holding it lets one prove **true** statements. | Persisted **only** under custody (§3). Kept private by policy, not because soundness requires it: it is large, operator-specific, and written by a T-bearing process. Retiring it is hygiene, not a soundness event. |
| **R: prover randomness** | The per-proof ChaCha20 seed (r, s) | ZK-critical: together with a proof it leaks the witness commitment | Never persisted. Fresh for each proof. |
| **W: witness** | P-M1: pre-state u128s, amount, accepted. P-L1: the Preprod tx body. | In these rows all of it is public (statement/payload, or on-chain). In future rows it may be private. | No witness files. Inputs come from public data only. |
| **Public** | `vk.bin`, `vk_digest`, `proof.bin`, `statement.bin`, `claim.json`, admission record, `pkSha256`, binary and source digests | — | May be published |
| **K: wallet keys** (outside B2, adjacent) | Fee payer; `refund_vkh` signer, which F-A/N1′ makes a settlement co-signer | Authority over ledger actions | §6 |

**Correction of current wording.** "No proving key or trapdoor is persisted" (`EXPECTED-OUTCOMES.md` §6; `main.rs:611`) conflates T and PK. The proposed rule is:
- **T: never persisted**;
- **PK: persisted only under §3 custody, after explicit root authorization**.

## 2. Key source

1. **Fresh only.** One new `circuit_specific_setup` per (row, campaign). No import or reuse of any existing PK, VK, SRS, powers-of-tau, ceremony output, Midnight or old-campaign key, or proof-zk-recovery artefact.
2. **Entropy:** OS CSPRNG (`/dev/urandom`, as now). No seed argument, environment-supplied seed or deterministic RNG for any Preprod-bound setup. The binary digest proves which code ran, so a later x7 revision must keep that property.
3. **Single operator, Class 0.** Nothing proves T was destroyed. Every consumer of the VK trusts the setup operator not to forge. Labels remain `setup_class = 0` and `setupTranscript: none`. Only a verifiable phase-2 transcript would change this, and that is a separate track.

## 3. Lifecycle (each stage requires its own root authorization record)

| Stage | Action | Conditions |
|---|---|---|
| **L0 Authorize** | Root record: campaign id, row, x7 binary sha256, source-manifest digest, `Cargo.lock` digest, private PK path, retention end, destruction method | The PK path is outside every task tree, repository, worktree, sync or backup folder. Directory mode 0700, owned by the operator. |
| **L1 Setup** | `x7 setup --row R --pk-out <private path>` | No-network namespace; `prlimit --core=0`; `core_pattern` and swap recorded (audit §13.5/7); RLIMIT caps. A signal exit, any core file, or any pipe-handler crash event means the VK is compromised: record, never pin, delete the partial PK. Outputs: `vk.bin` and `admission.json` (public), `pk.bin` (private, mode 0600), and `pkSha256` recorded publicly. |
| **L2 Custody** | PK at rest | Exactly one copy. Not copied to other hosts unless separately authorized. Digest checked before every use. No backups. |
| **L3 Prove** | `x7 prove --pk <path> …` | **Required Rust change (not made here; R-5):** an `--expect-vk-digest` argument, refusing if `H(pk.vk)` differs. A PK-digest check before deserialization. One context per invocation, with the outref taken from a **confirmed** UTxO (§0). Outputs are public only. A log line records (`pkSha256`, `vkDigest`, `statementDigest`). |
| **L4 Retire** | When the campaign ends, or on any compromise indicator: delete `pk.bin` and record a destruction receipt | On WSL ext4 or VHDX and SSD, deletion is **best effort** (no guaranteed overwrite). That is acceptable because the PK is not soundness-critical, and it is recorded as a residual. The VK and existing claims remain valid. Threads pinned to the VK cannot advance after retirement, which is a liveness consequence the root must accept at L0. |

## 4. Publication rules

| Material | Rule |
|---|---|
| Public | `vk.bin`, `vkDigest`, `pkSha256`, `admission.json` (with the §11 audit fields once implemented), proofs, statements, envelopes, claim and redeemer CBOR, binary and source digests, logs |
| Private | `pk.bin`, plus any future private witness. They never appear in a task tree, prompt, report, model input, provider result or public repository. Reviews see the digest only. |
| Never on disk | T (the setup trapdoor and its ChaCha20 seed) and R |
| Crash artefacts | Must not exist. If one appears: VK compromised; delete the artefact and the PK; record it. |

## 5. Interaction with the outref and genesis order (Preprod sequence; for design only)

1. L1 setup produces the VK. Its digest goes into the slot.
2. The genesis body is built with the slot (`c0_hash` and the audited C0 hash checked off-chain).
3. Genesis is submitted and confirmed. Only now does the thread UTxO `txid#ix` exist.
4. L3 prove for step 0 with that outref.
5. Issue, then settle (claimant signature required by N1′).
6. For every later step, prove after the previous settlement is confirmed.

A claim proved against an unconfirmed outref may be orphaned by a rollback. That is a liveness risk, not a soundness one; the issued claim can be refunded after expiry. The confirmation depth is the root's choice.

## 6. Wallet keys adjacent to B2 (K)

- Fresh, research-only keys for the fee payer and `refund_vkh`. Never an existing wallet, faucet key or old-campaign key.
- Generated and held outside task trees, under the same publication rules as the PK.
- N1′ requires the `refund_vkh` key at **settlement**, not only at refund, so its custody window equals the claim's life.

## 7. Open items this proposal does not close

- A verifiable setup (phase-2 MPC transcript) remains a future track.
- The Rust changes for L3 (`--expect-vk-digest`, PK digest check) and for the §11 admission fields.
- Compiler pin B-C (REVIEW §3.4) and physical asset integration (B3).
- Any Preprod action, which needs separate authorization after the second vote.
