# Offline Aiken dependency plan (audit S8a–S8d), source-derived

**Status: PLAN.** Nothing was installed, placed, cached, compiled or fetched. The tools it names (`tools/place_stdlib.py`, `tools/post_check.py`) were written and **not run**.

**Two sources, kept apart:**
- **Compiler behaviour** comes from the public aiken repository at `2a0475328be2fc361251be864b825c936fefb63b`. That is **v1.1.24 plus unreleased changes** (`Cargo.toml:8`; `CHANGELOG.md:3,20`), not the installed v1.1.21.
  - The v1.1.22–v1.1.24 changelog entries (`CHANGELOG.md:20-91`) mention no change to package resolution, caching or download. That is evidence, not proof.
  - v1.1.21's behaviour is therefore established **only** by the A6/A7 observations.
- **Paths below** are relative to `crates/aiken-project/src/` unless prefixed.

---

## S8a: acquisition (already done; nothing to fetch)

| Item | Value |
|---|---|
| Directory | `/home/charl/moriarty-eutxo-validation-2026-10-12/aiken-stdlib-v220-source-20261015` |
| Tag → commit | `v2.2.0` → tag object `154e650d…` → commit `779e9025356a85484475e06d5a14acb032bcdcc9` (`tag-ref.json`, `tag-object.json`) |
| Archive | `codeload.github.com/aiken-lang/stdlib/tar.gz/779e9025…`, 69,994 bytes, sha256 `90c07de94ebf858f0d78292a9482cfa3b2b45767ed85fd381e74c0463cdf9b51` |
| Method | Scrapling 0.4.15 Fetcher, HTTP 200 for all three requests (`RECEIPTS.json`) |

**Gap to note.** `RECEIPTS.json` records no ETag. Integrity rests on the sha256 and the commit-addressed URL. A robots-file observation is not recorded there either. If the root's acquisition rule requires both, the root should add them to the acquisition record. This plan does not re-fetch.

## S8b: extraction and closure audit

- **Extracted tree:** `…/source/`, exactly 38 files, each digest in `SOURCE-MANIFEST.json`. The contents are `.ak`, `.toml`, `.md`, `.lock`, `LICENSE`, dotfiles and one CI workflow YAML. Nothing is executed by the compiler: it only **reads** `.ak` files under `lib/` (below).

**Compiler-relevant closure, by source:**

| Fact | Source |
|---|---|
| Only `build/packages/<owner>-<repo>/lib` is read for a dependency | `lib.rs:715-724`; `read_package_source_files` → `aiken_files(lib, ModuleKind::Lib)` at `lib.rs:777-781` |
| Every `*.ak` file under it whose relative path matches `^([a-z][-_a-z0-9]*/)*[a-z][-_a-z0-9]*(\.[-_a-z0-9]*)*\.ak$` is a module. This includes `aiken/cbor.test.ak` and `aiken/math/rational.tests.ak`. | `lib.rs:1199-1229`, `1290-1306` |
| Tests, benchmarks and validators of dependencies are dropped after parsing | `lib.rs:730-741` |
| Modules of a dependency that none of our modules reaches are pruned before type checking | `module.rs:289-314` |
| The 27 non-test `lib/` modules do not import `aiken/fuzz` | Grep over `source/lib`: only `cbor.test.ak:2` and `rational.tests.ak:1` mention `fuzz` |
| Versions are resolved from the root `aiken.toml` only, with no transitive requirements (`requirements: vec![]`). The stdlib's `aiken-lang/fuzz v2` (stdlib `aiken.toml:12-15`) is therefore never resolved. | `deps/manifest.rs:127-149` |

**Conclusion.** The compile closure is the 38-file stdlib tree, and only its `lib/**` is read. The two fuzz-importing files must **parse** under v1.1.21. They are expected to, since the stdlib targets compiler v1.1.9 (stdlib `aiken.toml:3`). They are never type-checked, so the absent `aiken/fuzz` is not an error.

**Residual [UNVERIFIED for v1.1.21].** The pruning (`module.rs:289-314`) is v1.1.24-era source. If v1.1.21 type-checks unreachable dependency modules, A6 fails with an unknown-module error for `aiken/fuzz`. That is recorded as a **failure of the plan**, not of the revision. The remedy is a vendoring revision that excludes the two test files, with its own closure manifest and audit. It is not taken automatically.

## S8c: placement (project-local; no user cache)

**Mechanism, by source:**

1. `deps::download` (`deps.rs:140-191`):
   - takes a build lock in `build/aiken-compile.lock`;
   - loads or creates `aiken.lock` from `aiken.toml` (`deps/manifest.rs:29-71`, no network);
   - loads `build/packages/packages.toml` (`deps.rs:36-61`);
   - removes package directories that it lists but the manifest does not (`deps.rs:80-90`).
2. `missing_local_packages` (`deps.rs:105-120`) treats a package as **present** when `packages.toml` lists the same name with a version that `is_git_sha_or_tag` (`paths.rs:175-179`; `v2.2.0` matches `^v?[0-9]+\.[0-9]+(\.[0-9]+)?([-+].+)?$`) and that is equal to the manifest version.
3. With nothing missing, `fetch_missing_packages` skips the `Downloader` entirely (`deps.rs:210-221`). So:
   - `CacheKey::new` is never called, and its network ETag lookup with it (`paths.rs:55-122`);
   - `ensure_package_downloaded` is never called, and its GET and user-cache writes with it (`deps/downloader.rs:70-110`);
   - `paths::packages_cache()` = `dirs::cache_dir()/aiken/packages` (`paths.rs:39-47`) is never touched.
4. It then rewrites `aiken.lock` (`deps.rs:248`) and `packages.toml` (`deps.rs:188`). Both are task-local.
5. Other network code in the CLI:
   - `github/repo.rs` (latest-release lookup) is reached only from `ProjectConfig::default` (`config.rs:385-393`), which `aiken new` uses and `aiken check`/`build` do not;
   - `deps/downloader.rs` and `paths.rs` are covered above.

**Placement layout** (`tools/place_stdlib.py`; `RUN` must not exist beforehand):

```
RUN/                                   copy of revision-1 source/aiken (8 files, verified against SOURCE-MANIFEST-R1.json)
RUN/build/packages/packages.toml       [[packages]] name="aiken-lang/stdlib" version="v2.2.0" source="github"
RUN/build/packages/aiken-lang-stdlib/  the 38 pinned files, byte-identical (paths.rs:31-33 gives "<owner>-<repo>")
```

- The script also checks `SOURCE-PIN.json` (commit, archive digest) and re-hashes the archive.
- It refuses any extra or missing file, and it never overwrites.
- `aiken.lock` is **not** pre-placed: the CLI derives it from `aiken.toml` without network (`deps/manifest.rs:43-46`, `127-149`), and A7 checks it.
- **Serde shapes:**
  - `packages.toml` is `LocalPackages { packages: Vec<Dependency> }` (`deps.rs:29-32`);
  - `Dependency { name, version, source }` (`config.rs:354-359`);
  - `Platform` is lowercase (`config.rs:347-352`);
  - `PackageName` deserializes from `"owner/repo"` (`package_name.rs:79-…`).

**Why a run copy.** The CLI writes `build/` and `aiken.lock` inside the project root (`paths.rs:15-29`), so the revision's `source/aiken` is never used as the working directory. That keeps the source manifest valid.

**Defence in depth.**
- `HOME` and `XDG_CACHE_HOME` point to new, empty, task-local directories. The `dirs` crate's honouring of `XDG_CACHE_HOME` is **[UNVERIFIED-LIB]**: its source is not in this repository.
- Every Aiken step runs in a network-less namespace. A7 checks that both directories are still empty.

## S8d: check and build

Exact commands are in `EXECUTION-REQUEST-R1.json` (A6, A8). Expected results are in `EXPECTED-OUTCOMES-R1.md` §1 and §4.

**Outcome rules:**

| Observation | Recorded as |
|---|---|
| Exit 0, and A7 `allHold: true` | Offline route confirmed for v1.1.21 |
| Any download, cache or ETag attempt (A7 false, or a network error in the log) | **BLOCKED** |
| A type, parse or test failure | **FAILED**, with the log preserved; a fix needs a new revision |

## Vendoring fallback (not proposed for use now)

If A6 is BLOCKED, the fallback is to copy `lib/**` of the stdlib into the project as a new revision (for example `lib/aiken/**`, `lib/cardano/**`) and remove the `[[dependencies]]` entry. It needs:

1. a full closure manifest: all 29 `lib/**` files plus `LICENSE` (Apache-2.0, sha256 `59416b18…ad0d`), with a statement on whether the two fuzz-importing test files are excluded;
2. an independent audit that the copied modules are byte-identical to the pin, and of every exclusion;
3. a check that module paths do not collide with `pvc/*`.

No auto-accepted fetch: the archive is already pinned, and nothing is re-downloaded.
