# ABI v0, revision-1 delta: attributed normative candidate text

**Status: CANDIDATE.** Each clause below carries its own vote count from `REVIEW.md` §5. A count applies to that clause only. ABI v0 as a whole remains **PROPOSED**. Nothing here authorizes compiling, proving, deploying, Preprod or any wallet use.

The base text is `implementation-attempt-2/ABI-v0.md` (sha256 `14952b13705ee8c0ec89bde4d5c0a41783653697cd39f84d178851ee27943e92`). Clauses not listed are unchanged.

---

## Δ1. Release authorization: replaces ABI-v0 §4 "Spend (release)" item 3 and §9 N1

> **N1′ (normative candidate).** Proposed by the X7 audit (F-A); agreed by claude-opus-5-5 as revision-1 author. **2 agreeing votes.**
>
> A C0 claim UTxO is released only if all of the following hold:
> 1. The spent input holds exactly one token of the C0 policy, named `H(datum)`, and no other token of that policy (D9, unchanged).
> 2. No output carries any token of the C0 policy (N9, unchanged).
> 3. `refund_vkh` is among `extra_signatories`.
> 4. Either `settle_outref` is spent in the same transaction, or the validity lower bound is `Finite(t)` with `t > expiry`.

**Implementation:** `source/aiken/lib/pvc/c0.ak`, functions `release` and `after_expiry`.

**Rejected text:** "Settlement release is allowed at any time" without a signer (ABI-v0 §9 N1, second sentence) has 0 agreeing and 2 dissenting votes (V2, V3).

**Non-claims:**
- N1′ protects the claim UTxO's value from capture by a third-party settler. It does not move or settle any value under Moriarty semantics.
- The thread value is still carried unchanged (D1, N5). Physical asset integration remains an open required track.

## Δ2. Identity wording: replaces VOTE.md D3's "identity is `predicate_digest` alone"

> **D3′.** The relation identity a consumer admits is the pair (`predicate_digest`, `vk_digest`) pinned in its slot. `predicate_digest` is domain separation plus a pointer into the catalogue. `vk_digest` is the only binding of proofs to a relation. **2 votes** (V2 amendment, V3). Code unchanged (`abi.ak` `slot_accepts`).

## Δ3. Statement ordering rule: added to ABI-v0 §3

> Any on-chain caller of `abi.statement` must evaluate `abi.well_formed` on the same envelope first. `statement` assumes fixed-width fields. **2 votes** (V2, V3). C0 Issue already does this through its lazy `and` chain (`c0.ak` issue).

## Δ4. Kind refusal wording: replaces VOTE.md D2's "at mint and at release"

> **D2′.** `claim_kind ≠ 0` is refused at mint (`well_formed`) and is never counted in settlement (`claim_envelopes` fails closed). Release performs no kind check, because no token with kind ≠ 0 can exist. **2 votes** (V2, V3). Code unchanged.

## Δ5. Admission and VK documentation rule: added to ABI-v0 §1 and §8

> No consumer may pin, under `MRG16-PVC-FAM0-G16-BLS-ARK04-HL2`, a VK derived from a gnark commitment (BSB22) circuit. Admission records state "vanilla Groth16; no commitment extensions". **2 votes** (V2, V3). Documentation only. The bytes cannot tell such a VK apart.

---

## Not adopted by this delta (recorded so that nobody infers it)

| Item | Status |
|---|---|
| F-I identity-point rejection for VK γ, δ, ic1, ic2 | 2 votes. **Not implemented**, because it is out of revision-1 scope. It needs its own source revision and review. |
| §11 admission-record field additions (source manifest digest, binary digest, `setupTranscript: none`, …) | 2 votes. A Rust/x7 change, **not made**. |
| F-E alternative context (thread policy, thread_id, seq) | 1 for, 1 against. Not adopted. |
| F-Q hash-chained `last_effects` | v1 candidate |
| Thread termination; value-changing settlement; universal certificates; OR/k-of-n/DAG; recursion; private PCD; private handoff | Unchanged: required future tracks, not waivers |
