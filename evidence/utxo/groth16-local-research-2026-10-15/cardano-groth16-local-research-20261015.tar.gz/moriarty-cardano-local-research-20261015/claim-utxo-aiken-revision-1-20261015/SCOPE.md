# Aiken revision 1: scope and what was done

**Author:** claude-opus-5-5 (requested effort high; not observable). The source and tests in this directory are security-owned by this author. No root-substitute policy was applied.

## Writes
All writes are confined to this directory. Nothing was written to:
- the old candidate (attempt 2);
- the keys, ABI files, circuit, fixtures or results of earlier attempts;
- the running Rust job;
- the stdlib pin directory or the aiken repository.

## Executed
Only `python3 -I` running stdlib-only scripts that I wrote in `tools/` and `fixtures/`:

| Script | Action |
|---|---|
| `copy_aiken.py` | Verified copy of the 8-file Aiken subtree. The first invocation copied the files, then failed to write its receipt (missing `receipts/`). The second re-verified them byte for byte and wrote `receipts/copy-receipt.json`. |
| `gen_f2_fixture.py` | Byte assembly and hashing of fixture F2 |
| `freeze.py` | Freeze receipt `receipts/FREEZE-1.json` before any assertion was written |
| `check_names.py` | Text-only check of test names and counts |
| `diff_tree.py` | `receipts/aiken-r1.diff` |
| `manifest.py` | Final manifest and REVIEW input |

## Not executed
- `tools/place_stdlib.py` and `tools/post_check.py`. They are for EXECUTION-REQUEST-R1 A4/A7.
- Aiken, Cargo, Rust, any compiler, test, model, proof, key, wallet, ledger, network or subprocess.
- No project code was imported or evaluated.

## Read
- Attempt-2 sources and documents, VOTE.md, and the X7 audit (in the prompt).
- The pinned stdlib v2.2.0 source (read only).
- The public aiken repository at `2a0475328be2` (v1.1.24-era; not the installed v1.1.21).
- Frozen upstream proof-zk-recovery copies, embedded with sha256 headers in the attempt-2 review PROMPT.md.
- No private provider results, caches or SRS were read.

## Deliverables

| File | Content |
|---|---|
| `source/aiken/**` | Revision source (F-B, F-A, F-N, F-M, decoder probes) |
| `EXPECTED-OUTCOMES-R1.md`, `fixtures/F2-EXPECTED.json` | Expectations, frozen first |
| `REVIEW.md` | Votes, amendments, dissent, findings, upstream citation |
| `ABI-v0-R1-DELTA.md` | Attributed normative candidate text |
| `OFFLINE-AIKEN-PLAN.md` | S8a–d placement plan from source |
| `B2-PROVING-KEY-LIFECYCLE.md` | Design proposal, first vote |
| `EXECUTION-REQUEST-R1.json` | Exact bounded offline Aiken steps |
| `SOURCE-MANIFEST-R1.json` / `.sha256`, `REVIEW-INPUT.json` | Hashes |

## Still open, unchanged by this revision
- The 20 retained patterns and the general obligations.
- Private PCD, recursion and private handoff.
- Physical asset integration: the unit data transition carries the ledger value unchanged.
- Thread termination and universal certificates.
- Compiler pin B-C, proving-key lifecycle B2 and asset integration B3.
- Any Preprod action.
