Revision 1 is written in `claim-utxo-aiken-revision-1-20261015/`, but nothing has been compiled or tested. Every test result is a hand prediction frozen before the code was written, and no Aiken, Cargo, Rust or network step ran. A fresh independent review of my Aiken changes is still needed: my votes on D1–D12 and N1–N10 are independent judgments, but I wrote this revision, so they don't review my own code.

**What I ran:** only stdlib Python scripts I wrote, to copy, hash, assemble bytes and check text. The first copy run copied the 8 Aiken files but failed to write its receipt because `receipts/` didn't exist; the second run re-verified them byte for byte. My first exploratory shell command was denied by the harness, so I used read-only search tools after that. All of this is logged in `SCOPE.md` and `receipts/`.

## Aiken source changes

- **F-B:** the pinned stdlib shows the audit's premise is wrong: `Interval<a>` is generic (`interval.ak:42`), so the old annotation was valid. I applied the exact fix anyway; it changes nothing.
- **F-A:** I agree, which gives this one change two votes. `release` in `lib/pvc/c0.ak` now requires the `refund_vkh` signature on both release paths. One consequence: every settlement needs each claimant's signature. It also makes F-H moot, because settlement and refund now both need the same person's signature.
- **F-N:** new fixture F2 has byte strings of 64, 65, 128 and 129 bytes. Its expected bytes (544-byte statement, 598-byte CBOR, asset name `db59e4c2…`) were frozen in `fixtures/F2-EXPECTED.json` before any test was written. Aiken's own encoder is the first outside check of the chunking rule.
- **F-M and test strength:** I added the audit's missing coverage. The release tests and several issue refusals now fail only for their intended reason: they must return False, so an unrelated error can't pass them.
- **Expected result:** 76 tests (30 in `abi_test`, 46 in `context_test`), all listed in `EXPECTED-OUTCOMES-R1.md` with that file's hash recorded first. The test names and counts in the code match it. The five other Aiken files are byte-identical to attempt 2.

## New finding: compiler version risk

The installed compiler, v1.1.21, predates two fixes in v1.1.23. One (#1331) could make the compiled scripts decode one data type with another type's decoder. I couldn't read v1.1.21's source to check whether our types are affected. I added three decoder tests that should catch it; if one misbehaves, that's a compiler-version blocker before Preprod. I proposed tracking it as B-C.

## Votes (`REVIEW.md` §5)

Each count applies only to the exact wording in its row; none of this is approval of ABI v0 as a whole.

- **D3 and D2:** I disagree with the original wording. I agree with the audit's amended versions, which now have two votes each.
- **N1:** the refund rule has two votes. "Settlement release with no signer" has two votes against, and the signer-on-both-paths version has two votes for.
- **N2–N10:** two votes each, with conditions noted.
- **Identity-point rejection (F-I):** now has two votes, but I didn't implement it because it was outside this revision's scope.
- **F-E's alternative proof context:** I voted against, so it isn't adopted.

## Upstream identity-point claim

The original report's line 137 says upstream code rejects identity points; that's wrong. Only the upstream protocol document requires it (`commitment-groth16-protocol.md:362-364`, rule 4). The verifier `Verify.hs` imports no point-comparison function (`Verify.hs:36-55`). The other module that cites the requirement uses comparisons only for cost measurement. Full citations are in `REVIEW.md` §6; I made no crypto change.

## Offline Aiken plan (`OFFLINE-AIKEN-PLAN.md`)

From the compiler repo, which is v1.1.24, not the installed v1.1.21:
- **Closure:** the 38-file stdlib alone. Its own dependency on `aiken-lang/fuzz` is never resolved for a consumer, and the two files that import it are never type-checked.
- **Placement:** put the stdlib in a separate copy of the project under `build/packages/aiken-lang-stdlib/`, plus a `packages.toml` listing v2.2.0. The compiler then skips the downloader entirely, so neither the network nor the user cache is touched.
- **Confirmation:** whether v1.1.21 behaves the same is only confirmed by a post-run check (`tools/post_check.py`). Any fetch attempt counts as BLOCKED, not FAILED.

## B2 proving-key lifecycle (first vote; authorizes nothing)

- **Setup secret vs proving key:** the setup trapdoor, including the 32-byte random seed that recreates it, must never be written down. The proving key can't be used to forge proofs; it's kept under custody for operational hygiene.
- **Proposal:** a five-stage lifecycle with crash means "never use this VK", and fresh research keys only. It also states why the key must outlive setup: each step's thread output only exists after the previous transaction is confirmed. It doesn't pretend that output is known before genesis.

## Next steps

`EXECUTION-REQUEST-R1.json` gives the exact network-free steps A0–A9. They run inside a namespace with no network, empty `HOME` and cache directories, and the audit's resource limits. A later conditional set V1–V3 adds the generated proof tests once the Rust job's outputs exist (89 tests). The manifest is `SOURCE-MANIFEST-R1.json` (sha256 `284885367cae95cba0233739bd13ab6b7025a2a5203aa179dbe169c9cd8437aa`), with a `.sha256` file for `sha256sum -c`. `REVIEW-INPUT.json` lists 30 revision files and 38 external inputs for the reviewer.

Unchanged and still open: the 20 retained patterns and general obligations, private PCD, recursion and private handoff, and physical asset integration. This is still a data transition only, with the ledger value unchanged. The C0 depositing fix is in the source, but Preprod remains blocked on review, B2, B-C and B3.