# Expected outcomes, Aiken revision 1 (frozen before the assertions were written)

**Status: spec-only. Nothing here has been compiled, tested or run.** Every verdict below comes from reading source by hand. A run falsifies a row if its output differs. Any compile error, any unexpected test result, or any non-zero exit is a recorded failure. It is not retried silently, and a fix needs a new revision with a new manifest.

**Freeze order.** This file and `fixtures/F2-EXPECTED.json` are hashed into `receipts/FREEZE-1.json` before any edit to `source/aiken/lib/**` is made. The test names below are binding: the code must use exactly these names.

**Scope.** Aiken layer only. The Rust x7 subtree, the catalogue, `abi_ref.py` and `gen_x7_aiken.py` are unchanged and are not part of this revision. Execution is UNIT context only: no ledger, no Preprod, no cost-model claim.

---

## 0. Source changes this revision makes

| ID | File | Change | Basis |
|---|---|---|---|
| R1-FB | `lib/pvc/context_test.ak` | `fn after(t: Int) -> Interval<Int>` loses its return annotation | Audit F-B, applied exactly. The pinned stdlib shows the premise is false (`interval.ak:42` declares `Interval<a>`), so this is a no-op robustness edit (REVIEW §2). |
| R1-FA | `lib/pvc/c0.ak` | `release` requires `refund_vkh` among `extra_signatories` on **both** branches. `refund_ok` is replaced by `after_expiry`, which has the same bound rule and no signer clause. | Audit F-A (first vote) plus this author's agreeing vote (REVIEW §4, N1′) |
| R1-FN | `lib/pvc/abi_test.ak` | Fixture F2 with byte strings of 64, 65, 128 and 129 bytes | Audit F-N |
| R1-FM | `lib/pvc/context_test.ak` | Release fixtures updated for F-A; added test-gap coverage (audit F-M); three issue refusals made discriminating | Audit §7, F-M |
| R1-PROBE | `lib/pvc/abi_test.ak` | Decoder-strictness probes | Compiler pin v1.1.21 predates aiken fix #1331 (REVIEW §3.4) |

Unchanged, byte-identical to attempt 2 (`receipts/copy-receipt.json`): `aiken.toml`, `validators/c0.ak`, `validators/settle0.ak`, `lib/pvc/abi.ak`, `lib/pvc/settle.ak`.

---

## 1. Compile gate

| Gate | Expected |
|---|---|
| G-3′ `aiken check` (offline placement, EXECUTION-REQUEST-R1 step A6) | Exit 0. 76 tests, all pass: `abi_test` 30, `context_test` 46. Warnings are allowed and recorded. A compiler-version-mismatch warning is **not** expected, because the toml pins v1.1.21 and A2 requires v1.1.21. |
| G-4′ `aiken build` (A8) | Exit 0. Validators `c0.c0.{mint,spend,else}` and `settle0.settle0.{mint,spend,else}`. The hashes are recorded, not predicted. The C0 hash **differs** from any attempt-2 build because `release` changed. |

---

## 2. `abi_test.ak`: 30 tests

### 2.1 Tests carried over from attempt 2 (22, source unchanged), all pass

`family_and_tag_ascii`, `f0_statement_layout`, `f1_statement_layout`, `statement_lengths`, `f0_envelope_cbor`, `f1_envelope_cbor`, `envelope_name_is_hash_of_cbor`, `f0_f1_well_formed`, `universal_claim_kind_refused`, `setup_class_nonzero_refused`, `transition_without_context_refused`, `foreign_family_refused`, `outref_index_out_of_range_refused`, `u16_overflow_fails` (fail test), `slots_rules`, `slot_matching_on_pinned_pair`, `x2_scalars_match_prior_decimals`, `x2_vk_layout_lengths`, `x2_regression_verifies`, `x2_regression_statement_bit_flip_rejected`, `x2_regression_ic_count_tampered_fails` (fail), `x2_regression_truncated_proof_fails` (fail).

### 2.2 E-ABI-7: fixture F2 (F-N), 5 tests

F2 is F1 with `pre = a1⁶⁴`, `post = b2⁶⁵`, `effects = c3¹²⁸` and `payload = d4¹²⁹`. The frozen values are in `fixtures/F2-EXPECTED.json`.

| Test | Expected | What a pass shows |
|---|---|---|
| `f2_statement_layout` | pass | `abi.statement` equals the hand layout, 544 bytes |
| `f2_scalars_match_frozen` | pass | Aiken `blake2b_256` halves equal the frozen decimals (`109647507535968573812000909942980290589`, `87657774869094688286633492081292399739`), computed independently by Python `hashlib` |
| `f2_envelope_cbor` | pass | **Non-author oracle:** `builtin.serialise_data` chunks 65, 128 and 129 bytes as `5f (5840 …)* [4x …] ff` and leaves 64 bytes definite. 598 bytes. |
| `f2_asset_name_matches_frozen` | pass | `envelope_name` equals `db59e4c2eb83a691886e47025bdb5c17cbb756e78e2cc9c6ce9ef2d7e5af59f6` |
| `f2_well_formed` | pass | — |

If `f2_envelope_cbor` fails while the F0/F1 CBOR tests pass, then the ABI-v0 §2 chunking rule, x7 `abi::cbor` and `abi_ref.py` all share a wrong expectation. In that case every P-L1/P-M1 asset name computed off-chain is void.

### 2.3 E-ABI-8: decoder probes (compiler pin item), 3 tests

| Test | Expected | Meaning |
|---|---|---|
| `decoder_accepts_f2` | pass | Positive control: `expect env: EnvV0 = <F2 as Data>` succeeds and the bound value is used |
| `decoder_rejects_extra_transition_field` (fail test) | pass, because evaluation errors | A TransitionV0 with a 4th field is not an EnvV0 |
| `decoder_rejects_extra_transition_field_after_option_data` (fail test) | pass, because evaluation errors | The same probe, after an `Option<Data>` decoder is generated in the same program. A **pass of this test that turns into a test failure** (no error raised) is evidence of a decoder-name collision on v1.1.21. It would be a Preprod blocker for the compiler pin, not a test-authoring error. |

---

## 3. `context_test.ak`: 46 tests

The UNIT contexts are hand-built, and `placeholder.validity_range = interval.everything` (`transaction.ak:207-225`).

### 3.1 E-CTX-1 to E-CTX-3: carried over, unchanged (18), all pass

`settle_single_transition_ok`, `settle_and_two_slots_ok_either_order`, `settle_wrong_post_state_refused`, `settle_wrong_effects_digest_refused`, `settle_pre_state_mismatch_refused`, `settle_claim_for_other_thread_refused`, `settle_referenced_claim_not_counted`, `settle_extra_claim_refused`, `settle_wrong_vk_digest_refused`, `settle_value_changed_refused`, `settle_slots_changed_refused`, `settle_claim_token_mismatch_refused`, `settle_c0_input_without_datum_refused`, `settle_two_thread_inputs_refused` (the 12 E-CTX-2 tests are fail tests), `genesis_ok`, `genesis_seed_not_spent_refused`, `genesis_two_transition_slots_refused`, `genesis_no_transition_slot_refused` (the last three are fail tests).

### 3.2 E-CTX-4′: C0 release under F-A, 9 tests

Every test except the two `_ok` tests is a **value** test of the form `!release(...)`. A value test passes only if `release` returns False. An evaluation error makes it fail, so these tests discriminate a False result from an error.

| Test | Context | `release` returns | Test |
|---|---|---|---|
| `release_with_settle_outref_spent_ok` | thread input spent, signer `55²⁸` | True | pass |
| `release_settle_path_without_signer_refused` | thread input spent, no signer | False (signer clause) | pass |
| `release_settle_path_wrong_signer_refused` | thread input spent, signer `56²⁸` | False | pass |
| `release_signer_without_settle_or_expiry_refused` | no thread input, signer, validity `everything` | False (the `or` clause) | pass |
| `release_refund_after_expiry_ok` | lower bound Finite(1001), signer | True | pass |
| `release_refund_at_expiry_refused` | Finite(1000), signer | False | pass |
| `release_refund_unbounded_refused` | NegativeInfinity, signer | False | pass |
| `release_refund_without_signer_refused` | Finite(1001), no signer | False | pass |
| `release_token_kept_in_output_refused` | thread input spent, **signer present**, token kept in an output | False (output clause only) | pass |

`release_token_kept_in_output_refused` gains the signer, so the output clause is the only failing clause. Without that, F-A would make the test pass for the wrong reason.

### 3.3 E-CTX-5′: C0 issue, 9 tests

`issue_junk_vk_fails_at_point_decoding` is the positive control. Every clause before the pairing holds, so evaluation reaches `bls12_381_g1_uncompress` on `07…` and errors. The value tests below change exactly one input relative to that control. Because `and {}` is lazy (`gen_uplc.rs:4558`), they return False **without** reaching the pairing.

| Test | Form | Expected |
|---|---|---|
| `issue_junk_vk_fails_at_point_decoding` | fail test | pass (error) |
| `issue_universal_claim_kind_refused` | **value** `!c0.issue` (was a fail test) | pass: `well_formed` is False |
| `issue_vk_digest_mismatch_refused` | **value** (was a fail test) | pass: `vk_digest ≠ H(vk)` |
| `issue_name_not_envelope_hash_refused` | **value** (was a fail test) | pass: `name ≠ H(raw)` |
| `issue_claim_held_elsewhere_refused` | fail test (unchanged) | pass: `expect Script(holder)` errors |
| `issue_extra_policy_token_in_claim_output_refused` | value | pass: `dict.size(...) == 1` is False |
| `issue_two_outputs_holding_policy_refused` | fail test | pass: `expect [claim]` errors |
| `issue_transition_without_context_refused` | value | pass: `well_formed` is False |
| `burn_only_negative` | value | pass |

### 3.4 E-CTX-6: new settle and genesis coverage (F-M), 10 tests

| Test | Mutation from a passing base | Form | Expected |
|---|---|---|---|
| `settle_universal_claim_refused` | claim `claim_kind = 1` (token correctly named) | fail test | pass: `expect env.claim_kind == 0` in `claim_envelopes` |
| `settle_transition_slot_given_non_transition_claim_refused` | `transition = None`, same pinned pair | fail test | pass: `match_slots` returns None |
| `settle_thread_token_missing_refused` | thread input and continuation hold lovelace only | value | pass: the thread-token clause is False |
| `settle_own_policy_mint_refused` | the mint also adds a token of `sh()` | value | pass |
| `settle_continuation_stake_changed_refused` | continuation stake credential `Some(Inline(VerificationKey(02²⁸)))` | value | pass: the address clause is False |
| `genesis_extra_token_refused` | output also holds a foreign token | value | pass |
| `genesis_reference_script_refused` | output reference script `Some(0f²⁸)` | value | pass |
| `genesis_wrong_thread_id_refused` | `thread_id = 77³²` | value | pass |
| `genesis_quantity_two_refused` | mint quantity 2, output holds 2 | value | pass |
| `genesis_c0_hash_equals_policy_refused` | `c0_hash = sh()` | value | pass |

**Totals:** context_test has 18 + 9 + 9 + 10 = **46** tests, and abi_test has 22 + 5 + 3 = **30**. **76** in all. After S12/S13 the generated `x7_vectors_test.ak` adds 13, for **89**. The generator is unchanged and uses only `abi.statement`, `abi.envelope_name`, `abi.groth16_verify` and `c0.issue`, none of which this revision changes.

---

## 4. Offline-placement observations (part of the pass criteria for A6)

| Observation | Expected |
|---|---|
| Empty task-local `XDG_CACHE_HOME` and `HOME` after A6 | still empty. No `aiken/packages` directory is created, because no download path ran. |
| `build/packages/aiken-lang-stdlib/**` digests after A6 | identical to the 38-file pinned manifest |
| `aiken.lock` written by the CLI | one requirement and one package, `aiken-lang/stdlib` `v2.2.0` `github`, with an empty `[etags]` table |
| `build/packages/packages.toml` after A6 | same single entry |

If the CLI attempts any fetch inside the no-network namespace, A6 is **BLOCKED** (not failed), and the vendoring fallback needs its own audit.
