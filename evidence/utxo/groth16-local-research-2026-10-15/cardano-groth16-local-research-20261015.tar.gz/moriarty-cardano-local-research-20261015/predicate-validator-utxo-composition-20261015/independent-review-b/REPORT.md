# Independent review B: predicate validator and claim-UTxO composition

Reviewer: `claude-opus-5-5`, high effort, fresh non-author context, security owner. This is a read-only design review. Labels: **[SF]** source fact from an inspected capture, **[RO]** repository observation, **[INF]** inference, **[PROP]** proposal, **[GAP]** not inspected.

**Nothing was executed.** No builds, tests, SDK/VM, keys, proofs, ledger queries, network access or transactions. I did not read `provider-result.private.json`, `.foreman/` or any witness or key material. Pinned inputs match `INPUT-PINS.json` (REPORT `ebf03905…`, EARS `15b844d2…`, LEDGER-CODE-RECEIPTS `eb570c6e…`, cip0031.txt `581123bb…`). All ledger facts come from cardano-ledger source at `6654c3e5…`, which was the public `master` HEAD at capture time. That is not proof of the binary installed on Preprod. Preprod's protocol version and cost model remain **unknown**.

## 1. Votes

| Item | Vote |
|---|---|
| Approach selection: C (claim certificate UTxO) for run claims, issued by a family-shared Groth16 verifier; reference reuse only for universal certificates; A kept as a control | **AGREE** (substantive, after source inspection) |
| B as a *mandatory* token-authenticated VK registry | **DISSENT**: optional data store only (§4) |
| The concrete candidate (REPORT §3–4 and EARS PVC-01…15) as written | **CHANGES_REQUIRED** (§3) |
| The corrected first-prototype ABI in §5 | **PROPOSED**, not yet voted. It needs a second agreeing vote before adoption |

My agreement counts as the second agreeing vote only for the approach-selection row. It does not cover the original EARS text, or any ABI that did not exist in the original. This is not a security approval of any implementation.

## 2. Ledger facts checked against the captures

1. **[SF]** All inputs must exist. `babbageUtxoValidation` runs `validateBadInputsUTxO utxo allInputs`, where `allInputs = spendInputs ∪ collInputs ∪ refInputs` (Babbage `Utxo.hs:388-390`). This closes the original GAP. A transaction cannot consume its own outputs, and it cannot land on a chain where an input's issuing transaction was rolled back.
2. **[SF]** Spending inputs and reference inputs may overlap at protocol version ≥ 11. `disjointRefInputs` fails only when `pvMajor > Babbage-high && pvMajor < 11` (Babbage `Utxo.hs:214-229`). At protocol version 11 or later, one outref can be both spent and referenced in the same transaction. **The original candidate does not handle this.**
3. **[SF]** CIP-0031 (lines 59-69): a referenced output must exist. Its value is excluded from balancing. Its "validators are not required to pass (nor are the scripts themselves or redeemers required to be present)". It stays in the UTxO set. The creator **cannot control who references it** (lines 200-212). Plutus V1 scripts cannot appear in transactions that have reference inputs (line 90).
4. **[SF]** Phase-2 evaluation is all-or-nothing. `evalPlutusScripts`: "All scripts in the list must evaluate to `True`" (`Evaluate.hs:183-185`). The list comes from `getScriptsNeeded`. A redeemer missing for a needed script gives `NoRedeemer` (`:146-150`). If a transaction tagged `Phase2Valid` fails, the result is `ValidationTagMismatch`, which rejects the transaction (Alonzo `Utxos.hs:210-216`). If it is tagged `Phase2Invalid`, only collateral is consumed and no outputs are created (Babbage `Utxo.hs:489-502`). **[GAP]** I did not inspect `getScriptsNeeded` (Alonzo `UTxO.hs`), `babbageUtxowTransition` or `expectScriptsToPass`. That reference inputs add nothing to the needed scripts therefore rests on CIP-0031 text, not ledger code.
5. **[SF]** Collateral is checked only when redeemers exist. It must come from VKey addresses, be ADA-only (or have its non-ADA returned), cover `fee × collateralPercent`, be non-empty, and stay within `maxCollInputs` (Babbage `Utxo.hs:195-254`). The transaction's **total** ExUnits must be ≤ `maxTxExUnits` (`:423-424`). Every script in a transaction draws on that one budget.
6. **[GAP]** Not inspected: withdrawal and registration rules for withdraw-zero, the reference-script fee formula inside `getMinFeeTxUtxo`, the details of the Plutus V3 `ScriptInfo` multi-purpose case, and CIP-118 (superseded, so it is not treated as available).

## 3. Required changes to the candidate

**R1. Circular effects digest (blocking).** PVC-07 and REPORT §3.2 bind "an effects digest equal to the validator's own digest of the actual outputs **and mint**". In T_settle, the mint field includes the burn of `H(env)`, and `env` would have to commit to it. That cannot be satisfied. Fix: compute the digest over role-designated outputs only (continuation and effect outputs), using a fixed encoding that excludes claim-policy burns, fee, change and collateral return.

**R2. Ban circular context.** Envelopes must not commit to T_settle's TxId, the redeemer or script-integrity hash, or input/redeemer indices. The ledger sorts inputs, so indices are not stable [INF]. Bind only pre-existing outrefs: the settlement thread input and the issuance seed. Spending an outref once also gives natural invalidation. If the thread moves, every certificate bound to it becomes unusable.

**R3. Handle spend/reference overlap.** Run claims count only from `txInfoInputs` together with a −1 burn. A run-claim outref that also appears in `txInfoReferenceInputs` is rejected. Claims are de-duplicated by asset name before AND or k-of-n counting.

**R4. Consumer-enforced reuse.** Following CIP-0031, the holding script cannot stop anyone from referencing a run certificate. The settlement validator must therefore refuse referenced claims of kind `run`. PVC-08 must be stated as a consumer obligation, not a holding-script obligation.

**R5. The holding script must check more than presence.** "S_hold forwards by checking I_settle present" is too weak. Its spend branch must require that (a) its own token `H(datum)` is burned −1 in this transaction, and (b) either the input at `env.settle_outref` is spent, or the transaction lies after `env.expiry` and `env.refund_key` signs. A universal certificate is never spendable.

**R6. Parameter cycle.** The holding script and the policy each need the other's hash. Remove the cycle by making them **one Plutus V3 multi-purpose script `C0`**: its minting policy ID equals the payment credential of its holding address. The script runs once per purpose that is present [INF from the V3 purpose model; GAP on exact `ScriptInfo` handling].

**R7. Replace PVC-02.** A VK supplied in the redeemer is safe **if** `vk_digest = blake2b_256(canonical VK bytes)` is committed into `env`, and therefore into the asset name, and the consumer pins the digests it accepts. A token means "π verified under the VK with digest d". It does not mean the claim was approved. A registry UTxO, if used, only carries VK bytes, and its token proves immutable, content-addressed creation. Dropping the registry from the first prototype removes one authority surface and one reference-input cost.

**R8. Statement domain separation.** For a shared family verifier, the public statement must include the domain tag, catalogue `predicate_digest`, `family_id`, `vk_digest`, `setup_class` and the predicate payload. Each VK digest must map to at most one catalogue row. The validator itself derives the two public scalars as 16-byte big-endian halves of the statement digest, each less than q. It never accepts scalars from the redeemer. The experiment PLAN's X5 aliasing negative is the relevant falsifier.

**R9. Withdraw-zero is out of the first prototype.** Its registration, deposit and Conway withdrawal rules are GAP. S_settle0 alone coordinates the settlement.

**R10. Three claim classes, never conflated:**
- **Ledger claim.** Facts that S_settle0 recomputes from `TxInfo`: a spent or referenced outref exists in the UTxO set of the chain the transaction lands on, plus its value, datum, signatories, validity range and mint. No SNARK is needed.
- **Single-execution proof (run certificate).** π for one bound statement, minted once, bound to one settlement outref, and burned on use.
- **Universal property certificate.** A deploy-time statement about a `program_hash` under a semantics profile. It is reusable by reference and never asserts a run.

A P-L0-style proof ("bytes hashing to txid contain output j with coin ≥ T") is a statement about bytes only (E1/E2). It establishes neither inclusion nor unspentness. To make it a ledger claim, the outref has to appear as an input or a reference input.

**R11. Liability presence.** Any envelope or statement that carries Moriarty state must encode duty slots as (presence, amount), following R4 `DutyCell`. Absent means present=0 and amount=0. Present-zero means present=1 and amount=0. An absent slot is not refused. The certificate layer must never collapse these two cases.

**R12. Composition scope.** The prototype implements **AND with k ∈ {1,2}** only. OR and k-of-n are specified (§5.4) but not built. A DAG of parent claims is deferred. Ledger-mediated joins are **not PCD**. They do not close genuine recursive or multi-parent PCD, private handoff, the 20 retained patterns, or liability exits.

## 4. Registry and governance

- **[PROP]** Public compilation, proving and certificate minting stay permissionless. Anyone can mint a C0 certificate for any VK.
- Trust is a **per-consumer policy**: each settlement datum or script parameter pins accepted `(predicate_id, version, vk_digest)` tuples. This is the product contract's "per-contract policy commits to exact claim and verifier semantics" [RO `MORIARTY-PRODUCT-CONTRACT.md:62`].
- An application may optionally run a governed allowlist UTxO. That is application governance with explicit scope.
- Neither a mutable application registry nor an immutable one implies maintainer compile or deploy permission. Nothing here requires Moriarty-maintainer admission.
- Catalogue entries are immutable. A change produces a new version and a new digest. Revocation means consumers stop pinning the digest. Certificates are never mutated in place.

## 5. First-prototype public ABI [PROP]

Scope:
- Namespace `moriarty-research-g16/pvc/v0`, Preprod only.
- `setup_class = 0` means "research-insecure single-party". Any trapdoor holder can forge.
- No mainnet-conceptual policy may pin a class-0 digest. A mainnet ceremony produces new VKs, new digests and a new catalogue version, with no migration.
- New identities only. These are not rows of the bridge's missing 42-Cardano catalogue [RO bridge `predicate-catalog-status.md:24`].

### 5.1 Data (Plutus Data, Constr0, field order normative)

```
OutRef    = Constr0 [tx_id:Bytes32, index:Int]
EnvV0     = Constr0 [env_version=0, predicate_id:Bytes, predicate_version:Int,
                     predicate_digest:Bytes32, family_id:Bytes, vk_digest:Bytes32,
                     setup_class:Int, claim_kind:Int(0 run|1 universal),
                     payload:Bytes, seed:OutRef, settle_outref:Maybe OutRef,
                     pre_datum_hash:Maybe Bytes32, effects_digest:Maybe Bytes32,
                     expiry_posix_ms:Maybe Int, refund_key:Maybe Bytes28]
StmtV0    = Constr0 [tag="MRG16-PVC-STMT-v0", predicate_digest, family_id,
                     vk_digest, setup_class, payload, context:Maybe OutRef]
asset_name = blake2b_256(serialiseData(EnvV0))
D = blake2b_256(serialiseData(StmtV0));  publics = [int(D[0..16]), int(D[16..32])]
SettleDatumV0 = Constr0 [rule:Rule, slots:List<Slot>, thread_policy:Bytes28,
                         c0_hash:Bytes28, state:Data]
Slot = Constr0 [predicate_id, predicate_version, accepted_vk_digests:List<Bytes32>,
                claim_kind:Int, require_context:Bool]
Rule = Constr0 [kind:Int(0 AND), slot_indices:List<Int>]   -- v0: AND only
```

The catalogue row decides whether `StmtV0.context` is `settle_outref` (context-bound) or `None`, and also fixes the payload layout. Some fields only bind the envelope and are not part of the proof: `expiry`, `refund_key`, `seed`, and `settle_outref` when context is `None`. A public π can therefore be re-wrapped by a third party. For public-fact predicates this is harmless. Predicates that need it must choose context-bound statements.

### 5.2 T_issue (one claim per transaction)

- **Inputs:** `I_seed` (pubkey UTxO; `seed == its outref`) and `I_fee`.
- **Reference inputs:** `R_c0script`. If `pre_datum_hash` is present, also `R_thread = settle_outref`. Issuance then binds the predecessor datum from the ledger, not from the prover.
- **Mint:** exactly +1 `C0/asset_name`, with redeemer `Constr0[env, vk_bytes, proof_bytes]`.
- **Outputs:** exactly one output at the C0 address (no stake credential, no reference script), holding inline datum `env` and min-ADA plus that one token. Plus change.
- **Collateral:** pubkey, ADA-only.

The C0 mint branch checks: seed spent; asset name; `vk_digest`; Groth16 verification over the derived publics; `R_thread` datum hash when required; well-formed `Maybe` fields.

### 5.3 T_settle

- **Inputs:** `I_thread` (at S_settle0, holding a one-shot thread token), `I_claim_1..k` (at C0), `I_fee` and collateral.
- **Reference inputs:** `R_univ_*` (C0, `claim_kind = 1`) and script references.
- **Mint:** exactly −1 per used run claim. No other C0 movement.
- **Outputs:** `O_thread'` and `O_effect_*`.
- **Validity:** a finite upper bound.

S_settle0 reads each claim's env from the claim input's **resolved inline datum** and requires `H(datum) == held asset name`. The checks per run claim:
- `settle_outref == own outref`;
- `pre_datum_hash == hash(own datum)`;
- `effects_digest == role-digest(O_thread', O_effect_*)`;
- upper bound ≤ `expiry`;
- its slot accepts `vk_digest`.

Further checks:
- Universal certificates match a slot through reference inputs only.
- Rejected: duplicate or overlapping claims, extra C0 inputs, and unmatched slots.

### 5.4 Later semantics (specified only)

- **OR:** at least one slot is satisfied, and every claim present must match some slot.
- **k-of-n:** at least k distinct asset names, and each claim fills at most one slot.
- **DAG parents:** require new versioned Moriarty join semantics (PVC-14).

## 6. Corrective EARS text [PROP, untested]

**PVC-02′.** If a certificate's `vk_digest` is not among the slot's accepted digests, then S_settle0 shall reject. The verifier shall compute `vk_digest` from the VK bytes it used. It shall not treat registry presence or token presence as acceptance.

**PVC-07′.** The settlement shall compare effects only over role-designated outputs. It shall exclude claim-policy burns, fee, change and collateral return. No envelope shall commit to the settling TxId, redeemer hash, script-integrity hash or input index.

**PVC-08′.** S_settle0 shall count a run claim only if it is in `txInfoInputs`, is not in `txInfoReferenceInputs`, and its token is burned −1 in the same transaction.

**PVC-16.** C0's spend branch shall require that its own token is burned and that either `settle_outref` is spent, or `refund_key` signs after `expiry`. For `claim_kind = 1`, it shall reject every spend.

**PVC-17.** The family verifier shall derive both public scalars from `StmtV0` itself and reject any redeemer-supplied scalar.

**PVC-18.** The catalogue shall map each `vk_digest` to at most one `(predicate_id, version)` row. Each row shall pin exactly one `predicate_digest`, `family_id`, payload layout and context mode.

**PVC-19.** Policies or statements whose `setup_class = 0` shall never be pinned by any mainnet-target policy.

**PVC-20.** Envelopes carrying Moriarty duties shall encode (presence, amount) per slot and preserve the distinction between absent and present-zero.

**PVC-21.** The first prototype shall not use withdraw-zero, Plutus V1/V2, CIP-118 or nested transactions.

**PVC-22.** Reports shall label each claim as ledger claim, run certificate or universal certificate, and shall not describe a ledger-mediated join as PCD or recursion.

Retain PVC-03/04/05/06/09/10/12/13/14/15. PVC-01 shall drop its "script hash per row" requirement for family-shared rows.

## 7. Acceptance experiments (specified only, none run)

Two conditions apply to every experiment:
- **Submitting transactions needs separate authorization.** None is granted here. Local UPLC/`aiken check` runs need an execution authorization that this review does not grant.
- **Every Preprod observation is provider-observed (E0)**, recorded with bytes, digest, URL, time, tip and network magic.

| ID | Predicate (expected) | Falsifies |
|---|---|---|
| Y1 | Effects digest computed with and without the C0 burn. A burn-inclusive design has no satisfying env (by construction) | R1 |
| Y2 | At protocol version ≥ 11, one claim outref both spent and referenced. S_settle0 rejects; a mutant without de-duplication double-counts | R3 |
| Y3 | Run certificate referenced, not spent: rejected. Universal certificate referenced: accepted | R4 |
| Y4 | C0 spend without burn, or burn without the settle outref before expiry: rejected | R5 |
| Y5 | Certificate minted under a research VK digest not in the slot: rejected. The same certificate under a pinned digest: accepted | R7 |
| Y6 | Two catalogue rows sharing a VK digest: the catalogue checker rejects | PVC-18 |
| Y7 | Scalar alias `x + q` in place of the derived publics: the verifier ignores redeemer scalars, so there is no effect | PVC-17 |
| Y8 | Thread moved by another transaction, then the old certificate is used: `BadInputsUTxO` or `settle_outref` mismatch | R2 |
| Y9 | P-L0 certificate about a spent output, versus a ledger claim through a reference input to an unspent output. Only the latter establishes current membership | R10 |
| Y10 | R4 invoice `finish` (present-zero) against an absent-slot envelope: digests differ | R11 |
| Y11 | Total ExUnits for k ∈ {1,2}: issuance-side verification against S_settle0 alone, under the observed Preprod cost model | Cost |

## 8. Collateral, fees, privacy

- **Cost.** Each issuance carries one Groth16 verification and its own fee and collateral. The settlement carries none, but pays for k extra inputs, datums and burns. No ExUnit figure is claimed.
- **Failure and min-ADA.** A failed `Phase2Invalid` submission loses collateral. Min-ADA in certificates is locked until the burn or refund.
- **Privacy.** `env`, the payload, VK digests, the claim graph and the timing are all public. Groth16 hides only the witness. Private completeness of effects is **not** provided by this design.

## 9. Not inspected / limits

- **Ledger code:** Alonzo `UTxO.hs` (`getScriptsNeeded`), Babbage `Utxow`/`Utxos`, `Scripts.hs`, the Conway withdrawal and certificate rules, and the Plutus V3 `Contexts.hs` capture. For the last one I relied on the author's citation and did not re-inspect it.
- **Repository material:** the R4 `SEMANTIC-CORRECTION.md`, the Muse reviews, the experiment `data/` and outputs, and the bridge files other than `predicate-catalog-status.md`. Of the brainstorm reports I read only the verdict lines.
- **Preprod deployment and cost:** protocol version, cost model and MSM availability remain unknown.

This review does not certify any implementation. It authorizes no transaction, native run or proving.
