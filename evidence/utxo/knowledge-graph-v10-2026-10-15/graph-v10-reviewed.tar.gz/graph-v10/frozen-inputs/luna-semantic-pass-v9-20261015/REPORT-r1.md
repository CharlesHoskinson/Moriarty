# Luna semantic pass v9 r1

This successor preserves the initial v9 outputs and adds semantic coverage for the previously partial natural-language reports. It does not change the frozen input packet or make new security, formal, execution, or acceptance judgments.

Input freeze: `8407b1301aff11e519b427b25d06179b8c871708a740e8d4ce47976f13a6aae5`; 39 staged records / 419,946 bytes. All hashes were reverified. The ten previously partial report/review documents were each read individually from line 1 through EOF; both small Quint root-question JSON files were read structurally in full. Per-file modes and limits are recorded in `source-coverage-v9-r1.json`.

The added graph delta retains source/result/acceptance distinctions, the historical PR54 m3 miss and open second-vote requirement, the Quint r3 unexecuted request questions (including 89 versus 93), the ABI v1 R3 failure and source-only JSON/persistence proposals, and current-Core compiler source-only status. It records P3-7 disagreement as attributed report positions and preserves the repair report’s statement that no vote resolved it. No conclusion is promoted to Luna certification.

Requested model/effort: `gpt-6-luna` / `high`; returned runtime identity unavailable. No candidate was imported; no private provider body was read; no SDK, circuit, key, proof, K, Quint, Aiken, ledger, wallet, network, or retrieval execution occurred. No Graphify integration/build was run; no owned process remains.

New r1 graph size: 28 nodes, 22 edges, 0 hyperedges. Historical v8 nodes, IDs, labels, attributes, source digests and initial r0 output files remain unmodified.
