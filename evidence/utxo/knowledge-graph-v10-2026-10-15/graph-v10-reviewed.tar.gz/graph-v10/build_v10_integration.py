"""Exact frozen V8 + Luna V9 r1 + Luna V10 merge; mechanical operations only."""
from __future__ import annotations
import copy
import hashlib
import json
import re
import resource
from collections import Counter
from importlib.metadata import version
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = Path('/home/charl/moriarty-eutxo-validation-2026-10-12')
PARENT = BASE / 'luna-graph-v8-integration-20261015'
S9 = BASE / 'luna-semantic-pass-v9-20261015'
S10 = BASE / 'luna-semantic-pass-v10-20261015'
F9 = BASE / 'luna-graph-v9-input-staging-20261015/FREEZE.json'
F10 = BASE / 'luna-graph-v10-input-staging-20261015/FREEZE.json'
PYTHON = '/home/charl/.local/share/uv/tools/graphifyy/bin/python'
PINS = {
 PARENT / 'graphify-out/graph-v8.json': '87bc5d111ef528592ae520cbe430fdec9dd260391504830021ee00c6d52a77c0',
 PARENT / 'MANIFEST-v8.json': 'b46f8426d735e054ee3f939f3820e72062db546cebfd520f9d1a06254755d968',
 PARENT / 'build_v8_integration.py': '1197aea395acfa8b3597b3e20e07f9e38ad6e8918a479c3239c7d92d7a411862',
 S9 / 'semantic-v9-luna-r1.json': '79c9a08e3d6c75d686e8e00f5291a55b7f53b0143472e152f37b852729ebc858',
 S9 / 'MANIFEST-r1.json': '1d8f2a21fb9a6a0d31952be1385e6f5ca2ff9ee510b593d6f3d74c8ebf8ed8e1',
 S9 / 'source-coverage-v9-r1.json': 'be245df8fc430ece1a775feffb2ddec5c1ce63690eba9c06e62e380e200e53c5',
 S9 / 'REPORT-r1.md': 'dd4753c79714530db17ba0b34530e7553de12bfe94c88e986dc4aaf65e9b2f4c',
 S10 / 'semantic-v10-luna.json': 'ed7ac7f74341af71ed94ad20c5d28c4bf4ab5085d545ae0b9bc391234239c3c1',
 S10 / 'MANIFEST.json': '8abaa1741bfb3c2c5c0ace6b5e7b125c1a8e0ee59e1af320945b0f0580461ea4',
 S10 / 'source-coverage-v10.json': '9ca8713c7896ace074bceea90b88dacd8b80814de29cdb43d62939c69355e3ce',
 S10 / 'REPORT.md': '3e60e9c0a4a270dfae10cfa67898b840b1368ea4df0694d38f40a34d78f188db',
 F9: '8407b1301aff11e519b427b25d06179b8c871708a740e8d4ce47976f13a6aae5',
 F10: '135391641a89704b83fa5e2a9772bd99981f72bc71ae31e157ee69bef391d22b',
}

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''): h.update(block)
 return h.hexdigest()

def pin(p):
 p=Path(p); return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}

def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def canon(x): return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def stripped(n): return {k:v for k,v in n.items() if k not in ('community','community_name')}

def write(name,x):
 p=OUT/name; assert p.resolve().is_relative_to(OUT)
 p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8'); return p

def structure(nodes,edges,hypers):
 assert all(isinstance(n,dict) and isinstance(n.get('id'),str) and n['id'] and isinstance(n.get('label'),str) for n in nodes)
 ids={n['id'] for n in nodes}; assert len(ids)==len(nodes),'duplicate node ID'
 assert all(isinstance(e,dict) and e.get('source') in ids and e.get('target') in ids for e in edges),'missing edge endpoint'
 eids=[e['id'] for e in edges if 'id' in e]; assert len(eids)==len(set(eids)),'duplicate explicit edge ID'
 hids=[h.get('id') for h in hypers]; assert len(hids)==len(set(hids)),'duplicate hyperedge ID'
 assert all(isinstance(h,dict) and isinstance(h.get('nodes'),list) and all(n in ids for n in h['nodes']) for h in hypers),'missing hyperedge member'
 return ids

def main():
 assert OUT==BASE/'luna-graph-v10-integration-20261015'
 resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(2147483648,2147483648))
 assert version('graphifyy')=='0.9.91'
 verified={}
 def check(p,expected,expected_bytes=None):
  rec=pin(p); assert rec['sha256']==expected,f'hash mismatch: {p}'
  if expected_bytes is not None: assert rec['bytes']==expected_bytes,f'size mismatch: {p}'
  if rec['path'] in verified: assert verified[rec['path']]==rec
  verified[rec['path']]=rec
 for p,h in PINS.items(): check(p,h)
 parent_manifest=load(PARENT/'MANIFEST-v8.json')
 for rec in parent_manifest['files']:check(rec['path'],rec['sha256'],rec['bytes'])
 parent=load(PARENT/'graphify-out/graph-v8.json')
 s9=load(S9/'semantic-v9-luna-r1.json');s10=load(S10/'semantic-v10-luna.json')
 c9=load(S9/'source-coverage-v9-r1.json');c10=load(S10/'source-coverage-v10.json')
 freezes=[load(F9),load(F10)]; source_pins={}; coverage_summary=[]
 for v,fp,freeze,coverage in zip((9,10),(F9,F10),freezes,(c9,c10)):
  assert coverage['freeze_sha256']==PINS[fp]
  rows=freeze['files']; expected_count,expected_bytes=((39,419946) if v==9 else (21,184796))
  assert len(rows)==coverage['frozen_file_count']==expected_count
  assert sum(r['bytes'] for r in rows)==coverage['frozen_total_bytes']==expected_bytes
  rowpins={}
  for r in rows:
   p=Path(r['staged_file']) if 'staged_file' in r else fp.parent/r['copy']
   check(p,r['sha256'],r['bytes']); rowpins[str(p)]=verified[str(p)];source_pins[str(p)]=verified[str(p)]
  assert len(coverage['coverage'])==expected_count
  for r in coverage['coverage']:
   p=fp.parent/r['staged_file']; assert rowpins[str(p)]['sha256']==r['sha256'] and rowpins[str(p)]['bytes']==r['bytes']
  coverage_summary.append({'version':v,'selected_sources':expected_count,'selected_bytes':expected_bytes,
                           'read_modes':dict(Counter(r['read_mode'] for r in coverage['coverage']))})
 for folder,mp in ((S9,S9/'MANIFEST-r1.json'),(S10,S10/'MANIFEST.json')):
  for r in load(mp)['outputs']:check(folder/r['path'],r['sha256'],r['bytes'])
 for sem,expected in ((s9,(28,22,0)),(s10,(16,17,0))):
  assert tuple(len(sem[k]) for k in ('nodes','edges','hyperedges'))==expected
  for item in sem['nodes']+sem['edges']+sem['hyperedges']:
   if item.get('source_sha256'):
    assert item['source_file'] in verified,f'unpinned source reference: {item["source_file"]}'
    assert verified[item['source_file']]['sha256']==item['source_sha256']
 before=[verified[p] for p in sorted(verified)]
 nodes=copy.deepcopy(parent['nodes']+s9['nodes']+s10['nodes'])
 edges=copy.deepcopy(parent['links']+s9['edges']+s10['edges'])
 hypers=copy.deepcopy(parent['hyperedges']+s9['hyperedges']+s10['hyperedges'])
 parent_ids=structure(parent['nodes'],parent['links'],parent['hyperedges']);ids=structure(nodes,edges,hypers)
 assert (len(nodes),len(edges),len(hypers))==(6057,16790,1)
 old_ui=[n for n in parent['nodes'] if n['id'].startswith('luna_v8_sherlock_uireq_')];assert len(old_ui)==35
 parent_by_id={n['id']:n for n in parent['nodes']}
 versions=[n for n in s9['nodes'] if n['id'] in ('luna_v9_9eff_uireq_023','luna_v9_9eff_uireq_026')];assert len(versions)==2
 requirement_checks=[]
 for n in versions:
  attrs=n['attributes'];old=parent_by_id[attrs['historical_requirement_node']]
  assert attrs['base_block_sha256']==old['attributes']['clause_sha256']
  # Mechanical source block hashing uses the declared full requirement-block scope.
  text=Path(n['source_file']).read_text(encoding='utf-8')
  headings=list(re.finditer(r'^### Requirement: (.+)$',text,re.M));assert len(headings)==35
  index=int(attrs['requirement_id'][-3:])-1
  block=text[headings[index].start():headings[index+1].start() if index+1<len(headings) else len(text)]
  assert hashlib.sha256(block.encode()).hexdigest()==attrs['new_block_sha256']
  requirement_checks.append({'id':n['id'],'historical_id':old['id'],'base_block_sha256':attrs['base_block_sha256'],
                            'new_block_sha256':attrs['new_block_sha256'],'full_requirement_block_hash_verified':True})
 extraction={'schema':'exact-graphify-merge-input/1','scope':'exact V8 + frozen Luna V9 r1 + frozen Luna V10 concatenation',
             'parent':pin(PARENT/'graphify-out/graph-v8.json'),'overlays':[pin(S9/'semantic-v9-luna-r1.json'),pin(S10/'semantic-v10-luna.json')],
             'nodes':nodes,'edges':edges,'hyperedges':hypers,'input_tokens':None,'output_tokens':None}
 write('exact-merge-input-v10.json',extraction)
 for p in list(PINS):
  if p.parent in (S9,S10) or p in (F9,F10):
   target=OUT/'frozen-inputs'/p.parent.name/p.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
 import networkx as nx
 from graphify.cluster import score_all
 from graphify.analyze import god_nodes
 from graphify.export import to_html
 G=nx.DiGraph();G.graph.update(copy.deepcopy(parent.get('graph',{})))
 for n in nodes:G.add_node(n['id'],**{k:copy.deepcopy(v) for k,v in n.items() if k!='id'})
 for e in edges:G.add_edge(e['source'],e['target'],**{k:copy.deepcopy(v) for k,v in e.items() if k not in ('source','target')})
 G.graph['hyperedges']=copy.deepcopy(hypers)
 groups=nx.community.louvain_communities(G.to_undirected(),seed=42,weight='weight')
 communities=dict(enumerate(sorted((sorted(g) for g in groups),key=lambda g:(-len(g),g))))
 labels={cid:f'Community {cid}' for cid in communities};membership={n:cid for cid,group in communities.items() for n in group}
 assert set(membership)==ids
 cohesion=score_all(G,communities);gods=god_nodes(G)
 write('graphify-analysis-v10.json',{'method':'pure-Python NetworkX Louvain seed 42, default resolution 1.0; Graphify score_all/god_nodes/to_html',
                                  'communities':communities,'cohesion':cohesion,'god_nodes':gods,'labels':labels,
                                  'scope':'derived navigation only; no new semantic relationships or judgments'})
 graph=copy.deepcopy(parent);graph['nodes']=copy.deepcopy(nodes);graph['links']=copy.deepcopy(edges);graph['hyperedges']=copy.deepcopy(hypers)
 for n in graph['nodes']:n['community']=membership[n['id']];n['community_name']=labels[membership[n['id']]]
 if 'hyperedges' in graph.get('graph',{}):graph['graph']['hyperedges']=copy.deepcopy(hypers)
 gp=write('graphify-out/graph-v10.json',graph);hp=OUT/'graph-v10.html'
 assert to_html(G,communities,str(hp),community_labels=labels,node_limit=5000,learning_overlay={})
 final=load(gp);final_ids=structure(final['nodes'],final['links'],final['hyperedges']);by_id={n['id']:n for n in final['nodes']}
 assert parent_ids<=final_ids and all(stripped(n)==stripped(by_id[n['id']]) for n in nodes)
 assert final['links']==edges and final['hyperedges']==hypers
 assert all(by_id[n['id']]['attributes']==n['attributes'] for n in old_ui+versions)
 after=[pin(r['path']) for r in before];assert before==after,'immutable input/output changed'
 counts={'parent_nodes':6013,'parent_links':16751,'parent_hyperedges':1,'v9_added_nodes':28,'v9_added_edges':22,
         'v10_added_nodes':16,'v10_added_edges':17,'nodes':len(nodes),'links':len(edges),'hyperedges':len(hypers),
         'communities':len(communities),'god_nodes_returned':len(gods),'inherited_uireq_nodes_preserved':35,'new_uireq_versions':2,
         'duplicate_node_ids':0,'duplicate_explicit_edge_ids':0,'duplicate_hyperedge_ids':0,'missing_edge_endpoints':0,'missing_hyperedge_members':0,
         'identical_duplicate_link_records':len(edges)-len(set(map(canon,edges))),'self_loop_links':sum(e['source']==e['target'] for e in edges),
         'directed_pair_records_collapsed_only_in_analysis_topology':len(edges)-G.number_of_edges(),'analysis_topology_edges':G.number_of_edges(),
         'new_ast_files':0,'new_ast_nodes':0,'selected_v9_sources':39,'selected_v9_bytes':419946,'selected_v10_sources':21,'selected_v10_bytes':184796,
         'unique_staged_source_paths_across_new_freezes':len(source_pins),'immutable_files_verified':len(before),
         'inherited_node_source_file_strings':len({n['source_file'] for n in parent['nodes'] if n.get('source_file')}),
         'new_overlay_node_source_file_strings':len({n['source_file'] for n in s9['nodes']+s10['nodes'] if n.get('source_file')}),
         'all_node_source_file_strings':len({n['source_file'] for n in nodes if n.get('source_file')})}
 assert counts['identical_duplicate_link_records']==20 and counts['self_loop_links']==5
 checks={'schema':'mechanical-graph-v10-check/1','scope':'mechanical preservation only; no security/formal/acceptance judgment',
         'all_checks_passed':True,'counts':counts,'all_6013_v8_ids_and_noncommunity_attrs_preserved':True,
         'all_44_new_luna_node_noncommunity_attrs_preserved':True,'all_link_records_and_hyperedges_exact':True,
         'all_35_historical_uireq_nodes_and_declared_digests_unchanged':True,'new_requirement_block_checks':requirement_checks,
         'all_new_overlay_source_file_hash_references_match_frozen_inputs':True,'all_frozen_inputs_and_parent_manifest_outputs_unchanged':True,
         'immutable_pins':after,'graph':pin(gp),'html':pin(hp)}
 write('MECHANICAL-CHECK-v10.json',checks)
 inherited=load(PARENT/'source-coverage-receipt-v8.json')
 receipt={'schema':'luna-graph-v10-source-coverage/1','scope':'bounded exact source-attributed graph integration candidate',
          'graphify_version':version('graphifyy'),'interpreter':PYTHON,'integration_author_configured_model':'gpt-6.1-sol','integration_author_configured_effort':'high',
          'luna_requested_configured_model':'gpt-6-luna','luna_requested_effort':'high','luna_returned_identity':'unavailable',
          'identity_limit':'Explicit requested/configured identities are distinct from unobservable returned runtime identity.',
          'inherited_v8_coverage':{'receipt_pin':pin(PARENT/'source-coverage-receipt-v8.json'),
                                 'v7_coverage':inherited['inherited_v7_coverage'],'v8_luna_coverage':inherited['fresh_luna_coverage']},
          'new_luna_v9_r1_coverage':c9,'new_luna_v10_coverage':c10,'new_coverage_summary':coverage_summary,
          'integration_read_scope':'Whole frozen V8/overlay JSON structural reads, supplied coverage/manifests and builder. Staged source bodies were byte-hashed; two requirement blocks structurally hashed. No new semantic extraction or candidate/raw-source audit.',
          'counts':counts,'immutable_pins':after,'input_tokens':None,'output_tokens':None,'token_cost':None,
          'token_cost_limit':'Token usage and monetary cost were not exposed; no zero-cost assertion.',
          'html':{'aggregated':True,'node_limit':5000,'community_nodes':len(communities),'full_json_retains_exact_hyperedge':True},
          'acceptance':'unreviewed candidate awaiting fresh actual Muse Wonder high audit; no product acceptance',
          'limits':['No new model call, network, installation, AST extraction, source execution, test run, native tool, key/cache/SDK/VM/proof/ledger action or Git mutation.',
                    'Frozen records only; no later live A/P3 work status incorporated.',
                    'Luna claims/results remain exactly source-attributed; historical uncompiled nodes retain their original source versions.',
                    'All 20/U/M/MC/SP/G, recursion/private/multiparent, general/current compiler, physical settlement and actual Preprod exits remain open as attributed.']}
 write('source-coverage-receipt-v10.json',receipt)
 delta=['# Exact attributed Luna delta: V9 r1 and V10','', 'These are frozen source-attributed statements, not new integration judgments. Full attributes and edges are in the exact merge input.','']
 for sem in (s9,s10):
  for n in sem['nodes']:
   delta += [f"## {n['id']}",'',n['label'],'',n['attributed_statement'],'',f"Source: `{n['source_file']}` / `{n['source_location']}` / SHA-256 `{n['source_sha256']}`.",'','```json',json.dumps(n.get('attributes',{}),indent=2,ensure_ascii=False),'```','']
 (OUT/'ATTRIBUTED-DELTA-v10.md').write_text('\n'.join(delta),encoding='utf-8')
 lines=['# Graphify V10 frozen mechanical integration','',
        'Exact union: frozen V8 + Luna V9 r1 + Luna V10. This candidate awaits a fresh actual Muse Wonder high nonsecurity audit. It makes no security, cryptographic, formal, source-adoption, product or release judgment.','',
        f"{len(nodes)} nodes, {len(edges)} exact link records, {len(hypers)} exact hyperedge; {len(communities)} communities, {len(gods)} returned god nodes.",'',
        '## Sources and coverage','',
        'V9 r1: 39 frozen inputs / 419,946 bytes. V10: 21 frozen inputs / 184,796 bytes. The exact independent read-mode tallies below come from the respective Luna coverage receipts; they are not integrator semantic reads.','']
 for summary in coverage_summary:lines.append(f"- V{summary['version']}: `{json.dumps(summary['read_modes'],sort_keys=True)}`.")
 lines += ['', 'Inherited coverage remains separate and unchanged: V7 had 32 partial reads, one byte-only input and zero full-document reads; V8 Luna had 23 full reads and 10 partial/safe metadata reads across 33 sources / 439,837 bytes.',
           'The integrator read frozen graph/overlay JSON structurally and byte-verified selected staged sources. Only the two changed requirement blocks received new structural source-text hashing. No whole-source/corpus completeness, full raw-result audit or source acceptance is claimed.',
           'Luna was requested/configured as gpt-6-luna high; returned runtime identity remains unavailable. Integrator configured model: gpt-6.1-sol high. Token usage and monetary cost are unavailable, not zero.',
           f"Node source_file string counts: {counts['inherited_node_source_file_strings']} inherited, {counts['new_overlay_node_source_file_strings']} in new overlays, {counts['all_node_source_file_strings']} combined. These path-string counts do not imply source read coverage.",'',
           '## Mechanical integrity and visualization','',
           'All 6,013 parent node IDs/non-community attributes and all 44 new Luna node payloads are retained. All inherited links, 39 new links, multiplicities, source attributes and the existing hyperedge are exact. No new semantic relation was added. All 35 historical UIREQ IDs, clauses, routes, statuses and digests remain unchanged; UIREQ-023/026 receive separate exact V9 source-version nodes.',
           'The two changed new requirement digests were independently reproduced from the declared complete heading block through the next Requirement heading/EOF, including scenarios and trailing newlines. They are not hashes of the separately displayed normative-clause string.',
           f"Duplicate node/explicit-edge/hyperedge IDs and missing edge endpoints/hyperedge members: zero. Preserved identical duplicate links: 20; preserved self-loops: 5. Analysis topology collapses {counts['directed_pair_records_collapsed_only_in_analysis_topology']} same-pair link records, while JSON retains all {len(edges)} raw records.",
           f"All {len(before)} distinct bounded input/control/prior-output pins were verified before and after build. Parent V8 outputs and builder remain unchanged.",
           f"WARNING: {len(nodes)} nodes exceed the 5,000-node HTML limit. HTML uses an aggregated {len(communities)}-community view; the complete JSON retains every node, link record and exact hyperedge. An intra-community hyperedge can be omitted from the aggregate display.",
           'Communities use pure-Python NetworkX Louvain seed 42. Installed Graphify 0.9.91 provides cohesion, god-node ranking and HTML. Community labels/membership are derived navigation, not evidence or new semantic relations.','',
           '## Attributed scope and chronology','',
           'ATTRIBUTED-DELTA-v10.md reproduces all 44 new source statements and their exact attributes. Historical uncompiled nodes remain past source versions. New current-Core actual-run/review nodes retain the reported qualified evidence, N-01..N-08 and NOT_ADOPTED boundary. ABI local legacy R/G observations do not become generic compiler/key/proof/ledger evidence. Source A remains proposed/unexecuted at its freeze. Finite Sherlock K-A/Quint 98-green statements stay scoped to their frozen reports and do not qualify Cardano or whole Core.',
           'No later live A/P3 status is included. All 20 pattern families and U/M/MC/SP/G exits, recursion/private/multiparent, general/current compiler qualification, physical settlement and actual Preprod remain open as attributed.','',
           '## God Nodes','', '| ID | Label | Degree |','|---|---|---:|']
 for g in gods:lines.append(f"| `{g['id']}` | {g['label'].replace('|','/')} | {g['degree']} |")
 lines += ['', 'God nodes measure graph topology, not trust or claim acceptance.','', '## Community cohesion','', '| Community | Nodes | Raw cohesion |','|---|---:|---:|']
 for cid,members in communities.items():lines.append(f'| {cid} | {len(members)} | {cohesion[cid]} |')
 lines += ['', '## Frozen review candidate','',
           'MANIFEST-v10.json pins the repeatable builder, RUN.md, copied frozen semantic/control inputs, graph, exact merge input, HTML, report, attributed delta, coverage receipt, analysis and mechanical check. MANIFEST-v10.sha256 pins the manifest. Each original staged source and all inspected parent outputs are separately pinned in the mechanical/coverage receipts.',
           'No canonical vault/repository write, source publication, merge, deployment or product acceptance occurred.']
 (OUT/'GRAPH_REPORT-v10.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 paths=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name not in ('MANIFEST-v10.json','MANIFEST-v10.sha256','BUILD-LOG.txt'))
 mp=write('MANIFEST-v10.json',{'schema':'frozen-graph-v10-candidate/1','scope':'nonsecurity mechanical integration only',
          'candidate_status':'awaiting fresh actual Muse Wonder high full delta/builder/coverage audit',
          'parent':pin(PARENT/'graphify-out/graph-v8.json'),'overlays':extraction['overlays'],'counts':counts,'files':[pin(p) for p in paths]})
 (OUT/'MANIFEST-v10.sha256').write_text(sha(mp)+'  MANIFEST-v10.json\n',encoding='utf-8')
 print(json.dumps({'counts':counts,'new_coverage_summary':coverage_summary,'manifest':pin(mp),'graph':pin(gp),'html':pin(hp),
                   'report':pin(OUT/'GRAPH_REPORT-v10.md'),'receipt':pin(OUT/'source-coverage-receipt-v10.json'),'all_checks_passed':True},indent=2))

if __name__=='__main__':main()
