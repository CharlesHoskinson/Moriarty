# Exact attributed Luna delta: V9 r1 and V10

These are frozen source-attributed statements, not new integration judgments. Full attributes and edges are in the exact merge input.

## luna_v9_k_correspondence_source_only

Core/2 K correspondence source prepared; K not compiled or run

The Opus report says the candidate source and authorized checks are complete, but no K command ran; K semantics remain unverified and acceptance is pending.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/current-core-k-correspondence-source-r2-20261015/REPORT.md` / `line:5` / SHA-256 `f92b630c1bab9865de38d8341e6abe97d00e8eca4852a64f5ea3e51ec8aa24c5`.

```json
{
  "execution": "no K command",
  "acceptance": "none",
  "remaining": "all 20 patterns; general effects; recursion; private/multiparent; U/M/MC/SP/G",
  "attribution_role": "claim as stated in the cited report; no new Luna conclusion or certification"
}
```

## luna_v9_quint_claims_r2_sampled_scripted_result

Quint claims model: 14 deterministic tests and scripted mutants reported; evidence is sampled

The Opus report describes 14/14 tests, sampled runs and scripted mutants, and expressly limits this to a design model under assumptions, not proof, exhaustive checking, cryptography or Rust/Aiken/Groth16/ledger correspondence.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/cardano-claims-quint-model-r2-20261015/REPORT.md` / `line:16` / SHA-256 `57b5738b06751e063c85a599a98dac2fe9db25aabe81e94adb89ff9617c365ee`.

```json
{
  "reported_tests": "14/14",
  "sampled": "yes",
  "scripted_mutants": "3",
  "correspondence": "not established",
  "native_authority": 0,
  "attribution_role": "claim as stated in the cited report; no new Luna conclusion or certification"
}
```

## luna_v9_quint_claims_r2_review_narrowing

Independent review confirms recorded commands but requires source and result interpretation repairs

The Opus review says the r2 source is not adoptable as-is; recorded 26-command results are confirmed with interpretation narrowed, and acceptance remains none.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/quint-claims-independent-source-result-review-20261015/REPORT.md` / `line:14` / SHA-256 `e779bb37d5178da5b3c479ec003bf13998ae072152aa1d840952784d495d3dcb`.

```json
{
  "source_verdict": "NOT ADOPTABLE AS-IS: REPAIR REQUIRED",
  "results": "CONFIRMED AS RECORDED, WITH INTERPRETATION NARROWED",
  "acceptance": "none",
  "attribution_role": "claim as stated in the cited report; no new Luna conclusion or certification"
}
```

## luna_v9_quint_r3_source_only_successor

Quint r3 addresses review D1-D9 in source; it is unexecuted and unaccepted

The Opus successor report describes r3 changes to D1-D9 as authored and statically checked, while stating that the r3 Quint sources were never typechecked or run, predictions remain unexecuted, and acceptance is none. The report preserves the 26/40 r2 command count and leaves 14; proposed commands require separate authority.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/quint-claims-review-repair-source-20261015/REPORT.md` / `line:9` / SHA-256 `1184821df14631fbbb84ef02ea01df097b80bab4b06fdb584cdfcbe1d4bff156`.

```json
{
  "status": "source-only",
  "r3_typechecked": false,
  "r2_command_count_preserved": "26 of 40; 14 remaining",
  "acceptance": "none",
  "attribution_role": "claim as stated in the cited report; no new Luna conclusion or certification",
  "r3_execution": "none",
  "predictions": "frozen before r3 source; REV/AUTH/ORC attribution preserved",
  "proposed_quint_commands": "8, ordinals 27-34; never executed"
}
```

## luna_v9_pr54_codec_unit_adopted_scoped

PR54 staged-body codec: scoped captured-local UNIT result adopted; strict m3 minimum missed

The Opus review adopts scoped captured-local UNIT reference results for the exact pinned 210-file tree: Run C 93/93, M0 compile-red, and ten mutants as frozen. PROP2-m3 remains EXPECTED_RED_NOT_OBSERVED because its named test stayed green while 16 other W-derived tests failed; the strict minimum did not pass. The reviewer records a first vote to close by adjudication, with a second agreeing substantive vote still required. Authentication is none and consumption untracked.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/pr54-staged-body-codec-independent-source-result-review-20261015/REPORT.md` / `line:39` / SHA-256 `814fa12d32d000676b85c036328e970ee023f6f0e079444e35436f9e5a7c910b`.

```json
{
  "scope": "captured-local UNIT reference only; pinned 210-file tree",
  "tests": "93/93",
  "strict_batch": "COMPLETED_WITH_DEVIATIONS",
  "PROP2_m3": "EXPECTED_RED_NOT_OBSERVED; 16 other W-derived tests red",
  "second_vote_required": true,
  "authentication": "none",
  "consumption": "untracked",
  "attribution_role": "claim as stated in the cited report; no new Luna conclusion or certification",
  "M0": "COMPILE_RED_AS_EXPECTED",
  "mutants_expected_red": "10 of 11",
  "strict_minimum": "not passed and never to be relabelled ALL_AS_EXPECTED",
  "adjudication": "first vote only; second substantive agreeing vote required"
}
```

## luna_v9_pr54_combined_candidate_unexecuted

Combined codec integration is a byte integration snapshot, unreviewed and untested as a whole

The integration record identifies merge head ba12e473 and states that the combined candidate is unreviewed, untested and uncommitted; its captured 93 tests belong to the origin 210-file tree only.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/pr54-codec-combined-integration-20261015/RESULT.json` / `line:1` / SHA-256 `f1caef7228b1de869c0fe55e4c2ae3266b807cdaa30c855334ca2101c9b23acc`.

```json
{
  "merge_head": "ba12e4731b0d28dcdf87dc7f11c852511abbab64",
  "combined_candidate": "unreviewed/unverified/uncommitted",
  "93_test_scope": "origin 210-file tree only",
  "authentication": "none",
  "consumption": "untracked"
}
```

## luna_v9_abi_v1_source_review_scoped

ABI v1 source review scopes only a future bounded UNIT path and identifies open gaps

The Opus review separates source eligibility for bounded future UNIT phases from unperformed execution and target claims. It says phase K/persisted PK and Preprod require changes, phase R request was initially defective, and no compile, test, proof, setup, key, ledger or product acceptance is established. Its profile describes hand-written fixed Moriarty/1, not current generic compiler or current Core 6c7.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/claim-utxo-abi-v1-independent-source-review-r2-20261015/REPORT.md` / `line:24` / SHA-256 `f3ae85563c4e7ea6ce1860fe871b5e7bed340f2aa6630f02fcebf2ffc268fa5d`.

```json
{
  "scope": "future bounded UNIT only; no compile/runtime/target acceptance",
  "product_admission": false,
  "public_permission_change": false,
  "acceptance": "none",
  "attribution_role": "claim as stated in the cited report; no new Luna conclusion or certification",
  "profile": "hand-written fixed relation; not current generic compiler or current Core 6c7"
}
```

## luna_v9_abi_v1_r3_failed_e0277

ABI v1 R3 execution stopped on two E0277 compiler errors; later gates were skipped

The execution report says rustc rejected the candidate at two E0277 sites; R4, R5, R6, R6r and G1 were skipped, R7 post-check passed, and no retry or repair was attempted in that run.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/claim-utxo-abi-v1-rg-execution-20261015/REPORT.md` / `line:3` / SHA-256 `666633f24183fd34b2370ad2008faca885ef1bd3ec61a9d60cee25836a7fd8c3`.

```json
{
  "R3": "failed",
  "compiler_errors": "2 x E0277",
  "later_gates_skipped": [
    "R4",
    "R5",
    "R6",
    "R6r",
    "G1"
  ],
  "retry": "none",
  "attribution_role": "claim as stated in the cited report; no new Luna conclusion or certification"
}
```

## luna_v9_abi_v1_json_repair_source_only

ABI v1 JSON repair and request successor are source-only; no runtime or compile result

The Opus result review separates the frozen R3 failure judgment from its later JSON-rendering source proposal. The helper renders an externally tagged Result shape, but it was not compiled or executed; borrow-check and lint remain unobserved. It says the combined persistence successor needs a new manifest, fresh independent full-candidate source review, a new task and root adoption before any new R attempt.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/claim-utxo-abi-v1-rg-failure-review-and-json-repair-20261015/REPORT.md` / `line:41` / SHA-256 `89b77affbf9e2a5ed72cd68aafb3e574a46b88742ec2102c42e67baace2e7fb3`.

```json
{
  "status": "source-only proposal",
  "runtime": "not run",
  "compile": "unverified",
  "attribution_role": "claim as stated in the cited report; no new Luna conclusion or certification",
  "base_hash": "aa24777fad358d5a002c42f8c648a7ab14d8eaee2894665ead027221b776f687",
  "proposed_main_sha256": "651b2428068cc86130721cf38b5034129232609d3cf579fdfaeef4bbc69229df",
  "prior_R3_failure": "preserved; no retry"
}
```

## luna_v9_abi_v1_minimal_candidate_source_only

ABI v1 minimal JSON candidate is source/integration metadata only

The root integration record says this is mechanical integration only; copied reports/receipts/requests remain historical and supply no authority for the successor. The one changed main.rs is a source proposal that has not fixed SK1-SK5 or SD1; fresh independent full-candidate source/effect review is required before runtime.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/claim-utxo-abi-v1-json-minimal-candidate-20261015/ROOT-INTEGRATION.json` / `line:1` / SHA-256 `ec73b6fb95783d77fef53fda1f2843f3200982311d1e5d1246fb0dfa1b73300b`.

```json
{
  "runtime": "not established",
  "execution": "none",
  "source_role": "mechanical integration only",
  "changed_file": "source/x7/src/main.rs",
  "fixes_SK1_SK5_SD1": false,
  "review_required": "fresh independent full-candidate/source/effect review"
}
```

## luna_v9_current_core_compiler_first_slice_unexecuted

Current-Core Groth16 compiler first slice is source-complete candidate, uncompiled and unreviewed

The source report labels the candidate SOURCE_COMPLETE_FIRST_SLICE_UNEXECUTED and says it was not built, type-checked, tested, proven, set up, keyed or run against a ledger.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/current-core-groth16-compiler-source-r2-20261015/REPORT.md` / `line:5` / SHA-256 `5a7def81031118c7f6ab555ba9e4e5917d2a2992d3b96cd9d5d34d472084a99f`.

```json
{
  "status": "unexecuted",
  "candidate": "unadopted/unreviewed/uncompiled",
  "profile": "current Core",
  "legacy_source_identity": false,
  "attribution_role": "claim as stated in the cited report; no new Luna conclusion or certification"
}
```

## luna_v9_current_core_compiler_review_amended

Independent compiler review amends source disposition and records strict semantics and premises

The Opus source-only review marks the source verdict AMEND: it finds the represented successful Core/1 lowering faithful by reading and reviewer-Python differential only, but identifies F-04/F-05 premises and a test/request blocker F-01. It says execution request is not eligible as submitted, /2 and ABI v1 remain unadopted or refused, and acceptance is none.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/current-core-groth16-compiler-independent-source-review-20261015/REPORT.md` / `line:19` / SHA-256 `a0d1725fc6ad473f3aa9b94409c7894961c536de9a852f8d2ec4b6ccbe69455f`.

```json
{
  "verdict": "AMEND",
  "scope": "source-only",
  "strict_semantics": "represented Core/1 transitions",
  "execution": "none",
  "attribution_role": "claim as stated in the cited report; no new Luna conclusion or certification",
  "candidate": "uncompiled; /2 admitted then refused with plan; ABI v1 unadopted/refused",
  "execution_request": "NOT ELIGIBLE AS SUBMITTED due F-01/F-06/F-07",
  "acceptance": "none"
}
```

## luna_v9_current_core_compiler_repair_source_only

Compiler repair report retains explicit stale harness identity and no execution claim

The Opus repair report says F-01/F-11/F-12 and documentation changes are made at source level and static checks report 12/12 on the final pass, but the successor is unadopted, uncompiled, untested and unreviewed. A fresh exact full-candidate/delta audit is required before any command; the review harness still has stale build identity 2c943b51 while the successor build manifest is 4e3ba2e2.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/current-core-groth16-compiler-review-repair-source-20261015/REPORT.md` / `line:5` / SHA-256 `a932a35f001347f8c9ccdbbf83bb410b01af263dc9e7637e76b9875864fb3c03`.

```json
{
  "status": "source-only",
  "static_checks": "12/12 final pass reported",
  "compile": "none",
  "stale_harness_identity": "disclosed",
  "attribution_role": "claim as stated in the cited report; no new Luna conclusion or certification",
  "new_build_manifest": "4e3ba2e2796b425598b9b2abc022c4d6782bf032044aa53e124af4946c543b47",
  "review_harness_build_identity": "stale 2c943b51; only reviewer may revise",
  "fresh_full_candidate_delta_audit_required": true
}
```

## luna_v9_abi_persistence_repair_source_only

ABI persistence repair proposes file-system and admission changes; candidate remains uncompiled and untested

The Opus report describes a source-only persistence repair: uncompiled, untested and not run. Its 46-test census and 46-pass result are predictions, not results. It proposes libc 0.2.190 as a direct dependency (locked already but newly built on x86_64) and admission schema v2 (proposed/unadopted); setup, proving, PK lifecycle, ledger and Preprod are not established.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/claim-utxo-abi-v1-persistence-repair-source-20261015/REPORT.md` / `line:3` / SHA-256 `6773e724fe28f564a509be1d5297b44f6acaa129e4fc54ccca926d93a8ce5d0b`.

```json
{
  "status": "source-only",
  "future_tests": "predictions only",
  "proposed_admission_schema": "v2; unadopted",
  "runtime": "none",
  "attribution_role": "claim as stated in the cited report; no new Luna conclusion or certification",
  "tests": "46 predicted; not run",
  "proposed_dependency": "libc 0.2.190; locked but build script newly runs if compiled",
  "unsafe_FFI": "new fsx.rs first compile predicted risk; unobserved",
  "acceptance": "none"
}
```

## luna_v9_9eff_uireq_023

UIREQ-023 9eff source version: native relation inventory

The 9eff source requirement block is versioned against the preserved ba12 block; the source delta says it changed and supplies full heading-block-through-next-heading/EOF digests. All clauses remain obligations; this semantic node records lineage, not implementation or acceptance.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/upstream-sherlock-9eff-20261015/source/openspec/changes/sherlock-universal-interpreter-design/specs/universal-interpreter/spec.md` / `line:161` / SHA-256 `e593ecbe48e902ee430fa7c9d14a681100e27f71df297c5161c5881e3fb6311b`.

```json
{
  "requirement_id": "UIREQ-023",
  "historical_requirement_node": "luna_v8_sherlock_uireq_023",
  "base_block_sha256": "392a431777f47c274b54383f4225884d1caaa8dad0d00193e9cd4a8b4edc8428",
  "new_block_sha256": "d5c1875464acd3a04cb161464ee11ef8c1a555b275f2f01db5095362a37cd492",
  "changed": true,
  "base_commit": "ba12e4731b0d28dcdf87dc7f11c852511abbab64",
  "head_commit": "9effcd8e6f786dbea9d735da8b5f11cbcce88169",
  "digest_scope": "Entire Requirement heading block through next Requirement heading or EOF, including all scenarios and trailing newlines",
  "new_scenarios": [
    "Fixed relation across programs",
    "Midnight stagenet end-to-end qualification"
  ],
  "new_requirement_digest_scope": "Entire Requirement heading block through next Requirement heading or EOF, including all scenarios and trailing newlines",
  "acceptance": "open; source inventory is not acceptance",
  "attribution_role": "claim as stated in the cited report; no new Luna conclusion or certification"
}
```

## luna_v9_9eff_uireq_026

UIREQ-026 9eff source version: required Clean correspondence stage

The 9eff source requirement block is versioned against the preserved ba12 block; the source delta says it changed and supplies full heading-block-through-next-heading/EOF digests. All clauses remain obligations; this semantic node records lineage, not implementation or acceptance.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/upstream-sherlock-9eff-20261015/source/openspec/changes/sherlock-universal-interpreter-design/specs/universal-interpreter/spec.md` / `line:186` / SHA-256 `e593ecbe48e902ee430fa7c9d14a681100e27f71df297c5161c5881e3fb6311b`.

```json
{
  "requirement_id": "UIREQ-026",
  "historical_requirement_node": "luna_v8_sherlock_uireq_026",
  "base_block_sha256": "c870125e8fe9ba3473663177771d3fdc12196e12b2c83034d0d663fbe891c9a8",
  "new_block_sha256": "c8596d255575014fdf602cf636884384ad14dc00c9715c9078eeb2e039b36778",
  "changed": true,
  "base_commit": "ba12e4731b0d28dcdf87dc7f11c852511abbab64",
  "head_commit": "9effcd8e6f786dbea9d735da8b5f11cbcce88169",
  "digest_scope": "Entire Requirement heading block through next Requirement heading or EOF, including all scenarios and trailing newlines",
  "new_scenarios": [
    "Recursive semantics and bounded step circuit",
    "Iterate reference models and handwritten circuits"
  ],
  "new_requirement_digest_scope": "Entire Requirement heading block through next Requirement heading or EOF, including all scenarios and trailing newlines",
  "acceptance": "open; source inventory is not acceptance",
  "attribution_role": "claim as stated in the cited report; no new Luna conclusion or certification"
}
```

## luna_v9_catalogue_falsifier_inputs_byte_verified

Catalogue falsifier inputs are byte-verified; no falsifier execution is represented

The root verification record reports hashes matching for listed frozen catalogue inputs and declares a mechanical input-byte verification scope; this is provenance evidence, not a run of the falsifier harness.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/cardano-catalogue-falsifier-root-input-verification-20261015/VERIFICATION.json` / `line:1` / SHA-256 `60081513deb90533a59f962dd37097a4409c3d1823081d7f0a72efe6f023f212`.

```json
{
  "declared_cases": 257,
  "controls": 25,
  "input_verification": "byte hashes matched",
  "execution": "not established"
}
```

## luna_v9_public_compile_permissionless_maintainer_admission_control

Public compile/prove/deploy remains permissionless; admission is maintainer resource control

The cited Opus report explicitly states that permissionless public compile/prove/deploy is unaffected and admission is a maintainer resource control. This records that report statement; it does not convert maintainer controls into product admission.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/current-core-k-correspondence-source-r2-20261015/REPORT.md` / `line:120` / SHA-256 `f92b630c1bab9865de38d8341e6abe97d00e8eca4852a64f5ea3e51ec8aa24c5`.

```json
{
  "product_boundary": "permissionless public compile/prove/deploy",
  "maintainer_admission": "resource control only",
  "attribution_role": "cited Opus report statement; no new Luna conclusion"
}
```

## luna_v9_9eff_requirement_block_delta_inventory

9eff UIREQ delta inventories 35 retained IDs, two changed blocks and 33 unchanged blocks

The frozen delta receipt lists 35 requirement IDs; it records UIREQ-023 and UIREQ-026 as changed and the other 33 as unchanged. Base and new block digests are preserved per row. Digest scope is the entire Requirement heading block through the next Requirement heading or EOF, including all scenarios and trailing newlines.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/upstream-sherlock-9eff-20261015/UIREQ-REQUIREMENT-BLOCK-DELTA.json` / `/rows[0..34]` / SHA-256 `23a217ec4a2e9cc082b96005c6c47257b7b6ac0e8431592ac342e48dac6f4fbc`.

```json
{
  "requirement_count": 35,
  "changed_ids": [
    "UIREQ-023",
    "UIREQ-026"
  ],
  "unchanged_count": 33,
  "requirements": [
    {
      "id": "UIREQ-001",
      "base_block_sha256": "81ea48dcded3f2bc0930fe4756bf52d052747e8bbd8e0a18bd8e043b28356413",
      "new_block_sha256": "81ea48dcded3f2bc0930fe4756bf52d052747e8bbd8e0a18bd8e043b28356413",
      "changed": false
    },
    {
      "id": "UIREQ-002",
      "base_block_sha256": "01ef2451f650b415912594be8c2820bc80fe2d5023084123b44acea3db55726a",
      "new_block_sha256": "01ef2451f650b415912594be8c2820bc80fe2d5023084123b44acea3db55726a",
      "changed": false
    },
    {
      "id": "UIREQ-003",
      "base_block_sha256": "583455720050c89b7a3daf48a5e081b9a4d4b579fef2ee8f44e3083b93dee762",
      "new_block_sha256": "583455720050c89b7a3daf48a5e081b9a4d4b579fef2ee8f44e3083b93dee762",
      "changed": false
    },
    {
      "id": "UIREQ-004",
      "base_block_sha256": "a14480657a30a3558c0cdbb473d75ce146f66538dcd36557d3ea3437dc9e82a5",
      "new_block_sha256": "a14480657a30a3558c0cdbb473d75ce146f66538dcd36557d3ea3437dc9e82a5",
      "changed": false
    },
    {
      "id": "UIREQ-005",
      "base_block_sha256": "1bb5e3c089087dba1d1d6a10415ccd941406e25b964bf540a11209a7f56b4f79",
      "new_block_sha256": "1bb5e3c089087dba1d1d6a10415ccd941406e25b964bf540a11209a7f56b4f79",
      "changed": false
    },
    {
      "id": "UIREQ-006",
      "base_block_sha256": "1706f9ed9008f0b4f1eaf2331010ce61e853ce948ed009b14bfba1613a33f5f5",
      "new_block_sha256": "1706f9ed9008f0b4f1eaf2331010ce61e853ce948ed009b14bfba1613a33f5f5",
      "changed": false
    },
    {
      "id": "UIREQ-007",
      "base_block_sha256": "d95f1b448b6d3cc988782f2205871235212baa7c92e1b3f0afa367d2300c41f8",
      "new_block_sha256": "d95f1b448b6d3cc988782f2205871235212baa7c92e1b3f0afa367d2300c41f8",
      "changed": false
    },
    {
      "id": "UIREQ-008",
      "base_block_sha256": "e6b6a10904937cd18fbb262a1bb5a0881ef8eb2ca033844d939e5c5823a5a96c",
      "new_block_sha256": "e6b6a10904937cd18fbb262a1bb5a0881ef8eb2ca033844d939e5c5823a5a96c",
      "changed": false
    },
    {
      "id": "UIREQ-009",
      "base_block_sha256": "fc90db569fea721a4206d673e6565023066d8bc207dc88c5c785ce607c5db1e6",
      "new_block_sha256": "fc90db569fea721a4206d673e6565023066d8bc207dc88c5c785ce607c5db1e6",
      "changed": false
    },
    {
      "id": "UIREQ-010",
      "base_block_sha256": "004eab238f2eeb29258e4eccff7d2980903f94bac9e2c5d27515a1e1b0afab84",
      "new_block_sha256": "004eab238f2eeb29258e4eccff7d2980903f94bac9e2c5d27515a1e1b0afab84",
      "changed": false
    },
    {
      "id": "UIREQ-011",
      "base_block_sha256": "972a316bcd19df39c246705ca3def8442093901dfc02cca275cabd8d19fc0027",
      "new_block_sha256": "972a316bcd19df39c246705ca3def8442093901dfc02cca275cabd8d19fc0027",
      "changed": false
    },
    {
      "id": "UIREQ-012",
      "base_block_sha256": "0c36debc805b1b95df943152c40839a22cd8ac5d89a71d83cfb8b594aad5d870",
      "new_block_sha256": "0c36debc805b1b95df943152c40839a22cd8ac5d89a71d83cfb8b594aad5d870",
      "changed": false
    },
    {
      "id": "UIREQ-013",
      "base_block_sha256": "f6fdf99a86fab0ba37373e7fa29ca0d047eaad6e07d7c9cbfabc1f49b6ab6fc2",
      "new_block_sha256": "f6fdf99a86fab0ba37373e7fa29ca0d047eaad6e07d7c9cbfabc1f49b6ab6fc2",
      "changed": false
    },
    {
      "id": "UIREQ-014",
      "base_block_sha256": "63fc75392afe9ba383ea501dd613678c82dc5dde5c34445a294faca6b41eb2db",
      "new_block_sha256": "63fc75392afe9ba383ea501dd613678c82dc5dde5c34445a294faca6b41eb2db",
      "changed": false
    },
    {
      "id": "UIREQ-015",
      "base_block_sha256": "38e138918bebcfbf94c64de17a60c25d6477f805933c8bcc489902ba210960c7",
      "new_block_sha256": "38e138918bebcfbf94c64de17a60c25d6477f805933c8bcc489902ba210960c7",
      "changed": false
    },
    {
      "id": "UIREQ-016",
      "base_block_sha256": "8d5141d1426fcdb50ce5f0b806a91dbec2658c5b893384f27ae7409547370200",
      "new_block_sha256": "8d5141d1426fcdb50ce5f0b806a91dbec2658c5b893384f27ae7409547370200",
      "changed": false
    },
    {
      "id": "UIREQ-017",
      "base_block_sha256": "5204cb4f5b25080b8eae63c4ec2496a80002ce1b8a1f7d0780899c77caaf4a87",
      "new_block_sha256": "5204cb4f5b25080b8eae63c4ec2496a80002ce1b8a1f7d0780899c77caaf4a87",
      "changed": false
    },
    {
      "id": "UIREQ-018",
      "base_block_sha256": "88e9e30ee3adbf89ddba1e7a0e227c19975c85a0ebe997c2f4e2a9573afd73b2",
      "new_block_sha256": "88e9e30ee3adbf89ddba1e7a0e227c19975c85a0ebe997c2f4e2a9573afd73b2",
      "changed": false
    },
    {
      "id": "UIREQ-019",
      "base_block_sha256": "2d5893a62de800ba9364815dfc2527919884591ef8a824a05cd51bd9a5b1ec1f",
      "new_block_sha256": "2d5893a62de800ba9364815dfc2527919884591ef8a824a05cd51bd9a5b1ec1f",
      "changed": false
    },
    {
      "id": "UIREQ-020",
      "base_block_sha256": "07b04c4683b4f8e2df88a66a582eb1a020e63b2ef6db553764bd2707dfb96f73",
      "new_block_sha256": "07b04c4683b4f8e2df88a66a582eb1a020e63b2ef6db553764bd2707dfb96f73",
      "changed": false
    },
    {
      "id": "UIREQ-021",
      "base_block_sha256": "547dc499c5a315667354177184d716ac40dc58491a95f559b69aa3338c3fab6f",
      "new_block_sha256": "547dc499c5a315667354177184d716ac40dc58491a95f559b69aa3338c3fab6f",
      "changed": false
    },
    {
      "id": "UIREQ-022",
      "base_block_sha256": "e8029a82956ae9d6692bafb2a223e2fcb4db15a0413acacc43a4d51567b434e3",
      "new_block_sha256": "e8029a82956ae9d6692bafb2a223e2fcb4db15a0413acacc43a4d51567b434e3",
      "changed": false
    },
    {
      "id": "UIREQ-023",
      "base_block_sha256": "392a431777f47c274b54383f4225884d1caaa8dad0d00193e9cd4a8b4edc8428",
      "new_block_sha256": "d5c1875464acd3a04cb161464ee11ef8c1a555b275f2f01db5095362a37cd492",
      "changed": true
    },
    {
      "id": "UIREQ-024",
      "base_block_sha256": "b9793029c76ff62984452782ed19bc1bc59b3a8f8b1201b01aa62aa7f735bd7d",
      "new_block_sha256": "b9793029c76ff62984452782ed19bc1bc59b3a8f8b1201b01aa62aa7f735bd7d",
      "changed": false
    },
    {
      "id": "UIREQ-025",
      "base_block_sha256": "cca95c39c62bc07107653955c8825bc36f47bcdcce6583392b995d3e27012882",
      "new_block_sha256": "cca95c39c62bc07107653955c8825bc36f47bcdcce6583392b995d3e27012882",
      "changed": false
    },
    {
      "id": "UIREQ-026",
      "base_block_sha256": "c870125e8fe9ba3473663177771d3fdc12196e12b2c83034d0d663fbe891c9a8",
      "new_block_sha256": "c8596d255575014fdf602cf636884384ad14dc00c9715c9078eeb2e039b36778",
      "changed": true
    },
    {
      "id": "UIREQ-027",
      "base_block_sha256": "5000a0ef55d779a16f728ac10086730f9b6b5b11d0eadb74399215a800510376",
      "new_block_sha256": "5000a0ef55d779a16f728ac10086730f9b6b5b11d0eadb74399215a800510376",
      "changed": false
    },
    {
      "id": "UIREQ-028",
      "base_block_sha256": "a69124a912dcbf9bc5c0121dc3fb44bec1d389a81fdbc35dbc129064b91e2186",
      "new_block_sha256": "a69124a912dcbf9bc5c0121dc3fb44bec1d389a81fdbc35dbc129064b91e2186",
      "changed": false
    },
    {
      "id": "UIREQ-029",
      "base_block_sha256": "09972264087747a9299ef08000c6e80976a208500212fe759a13345a2157111f",
      "new_block_sha256": "09972264087747a9299ef08000c6e80976a208500212fe759a13345a2157111f",
      "changed": false
    },
    {
      "id": "UIREQ-030",
      "base_block_sha256": "ed95f8b1ba6e2f0e7edb39ce9b3c45c279619c36fb492af909d64965f9b4e1cc",
      "new_block_sha256": "ed95f8b1ba6e2f0e7edb39ce9b3c45c279619c36fb492af909d64965f9b4e1cc",
      "changed": false
    },
    {
      "id": "UIREQ-031",
      "base_block_sha256": "deeae3f04ca308eef0bc8b52d50d9a3da21fe4c36ba6987dcfc6b75899f30c02",
      "new_block_sha256": "deeae3f04ca308eef0bc8b52d50d9a3da21fe4c36ba6987dcfc6b75899f30c02",
      "changed": false
    },
    {
      "id": "UIREQ-032",
      "base_block_sha256": "abdcccc5cc255e0b5755a092461ba6dff8b6986bba09d853a87270df64ece3fb",
      "new_block_sha256": "abdcccc5cc255e0b5755a092461ba6dff8b6986bba09d853a87270df64ece3fb",
      "changed": false
    },
    {
      "id": "UIREQ-033",
      "base_block_sha256": "d9345747dead851f55f159a46055caeed77a97f0245a4d65a950bd3230266411",
      "new_block_sha256": "d9345747dead851f55f159a46055caeed77a97f0245a4d65a950bd3230266411",
      "changed": false
    },
    {
      "id": "UIREQ-034",
      "base_block_sha256": "b5659f2f011120a51e03fd6c6b309a48a5af03126493f054d9895e9f2c24b998",
      "new_block_sha256": "b5659f2f011120a51e03fd6c6b309a48a5af03126493f054d9895e9f2c24b998",
      "changed": false
    },
    {
      "id": "UIREQ-035",
      "base_block_sha256": "df589798980d21cb5490db8a694a9bb644ee9daf2900be17f2b3d2e840f226e1",
      "new_block_sha256": "df589798980d21cb5490db8a694a9bb644ee9daf2900be17f2b3d2e840f226e1",
      "changed": false
    }
  ],
  "digest_scope": "Entire Requirement heading block through next Requirement heading or EOF, including all scenarios and trailing newlines",
  "base_commit": "ba12e4731b0d28dcdf87dc7f11c852511abbab64",
  "head_commit": "9effcd8e6f786dbea9d735da8b5f11cbcce88169",
  "attribution_role": "mechanical fields extracted from frozen source delta receipt; not acceptance"
}
```

## luna_v9_quint_r3_change_details_unexecuted

Quint r3 discloses payer/premise profile switches, witness corrections and request proposals; all predictions remain unexecuted

The Opus report says r3 preserves v1 behavior with PAYER_AUTH and PREMISES_CHECKED false, adds predicted witnesses, reclassifies prior sample labels, and proposes future Quint/Rust commands. The report explicitly labels these as source/static predictions, not executed results.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/quint-claims-review-repair-source-20261015/REPORT.md` / `lines:64-100;110-140;152-183` / SHA-256 `1184821df14631fbbb84ef02ea01df097b80bab4b06fdb584cdfcbe1d4bff156`.

```json
{
  "attribution_role": "claim as stated in cited report/receipt; no new Luna judgment or certification",
  "PAYER_AUTH": "false in every v1 instance; hypothetical profile only",
  "PREMISES_CHECKED": "false in every v1 instance; hypothetical profile only",
  "r3_predictions": "REV/AUTH/ORC sources retained; unexecuted",
  "adapter": "updated, not executed; no fixture regenerated",
  "future_commands": "8 Quint + 2 Rust proposed; no authority inferred"
}
```

## luna_v9_quint_r3_replay_request_questions_open

R3 replay request has unresolved inventory and resource questions; no request approval is recorded

The root question addendum asks for review of the request’s whole-tree-copy scope and 8 GiB versus earlier 4 GiB memory limit; it says neither request is approved and grants no runtime scope.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/quint-r3-root-review-questions-20261015/QUESTIONS-ADDENDUM-1.json` / `/questions[0..1]` / SHA-256 `5a84bf858fb766352b493d17b68a9940a39358b87ece25352ec28d92398cee61`.

```json
{
  "attribution_role": "claim as stated in cited report/receipt; no new Luna judgment or certification",
  "questions": [
    "Q2-materialization",
    "Q3-resource"
  ],
  "request_approved": false,
  "runtime_scope_granted": false,
  "chronology": "dated 2026-10-15T13:32:31Z"
}
```

## luna_v9_quint_r3_filtered_test_count_discrepancy_open

R3 expects 89 filtered tests while captured codec baseline ran 93; count reconciliation was routed without execution

The frozen root question records an unresolved discrepancy between the R3 request’s static 89 filtered-test count and the captured codec baseline’s 93 tests, and requests reconciliation against frozen source/commands without rewriting history or running merely to discover the count.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/quint-r3-root-review-questions-20261015/QUESTIONS.json` / `/question` / SHA-256 `4f2cb6eed55410ec7b216c4bda70839a6808fee5aeb794b1892e1365a2a2de03`.

```json
{
  "attribution_role": "claim as stated in cited report/receipt; no new Luna judgment or certification",
  "expected_filtered_count": 89,
  "captured_codec_C_tests": 93,
  "status": "question; no predicted outcome adjudicated",
  "new_execution_authorized": false,
  "chronology": "dated 2026-10-15T13:23:05Z"
}
```

## luna_v9_generic_compiler_review_r1_only_static_and_uncompiled

Generic current-Core compiler review is source-only; candidate predicate, hostile vectors and API checks were not executed

The Opus review states that all source findings are from reading and reviewer-Python work, not Core execution; it recommends a corrected request after F-01/F-06/F-07 and records no acceptance. The 61 held-out vectors and hostile proposals are frozen/review artifacts, not run evidence.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/current-core-groth16-compiler-independent-source-review-20261015/REPORT.md` / `lines:15;23-27;46-80;178-194;388-394` / SHA-256 `a0d1725fc6ad473f3aa9b94409c7894961c536de9a852f8d2ec4b6ccbe69455f`.

```json
{
  "attribution_role": "claim as stated in cited report/receipt; no new Luna judgment or certification",
  "source_verdict": "AMEND",
  "execution": "none",
  "heldout_vectors": "61 vectors, 9 static refusals and 26 hostile proposals reported frozen; not executed",
  "reviewer_oracle": "source reading only, not Core",
  "acceptance": "none",
  "native_authority": 0
}
```

## luna_v9_current_core_compiler_p3_7_external_only_vote

Compiler review records an external-account-only P3-7 vote; later source repair says the vote does not resolve the all-account dispute

The Opus compiler review records AGREE on P3-7 as debit authority per external account with gross debit > 0.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/current-core-groth16-compiler-independent-source-review-20261015/REPORT.md` / `line:296` / SHA-256 `a0d1725fc6ad473f3aa9b94409c7894961c536de9a852f8d2ec4b6ccbe69455f`.

```json
{
  "attribution_role": "claim as stated in cited report/receipt; no new Luna judgment or certification",
  "review_vote": "AGREE",
  "wording_scope": "external account with gross debit > 0",
  "status": "review vote; not runtime evidence",
  "review_identity": "claude-opus-5-5; context-level independence only"
}
```

## luna_v9_abi_v1_p3_7_all_debited_accounts_vote

ABI v1 review requires debit authority for every debited account, including custody-held balances, plus thread-advance authority and signed intent

The Opus ABI review records CHANGE/dissent on the narrower P3-7 wording and states that authority must cover each debited Moriarty account including custody-held balances; it also requires thread-advance authority and signed intent in the statement before payment-settled wording.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/claim-utxo-abi-v1-independent-source-review-r2-20261015/REPORT.md` / `line:240` / SHA-256 `f3ae85563c4e7ea6ce1860fe871b5e7bed340f2aa6630f02fcebf2ffc268fa5d`.

```json
{
  "attribution_role": "claim as stated in cited report/receipt; no new Luna judgment or certification",
  "review_vote": "DISSENT AS WORDED; CHANGE",
  "wording_scope": "all debited accounts, including custody-held balances; thread-advance authority; signed intent",
  "status": "architecture/source review position; not implementation or runtime evidence",
  "review_identity": "claude-opus-5-5; context-level independence only"
}
```

## luna_v9_compiler_repair_preserves_p3_7_dissent

Compiler repair report explicitly preserves the P3-7 disagreement and makes no P3 vote

The Opus repair report says there is no P3 vote; it preserves V6 P3-7 CHANGE and states that the compiler review’s older external-account AGREE does not overrule it, with the review windows overlapping. Reconciliation is deferred to the source owner.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/current-core-groth16-compiler-review-repair-source-20261015/REPORT.md` / `line:104` / SHA-256 `a932a35f001347f8c9ccdbbf83bb410b01af263dc9e7637e76b9875864fb3c03`.

```json
{
  "attribution_role": "claim as stated in cited report/receipt; no new Luna judgment or certification",
  "P3_vote": "none",
  "preservation": "P3-7 positions retained; no override",
  "reported_review_windows": "V6 12:19-13:01Z; compiler review 12:46-13:21Z; overlap reported",
  "decision": "deferred to source owner; not settled here"
}
```

## luna_v9_abi_persistence_thread_authority_proposals_unimplemented

Persistence repair records one-vote TA-1/TA-2 thread-authority proposals; physical and signed-intent integration stays open

The Opus source report records TA-1 and TA-2 as one-vote proposals, not implemented mechanisms; it preserves dissent and says physical and signed-intent integration remains open.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/claim-utxo-abi-v1-persistence-repair-source-20261015/REPORT.md` / `lines:98-105` / SHA-256 `6773e724fe28f564a509be1d5297b44f6acaa129e4fc54ccca926d93a8ce5d0b`.

```json
{
  "attribution_role": "claim as stated in cited report/receipt; no new Luna judgment or certification",
  "TA1": "one vote; proposal only; not implemented",
  "TA2": "one vote; proposal only; insufficient; not implemented",
  "P3": "no repair-author vote; disagreement preserved",
  "acceptance": "none"
}
```

## luna_v9_abi_persistence_predicted_tests_not_results

Persistence repair’s 46-test and runtime claims are predictions only

The Opus report says the proposed 46 passing tests and helper behavior are same-author predictions; nothing was compiled or executed, and lexical checks cannot detect type/trait errors.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v9-input-staging-20261015/sources/claim-utxo-abi-v1-persistence-repair-source-20261015/REPORT.md` / `lines:88-96;138-141` / SHA-256 `6773e724fe28f564a509be1d5297b44f6acaa129e4fc54ccca926d93a8ce5d0b`.

```json
{
  "attribution_role": "claim as stated in cited report/receipt; no new Luna judgment or certification",
  "tests": "46 predicted; not executed",
  "CLI_and_helpers": "source only",
  "unsafe_FFI": "first compilation risk unobserved",
  "independence": "author/reviewer/repair same model family"
}
```

## luna_v10_current_core_pathb_actual_e0_e5

Current-Core R1CS Path B run reports all E0r2 through E5-r2 steps exited zero on exact copied trees

The operator report states all listed steps ran once, exited 0, with no retries or changed limits/source/oracle. It limits the observation to local current-Core/R1CS constraint-level evidence for exact copied trees; no proof, key, verifier, ledger, ZKIRv3, Midnight, Cardano or security result.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v10-input-staging-20261015/sources/current-core-groth16-env-corrected-offline-execution-20261015/REPORT.md` / `lines:1-5;69-92` / SHA-256 `18afb040ff7b961543f5b8dc478faa42044a4e4129f4f6dfed58349d1ac84cc1`.

```json
{
  "attribution_role": "claim as stated in cited frozen source; no new Luna judgment or certification",
  "status": "actual local run; all listed steps exit 0",
  "profile": "moriarty/1 + current Core closure f47318a2; x86_64 debug; DirectFieldV0",
  "attempts": "one; no retries",
  "e4_tests": "41 author/oracle-reused tests pass; internal agreement only",
  "e5_tests": "6 reviewer-frozen harness tests pass",
  "acceptance": "none"
}
```

## luna_v10_current_core_result_review_accept_qualified_not_adopted

Independent actual-result review labels the captured local constraint evidence ACCEPT-QUALIFIED and adoption NOT ADOPTED

The Opus result review reports ACCEPT-QUALIFIED only for the captured local constraint evidence under represented-snapshot premises; it explicitly reports NOT ADOPTED and no coverage claim because R-01/R-04 remain mandatory. This is the source review’s verdict, not a Luna judgment.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v10-input-staging-20261015/sources/current-core-groth16-independent-result-review-20261015/REPORT.md` / `lines:1-18` / SHA-256 `06e316bcf575c9258c292c29c84712ab2be7ff21be735add8c236f0be47d6ece`.

```json
{
  "attribution_role": "claim as stated in cited frozen source; no new Luna judgment or certification",
  "verdict": "ACCEPT-QUALIFIED captured-local constraint evidence",
  "adoption": "NOT ADOPTED; no coverage claim",
  "acceptance": "none",
  "review_type": "read-only independent source+actual-result review; same model family/context independence only"
}
```

## luna_v10_current_core_e5_heldout_and_omissions

Result review distinguishes 27 relation refusals from 31 hostile rows and records frozen held-outs not executed

The reviewer reports 61 held-out vector IDs/121 lines; for hostile rows it classifies 27 as relation UNSAT, while four rows carry no relation evidence. It reports S-9, M-10, M-11, M-13 and HW-01…26-by-ID not executed; M-14 is SAT as the known F-04 balance-row-presence gap. These are attributed review observations and limits.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v10-input-staging-20261015/sources/current-core-groth16-independent-result-review-20261015/REPORT.md` / `lines:45-65;75-88;103-118` / SHA-256 `06e316bcf575c9258c292c29c84712ab2be7ff21be735add8c236f0be47d6ece`.

```json
{
  "attribution_role": "claim as stated in cited frozen source; no new Luna judgment or certification",
  "heldout_vectors": "61 IDs, 121 lines",
  "hostile_rows": "31 total; 27 relation UNSAT; 4 non-relation rows",
  "not_executed": "S-9; M-10/M-11/M-13; HW-01..26 by ID",
  "M14": "SAT; reported as known F-04 presence gap",
  "acceptance": "not security coverage"
}
```

## luna_v10_current_core_n04_parser_repair_and_overwritten_analysis

N-04 review records parser repair with raw logs unchanged and the first defective ANALYSIS output overwritten

The independent review says the first analyze.py parse missed inline test rows, was fixed without changing raw logs, and the corrected output agrees with its independent parse. It also records that the first defective ANALYSIS output was overwritten and the frozen RESULT parser retained the inline-line defect; the original defective analysis was not recovered.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v10-input-staging-20261015/sources/current-core-groth16-independent-result-review-20261015/REPORT.md` / `lines:65-69;91-97` / SHA-256 `06e316bcf575c9258c292c29c84712ab2be7ff21be735add8c236f0be47d6ece`.

```json
{
  "attribution_role": "claim as stated in cited frozen source; no new Luna judgment or certification",
  "first_parser": "missed inline first data row and identity line; fixed",
  "raw_logs": "unchanged",
  "first_defective_analysis": "overwritten, not preserved",
  "RESULT_parser": "same defect remains in frozen result record",
  "disposition": "record limitation; no result record rewritten"
}
```

## luna_v10_current_core_n05_prompt_prefix_reconstruction

N-05 prefix recovery receipt reconstructs a prior preparation prompt prefix by hash

The dated receipt reports a 7,363-byte reconstructed prompt prefix whose SHA-256 equals the immutable PREPARATION prompt hash, and expressly qualifies this as a new forensic reconstruction, not an original pre-runtime publication or fresh security review.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v10-input-staging-20261015/sources/current-core-groth16-root-provenance-followup-20261015/N05-PREFIX-RECOVERY.json` / `/currentPromptSha256;/preparationPromptSha256;/reconstructedPrefixSha256;/qualification` / SHA-256 `147ed628c80371401f30d92f4f9db387b9450d437a97cdf7dae41fa4f344da01`.

```json
{
  "attribution_role": "claim as stated in cited frozen source; no new Luna judgment or certification",
  "reconstructed_prefix_bytes": 7363,
  "prefix_hash_equals_preparation": true,
  "original_pre_runtime_publication": false,
  "N04_overwritten_analysis_recovered": false
}
```

## luna_v10_abi_combined_source_review_scoped_unit_eligible

Combined ABI v1 source review grants only scoped eligibility for a bounded UNIT and amended R/G proposal

The Opus source/effects review labels exact combined 76-row source ACCEPT_SCOPED_FOR_BOUNDED_UNIT and amended R/G eligible as a proposal; it says the literal V1R1 request was not eligible, A was not eligible from those bytes, and no compile success/result or product acceptance was established at that review time.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v10-input-staging-20261015/sources/claim-utxo-abi-v1-combined-independent-review-20261015/REPORT.md` / `lines:30-69;151-176` / SHA-256 `aaab91300f2af8d9ed503fe072de22dc0aea7c1e81f02d1c337918d893a024f1`.

```json
{
  "attribution_role": "claim as stated in cited frozen source; no new Luna judgment or certification",
  "source_verdict": "ACCEPT_SCOPED_FOR_BOUNDED_UNIT",
  "amended_RG": "eligible proposal only, root adoption required",
  "literal_V1R1": "not eligible",
  "A": "not eligible from those bytes",
  "compile_at_review_time": "not established",
  "product_acceptance": "none"
}
```

## luna_v10_abi_combined_rg_prior_permission_block

Earlier combined ABI R/G operator stopped before R1 at the tool-permission boundary; no runtime result was produced

The earlier operator report states it cast votes but did not start R1; the one-shot TASK remained absent and unconsumed, with first blocked boundary before R1 at the session permission layer. Its R/G outcomes remained predictions at that time.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v10-input-staging-20261015/sources/claim-utxo-abi-v1-combined-rg-execution-20261015/REPORT.md` / `lines:1-4;53-73` / SHA-256 `746fa241da863d8bd09bf3fac3da27e9f9b553f47aced11daff636a725207c7e`.

```json
{
  "attribution_role": "claim as stated in cited frozen source; no new Luna judgment or certification",
  "status": "stopped before R1; no candidate defect claimed",
  "TASK": "absent and unconsumed at that historical time",
  "result": "none; predictions only",
  "authority": "no native authority"
}
```

## luna_v10_abi_combined_rg_actual_11_steps_pass

Combined ABI v1 R-prime/G-prime execution reports all eleven steps exit zero and match frozen V8 expectations

The later operator report states it ran R1, R0, G1, R2, R2c, R3, R4, R5, R6, R6r and R7 once, each exit 0. It reports 46 passing UNIT tests, 25 ABI lines as expected, R6/R6r empty mismatch arrays and G byte identity. Scope is one fixed legacy ABI1 local UNIT under stable Rust/Cargo 1.98.1; independent result audit was pending.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v10-input-staging-20261015/sources/claim-utxo-abi-v1-combined-rg-execution-r2-20261015/REPORT.md` / `lines:1-8;48-80` / SHA-256 `fa0bef5710b587309c647d54ec202fcc8cbc4594aa953e5d0c31ef0af449478b`.

```json
{
  "attribution_role": "claim as stated in cited frozen source; no new Luna judgment or certification",
  "status": "actual local run; 11/11 exits zero",
  "unit_tests": "46 passed",
  "abi_rows": "25 as expected; Ok 307706 observed",
  "comparators": "author and reviewer mismatch arrays empty",
  "candidate": "combined ABI1 fixed legacy relation",
  "toolchain": "stable 1.98.1",
  "independent_result_audit": "pending in source report",
  "product_acceptance": "none"
}
```

## luna_v10_abi_rg_green_scope_and_open_gaps

ABI execution report keeps its green UNIT result separate from generic compiler, proof, Aiken, authority, ledger and acceptance

The execution report says the observed pass does not establish current generic compiler/P4, proof or PK/VK lifecycle, Aiken, wrapper, ledger/Preprod, thread or debit authority, signed intent, physical settlement, PCD/private/multiparent work, all 20 patterns or roadmap exits.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v10-input-staging-20261015/sources/claim-utxo-abi-v1-combined-rg-execution-r2-20261015/REPORT.md` / `lines:76-97` / SHA-256 `fa0bef5710b587309c647d54ec202fcc8cbc4594aa953e5d0c31ef0af449478b`.

```json
{
  "attribution_role": "claim as stated in cited frozen source; no new Luna judgment or certification",
  "generic_current_core": "not established",
  "proof_or_PK_VK": "not established",
  "Aiken_U_ledger_Preprod": "not run/established",
  "P3_authority_intent_physical_settlement": "open",
  "all20_and_U_M_MC_SP_G": "open",
  "acceptance": "not decided"
}
```

## luna_v10_aiken_c2_source_integration_only

C2 placement integration record identifies a new 99bf source manifest with exactly one helper row changed

The integration record labels the change mechanically integrated source-only with no review/runtime authority: parent manifest d08c…, new manifest 99bf…, exactly one changed row in `tools/aiken_place_v1r1.py`, all other 75 rows and all Rust/16 Aiken files byte-identical. A fresh source/effect/request review is required before A execution.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v10-input-staging-20261015/sources/claim-utxo-abi-v1-aiken-placement-integration-20261015/RESULT.json` / `/state;/parentManifestSha256;/newManifestSha256;/changedRows;/requiredBeforeAExecution` / SHA-256 `e42136effeda1ae81f4f6209f3042157047981a2e282af7aa8e48101d64ae431`.

```json
{
  "attribution_role": "claim as stated in cited frozen source; no new Luna judgment or certification",
  "state": "source-only; no review/runtime authority",
  "new_candidate_manifest": "99bf694fed3880f58c79bf7c58d57c5ac0bb2ce4402a28dd3c5d425d8a6d6296",
  "changed_rows": "one helper row",
  "all_other_rows": "75 byte-identical",
  "all_rust_and_16_aiken": "unchanged",
  "execution": "none"
}
```

## luna_v10_aiken_c2_a_only_request_proposal_unexecuted

A-only C2 corrected request is a proposal, with no A execution authority or result

The request describes proposal-only corrected Aiken placement commands and requires a fresh Opus full source/effect/request review before helper or binary execution. It explicitly states no A command is authorized by these bytes, no source UNIT/VM test/compiled blueprint result exists, and any green result would remain UNIT-only.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v10-input-staging-20261015/sources/claim-utxo-abi-v1-aiken-placement-integration-20261015/REQUEST-A-C2-PROPOSAL.md` / `lines:1-8;16-35;72-79` / SHA-256 `ed21dd72d1527d7eecda06a4e6292ed0e53b4bb03f14aaa16d3c6bab494d92dd`.

```json
{
  "attribution_role": "claim as stated in cited frozen source; no new Luna judgment or certification",
  "status": "proposal only",
  "fresh_review_before_execution": true,
  "A_execution_authorized_by_document": false,
  "A_result": "none",
  "scope_if_future_green": "UNIT-level Aiken only"
}
```

## luna_v10_k_a_quint_current_local_normal_results

K-A Quint README reports six exact normal traces plus 92 fuel-prefix cases, 98 deterministic tests

The project README reports current-local successful typechecking and 98 passing deterministic normal tests for six frozen programs and 92 fuel prefixes on the exact source. It says tests are literal oracle transcriptions and results are not exhaustive or randomized model checking. Broader grammar/fixtures/correspondence/security/native/stagenet remain open.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v10-input-staging-20261015/sources/upstream-sherlock-30b65-20261015/source/models/sherlock/quint/K-PROFILE-README.md` / `lines:1-34;121-158` / SHA-256 `e15fbed29d0129550933c85b52b94cf18d2e6a2e439f35554ac6b01fe4b5095e`.

```json
{
  "attribution_role": "claim as stated in cited frozen source; no new Luna judgment or certification",
  "profile": "sherlock-k-a/1",
  "cases": 6,
  "fuel_prefixes": 92,
  "tests": 98,
  "result": "reported pass; source-attributed",
  "exhaustive": "false",
  "security_or_cross_layer": "not established"
}
```

## luna_v10_k_a_opus_review_approves_finite_evidence

Opus review approves source/spec/quality/result evidence only within the finite K-A model scope

The Opus review reports APPROVE for SOURCE, SPEC, QUALITY and RESULT_EVIDENCE for the finite model source and supplied normal observations. It did not rerun Quint or recompute hashes. It explicitly excludes B profile, security properties, malformed admission, K runtime, cross-layer correspondence, constraints, native/stagenet and roadmap exits; F1-F6 limitations remain.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v10-input-staging-20261015/sources/upstream-sherlock-30b65-20261015/source/docs/audits/2026-10-15/sherlock-k-profile-quint/reviews/OPUS.md` / `lines:1-19;119-185` / SHA-256 `93b833e188c820d8cc7167959b75691fc144220783c79c263ced8e8444152a21`.

```json
{
  "attribution_role": "claim as stated in cited frozen source; no new Luna judgment or certification",
  "verdicts": "SOURCE/SPEC/QUALITY/RESULT_EVIDENCE approved",
  "review_method": "supplied source and supplied observations; no rerun or hash recomputation",
  "limitations": "F1-F6; no security, B, cross-layer, native, stagenet, roadmap claim",
  "independence": "fresh context only; same model family"
}
```

## luna_v10_k_a_muse_review_approves_finite_evidence

Muse review approves only the finite K-A model and 98 recorded normal observations

The Muse review reports SOURCE/SPEC/QUALITY/RESULT_EVIDENCE approval for the finite generic K-A model and its 98 recorded normal observations, and states that it is not an independent live-filesystem or test-execution attestation. Its listed limits include error/negative-path, malformed-domain, broad grammar, UInt128 exhaustion, security, correspondence, circuit, native and stagenet.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v10-input-staging-20261015/sources/upstream-sherlock-30b65-20261015/source/docs/audits/2026-10-15/sherlock-k-profile-quint/reviews/MUSE.md` / `lines:1-10;24-40` / SHA-256 `1da769aa0da29e075761f520bc90ceac167a9281429201e6c4a914f31383092c`.

```json
{
  "attribution_role": "claim as stated in cited frozen source; no new Luna judgment or certification",
  "verdicts": "SOURCE/SPEC/QUALITY/RESULT_EVIDENCE approved",
  "review_method": "supplied-source review; not live filesystem or execution attestation",
  "scope": "finite K-A model and 98 normal observations",
  "limitations": "security/negative/broad grammar/correspondence/circuit/native/stagenet open"
}
```

## luna_v10_sherlock_30b65_frozen_core_byte_comparison

30b65 comparison covers only the frozen 70-path Core closure: 69 byte-equal, one pubmod line changed

The byte-comparison JSON reports 69 of the 70 frozen Core paths byte-identical and `crates/mori-core/src/lib.rs` as the single changed row. It explicitly says new paths outside the frozen 70-path closure are not covered and no code was imported or executed.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v10-input-staging-20261015/sources/upstream-sherlock-30b65-20261015/COMPILER-INPUT-BYTE-COMPARISON.json` / `/scope;/files` / SHA-256 `3c65cdf7ddf9c579a573757c3e37967661a5be98ded3ed237c3735a651b4599b`.

```json
{
  "attribution_role": "claim as stated in cited frozen source; no new Luna judgment or certification",
  "frozen_closure": "70 paths",
  "byte_identical": 69,
  "changed": 1,
  "changed_path": "crates/mori-core/src/lib.rs",
  "new_paths_outside_closure": "unknown/not covered",
  "execution": "none"
}
```

## luna_v10_sherlock_30b65_review_index_limits

Sherlock review README binds a finite normal K-A result while preserving Opus/Muse limitations

The review README says the two completed reviews supersede historical pending status only for the pinned candidate; actual test receipts were separately captured by root. The approved result is six complete traces and 92 fuel prefixes with 98 GREEN tests. Opus F1-F6/Muse limitations remain, and no security, B-profile, schema, cross-layer, native, stagenet or roadmap exit is claimed.

Source: `/home/charl/moriarty-eutxo-validation-2026-10-12/luna-graph-v10-input-staging-20261015/sources/upstream-sherlock-30b65-20261015/source/docs/audits/2026-10-15/sherlock-k-profile-quint/reviews/README.md` / `lines:1-13` / SHA-256 `dcda5173cb29c6bc061d4b434fbeae4c7ccc665eb3d591929035a9f9d0c68648`.

```json
{
  "attribution_role": "claim as stated in cited frozen source; no new Luna judgment or certification",
  "reviews": "Opus and Muse supplied-source reviews",
  "result": "98 GREEN normal observations; 6 traces + 92 prefixes",
  "remaining": "F1-F6 and Muse limitations; no security/B/cross-layer/native/stagenet/roadmap"
}
```
