Use the installed interpreter from this owned output directory:

```bash
timeout --kill-after=5s 180s prlimit --cpu=120 --as=2147483648 -- /home/charl/.local/share/uv/tools/graphifyy/bin/python build_v10_integration.py
```

The builder verifies immutable V8 and exact Luna V9 r1/V10 inputs, byte-checks the 39/21 staged source packets, and writes only in this new V10 integration directory. The CPU and 2 GiB address-space limits also apply internally. Fixed-seed pure-Python NetworkX communities and installed Graphify 0.9.91 analysis/HTML avoid installation, network, model calls and native clustering. No project/native/test/key/proof/ledger command is used.

The JSON is an exact union of input nodes, links and hyperedges, with only node community fields changed. Analysis topology and aggregated HTML can collapse multiple link records on a node pair; the exact merge input and graph JSON retain all records and attributions. Requirement block checks use the full declared heading-to-next-heading/EOF scope.

MANIFEST-v10.json pins all output candidate files except itself and its detached checksum; MANIFEST-v10.sha256 pins that manifest. The receipts pin original source/control files separately. Re-running writes only this owned candidate directory and requires comparison of all resulting hashes before relying on an existing exact-byte audit.
