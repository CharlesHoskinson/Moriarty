# ADDED Requirements

### Requirement: Independent successor witness
A successor SHALL prove using only its permitted private inputs and the declared handoff package.

#### Scenario: Alice to Bob
- **WHEN** Bob receives only his permitted private inputs and the declared handoff artifacts
- **THEN** isolated processes and secret stores produce a valid successor proof without access to Alice secrets.

#### Scenario: Unavailable witness
- **WHEN** a required handoff artifact is missing
- **THEN** the successor reports unavailable and cannot fabricate evidence or disclose Alice secrets to force acceptance.

### Requirement: Bounded history composition
Split and join SHALL preserve obligations, authority limits, output uniqueness, and the original global lifecycle measure.

#### Scenario: Compatible composition
- **WHEN** two independently proved compatible branches undergo the declared split and join
- **THEN** their new proofs discharge dependencies and preserve obligations, residual authority, uniqueness, and global lifecycle bounds.

#### Scenario: Composition attack
- **WHEN** composition duplicates predecessors, reuses outputs, mixes incompatible policies, exceeds fan-in, or resets bounds
- **THEN** proof and acceptance gates reject the invalid composition.

### Requirement: Ledger and confidentiality boundaries
The evidence SHALL distinguish history compliance, ledger uniqueness, oracle truth, and confidentiality assumptions.

#### Scenario: Competing valid branches
- **WHEN** two otherwise valid branches conflict on ledger consumption
- **THEN** both may have valid proofs, but only permitted unique consumption settles.

#### Scenario: False privacy claim
- **WHEN** a demonstration relies on a public proof alone or shared access to both parties secret directories
- **THEN** the private-handoff evidence gate rejects the demonstration.

### Requirement: Independent audit and provenance
The package SHALL bind acceptance evidence to exact sources, commands, environment, outputs, and both required audit identities.

#### Scenario: Audited result
- **WHEN** deterministic checks pass and both independent reviewers have no unresolved blocking finding
- **THEN** the package records accepted scope with the exact reviewed candidate digest.

#### Scenario: Missing or stale audit
- **WHEN** Fable or GPT-6 is unavailable, substituted, stale, or lacks a substantive identity-bound verdict
- **THEN** the package remains pending audit and cannot promote dependent acceptance.

### Requirement: Failed predicate stops promotion
The package SHALL remain incomplete if any required positive or rejection predicate fails.

#### Scenario: Negative control incorrectly accepts
- **WHEN** a required invalid input is accepted or its rejection lacks evidence
- **THEN** verification fails and dependent acceptance remains blocked.
