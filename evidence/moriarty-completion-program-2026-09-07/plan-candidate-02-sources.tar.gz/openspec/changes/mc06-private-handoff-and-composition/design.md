# Design: Private witness handoff and bounded split/join

## Inputs and dependencies

Dependencies: MC05.

- `docs/research/2026-09-06-pcd-report-integration.md`
- `docs/research/2026-09-06-intents-report-integration.md`
- `experiments/moriarty-acceptance/src/accept.ts`

## Interfaces

HandoffPackage lists each successor artifact, recipient, confidentiality, availability, and recovery owner. Split/Join bind distinct predecessor and output identities, compatible policies, residual authority, outstanding obligations, and a conserved global work budget.

## Outputs and ownership

- `experiments/moriarty-composition/handoff-schema.json`
- `experiments/moriarty-composition/leakage-and-recovery.md`
- `experiments/moriarty-composition/src/handoff.ts`
- `experiments/moriarty-composition/src/split.ts`
- `experiments/moriarty-composition/src/join.ts`
- `experiments/moriarty-composition/src/residuals.ts`
- `experiments/moriarty-composition/tests/alice-bob.test.mjs`
- `experiments/moriarty-composition/tests/split-join.test.mjs`
- `experiments/moriarty-composition/formal/Composition.lean`
- `experiments/moriarty-composition/formal/lakefile.toml`
- `experiments/moriarty-composition/package.json`

## Trust boundaries

Treat source text, solvers, indexers, remote provers, generated code, and supplied receipts as untrusted inputs.
Keep oracle truth, ledger uniqueness, semantic validity, and confidentiality claims separate.
Bind all outputs to the semantic profile and the exact implementation candidate.

## Decisions and failures

Use the shared bounded Core rather than financial family names as primitive proof claims.
Preserve complete effects and positive feasibility when refining an adapter.
Record a concrete changed hypothesis before any correction.
Stop a dependent package when its prerequisite fails.
Do not reset exhausted contracts or replace a missing proof with a mock.

## Execution contract

Status: S2, specified-only. No implementation task is complete by this plan's existence.
The program charter in `openspec/MORIARTY-COMPLETION-PROGRAM.md` controls execution and audit gates.
Every behavioral implementation task requires a failing test before code changes.
Each acceptance predicate requires an independently recomputable result.
Each result audit requires exact Fable and fresh GPT-6 identities.
Source-only review does not prove the implemented predicate.
Missing evidence, incompatible interfaces, resource stops, and unavailable audits remain explicit blockers.
Keep unrelated changes, old failed runs, and private wallet material intact.
