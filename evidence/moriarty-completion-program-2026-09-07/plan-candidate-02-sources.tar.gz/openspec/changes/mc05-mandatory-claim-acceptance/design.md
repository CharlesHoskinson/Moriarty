# Design: Mandatory contract, intent, transition, and history claims

## Inputs and dependencies

Dependencies: MC03, MC04.

- `experiments/moriarty-developer-mock/src/language/claims.ts`
- `experiments/moriarty-developer-mock/src/language/policy.ts`
- `docs/research/2026-09-06-pcd-report-integration.md`
- `experiments/moriarty-ledger-adapter/correspondence-spec.md`

## Interfaces

ClaimSpec -> MandatoryManifest -> signed Intent -> BoundClaim -> ProofArtifact. VerifiedClaim records trusted verifier identity, domain, program/spec versions, dependencies, assumptions, and applicability. accept checks ContractInvariant, IntentRefinement, TransitionValidity, and HistoryCompliance.

## Outputs and ownership

- `experiments/moriarty-acceptance/claim-policy.json`
- `experiments/moriarty-acceptance/src/claim-codec.ts`
- `experiments/moriarty-acceptance/src/certificates.ts`
- `experiments/moriarty-acceptance/src/verify-intent.ts`
- `experiments/moriarty-acceptance/src/accept.ts`
- `experiments/moriarty-acceptance/formal/ContractProperties.lean`
- `experiments/moriarty-acceptance/formal/IntentRefinement.lean`
- `experiments/moriarty-acceptance/formal/lakefile.toml`
- `experiments/moriarty-acceptance/contracts/mandatory-claims.compact`
- `experiments/moriarty-acceptance/tests/acceptance.test.mjs`
- `experiments/moriarty-acceptance/package.json`

## Trust boundaries

Treat source text, solvers, indexers, remote provers, generated code, and supplied receipts as untrusted inputs.
Keep oracle truth, ledger uniqueness, semantic validity, and confidentiality claims separate.
Bind all outputs to the semantic profile and the exact implementation candidate.

## Decisions and failures

Use the shared bounded Core rather than financial family names as primitive proof claims.
Preserve complete effects and positive feasibility when refining an adapter.
Record a concrete changed hypothesis before any correction.
Stop a dependent package when its prerequisite fails.
Do not reset exhausted contracts or replace a missing proof with a mock.

## Execution contract

Status: S2, specified-only. No implementation task is complete by this plan's existence.
The program charter in `openspec/MORIARTY-COMPLETION-PROGRAM.md` controls execution and audit gates.
Every behavioral implementation task requires a failing test before code changes.
Each acceptance predicate requires an independently recomputable result.
Each result audit requires exact Fable and fresh GPT-6 identities.
Source-only review does not prove the implemented predicate.
Missing evidence, incompatible interfaces, resource stops, and unavailable audits remain explicit blockers.
Keep unrelated changes, old failed runs, and private wallet material intact.
