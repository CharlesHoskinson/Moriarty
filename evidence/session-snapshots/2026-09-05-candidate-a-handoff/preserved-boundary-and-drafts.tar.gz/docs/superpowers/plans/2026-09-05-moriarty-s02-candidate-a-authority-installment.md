# Candidate A installment authority lifecycle implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans task-by-task. Steps use checkbox (`- [ ]`) syntax.

**Goal:** execute actual Candidate A installment authority lifecycle paths under both signing profiles through the frozen A adapter and boundary.

**Architecture:** Create literal A fixtures, pure A-guarded lifecycle helpers, a finite no-stutter harness, and tests. Every expected `PlannedOperation` is independently literal: predecessor/program/state, `AgreementCallA`/`CancellationCallA`, projected input/time/core result/effects/facts. Never copy an adapter output to manufacture an expected plan.

**Tech Stack:** Quint 0.32.0 Rust backend; frozen common modules plus `candidate_a_authority_adapter` and `candidate_a_authority_boundary`.

## Global constraints

- Do not alter Core, common authorization/execution, adapter/boundary, B–D, or generic string installment fixtures.
- Use `canPrepareSigningAuthorityA`, `canSignAuthorityA`, `canVerifyAuthorityA`, `canCommitAuthorityA`, and existing common apply functions only after their guards.
- Plain shared-state Quint; no Choreo, Apalache, Foreman, or Council.
- Adapter plans may be literal but all execution plans must have 1–4 independently faithful operations.

### Task 1: literal A installment fixtures and RED evidence

**Files:** Create `specs/quint/s02/candidate_a_authority_installment_fixtures.qnt`, `candidate_a_authority_installment_test.qnt`.

**Interfaces:** Produce `initialInstallmentA(profile)`, `firstFillPlanA`, `cancelPlanA`, `secondFillPlanA`, `recoveryTenPlanA`, `recoveryFivePlanA`, `deadlineRefundPlanA`, `deadlineRollbackPlanA`, and `evidenceForInstallmentA`.

- [ ] Write compiling tests first for: N4/Alice escrow10/time2; `ChoiceLike(fill1,Bob,1)` gives N2/escrow5/effect escrow→Bob5; N2 `fill2` gives Close/escrow0/second effect5; cancellation carries unchanged A predecessor, NoInput, NoCoreProjection, empty effects; recovery input `ChoiceLike(recover,Alice,1)` yields refunds10 at N4 and5 at N2; Time100 NoInput yields timeout refunds; supplied recovery at Time100 is exact original-state CoreRejected rollback.
- [ ] Run the focused test and archive full source closure/output as behavioral RED against a compiling permissive fixture stub; type/import failures are not RED.
- [ ] Define literal `APredecessor`, `AAuthorityRequest`, `CoreProjected` records, effects, full `PolicyFacts`, and `PlannedOperation` records. Include all six accounts/five choices/full sixteen-node program, including unused nodes. Define parent nonce0 clauses for fill1/fill2/cancel and recovery nonce1 clauses separately; exact facts bind `ParentVacant`, live revision0, and cancelled parent revision/facts.
- [ ] Run focused test GREEN; assert adapter equality only against the independently literal records.

### Task 2: A-guarded lifecycle helpers and adversarial tests

**Files:** Create `specs/quint/s02/candidate_a_authority_installment.qnt`; modify only the new test/fixtures files above.

**Interfaces:** `canPrepareInstallmentA`, `canSignInstallmentA`, `canProposeInstallmentA`, `canVerifyInstallmentA`, `canCommitInstallmentA`, `apply…InstallmentA`, `installmentSafetyA`, `recoveryPreservesNonceZeroA`.

- [ ] RED then implement minimal wrappers: each uses frozen A boundary guard plus common transition. Propose requires actual `AuthorityAdaptedA`; verify/commit use its exact evidence/attempt. No wrapper changes ledger, candidate, parent, registry, or attempts except the corresponding common apply.
- [ ] Test both profiles through prepare/sign/propose/verify/commit for first fill then second fill; assert Bob10, escrow0, Close, nonce0 consumed revision1, no second commit.
- [ ] Test both initial race orders: signed fill/cancel share exact initial parent facts; winner commits and loser becomes stale/rejected with original evidence retained. After first fill, require a newly prepared/signed fresh cancellation against N2/live parent facts; cancellation changes parent authority only and does not transfer money.
- [ ] Test recovery after either cancellation state: newly sign nonce1; N4 refunds10 and N2 refunds5; nonce0 remains cancelled/unchanged and nonce1 alone becomes consumed revision1. Test Time100 NoInput refund and supplied deadline recovery rollback with actual CoreRejected classification, not an invented transfer.
- [ ] Add controls mutating full program unused node, input/call, successor, time, core projection, effects, parent facts, second plan operation, evidence attempt binding, nonce, and cancellation call; each fails A guard or reaches `UnauthorizedEffect` rejection as appropriate.

### Task 3: finite harness, verification, handoff

**Files:** Create `specs/quint/s02/candidate_a_authority_installment_harness.qnt`; modify new test only.

- [ ] Add cohesive `var state: AAuthorityExecution`, `var profile`, `var scenario`; guarded actions for prepare/sign/propose/verify/commit, fresh cancellation, recovery, and deadline environment selection. No stutter. Every action assigns all vars.
- [ ] Witnesses: first fill, second payment, cancellation-first, first-fill-then-cancel, recovery10, recovery5, timeout refund, and deadline rollback. Invariants: TokenA conservation; nonnegative valid ledger; parent `paid + remainingAllowance == 10`; cancelled parent has no remaining fill authority; nonce replay exclusion; cancellation/fill exclusion; recovery preserves nonce0 parent/registry.
- [ ] Archive RED/GREEN source hashes, Quint identity and raw receipts. Run:
```bash
quint typecheck specs/quint/s02/candidate_a_authority_installment_test.qnt
quint test specs/quint/s02/candidate_a_authority_installment_test.qnt --backend=rust --seed=42
quint typecheck specs/quint/s02/candidate_a_authority_installment_harness.qnt
quint run specs/quint/s02/candidate_a_authority_installment_harness.qnt --backend=rust --seed=42 --max-samples=100 --max-steps=20 --invariant=installmentSafetyA --witnesses firstFillWitnessA,secondFillWitnessA,cancelFirstWitnessA,freshCancelWitnessA,recoveryTenWitnessA,recoveryFiveWitnessA,timeoutWitnessA,deadlineRollbackWitnessA --verbosity=1
quint test specs/quint/s02/candidate_a_authority_adapter_test.qnt --backend=rust --seed=42
/home/charl/Moriarty/.venv/bin/python -m pytest -q
```
- [ ] Commit only the four new `.qnt` files after GREEN. Write `.superpowers/sdd/candidate-a-authority-installment-report.md` with exact hashes, commands/exits/raw receipts, RED/GREEN, witness counts, limitations, and independent review request.

## Review checklist

The unit excludes swap, exports, correspondence, B–D, selection, and model checking. It proves sampled finite paths only. Confirm both profiles and both race orders have positive witnesses; confirm expected plans never copy adapter outputs; confirm no cancellation releases funds or changes A Core state.
