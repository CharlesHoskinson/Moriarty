# Candidate A authority boundary author report

Status: local implementation and validation complete; required nonauthor review
and archive intake remain parent-owned. No S02 or Council acceptance claim.
Scope: adopted authority-boundary plan Tasks 1–3, one bounded actual funding unit.
The root dispatched this worker under the subagent-driven-development workflow
and retains nonauthor review and archival ownership. No further provider work or
Foreman action is in scope.

## Method and scope

Use the adopted plain shared-state shape: one execution state and a separate
finite chosen signing profile. There is no message protocol, candidate label
interpreter, or replacement common signature/parent/financial transition.
Primary properties are actual full-plan fidelity, account/escrow coupling,
reachable classified rejection, atomic funding, and conservation. These derive
from plan Tasks 1–3. Complete swap/installment lifecycles and final exports are
outside this unit.

Behavioral RED batches use explicitly permissive A stubs over real common
guards. Each RED retains full source-byte import closure before execution.
QNT404 constructor-name correction is separately recorded and is not RED.
Final source, exact commands, terminal results, hashes and commit identity will
be appended only after actual verification.

## Preserved development sequence (experiment observations)

- Stage 1 initial name-resolution error: PayNodeA is not a constructor. Corrected
  to the frozen PayA constructor. This is not behavioral RED.
- Stage 1 mixed run: 2 passing, 12 failing, exit 1. The positive fixture check
  exposed emptyAState's Time0 default, contrary to the required Time1 fixture.
  Preserved its full source closure and output in stage1-red. Corrected only the
  literal initial minimumTime, without changing any permissive guard.
- Stage 1 corrected behavioral RED: 5 passing, 9 failing, exit 1. Actual fixture
  and both-profile common signing positives passed. All nine A-specific negative
  controls failed. Full 14-file before/after identical source closure and output
  are in stage1-red-corrected.
- Stage 1 GREEN: 14 passing, exit 0, after implementing Task 1 guards. Full closure
  and terminal receipt are in stage1-green.
- Stage 2 typed behavioral RED: standalone typecheck exit 0; 20 passing, 7
  failing, test exit 1. Both funding pipelines, genuine deadline rejection,
  missing-evidence and stale-context controls passed against common delegation.
  The seven failed controls expose absent A fidelity/reachable-rejection/domain
  checks. Full 14-file source bytes and terminal output are in stage2-red.
- Stage 2 GREEN: 27 passing, exit 0. Full before/after source hashes are identical.
  Terminal output and full source closure are in stage2-green.
- Stage 3 action RED: seven failures, exit 1, QNT508/QNT513 from deliberately
  disabled actions. This is executable enabledness RED, not a parser or fixture
  failure. Five isolated transitions and both full-profile paths were selected.
  The full 15-file source closure and exact terminal receipt are in stage3-red.
  Four additional pure guard tests are supplemental coverage, not claimed as
  pre-implementation RED.
- First final validation attempt: all four new harness/test typecheck/run/test
  invocations ended naturally with QNT000 effect-typing failure. Two action match
  fallbacks returned Pure false while sibling branches assigned both variables.
  No process was terminated. The historical final-source directory preserves
  this failed source, not a passing final closure.
- Corrected only those two fallback branches to false-guarded complete variable
  assignments. They remain disabled and cannot stutter. The final-corrected-source
  directory preserves the corrected 15-file unit closure plus the adapter
  regression test (16 files total). Fresh affected validations all passed.
- Two explicit rejection-action witnesses supplement the prior Task 2 semantic
  RED/GREEN tests. Their initial tampering is constructed; only the subsequent
  guarded rejection is an executed action. They are not claimed as new original
  RED or as honest-workload tampering reachability.

The adapter regression passed all 15 tests, exit 0. The full Python suite was
run once by this worker and passed 441 tests, exit 0 (22.52 seconds). Both ran
after the first final source freeze. The later change affects only the boundary
harness's Quint action-effect syntax, outside their imported source closures;
the regression sources remain unchanged.

The corrected initial fixture, not an adapter expectation weakening, resolved
the fixture failure. No frozen constructor, interpreter, adapter or common
authorization source was changed.

## Self-review (repository observations)

The A-specific layer has no replacement signature, parent or financial update.
It checks all six admitted accounts against complete escrow maps, validates
every operation of the complete one-to-four-operation plan, and rechecks exact
observation/plan/evidence-policy fidelity at verification and commitment.
After-resolution outer operations must equal the complete identity payload.
Before-resolution signing does not require an already resolved plan.

Rejection guards check only the four complete structural map domains before
retained-stage lookup. They do not require the semantic condition which failed.
A-specific invalid coupling/fidelity takes UnauthorizedEffect precedence;
faithful missing proof, stale context and genuine Core rejection retain the
common classifications. Tests compare complete original attempt/evidence/context
values and the whole resulting execution state. This is exact structural
preservation in the model, not a cryptographic serialization claim.

The honest harness begins unsigned and has five distinct guarded transitions.
Only the common commit updates candidate, ledger and consumed key. Both profiles
have separate deterministic full-path tests. Five exact-state witnesses identify
each major transition; two further witnesses identify committed profiles.
The two rejection-action tests start from explicitly constructed tampering and
retain that distinction. No disabled fallback is an enabled stutter.

These author checks do not replace root's required nonauthor source/spec/evidence
review. The verification-before-completion skill requires terminal results and
unchanged source hashes before the source-only commit; the review skill requests
that separate review through the parent coordinator.

## Final local validation (experiment observations)

All final checks reached terminal exit 0. Four modules typechecked; the complete
boundary test module passed 40 tests; adapter regression passed 15 tests; the
Python suite passed 441 tests. The 100-sample funding harness found no
boundarySafetyA violation. Every prepare/sign/propose/verify/commit witness
occurred in all 100 traces; committed profiles were 50 after-resolution and
50 before-resolution. These finite paths and author predicates are not exhaustive
verification, universal correspondence, or a cryptographic proof.

Boundary and fixture standalone typechecks used their now-final byte-identical
Task 2 source/import closures. The corrected harness and complete test module
were separately typechecked after the two effect-typing corrections. No
passing typecheck is inferred from an empty log without its terminal exit.

Exact successful commands, all in
`/home/charl/Moriarty/.worktrees/s01-audit-start`:

```text
quint typecheck specs/quint/s02/candidate_a_authority_boundary.qnt
quint typecheck specs/quint/s02/candidate_a_authority_boundary_fixtures.qnt
quint typecheck specs/quint/s02/candidate_a_authority_boundary_harness.qnt
quint typecheck specs/quint/s02/candidate_a_authority_boundary_test.qnt
quint test specs/quint/s02/candidate_a_authority_boundary_test.qnt --backend=rust --seed=42
quint run specs/quint/s02/candidate_a_authority_boundary_harness.qnt --backend=rust --seed=42 --max-samples=100 --max-steps=6 --invariant=boundarySafetyA --witnesses fundingPreparedWitnessA fundingSignedWitnessA fundingProposedWitnessA fundingVerifiedWitnessA fundingCommittedWitnessA fundingCommittedAfterWitnessA fundingCommittedBeforeWitnessA --verbosity=1
quint test specs/quint/s02/candidate_a_authority_adapter_test.qnt --backend=rust --seed=42
/home/charl/Moriarty/.venv/bin/python -m pytest -q
```

Full command/initial chunk/poll chunks/terminal exits are retained in
`candidate-a-authority-boundary-receipts/final-verification/*.json`.
The four text files concatenate the actual raw output chunks. The harness's
original command uses seed 42; Quint printed a reproduction hint of 0xc27.
The raw hint is preserved, not normalized or substituted for the command.

### Complete boundary test output

```text

  candidate_a_authority_boundary_test
    ok literalFundingFixtureTest passed 1 test(s)
    ok honestPlansAndPoliciesTest passed 1 test(s)
    ok planCardinalityTest passed 1 test(s)
    ok secondSuccessorAndInputTest passed 1 test(s)
    ok secondArtifactAndTimeTest passed 1 test(s)
    ok secondProjectionAndEffectsTest passed 1 test(s)
    ok secondFactsCouplingAndClockTest passed 1 test(s)
    ok missingPlanMapsFailSafelyTest passed 1 test(s)
    ok afterViewMismatchPreparationTest passed 1 test(s)
    ok beforePreparationWithoutConcretePlanTest passed 1 test(s)
    ok signingAfterPipelineTest passed 1 test(s)
    ok signingBeforePipelineTest passed 1 test(s)
    ok invalidPlanRecheckedAtSigningTest passed 1 test(s)
    ok coupledStateRecheckedAtSigningTest passed 1 test(s)
    ok actualAfterFundingPipelineTest passed 1 test(s)
    ok actualBeforeFundingPipelineTest passed 1 test(s)
    ok forgedProposedRejectedReachablyTest passed 1 test(s)
    ok forgedVerifiedRejectedReachablyTest passed 1 test(s)
    ok forgedCoreErrorIsUnauthorizedTest passed 1 test(s)
    ok faithfulMissingEvidenceClassificationTest passed 1 test(s)
    ok faithfulStaleVerifiedClassificationTest passed 1 test(s)
    ok uncoupledStateStillRejectableTest passed 1 test(s)
    ok malformedStructuralMapsRefuseSafelyTest passed 1 test(s)
    ok retainedWrongIdRefusesRejectionTest passed 1 test(s)
    ok resolvedPlanRecheckedDuringExecutionTest passed 1 test(s)
    ok evidenceAfterViewFidelityTest passed 1 test(s)
    ok genuineDeadlineCoreRejectionTest passed 1 test(s)
    ok threeAndFourFaithfulPlanLengthsTest passed 1 test(s)
    ok allSixEscrowsCoupledTest passed 1 test(s)
    ok malformedCallDiagnosticsFailPlanTest passed 1 test(s)
    ok verifiedStructuralMapsRefuseSafelyTest passed 1 test(s)
    ok prepareFundingActionTest passed 1 test(s)
    ok signFundingActionTest passed 1 test(s)
    ok proposeFundingActionTest passed 1 test(s)
    ok verifyFundingActionTest passed 1 test(s)
    ok commitFundingActionTest passed 1 test(s)
    ok fullAfterFundingActionsTest passed 1 test(s)
    ok fullBeforeFundingActionsTest passed 1 test(s)
    ok proposedRejectionActionWitnessTest passed 1 test(s)
    ok verifiedRejectionActionWitnessTest passed 1 test(s)

  40 passing (106206ms)
```

### Complete harness output

```text
[ok] No violation found (7092ms at 14 traces/second).
Witnesses:
fundingPreparedWitnessA was witnessed in 100 trace(s) out of 100 explored (100.00%)
fundingSignedWitnessA was witnessed in 100 trace(s) out of 100 explored (100.00%)
fundingProposedWitnessA was witnessed in 100 trace(s) out of 100 explored (100.00%)
fundingVerifiedWitnessA was witnessed in 100 trace(s) out of 100 explored (100.00%)
fundingCommittedWitnessA was witnessed in 100 trace(s) out of 100 explored (100.00%)
fundingCommittedAfterWitnessA was witnessed in 50 trace(s) out of 100 explored (50.00%)
fundingCommittedBeforeWitnessA was witnessed in 50 trace(s) out of 100 explored (50.00%)
Use --seed=0xc27 --backend=rust to reproduce.
```

### Final source pins

All preserved source snapshots were audited against their recorded source
hashes, including the mixed initial fixture failure and failed first-final
effect-typing attempt. Final tested source bytes are under
`candidate-a-authority-boundary-receipts/final-corrected-source/`.
This directory contains the complete 15-file boundary unit import closure plus
the adapter regression test. Before/after final hashes are identical.

```text
b59779d5e2e7f1bf0a14952dfe1cd3ab70bcfe813210d690abbb3e3205a6df61  specs/quint/s02/authorization.qnt
3dd07f3c5f274aff4fce4de9c245aa0b1f1fe7f68e29e5de95a0b1c42a00f93b  specs/quint/s02/consumption.qnt
dccc9208d9a42f01685000b1358f1d2f9684bf5e8ebe1d5deadd0c992557504c  specs/quint/s02/effects.qnt
cf52f55ad1810548b7c45e32552b977a30fc8dd937dfbd01d35829b6beec8928  specs/quint/s02/execution.qnt
e44484ed9035e560ef9f4d012198671917750da42ab404022592db16cdd59bc3  specs/quint/s02/observations.qnt
0886619203c3de16f2326e27e9d4ae2ddfda8c54742c231dd4e824397c5fa9fe  specs/quint/s02/policies.qnt
40901738fd1749527761b624a84253da94bbc24c209d408dc2fd4e895daaae0b  specs/quint/s02/candidate_a_types.qnt
bf814bce2924cafac5836a171b52a4c9bdba43e083fe7129bcdeadd810c42d5e  specs/quint/s02/candidate_a_programs.qnt
e759d4c13032d83a4d839e08bef0fcf8272943792f73bb3ab7910357b0f28dec  specs/quint/s02/candidate_a_core.qnt
2eb66db8010a3d47ddba8f99d647326d2eb7bf3c9da5177c7dd2dcd88145452c  specs/quint/s02/candidate_a_projection.qnt
3f3b093f4c718dd08eda38e610de700d0a24138beb82fd7b2b12dcf9d300bda8  specs/quint/s02/candidate_a_authority_adapter.qnt
95ddf75ef32b432acaec5384c89826d0dc12245b80f78fd8a60ff78d0da8164b  specs/quint/s02/candidate_a_authority_boundary.qnt
32e68b44ac77f01df74e200cde3c23150b12e40ff772167dc5fa3c79464b52ad  specs/quint/s02/candidate_a_authority_boundary_fixtures.qnt
a5c7645697166d8979125f8f46e81ccb6938d589c69165c01bd540b92a9585cd  specs/quint/s02/candidate_a_authority_boundary_test.qnt
26d13e6f34b4e16158dc92d80ccbdf0075d9291121deb1a88aa76de817c39652  specs/quint/s02/candidate_a_authority_boundary_harness.qnt
029b2dfd24380f385c961a3145d52528339ee78b9a4d63b9009e7770f2077cf8  specs/quint/s02/candidate_a_authority_adapter_test.qnt
```

Reference and tool pins:

```text
564a926779beb54bd16ff58481f5c950bae6fb50fcd5b0d7c9eb56427f83273b  moriarty/core.py
82e9e1da76af65706171049f0238953aca5333edec4aeed6caa43dbd57c79797  moriarty/swap.py
7d3d7e2a9a4b86bd7028b2fd45982685c01d4859208bbe59eb3fce424a348345  docs/superpowers/plans/2026-09-05-moriarty-s02-candidate-a-authority-boundary.md
04cd2ed28f9c794823282b982de7d7a5b30c67e8e2d6df95ef18365ab19dddbd  docs/superpowers/specs/2026-09-05-moriarty-s02-candidate-a-authority-design.md
ac12595b1cb7253feec93c79417615c6eb20fc3b6a3df35c5e3530b24e90a501  /home/charl/.npm-global/bin/quint
b2efdeac5713d153e41bf2143b94ed75d888fdd5637f4a5d61a04c695313510a  /home/charl/.quint/rust-evaluator-v0.6.0/quint_evaluator
```

The plan hash above includes its adopted review-disposition paragraph. The
earlier dbc4ecc review hash quoted inside the plan names the reviewed draft,
not the final file's self-hash.

## Handoff limits and review

This worker authored the four boundary files and earlier Candidate A semantic
units. These are implementation-author observations. Root's separate review and
archive intake are required; this report does not supply a nonauthor or Council
verdict. Root had reported no concrete pure-boundary defect at the time of the
final validation, not a completed whole-unit gate.

Complete signed swap/installment lifecycles, races and separately signed
recovery, integrated correspondence exports, bounded model checking, candidates
B–D and S02/Council acceptance remain outside this unit. No frozen Python/Core,
completed adapter, common authorization, or root-owned evidence/design file was
edited. Foreman/checkpoint databases were not used under the explicit ownership
and no-Foreman restriction. The unique report/receipts provide the scoped handoff.

Authorized source-only commit: `d14cfea98a1c9213e5ef5f12c1a088f4e966083d`.
Exactly the four owned new Quint files were committed. The full terminal commit
receipt, path list and unchanged post-commit hashes are in
`final-verification/commit.json`. Root controls report/receipt archival.
