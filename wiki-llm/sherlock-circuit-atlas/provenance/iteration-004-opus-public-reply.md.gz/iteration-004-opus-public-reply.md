```json
{
  "iteration004_markdown": "# Iteration 004: full-image literal and borrow\n\nProposed corrected materialization. The raw Gemini author reply stays immutable. This proposal performs no wiki transaction or publication.\n\n## Authorship and provenance\n\n- **Initial concepts:** Gemini 4 Argon (High) via AGY, drafted under the user's explicit fallback while Claude Opus 5.5 was temporarily unavailable. Raw reply `circuit-atlas-004-argon-author-r1/RESULT.json` `975cb29561fc0b0bc94bd673a2ef465bbc726fc3aa2746495569229b9d98e1a2` (26997 bytes).\n  - Requested: `gemini-4-argon-high`, mode `plan`, effort `high`.\n  - Returned: selection `gemini-4-argon-high` and `permission_mode: always-proceed`. Separate canonical ID and returned effort are both `NOT_REPORTED`.\n  - No plan-mode enforcement or mechanical tool absence is claimed.\n- **Source-accuracy revisions:** Claude Opus 5.5 (`claude-opus-5-5`, requested effort high). Captured Muse normal findings (`circuit-atlas-004-muse-review-r1/LAUNCH.stdout` `496f840969365740a143a24d34140e3e384fbb1f7af29b6e5ef37e37f1fb9ed3`; qualification `74b34f3b3331eaf8832aae3620807b933fb52df18e74dbd623a14eee05a60e39`) were checked independently against the complete frozen source. Muse's reply lacked its required outer delivery marker, so it is normal advice, not an approved audit.\n- Iterations 000–003 keep their original Claude Opus 5.5 authorship.\n\n## Status\n\n- This is a creative, source-only concept note. It is not an audit, a compiler check, or an acceptance decision.\n- At authoring time, the A102 source was pending fresh owner review.\n- Two scoped source reviews came later, both `APPROVED_SOURCE_WITH_LIMITS`:\n  - Muse normal `f3ba9ef52a43124b0fc9d450d621e4ca1553e93f252133d7f00954ae2633346e`\n  - Gemini source-owner `09c4a6c2375721fbdb6984ff2ff8bb253edf93b5297a8f43a809aa22cf45bbd8`\n  \n  They cover the source fragment only. They do not approve this note, a website, execution, proof, cost, or acceptance.\n- At its freeze, the original source was unregistered and uncompiled, all five tests were UNRUN, and `native_authority = 0`. A later registration source now in preparation is excluded from this iteration's freeze.\n- No cost, `k`, row, proof, runtime, or stagenet claim is made.\n\n## Source pins\n\nManifest `662bc7748f2a98e2186372970951c08ebed0328b04c574f6f7e4f5eab42e7f85`. Envelope/carrier clarification `d808e46cc9c1b871f285722639511c5e45e0b01e4e9067078d5fa5a40216f3cc` continues scoped P1 `ebea84ac1ce065d508d6a0ff17bafa39a190007214142075205fb97278c59213`.\n\n| Path | SHA256 | Bytes |\n|---|---|---:|\n| `crates/mori-backend/src/sherlock_machine/literal_step.rs` | `b5d2ca73b0e6b561f554902c3f4e50ec7743cc7ca04b9e7e9acb0c3aca10b839` | 19788 |\n| `crates/mori-backend/src/sherlock_machine/literal_step_normal_tests.rs` | `255408fdafb36b2ed771206c366232dea2b61d7345d79537121e556f38163ef6` | 8079 |\n| `models/sherlock/literal-step/MAPPING.md` | `72411a42e8886f18286192d10aff885bc8435347e424c9170c1f1f4dc467eaad` | 9041 |\n\n## Source features\n\n1. **Logical schema** (`literal_schema`, `check_image`).\n   - Rejects with `MinimumShape` when `x == 0 || k == 0 || control == 0 || t < 4 || q < 4 || qf < 5`.\n   - Builds a 16-lane program header and 15 program tables with lanes `[2,1,4,1,11,1,6,2,3,2,3,4,1,22,2]`.\n   - Each state image gets a 45-lane Root and six tables with lanes `[22,2,5,2,17,36]`.\n   - These are logical operand images (`LiteralImage`), not serialized bytes or canonical L4.\n2. **Pre guards.** When `enable` is set:\n   - the pre outcome is Pending with zero payload and error;\n   - `controlLength == 1`;\n   - ControlRows row 0 is zero except `exprId`, which makes it Eval;\n   - later rows are zero.\n3. **Real G3 fetch** (`emit_enabled_fetch_block`).\n   - Index is `pre.tables[5][0].exprId`, rows are `program.tables[4]`, and the active count is `program.root[5]`.\n   - The selected row must have `tag == 0` and `valueRef.space == 0`, with inactive columns and slices zero.\n   - It must also satisfy `occurrenceId == exprId` and `valueRef.index < program.root[14]`.\n4. **Constant alias.**\n   - The selected `valueRef.{space,index}` is aliased into post ControlRows row 0.\n   - The supplied `Constants` [13] and `ConstantFields` [14] rows are range-checked.\n   - No fetch, unfold, or `Data` materialization occurs.\n5. **Root and tables.**\n   - All 45 Root lanes are constrained: 16 `remainingFuel` lanes by borrow equations, `controlLength == 1`, and the other 28 lanes (including every `initialFuel` byte) by `post == pre`.\n   - Five whole tables, indices 0–4, are preserved cell by cell.\n   - `ControlRows` (index 5) is constrained separately. Row 0 has `tag == 1` (Return) plus the aliased reference, and its other 33 columns are zero. Rows ≥ 1 are zero.\n6. **Borrow.**\n   - `zero_i = TestEq(pre_i, 0)`, and the all-zero fold is gated to 0.\n   - `borrow_0 = enable` and `next = CondSelect(borrow_i, zero_i, 0)`.\n   - Each byte satisfies the gated equation `pre_i + 256*next == post_i + borrow_i`, with 9-bit intermediates.\n   - A final unconditional `ConstrainEq(borrow_16, 0)` closes the chain.\n7. **Ranges and guarding.**\n   - Every supplied lane gets a bit-width or Boolean check unconditionally.\n   - Only lanes that carry a `maximum` also get `LessThan(maximum, val) == 0`.\n   - `gated_eq` emits `ConstrainEq(CondSelect(enable, a, b), b)`. A disabled branch therefore imposes no A102 transition equation on the shared post state, while range checks still apply.\n8. **Envelope.** `LiteralEnvelope` sits outside both blocks. When enabled, it constrains `rule_tag == 3` (enum(39)) and `charge == 1`. Host `RecordEnvelopeA.rule_start_line = 102` is unchanged and is not a circuit operand.\n\n## Proposed Three.js PCB scenes\n\n1. **Triple-plane logical-image carrier.**\n   - Program, pre, and post planes carry the caption `logical operand images — not serialized bytes, canonical L4, or a running machine`.\n   - Standoffs bridge the 28 preserved Root pads and the five preserved table banks.\n   - ControlRows gets its own Return-row and zero-bar footprint.\n   - Constants banks show populated pads with range terminations and no fetch traces.\n   - Fuel is drawn as two solid 16-trace byte buses.\n   - Non-fuel carriers end in dashed sockets labeled `OBL.G4@A102 / StepInv: ceil(w/8) LE byte bridge — caller obligation`.\n2. **Sixteen-stage borrow daughterboard.**\n   - A zero-fold rail runs above the borrow chain, which is grounded at `borrow_16 == 0`.\n   - An optional `256 -> 255` stepper (`pre = [0,1,0..]`, `post = [255,0,0..]`) runs under the fixed banner **`arithmetic illustration; not an executed circuit`**.\n3. **Guarded composition backplane.**\n   - An unconditional bit/Boolean pad grid, with maximum pads only on lanes that carry a maximum.\n   - A `%dispatch.a102` enable bus feeds the `CondSelect` trapezoids.\n   - Dashed perimeter sockets are labeled `caller prerequisite — not implemented by A102`.\n\n## Accessibility and truth labels\n\n- Badge: `SOURCE-ONLY | UNREGISTERED AT FREEZE | 5 TESTS UNRUN | COMPILER/SDK UNRUN | NATIVE AUTHORITY 0 | COST UNMEASURED`.\n- DOM netlist and static SVG fallback, with unabbreviated `%` identifiers.\n- Keys `B`/`P`/`O` step through borrow stages, preservation rails, and open sockets.\n- Under `prefers-reduced-motion`, transitions cut without interpolation.\n\n## Corrections versus the raw draft\n\n- `6-Table Preservation` now reads as five preserved tables plus separately constrained ControlRows.\n- The maximum check is limited to lanes that carry a maximum.\n- Minimum shape is stated as a rejection condition.\n- Author-time pending review is separated from the later scoped approvals.\n- The plan-mode request and the always-proceed return are both recorded. The ambiguous bare `effort` field is removed.\n- Planes are captioned as logical images, and Constants are shown populated rather than as keep-outs.\n- Opus additions:\n  - removed the `RULE_LINES` bijection, which is absent from the supplied source;\n  - replaced `post unconstrained` with `no A102 transition equation`;\n  - added the pre guards.\n\n## Open gates (unwaived)\n\n- Non-fuel byte bridge, `StepInv`/O1–O4, and `uiValid`\n- `F4` canonicality\n- Exact-one 39-rule dispatch and free publication\n- Remaining 38 events, unwritten P1 rows, and P2–P6\n- Statement, trace, and public-private binding\n- Resource admission\n- Candidate B, general ADTs, and financial gates\n- Proofs and stagenet\n",
  "README_append_markdown": "### Index row (append)\n\n| Iteration | Source slice and snapshot | Note | Source status and review scope |\n|---|---|---|---|\n| 004 | Full-image A102 Literal step and 16-byte LE fuel borrow (`sherlock_machine::literal_step`, manifest `662bc7748f2a98e2186372970951c08ebed0328b04c574f6f7e4f5eab42e7f85`) | [Full-image literal and borrow](ITERATION-004-FULL-IMAGE-LITERAL-AND-BORROW.md) | Unregistered and uncompiled at freeze; 5 tests UNRUN; native_authority 0. Pending owner review at authoring time. Later scoped source reviews returned `APPROVED_SOURCE_WITH_LIMITS` for the source only, not this note. |\n\n### Provenance (append)\n\n- 004 credit:\n  - Initial concepts: Gemini 4 Argon (High) via AGY, under explicit user fallback. Raw reply `975cb29561fc0b0bc94bd673a2ef465bbc726fc3aa2746495569229b9d98e1a2` is preserved unchanged.\n  - Source-accuracy revisions: Claude Opus 5.5, after independent source checks of captured Muse normal advice `496f840969365740a143a24d34140e3e384fbb1f7af29b6e5ef37e37f1fb9ed3`. That advice lacked its outer marker and is not an approval.\n- The Opus revision reply hash will be assigned when Root captures it.\n- Iterations 000–003 keep their original Claude Opus 5.5 authorship.\n",
  "authorship_entry": {
    "iteration": "004",
    "note_file": "ITERATION-004-FULL-IMAGE-LITERAL-AND-BORROW.md",
    "materialization_status": "PROPOSED_CORRECTED_MATERIALIZATION_NOT_COMMITTED",
    "credit": "Initial concepts: Gemini 4 Argon (High) via AGY. Source-accuracy revisions: Claude Opus 5.5 (high). Original Gemini prose is not relabeled as Opus-authored.",
    "contributors": [
      {
        "role": "initial_concepts",
        "author": "Gemini 4 Argon (High) via AGY",
        "provider": "AGY",
        "requested_model": "gemini-4-argon-high",
        "requested_mode": "plan",
        "returned_permission_mode": "always-proceed",
        "returned_model_selection": "gemini-4-argon-high",
        "separate_canonical_model_id": "NOT_REPORTED",
        "requested_effort": "high",
        "returned_effort": "NOT_REPORTED",
        "tool_absence_claim": "NONE; plan-mode enforcement not established",
        "fallback_context": "Explicit user-authorized fallback while Claude Opus 5.5 was temporarily unavailable",
        "raw_reply": {
          "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-reference-20261015/opus-sprint-loop-20261015/circuit-atlas-004-argon-author-r1/RESULT.json",
          "sha256": "975cb29561fc0b0bc94bd673a2ef465bbc726fc3aa2746495569229b9d98e1a2",
          "bytes": 26997,
          "disposition": "IMMUTABLE_PRESERVED"
        }
      },
      {
        "role": "source_accuracy_revisions",
        "author": "Claude Opus 5.5",
        "model_id": "claude-opus-5-5",
        "requested_effort": "high",
        "returned_effort": "NOT_SELF_REPORTED",
        "raw_reply": "This response; path and sha256 to be assigned when Root captures it"
      }
    ],
    "review_inputs": {
      "muse_draft_findings": {
        "path": "/home/charl/Moriarty/.moriarty-dev/runtime/sherlock-reference-20261015/opus-sprint-loop-20261015/circuit-atlas-004-muse-review-r1/LAUNCH.stdout",
        "sha256": "496f840969365740a143a24d34140e3e384fbb1f7af29b6e5ef37e37f1fb9ed3",
        "bytes": 7574,
        "qualification_sha256": "74b34f3b3331eaf8832aae3620807b933fb52df18e74dbd623a14eee05a60e39",
        "status": "CAPTURED_NORMAL_FINDINGS_NOT_BOUND_APPROVAL (required outer marker missing)",
        "opus_assessment": "All six findings confirmed against source. Three additional corrections were made: RULE_LINES removed, disabled-branch wording fixed, pre guards added."
      },
      "later_scoped_source_reviews": [
        {
          "reviewer": "Muse Wonder 1.0 normal",
          "sha256": "f3ba9ef52a43124b0fc9d450d621e4ca1553e93f252133d7f00954ae2633346e",
          "verdict": "APPROVED_SOURCE_WITH_LIMITS"
        },
        {
          "reviewer": "Gemini 4 Argon source owner",
          "sha256": "09c4a6c2375721fbdb6984ff2ff8bb253edf93b5297a8f43a809aa22cf45bbd8",
          "verdict": "APPROVED_SOURCE_WITH_LIMITS"
        }
      ]
    },
    "adoption": "brainstorm only",
    "native_authority": 0,
    "source_manifest_sha256": "662bc7748f2a98e2186372970951c08ebed0328b04c574f6f7e4f5eab42e7f85",
    "work_report_sha256": "961138da1176176f2a0f59ea47351ef7b865985dbf9d9649a7d55df9be2212c7",
    "inputs_manifest_sha256": "9accbd90b15a50d0201740255d3757752a6a0c411f8778a7f3b3f08964d5970f",
    "test_first_manifest_sha256": "d188cdede98bd34dd6a646258e5f4463476082f785541b826c9b1c2851abcb84",
    "envelope_clarification_result_sha256": "d808e46cc9c1b871f285722639511c5e45e0b01e4e9067078d5fa5a40216f3cc",
    "scoped_p1_adoption_sha256": "ebea84ac1ce065d508d6a0ff17bafa39a190007214142075205fb97278c59213",
    "circuit_source_pins": [
      {
        "path": "crates/mori-backend/src/sherlock_machine/literal_step.rs",
        "sha256": "b5d2ca73b0e6b561f554902c3f4e50ec7743cc7ca04b9e7e9acb0c3aca10b839",
        "bytes": 19788
      },
      {
        "path": "crates/mori-backend/src/sherlock_machine/literal_step_normal_tests.rs",
        "sha256": "255408fdafb36b2ed771206c366232dea2b61d7345d79537121e556f38163ef6",
        "bytes": 8079
      },
      {
        "path": "models/sherlock/literal-step/MAPPING.md",
        "sha256": "72411a42e8886f18286192d10aff885bc8435347e424c9170c1f1f4dc467eaad",
        "bytes": 9041
      }
    ],
    "review_scope": "Creative source-only concept note. At authoring time the A102 source was pending fresh owner review. Later scoped source reviews (APPROVED_SOURCE_WITH_LIMITS) cover only the source fragment and do not approve this note, a website, execution, proof, cost, or acceptance. Original source was unregistered and uncompiled at its freeze, with 5 tests UNRUN. The later registration source is excluded from this freeze."
  },
  "concept_feature_map": [
    {
      "feature_id": "logical_schema_and_images",
      "source_file": "crates/mori-backend/src/sherlock_machine/literal_step.rs",
      "source_sha256": "b5d2ca73b0e6b561f554902c3f4e50ec7743cc7ca04b9e7e9acb0c3aca10b839",
      "symbol_anchors": ["LiteralCapacities", "LiteralLane", "LiteralTable", "LiteralSchema", "LiteralImage", "literal_schema", "check_image"],
      "test_anchor": "complete_l4_column_membership_and_both_fuel_arrays_are_retained (no test exercises MinimumShape rejection)",
      "source_facts": "Rejects with MinimumShape when x == 0 || k == 0 || control == 0 || t < 4 || q < 4 || qf < 5. Builds a 16-lane program header, 15 program tables with lanes [2,1,4,1,11,1,6,2,3,2,3,4,1,22,2], and per state image a 45-lane Root plus 6 tables with lanes [22,2,5,2,17,36].",
      "pcb_component_model": "Triple-plane carrier (program, pre, post) captioned as logical operand images.",
      "truth_and_limitation_label": "Logical operand images only: not serialized ProgramBlock/StateBlock bytes or canonical L4. Specimen capacities are not resource bounds.",
      "concept_origin": "Gemini 4 Argon",
      "revision": "Opus: minimum shape restated as rejection; logical-image caption added."
    },
    {
      "feature_id": "pre_state_guards",
      "source_file": "crates/mori-backend/src/sherlock_machine/literal_step.rs",
      "source_sha256": "b5d2ca73b0e6b561f554902c3f4e50ec7743cc7ca04b9e7e9acb0c3aca10b839",
      "symbol_anchors": ["emit_literal_step", "Emitter::gated_eq"],
      "test_anchor": "NONE (no normal test inspects pre-state guards)",
      "source_facts": "When enabled: pre outcomeTag, outcomeValue.space, outcomeValue.index and outcomeError are all 0; pre controlLength == 1; pre ControlRows row 0 is zero except exprId; rows >= 1 are zero.",
      "pcb_component_model": "Pre-plane guard pads on the outcome lanes and the Eval control row.",
      "truth_and_limitation_label": "SOURCE-ONLY UNRUN.",
      "concept_origin": "Claude Opus 5.5",
      "revision": "Added by Opus."
    },
    {
      "feature_id": "real_g3_expression_fetch",
      "source_file": "crates/mori-backend/src/sherlock_machine/literal_step.rs",
      "source_sha256": "b5d2ca73b0e6b561f554902c3f4e50ec7743cc7ca04b9e7e9acb0c3aca10b839",
      "symbol_anchors": ["emit_literal_step", "emit_enabled_fetch_block", "EnabledFetchInputs", "TableShape::new"],
      "test_anchor": "real_enabled_fetch_instructions_feed_the_exact_return_reference",
      "source_facts": "Fetch indexes program.tables[4] by pre.tables[5][0].exprId, with active count program.root[5]. The selected row is constrained to tag == 0 and valueRef.space == 0, with nameId, binaryOp, unaryOp and both slices zero, occurrenceId == exprId, and LessThan(valueRef.index, program.root[14]) == 1.",
      "pcb_component_model": "G3 fetch mezzanine on the Expressions bank, in namespace %{scope}.expression_fetch.temp.",
      "truth_and_limitation_label": "SOURCE-ONLY UNRUN. uiValid remains an external typing obligation.",
      "concept_origin": "Gemini 4 Argon",
      "revision": "Unchanged in substance."
    },
    {
      "feature_id": "constant_alias_without_unfold",
      "source_file": "crates/mori-backend/src/sherlock_machine/literal_step.rs",
      "source_sha256": "b5d2ca73b0e6b561f554902c3f4e50ec7743cc7ca04b9e7e9acb0c3aca10b839",
      "symbol_anchors": ["emit_literal_step", "field", "Emitter::image_ranges"],
      "test_anchor": "real_enabled_fetch_instructions_feed_the_exact_return_reference; return_padding_and_wire_envelope_have_explicit_guarded_equations",
      "source_facts": "Selected valueRef.{space,index} is aliased into post ControlRows row 0. The supplied Constants [13] and ConstantFields [14] rows receive unconditional range checks; there is no fetch, recursive unfold, or Data materialization.",
      "pcb_component_model": "Two-trace jumper into post row 0. Constants banks are populated pads with range terminations and no fetch traces.",
      "truth_and_limitation_label": "SOURCE-ONLY UNRUN.",
      "concept_origin": "Gemini 4 Argon",
      "revision": "Opus: keep-out rendering replaced by populated range-checked pads."
    },
    {
      "feature_id": "root45_five_tables_and_control_rows",
      "source_file": "crates/mori-backend/src/sherlock_machine/literal_step.rs",
      "source_sha256": "b5d2ca73b0e6b561f554902c3f4e50ec7743cc7ca04b9e7e9acb0c3aca10b839",
      "symbol_anchors": ["emit_literal_step", "Emitter::gated_eq"],
      "test_anchor": "every_unchanged_root_and_arena_cell_has_a_post_to_pre_equation; return_padding_and_wire_envelope_have_explicit_guarded_equations",
      "source_facts": "45 Root lanes: 16 remainingFuel lanes constrained by borrow equations, controlLength == 1, and the other 28 by post == pre (including initialFuel). Tables 0-4 (Data, DataFields, EnvCells, ValueSlots, FrameSlots) are preserved whole. ControlRows (index 5) is constrained separately: row 0 is tag 1 with the aliased valueRef and 33 other columns zero; rows >= 1 are zero.",
      "pcb_component_model": "Standoff bus across 28 Root pads and 5 table banks, plus a separate ControlRows Return/zero-bar footprint.",
      "truth_and_limitation_label": "SOURCE-ONLY UNRUN.",
      "concept_origin": "Gemini 4 Argon",
      "revision": "Opus: '6-table preservation' corrected to 5 preserved tables plus separately constrained ControlRows."
    },
    {
      "feature_id": "sixteen_byte_le_borrow",
      "source_file": "crates/mori-backend/src/sherlock_machine/literal_step.rs",
      "source_sha256": "b5d2ca73b0e6b561f554902c3f4e50ec7743cc7ca04b9e7e9acb0c3aca10b839",
      "symbol_anchors": ["bytes", "Emitter::test_zero", "Emitter::select", "Emitter::mul", "Emitter::add", "Emitter::bits", "Emitter::gated_eq"],
      "test_anchor": "decrement_wiring_propagates_a_boolean_borrow_through_all_sixteen_bytes (does not inspect the all_zero fold or the 9-bit bounds)",
      "source_facts": "zero_i = TestEq(pre_i, 0). The all_zero fold is gated to 0. borrow_0 = enable; next = CondSelect(borrow_i, zero_i, 0) and is Boolean. Each byte has a gated pre_i + 256*next == post_i + borrow_i with 9-bit bounds. A final unconditional ConstrainEq(borrow_16, 0) closes the chain.",
      "pcb_component_model": "16-stage daughterboard with a zero-fold rail, plus an optional 256 -> 255 stepper.",
      "truth_and_limitation_label": "The 256 -> 255 stepper is an arithmetic illustration, not an executed circuit. Tests UNRUN.",
      "concept_origin": "Gemini 4 Argon",
      "revision": "Illustration arithmetic rechecked by hand; not executed."
    },
    {
      "feature_id": "ranges_and_guarded_disable",
      "source_file": "crates/mori-backend/src/sherlock_machine/literal_step.rs",
      "source_sha256": "b5d2ca73b0e6b561f554902c3f4e50ec7743cc7ca04b9e7e9acb0c3aca10b839",
      "symbol_anchors": ["Emitter::ranges", "Emitter::image_ranges", "Emitter::less", "Emitter::gated_eq"],
      "test_anchor": "Partial: decrement test checks 8-bit ConstrainBits on fuel bytes; no test inspects maximum checks",
      "source_facts": "Every supplied lane gets ConstrainBits or ConstrainToBoolean unconditionally. Only lanes with maximum Some (count and tag lanes) also get LessThan(maximum, val) == 0. gated_eq emits ConstrainEq(CondSelect(enable,a,b), b), so a disabled branch imposes no A102 transition equation on post; range checks still apply.",
      "pcb_component_model": "Bit/Boolean pad grid with maximum pads only on maximum-bearing lanes, plus the %dispatch.a102 enable bus.",
      "truth_and_limitation_label": "SOURCE-ONLY UNRUN. Exact-one dispatch is a caller prerequisite.",
      "concept_origin": "Gemini 4 Argon",
      "revision": "Opus: maximum-check scope narrowed; 'post unconstrained' corrected."
    },
    {
      "feature_id": "wire_envelope_vs_host_line_102",
      "source_file": "crates/mori-backend/src/sherlock_machine/literal_step.rs",
      "source_sha256": "b5d2ca73b0e6b561f554902c3f4e50ec7743cc7ca04b9e7e9acb0c3aca10b839",
      "symbol_anchors": ["LiteralEnvelope", "emit_literal_step"],
      "test_anchor": "return_padding_and_wire_envelope_have_explicit_guarded_equations",
      "source_facts": "The envelope sits outside both blocks. rule_tag is a 6-bit enum(39) with maximum 38 and charge is 8-bit. When enabled, rule_tag == 3 and charge == 1. Host RecordEnvelopeA.rule_start_line = 102 is not an operand. No PublicInput or Output is emitted.",
      "pcb_component_model": "Isolated 2-pin edge header with the silkscreen 'wire enum(39) = 3; host line 102 outside circuit'.",
      "truth_and_limitation_label": "SOURCE-ONLY UNRUN. No statement binding.",
      "concept_origin": "Gemini 4 Argon",
      "revision": "Opus: unsourced 'RULE_LINES bijection' removed."
    },
    {
      "feature_id": "nonfuel_carrier_byte_bridge",
      "source_file": "models/sherlock/literal-step/MAPPING.md",
      "source_sha256": "72411a42e8886f18286192d10aff885bc8435347e424c9170c1f1f4dc467eaad",
      "symbol_anchors": ["literal_schema", "bytes", "unsigned", "id", "count", "tag"],
      "test_anchor": "complete_l4_column_membership_and_both_fuel_arrays_are_retained",
      "source_facts": "Fuel fields are 16 little-endian u8 operands each. Other bounded scalars are logical Native operands. The ceil(w/8) LE byte bridge for every non-fuel carrier is an unwaived OBL.G4@A102/StepInv caller obligation.",
      "pcb_component_model": "Two solid 16-trace fuel buses, with dashed, unlit sockets on the non-fuel carriers.",
      "truth_and_limitation_label": "UNWAIVED CALLER OBLIGATION. Not an alternate L4 serialization.",
      "concept_origin": "Gemini 4 Argon",
      "revision": "Wording aligned to MAPPING.md."
    }
  ],
  "context_marker": "ATLAS004_REVISION_END_b54221e4b332003bd976fa0bfb702522"
}
```