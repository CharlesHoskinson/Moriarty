## Verdict: APPROVED_NORMAL_CREATIVE_SOURCE_WITH_LIMITS

Candidate manifest: `19d785b44d7dd9c8c18da044b3dc84ae654387a15f47287ed9d9c0daa0770001`

The unchanged note is publishable as a historical creative companion, provided Root publishes the historical-currentness and source-mapping clarification described below alongside it. No author repair to a source equation or specimen is required.

### Reading limits

- I reviewed only the complete note, original public result, original request, and forwarded primary-source evidence supplied in this request. I used no tools, filesystem access, commands, parsers, web access, model execution, native execution, writes, or delegation.
- This is a normal factual, source, branding, and accessibility review only. It is not a security judgment, circuit audit, adoption decision, or substitute owner review.
- SHA256 values, byte counts, provider identity, and transport provenance are as supplied; I recomputed no hash. The `.qnt` file bytes and the exact P3 errata texts were not supplied, so I make no claim about their contents beyond the supplied records.
- The later P4 adoption and aux r2 status were taken from the review instruction as Root’s currentness premise, not independently inspected here.
- All native authority, caps, C4, and roadmap limits remain unchanged. Publication would not be execution, registration, emitter acceptance, or website authorization.

### Source-fidelity findings

The note’s principal source representations are accurate:

- The EXT/COPY selector, EX4 two-holder trace, `w`-slot variant, and `V < v+5` refusal match P3. The third EX4 step correctly copies because `v+1 ≠ v+2`; the fourth correctly uses EXT because `(v+2)+2 = v+4`.
- The four aux/1 regions, packing order, disabled-zero shape, header/row columns, and EX2, EX5, EX7, and EX8 descriptions match the supplied P3 source.
- The aux/2 ADD and SUB per-limb relations and the Lt relation `ltOut = selLt·SUB.bo_16` match the supplied candidate. The lane arithmetic is correct: `55 + 32 + 32 + 65 = 184`, plus 32 FuelProbe and 16 FuelDec lanes equals **232 logical lanes**. The note correctly does not equate those lanes with gates, rows, circuit `k`, proof size, cost, DUST, or fees.
- The cited specimens are correct, including A-3, S-3, L-4, L-5, M-4, M-6 with `c_16 = 4079`, and F-2 `65536 → 65535`. The note does not reproduce the candidate’s faulty §9 fuel inventory, although Root’s clarification must still bind readers to the corrected E1/E-FUEL reading.
- Branding is represented accurately: Moriarty wordmark and the 4px/grid/ledger system are preserved, copper is the existing accent, and any glow is expressly identified as a departure from “Nothing glows” requiring design review. Accessibility proposals include DOM-first explanation, keyboard operation, reduced motion, labels, patterns, and non-colour cues; the proposed contrast values remain unmeasured and cannot yet be claimed to pass.

### Required publication conditions

Root’s adjacent clarification, without silently editing the note, must state:

1. **Historical freeze:** This is `DESIGN-005`, a companion concept note, not an `ITERATION-NNN` handwritten-circuit iteration. It was authored from snapshot base `2afbabdc27984015979ef952dad89ce350f2450a`, when the exact P4/aux/2 source was still described in the note as an unadopted proposal and the aux host packer remained at its r1 `BLOCKED_SOURCE` F1 stage. Earlier atlas notes remain unchanged.

2. **Current P4 status:** Root subsequently adopted the exact aux/2 arithmetic/fuel source conditionally, with both full fresh votes and binding E1–E7/E-FUEL. The exact design remains `88887f1d30aee2c5c0f473d2276a8aecd5e8f4e12018a34b0037ec11d51b13c3`, under candidate manifest `42d45bd3bea826469408a774984318d1ae473b82636ae5f32c0bf4ca8b23c6a2`. Charged rules total 36 as `24 + 8 + 4`, including A108; the free rules are A080, A082, and A084. This is not complete P4, native, emitter, or execution adoption: `adopted_as_execution` remains false and the relevant K, Quint, Clean, native, and stagenet checks remain UNRUN, with G4 and IO obligations still open.

3. **Host-packer status:** The note’s host-packer material describes the historical r1 candidate manifest `004f3b75b2b17a470ac29c96f82583f76966e4fe2103defaa9bbb97bf7003fe9` and `aux.rs` hash `ecaa1cc18d656481d37163f88b840d25300e57ecf05bb955b52ca654065fb733`, blocked on F1. The renamed aux r2 module is a distinct later candidate, pending fresh owner source review, with normal Muse approval. No approval or identity transfers from r1 to r2.

4. **Freeze-time labels:** Internal labels and questions such as “UNADOPTED CANDIDATE · PAPER ONLY” are accurate at the note’s freeze time, but must not be reused as current website copy without a new reviewed update. The same applies to the note’s Question 4, Question 5, and Question 10 treatment of publication and candidate status.

5. **Exact mapping:** The publication record should map the note and owner result to the supplied file identities — note `1a55057ade5c1eb494d5df58f6196e75ff058b8222d1e8c86db4fd516d91133a` and owner result `1f76b95e2e66a366bce28336ae349bf8d562a16931ceb62841877de92b024253` — and map each evidence tier to its pinned P3, Quint, host-packer, and P4 source records.

6. **Implementation boundary:** Any later scene or website must use the pinned primary sources verbatim for equation text and must separately obtain design and measured-contrast review. The note itself claims no website code, assets, deployment, circuit execution, measured layout, proof, cost, or physical gate count.

Subject to those Root-side clarifications, the unchanged note is accurate as a historical creative companion.
